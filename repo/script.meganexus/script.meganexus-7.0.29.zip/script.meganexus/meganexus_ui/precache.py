"""Kodi stores collection posters in advance - the One-time setup (7.0.8, 7.0.18).

Kodi makes its own copy of a poster (decode, resize, write to its texture cache
on disk) the first time it shows it, so a collection opened for the first time
showed its posters one by one (very visible on Android / CoreELEC boxes).
Kodi does the same work for an invisible image: behind the "One-time setup"
screen on opening MegaNexus (meganexus_loading.xml, Window.Property(
meganexus.precache.N)) it stores the first screen of every collection - after
the first install, after every update and when Kodi lacks more than 10 % of
them (``needs_full`` / ``plan``). Home opens at 90 %. Nothing runs in the
background afterwards (7.0.18: it competed with Kodi's own work on CoreELEC);
Kodi's normal cache takes over. About 30 KB per poster on the device.
HUB Settings > Performance turns it off (meganexus_poster_precache).
"""
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen

import xbmcaddon
import xbmcgui

from . import kodi_textures

SLOTS = 30            # a collection's first screen at once, as when it opens
SLOTS_ARM = 10        # 7.0.17: CoreELEC / Android boxes decode far fewer at once
PER_SHELF = 12        # the first screen of a row
WAIT = 8              # seconds Kodi gets for one batch
STALL = 2             # ... or fewer when it stores nothing more (a broken image link)
FULL_SHARE = .8       # Kodi keeps fewer than this share of the last full preload: preload again
TOTAL_SETTING = 'meganexus_precache_total'
VERSION_SETTING = 'meganexus_precache_version'   # 7.0.16: the preload runs again after every update
AHEAD_WORKERS = 6     # the next batch downloads into the image RAM while Kodi stores this one
RING_STEPS = 20
RING_DONE = .9        # the ring next to HUB shows the tick from 90 % (the rest needs no watching)

# This interface session: posters Kodi keeps (done), those still to store
# (todo, Home order) and every poster MegaNexus wants stored (wanted, the ring).
_STATE = {'lock': threading.Lock(), 'base': '', 'done': set(), 'todo': {}, 'wanted': set(), 'shown_done': False}


def slots():
    """Invisible images in use at once: fewer on ARM boxes (CoreELEC, Android)."""
    import platform
    machine = (platform.machine() or '').lower()
    return SLOTS_ARM if machine.startswith(('arm', 'aarch')) else SLOTS


def enabled():
    try:
        return xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_poster_precache') != 'false'
    except Exception:
        return False


def base():
    value = xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
    return value if value.startswith('http://127.0.0.1:') else ''


def _reset(proxy):
    if _STATE['base'] != proxy:
        _STATE.update(base=proxy, done=set(), todo={}, wanted=set(), shown_done=False)


def card_art(row, landscape=False):
    if landscape:
        return str(row.get('landscape') or row.get('fanart') or row.get('poster') or '')
    return str(row.get('poster') or '')


def targets(proxy, rows, landscape=False):
    """Proxy URLs of the first screen of one row."""
    result = []
    for row in [r for r in rows or [] if r.get('target')][:PER_SHELF]:
        url = card_art(row, landscape)
        if url.startswith(('https://', 'http://')) and '|' not in url:
            result.append(kodi_textures.proxy_url(proxy, url))
    return result


def collection_targets(proxy, collection_id, landscape=False, remembered=None):
    """First screens of every row of a collection (cached catalog pages only)."""
    from resources.lib import home_data
    from resources.lib.collections_home import collection_shelves
    found = []
    for shelf in collection_shelves(collection_id):
        rows = remembered(shelf) if remembered else None
        if rows is None:
            try:
                rows = home_data.load_catalog(shelf, cached_only=True)
            except Exception:
                rows = None
        found.extend(targets(proxy, rows, landscape))
    return found


def mark(proxy, kept):
    with _STATE['lock']:
        _reset(proxy)
        _STATE['done'].update(kept)
        for url in kept:
            _STATE['todo'].pop(url, None)


def add(proxy, urls, front=False):
    """Queue posters for the idle work (front: the cursor's neighbours)."""
    if not proxy or not urls:
        return
    with _STATE['lock']:
        _reset(proxy)
        urls = list(dict.fromkeys(urls))
        _STATE['wanted'].update(urls)
        new = {url: True for url in urls if url not in _STATE['done']}
        if front:
            new.update((url, True) for url in _STATE['todo'] if url not in new)
            _STATE['todo'] = new
        else:
            for url in new:
                _STATE['todo'].setdefault(url, True)
    publish()


def peek(count):
    with _STATE['lock']:
        result = []
        for url in _STATE['todo']:
            if len(result) >= count:
                break
            if url not in _STATE['done']:
                result.append(url)
        return result


def _head(url):
    try:
        with urlopen(Request(url, method='HEAD'), timeout=6) as response:
            response.read(0)
    except Exception:
        pass


def pending():
    with _STATE['lock']:
        return bool(_STATE['todo'])


def take(count):
    with _STATE['lock']:
        batch = []
        while _STATE['todo'] and len(batch) < count:
            url = next(iter(_STATE['todo']))
            del _STATE['todo'][url]
            if url not in _STATE['done']:
                batch.append(url)
        return batch


def store(window, batch, stopped, wait=time.sleep):
    """Hand a batch to Kodi through the window's invisible images and wait
    until its texture cache has them (or WAIT). Returns how many were stored."""
    kept = kodi_textures.kept(batch)
    left = [url for url in batch if url not in kept][:slots()]
    stored = 0
    with _STATE['lock']:
        _STATE['done'].update(kept)
    if left:
        for slot, url in enumerate(left):
            window.setProperty('meganexus.precache.%d' % slot, url)
        waiting = set(left)
        deadline = time.monotonic() + WAIT
        moved = time.monotonic()
        try:
            while waiting and not stopped() and time.monotonic() < deadline and time.monotonic() - moved < STALL:
                if wait(.1):
                    break
                got = kodi_textures.kept(waiting)
                if got:
                    moved = time.monotonic()
                    waiting -= got
                    stored += len(got)
                    with _STATE['lock']:
                        _STATE['done'].update(got)
                    publish()
        finally:
            for slot in range(len(left)):
                window.setProperty('meganexus.precache.%d' % slot, '')
    publish()
    return stored


def progress():
    with _STATE['lock']:
        wanted = _STATE['wanted']
        return len(wanted & _STATE['done']), len(wanted)


def publish():
    """7.0.18: no ring next to HUB any more (the invisible posters only run behind
    the One-time setup screen, which shows its own ring); clears an old one."""
    try:
        xbmcgui.Window(10000).clearProperty('meganexus.precache.ring')
    except Exception:
        pass


def _version():
    try:
        return xbmcaddon.Addon('script.meganexus').getAddonInfo('version') or ''
    except Exception:
        return ''


def needs_full(proxy):
    """The preload check: never done on this device, done for an earlier
    version (7.0.16: after every update), or Kodi keeps far fewer posters than
    after the last one (one query). plan() then counts what is really missing."""
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    try:
        expected = int(addon.getSetting(TOTAL_SETTING) or 0)
    except (ValueError, Exception):
        expected = 0
    if not expected or addon.getSetting(VERSION_SETTING) != _version():
        return True
    return len(kodi_textures.cached(proxy)) < expected * FULL_SHARE


def plan(collection_ids, landscape, stopped=lambda: False):
    """Every collection's first screen: queued, Kodi's copies marked, the total
    and this version remembered. Returns (stored by Kodi, total)."""
    proxy = base()
    if not proxy or not enabled():
        return 0, 0
    wanted = []
    for collection_id in collection_ids:
        if stopped():
            return 0, 0
        try:
            wanted += collection_targets(proxy, collection_id, landscape)
        except Exception:
            continue
    wanted = list(dict.fromkeys(wanted))
    mark(proxy, kodi_textures.cached(proxy))
    add(proxy, wanted)
    try:
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        addon.setSetting(TOTAL_SETTING, str(len(wanted)))
        addon.setSetting(VERSION_SETTING, _version())
    except Exception:
        pass
    return progress()


def prepare_all(window, collection_ids, landscape, stopped, wait, label):
    """Behind the "One-time setup" screen: the first screen of every
    collection, SLOTS at once. label(done, total) shows the progress.
    Returns (stored, total)."""
    if not base() or not enabled():
        return 0, 0
    plan(collection_ids, landscape, stopped)
    return run(window, stopped, wait, label)


def run(window, stopped, wait, label):
    """Store the queued posters until RING_DONE of them are in Kodi's cache."""
    stored = 0
    ahead = ThreadPoolExecutor(max_workers=AHEAD_WORKERS, thread_name_prefix='MegaNexusPreloadNet')
    asked, futures = set(), []
    def download(urls):
        for url in urls:
            if url not in asked:
                asked.add(url)
                futures.append(ahead.submit(_head, url))
    try:
        download(peek(slots()))
        while not stopped():
            done, total = progress()
            label(done, total)
            if done >= total * RING_DONE:
                break                    # 7.0.11: Home opens at 90 %; the rest finishes there in the background
            batch = take(slots())
            if not batch:
                break
            download(batch)              # (normally already asked for)
            download(peek(slots()))        # the next batch, while Kodi stores this one
            stored += store(window, batch, stopped, wait)
    finally:
        for future in futures:
            future.cancel()
        ahead.shutdown(wait=False)       # Kodi on Windows still embeds Python 3.8
    done, total = progress()
    label(done, total)
    return stored, total
