from resources.lib import art_cache
"""Rounded source selection and artwork that stays visible until AV starts."""
import queue
import re
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

class JobPool:
    """Bounded workers which can close and reopen with Kodi's reused invoker."""
    def __init__(self,workers=2,name="MegaNexusLoad"):
        self.lock=threading.RLock();self.pool=None;self.pending=set();self.workers=workers;self.name=name
    def submit(self,fn):
        with self.lock:
            if self.pool is None:self.pool=ThreadPoolExecutor(max_workers=self.workers,thread_name_prefix=self.name)
            future=self.pool.submit(fn);self.pending.add(future)
            future.add_done_callback(self._done)
            return future
    def _done(self,future):
        with self.lock:self.pending.discard(future)
    def shutdown(self):
        with self.lock:
            pool=self.pool;self.pool=None;pending=list(self.pending);self.pending.clear()
        for future in pending:future.cancel()
        if pool:pool.shutdown(wait=False)

_JOBS=JobPool()
_BACKGROUND=JobPool(1,"MegaNexusDetailsExtras")
_CATALOG=JobPool(2,"MegaNexusCatalog")
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import backend_api

ROOT=xbmcaddon.Addon('script.meganexus').getAddonInfo('path')

from .source_text import plain as plain_label, normalized as normalized_source
from resources.lib.theme import folder as theme_folder

LOCK=25   # seconds Back / Esc wait while a chosen source starts

class Loading(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self._xml=args[0] if args else '';self.meta=kwargs.get('meta') or {};self.full=kwargs.get('full',False);self.label=kwargs.get('label','Loading sources');self.cancelled=False
        self.hub=kwargs.get('hub',False)  # 7.0.10: HUB picture + progress ring (opening MegaNexus / Sport)
        self._closed=False;self._filling=False;self.locked=0
        # 7.0.29: the title's picture is there from the first frame (onInit comes after
        # the window was first drawn - the wallpaper showed for a moment).
        try:self.apply()
        except Exception:pass
    def apply(self,meta=None):
        """The title's picture, logo and name - again when the full details arrive
        (7.0.29: a resume opens this screen at once, on the card's own pictures)."""
        if meta:self.meta=meta
        m=self.meta or {}
        art=m.get('background') or m.get('fanart') or m.get('poster') or ''
        self.setProperty('meganexus.full','1' if self.full else '')
        self.setProperty('meganexus.hub','1' if self.hub else '')
        self.setProperty('meganexus.art',art_cache.url(art) if art else '')
        self.setProperty('meganexus.poster',art_cache.url(m.get('poster') or ''))
        self.setProperty('meganexus.title',m.get('name') or m.get('title') or '')
        # 7.0.12: the title's logo fills from left to right while streams are searched.
        logo=(m.get('logo') or m.get('clearlogo')) if (self.full and not self.hub) else ''
        self.setProperty('meganexus.logo',art_cache.url(logo) if logo else '')
        if logo and not self._filling:
            self._filling=True
            threading.Thread(target=self._fill,name='MegaNexusLogoFill',daemon=True).start()
    def onInit(self):
        xbmcgui.Window(10000).setProperty('meganexus.loading.active',str(time.time()))  # 7.0.11: when, so a lost one expires
        if self.hub and not self.getProperty('meganexus.ring'):self.setProperty('meganexus.ring','00')
        self.setProperty('meganexus.loading',self.label)
        self.apply()
    def _fill(self):
        import math
        start=time.monotonic();monitor=xbmc.Monitor()
        while not self._closed:
            # Fast at first, then slower towards 90 % - the search time is unknown.
            step=max(1,min(18,int(18*(1-math.exp(-(time.monotonic()-start)/4.0)))+1))
            self.setProperty('meganexus.fill','%02d'%step)
            if monitor.waitForAbort(.15):break
    def filled(self):
        self.setProperty('meganexus.fill','20')
    def onAction(self,action):
        if action.getId() in (9,10,92,216):
            # 7.0.29: once a source is starting, Back / Esc wait - leaving then left the film
            # loading behind Home and the display switching colours under the interface.
            # A source that never opens can still be left after LOCK seconds.
            if self.locked and time.monotonic()-self.locked<LOCK:return
            self.cancelled=True
    def close(self):
        self._closed=True
        xbmcgui.Window(10000).clearProperty('meganexus.loading.active')
        super().close()

BUSY_XML='meganexus_busy.xml'


def job(fn,meta=None,full=False,label='Loading sources',cancel=None,window=None,quiet=False):
    """Run fn off the GUI thread behind a loading screen. An already open
    ``window`` is reused and left open, so consecutive steps show one screen.
    ``quiet`` (7.0.29): during a video - a small pill at the bottom instead of the
    loading screen, the film stays in view (an error still comes as a dialog)."""
    own=window is None
    xml=BUSY_XML if quiet else 'meganexus_loading.xml'
    win=window or Loading(xml,ROOT,theme_folder(),'1080i',meta=meta,full=full,label=label)
    if not own:win.setProperty('meganexus.loading',label)
    results=queue.Queue()
    def work():
        try:results.put((True,fn()))
        except Exception as exc:results.put((False,exc))
    if own:win.show()
    future=_JOBS.submit(work)
    try:
        while not win.cancelled and not xbmc.Monitor().abortRequested():
            try:
                ok,value=results.get_nowait()
                if win.cancelled or xbmc.Monitor().abortRequested():return None
                if not ok:raise value
                return value
            except queue.Empty:
                xbmc.Monitor().waitForAbort(.05)
        return None
    finally:
        if cancel is not None:cancel.set()
        future.cancel()
        if own:
            win.close()
            gone(xml)


def gone(xml,limit=1.5):
    """7.0.29: wait until Kodi has really removed a closed MegaNexus window. On the
    Cube the next window (Choose source) got the id of the Loading window that was
    still fading out: its list could not take the focus - an empty screen the remote
    could hardly leave, and it worked only after a few tries."""
    monitor=xbmc.Monitor();end=time.monotonic()+limit
    while xbmc.getCondVisibility('Window.IsVisible(%s)'%xml) and time.monotonic()<end:
        if monitor.waitForAbort(.03):break

DIRECT=('torbox','premiumize')   # the debrid services' own results ("TorBox direct")


def addon_of(row):
    """(key, label) of the add-on a source comes from - every source shows it."""
    source=row.get('_meganexus_source') or {}
    name=plain_label(source.get('name') or '') or 'Add-on'
    if source.get('id') in DIRECT:name+=' direct'
    return str(source.get('id') or name),name


def addon_tabs(rows):
    """7.0.29: [(key or None, label)] above the list: All, TorBox direct, Premiumize
    direct (when they have sources), then the other add-ons by name."""
    counts={};names={}
    for row in rows:
        key,name=addon_of(row);counts[key]=counts.get(key,0)+1;names[key]=name
    direct=[k for k in DIRECT if k in counts]
    others=sorted((k for k in counts if k not in DIRECT),key=lambda k:names[k].casefold())
    return [(None,'All · %d'%len(rows))]+[(k,'%s · %d'%(names[k],counts[k])) for k in direct+others]


class Sources(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self.rows=kwargs['rows'];self.choice=-1;self.closed=False;self.ready=False
        self.download=kwargs.get('download')   # 7.0.29: long OK / menu key on a source
        self.tabs=[];self.tab=0;self.visible=[]
    def _item(self,i,row):
        name=' '.join(plain_label(row.get('name')).split()) or 'Source %d'%(i+1)
        _,provider=addon_of(row)
        name=provider+' · '+name          # 7.0.29: always the add-on it comes from
        details='  |  '.join(plain_label(row.get('title') or row.get('description')).splitlines())
        item=xbmcgui.ListItem(label=name,label2=details)
        item.setProperty('provider',provider)
        item.setProperty('size',source_size(row))
        # 7.0.29: Nuvio badges are their own pictures, side by side - Kodi
        # draws (downloads, scales, caches) them; no pill of ours around them.
        custom=row.get('_meganexus_badges')
        pictures=[badge.get('kodi_image') or badge.get('image') for badge in (custom or [])]
        pictures=[picture for picture in pictures if picture][:8]
        for index,picture in enumerate(pictures):item.setProperty('badge%d.img'%index,picture)
        if not pictures:   # no badge set (or no pictures in it): the names, quietly
            names=[badge['name'] for badge in custom[:8]] if custom is not None else source_badges(row)
            item.setProperty('badgetext','  ·  '.join(names))
        return item
    def _fill(self,keep=None):
        key=self.tabs[self.tab][0]
        self.visible=[i for i,row in enumerate(self.rows) if key is None or addon_of(row)[0]==key]
        control=self.getControl(500);control.reset()
        control.addItems([self._item(i,self.rows[i]) for i in self.visible])
        at=next((n for n,i in enumerate(self.visible) if self.rows[i] is keep),0) if keep is not None else 0
        if self.visible:control.selectItem(at)
        tabs=self.getControl(600)
        for index in range(len(self.tabs)):
            tabs.getListItem(index).setProperty('active','1' if index==self.tab else '')
    def onInit(self):
        self.tabs=addon_tabs(self.rows);self.tab=0
        tabs=self.getControl(600);tabs.reset()
        tabs.addItems([xbmcgui.ListItem(label=label) for _,label in self.tabs])
        self._fill()
        self.setFocusId(500);self.ready=True
    def _current(self):
        try:pos=self.getControl(500).getSelectedPosition()
        except Exception:return None
        return self.rows[self.visible[pos]] if 0<=pos<len(self.visible) else None
    def update_rows(self,rows,more):
        """7.0.29: more add-ons answered - the list grows where it is; the source
        under the cursor stays under the cursor."""
        self.setProperty('meganexus.sources.more','Loading more sources…' if more else '')
        if not self.ready or rows is self.rows:return
        keep=self._current();key=self.tabs[self.tab][0] if self.tabs else None
        self.rows=rows;self.tabs=addon_tabs(rows)
        self.tab=next((i for i,(k,_) in enumerate(self.tabs) if k==key),0)
        tabs=self.getControl(600);tabs.reset()
        tabs.addItems([xbmcgui.ListItem(label=label) for _,label in self.tabs])
        tabs.selectItem(self.tab)
        self._fill(keep)
    def tick(self):
        """Moving along the add-on row filters the list (select_source's loop)."""
        if not self.ready or self.closed or self.getFocusId()!=600:return
        pos=self.getControl(600).getSelectedPosition()
        if 0<=pos<len(self.tabs) and pos!=self.tab:
            self.tab=pos;self._fill()
    def close(self):
        self.closed=True;super().close()
    def onClick(self,cid):
        if cid==500:
            pos=self.getControl(500).getSelectedPosition()
            if 0<=pos<len(self.visible):self.choice=self.visible[pos];self.close()
        elif cid==600:self.setFocusId(500)
    def onAction(self,action):
        if action.getId() in (9,10,92,216):self.close()
        elif action.getId() in (101,117) and getattr(self,'download',None) and self.getFocusId()==500:
            # 7.0.29: a long OK (Kodi's context menu) - download this source; the list stays
            index=self.getControl(500).getSelectedPosition()
            if 0<=index<len(self.visible):self.download(self.rows[self.visible[index]])

def _download(meta,context,row,source):
    from .downloads import start
    start(meta,context,row,source)   # playback_context takes the row's own add-on first


def select_source(rows,download=None,cover=None,feed=None):
    """The source list. ``cover`` (7.0.29): the loading shown while the sources were
    searched - the list opens over it and it closes underneath, so nothing between
    them blinks (the wallpaper, black or another screen showed for a moment)."""
    from resources.lib import quality_badges,settings_cache
    # Phone imports can happen while Home's interpreter is still running.
    # Read the current toggle for this explicit source choice.
    settings_cache.invalidate()
    if feed is None and quality_badges.cached_addon().getSetting(quality_badges.ENABLED)=='true':
        prepared=job(lambda:quality_badges.decorate(rows),label='Preparing source badges',window=cover)
        if prepared is None:
            if cover is not None:cover.close()
            return -1
        rows=prepared
    if cover is None:gone('meganexus_loading.xml')
    win=Sources('meganexus_sources.xml',ROOT,theme_folder(),'1080i',rows=rows,download=download)
    try:
        win.show();monitor=xbmc.Monitor();focused=False;version=feed['version'] if feed else 0
        while not win.closed and not monitor.abortRequested():
            monitor.waitForAbort(.05)
            # Loading.close and Sources.show can land in the same GUI frame.
            # Apply focus after activation, when Kodi has finished closing Loading.
            win.tick()
            if feed and win.ready and (feed['version']!=version or bool(win.getProperty('meganexus.sources.more'))==feed['done']):
                version=feed['version'];win.update_rows(feed['rows'],not feed['done'])
            if win.ready and not focused and not win.closed:
                win.setFocusId(500);focused=True
                if cover is not None:
                    cover.close();cover=None     # under the list now
        if feed is not None:feed['shown']=win.rows
        return win.choice
    finally:
        win.close()
        if cover is not None:cover.close()


WAIT_XML='meganexus_wait.xml'
# 7.0.29: screens a title was started from (Dialog.in_place). They stay while its
# sources are searched and chosen and hide only once the video starts.
PARENTS=[]


def wait_overlay(label='Loading sources…',meta=None):
    """The blue loading in the middle, over the screen the title was started from."""
    win=Loading(WAIT_XML,ROOT,theme_folder(),'1080i',meta=meta or {},label=label)
    win.show()
    return win


def _hide_parents():
    for parent in list(PARENTS):
        if not getattr(parent,'_meganexus_play_hidden',True):
            parent._meganexus_play_hidden=True
            try:xbmcgui.WindowXMLDialog.close(parent)
            except Exception:pass


PLAYING='meganexus.playing.request'


def remember_playing(meta,context,row):
    """7.0.29: what is playing, for the player's Sources button and its badge
    row (Window(Home).Property(meganexus.playing.*))."""
    import json
    home=xbmcgui.Window(10000)
    keep={k:context.get(k) for k in ('video_id','season','episode') if context.get(k) not in (None,'')}
    try:home.setProperty(PLAYING,json.dumps({'meta':meta,'context':keep},default=str))
    except (TypeError,ValueError):home.clearProperty(PLAYING)
    pictures=[]
    if row:
        try:
            from resources.lib import quality_badges
            badges=row.get('_meganexus_badges')
            if badges is None and quality_badges.cached_addon().getSetting(quality_badges.ENABLED)=='true':
                badges=quality_badges.match(' '.join(str(row.get(k) or '') for k in ('name','title','description')))
            pictures=[p for p in (b.get('kodi_image') or b.get('image') for b in (badges or [])) if p][:8]
        except Exception:pictures=[]
        home.setProperty('meganexus.playing.source',plain_label(row.get('name') or ''))
    else:home.clearProperty('meganexus.playing.source')
    for index in range(8):home.setProperty('meganexus.playing.badge%d'%index,pictures[index] if index<len(pictures) else '')


def switch_source():
    """The player's Sources button: pause, choose another source of the same
    title (the same picker), carry on from the same minute. Back resumes."""
    import json
    home=xbmcgui.Window(10000);player=xbmc.Player()
    try:data=json.loads(home.getProperty(PLAYING) or '{}')
    except ValueError:data={}
    meta=data.get('meta');context=data.get('context') or {}
    if not meta or not player.isPlayingVideo():
        xbmcgui.Dialog().notification('MegaNexus','No MegaNexus title is playing.');return False
    home.setProperty(CHOOSING,'1')
    try:return _switch(meta,context,player)
    finally:home.clearProperty(CHOOSING)


def _switch(meta,context,player):
    paused_here=False
    try:
        position=player.getTime()
        if not xbmc.getCondVisibility('Player.Paused'):player.pause();paused_here=True
    except Exception:position=0
    def carry_on():
        if paused_here and xbmc.getCondVisibility('Player.Paused'):player.pause()
    result=job(lambda:backend_api.streams(meta.get('type') or 'movie',context.get('video_id') or meta['id'],complete=True),meta,False,label='Loading sources',quiet=True)
    if not result or not result[1]:
        carry_on();return False
    source,rows=result
    selected=select_source(rows,download=lambda row:_download(meta,context,row,source))
    if selected<0:
        carry_on();return False
    remember_playing(meta,context,rows[selected])
    ctx=backend_api.playback_context(meta,rows[selected],source,context.get('season',''),context.get('episode',''),
                                     context.get('video_id') or meta['id'],int(position or 0))
    return _start(meta,ctx,None)


def source_size(row):
    size=(row.get('behaviorHints') or {}).get('videoSize') or row.get('size')
    try:
        size=float(size)
        if size>0:return ('%.2f GB'%(size/1_000_000_000))
    except (TypeError,ValueError):pass
    match=re.search(r'\b\d+(?:[.,]\d+)?\s*(?:GiB|GB|MiB|MB|TB)\b',str(row.get('title') or row.get('description') or ''),re.I)
    return match.group(0) if match else ''

class StartListener(xbmc.Player):
    def __init__(self,token):super().__init__();self.started=False;self.failed=False;self.token=token;self.opening=False;self.ended=False
    def onPlayBackStarted(self):self.opening=True   # the video is being opened: the TV switches next
    def onPlayBackEnded(self):
        if self.opening:self.ended=True              # 7.0.29: over at once - not a film
    def onPlayBackStopped(self):
        if self.opening:self.ended=True
    def onAVStarted(self):
        try:
            self.started=xbmcgui.Window(10000).getProperty('meganexus.playback.started')==self.token
        except Exception:pass
    def onPlayBackError(self):self.failed=True

CHOOSING='meganexus.playback.choosing'


def _hold_wallpaper(on):
    """7.0.29: the experimental video wallpaper steps aside while sources are
    searched and chosen (on Amlogic its video layer could hide the picker)."""
    home=xbmcgui.Window(10000)
    if not on:home.clearProperty(CHOOSING);return
    home.setProperty(CHOOSING,'1')
    try:
        from resources.lib import wallpaper_video
        wallpaper_video.suspend()
    except Exception:pass


def play(meta,context):
    _hold_wallpaper(True)
    try:return _play_held(meta,context)
    finally:_hold_wallpaper(False)


_HANDOFF=[]


def handoff(window):
    """7.0.29: a title's loading screen (its picture, the filling logo) already up
    when a resume starts - play() carries on in it instead of a second one."""
    _HANDOFF[:]=[window]


def _take_handoff():
    window=_HANDOFF[0] if _HANDOFF else None
    _HANDOFF[:]=[]
    return window


def _play_held(meta,context):
    auto=xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_autoplay')=='true' and not context.get('force_manual')
    loading_label='Loading video…' if auto else 'Loading sources…'
    # Autoplay keeps ONE loading screen from the source search until the video
    # starts; closing and reopening it flashed the page underneath.
    shared=_take_handoff()
    if not auto:
        # 7.0.29: choosing a source happens over the screen it was started from: the
        # blue loading in the middle until the list opens over it (no other screen,
        # wallpaper or black between them).
        if shared is None or getattr(shared,'_xml','')!=WAIT_XML:
            cover=wait_overlay(loading_label,meta)
            if shared is not None:shared.close()   # under the new one
            shared=cover
        else:shared.setProperty('meganexus.loading',loading_label)
    elif shared is not None:
        shared.full=True;shared.setProperty('meganexus.loading',loading_label)
        shared.apply(meta)   # the full details: their picture and logo
    else:
        shared=Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label=loading_label)
        shared.show()
    try:
        from resources.lib import last_source
        if context.get('meganexus_continue') or context.get('resume_seconds') or context.get('resume_percent'):
            try:cached=job(lambda:last_source.context(meta,context),meta,auto,label='Loading video…',window=shared)
            except Exception:cached=None
            if cached:
                # the last link's own name: the player's badges and source line (7.0.29)
                remember_playing(meta,context,{'name':cached.get('stream_name') or '','title':cached.get('stream_title') or ''})
                result=_start(meta,cached,shared if auto else None)   # the title's loading screen, not the small one
                if result:return True
                if result is None:return False
                _BACKGROUND.submit(lambda:last_source.forget(cached))
                if shared and shared.cancelled:return False
        return _play(meta,context,auto,loading_label,shared)
    finally:
        if shared:shared.close()


RECONNECTS=2   # 7.0.29: stream add-ons that did not answer are asked again


AUTO_SOURCES=3   # 7.0.29: sources Autoplay tries before it gives up
FIRST_SHOW=0.6   # 7.0.29: seconds the list waits for more once the first sources are in


def _grow(meta,context):
    """Search the sources in the background; feed['rows'] grows as add-ons answer."""
    import threading
    from resources.lib import quality_badges
    badges=quality_badges.cached_addon().getSetting(quality_badges.ENABLED)=='true'
    feed={'rows':[],'version':0,'done':False,'source':None,'error':None}
    lock=threading.Lock()
    def publish(rows):
        if badges:
            try:rows=quality_badges.decorate(rows)
            except Exception:pass
        with lock:feed['rows']=rows;feed['version']+=1
    def work():
        try:
            source,rows=backend_api.streams(meta.get('type') or 'movie',context.get('video_id') or meta['id'],complete=True,on_update=publish)
            feed['source']=source
            publish(rows)
        except Exception as exc:feed['error']=exc
        finally:feed['done']=True
    _JOBS.submit(work)
    return feed


def _choose(meta,context,cover,label):
    """7.0.29: the source list opens with the first sources, the others join it as
    their add-ons answer; reconnects when nothing came back."""
    monitor=xbmc.Monitor()
    for attempt in range(RECONNECTS+1):
        cover.setProperty('meganexus.loading',label)
        feed=_grow(meta,context);first=None
        while not monitor.abortRequested() and not cover.cancelled:
            if feed['rows'] and first is None:first=time.monotonic()
            if feed['done'] or (first is not None and time.monotonic()-first>=FIRST_SHOW):break
            monitor.waitForAbort(.05)
        if cover.cancelled or monitor.abortRequested():
            cover.close();return False
        if feed['rows']:break
        errors=(feed['source'] or {}).get('_meganexus_errors') or feed['error']
        if not errors or attempt==RECONNECTS:
            cover.close()
            if errors:xbmcgui.Dialog().ok('Sources','No streams found - the stream add-ons did not answer. Check the internet connection and try again.')
            else:xbmcgui.Dialog().ok('Sources','No streams found for this title.')
            return False
        label='Reconnecting… (%d of %d)'%(attempt+2,RECONNECTS+1)
        if monitor.waitForAbort(2):return False
    blank={'id':'','name':'','base_url':''}
    failed=[]
    while True:
        rows=[r for r in feed['rows'] if not any(r is f for f in failed)]
        if not rows:return False
        selected=select_source(rows,download=lambda row:_download(meta,context,row,feed['source'] or blank),cover=cover,feed=feed if not failed else None)
        cover=None
        if selected<0:return False
        shown=feed.get('shown') if not failed else None
        row=(shown or rows)[selected]
        remember_playing(meta,context,row)
        ctx=backend_api.playback_context(meta,row,feed['source'] or blank,context.get('season',''),context.get('episode',''),context.get('video_id') or meta['id'],context.get('resume_seconds') or 0)
        ctx['resume_percent']=context.get('resume_percent') or 0
        try:
            from resources.lib import last_source
            last_source.tag(ctx)
        except Exception:pass
        result=_start(meta,ctx,None)
        if result or result is None:return result
        # 7.0.29: it did not play - the list again, without it
        failed.append(row);feed.pop('shown',None)


def _play(meta,context,auto,loading_label,shared):
    if not auto and shared is not None:return _choose(meta,context,shared,loading_label)
    label=loading_label
    for attempt in range(RECONNECTS+1):
        result=job(lambda:backend_api.streams(meta.get('type') or 'movie',context.get('video_id') or meta['id'],complete=not auto),meta,auto,label=label,window=shared)
        if result is None or (shared and shared.cancelled):return False
        source,rows=result
        if rows or not source.get('_meganexus_errors') or attempt==RECONNECTS:break
        # Nothing came back because add-ons did not answer (no network, a slow
        # server): reconnect and ask again before saying there are no streams.
        label='Reconnecting… (%d of %d)'%(attempt+2,RECONNECTS+1)
        if xbmc.Monitor().waitForAbort(2):return False
    if source.get('_meganexus_errors') and rows:
        xbmcgui.Dialog().notification('Stream add-ons', '%d add-on(s) unavailable; showing available results.' % len(source['_meganexus_errors']))
    if not rows:
        if shared:shared.close()
        if source.get('_meganexus_errors'):
            xbmcgui.Dialog().ok('Sources','No streams found - the stream add-ons did not answer. Check the internet connection and try again.')
        else:
            xbmcgui.Dialog().ok('Sources','No streams found for this title.')
        return False
    # 7.0.29: Autoplay tries the next source when one does not play (an instant end,
    # a debrid "not ready" clip) - up to AUTO_SOURCES, the last one says why.
    tries=rows[:AUTO_SOURCES];window=shared
    for attempt,row in enumerate(tries):
        remember_playing(meta,context,row)
        ctx=backend_api.playback_context(meta,row,source,context.get('season',''),context.get('episode',''),context.get('video_id') or meta['id'],context.get('resume_seconds') or 0)
        ctx['resume_percent']=context.get('resume_percent') or 0
        try:
            from resources.lib import last_source
            last_source.tag(ctx)
        except Exception:pass
        result=_start(meta,ctx,window,quiet=attempt<len(tries)-1)
        if window is not shared:window.close()
        if result or result is None or (window and window.cancelled):return result
        if attempt<len(tries)-1:
            # the start closed its loading screen once the video was up - a new one
            window=Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,
                           label='Trying the next source… (%d of %d)'%(attempt+2,len(tries)))
            window.show()
    return False


PLAYS_FOR=4        # 7.0.29: seconds a started video must keep playing to count as started
PLACEHOLDER=90     # seconds: a "film" this short is a debrid service's "not ready" clip


def _really_plays(listener):
    """After the start: the video goes on (not an instant end, not a debrid
    service's short "still downloading" clip - StremThru shows one at 1 fps that
    ends at once, and MegaNexus went back to the title page without a word)."""
    monitor=xbmc.Monitor();until=time.monotonic()+PLAYS_FOR;player=xbmc.Player()
    ended=lambda:getattr(listener,'ended',False) is True
    while time.monotonic()<until and not monitor.abortRequested():
        try:playing=player.isPlayingVideo()
        except Exception:playing=True
        if ended() or not playing:return False
        try:total=float(player.getTotalTime())
        except Exception:total=0
        if 0<total<PLACEHOLDER:
            player.stop();return False
        if monitor.waitForAbort(.2):break
    return not ended()


def _start(meta,ctx,shared,quiet=False):
    import uuid
    token=uuid.uuid4().hex;ctx['meganexus_request_id']=token
    home=xbmcgui.Window(10000);home.clearProperty('meganexus.preview.active')
    home.setProperty('meganexus.playing.request_id',token)   # whose badges / Sources the player shows
    home.clearProperty('meganexus.preview.silent')
    listener=StartListener(token)
    win=shared or Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label='Starting playback')
    if shared is None:win.show()
    _hide_parents()    # 7.0.29: the screen it was started from, now under the loading screen
    curtain=None
    try:
        # 7.0.29: the title's picture and logo stay while the stream is found; black
        # only once the video opens and only with the refresh-rate switch on (the TV
        # blinks then). Without it the picture stays until the film is on screen.
        from resources.lib import curtain as display
        want_curtain=display.afr_on()
        handed=False
        win.locked=time.monotonic()
        xbmc.executebuiltin('RunPlugin("%s")'%backend_api.queue_playback(ctx))
        deadline=time.monotonic()+60
        while not listener.started and not listener.failed and not win.cancelled and time.monotonic()<deadline:
            # The long-lived service also confirms resolver handoffs which lose item properties.
            if home.getProperty('meganexus.playback.started')==token:
                listener.started=True;break
            if home.getProperty('meganexus.playback.error')==token:   # 7.0.12: the backend told why (TorBox...)
                home.clearProperty('meganexus.playback.error');return False
            if listener.opening and not handed and xbmc.getInfoLabel('VideoPlayer.HdrType') and display.hdr_switches():
                # An HDR film switches the display into HDR as its first picture comes:
                # the interface left over it showed in glaring, wrong colours. The
                # loading screen stays through the whole search and goes the moment
                # the video is known to be HDR - straight to the film, no black curtain.
                handed=True
                try:win.filled();win.close()
                except Exception:pass
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            # 7.0.29: black only when the video itself opens (its decoder exists) - the
            # TV switches then; at the file's opening it darkened a second too early.
            if want_curtain and curtain is None and listener.opening and xbmc.getCondVisibility('Player.HasVideo'):
                curtain=display.Curtain(fade_in=300)
            if xbmc.Monitor().waitForAbort(.1):break
        if listener.started:
            from resources.lib import last_source,session_store
            session=session_store.load_session() or {}
            saved=dict(ctx)
            if session.get('meganexus_request_id')==token and session.get('stream_url'):
                saved['stream_url']=session['stream_url']
            _BACKGROUND.submit(lambda:last_source.remember(saved))
            try:win.filled()
            except Exception:pass
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            # 7.0.29: the title's picture stays until the film is on screen - closed at
            # once, the wallpaper behind showed before the full-screen video.
            # 7.0.29: the loading screen stays until the film's picture really moves -
            # then it goes and the film is there (the page behind showed for a moment,
            # and the screen darkened about a second too early).
            monitor=xbmc.Monitor();until=time.monotonic()+8;player=xbmc.Player();first=None
            while time.monotonic()<until and not monitor.abortRequested():
                if getattr(listener,'ended',False) is True or not xbmc.getCondVisibility('Player.HasVideo'):break
                if not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                elif not xbmc.getCondVisibility('Player.Caching'):
                    try:now=player.getTime()
                    except Exception:now=0
                    if first is None:first=now
                    elif now>first+.2:break      # frames are moving
                monitor.waitForAbort(.1)
            try:win.close()     # the film is on screen; the check below happens under it
            except Exception:pass
            if _really_plays(listener):return True
            xbmc.log('[MegaNexus] The source ended at once (not ready on the debrid service?)',xbmc.LOGINFO)
            if not quiet and not ctx.get('_last_source_reused'):
                if shared:shared.close()
                xbmcgui.Dialog().ok('Playback','This source ended at once - it is probably not ready on the debrid service yet. Choose another source.')
            return False
        home.setProperty('meganexus.cancelled.'+token,'1')
        if win.cancelled:return None
        if not quiet and not win.cancelled and not ctx.get('_last_source_reused'):
            if shared:shared.close()
            xbmcgui.Dialog().ok('Playback','The selected source did not start. Try another source or check your provider.')
        return False
    finally:
        if shared is None:win.close()
        if curtain is not None:
            from resources.lib.curtain import SETTLE
            curtain.close(after=SETTLE)   # the video is there; fade in once the TV has switched


def source_badges(row):
    """Portable text pills replace font-dependent provider emoji badges."""
    raw=normalized_source(' '.join(str(row.get(k) or '') for k in ('name','title','description')))
    text=raw.upper(); result=[]
    for label,pattern in [('4K',r'\b(?:2160P|4K|UHD)\b'),('1080p',r'\b1080P\b'),('720p',r'\b720P\b'),
                          ('Dolby Vision',r'\b(?:DV|DOVI|DOLBY VISION)\b'),('HDR10+',r'HDR10\+'),('HDR',r'\bHDR(?:10)?\b'),
                          ('DD+',r'\b(?:DDP|DD\+|E[ .-]?AC[ .-]?3)(?![A-Z])'),('DTS',r'\bDTS\b'),('HEVC',r'\b(?:HEVC|X265|H[ .]?265)\b'),('AV1',r'\bAV1\b'),('Atmos',r'\bATMOS\b'),
                          ('Remux',r'\bREMUX\b'),('WEB-DL',r'\bWEB[ .-]?DL\b')]:
        if re.search(pattern,text):result.append(label)
    if any(c in raw for c in ('⚡','🚀')) or re.search(r'\bCACHED\b',text):result.append('Cached')
    if '🇭🇷' in raw or re.search(r'\b(?:CROATIAN|HRV|HRVATSKI)\b',text):result.append('HR')
    if '🇬🇧' in raw or '🇺🇸' in raw or re.search(r'\b(?:ENGLISH|ENG)\b',text):result.append('EN')
    return result[:8]
