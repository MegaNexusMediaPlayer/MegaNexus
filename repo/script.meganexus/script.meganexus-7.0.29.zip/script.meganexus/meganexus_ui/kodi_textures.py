"""Posters Kodi already keeps, and the image memory the preload may fill (7.0.7).

Kodi stores every poster it has shown in its own texture cache on disk
(userdata/Thumbnails + Textures DB) and never asks the image proxy for it
again, also after a restart. Preloading those into the proxy's RAM only cost
time, data and memory (the poster screen after each Kodi start). The preload
now skips them and fills the proxy with the posters Kodi does not have yet, up
to SHARE of the chosen image memory (RAM 128 / 256 / 512 MiB).
"""
import json
import os
from urllib.parse import quote, unquote

import xbmc
import xbmcgui

SHARE = .8


def proxy_url(base, url):
    return base + '/image?url=' + quote(url, safe='')


def _plain(url):
    url = str(url or '')
    if url.startswith('image://'):   # JSON-RPC wraps texture URLs as image://<encoded>/
        url = unquote(url[8:])
    return url.rstrip('/')


def cached(base):
    """Proxy URLs Kodi has in its texture cache; empty when unknown (preload all)."""
    if not str(base or '').startswith('http://127.0.0.1:'):
        return set()
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.GetTextures',
               'params': {'properties': ['url'], 'filter': {'field': 'url', 'operator': 'startswith', 'value': base + '/'}}}
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        textures = (reply.get('result') or {}).get('textures') or []
    except Exception:
        return set()
    return {_plain(texture.get('url')) for texture in textures if isinstance(texture, dict) and texture.get('url')}


def kept(urls):
    """Those of these (proxy) URLs Kodi keeps in its texture cache.

    7.0.17: read from Kodi's thumbnail files, not its Textures database - polling
    the database while Kodi writes to it for every new poster blocked Kodi's
    interface on CoreELEC (clicks did nothing for 20 s). Kodi names the file
    after the CRC-32 of the lower-case URL: Thumbnails/<h[0]>/<h>.jpg|png."""
    root = _thumbnails()
    if not root:
        return set()
    found = set()
    for url in urls:
        digest = kodi_crc(url)
        folder = os.path.join(root, digest[0])
        if os.path.exists(os.path.join(folder, digest + '.jpg')) or os.path.exists(os.path.join(folder, digest + '.png')):
            found.add(url)
    return found


_THUMBS = []


def _thumbnails():
    if not _THUMBS:
        try:
            import xbmcvfs
            _THUMBS.append(xbmcvfs.translatePath('special://thumbnails/'))
        except Exception:
            return ''
    return _THUMBS[0]


def _crc_table():
    table = []
    for i in range(256):
        c = i << 24
        for _ in range(8):
            c = ((c << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if c & 0x80000000 else (c << 1) & 0xFFFFFFFF
        table.append(c)
    return table


_CRC = _crc_table()


def kodi_crc(text):
    """Kodi's Crc32::ComputeFromLowerCase (MSB-first CRC-32, no final xor), hex."""
    crc = 0xFFFFFFFF
    for byte in str(text).lower().encode('utf-8'):
        crc = ((crc << 8) & 0xFFFFFFFF) ^ _CRC[((crc >> 24) ^ byte) & 0xFF]
    return '%08x' % crc


def budget():
    """Bytes the preload may fill: SHARE of the chosen image memory."""
    try:
        import xbmcaddon
        from resources.lib import art_cache, ram_profile
        mode = ram_profile.chosen(xbmcaddon.Addon('plugin.video.meganexus'))
        return int(art_cache.LIMITS.get(mode, 0) * SHARE)
    except Exception:
        return 0


def used():
    """Bytes in the image proxy now (its 'x.x MB · n images' Home property)."""
    text = xbmcgui.Window(10000).getProperty('meganexus.art_cache.usage') or ''
    try:
        return int(float(text.split('MB')[0].strip()) * 1024 * 1024)
    except ValueError:
        return 0
