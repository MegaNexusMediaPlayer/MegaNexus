# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from .dialog import Dialog
from .top_row import TopRow
"""Channel browser with EPG and two-click preview/fullscreen playback."""
import time
import queue
import threading
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from .system_setup import rpc,ensure_addon
from .play_jobs import plain_label, job
from . import listitems
from .player_osd import player_buttons,switched
from resources.lib import screen_guard
from resources.lib.iptv_config import xtream_urls,apply_features,ensure_client_enabled
from resources.lib.theme import folder as theme_folder
from resources.lib.settings_snapshot import cached_addon

ADDON=cached_addon()
_CHANNEL_CACHE=OrderedDict()
_CHANNEL_LOCK=threading.Lock()

TIMESHIFT='meganexus_iptv_timeshift'      # 7.0.29, opt-in: inputstream.ffmpegdirect asks an offline
                                          # channel on Kodi's GUI thread (30 s freezes, seen on a PC)
CATCHUP='meganexus_iptv_catchup'          # 7.0.29, default on
FEATURES_APPLIED='meganexus_iptv_features'   # '2': timeshift opt-in (7.0.29 test builds wrote it on)

# 7.0.48: as in Sport - OK on the channel that plays opens Kodi's own full-screen player
# (the same playback, no new start); its IPTV buttons (review/make_iptv_osd.py) do the rest.
# The enlarged channel inside this window (7.0.32) is gone.
GROUPS_BUTTON=507         # 7.0.37: the channel groups to load
ARCHIVE_LIST=961         # 7.0.48: the picker over Kodi's player: the catch-up box
STRIP=980                # ... the channels as logos
CHANNEL_DWELL=.6          # seconds on a channel before its catch-up loads
ARCHIVE_HOURS=7*24        # the catch-up shown: this far back (7.0.48: the guide says what plays - the
                          # provider's days, iptv_catchup.py; it was 24 hours of a 2-3 day archive)
INFO=(11,)                # Info: Kodi's own full-screen player
STOP=(13,)                # Stop stops the channel; Back never does
HINT='OK  Preview, again for full screen     Back  HUB button'
OSD_COMMAND='meganexus.iptv.osd'   # the player's IPTV buttons (review/make_iptv_osd.py)
SWITCH_GRACE=8.0         # seconds a channel switch in Kodi's player may take
RECENT=5                  # Last channels: the last ones watched
BACK=(9,10,92,216,247,257,275,61448,61467)


def feature_on(key):
    if key==TIMESHIFT:return ADDON.getSetting(key)=='true'
    return ADDON.getSetting(key)!='false'


def apply_iptv_features(quiet=False):
    """Write timeshift / catch-up into MegaNexus' IPTV Simple instance (Kodi reloads the channels)."""
    from resources.lib import iptv_lists
    numbers=iptv_lists.instances(_folder()) or [n for n in [ADDON.getSetting('meganexus_iptv_instance')] if n]
    if not numbers or xbmc.getCondVisibility('Pvr.IsPlayingTV'):return False
    if feature_on(TIMESHIFT) and not ensure_addon('inputstream.ffmpegdirect'):return False
    profile=_pvr_profile()
    rpc('Addons.SetAddonEnabled',{'addonid':'pvr.iptvsimple','enabled':False})
    try:done=all([apply_features(profile,n,feature_on(TIMESHIFT),feature_on(CATCHUP)) for n in numbers])   # 7.0.37: every list
    finally:ensure_client_enabled(rpc)
    if done:
        ADDON.setSetting(FEATURES_APPLIED,'2')
        if not quiet:xbmcgui.Dialog().notification('Live TV','Saved - the channels reload in a moment.',time=3000)
    return done


def configure():
    """IPTV setup chooser (translucent settings page, 7.0); 7.0.29: timeshift and catch-up."""
    from . import settings_page as page
    def build():
        lists=_lists()
        return ([('lists',page.item('IPTV lists','%d · channels, VOD, groups'%len(lists)))] if lists else [])+[
                        ('xtream',page.item('Add an Xtream account')),('m3u',page.item('Add an M3U playlist + XMLTV TV guide')),
                        ('pvr',page.item('Use an existing Kodi PVR setup')),
                        ('timeshift',page.item('Pause and rewind live TV · may freeze Kodi on some boxes',enabled=feature_on(TIMESHIFT))),
                        ('catchup',page.item('Catch-up: past programmes, when the list has an archive',enabled=feature_on(CATCHUP))),
                        ('live',page.item('Only live TV in the channel list (less RAM, faster start)',
                                          enabled=ADDON.getSetting('meganexus_iptv_live_only')!='false'))]
    def act(key):
        if key=='pvr':return page.DONE
        if key=='lists':return lists_page()
        if key=='live':
            ADDON.setSetting('meganexus_iptv_live_only','false' if live_only() else 'true')
            if configured():apply_lists()
            return None
        if key in ('timeshift','catchup'):
            setting={'timeshift':TIMESHIFT,'catchup':CATCHUP}[key]
            ADDON.setSetting(setting,'false' if feature_on(setting) else 'true')
            if configured():apply_iptv_features()
            return None
        return page.DONE if setup(key) else None
    page.keyed('IPTV setup',build,act)
    return configured()


def configured():
    """Live TV is set up. 8.1.2: the lists on disk count as well as the setting.

    The setting is a copy of what iptv-lists.json holds, and on one machine it read
    false while the store held a working list of 1,150 channels - so Settings said
    "not set" and nothing would repair it. The store is asked first; the service puts
    the setting right at the next start (hub_service._iptv_on_again).
    """
    if ADDON.getSetting('meganexus_iptv_configured')=='true':return True
    try:
        from resources.lib import iptv_lists
        return iptv_lists.set_up(_folder())
    except Exception:
        return False


def _folder():
    return xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))


def _pvr_profile():
    """IPTV Simple's own data folder, without asking Kodi for the add-on.

    8.1.2: xbmcaddon.Addon('pvr.iptvsimple') raises "Unknown addon id" while the add-on
    is DISABLED - and MegaNexus disables it itself, deliberately, every time it writes a
    playlist (Kodi only rereads one when it is enabled again). So this failed exactly
    during the moments IPTV needed it: "EXCEPTION: Unknown addon id 'pvr.iptvsimple'"
    a dozen times in forty seconds, one channel list taking 32.7 s instead of 0.2 s,
    and the click meant to play a channel raising inside its own handler - the screen
    that loads and never opens.

    The path is Kodi's own layout and needs no add-on object; hub_service has always
    used this form.
    """
    return xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple/')


def _log(text):xbmc.log(text,xbmc.LOGINFO)


def _lists():
    """7.0.37: the IPTV lists (the one list of 7.0.36 and older becomes the first)."""
    from resources.lib import iptv_lists
    # 7.0.46: without IPTV Simple Client there is no old list to move (and asking for it logs an error)
    if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
        try:iptv_lists.migrate(_folder(),_pvr_profile(),configured(),ADDON.getSetting('meganexus_iptv_instance'))
        except Exception:pass
    return iptv_lists.load(_folder())


def live_only():
    return ADDON.getSetting('meganexus_iptv_live_only')!='false'


def apply_lists(quiet=False):
    """Make the lists' files and point Kodi at them now (IPTV Simple reloads),
    behind the ring. Not while live TV plays."""
    from resources.lib import iptv_lists
    if xbmc.getCondVisibility('Pvr.IsPlayingTV'):
        if not quiet:xbmcgui.Dialog().notification('Live TV','Saved - the channel list changes when live TV stops.',time=3500)
        return False
    done=job(lambda:iptv_lists.sync(_folder(),_pvr_profile(),live_only(),rpc=rpc,log=_log,wait=xbmc.Monitor().waitForAbort),None,label='')
    with _CHANNEL_LOCK:_CHANNEL_CACHE.clear()
    if done is None and not quiet:   # the service is making the lists right now: it takes this change next
        xbmcgui.Dialog().notification('Live TV','The lists are being updated - your change follows in a minute or two.',time=4000)
    return True


def _list_state(row):
    return '%s · %s'%('Live TV on' if row.get('live') else 'Live TV off',
                      'IPTV VOD on' if row.get('vod') else 'IPTV VOD off')


def lists_page():
    """7.0.37: every IPTV list with its switches (Live TV, IPTV VOD, groups)."""
    from . import settings_page as page
    def build():
        rows=[(row['id'],page.item(row.get('name') or row['id'],_list_state(row))) for row in _lists()]
        return rows+[('xtream',page.item('Add an Xtream account')),('m3u',page.item('Add an M3U playlist + XMLTV TV guide'))]
    def act(key):
        if key in ('xtream','m3u'):setup(key);return None
        return list_page(key)
    return page.keyed('IPTV lists',build,act)


def list_page(list_id):
    from . import settings_page as page
    from resources.lib import iptv_lists
    def row():return iptv_lists.find(_folder(),list_id) or {}
    def build():
        current=row()
        if not current:return []
        hidden=len(current.get('hidden_groups') or [])
        archive=current.get('catchup') or [0,0]
        catchup=('%d channels · up to %d days'%(archive[0],archive[1]) if archive[1] else '%d channels'%archive[0]) if archive[0] else 'None found'
        return [('live',page.item('Live TV · its channels in the TV list',enabled=bool(current.get('live')))),
                ('vod',page.item('IPTV VOD films and series as a source',enabled=bool(current.get('vod')))),
                ('groups',page.item('Groups',('%d switched off'%hidden) if hidden else 'All on')),
                ('catchup',page.item('Catch-up',catchup)),   # 7.0.48: what the list was checked to have
                ('name',page.item('Name',current.get('name') or '')),
                ('remove',page.item('Remove this list'))]
    def act(key):
        current=row()
        if not current:return page.DONE
        if key in ('live','vod'):
            iptv_lists.update(_folder(),list_id,**{key:not current.get(key)})
            if key=='live':apply_lists()      # IPTV VOD's index is made by the service within minutes
        elif key=='groups':
            if pick_groups(list_id):apply_lists()
        elif key=='catchup':
            iptv_lists.update(_folder(),list_id,rules=0)   # 7.0.48: read and checked again now
            apply_lists()
        elif key=='name':
            name=xbmcgui.Dialog().input('Name of this list',current.get('name') or '').strip()
            if name:iptv_lists.update(_folder(),list_id,name=name[:40])
        elif key=='remove':
            if not xbmcgui.Dialog().yesno('IPTV','Remove "%s"? Its channels and IPTV VOD go.'%(current.get('name') or list_id)):return None
            # 7.0.48: its folder asked while it is on - Kodi no longer knows a switched-off
            # add-on ("Unknown addon id"), and the list stayed
            profile=_pvr_profile()
            rpc('Addons.SetAddonEnabled',{'addonid':'pvr.iptvsimple','enabled':False})
            try:iptv_lists.remove(_folder(),profile,list_id)
            finally:ensure_client_enabled(rpc)
            left=iptv_lists.load(_folder())
            if not left:ADDON.setSetting('meganexus_iptv_configured','false')
            ADDON.setSetting('meganexus_iptv_instance',str(left[0]['instance']) if left else '')
            with _CHANNEL_LOCK:_CHANNEL_CACHE.clear()
            return page.DONE
        return None
    return page.keyed('IPTV list',build,act)


def pick_groups(list_id=None):
    """7.0.37: switch channel groups on and off (countries...). Switched-off
    groups are left out of the list Kodi reads - not only hidden. Returns True
    when something changed."""
    from resources.lib import iptv_lists
    lists=[r for r in _lists() if r.get('live') and (list_id is None or r['id']==list_id)]
    choices=[]
    for row in lists:
        for name,count in sorted(iptv_lists.list_groups(_folder(),row).items(),key=lambda kv:kv[0].casefold()):
            choices.append((row,name,count))
    if not choices:
        xbmcgui.Dialog().ok('Groups','The groups show after the list was read once (a minute after setup or a restart).')
        return False
    several=len(lists)>1
    labels=['%s%s  ·  %d'%((row.get('name')+' · ') if several else '',name or 'No group',count) for row,name,count in choices]
    on=[i for i,(row,name,_) in enumerate(choices) if name not in (row.get('hidden_groups') or [])]
    picked=xbmcgui.Dialog().multiselect('Groups to load',labels,preselect=on)
    if picked is None:return False
    if not picked:
        xbmcgui.Dialog().ok('Groups','Keep at least one group on.');return False
    changed=False
    for row in lists:
        hidden=[name for i,(r,name,_) in enumerate(choices) if r['id']==row['id'] and i not in picked]
        if sorted(hidden)!=sorted(row.get('hidden_groups') or []):
            iptv_lists.set_hidden(_folder(),row['id'],hidden);changed=True
    return changed


def setup(kind):
    """'xtream' or 'm3u': ask the details and write MegaNexus' IPTV Simple instance."""
    dialog=xbmcgui.Dialog()
    if xbmc.getCondVisibility('Pvr.IsPlayingTV'):
        dialog.ok('IPTV','Stop live TV before changing the playlist.');return False
    choice=0 if kind=='xtream' else 1
    if choice==0:
        server=dialog.input('Xtream server URL including port').strip()
        if not server:return False
        username=dialog.input('Xtream username').strip()
        password=dialog.input('Xtream password',option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not username or not password:return False
        # 8.1.2: said nothing and did nothing when the address was not to its liking -
        # the M3U path below has always shown the reason, this one raised out of the
        # click handler instead
        try:m3u,epg=xtream_urls(server,username,password)
        except ValueError as exc:
            dialog.ok('IPTV',str(exc));return False
    else:
        m3u=dialog.input('M3U playlist URL').strip()
        if not m3u:return False
        epg=dialog.input('XMLTV EPG URL (optional if supplied in the playlist)').strip()
    if not ensure_addon('pvr.iptvsimple'):return False
    from resources.lib import iptv_lists
    from resources.lib.iptv_config import valid_url
    try:valid_url(m3u)
    except ValueError as exc:
        dialog.ok('IPTV',str(exc));return False
    name=dialog.input('Name of this list',iptv_lists.default_name(m3u)).strip() or iptv_lists.default_name(m3u)
    _lists()      # the list of an older setup first
    profile=_pvr_profile()
    rpc('Addons.SetAddonEnabled',{'addonid':'pvr.iptvsimple','enabled':False})
    try:
        if feature_on(TIMESHIFT):ensure_addon('inputstream.ffmpegdirect')
        # 7.0.37: another list next to the others (its own IPTV Simple instance);
        # Kodi gets its channels only (films and series stay out, IPTV VOD)
        row=iptv_lists.add(_folder(),profile,name,m3u,epg,feature_on(TIMESHIFT),feature_on(CATCHUP))
        ADDON.setSetting(FEATURES_APPLIED,'2')
        if not ADDON.getSetting('meganexus_iptv_instance'):ADDON.setSetting('meganexus_iptv_instance',str(row['instance']))
        ADDON.setSetting('meganexus_iptv_configured','true')
        job(lambda:iptv_lists.sync(_folder(),profile,live_only(),rpc=None,log=_log),None,label='')
    finally:ensure_client_enabled(rpc)
    with _CHANNEL_LOCK:_CHANNEL_CACHE.clear()
    return True

def channels(group='alltv',refresh=False):
    with _CHANNEL_LOCK:
        cached=_CHANNEL_CACHE.get(group)
        if not refresh and cached and time.monotonic()-cached[0]<60:return list(cached[1])
    # Kodi 21 'icon' is the channel logo; 'thumbnail' can be current EPG art.
    # Programme details/artwork are not requested
    # for every channel; the selected channel's guide loads after focus settles.
    rows=(rpc('PVR.GetChannels',{'channelgroupid':group,'properties':['icon','channelnumber','subchannelnumber','uniqueid','clientid','hasarchive']}) or {}).get('channels') or []
    # The unsorted response may follow database IDs rather than channel order.
    rows=sorted(rows,key=lambda r:(int(r.get('channelnumber') or 0),int(r.get('subchannelnumber') or 0)))
    if rows:
        with _CHANNEL_LOCK:
            _CHANNEL_CACHE[group]=(time.monotonic(),rows);_CHANNEL_CACHE.move_to_end(group)
            while len(_CHANNEL_CACHE)>8:_CHANNEL_CACHE.popitem(last=False)
    return list(rows)


def groups():
    rows=(rpc('PVR.GetChannelGroups',{'channeltype':'tv'}) or {}).get('channelgroups') or []
    # Kodi's own "All channels" group is the same list as ours: shown once.
    return [{'channelgroupid':'alltv','label':'All channels'}]+[r for r in rows if r.get('channelgroupid')!='alltv'
                                                                and str(r.get('label') or '').strip().casefold()!='all channels']


def epg_time(value):
    # PVR JSON-RPC serializes UTC without a suffix. Convert once to local time.
    try:
        date=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if date.tzinfo is None:date=date.replace(tzinfo=timezone.utc)
        return date.astimezone()
    except (ValueError,TypeError):return None


def programme_time(row):
    start,end=epg_time(row.get('starttime')),epg_time(row.get('endtime'))
    if not start or not end:return 'Time unavailable'
    return start.strftime('%d %b  %H:%M')+' - '+end.strftime('%H:%M')


def _on_now(row,now):
    start,end=epg_time(row.get('starttime')),epg_time(row.get('endtime'))
    return bool(row.get('isactive') or (start and end and start<=now<end))


def catchup_ready(row):
    """A finished programme Kodi can play from the archive (IPTV Simple catch-up)."""
    end=epg_time(row.get('endtime'))
    return bool(row.get('isplayable') and row.get('broadcastid') and not row.get('isactive') and end and end<datetime.now(timezone.utc))


def broadcasts(channel):
    rows=(rpc('PVR.GetBroadcasts',{'channelid':channel,'properties':['title','plot','starttime','endtime','isactive','isplayable']}) or {}).get('broadcasts') or []
    return sorted(rows,key=lambda r:r.get('starttime') or '')


def _playable(rows):
    """7.0.48: Kodi 21+ sends no isplayable with the guide any more (deprecated - catch-up
    showed nothing): asked per programme (PVR.GetBroadcastIsPlayable), the newest finished
    one first, until one is not - the archive's edge. A channel without one: one question."""
    if not rows or any('isplayable' in r for r in rows):return
    now=datetime.now(timezone.utc)
    for r in rows:r['isplayable']=False
    for r in reversed([r for r in rows if r.get('broadcastid') and (epg_time(r.get('endtime')) or now)<now]):
        try:playable=rpc('PVR.GetBroadcastIsPlayable',{'broadcastid':r['broadcastid']}) is True
        except RuntimeError:playable=False
        if not playable:break
        r['isplayable']=True

def archive(channel,hours=ARCHIVE_HOURS):
    """7.0.32: the channel's past programmes Kodi can play from the archive, newest first."""
    since=datetime.now(timezone.utc).timestamp()-hours*3600
    rows=broadcasts(channel);_playable(rows)
    rows=[r for r in rows if catchup_ready(r) and (epg_time(r.get('starttime')) or datetime.now(timezone.utc)).timestamp()>=since]
    return rows[::-1]


def pvr_ready():
    """Kodi's PVR has started (its clients loaded the channels and the guide)."""
    try:return bool((rpc('PVR.GetProperties',{'properties':['available']}) or {}).get('available'))
    except Exception:return False


def channel_key(row):return '%s:%s'%(row.get('clientid',''),row.get('uniqueid',row['channelid']))

def current_id():
    try:
        for p in rpc('Player.GetActivePlayers') or []:
            if p['type']=='video':return (rpc('Player.GetItem',{'playerid':p['playerid']}) or {}).get('item',{}).get('id')
    except Exception:pass
    return None


def _play_file(url,title,windowed=False):
    """A programme from the archive as a file in Kodi's player (the film's controls: it seeks)."""
    item=listitems.item(label=title)
    item.setProperty('IsPlayable','true')
    xbmc.Player().play(url,item,windowed)


AUTOSTART_WAIT=10   # 7.0.50: seconds the last channel waits for the screensaver to let go (was 5)


def _free_for_channel():
    """Nothing of the user's plays (the video wallpaper may: the channel takes its place).
    7.0.50: and the screensaver's poster work has stopped - a channel opened while it was
    being stopped froze the picture on the Cube (the Amlogic decoder, sound only)."""
    if xbmcgui.Window(10000).getProperty('meganexus.saver.storing'):return False
    if not xbmc.getCondVisibility('Player.HasMedia'):return True
    try:
        from resources.lib.wallpaper_video import is_background
        return is_background(xbmc.Player())
    except Exception:return False


def open_preview(channel_id):
    """Kodi Player.Open(channelid) obeys the PVR fullscreen preference.

    JSON-RPC has no windowed option for a channel. Temporarily override the
    documented native preference while its synchronous PlayMedia call decides
    the playback mode, then restore it even on errors. Never change app-window
    fullscreen, video zoom, resolution, or the user's saved channel setup.
    """
    from resources.lib.wallpaper_video import suspend
    suspend()
    if _WINDOWED[0] is not None:return rpc('Player.Open',{'item':item_for(channel_id)})   # 7.0.32: set once for the screen
    setting='pvrplayback.switchtofullscreenchanneltypes'
    previous=(rpc('Settings.GetSettingValue',{'setting':setting}) or {}).get('value')
    if type(previous) is not int or previous not in (0,1,2,3):
        raise ValueError('Kodi could not enable the IPTV preview. Check PVR playback settings.')
    changed=previous!=0
    if changed and rpc('Settings.SetSettingValue',{'setting':setting,'value':0}) is not True:
        raise ValueError('Kodi did not allow windowed IPTV playback.')
    try:
        return rpc('Player.Open',{'item':item_for(channel_id)})
    finally:
        if changed:
            # Do not overwrite a preference the user changed in another window.
            current=(rpc('Settings.GetSettingValue',{'setting':setting}) or {}).get('value')
            if current==0:rpc('Settings.SetSettingValue',{'setting':setting,'value':previous})

def item_for(target):
    """A channel id, or ('broadcast', id) for a programme from the archive."""
    if isinstance(target,tuple):return {'broadcastid':target[1]}
    return {'channelid':target}


_WINDOWED=[None]
FULLSCREEN_SETTING='pvrplayback.switchtofullscreenchanneltypes'


def keep_windowed():
    """7.0.32: Kodi's "switch to full screen" for channels is off while the IPTV
    screen is open - once, not around every channel start (two settings writes
    each time) - and given back afterwards (release_windowed)."""
    previous=(rpc('Settings.GetSettingValue',{'setting':FULLSCREEN_SETTING}) or {}).get('value')
    if type(previous) is not int or previous not in (0,1,2,3):return False
    if previous!=0 and rpc('Settings.SetSettingValue',{'setting':FULLSCREEN_SETTING,'value':0}) is not True:return False
    _WINDOWED[0]=previous
    return True


def release_windowed():
    previous,_WINDOWED[0]=_WINDOWED[0],None
    if previous is None or previous==0:return
    try:
        if (rpc('Settings.GetSettingValue',{'setting':FULLSCREEN_SETTING}) or {}).get('value')==0:
            rpc('Settings.SetSettingValue',{'setting':FULLSCREEN_SETTING,'value':previous})
    except Exception:pass


PICKER_SECONDS=15.0      # the picker over Kodi's player goes this long after the last key
PICKER_BACK=(9,10,92,216,247,257,275,61448,61467)
PICKER_UP,PICKER_DOWN=(3,),(4,)


class PlayerPicker(xbmcgui.WindowXMLDialog):
    """7.0.48: over Kodi's player while Live TV from our IPTV plays: the channels as logos
    (Up / Down the category) or the catch-up in a box; the choice plays on in the player.
    A window of its own: it gets every key (the IPTV screen is closed meanwhile)."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args)
        self.mode=kwargs['mode'];self.rows=list(kwargs.get('rows') or [])
        self.groups=kwargs.get('groups') or [];self.group=kwargs.get('group')
        self.title=kwargs.get('title') or '';self.channel=kwargs.get('channel') or ''
        self.selected=kwargs.get('selected');self.load=kwargs.get('load')
        self.chosen=None;self._timer=None

    def onInit(self):
        self.setProperty('meganexus.picker.mode',self.mode)
        self.setProperty('meganexus.picker.channel',self.channel)
        self._fill()
        self._touch()

    def _fill(self):
        if self.mode=='strip':
            items=[]
            for r in self.rows:
                li=listitems.item(label=plain_label(r.get('label')));li.setArt({'icon':r.get('icon') or ''});items.append(li)
            control=self.getControl(STRIP);control.reset();control.addItems(items)
            control.selectItem(next((i for i,r in enumerate(self.rows) if r['channelid']==self.selected),0))
            self.setProperty('meganexus.picker.title',self.title)
            self.setFocusId(STRIP)
        else:
            items=[listitems.item(label=programme_time(r),label2=plain_label(r.get('title') or 'Programme')) for r in self.rows]
            control=self.getControl(ARCHIVE_LIST);control.reset();control.addItems(items)
            self.setProperty('meganexus.picker.status','' if items else 'Nothing in the archive of this channel.')
            if items:self.setFocusId(ARCHIVE_LIST)

    def _touch(self):
        if self._timer:self._timer.cancel()
        self._timer=threading.Timer(PICKER_SECONDS,self.close);self._timer.daemon=True;self._timer.start()

    def onAction(self,action):
        aid=action.getId()
        self._touch()
        if aid in PICKER_BACK:
            self.close();return
        if self.mode=='strip' and self.groups and (aid in PICKER_UP or aid in PICKER_DOWN) and self.load:
            index=next((i for i,g in enumerate(self.groups) if g['channelgroupid']==self.group),0)
            group=self.groups[(index+(-1 if aid in PICKER_UP else 1))%len(self.groups)]
            try:rows=self.load(group['channelgroupid'])
            except Exception:rows=[]
            if rows:
                self.group,self.rows,self.title=group['channelgroupid'],rows,plain_label(group['label'])
                self._fill()

    def onClick(self,cid):
        control=self.getControl(cid)
        pos=control.getSelectedPosition()
        if 0<=pos<len(self.rows):self.chosen=self.rows[pos]
        self.close()

    def close(self):
        if self._timer:self._timer.cancel()
        super().close()


class IPTV(TopRow, Dialog):
    TOP_ROW=(GROUPS_BUTTON,502,503,508,506)   # 8.1.3: the row that keeps out of the way, as on Home
    def __init__(self,*args,**kwargs):
        super().__init__(*args)
        self.rows=kwargs['rows'];self.group=kwargs.get('group','alltv')
        self.groups=kwargs.get('groups') or [{'channelgroupid':'alltv','label':'All channels'}]
        self.playing=current_id();self.fullscreen=False;self.closed=False
        self._pool=ThreadPoolExecutor(max_workers=2);self._jobs={};self._updates=queue.Queue()
        self._cache=OrderedDict();self._generation=0;self._selection=None;self._selected_at=0
        self._epg_channel=None;self._epg=[];self._epg_refresh=0;self._ready=False
        self._requested_group=self.group;self._pending_group=None
        self._initialized=False;self._selected=0;self._back_block_until=0
        self._play_requested=None
        self._started=None
        self._recent=[];self._autostart=None   # 7.0.48: Last channels; the last channel starts by itself
        self._autostart_until=0.;self._archive_from=False   # ... (a while); a programme from the archive plays
    def onInit(self):
        from .trailers import lift_curtain
        lift_curtain()   # 7.0.48: after a programme from the archive, the curtain fades to this page
        if self._initialized:
            self.getControl(501).reset()
            self.getControl(501).addItems([listitems.item(label=plain_label(g['label'])) for g in self.groups])
            selected=next((i for i,g in enumerate(self.groups) if g['channelgroupid']==self.group),0)
            self.getControl(501).selectItem(selected)
            self.setProperty('meganexus.group',plain_label(self.groups[selected]['label']))
            current=next((r for r in self.rows if r['channelid']==self.playing),None)
            self.setProperty('meganexus.playing',plain_label(current.get('label')) if current else '')
            self._paint()
            if self.rows:self.getControl(500).selectItem(min(self._selected,len(self.rows)-1))
            if self._epg:self._paint_epg(self._epg)
            self._ready=True;self.restore_focus()
            return
        self._initialized=True
        self.getControl(501).reset()
        self.getControl(501).addItems([listitems.item(label=plain_label(g['label'])) for g in self.groups])
        selected=next((i for i,g in enumerate(self.groups) if g['channelgroupid']==self.group),0)
        self.getControl(501).selectItem(selected)
        self.setProperty('meganexus.group',plain_label(self.groups[selected]['label']));self._paint()
        self._ready=True;self.focus(500)
        last=ADDON.getSetting('meganexus_iptv_last_unique')
        row=next((r for r in self.rows if channel_key(r)==last),None)
        if row:
            self.getControl(500).selectItem(self.rows.index(row))
            # Restore selection only. A stream open in Kodi's GUI callback can
            # block rendering for 90 seconds on an offline playlist.
            if self.playing==row['channelid']:self.setProperty('meganexus.playing',plain_label(row.get('label')))
            elif _free_for_channel():self._start_channel(row)   # 7.0.48: the last channel starts by itself (from tick)
            else:self.setProperty('meganexus.iptv.status','Select a channel to start the preview.')
        self._select_channel()
    def _paint(self):
        items=[]
        for number,r in enumerate(self.rows,1):
            now=r.get('broadcastnow') or {}
            # A group has a contiguous 1..N list; provider numbers remain in the
            # PVR database and the stable playback ID is never renumbered.
            li=listitems.item(label='%d  %s'%(number,plain_label(r.get('label'))),label2=plain_label(now.get('title') or ''))
            li.setArt({'icon':r.get('icon') or '', 'thumb':'', 'fanart':''})
            li.setProperty('archive','1' if r.get('hasarchive') else '')   # 7.0.48: the catch-up mark
            items.append(li)
        self.getControl(500).reset();self.getControl(500).addItems(items)
        self.setProperty('meganexus.iptv.status','' if items else 'No channels in this category.')

    def _submit(self,kind,key,call):
        previous=self._jobs.get(kind)
        if previous and not previous.done():return False
        generation=self._generation
        def load():
            try:result=call()
            except Exception:result=None
            if not self.closed:self._updates.put((kind,generation,key,result))
        self._jobs[kind]=self._pool.submit(load)
        return True

    def _request_group(self,key,refresh=False):
        self._play_requested=None
        self._requested_group=key
        self._pending_group=(key,refresh)
        self.setProperty('meganexus.iptv.status','')   # 7.0.42: no loading words

    def _load_pending_group(self):
        if self._pending_group:
            key,refresh=self._pending_group
            if self._submit('group',key,lambda:channels(key,refresh=refresh)):
                self._pending_group=None

    def _select_channel(self):
        pos=self.getControl(500).getSelectedPosition()
        if not 0<=pos<len(self.rows):return
        row=self.rows[pos];cid=row['channelid']
        if cid!=self._selection:
            self._selection=cid;self._selected_at=time.monotonic();self._epg_channel=None
            self.setProperty('meganexus.epg.channel',plain_label(row.get('label')))
            # Immediate now/next, then the full guide after the focus settles.
            self._paint_epg([r for r in (row.get('broadcastnow'),row.get('broadcastnext')) if r])

    def _paint_epg(self,rows):
        # 7.0.48: what is on now first (▶ - OK plays the channel), then what comes; the
        # archive plays from Kodi's player (its Catch-up button), not from here
        now=datetime.now(timezone.utc)
        rows=[r for r in rows if (epg_time(r.get('endtime')) or now)>now]
        self._epg=rows
        items=[]
        for row in rows:
            title=plain_label(row.get('title') or row.get('label') or 'Programme')
            live=_on_now(row,now)
            li=listitems.item(label=programme_time(row),label2=('\u25b6  '+title) if live else title)
            li.setProperty('live','1' if live else '')
            items.append(li)
        self.getControl(504).reset();self.getControl(504).addItems(items)
        if items:self.getControl(504).selectItem(0)
        self.setProperty('meganexus.epg.empty','' if items else 'No EPG available for this channel.')

    def onFocus(self,cid):
        self.row_focus(cid)
    def tick(self):
        self.drain_events()
        self.row_tick()
        if self.closed or not self._ready:return
        self._load_pending_group()
        self._select_channel()
        if self._autostart:
            # the last channel in the small player, as a click on it - never inside onInit
            # (a stream opened there could hold the screen on an offline playlist); after a
            # programme from the archive once Kodi has stopped it
            if _free_for_channel():
                row,self._autostart=self._autostart,None
                self._request_play(row)
            elif time.monotonic()>self._autostart_until:self._autostart=None
        now=time.monotonic()
        if self.getProperty('meganexus.iptv.hint')!=HINT:self.setProperty('meganexus.iptv.hint',HINT)
        if self._started:
            cid,began,opened,before=self._started
            # The new channel (another file than before the click) and its picture moving.
            path=xbmc.getInfoLabel('Player.FilenameAndPath')
            if now-began>30:self._started=None
            elif path and path!=before and xbmc.getCondVisibility('Player.HasVideo + Player.Playing + !Player.Caching'):
                try:moving=xbmc.Player().getTime()>=.2
                except Exception:moving=False
                if moving:
                    self._started=None
                    # 7.0.44: the small picture fills its corner like Home's trailers
                    from .home_trailers import fill_corner
                    fill_corner()
                    xbmc.log('[MegaNexus][perf] IPTV channel start: picture after %d ms (Kodi took the channel in %d ms) channel=%s'
                             %((now-began)*1000,(opened-began)*1000,cid),xbmc.LOGINFO)
        if self._selection is not None and now-self._selected_at>=.3 and (self._epg_channel!=self._selection or now>=self._epg_refresh):
            cid=self._selection;cached=self._cache.get(cid)
            if cached and now-cached[0]<60:
                self._paint_epg(cached[1]);self._epg_channel=cid;self._epg_refresh=cached[0]+60
            elif self._submit('epg',cid,lambda:broadcasts(cid)):
                self._epg_channel=cid;self._epg_refresh=now+60
        for _ in range(8):
            try:kind,generation,key,result=self._updates.get_nowait()
            except queue.Empty:break
            if generation!=self._generation:continue
            if kind=='group':
                if key!=self._requested_group:continue
                if result is not None:
                    self.group=key;self.rows=result;self._selection=None;self._paint()
                    self.setProperty('meganexus.group',plain_label(next(g['label'] for g in self.groups if g['channelgroupid']==key)))
                    ADDON.setSetting('meganexus_iptv_last_group',str(key))
                    self.setFocusId(500)
                else:self.setProperty('meganexus.iptv.status','Could not load this category. Select it to retry.')
            elif kind=='epg':
                if result is not None:
                    self._cache[key]=(now,result);self._cache.move_to_end(key)
                    while len(self._cache)>24:self._cache.popitem(last=False)
                if key==self._selection:
                    if result:self._paint_epg(result)
                    elif not self._epg:self.setProperty('meganexus.epg.empty','EPG is not available yet. Check the XMLTV source in IPTV setup.')
            elif kind=='play' and key==self._play_requested:
                if result:
                    row=next((r for r in self.rows if r['channelid']==key),None)
                    if row:self._play(row)
                else:self.setProperty('meganexus.iptv.status','This channel is not responding. Try another channel.')

    def _request_play(self,row):
        # 7.0.29: on the click, as before. The stream check guarded against an offline
        # channel freezing Kodi through timeshift (inputstream.ffmpegdirect); timeshift
        # is opt-in now, and the check (the whole playlist downloaded) cost seconds.
        if not feature_on(TIMESHIFT):
            self._play_requested=None
            self._play(row);return
        from resources.lib import iptv_probe
        profile=_pvr_profile()   # 8.1.2: raised here while the add-on was disabled, in a click handler
        key=row['channelid'];self._play_requested=key
        self.setProperty('meganexus.iptv.status','Checking channel...')
        def check():
            clients=(rpc('PVR.GetClients') or {}).get('clients') or []
            client=next((c for c in clients if c.get('clientid')==row.get('clientid')),None)
            if client and client.get('addonid')!='pvr.iptvsimple':return True
            return iptv_probe.verify(row,profile,lambda:self.closed or self._play_requested!=key,
                                     client.get('instanceid') if client else None)
        if not self._submit('play',key,check):
            self.setProperty('meganexus.iptv.status','Checking the previous channel. Select this channel again in a moment.')

    def _play(self,row):
        # Opening a channel via JSON-RPC uses Kodi PVR's EPG, buffering and tuner.
        began=time.monotonic();before=xbmc.getInfoLabel('Player.FilenameAndPath')
        try:open_preview(row['channelid'])
        except (RuntimeError,ValueError):
            self.setProperty('meganexus.iptv.status','This channel could not start in preview. Check the playlist or try another channel.')
            return
        if self.playing and self.playing!=row['channelid']:   # 7.0.48: Last channels, newest first
            self._recent=[self.playing]+[c for c in self._recent if c not in (self.playing,row['channelid'])][:RECENT-1]
        self.playing=row['channelid'];self._archive_from=False   # live again
        self._started=(row['channelid'],began,time.monotonic(),before)   # 7.0.32: logged once the picture moves
        ADDON.setSetting('meganexus_iptv_last_unique',channel_key(row))
        self.setProperty('meganexus.playing',plain_label(row.get('label')))
        # Keep this modal visible: playback is rendered by its videowindow.
    def onClick(self,cid):
        if cid==500 and self.rows:
            row=self.rows[self.getControl(500).getSelectedPosition()]
            if self.playing==row['channelid'] and current_id()==row['channelid']:
                self._selected=self.getControl(500).getSelectedPosition()
                self.child(self._fullscreen)    # 7.0.48: the channel that plays: Kodi's player
                self._back_block_until=time.monotonic()+.3
            else:self._request_play(row)
        elif cid==506:
            if xbmc.getCondVisibility('Pvr.IsPlayingTV'):xbmc.Player().stop()
            self.finish()
        elif cid==501:
            pick=self.getControl(501).getSelectedPosition()
            if not 0<=pick<len(self.groups):return
            key=self.groups[pick]['channelgroupid']
            self._request_group(key)
        elif cid==502:
            self._cache.clear();self._epg_channel=None
            self._request_group(self.group,refresh=True)
        elif cid==GROUPS_BUTTON:
            self.over(self._groups)   # 8.1.3: over IPTV, as Settings - child() hid IPTV and the HUB showed under it
        elif cid==508:
            from .settings import run   # 8.1.3: HUB Settings from the top row, as on Home and Sport
            self.over(run)
        elif cid==503:
            if configure():
                with _CHANNEL_LOCK:_CHANNEL_CACHE.clear()
                self._request_group(self.group,refresh=True)
        elif cid==504 and self._epg:
            pos=self.getControl(504).getSelectedPosition()
            if 0<=pos<len(self._epg):
                row=self._epg[pos]
                # 7.0.48: the archive opens in Kodi's player only (its Catch-up button) - from
                # this guide it played behind the page and Kodi went to the HUB. What is on
                # now: its channel, as OK on the channel
                cid=getattr(self,'_epg_channel',None) or getattr(self,'_selection',None)   # the guide's channel
                channel=next((r for r in getattr(self,'rows',[]) if r['channelid']==cid),None)
                if channel and _on_now(row,datetime.now(timezone.utc)):
                    if self.playing==channel['channelid'] and current_id()==channel['channelid']:
                        self.child(self._fullscreen);self._back_block_until=time.monotonic()+.3
                    else:self._request_play(channel)
                    return
                xbmcgui.Dialog().textviewer(plain_label(row.get('title') or 'Programme'),programme_time(row)+'\n\n'+plain_label(row.get('plot') or 'No description available.'))
    def _fullscreen(self):
        """The SAME IPTV page survives native fullscreen, Stop and stream EOF.
        7.0.48: the player's IPTV buttons (review/make_iptv_osd.py) ask through
        Window(Home) meganexus.iptv.osd: Previous / Next channel and From start here,
        Channels / Last channels / Catch-up in a picker over the player. A programme
        from the archive is stopped when the player is left (left playing, it drew over
        the whole screen behind this page), behind the film's curtain."""
        self.fullscreen=True
        monitor=xbmc.Monitor();home=xbmcgui.Window(10000)
        home.clearProperty(OSD_COMMAND)
        home.setProperty('meganexus.iptv.open','1')
        # 7.0.48: Kodi's player first - this page was just closed, and the questions below
        # (the guide) took long enough to show the screen under it (the HUB)
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        try:
            from .home_trailers import view_mode
            view_mode('normal')   # 7.0.44: the whole picture in Kodi's own player
            self._osd_state()
            seen=False;start=time.monotonic();switching=0.;osd=None;before=''
            while not monitor.waitForAbort(.05):
                osd=player_buttons(osd)
                command=home.getProperty(OSD_COMMAND)
                if command:
                    home.clearProperty(OSD_COMMAND)
                    before=xbmc.getInfoLabel('Player.FilenameAndPath')
                    if command in ('previous','next','restart'):
                        if self._osd_here(command):switching=time.monotonic()+SWITCH_GRACE
                    elif command in ('channels','last','catchup'):
                        # over Kodi's player: the channels as logos / the catch-up box; it plays on there
                        if self._player_picker(command):switching=time.monotonic()+SWITCH_GRACE
                full=xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                if time.monotonic()<switching and switched(before):switching=0.
                if time.monotonic()<switching:
                    # a channel switch: the picture stops for a moment and Kodi may drop full screen
                    if not full and xbmc.Player().isPlayingVideo():xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                    continue
                if full:seen=True
                if seen and not full:break
                if not xbmc.Player().isPlayingVideo():break
                if not seen and time.monotonic()-start>5:break
        finally:
            self.fullscreen=False
            home.clearProperty('meganexus.iptv.open');home.clearProperty(OSD_COMMAND)
            if self._archive_from and xbmc.Player().isPlaying():
                # the programme from the archive stops before this page comes back - as a
                # film: our curtain over the change at once, lifted once this page is drawn
                # (onInit), so the screen under the player does not show between
                from .trailers import _darken_for_stop
                _darken_for_stop()
                xbmc.Player().stop()
                until=time.monotonic()+3
                while xbmc.Player().isPlaying() and time.monotonic()<until and not monitor.waitForAbort(.05):pass
            # Stop/EOF must return to the guide without auto-restarting a channel.
            if not xbmc.Player().isPlayingVideo():
                self.playing=None
                self.setProperty('meganexus.playing','')
            self._archive_from=False
            # 7.0.48: Back from Kodi's player comes down to the small video, the cursor on the
            # channel that plays (restore_focus) or on the programme of the guide it came from

    def _archive_file(self,cid,programme):
        """7.0.48: the programme as a file from its Xtream server, or '' (other lists: Kodi's PVR).
        A file plays in Kodi's player like a film - it seeks; through IPTV Simple it did not
        (the add-on lets Kodi seek only through inputstream.ffmpegdirect, which lost the time
        and the sound on such streams). The programme on air: up to now."""
        from resources.lib import iptv_lists,iptv_catchup
        row=next((r for r in self.rows if r['channelid']==cid),None) if cid else None
        start,end=epg_time(programme.get('starttime')),epg_time(programme.get('endtime'))
        if not row or not start or not end:return ''
        try:index=iptv_lists.catchup_index(_folder())
        except Exception:return ''
        name=plain_label(row.get('label') or '')
        end=min(end,datetime.now(timezone.utc))
        return iptv_catchup.programme_url(index.get(iptv_catchup.channel_key(name)),name,start.timestamp(),end.timestamp())

    def _to_archive(self):
        """A programme from the archive takes the player: the live channel is remembered."""
        if not self._archive_from:self._archive_from=self.playing or True
        self.playing=None

    def _start_channel(self,row):
        """The channel in the small video from tick, once nothing else plays (a few seconds)."""
        self._autostart=row;self._autostart_until=time.monotonic()+AUTOSTART_WAIT

    def _player_picker(self,command):
        """Channels / Last channels / Catch-up over Kodi's player; True once something new plays."""
        group=next((g for g in self.groups if g['channelgroupid']==self.group),{'label':'Channels'})
        if command=='catchup':
            try:rows=archive(self.playing) if self.playing else []
            except Exception:rows=[]
            kwargs=dict(mode='box',rows=rows,channel=plain_label((self._playing_row() or {}).get('label') or ''))
        elif command=='last':
            known={r['channelid']:r for r in self.rows}
            recent=[known[c] for c in self._recent if c in known and c!=self.playing]
            if not recent:return False
            kwargs=dict(mode='strip',rows=recent,selected=recent[0]['channelid'],title='Last channels')
        else:
            kwargs=dict(mode='strip',rows=self.rows,selected=self.playing,title=plain_label(group.get('label')),
                        groups=self.groups,group=self.group,load=lambda key:channels(key))
        picker=PlayerPicker('meganexus_iptv_picker.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',**kwargs)
        try:
            picker.doModal()
            chosen=picker.chosen
            if picker.mode=='strip' and getattr(picker,'group',None) not in (None,self.group) and chosen:
                self.group=picker.group;self.rows=picker.rows   # the category it was chosen in
        finally:
            del picker
        if not chosen:return False
        if command=='catchup':
            url=self._archive_file(self.playing,chosen)
            self._to_archive()
            if url:
                _play_file(url,plain_label(chosen.get('title') or 'Programme'));return True
            return rpc('Player.Open',{'item':item_for(('broadcast',chosen['broadcastid']))})=='OK'
        if chosen['channelid']==self.playing:return False
        self._play(chosen);self._osd_state()
        return True

    def restore_focus(self):
        focus,self._restore_focus=self._restore_focus,None
        if focus in (None,500):
            # 7.0.48: back from Kodi's player: on the channel that plays (another one may
            # have been chosen there)
            index=next((i for i,r in enumerate(self.rows) if r['channelid']==self.playing),None)
            if index is not None:
                try:self.getControl(500).selectItem(index)
                except RuntimeError:pass
            self.setFocusId(500);return
        if focus is not None:
            try:self.setFocusId(focus)
            except Exception:pass

    def _osd_state(self):
        """What the player's IPTV buttons can do for the channel that plays."""
        home=xbmcgui.Window(10000);row=self._playing_row() or {}
        if self.playing and self.playing not in self._cache:
            try:self._cache[self.playing]=(time.monotonic(),broadcasts(self.playing))
            except Exception:pass
        now=self._now_programme()
        home.setProperty('meganexus.iptv.has_recent','1' if any(c!=self.playing for c in self._recent) else '')
        home.setProperty('meganexus.iptv.has_archive','1' if row.get('hasarchive') else '')
        home.setProperty('meganexus.iptv.has_restart','1' if row.get('hasarchive') and now and now.get('broadcastid') else '')

    def _osd_here(self,command):
        """Previous / Next channel or From start inside Kodi's player."""
        if command=='restart':
            now=self._now_programme()
            if not now:return False
            url=self._archive_file(self.playing,now)
            self._to_archive()
            if url:
                _play_file(url,plain_label(now.get('title') or 'Programme'));return True
            return rpc('Player.Open',{'item':item_for(('broadcast',now['broadcastid']))})=='OK'
        if not self.rows:return False
        index=next((i for i,r in enumerate(self.rows) if r['channelid']==self.playing),-1)
        row=self.rows[(index+(-1 if command=='previous' else 1))%len(self.rows)]
        self._play(row)
        self._osd_state()
        return True

    def onAction(self,action):
        aid=action.getId()
        self.row_focus(key=True)
        if aid in INFO:
            # Info: Kodi's own full-screen player for the channel that plays.
            if xbmc.getCondVisibility('Player.HasVideo'):
                self.child(self._fullscreen)
                self._back_block_until=time.monotonic()+.3
            return
        if aid not in BACK+STOP:return
        if time.monotonic()<self._back_block_until:return
        if aid in STOP:
            self._play_requested=None
            if xbmc.getCondVisibility('Pvr.IsPlayingTV | Player.HasVideo'):xbmc.Player().stop()
            self.playing=None;self._started=None
            self.setProperty('meganexus.playing','')
            self.setProperty('meganexus.iptv.status','Stopped. Select a channel to play.')
            self.setFocusId(500)
            return
        # 7.0.32: Back never stops the channel (as in Sport): the HUB button.
        # HUB is deliberate, not a side effect of Escape.
        self.setFocusId(506)

    # ---- the channel that plays (the player's IPTV buttons, 7.0.48) ----------
    def _playing_row(self):
        return next((r for r in self.rows if r['channelid']==self.playing),None) if self.playing else None

    def _guide(self,cid):
        cached=self._cache.get(cid)
        return cached[1] if cached else (self._epg if self._epg_channel==cid else [])

    def _now_programme(self):
        """The programme on air on the channel that plays, from its guide already loaded
        (nothing is asked for here)."""
        now=datetime.now(timezone.utc)
        for row in self._guide(self.playing) or []:
            start,end=epg_time(row.get('starttime')),epg_time(row.get('endtime'))
            if start and end and start<=now<end:return row
        return None

    def _groups(self):
        """7.0.37: switch channel groups on / off; Kodi then reads the list again
        (only the groups switched on) and this screen shows the new groups."""
        if not pick_groups():return
        if not apply_lists():return
        def wait_pvr():
            monitor=xbmc.Monitor()
            for _ in range(240):
                if pvr_ready() and channels(refresh=True) or monitor.waitForAbort(.25):return True
            return False
        job(wait_pvr,None,label='')
        try:self.groups=groups()
        except RuntimeError:return
        if not any(g['channelgroupid']==self.group for g in self.groups):self.group='alltv'
        self.getControl(501).reset()
        self.getControl(501).addItems([listitems.item(label=plain_label(g['label'])) for g in self.groups])
        selected=next((i for i,g in enumerate(self.groups) if g['channelgroupid']==self.group),0)
        self.getControl(501).selectItem(selected)
        self.setProperty('meganexus.group',plain_label(self.groups[selected]['label']))
        self._cache.clear();self._epg_channel=None
        self._request_group(self.group,refresh=True)

    def finish(self):
        if self.closed:return
        self.closed=True;self._generation+=1
        for future in self._jobs.values():future.cancel()
        self._pool.shutdown(wait=False);self.close()

ENTRY_WAIT=120            # seconds the entry waits (our ring, Back skips) for the channels of a list there is


def _entry_rows(refresh=False):
    """(groups, group, channels) of the last group, or None while there are no channels."""
    try:category_rows=groups()
    except RuntimeError:category_rows=[{'channelgroupid':'alltv','label':'All channels'}]
    saved=ADDON.getSetting('meganexus_iptv_last_group')
    group=next((g['channelgroupid'] for g in category_rows if str(g['channelgroupid'])==saved),'alltv')
    try:rows=channels(group,refresh=refresh)
    except RuntimeError:rows=[]
    if not rows and group!='alltv':
        group='alltv'
        try:rows=channels(refresh=refresh)
        except RuntimeError:rows=[]
    return (category_rows,group,rows) if rows else None


def _entry_channels():
    """(groups, group, channels) of the last group; None when there are none.
    7.0.48: with a list set up, the entry only waits behind our ring while Kodi
    loads its channels (just after Kodi starts, or while IPTV Simple reads the list
    again) - the setup page came instead, and the waiting was cut short. The setup
    page only when nothing is set up yet."""
    loaded=_entry_rows()
    if loaded:return loaded
    if not (configured() or _lists()):
        if not configure():return None
    cancelled=threading.Event();waited=[False]
    def wait_channels():
        monitor=xbmc.Monitor();until=time.monotonic()+ENTRY_WAIT
        while not cancelled.is_set():
            # 8.1.2: the deadline is read BEFORE each round as well as after. It used to
            # be checked only between rounds, and a round is one PVR question: against a
            # client that is not running those questions hang, so ENTRY_WAIT of 120 s
            # became a measured 479 s ("IPTV channels: 479346 ms") - eight minutes of a
            # spinning ring. Checking first means the wait can overrun by one question
            # instead of by four times over.
            if time.monotonic()>=until:
                waited[0]=True;break      # the whole time: no channels came
            found=_entry_rows(refresh=True)
            if found:return found
            if time.monotonic()>=until:
                waited[0]=True;break
            if monitor.waitForAbort(.5):break
        return None
    from .play_jobs import ring_job
    try:loaded=ring_job(wait_channels)
    finally:cancelled.set()
    if loaded:return loaded
    if not waited[0]:return None          # Back
    xbmcgui.Dialog().ok('IPTV','No channels are available yet. Check the playlist in IPTV Simple settings, or restart Kodi after installing the PVR client.')
    return None


def open_iptv():
    from . import perf
    if not pvr_ready():
        # 8.1.2: IPTV Simple is switched off while a playlist is written and on again
        # after; an interrupted save left it off, and then this waited the full minute
        # for a PVR that was never going to start - the screen that only spins. Switch
        # it on first, so the wait below is for channels loading, not for nothing.
        try:
            from resources.lib import iptv_config
            if configured() and not xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
                # 8.1.2: a list of ours, but the PVR client is not on the box at all - a
                # restored backup, or a CoreELEC image that lost it. Nothing would ever
                # make the PVR ready, so this used to sit through the whole wait showing
                # a spinner. Kodi's own installer picks the right build for the box.
                _log('[MegaNexus] Live TV is set up but IPTV Simple is missing; installing it')
                if not ensure_addon('pvr.iptvsimple'):
                    xbmcgui.Dialog().ok('IPTV', 'Live TV needs the IPTV Simple Client, and it is '
                                                'not installed on this device.[CR][CR]Your playlist and '
                                                'settings are kept - open IPTV again once it is installed.')
                    return
            if configured() and not xbmc.getCondVisibility('System.AddonIsEnabled(pvr.iptvsimple)'):
                _log('[MegaNexus] IPTV Simple was switched off; switching it on')
                iptv_config.ensure_client_enabled(rpc)
        except Exception:
            _log('[MegaNexus] IPTV Simple could not be switched on from the IPTV screen.')
    if not pvr_ready():
        # 7.0.32: IPTV Simple still loading the channels and the guide (after Kodi
        # starts). Kodi keeps them through a suspend - nothing reloads them here.
        def wait_pvr():
            monitor=xbmc.Monitor()
            for _ in range(240):
                if pvr_ready() or monitor.waitForAbort(.25):return True
            return False
        from .play_jobs import ring_job
        ring_job(wait_pvr)   # 7.0.42: our ring over the HUB, no loading page
    if configured() and ADDON.getSetting(FEATURES_APPLIED)!='2':
        try:apply_iptv_features(quiet=True)    # 7.0.29: timeshift / catch-up for an existing setup, once
        except Exception:xbmc.log('[MegaNexus] IPTV timeshift / catch-up not applied.',xbmc.LOGWARNING)
    try:
        with perf.timed('IPTV channels'):
            loaded=_entry_channels()
        if loaded is None:return
        category_rows,group,rows=loaded
        if group=='alltv':category_rows=groups()
        win=IPTV('meganexus_iptv.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',rows=rows,groups=category_rows,group=group)
        monitor=xbmc.Monitor()
        windowed=keep_windowed()
        from resources.lib.refresh_guard import hold
        # 7.0.50: no refresh-rate switching in IPTV (small video and full screen alike)
        with hold('iptv'):
            try:
                # 8.1.2: IPTV drives itself rather than through doModal, so the two things
                # doModal does around its loop were missing here: the mark that stops
                # anything reloading the skin under an open window, and the release that
                # lets Kodi free it (six windows were still held at script exit).
                screen_guard.hold()
                win.show_ready()
                while not win.closed and not monitor.abortRequested():
                    win.tick();monitor.waitForAbort(.1)
            finally:
                win.finish()
                screen_guard.release()
                win._release()
                if windowed:release_windowed()

    except Exception as exc:
        xbmcgui.Dialog().ok('IPTV',str(exc) if isinstance(exc,ValueError) else 'IPTV could not open. Check IPTV Simple and your playlist in Kodi PVR settings.')
