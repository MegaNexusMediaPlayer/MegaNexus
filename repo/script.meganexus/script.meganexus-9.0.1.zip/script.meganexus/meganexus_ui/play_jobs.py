# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from resources.lib import art_cache
"""Rounded source selection and artwork that stays visible until AV starts."""
import queue
import re
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

class JobPool:
    """Bounded workers which can close and reopen with Kodi's reused invoker."""
    def __init__(self,workers=2,name="MegaNexusLoad"):
        self.lock=threading.RLock();self.pool=None;self.pending=set();self.workers=workers;self.name=name
    def submit(self,fn):
        with self.lock:
            if self.pool is None:self.pool=ThreadPoolExecutor(max_workers=self.workers,thread_name_prefix=self.name)
            future=self.pool.submit(fn);self.pending.add(future)
            future.add_done_callback(self._done)
            return future
    def _done(self,future):
        with self.lock:self.pending.discard(future)
    def shutdown(self):
        with self.lock:
            pool=self.pool;self.pool=None;pending=list(self.pending);self.pending.clear()
        for future in pending:future.cancel()
        if pool:pool.shutdown(wait=False)

_JOBS=JobPool()
_BACKGROUND=JobPool(1,"MegaNexusDetailsExtras")
_CATALOG=JobPool(2,"MegaNexusCatalog")
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import backend_api

ROOT=xbmcaddon.Addon('script.meganexus').getAddonInfo('path')

from .source_text import plain as plain_label, normalized as normalized_source
from . import listitems
from resources.lib.theme import folder as theme_folder
_ORIGIN = 'mnx-cacaa809b488'

LOCK=25   # seconds Back / Esc wait while a chosen source starts

class Loading(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self._xml=args[0] if args else '';self.meta=kwargs.get('meta') or {};self.full=kwargs.get('full',False);self.label=kwargs.get('label','Loading sources');self.cancelled=False
        self.hub=kwargs.get('hub',False)  # 7.0.10: HUB picture + progress ring (opening MegaNexus / Sport)
        self._closed=False;self._filling=False;self._full=False;self._round=0;self.locked=0
        # 7.0.29: the title's picture is there from the first frame (onInit comes after
        # the window was first drawn - the wallpaper showed for a moment).
        try:self.apply()
        except Exception:pass
    SHOWN=('background','fanart','poster','logo','clearlogo','name','title')

    def apply(self,meta=None):
        """The title's picture, logo and name - again when the full details arrive
        (7.0.29: a resume opens this screen at once, on the card's own pictures).

        8.1.2: the second call only fills in what was NOT on screen yet. It used to
        replace all of it, so a film that opened on the card's own artwork - often the
        one in the person's own language, because that is what the provider gave the
        card - visibly swapped to another picture and an English title a moment later:
        "na pokretanju filmova zna prikazati 2 razlicita artworka". Whatever was shown
        first stays shown; the full details only add what was missing.
        """
        if meta:
            kept={key:value for key,value in (self.meta or {}).items() if value and key in self.SHOWN}
            self.meta=dict(meta,**kept)
        m=self.meta or {}
        self.setProperty('meganexus.full','1' if self.full else '')
        self.setProperty('meganexus.hub','1' if self.hub else '')
        if not (self.full and not self.hub):
            # 7.0.42: every other loading is our ring alone - no picture, name or words
            for key in ('meganexus.art','meganexus.poster','meganexus.title','meganexus.logo'):self.setProperty(key,'')
            return
        # starting a film: its picture, and its logo filling while the streams are searched (7.0.12)
        art=m.get('background') or m.get('fanart') or m.get('poster') or ''
        self.setProperty('meganexus.art',art_cache.url(art) if art else '')
        self.setProperty('meganexus.poster',art_cache.url(m.get('poster') or ''))
        self.setProperty('meganexus.title',m.get('name') or m.get('title') or '')
        logo=m.get('logo') or m.get('clearlogo') or ''
        self.setProperty('meganexus.logo',art_cache.url(logo) if logo else '')
        if logo and not self._filling:
            self._filling=True
            threading.Thread(target=self._fill,name='MegaNexusLogoFill',daemon=True).start()
    def onInit(self):
        xbmcgui.Window(10000).setProperty('meganexus.loading.active',str(time.time()))  # 7.0.11: when, so a lost one expires
        if self.hub and not self.getProperty('meganexus.ring'):self.setProperty('meganexus.ring','00')
        # 7.0.42: our ring only, no words (the opening's One-time setup sets its own)
        self.setProperty('meganexus.loading','')
        self.apply()
    def _fill(self):
        import math
        start=time.monotonic();monitor=xbmc.Monitor();round_=self._round
        while not self._closed and not self._full and round_==self._round:
            # Fast at first, then slower towards 90 % - the search time is unknown.
            step=max(1,min(18,int(18*(1-math.exp(-(time.monotonic()-start)/4.0)))+1))
            if self._full or round_!=self._round:break
            self.setProperty('meganexus.fill','%02d'%step)
            if monitor.waitForAbort(.15):break
    def refill(self):
        """8.1.3: the next source is being tried - the logo fills again from the start."""
        if not self._full:return
        self._round+=1;self._full=False;self._filling=False   # a filling still asleep stops
        self.setProperty('meganexus.fill','01')
        self.apply()

    def filled(self):
        # 8.1.3: and it stays full - the filling went on and took the logo from full back
        # to 90 % while the film's first frames were awaited
        self._full=True
        self.setProperty('meganexus.fill','20')
    def onAction(self,action):
        if action.getId() in (9,10,92,216):
            # 7.0.29: once a source is starting, Back / Esc wait - leaving then left the film
            # loading behind Home and the display switching colours under the interface.
            # A source that never opens can still be left after LOCK seconds.
            if self.locked and time.monotonic()-self.locked<LOCK:return
            if getattr(self,'holding',False):return   # 9.0.0: a job that may not stop half way (startup.switch_artwork)
            self.cancelled=True
    def close(self):
        self._closed=True
        xbmcgui.Window(10000).clearProperty('meganexus.loading.active')
        super().close()

BUSY_XML='meganexus_busy.xml'


def job(fn,meta=None,full=False,label='Loading sources',cancel=None,window=None,quiet=False):
    """Run fn off the GUI thread behind a loading screen. An already open
    ``window`` is reused and left open, so consecutive steps show one screen.
    ``quiet`` (7.0.29): during a video - a small pill at the bottom instead of the
    loading screen, the film stays in view (an error still comes as a dialog)."""
    own=window is None
    xml=BUSY_XML if quiet else 'meganexus_loading.xml'
    win=window or Loading(xml,ROOT,theme_folder(),'1080i',meta=meta,full=full,label=label)
    if not own:win.setProperty('meganexus.loading','')   # 7.0.42: the ring only
    results=queue.Queue()
    def work():
        try:results.put((True,fn()))
        except Exception as exc:results.put((False,exc))
    if own:win.show()
    future=_JOBS.submit(work)
    try:
        while not win.cancelled and not xbmc.Monitor().abortRequested():
            try:
                ok,value=results.get_nowait()
                if win.cancelled or xbmc.Monitor().abortRequested():return None
                if not ok:raise value
                return value
            except queue.Empty:
                xbmc.Monitor().waitForAbort(.05)
        return None
    finally:
        if cancel is not None:cancel.set()
        future.cancel()
        if own:
            win.close()
            gone(xml)


def gone(xml,limit=1.5):
    """7.0.29: wait until Kodi has really removed a closed MegaNexus window. On the
    Cube the next window (Choose source) got the id of the Loading window that was
    still fading out: its list could not take the focus - an empty screen the remote
    could hardly leave, and it worked only after a few tries."""
    monitor=xbmc.Monitor();end=time.monotonic()+limit
    while xbmc.getCondVisibility('Window.IsVisible(%s)'%xml) and time.monotonic()<end:
        if monitor.waitForAbort(.03):break

DIRECT=('torbox','premiumize','offcloud','realdebrid','alldebrid','easynews')   # the debrid services' own results ("TorBox direct")


def addon_of(row):
    """(key, label) of the add-on a source comes from - every source shows it."""
    source=row.get('_meganexus_source') or {}
    name=plain_label(source.get('name') or '') or 'Add-on'
    if source.get('id') in DIRECT:name+=' direct'
    return str(source.get('id') or name),name


REFRESH=-2   # 7.0.44: Refresh on the source list - search again


def source_header(meta,context=None):
    """7.0.44: what the source list shows of the title (left side, and the
    film's year or the episode over the sources)."""
    m=meta or {};context=context or {}
    def text(value):
        if isinstance(value,list):return ', '.join(str(v.get('name') if isinstance(v,dict) else v) for v in value[:3] if v)
        return str(value or '').strip()
    art=m.get('background') or m.get('fanart') or ''
    logo=m.get('logo') or m.get('clearlogo') or ''
    runtime=text(m.get('runtime'))
    if runtime.isdigit():runtime='%s min'%runtime
    info='  ·  '.join(v for v in (text(m.get('released'))[:10] if m.get('released') and not m.get('releaseInfo') else text(m.get('releaseInfo') or m.get('year')),
                                  text(m.get('genres') or m.get('genre')),runtime) if v)
    season,episode=str(context.get('season') or ''),str(context.get('episode') or '')
    if season and episode:
        video=next((v for v in m.get('videos') or [] if str(v.get('season'))==season and str(v.get('episode') or v.get('number'))==episode),{})
        name=str(video.get('name') or video.get('title') or '').strip()
        subtitle='S%02dE%02d%s'%(int(season) if season.isdigit() else 0,int(episode) if episode.isdigit() else 0,'  ·  '+name if name else '')
    else:
        subtitle=' '.join(v for v in (str(m.get('name') or m.get('title') or ''),'(%s)'%text(m.get('year') or m.get('releaseInfo'))[:4] if (m.get('year') or m.get('releaseInfo')) else '') if v)
    plot=m.get('description') or m.get('overview') or ''
    if season and episode:plot=next((str(v.get('overview') or v.get('description') or '') for v in m.get('videos') or []
                                       if str(v.get('season'))==season and str(v.get('episode') or v.get('number'))==episode and (v.get('overview') or v.get('description'))),plot)
    return {'art':art_cache.url(art) if art else '','logo':art_cache.url(logo) if logo else '',
            'title':str(m.get('name') or m.get('title') or ''),'info':info,
            'rating':text(m.get('imdbRating') or m.get('rating')),'plot':plot,'subtitle':subtitle}


class Sources(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self.rows=kwargs['rows'];self.choice=-1;self.closed=False;self.ready=False
        self.download=kwargs.get('download')   # 7.0.29: long OK / menu key on a source
        self.tabs=[];self.tab=0;self.visible=[]
        # 7.0.44: the title on the left only where nothing shows it underneath (the
        # source list over a paused video); over Home / a title the list is just its panel
        self.header=kwargs.get('header') or {}
        self.meta=kwargs.get('meta') or {}
        self.feed=kwargs.get('feed')   # 8.1.3: the add-ons asked, and which still search
    def _formatter(self):
        if not hasattr(self,'_format'):
            try:
                from resources.lib import source_formats
                self._format=(source_formats,source_formats.chosen()[1])
            except Exception:
                self._format=(None,None)
        return self._format
    def _item(self,i,row):
        _,provider=addon_of(row)
        lines=None
        formats,template=self._formatter()
        if template:
            try:
                facts=formats.facts(row,getattr(self,'meta',None))
                # 7.0.44: written by the chosen formatter when the row says enough about itself
                if facts['res'] or facts['size'] or facts['quality']:lines=formats.lines(row,template,getattr(self,'meta',None))
            except Exception:lines=None
        if lines and lines[0]:
            name,details=lines   # 7.0.44: written by the chosen formatter
        else:                    # the add-on's own text (7.0.29: always with the add-on it comes from)
            name=provider+' · '+(' '.join(plain_label(row.get('name')).split()) or 'Source %d'%(i+1))
            details='  |  '.join(plain_label(row.get('title') or row.get('description')).splitlines())
        item=listitems.item(label=name,label2=details.replace('[CR]','  ·  '))
        under=details.split('[CR]')   # 7.0.44: each line its own label - the focused source scrolls them
        item.setProperty('line2',under[0]);item.setProperty('line3',under[1] if len(under)>1 else '')
        item.setProperty('provider',provider)
        item.setProperty('size',source_size(row))
        # 7.0.29: Nuvio badges are their own pictures, side by side - Kodi
        # draws (downloads, scales, caches) them; no pill of ours around them.
        custom=row.get('_meganexus_badges')
        pictures=[badge.get('kodi_image') or badge.get('image') for badge in (custom or [])]
        pictures=[picture for picture in pictures if picture][:8]
        for index,picture in enumerate(pictures):item.setProperty('badge%d.img'%index,picture)
        if not pictures:   # no badge set (or no pictures in it): the names, quietly
            names=[badge['name'] for badge in custom[:8]] if custom is not None else source_badges(row)
            item.setProperty('badgetext','  ·  '.join(names))
        return item
    def _wanted(self,row):
        """The row belongs in the list under the add-on chosen on the row of pills."""
        key=self.tabs[self.tab][0] if self.tabs else None
        return key is None or addon_of(row)[0]==key
    def _fill(self,keep=None):
        self.visible=[i for i,row in enumerate(self.rows) if self._wanted(row)]
        control=self.getControl(500);control.reset()
        control.addItems([self._item(i,self.rows[i]) for i in self.visible])
        at=next((n for n,i in enumerate(self.visible) if self.rows[i] is keep),0) if keep is not None else 0
        if self.visible:control.selectItem(at)

    # ---- 8.1.3: the add-on row and sources that arrive while the list is open ----
    @staticmethod
    def _key(row):
        source=row.get('_meganexus_source') or {}
        return (source.get('id') or source.get('name'),row.get('url') or row.get('infoHash') or row.get('externalUrl') or row.get('ytId') or '',
                row.get('fileIdx'),plain_label(row.get('name')),plain_label(row.get('title') or row.get('description')))

    def _tab_list(self):
        """All, then every add-on asked - in the order they were asked, never reordered -
        each with what it found, "searching..." or "nothing found"."""
        feed=getattr(self,'feed',None) or {}
        counts={};names={}
        for row in self.rows:
            key,name=addon_of(row);counts[key]=counts.get(key,0)+1;names.setdefault(key,name)
        order=getattr(self,'_tab_order',None)
        if order is None:order=self._tab_order=[]
        for key,name in feed.get('addons') or []:
            if key not in order:order.append(key)
            names.setdefault(key,plain_label(name) or key)
        for key in counts:
            if key not in order:order.append(key)
        pending=set(feed.get('pending') or ());done=feed.get('done',True)
        tabs=[(None,'All · %d'%len(self.rows),'found' if self.rows else 'searching')]
        for key in order:
            name=names.get(key,key);count=counts.get(key,0)
            if count:tabs.append((key,'%s · %d'%(name,count),'found'))
            elif not done and (name in pending or key in pending):tabs.append((key,'%s · searching…'%name,'searching'))
            else:tabs.append((key,'%s · nothing found'%name,'none'))
        return tabs

    def _show_tabs(self):
        tabs=self._tab_list();control=self.getControl(600)
        old=self.tabs or []
        if not old or [t[0] for t in tabs[:len(old)]]!=[t[0] for t in old]:
            control.reset()
            control.addItems([self._tab_item(tab) for tab in tabs])
            control.selectItem(min(self.tab,len(tabs)-1))
        else:
            for index,(was,now) in enumerate(zip(old,tabs)):
                if was!=now:
                    item=control.getListItem(index);item.setLabel(now[1]);item.setProperty('state',now[2])
            if len(tabs)>len(old):
                at=control.getSelectedPosition()
                control.addItems([self._tab_item(tab) for tab in tabs[len(old):]])
                if control.getSelectedPosition()!=at:control.selectItem(at)
        self.tabs=tabs

    @staticmethod
    def _tab_item(tab):
        item=listitems.item(label=tab[1]);item.setProperty('state',tab[2])
        return item
    def onInit(self):
        for key,value in (getattr(self,'header',None) or {}).items():self.setProperty('meganexus.src.'+key,value)
        self.tabs=[];self.tab=0
        self._show_tabs()
        self._fill()
        self.setFocusId(500);self.ready=True
    def _current(self):
        try:pos=self.getControl(500).getSelectedPosition()
        except Exception:return None
        return self.rows[self.visible[pos]] if 0<=pos<len(self.visible) else None
    def update_rows(self,rows,more=''):
        """7.0.29: more add-ons answered. 8.1.3: the new sources are only ADDED, at the end -
        nothing already in the list moves and the cursor stays on its source. Every answer
        came as a fresh, re-sorted copy of the whole list, the source under the cursor was
        looked for by identity, never found, and the cursor went back to the first one:
        "spustim se na dno, pojavi se nešto novo i vrati me na početak"."""
        self.setProperty('meganexus.sources.more',more if isinstance(more,str) else '')
        if not self.ready or rows is self.rows:return
        known={self._key(row) for row in self.rows}
        new=[row for row in rows if self._key(row) not in known]
        if new:
            first=len(self.rows);self.rows=self.rows+new
            shown=[first+n for n,row in enumerate(new) if self._wanted(row)]
            if shown:
                control=self.getControl(500);at=control.getSelectedPosition()
                self.visible=self.visible+shown
                control.addItems([self._item(i,self.rows[i]) for i in shown])
                if at>=0 and control.getSelectedPosition()!=at:control.selectItem(at)
        self._show_tabs()
    def tick(self):
        """Moving along the add-on row filters the list (select_source's loop)."""
        if not self.ready or self.closed or self.getFocusId()!=600:return
        pos=self.getControl(600).getSelectedPosition()
        if 0<=pos<len(self.tabs) and pos!=self.tab:
            self.tab=pos;self._fill()
    def close(self):
        self.closed=True;super().close()
    def onClick(self,cid):
        if cid==500:
            pos=self.getControl(500).getSelectedPosition()
            if 0<=pos<len(self.visible):self.choice=self.visible[pos];self.close()
        elif cid==600:self.setFocusId(500)
        elif cid==610:self.choice=REFRESH;self.close()   # 7.0.44: search again
        elif cid==611:self.close()
    def onAction(self,action):
        if action.getId() in (9,10,92,216):self.close()
        elif action.getId() in (101,117) and getattr(self,'download',None) and self.getFocusId()==500:
            # 7.0.29: a long OK (Kodi's context menu) - download this source; the list stays
            index=self.getControl(500).getSelectedPosition()
            if 0<=index<len(self.visible):self.download(self.rows[self.visible[index]])

def _download(meta,context,row,source):
    from .downloads import start
    start(meta,context,row,source)   # playback_context takes the row's own add-on first


def select_source(rows,download=None,cover=None,feed=None,meta=None,context=None,standalone=False,quiet=False):
    """The source list. ``cover`` (7.0.29): the loading shown while the sources were
    searched - the list opens over it and it closes underneath, so nothing between
    them blinks (the wallpaper, black or another screen showed for a moment)."""
    from resources.lib import quality_badges, settings_snapshot
    # Phone imports can happen while Home's interpreter is still running.
    # Read the current toggle for this explicit source choice.
    settings_snapshot.invalidate()
    if feed is None and quality_badges.cached_addon().getSetting(quality_badges.ENABLED)=='true':
        prepared=job(lambda:quality_badges.decorate(rows),label='Preparing source badges',window=cover,quiet=quiet)   # 8.1.3: quiet - no loading screen over Sport
        if prepared is None:
            if cover is not None:cover.close()
            return -1
        rows=prepared
    if cover is None:gone('meganexus_loading.xml')
    try:header=dict(source_header(meta,context),standalone='1' if standalone else '')
    except Exception:header={}
    win=Sources('meganexus_sources.xml',ROOT,theme_folder(),'1080i',rows=rows,download=download,header=header,meta=meta,feed=feed)
    try:
        win.show();monitor=xbmc.Monitor();focused=False;version=feed['version'] if feed else 0;asked=0.0;ended=False
        while not win.closed and not monitor.abortRequested():
            monitor.waitForAbort(.05)
            # Loading.close and Sources.show can land in the same GUI frame.
            # Apply focus after activation, when Kodi has finished closing Loading.
            win.tick()
            if feed and win.ready and (feed['version']!=version or feed['done']!=ended):
                version=feed['version'];ended=feed['done']   # 8.1.3: the end too - "searching..." becomes "nothing found"
                win.update_rows(feed['rows'],'' if feed['done'] else feed.get('waiting') or '')
            if win.ready and not focused and not win.closed:
                # 8.1.3: asked until the list really has the cursor (2 s at most) - asked
                # once, Kodi could refuse it ("asked to focus, but it can't") and the list
                # opened with nothing focused until a key was pressed
                asked=asked or time.monotonic()
                try:held=win.getFocusId()
                except Exception:held=0
                if held in (500,600,610,611) or time.monotonic()-asked>2:focused=True
                else:win.setFocusId(500)
                if cover is not None:
                    cover.close();cover=None     # under the list now
        if feed is not None:feed['shown']=win.rows
        return win.choice
    finally:
        win.close()
        if cover is not None:cover.close()


WAIT_XML='meganexus_wait.xml'
# 7.0.29: screens a title was started from (Dialog.in_place). They stay while its
# sources are searched and chosen and hide only once the video starts.
PARENTS=[]


def wait_overlay(label='Loading sources…',meta=None):
    """The blue loading in the middle, over the screen the title was started from."""
    win=Loading(WAIT_XML,ROOT,theme_folder(),'1080i',meta=meta or {},label=label)
    win.show()
    return win


def ring_job(fn):
    """7.0.42: work behind our ring alone, over the screen as it is (no page
    background, no words) - the next screen comes when it is ready."""
    cover=wait_overlay('',{})
    try:return job(fn,None,label='',window=cover)
    finally:cover.close()


def _hide_parents():
    for parent in list(PARENTS):
        if not getattr(parent,'_meganexus_play_hidden',True):
            parent._meganexus_play_hidden=True
            try:xbmcgui.WindowXMLDialog.close(parent)
            except Exception:pass


PLAYING='meganexus.playing.request'


def remember_playing(meta,context,row):
    """7.0.29: what is playing, for the player's Sources button and its badge
    row (Window(Home).Property(meganexus.playing.*))."""
    import json
    home=xbmcgui.Window(10000)
    keep={k:context.get(k) for k in ('video_id','season','episode') if context.get(k) not in (None,'')}
    try:home.setProperty(PLAYING,json.dumps({'meta':meta,'context':keep},default=str))
    except (TypeError,ValueError):home.clearProperty(PLAYING)
    if row:
        from resources.lib.party_bridge import note_release
        note_release(row)          # 7.0.52: Watch Party - which release the host plays
    pictures=[]
    if row:
        try:
            from resources.lib import quality_badges
            badges=row.get('_meganexus_badges')
            if badges is None and quality_badges.cached_addon().getSetting(quality_badges.ENABLED)=='true':
                badges=quality_badges.match(' '.join(str(row.get(k) or '') for k in ('name','title','description')))
            pictures=[p for p in (b.get('kodi_image') or b.get('image') for b in (badges or [])) if p][:8]
        except Exception:pictures=[]
        home.setProperty('meganexus.playing.source',plain_label(row.get('name') or ''))
    else:home.clearProperty('meganexus.playing.source')
    for index in range(8):home.setProperty('meganexus.playing.badge%d'%index,pictures[index] if index<len(pictures) else '')


def switch_source():
    """The player's Sources button: pause, choose another source of the same
    title (the same picker), carry on from the same minute. Back resumes."""
    import json
    home=xbmcgui.Window(10000);player=xbmc.Player()
    try:data=json.loads(home.getProperty(PLAYING) or '{}')
    except ValueError:data={}
    meta=data.get('meta');context=data.get('context') or {}
    if not meta or not player.isPlayingVideo():
        xbmcgui.Dialog().notification('MegaNexus','No MegaNexus title is playing.');return False
    home.setProperty(CHOOSING,'1')
    try:return _switch(meta,context,player)
    finally:home.clearProperty(CHOOSING)


def _switch(meta,context,player):
    paused_here=False
    try:
        position=player.getTime()
        if not xbmc.getCondVisibility('Player.Paused'):player.pause();paused_here=True
    except Exception:position=0
    def carry_on():
        if paused_here and xbmc.getCondVisibility('Player.Paused'):player.pause()
    result=job(lambda:backend_api.streams(meta.get('type') or 'movie',context.get('video_id') or meta['id'],complete=True),meta,False,label='Loading sources',quiet=True)
    if not result or not result[1]:
        carry_on();return False
    source,rows=result
    selected=select_source(rows,download=lambda row:_download(meta,context,row,source),meta=meta,context=context,standalone=True)
    if selected==REFRESH:
        carry_on();return _switch(meta,context,player)
    if selected<0:
        carry_on();return False
    remember_playing(meta,context,rows[selected])
    ctx=backend_api.playback_context(meta,rows[selected],source,context.get('season',''),context.get('episode',''),
                                     context.get('video_id') or meta['id'],int(position or 0))
    return _start(meta,ctx,None)


def source_size(row):
    size=(row.get('behaviorHints') or {}).get('videoSize') or row.get('size')
    try:
        size=float(size)
        if size>0:return ('%.2f GB'%(size/1_000_000_000))
    except (TypeError,ValueError):pass
    match=re.search(r'\b\d+(?:[.,]\d+)?\s*(?:GiB|GB|MiB|MB|TB)\b',str(row.get('title') or row.get('description') or ''),re.I)
    return match.group(0) if match else ''

class StartListener(xbmc.Player):
    def __init__(self,token):super().__init__();self.started=False;self.failed=False;self.token=token;self.opening=False;self.ended=False
    def onPlayBackStarted(self):self.opening=True   # the video is being opened: the TV switches next
    def onPlayBackEnded(self):
        if self.opening:self.ended=True              # 7.0.29: over at once - not a film
    def onPlayBackStopped(self):
        if self.opening:self.ended=True
    def onAVStarted(self):
        try:
            self.started=xbmcgui.Window(10000).getProperty('meganexus.playback.started')==self.token
        except Exception:pass
    def onPlayBackError(self):self.failed=True

CHOOSING='meganexus.playback.choosing'


def _hold_wallpaper(on):
    """7.0.29: the experimental video wallpaper steps aside while sources are
    searched and chosen (on Amlogic its video layer could hide the picker)."""
    home=xbmcgui.Window(10000)
    if not on:home.clearProperty(CHOOSING);return
    home.setProperty(CHOOSING,'1')
    try:
        from resources.lib import wallpaper_video
        wallpaper_video.suspend()
    except Exception:pass


def release_allowed(meta,context):
    """7.0.32, Settings > Playback > Digital release filter (AIOStreams' rules):
    a film only in cinemas or an episode not aired yet is not searched or
    played - Play, a manual search, Continue Watching and the last link alike."""
    from resources.lib import release_info
    if not release_info.filter_on():return True
    episode=None
    if (meta.get('type') or '') in ('series','anime','tv'):
        wanted=str(context.get('video_id') or '')
        for video in meta.get('videos') or []:
            if not isinstance(video,dict):continue
            if (wanted and str(video.get('id'))==wanted) or (str(video.get('season'))==str(context.get('season')) and str(video.get('episode'))==str(context.get('episode'))):
                episode=video;break
        if episode is None:return True                 # nothing known about it: never blocked
        allowed,why=release_info.digital_verdict(meta,episode=episode)
    else:
        dates=job(lambda:release_info.tmdb_dates(meta),meta,label='Checking the release')
        allowed,why=release_info.digital_verdict(meta,dates)
    if not allowed:
        xbmc.log('[MegaNexus] Digital release filter: %s'%why,xbmc.LOGINFO)
        xbmcgui.Dialog().ok('Digital release filter',why+'[CR][CR]No sources are searched until it is out. '
                            'Turn the filter off in Settings > Playback to search anyway.')
    return allowed


def play(meta,context):
    if not release_allowed(meta,context):return False
    # 7.0.50: your refresh-rate setting back as the film's loading begins (not only as it
    # opens) - Kodi has it before it picks the TV's mode for the film
    try:
        from resources.lib.refresh_guard import release_all
        release_all()
    except Exception:pass
    _hold_wallpaper(True)
    try:return _play_held(meta,context)
    finally:_hold_wallpaper(False)


_HANDOFF=[]


def handoff(window):
    """7.0.29: a title's loading screen (its picture, the filling logo) already up
    when a resume starts - play() carries on in it instead of a second one."""
    _HANDOFF[:]=[window]


def _take_handoff():
    window=_HANDOFF[0] if _HANDOFF else None
    _HANDOFF[:]=[]
    return window


def _play_held(meta,context):
    auto=xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_autoplay')=='true' and not context.get('force_manual')
    loading_label='Loading video…' if auto else 'Loading sources…'
    # Autoplay keeps ONE loading screen from the source search until the video
    # starts; closing and reopening it flashed the page underneath.
    shared=_take_handoff()
    if not auto:
        # 7.0.29: choosing a source happens over the screen it was started from: the
        # blue loading in the middle until the list opens over it (no other screen,
        # wallpaper or black between them).
        if shared is None or getattr(shared,'_xml','')!=WAIT_XML:
            cover=wait_overlay('',meta)   # 7.0.44: the ring alone, no pill or words
            if shared is not None:shared.close()   # under the new one
            shared=cover
        else:shared.setProperty('meganexus.loading','')
    elif shared is not None:
        shared.full=True;shared.setProperty('meganexus.loading','')   # 7.0.42: no words
        shared.apply(meta)   # the full details: their picture and logo
    else:
        shared=Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label=loading_label)
        shared.show()
    try:
        from resources.lib import last_source
        if context.get('meganexus_continue') or context.get('resume_seconds') or context.get('resume_percent'):
            try:cached=job(lambda:last_source.context(meta,context),meta,auto,label='Loading video…',window=shared)
            except Exception:cached=None
            if cached:
                # the last link's own name: the player's badges and source line (7.0.29)
                remember_playing(meta,context,{'name':cached.get('stream_name') or '','title':cached.get('stream_title') or ''})
                result=_start(meta,cached,shared if auto else None,quiet=True)   # the title's loading screen, not the small one
                if result:return True
                if result is None:return False
                _BACKGROUND.submit(lambda:last_source.forget(cached))
                if shared and shared.cancelled:return False
                # 8.1.3: the last link is dead - the next sources are tried by themselves
                # (other add-ons and servers first), without a word in between
                return _play(meta,context,True,'Loading video…',shared if auto else None)
        return _play(meta,context,auto,loading_label,shared)
    finally:
        if shared:shared.close()


RECONNECTS=2   # 7.0.29: stream add-ons that did not answer are asked again


AUTO_SOURCES=6   # sources tried before giving up (7.0.29: 3; 8.1.3: other add-ons and servers first)
NEXT_PATIENCE=25 # 8.1.3: seconds a stand-in source gets to start (the first one 60)


def _host(row):
    from urllib.parse import urlsplit
    try:return (urlsplit(str(row.get('url') or '').split('|',1)[0]).hostname or '').lower()
    except ValueError:return ''


def _next_source(rows,tried):
    """8.1.3: the source to try after ``tried`` failed: the best one from an add-on and a
    server that have not failed yet, then one from another server, then the next in line.
    A dead server (a debrid CDN, StremThru) usually takes every link on it down."""
    # by what the source is, not which copy: the list on screen and the search behind it
    # each hold their own copy of a row (the badges are added to every new answer)
    gone={Sources._key(t) for t in tried}
    left=[r for r in rows if Sources._key(r) not in gone]
    addons={addon_of(r)[0] for r in tried};hosts={_host(r) for r in tried}-{''}
    for fits in (lambda r:addon_of(r)[0] not in addons and _host(r) not in hosts,lambda r:_host(r) not in hosts):
        for row in left:
            if fits(row):return row
    return left[0] if left else None


def _try_sources(meta,context,rows,source,window,tried,limit=AUTO_SOURCES,first=None):
    """8.1.3: one source after another under one loading screen until one plays - no
    message for a source that did not start. True / None (Back) / False (none played)."""
    began=len(tried)
    while len(tried)<limit:
        row=first if first is not None and len(tried)==began else _next_source(rows,tried)
        if row is None:break
        if len(tried)>began:
            xbmc.log('[MegaNexus] Playback: %s did not start - trying %s'%(addon_of(tried[-1])[1],addon_of(row)[1]),xbmc.LOGINFO)
            try:
                window.setProperty('meganexus.loading','Trying another source…')
                if hasattr(window,'refill'):window.refill()
            except Exception:pass
        remember_playing(meta,context,row)
        ctx=backend_api.playback_context(meta,row,source,context.get('season',''),context.get('episode',''),context.get('video_id') or meta['id'],context.get('resume_seconds') or 0)
        ctx['resume_percent']=context.get('resume_percent') or 0
        ctx['meganexus_quiet']=True
        try:
            from resources.lib import last_source
            last_source.tag(ctx)
        except Exception:pass
        result=_start(meta,ctx,window,quiet=True,patience=NEXT_PATIENCE if len(tried)>began else 60)
        if result or result is None or window.cancelled:return result
        tried.append(row)
    return False


def _close_failed_dialog(wait=2.0):
    """8.1.3: Kodi's own "Playback failed" after one of our tries is closed - the next
    source is on its way."""
    monitor=xbmc.Monitor();until=time.monotonic()+wait
    heading,body=xbmc.getLocalizedString(16026),xbmc.getLocalizedString(16027)
    while time.monotonic()<until:
        if xbmc.getCondVisibility('Window.IsActive(okdialog)'):
            # our skin's dialog has no heading control 1 - its text (9) says it as well;
            # one that cannot be read at all, right after our own try, is that one too
            title,text=xbmc.getInfoLabel('Control.GetLabel(1)'),xbmc.getInfoLabel('Control.GetLabel(9)')
            if title==heading or (body and text.startswith(body[:30])) or not (title or text):
                xbmc.executebuiltin('Dialog.Close(okdialog)')
            return
        if monitor.waitForAbort(.1):return
FIRST_SHOW=0.6   # 7.0.29: seconds the list waits for more once the first sources are in


def _grow(meta,context):
    """Search the sources in the background; feed['rows'] grows as add-ons answer."""
    import threading
    from resources.lib import quality_badges
    badges=quality_badges.cached_addon().getSetting(quality_badges.ENABLED)=='true'
    feed={'rows':[],'version':0,'done':False,'source':None,'error':None,'waiting':'','addons':[],'pending':[]}
    lock=threading.Lock()
    def publish(rows):
        if badges:
            try:rows=quality_badges.decorate(rows)
            except Exception:pass
        with lock:feed['rows']=rows;feed['version']+=1
    def waiting(names):
        # 7.0.43: the add-ons still searching, named in the list's title
        text='Searching: '+', '.join(names[:3])+(' +%d'%(len(names)-3) if len(names)>3 else '') if names else ''
        with lock:
            feed['pending']=list(names)   # 8.1.3: per add-on: still searching
            if text!=feed['waiting']:feed['waiting']=text;feed['version']+=1
    def started(addons):
        with lock:feed['addons']=list(addons);feed['version']+=1
    def work():
        try:
            source,rows=backend_api.streams(meta.get('type') or 'movie',context.get('video_id') or meta['id'],complete=True,on_update=publish,
                                            patience=backend_api.SLOW_TIMEOUT,on_waiting=waiting,on_start=started)
            feed['source']=source
            publish(rows)
        except Exception as exc:feed['error']=exc
        finally:feed['done']=True
    _JOBS.submit(work)
    return feed


def _choose(meta,context,cover,label):
    """7.0.29: the source list opens with the first sources, the others join it as
    their add-ons answer; reconnects when nothing came back."""
    monitor=xbmc.Monitor()
    for attempt in range(RECONNECTS+1):
        cover.setProperty('meganexus.loading','')   # 7.0.44: the ring alone until the list opens - no pill, no words
        feed=_grow(meta,context);first=None
        while not monitor.abortRequested() and not cover.cancelled:
            if feed['rows'] and first is None:first=time.monotonic()
            if feed['done'] or (first is not None and time.monotonic()-first>=FIRST_SHOW):break
            monitor.waitForAbort(.05)
        if cover.cancelled or monitor.abortRequested():
            cover.close();return False
        if feed['rows']:break
        errors=(feed['source'] or {}).get('_meganexus_errors') or feed['error']
        if not errors or attempt==RECONNECTS:
            cover.close()
            if errors:xbmcgui.Dialog().ok('Sources','No streams found - the stream add-ons did not answer. Check the internet connection and try again.')
            else:xbmcgui.Dialog().ok('Sources','No streams found for this title.')
            return False
        label='Reconnecting… (%d of %d)'%(attempt+2,RECONNECTS+1)
        if monitor.waitForAbort(2):return False
    blank={'id':'','name':'','base_url':''}
    failed=[]
    while True:
        gone={Sources._key(f) for f in failed}
        rows=[r for r in feed['rows'] if Sources._key(r) not in gone]
        if not rows:return False
        selected=select_source(rows,download=lambda row:_download(meta,context,row,feed['source'] or blank),cover=cover,feed=feed if not failed else None,
                               meta=meta,context=context)
        cover=None
        if selected==REFRESH:return _choose(meta,context,wait_overlay('',meta),label)   # 7.0.44: search again
        if selected<0:return False
        shown=feed.get('shown') if not failed else None
        row=(shown or rows)[selected]
        # 8.1.3: the chosen source, and when it does not start the next ones by themselves
        # (other add-ons and servers first) under the same loading screen - no message in
        # between. Only when none of them plays does the list come back, without them.
        window=Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label='')
        window.show()
        try:
            result=_try_sources(meta,context,list(feed['rows']),feed['source'] or blank,window,failed,
                                limit=len(failed)+AUTO_SOURCES,first=row)
        finally:window.close()
        if result or result is None:return result
        feed.pop('shown',None)


def _play(meta,context,auto,loading_label,shared):
    if not auto and shared is not None:return _choose(meta,context,shared,loading_label)
    label=loading_label
    for attempt in range(RECONNECTS+1):
        result=job(lambda:backend_api.streams(meta.get('type') or 'movie',context.get('video_id') or meta['id'],complete=not auto),meta,auto,label=label,window=shared)
        if result is None or (shared and shared.cancelled):return False
        source,rows=result
        if rows or not source.get('_meganexus_errors') or attempt==RECONNECTS:break
        # Nothing came back because add-ons did not answer (no network, a slow
        # server): reconnect and ask again before saying there are no streams.
        label='Reconnecting… (%d of %d)'%(attempt+2,RECONNECTS+1)
        if xbmc.Monitor().waitForAbort(2):return False
    if source.get('_meganexus_errors') and rows:
        xbmcgui.Dialog().notification('Stream add-ons', '%d add-on(s) unavailable; showing available results.' % len(source['_meganexus_errors']))
    if not rows:
        if shared:shared.close()
        if source.get('_meganexus_errors'):
            xbmcgui.Dialog().ok('Sources','No streams found - the stream add-ons did not answer. Check the internet connection and try again.')
        else:
            xbmcgui.Dialog().ok('Sources','No streams found for this title.')
        return False
    # 7.0.29: Autoplay tries the next source when one does not play (an instant end,
    # a debrid "not ready" clip). 8.1.3: up to AUTO_SOURCES, other add-ons and servers
    # first, without a word in between; one line at the end when none of them played.
    window=shared;own=None
    if window is None:
        # 7.0.42: ONE loading screen through every try - a new one per source showed the
        # page underneath between them (the film seemed to load twice)
        own=window=Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label='')
        window.show()
    try:
        tried=[]
        result=_try_sources(meta,context,rows,source,window,tried)
        if result is False and not window.cancelled:
            xbmcgui.Dialog().notification('Playback','None of %d sources started - choose one yourself.'%len(tried),time=5000)
        return result
    finally:
        if own is not None:own.close()


PLAYS_FOR=4        # 7.0.29: seconds a started video must keep playing to count as started
OPEN_WAIT=45       # 8.1.3: seconds Kodi may take to open a link and move its first frames (was 8)
MODE_WAIT=2.5      # 8.1.3: seconds a refresh-rate switch may take to begin once frames move
PLACEHOLDER=90     # seconds: a "film" this short is a debrid service's "not ready" clip


def _switch_coming(mode,fps):
    """8.1.3: will Kodi's "Adjust display refresh rate" switch the TV for this film? Only
    when the screen's rate is not already a whole multiple of the film's (60 Hz carries
    30 fps, not 23.976). Unknown either way counts as yes - the wait is short."""
    import re
    found=re.search(r'@\s*([\d.]+)',mode or '')
    try:hz=float(found.group(1));rate=float(fps or 0)
    except (AttributeError,ValueError):return True
    if not hz or not rate:return True
    return abs(hz-round(hz/rate)*rate)>.05


def _really_plays(listener):
    """After the start: the video goes on (not an instant end, not a debrid
    service's short "still downloading" clip - StremThru shows one at 1 fps that
    ends at once, and MegaNexus went back to the title page without a word)."""
    monitor=xbmc.Monitor();until=time.monotonic()+PLAYS_FOR;player=xbmc.Player()
    ended=lambda:getattr(listener,'ended',False) is True
    while time.monotonic()<until and not monitor.abortRequested():
        try:playing=player.isPlayingVideo()
        except Exception:playing=True
        if ended() or not playing:return False
        try:total=float(player.getTotalTime())
        except Exception:total=0
        if 0<total<PLACEHOLDER:
            player.stop();return False
        if monitor.waitForAbort(.2):break
    return not ended()


RESUME_WAIT=10     # 8.1.3: seconds the loading screen waits for the jump to the resume point


def _resume_point(ctx):
    """(seconds, percent) a start resumes at, or None for a start from the beginning."""
    try:seconds=float(ctx.get('resume_seconds') or 0);percent=float(ctx.get('resume_percent') or 0)
    except (TypeError,ValueError):return None
    return (seconds,percent) if seconds>=5 or 1<percent<95 else None


def _at_resume(player,resume,now):
    """Has the player jumped to the resume point (playback_watch's resume coordinator)?"""
    seconds,percent=resume
    if seconds<5:
        try:total=float(player.getTotalTime() or 0)
        except Exception:total=0
        if total<=60:return False
        seconds=total*percent/100.0
    return now>=seconds-15


def _hush(on):
    """8.1.3: the sound off while a resumed film opens at 0:00 and jumps on (the
    7.0.55 DTS-HD fix) - its first seconds were heard under the loading screen."""
    import json,os
    import xbmcvfs
    # Kodi keeps "muted" over a restart: a mark, so the service turns the sound back on
    # if Kodi went down in these few seconds (hub_service)
    mark=xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/hushed')
    try:
        if on:open(mark,'w').close()
        elif os.path.exists(mark):os.remove(mark)
    except OSError:pass
    # Kodi's mute icon and volume bar hidden meanwhile and a moment after (skin.meganexus:
    # meganexus.quiet, as for the muted Home trailers) - the icon showed at the top
    home=xbmcgui.Window(10000);stamp=str(time.time());home.setProperty('meganexus.quiet',stamp)
    xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Application.SetMute','params':{'mute':bool(on)}}))
    if not on:
        def later():
            xbmc.Monitor().waitForAbort(2.5)
            if home.getProperty('meganexus.quiet')==stamp:home.clearProperty('meganexus.quiet')
        threading.Thread(target=later,name='MegaNexusQuiet',daemon=True).start()


FRONT_WAIT=3.0   # 9.0.0: s after the loading screen goes in which the film is kept in front (a Back after it is yours)


def _film_in_front():
    """9.0.0: the loading screen has gone - Kodi then sometimes brings MegaNexus' base window
    up over the film (after the jump to the resume point most of all): the film was
    playing behind a picture of the HUB, and Back first closed that. The film goes back in
    front at once; only the base window counts - a screen the user opens stays."""
    monitor=xbmc.Monitor();until=time.monotonic()+FRONT_WAIT
    while time.monotonic()<until and not monitor.abortRequested():
        if not xbmc.getCondVisibility('Player.HasVideo'):return
        if xbmc.getCondVisibility('Window.IsActive(meganexus_session.xml) + !Window.IsActive(fullscreenvideo)'):
            xbmc.log('[MegaNexus] The base window came up over the film - the film back in front',xbmc.LOGINFO)
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        monitor.waitForAbort(.05)


def _wait_for_picture(listener,afr,mode,resume=None):
    """True once the film's picture moves (and, with the refresh rate switching, once the
    TV shows the film's mode); False when the player gave up first. ``resume``: (seconds,
    percent) - and only once it has jumped there (RESUME_WAIT at most)."""
    from resources.lib import curtain as display
    # 8.1.3: and "started" is not "playing": Kodi says it plays while it is still
    # opening the link, and a dead server fails only then (4.3 s later, after the old
    # 4 s check had already called it a success - no next source, Kodi's "Playback
    # failed"). It counts once the picture moves.
    monitor=xbmc.Monitor();until=time.monotonic()+OPEN_WAIT;player=xbmc.Player();first=None;moving=switched=jumping=None;moved=False
    while time.monotonic()<until and not monitor.abortRequested():
        if getattr(listener,'ended',False) is True or listener.failed:break
        if not xbmc.getCondVisibility('Player.HasVideo'):
            if not xbmc.getCondVisibility('Player.HasMedia'):break   # the player gave up
            monitor.waitForAbort(.1);continue                        # still opening the link
        if not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        elif not xbmc.getCondVisibility('Player.Caching'):
            try:now=player.getTime()
            except Exception:now=0
            if first is None:first=now
            elif now>first+.2:           # frames are moving
                if resume and not _at_resume(player,resume,now):
                    jumping=jumping or time.monotonic()
                    if time.monotonic()-jumping<RESUME_WAIT:
                        monitor.waitForAbort(.1);continue
                moved=True
                if not afr:break
                clock=time.monotonic();moving=moving or clock
                if xbmc.getInfoLabel('System.ScreenMode')!=mode:
                    switched=switched or clock
                    if clock-switched>=display.SETTLE:break      # the TV shows the film's mode
                elif clock-moving>=MODE_WAIT or not _switch_coming(mode,xbmc.getInfoLabel('Player.Process(videofps)')):
                    break                                        # no switch for this one
        monitor.waitForAbort(.1)
    return moved


def _start(meta,ctx,shared,quiet=False,patience=60):
    import uuid
    token=uuid.uuid4().hex;ctx['meganexus_request_id']=token
    from resources.lib.party_bridge import note_start
    note_start(meta,ctx)           # 7.0.52: Watch Party - the host's film goes to the party
    home=xbmcgui.Window(10000);home.clearProperty('meganexus.preview.active')
    home.setProperty('meganexus.playing.request_id',token)   # whose badges / Sources the player shows
    try:   # 7.0.50: the player's Sync button from the first second, whatever subtitle is on
        from resources.lib.meganexus_subtitles import autosync_on
        home.setProperty('meganexus.subtitle.syncable','1' if autosync_on() else '')
        try:
            from resources.lib import ai_subtitles
            home.setProperty(ai_subtitles.READY,'1' if ai_subtitles.enabled() and ai_subtitles.configured() else '')   # 8.1.3
        except Exception:pass
    except Exception:pass
    home.clearProperty('meganexus.preview.silent')
    listener=StartListener(token)
    win=shared or Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label='Starting playback')
    if shared is None:win.show()
    _hide_parents()    # 7.0.29: the screen it was started from, now under the loading screen
    hushed=False
    try:
        # 7.0.29: the title's picture and logo stay while the stream is found. 7.0.48: and
        # through the whole start - our black curtain while the TV switched its refresh
        # rate is gone (the user: no darkening; Kodi's switch itself is untouched); the
        # loading screen stays until the film is there, then fades away.
        from resources.lib import curtain as display

        win.locked=time.monotonic()
        # 8.1.3: with the refresh rate on "start/stop", frames move while the TV is still
        # switching - the loading screen went then and the HUB under it showed for a
        # moment before the film. The mode before the start tells when the switch is over.
        afr=display.afr_on();mode=xbmc.getInfoLabel('System.ScreenMode')
        if not xbmc.getCondVisibility('Player.HasVideo'):   # 9.0.0: not the mode of a film it takes over from
            home.setProperty('meganexus.gui.mode',mode)   # the stop curtain waits for the TV to come back to it
        resume=_resume_point(ctx);hushed=bool(resume) and not xbmc.getCondVisibility('Player.Muted')
        if hushed:_hush(True)
        xbmc.executebuiltin('RunPlugin("%s")'%backend_api.queue_playback(ctx))
        deadline=time.monotonic()+patience;gone=None
        while not listener.started and not listener.failed and not win.cancelled and time.monotonic()<deadline:
            # 8.1.3: Kodi gave up on the link (it could not connect): for a link it had begun
            # to open Kodi says "stopped", not "error", and this waited the full minute under
            # Kodi's "Playback failed" before the next source was tried
            if listener.opening:
                if listener.ended:break
                if xbmc.getCondVisibility('Player.HasMedia'):gone=None
                elif gone is None:gone=time.monotonic()
                elif time.monotonic()-gone>1.0:break
            # The long-lived service also confirms resolver handoffs which lose item properties.
            if home.getProperty('meganexus.playback.started')==token:
                listener.started=True;break
            if home.getProperty('meganexus.playback.error')==token:   # 7.0.12: the backend told why (TorBox...)
                home.clearProperty('meganexus.playback.error');return False
            # 9.0.0: no early hand-over for HDR / Dolby Vision any more. It closed the loading
            # screen the moment Kodi called the video HDR - before there was a picture - and
            # MegaNexus' base window showed in between (the user: logo full, background, film).
            # The logo stays until the film plays at its place, as for every other film.
            if xbmc.Monitor().waitForAbort(.1):break
        if listener.started:
            from resources.lib import last_source, player_session
            session=player_session.load_session() or {}
            saved=dict(ctx)
            if session.get('meganexus_request_id')==token and session.get('stream_url'):
                saved['stream_url']=session['stream_url']
            _BACKGROUND.submit(lambda:last_source.remember(saved))
            try:win.filled()
            except Exception:pass
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            # 7.0.29: the title's picture stays until the film is on screen - closed at
            # once, the wallpaper behind showed before the full-screen video.
            # 7.0.29: the loading screen stays until the film's picture really moves -
            # then it goes and the film is there (the page behind showed for a moment,
            # and the screen darkened about a second too early).
            # 9.0.0: the logo stays full until the film plays at its place (the jump to the resume
            # point included) - then it fades into the film. Kodi may bring MegaNexus' base window
            # up as the loading screen goes: _film_in_front puts the film back at once, and the
            # base window is black while a film starts or plays (meganexus_session.xml).
            moved=_wait_for_picture(listener,afr,mode,resume)
            if hushed:_hush(False);hushed=False   # at the resume point: the sound comes with the picture
            # 7.0.48: the film is on screen - the loading screen fades away over it in a second
            # (meganexus_loading.xml WindowClose); the check below happens under it
            try:win.setProperty('meganexus.loading.handover','1');win.close()
            except Exception:pass
            if moved:_film_in_front()
            if moved and _really_plays(listener):return True
            xbmc.log('[MegaNexus] The source %s'%('ended at once (not ready on the debrid service?)' if moved else 'did not open'),xbmc.LOGINFO)
            if quiet:_close_failed_dialog()
            if not quiet and not ctx.get('_last_source_reused'):
                if shared:shared.close()
                xbmcgui.Dialog().ok('Playback','This source ended at once - it is probably not ready on the debrid service yet. Choose another source.')
            return False
        home.setProperty('meganexus.cancelled.'+token,'1')
        if win.cancelled:return None
        if quiet:_close_failed_dialog()
        if not quiet and not win.cancelled and not ctx.get('_last_source_reused'):
            if shared:shared.close()
            xbmcgui.Dialog().ok('Playback','The selected source did not start. Try another source or check your provider.')
        return False
    finally:
        if hushed:_hush(False)               # never left silent - whatever happened
        if shared is None:win.close()


def source_badges(row):
    """Portable text pills replace font-dependent provider emoji badges."""
    raw=normalized_source(' '.join(str(row.get(k) or '') for k in ('name','title','description')))
    text=raw.upper(); result=[]
    for label,pattern in [('4K',r'\b(?:2160P|4K|UHD)\b'),('1080p',r'\b1080P\b'),('720p',r'\b720P\b'),
                          ('Dolby Vision',r'\b(?:DV|DOVI|DOLBY VISION)\b'),('HDR10+',r'HDR10\+'),('HDR',r'\bHDR(?:10)?\b'),
                          ('DD+',r'\b(?:DDP|DD\+|E[ .-]?AC[ .-]?3)(?![A-Z])'),('DTS',r'\bDTS\b'),('HEVC',r'\b(?:HEVC|X265|H[ .]?265)\b'),('AV1',r'\bAV1\b'),('Atmos',r'\bATMOS\b'),
                          ('Remux',r'\bREMUX\b'),('WEB-DL',r'\bWEB[ .-]?DL\b')]:
        if re.search(pattern,text):result.append(label)
    if any(c in raw for c in ('⚡','🚀')) or re.search(r'\bCACHED\b',text):result.append('Cached')
    if '🇭🇷' in raw or re.search(r'\b(?:CROATIAN|HRV|HRVATSKI)\b',text):result.append('HR')
    if '🇬🇧' in raw or '🇺🇸' in raw or re.search(r'\b(?:ENGLISH|ENG)\b',text):result.append('EN')
    return result[:8]
