# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""HUB Settings (7.0): API keys, the Stremio account (beta) and backup /
restore of every MegaNexus choice to move it to another device."""
import xbmcgui
import xbmcvfs
from resources.lib import api_keys, settings_cache, settings_backup, stremio_account
from . import settings_page as page


def keys():
    """Every API key with where to get it; Select pastes / replaces / removes."""
    def rows():
        return [page.item(k['name'] + ' · ' + k['purpose'], 'Set' if k['set'] else 'Not set') for k in api_keys.status()] + \
            [page.item('Back')]

    def choose(pick):
        status = api_keys.status()
        if pick >= len(status):
            return page.DONE
        k = status[pick]
        dialog = xbmcgui.Dialog()
        if k['set'] and dialog.select(k['name'], ['Replace the key', 'Remove the key']) == 1:
            api_keys.save(k['id'], '')
            return None
        value = dialog.input('%s API key (get it at %s)' % (k['name'], k['url']), option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
        if value:
            api_keys.save(k['id'], value)
        return None
    return page.show('API keys', rows, choose)


def stremio():
    def rows():
        return [page.item('Stremio account', stremio_account.status()),
                page.item('Import add-ons and Continue Watching now'),
                page.item('Keep Continue Watching in sync (beta)', enabled=stremio_account.keep_in_sync()),
                page.item('Back')]

    def choose(pick):
        dialog = xbmcgui.Dialog()
        if pick == 0:
            if stremio_account.linked():
                if dialog.yesno('Stremio', 'Sign out of Stremio on this device?'):
                    stremio_account.sign_out()
                return None
            email = dialog.input('Stremio email').strip()
            if not email:
                return None
            password = dialog.input('Stremio password', option=xbmcgui.ALPHANUM_HIDE_INPUT)
            stremio_account.sign_in(email, password)
            _import(dialog)
        elif pick == 1:
            if not stremio_account.linked():
                raise ValueError('Sign in to Stremio first.')
            _import(dialog)
        elif pick == 2:
            if not stremio_account.linked():
                raise ValueError('Sign in to Stremio first.')
            stremio_account.set_keep_in_sync(not stremio_account.keep_in_sync())
        elif pick == 3:
            return page.DONE
        return None
    return page.show('Stremio (beta)', rows, choose)


def _import(dialog):
    from .playback import job
    report = job(stremio_account.import_now, label='Importing from Stremio')
    if report is not None:
        dialog.ok('Stremio', '%d add-on(s) and %d Continue Watching title(s) imported.%s' % (
            report.get('providers', 0), report.get('progress', 0) or 0,
            ('[CR]' + ' '.join(report['errors'])) if report.get('errors') else ''))
    settings_cache.invalidate()


def backup():
    """Save a backup file to a folder the user picks (USB, network, Downloads)."""
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(3, 'Where should the backup go?', 'files')
    if not folder:
        return
    from .playback import job
    text = job(settings_backup.export_text, label='Writing the backup')
    if text is None:
        return
    target = folder.rstrip('/\\') + '/' + settings_backup.filename()
    handle = xbmcvfs.File(target, 'w')
    try:
        if not handle.write(text.encode('utf-8')):
            raise ValueError('The backup could not be written there. Choose another folder.')
    finally:
        handle.close()
    dialog.ok('Backup', 'Saved as %s.[CR][CR]It holds your sign-ins and API keys: keep it private. On another device: '
              'HUB Settings > Maintenance > Restore settings from a backup (or Set up on phone > Backup).' % target)


def restore():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(1, 'Choose the MegaNexus backup', 'files', '.json')
    if not path:
        return None
    if not dialog.yesno('Restore', 'Replace the settings, accounts, add-ons and collections on this device with the backup?'):
        return None
    handle = xbmcvfs.File(path)
    try:
        text = handle.read()
    finally:
        handle.close()
    from .playback import job
    report = job(lambda: settings_backup.import_text(text), label='Restoring the backup')
    if report is None:
        return None
    dialog.ok('Restore', 'Restored %d settings, %d files and %d libraries. MegaNexus reloads now.' % (
        report['settings'], report['files'], report['databases']))
    return 'reload'
