# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Cards built off screen (7.0.30).

Kodi takes its interface lock for every change to a ListItem it may draw: the
drawing thread waits each time. A Home of 24 rows set about 20 values per card,
some 10,000 locks, so on CoreELEC / Android boxes Home stuttered while it filled
and a collection took 2-3 s to open. A card built before it goes into a list
needs no lock (offscreen=True), and setProperties() hands all of its values over
in one call. Cards Kodi already shows (getListItem) keep their locks; the batch
still makes one lock of twenty.
"""
import xbmcgui


def item(label='', label2='', path=''):
    """A new card for addItems: built without interface locks."""
    extra = {'label': label, 'label2': label2}
    if path:
        extra['path'] = path
    try:
        return xbmcgui.ListItem(offscreen=True, **extra)
    except TypeError:   # a stand-in without offscreen (tests)
        return xbmcgui.ListItem(**extra)


def properties(li, values):
    """Set all of a card's properties at once (Kodi 20+), one by one otherwise."""
    values = {key: '' if value is None else str(value) for key, value in values.items()}
    if callable(getattr(type(li), 'setProperties', None)):
        li.setProperties(values)
        return
    for key, value in values.items():
        li.setProperty(key, value)
