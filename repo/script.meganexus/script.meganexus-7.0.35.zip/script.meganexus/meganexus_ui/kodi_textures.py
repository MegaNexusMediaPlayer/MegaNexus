# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Posters Kodi already keeps, and the image memory the preload may fill (7.0.7).

Kodi stores every poster it has shown in its own texture cache on disk
(userdata/Thumbnails + Textures DB) and never asks the image proxy for it
again, also after a restart. Preloading those into the proxy's RAM only cost
time, data and memory (the poster screen after each Kodi start). The preload
now skips them and fills the proxy with the posters Kodi does not have yet, up
to SHARE of the chosen image memory (RAM 128 / 256 / 512 MiB).
"""
import json
import os
from urllib.parse import quote, unquote

import xbmc
import xbmcgui

from resources.lib import art_cache

SHARE = .8


def proxy_url(base, url):
    return base + '/image?url=' + quote(url, safe='')


FULL = 'full:'   # 7.0.32: a picture Home shows at full size (a background, a title logo)


def full(url):
    return FULL + url


def link(url):
    """The proxy link itself, without the full-size mark."""
    url = str(url or '')
    return url[len(FULL):] if url.startswith(FULL) else url


def texture(url):
    """The link Kodi gets for a card's picture (7.0.30: at card size), so the
    preload stores exactly what the cards later ask for. Backgrounds and title
    logos (marked full:) and other pictures (the ratings logos) are shown by
    their own link."""
    url = str(url or '')
    if url.startswith(FULL):
        return url[len(FULL):]
    if not url.startswith('http://127.0.0.1:'):
        return url
    return art_cache.card(url)


def _plain(url):
    url = str(url or '')
    if url.startswith('image://') and '/transform?' not in url:
        # JSON-RPC wraps a texture URL as image://<encoded>/
        url = unquote(url[8:]).rstrip('/')
    if url.startswith('image://') and '/transform?' in url:   # a card-size picture (7.0.30)
        url = art_cache.uncard(url)
    return url.rstrip('/')


def _textures():
    """(texture id, url) of every picture Kodi keeps from 127.0.0.1.

    7.0.32: Kodi unwraps an image:// value in a JSON-RPC filter, so the
    'startswith image://<proxy>' filter of 7.0.30 found only the full-size
    copies, never the card-size ones the cards ask for: Kodi seemed to lack
    most posters and the opening screen prepared them on every start."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.GetTextures',
               'params': {'properties': ['url'], 'filter': {'field': 'url', 'operator': 'contains', 'value': '127.0.0.1'}}}
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        textures = (reply.get('result') or {}).get('textures') or []
    except Exception:
        return []
    return [(item.get('textureid'), str(item['url'])) for item in textures if isinstance(item, dict) and item.get('url')]


def _card(url):
    return '/transform?' in url or '%2ftransform%3f' in url.lower()


def cached(base):
    """Proxy URLs Kodi has in its texture cache; empty when unknown (preload all)."""
    if not str(base or '').startswith('http://127.0.0.1:'):
        return set()
    # 7.0.30: cards ask for card-size pictures - only those count.
    card = art_cache.card_size()
    found = set()
    for _, url in _textures():
        plain = _plain(url)
        if not plain.startswith(base + '/'):
            continue
        if _card(url) == card:
            found.add(plain)
        if not _card(url):
            found.add(FULL + plain)   # a background / title logo at full size
    return found


def count(base):
    """How many pictures Kodi keeps from the image proxy (Settings > Cache usage)."""
    if not str(base or '').startswith('http://127.0.0.1:'):
        return 0
    return sum(1 for _, url in _textures() if _plain(url).startswith(base + '/'))


def _ours(url):
    plain = _plain(url)
    return plain.startswith('http://127.0.0.1:') and ('/image?' in plain or '/anim?' in plain)


def ours():
    """Texture ids of every MegaNexus picture Kodi keeps (7.0.32): image-proxy
    links on any port (the proxy may get a new one after a restart), at card
    size or not, animations included."""
    return [texture_id for texture_id, url in _textures() if texture_id is not None and _ours(url)]


def remove(ids, progress=None):
    """Kodi deletes each copy from its Textures database and Thumbnails folder.
    ``progress(done, total)`` returning True stops. Returns how many went."""
    removed = 0
    for index, texture_id in enumerate(ids):
        if progress and progress(index, len(ids)):
            break
        request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.RemoveTexture', 'params': {'textureid': texture_id}}
        try:
            reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            if 'error' not in reply:
                removed += 1
        except Exception:
            pass
    return removed


def kept(urls):
    """Those of these (proxy) URLs Kodi keeps in its texture cache.

    7.0.17: read from Kodi's thumbnail files, not its Textures database - polling
    the database while Kodi writes to it for every new poster blocked Kodi's
    interface on CoreELEC (clicks did nothing for 20 s). Kodi names the file
    after the CRC-32 of the lower-case URL: Thumbnails/<h[0]>/<h>.jpg|png."""
    root = _thumbnails()
    if not root:
        return set()
    found = set()
    for url in urls:
        digest = kodi_crc(texture(url))
        folder = os.path.join(root, digest[0])
        if os.path.exists(os.path.join(folder, digest + '.jpg')) or os.path.exists(os.path.join(folder, digest + '.png')):
            found.add(url)
    return found


_THUMBS = []


def _thumbnails():
    if not _THUMBS:
        try:
            import xbmcvfs
            _THUMBS.append(xbmcvfs.translatePath('special://thumbnails/'))
        except Exception:
            return ''
    return _THUMBS[0]


def _crc_table():
    table = []
    for i in range(256):
        c = i << 24
        for _ in range(8):
            c = ((c << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if c & 0x80000000 else (c << 1) & 0xFFFFFFFF
        table.append(c)
    return table


_CRC = _crc_table()


def kodi_crc(text):
    """Kodi's Crc32::ComputeFromLowerCase (MSB-first CRC-32, no final xor), hex."""
    crc = 0xFFFFFFFF
    for byte in str(text).lower().encode('utf-8'):
        crc = ((crc << 8) & 0xFFFFFFFF) ^ _CRC[((crc >> 24) ^ byte) & 0xFF]
    return '%08x' % crc


def budget():
    """Bytes the preload may fill: SHARE of the chosen image memory."""
    try:
        import xbmcaddon
        from resources.lib import art_cache, ram_profile
        mode = ram_profile.chosen(xbmcaddon.Addon('plugin.video.meganexus'))
        return int(art_cache.LIMITS.get(mode, 0) * SHARE)
    except Exception:
        return 0


def used():
    """Bytes in the image proxy now (its 'x.x MB · n images' Home property)."""
    text = xbmcgui.Window(10000).getProperty('meganexus.art_cache.usage') or ''
    try:
        return int(float(text.split('MB')[0].strip()) * 1024 * 1024)
    except ValueError:
        return 0
