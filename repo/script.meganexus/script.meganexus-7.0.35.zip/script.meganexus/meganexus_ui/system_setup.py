# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import time
import xbmc
import xbmcaddon
import xbmcgui


def execute_command(command):
    """Called only after the owning MegaNexus modal window has closed."""
    while command:
        if command=='meganexus:reload':   # 7.0.30: a new theme chosen in the settings
            from resources.lib import theme
            theme.sync()
            return
        if command.startswith('meganexus:activate_skin'):
            from resources.lib import skin_activation
            xbmcgui.Window(10000).clearProperty(skin_activation.DECLINED)  # asked for it explicitly
            if skin_activation.switch()=='failed':skin_activation.report_failure()
            if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):return
            if command.endswith(':wizard'):
                from .onboarding import run
                command=run()
                continue
            xbmc.executebuiltin('ActivateWindow(Home)')
        else:xbmc.executebuiltin(command)
        return

def rpc(method,params=None):
    result=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params or {}})))
    if result.get('error'):raise RuntimeError('Kodi could not complete '+method)
    return result.get('result')

def ensure_addon(aid):
    from resources.lib import meganexus_uninstall
    before=meganexus_uninstall.inventory()
    if not xbmc.getCondVisibility('System.HasAddon(%s)'%aid):
        # Kodi's InstallAddon is already a cancellable modal operation. Waiting
        # for that operation distinguishes Cancel from an ongoing installation;
        # polling HasAddon afterwards used to lock Nuvio for another 60 seconds.
        xbmc.executebuiltin('InstallAddon(%s)'%aid,True)
        if not xbmc.getCondVisibility('System.HasAddon(%s)'%aid):return False
    rpc('Addons.SetAddonEnabled',{'addonid':aid,'enabled':True})
    meganexus_uninstall.record_install(aid,before,meganexus_uninstall.inventory())
    return True

def weather():
    if ensure_addon('weather.openmeteo'):
        rpc('Settings.SetSettingValue',{'setting':'weather.addon','value':'weather.openmeteo'})
        xbmcaddon.Addon('weather.openmeteo').openSettings()
        xbmc.executebuiltin('Weather.Refresh')

def screensaver():
    rpc('Settings.SetSettingValue',{'setting':'screensaver.mode','value':'screensaver.meganexus'})
    xbmcgui.Dialog().ok('MegaNexus screensaver','Enabled. Start time, background and widgets: HUB Settings > Home & appearance > Screensaver.')
