# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Downloads in the interface (7.0.29): the progress box, HUB Settings > Downloads
and the source list's long OK. The download itself runs in the service
(resources.lib.downloads)."""
import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import downloads as engine
from resources.lib.theme import folder as theme_folder

from . import settings_page as page

ROOT = xbmcaddon.Addon('script.meganexus').getAddonInfo('path')
STATES = {'queued': 'Waiting', 'downloading': 'Downloading', 'done': 'Finished', 'error': 'Stopped'}


class Progress(xbmcgui.WindowXMLDialog):
    """The box in the middle: the ring, size, speed and time left (live from the
    service's Window(Home) properties), "Close · continue" and "Stop"."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.stopped = False

    def onInit(self):
        self.setFocusId(10)

    def onClick(self, cid):
        if cid == 11:
            item_id = xbmcgui.Window(10000).getProperty(engine.PROP + 'id')
            if item_id and xbmcgui.Dialog().yesno('Stop the download', 'Stop the download and delete what was downloaded so far?',
                                                  nolabel='Keep going', yeslabel='Stop'):
                engine.stop(item_id)
                self.stopped = True
        self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61448, 61467):
            self.close()


def progress():
    """The corner ring's box."""
    if not xbmcgui.Window(10000).getProperty(engine.PROP + 'active'):
        return manage()
    win = Progress('meganexus_download.xml', ROOT, theme_folder(), '1080i')
    try:
        win.doModal()
    finally:
        del win


def choose_folder():
    current = engine.folder()
    path = xbmcgui.Dialog().browse(3, 'Download folder', 'files', defaultt=current or '')
    if path and path != current:
        engine.set_folder(path)
    return engine.folder()


def manage():
    """HUB Settings > Downloads."""
    def rows():
        items = engine.load()
        out = [page.item('Download folder', engine.folder() or 'Choose…'),
               page.item('How to download', 'Long OK on a source')]
        for item in items:
            done, size = int(item.get('done') or 0), int(item.get('size') or 0)
            state = STATES.get(item.get('state'), item.get('state') or '')
            if item.get('state') == 'downloading' and size:
                state += ' · %d %%' % int(done * 100 / size)
            out.append(page.item(item.get('title') or item.get('name'), state))
        if any(i.get('state') in ('done', 'error') for i in items):
            out.append(page.item('Clear finished downloads'))
        out.append(page.item('Back'))
        return out

    def choose(pick):
        items = engine.load()
        if pick == 0:
            choose_folder()
            return None
        if pick == 1:
            xbmcgui.Dialog().ok('Downloads', 'In the source list, hold OK on a source (or press the menu key) and choose '
                                'Download. It runs in the background - the blue ring by the clock shows how far it is; '
                                'select it for the details. A lost connection does not stop it: it carries on when the '
                                'network is back.')
            return None
        index = pick - 2
        if 0 <= index < len(items):
            item = items[index]
            if item.get('state') == 'error':
                xbmcgui.Dialog().ok(item.get('title') or 'Download', item.get('error') or 'The download stopped.')
            elif item.get('state') == 'done':
                xbmcgui.Dialog().ok(item.get('title') or 'Download', 'Saved as[CR]%s' % engine._join(item['folder'], item['name']))
            elif xbmcgui.Window(10000).getProperty(engine.PROP + 'id') == item['id']:
                progress()
            elif xbmcgui.Dialog().yesno(item.get('title') or 'Download', 'Remove it from the downloads?'):
                engine.stop(item['id'])
            return None
        extra = pick - 2 - len(items)
        if extra == 0 and any(i.get('state') in ('done', 'error') for i in items):
            engine.remove_finished()
            return None
        return page.DONE
    return page.show('Downloads', rows, choose)


def start(meta, context, row, source):
    """The source list's long OK: queue this source (the folder is asked once)."""
    from resources.lib import backend_api
    name = ' '.join(str(row.get('name') or '').split()) or 'this source'
    if not xbmcgui.Dialog().yesno('Download', 'Download this source?[CR][CR]%s' % name, nolabel='Cancel', yeslabel='Download'):
        return False
    if not engine.folder() and not choose_folder():
        return False
    try:
        ctx = backend_api.playback_context(meta, row, source, context.get('season', ''), context.get('episode', ''),
                                           context.get('video_id') or meta['id'], 0)
        item = engine.add(ctx)
    except ValueError as exc:
        xbmcgui.Dialog().ok('Download', str(exc))
        return False
    except Exception:
        import traceback
        xbmc.log('[MegaNexus] Download could not start: ' + traceback.format_exc(), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Download', 'The download could not start. Try another source.')
        return False
    xbmcgui.Dialog().notification('Download started', item['name'], xbmcgui.NOTIFICATION_INFO, 4000)
    return True
