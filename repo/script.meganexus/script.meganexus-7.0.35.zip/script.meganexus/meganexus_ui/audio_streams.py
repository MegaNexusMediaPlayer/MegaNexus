# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Audio stream choice from the player's OSD (7.0.24).

The OSD's audio button lists the playing video's audio streams - language,
format and channels, with the one playing marked - and switches to the one
chosen. Kodi's own JSON-RPC gives the details; nothing else is needed.
"""
import json

import xbmc
import xbmcgui

CHANNELS = {1: 'Mono', 2: 'Stereo', 6: '5.1', 7: '6.1', 8: '7.1'}


def _rpc(method, params=None):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}})))
    return reply.get('result')


def _video_player():
    for player in _rpc('Player.GetActivePlayers') or []:
        if player.get('type') == 'video':
            return player.get('playerid')
    return None


def label(stream):
    """'English · TrueHD · 7.1 · Director commentary'."""
    language = str(stream.get('language') or '').strip()
    try:
        name = xbmc.convertLanguage(language, xbmc.ENGLISH_NAME) if language else ''
    except Exception:
        name = ''
    parts = [name or language or 'Unknown language']
    codec = str(stream.get('codec') or '').replace('_', ' ').upper()
    if codec:
        parts.append(codec)
    channels = int(stream.get('channels') or 0)
    if channels:
        parts.append(CHANNELS.get(channels, '%d ch' % channels))
    title = str(stream.get('name') or '').strip()
    if title and title.lower() not in (name.lower(), language.lower()):
        parts.append(title)
    return ' · '.join(parts)


def run():
    player = _video_player()
    if player is None:
        return
    data = _rpc('Player.GetProperties', {'playerid': player, 'properties': ['audiostreams', 'currentaudiostream']}) or {}
    streams = data.get('audiostreams') or []
    if not streams:
        xbmcgui.Dialog().notification('Audio', 'This video has no other audio stream.', time=3000)
        return
    current = (data.get('currentaudiostream') or {}).get('index')
    if len(streams) == 1:
        xbmcgui.Dialog().notification('Audio', 'Only one audio stream: ' + label(streams[0]), time=4000)
        return
    rows = [('▶  ' if s.get('index') == current else '     ') + label(s) for s in streams]
    position = next((i for i, s in enumerate(streams) if s.get('index') == current), 0)
    choice = xbmcgui.Dialog().select('Audio stream', rows, preselect=position)
    if choice >= 0 and streams[choice].get('index') != current:
        _rpc('Player.SetAudioStream', {'playerid': player, 'stream': streams[choice]['index']})
