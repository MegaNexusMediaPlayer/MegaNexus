# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""HUB Settings: accounts, add-ons and presentation preferences."""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from resources.lib import settings_cache, collection_profile
from resources.lib.meganexus import store
from resources.lib.setup_wizard import add_manifest
from .system_setup import rpc,ensure_addon
from . import settings_page as page
from resources.lib.theme import folder as theme_folder

ADDON=settings_cache.cached_addon()

def select_provider(role):
    # Compatibility entry point for the existing wizard and collection editor.
    return metadata_addons() if role == 'metadata' else stream_addons()


def metadata_addons():
    from resources.lib import metadata_providers, default_setup
    def cinemeta_missing():
        return default_setup.cinemeta_provider(store.list_providers()) is None
    def rows():
        entries = metadata_providers.entries()
        result = [page.item(p.get('name') or p['id'],
                            'Built-in · no setup' if (p.get('manifest') or {}).get('id') == default_setup.CINEMETA_ID
                            else 'Metadata and compatible catalogs', enabled=on)
                  for p, on in entries]
        if cinemeta_missing():
            result.append(page.item('Cinemeta · built-in, no setup', 'Add'))
        return result + [page.item('Add metadata manifest URL'), page.item('Back')]
    def choose(pick):
        entries = metadata_providers.entries()
        extra = 1 if cinemeta_missing() else 0
        if pick < len(entries):
            provider, on = entries[pick]
            metadata_providers.set_enabled(provider['id'], not on)
            if (provider.get('manifest') or {}).get('id') == default_setup.CINEMETA_ID:
                # A manual choice: never switched back automatically.
                ADDON.setSetting(default_setup.CINEMETA_AUTO, '' if not on else 'off')
        elif extra and pick == len(entries):
            from .playback import job
            try:job(default_setup.install_cinemeta, label='Adding Cinemeta')
            except Exception:xbmcgui.Dialog().ok('Cinemeta','Cinemeta could not be added now. Check the connection and retry.')
            ADDON.setSetting(default_setup.CINEMETA_AUTO, '')
        elif pick == len(entries) + extra:
            before = {p['id'] for p in metadata_providers.candidates()}
            if add_manifest(xbmcgui.Dialog()):
                for p in metadata_providers.candidates():
                    if p['id'] not in before:
                        metadata_providers.set_enabled(p['id'], True)
        else:
            return page.DONE
    return page.show('Metadata add-ons · enable each provider', rows, choose)


def stream_addons():
    from resources.lib import stream_providers
    def rows():
        providers=stream_providers.entries()
        return [page.item(p.get('name') or p['id'], 'Stream results', enabled=on)
                for p,on in providers]+[page.item('Add stream add-on manifest URL'),page.item('Back')]
    def choose(pick):
        providers=stream_providers.entries()
        if pick<len(providers):
            provider,on=providers[pick]
            stream_providers.set_enabled(provider['id'],not on)
        elif pick==len(providers):
            before={p['id'] for p in stream_providers.candidates()}
            if add_manifest(xbmcgui.Dialog()):
                for p in stream_providers.candidates():
                    if p['id'] not in before:stream_providers.set_enabled(p['id'],True)
        else:return page.DONE
    return page.show('Stream add-ons · enable each provider',rows,choose)


DIM='[COLOR 59FFFFFF]%s[/COLOR]'
ROLES=(('streams','Streams'),('metadata','Metadata'),('subtitles','Subtitles'),('sport','Sport'))


def _role_modules():
    from resources.lib import stream_providers, metadata_providers, subtitle_providers, sport_providers
    return {'streams':stream_providers,'metadata':metadata_providers,'subtitles':subtitle_providers,'sport':sport_providers}


def _roles_of(provider):
    """{role: None (not offered) | True | False} for one add-on."""
    result={}
    for role,module in _role_modules().items():
        switches={p['id']:on for p,on in module.entries()}
        result[role]=switches.get(provider['id']) if provider['id'] in switches else None
    return result


def addon_roles(provider_id):
    """7.0.17: what one add-on is used for - streams, metadata, subtitles and
    (7.0.20) the Sport screen - each switched on its own. A role the add-on's
    manifest does not offer is dimmed (AIOStreams may serve all three,
    AIOMetadata only metadata and its sport catalogs, a subtitle add-on only
    subtitles)."""
    def provider():
        return next((p for p in store.list_providers() if p.get('id')==provider_id),None)
    def build():
        p=provider()
        if not p:return []
        roles=_roles_of(p)
        rows=[]
        for role,label in ROLES:
            if roles.get(role) is None:
                rows.append((role,page.item(DIM%label,DIM%'Not offered by this add-on')))
            else:
                rows.append((role,page.item(label,enabled=roles.get(role))))
        return rows
    def act(role):
        p=provider()
        if not p:return page.DONE
        on=_roles_of(p).get(role)
        if on is None:return None
        _role_modules()[role].set_enabled(provider_id,not on)
        settings_cache.invalidate()
        return None
    p=provider()
    return _keyed((p or {}).get('name') or provider_id,build,act)


def your_addons():
    """Every add-on with what it is used for (7.0.17)."""
    def summary(p):
        roles=_roles_of(p)
        parts=[label for role,label in ROLES if roles.get(role)]
        return ' · '.join(parts) if parts else 'Not used'
    def build():
        return [(p['id'],page.item(p.get('name') or p['id'],summary(p))) for p in store.list_providers() if p.get('id')]
    def act(provider_id):
        return addon_roles(provider_id)
    return _keyed('Your add-ons · streams, metadata, subtitles, sport',build,act)


ROLE_PAGES={'subtitles':('Subtitle add-ons · enable each provider','Subtitles','Add-ons that offer subtitles (OpenSubtitles, AIOStreams...) appear here.'),
            'sport':('Sport add-ons · shown in the Sport screen','Sport catalogs','Add-ons with sport catalogs (sports add-ons, AIOMetadata sport catalogs) appear here.')}


def role_addons(role):
    """7.0.20: every add-on offering subtitles or sport, switched on its own
    (the same switches as the add-on's own page)."""
    title,detail,empty=ROLE_PAGES[role]
    module=_role_modules()[role]
    def build():
        rows=[(p['id'],page.item(p.get('name') or p['id'],detail,enabled=on)) for p,on in module.entries()]
        return rows or [('none',page.item(empty))]
    def act(provider_id):
        if provider_id=='none':return None
        on=dict((p['id'],on) for p,on in module.entries()).get(provider_id)
        if on is not None:module.set_enabled(provider_id,not on)
        settings_cache.invalidate()
        return None
    return _keyed(title,build,act)


def _role_count(role):
    try:rows=_role_modules()[role].entries()
    except Exception:return ''
    return '%d / %d on'%(sum(1 for _,on in rows if on),len(rows))


def _add_and_choose_roles(dialog):
    """Add a manifest, then choose what it is used for (7.0.17)."""
    before={p.get('id') for p in store.list_providers()}
    if not add_manifest(dialog):return False
    for p in store.list_providers():
        if p.get('id') not in before:addon_roles(p['id'])
    return True


def addons():
    """Add-ons (translucent page, 7.0): which add-ons are used, adding and importing them."""
    from resources.lib import stream_providers, metadata_providers
    dialog=xbmcgui.Dialog()
    def build():
        metadata=metadata_providers.entries();providers=stream_providers.entries()
        return [('yours',page.item('Your add-ons · streams, metadata, subtitles, sport','%d add-ons'%len(store.list_providers()))),
                ('meta',page.item('Metadata add-ons','%d / %d on'%(sum(1 for _,on in metadata if on),len(metadata)))),
                ('streams',page.item('Stream add-ons','%d / %d on'%(sum(1 for _,on in providers if on),len(providers)))),
                ('subtitles',page.item('Subtitle add-ons',_role_count('subtitles'))),
                ('sport',page.item('Sport add-ons',_role_count('sport'))),
                ('add',page.item('Add a configured add-on link')),
                ('nuvio',page.item('Import add-ons from Nuvio',nuvio_status())),
                ('stremio',page.item('Import add-ons from Stremio (beta)')),
                ('debrid',page.item('TorBox & Premiumize · streams without an add-on',_debrid_status())),
                ('remove',page.item('Remove an add-on')),
                ('refresh',page.item('Refresh add-on catalogs now'))]
    def act(key):
        if key=='yours':return your_addons()
        if key=='meta':select_provider('metadata')
        elif key=='streams':stream_addons()
        elif key in ('subtitles','sport'):return role_addons(key)
        elif key=='debrid':return debrid_page()
        elif key=='add':_add_and_choose_roles(dialog)
        elif key=='nuvio':sync_nuvio()
        elif key=='stremio':
            from .keys_backup import stremio
            stremio()
        elif key=='refresh':
            # 6.0.36: catalogs added in an add-on's configuration (e.g. streaming
            # services in AIOMetadata / Xperience) appear without re-adding it.
            from resources.lib import manifest_refresh
            from .playback import job
            changed=job(manifest_refresh.refresh_all,label='Reading the add-ons\' catalogs')
            if changed is not None:
                dialog.ok('Add-ons','Updated: %s.'%', '.join(changed) if changed else 'All add-ons were already up to date.')
        elif key=='remove':
            providers=store.list_providers()
            i=dialog.select('Remove an add-on',[p.get('name') or p['id'] for p in providers])
            if i>=0 and dialog.yesno('Remove an add-on','Remove this add-on from MegaNexus?'):
                store.remove_provider(providers[i]['id'])
                for role in ('metadata','streams'):
                    if ADDON.getSetting('meganexus_'+role+'_provider')==providers[i]['id']:ADDON.setSetting('meganexus_'+role+'_provider','')
        settings_cache.invalidate()
        return None
    return _keyed('Add-ons',build,act)


def sync_nuvio():
    from resources.lib.meganexus import nuvio_stremio_sync as sync
    from .playback import job
    if not sync.Nuvio.is_linked():xbmcgui.Dialog().ok('Nuvio account','Sign in to Nuvio in Account first.');return
    if not sync.Nuvio.token().get('profile_index') and not choose_nuvio_profile():return False
    from resources.lib import nuvio_import
    result=job(nuvio_import.fetch,label='Importing Nuvio - '+nuvio_status())
    if result is None:return False
    report=nuvio_import.apply(result)
    settings_cache.invalidate()
    message='%d add-ons saved. Home layout kept. Import and validate your collections in Settings > Collections before browsing.'%report['providers']
    if not report['providers']:message+=' No add-ons imported; check your selected profile.'
    if report['errors']:message+='\n'+'\n'.join(dict.fromkeys(report['errors']))
    xbmcgui.Dialog().ok('Nuvio import - '+nuvio_status(),message)
    return bool(report['providers'] or report['collections']) and not report['errors']


def nuvio_status():
    from resources.lib.meganexus import nuvio_stremio_sync as sync
    token=sync.Nuvio.token()
    if not token.get('access_token'):return 'Not connected'
    return 'Connected / '+str(token.get('profile_name') or ('Profile '+str(token['profile_index']) if token.get('profile_index') else 'Choose profile'))


def choose_nuvio_profile():
    from resources.lib.meganexus import nuvio_stremio_sync as sync
    from .playback import job
    profiles=job(sync.Nuvio.profiles,label='Loading Nuvio profiles')
    if not profiles:return False
    pick=0 if len(profiles)==1 else xbmcgui.Dialog().select('Choose the Nuvio profile with your collections',[p['profile_name'] for p in profiles])
    if pick<0:return False
    sync.Nuvio.select_profile(profiles[pick])
    return True

def sign_in_nuvio():
    from resources.lib.meganexus import nuvio_stremio_sync as sync
    dialog=xbmcgui.Dialog()
    email=dialog.input('Nuvio email').strip()
    if not email:return False
    password=dialog.input('Nuvio password',option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not password:return False
    from .playback import job
    try:token=job(lambda:sync.Nuvio.authenticate(email,password),label='Signing in to Nuvio')
    except Exception:token=None
    if not token:
        dialog.ok('Nuvio account','Sign-in did not complete. Check your account and connection, or skip and connect later.')
        return False
    sync.Nuvio.save_token(token)
    ADDON.setSetting('nuvio_sync_enabled','true')
    settings_cache.invalidate()
    if not choose_nuvio_profile():return False
    import_from_nuvio()  # 6.0.25: connecting imports everything; no extra steps
    return True


def import_from_nuvio():
    """Connected account: add-ons, progress and the profile's collections, with
    the metadata add-ons those collections use switched ON, so Home loads at once.
    A Home layout the user made is replaced only after a yes."""
    from resources.lib import nuvio_import
    from .playback import job
    dialog=xbmcgui.Dialog()
    collections=True
    if nuvio_import.layout_is_users_own():
        collections=dialog.yesno('Nuvio account','Replace your current Home layout with the collections of your Nuvio profile?')
    result=job(lambda:nuvio_import.fetch(collections=collections),label='Importing your Nuvio add-ons and collections')
    if result is None:return False
    report=nuvio_import.apply(result)
    settings_cache.invalidate()
    try:
        from .browse_meta import clear
        clear()
    except Exception:pass
    lines=['%d add-ons imported.'%report['providers']]
    if report.get('collections'):lines.append('%d collections are on Home.'%report['collections'])
    if report.get('metadata_on'):lines.append('Metadata switched ON: '+', '.join(report['metadata_on'])+'.')
    if report['errors']:lines.append('\n'.join(dict.fromkeys(report['errors'])))
    dialog.ok('Nuvio account - '+nuvio_status(),'\n'.join(lines))
    return bool(report['providers'] or report.get('collections')) and not report['errors']


def accounts():
    from resources.lib.meganexus import nuvio_stremio_sync as sync
    def rows():return [page.item('Sign in',nuvio_status()),page.item('Sign in with phone · QR code'),page.item('Sync add-ons and progress','Keep Home layout'),page.item('Sign out'),page.item('Choose Nuvio profile',sync.Nuvio.token().get('profile_name') or ''),page.item('Continue Watching sync', (ADDON.getSetting('nuvio_progress_interval') or '60')+' seconds'),page.item('Back')]
    def choose(pick):
        if pick==0:sign_in_nuvio()
        elif pick==1:phone_setup()
        elif pick==2:sync_nuvio()
        elif pick==3:sync.Nuvio.clear();ADDON.setSetting('nuvio_sync_enabled','false')
        elif pick==4:choose_nuvio_profile()
        elif pick==5:progress_settings()
        elif pick==6:return page.DONE
    return page.show('Nuvio account',rows,choose)

def progress_settings():
    dialog=xbmcgui.Dialog()
    def build():return [('interval',page.item('Refresh interval (Nuvio + Simkl)',(ADDON.getSetting('nuvio_progress_interval') or '60')+' seconds')),
                        ('direction',page.item('Nuvio sync direction',ADDON.getSetting('nuvio_sync_direction') or 'Two-way'))]
    def act(key):
        if key=='interval':
            values=['30','60','120','300']
            current=ADDON.getSetting('nuvio_progress_interval') or '60'
            selected=dialog.select('Refresh in seconds · retries respect server limits', values, preselect=values.index(current) if current in values else 1)
            if selected>=0:ADDON.setSetting('nuvio_progress_interval',values[selected])
        else:
            values=['Two-way','Upload only','Download only']
            current=ADDON.getSetting('nuvio_sync_direction') or 'Two-way'
            selected=dialog.select('Nuvio progress direction',values,preselect=values.index(current) if current in values else 0)
            if selected>=0:ADDON.setSetting('nuvio_sync_direction',values[selected])
        settings_cache.invalidate()
        return None
    return _keyed('Continue Watching sync',build,act)


def collections():
    from .collection_editor import run
    return run()


def import_nuvio_collections():
    from resources.lib.meganexus import nuvio_stremio_sync as sync
    from .playback import job
    dialog=xbmcgui.Dialog()
    if not sync.Nuvio.is_linked():dialog.ok('Collections','Connect a Nuvio account first.');return False
    if not sync.Nuvio.token().get('profile_index') and not choose_nuvio_profile():return False
    if not dialog.yesno('Import collection layout','Replace Home collection titles, pictures and order with the selected Nuvio profile? Sports stay in the Sport screen.'):return False
    data=job(lambda:sync.Nuvio.sync_collections([],direction='pull'),label='Importing collection layout')
    if data is None:return False
    return commit_collections(data)


def _switch_on_collection_addons(groups, dialog):
    """Collections reference catalogs of metadata add-ons that are OFF: ask once."""
    from resources.lib import collection_validation, metadata_providers
    from resources.lib.collections_home import matching_catalog
    providers = store.list_providers()
    switches = {p['id']: on for p, on in metadata_providers.entries(providers)}
    off = {}
    for _, source in collection_validation.sources(groups):
        match = matching_catalog(source, providers)
        if match and switches.get(match[0]['id']) is False:
            off[match[0]['id']] = match[0].get('name') or match[0]['id']
    if not off:
        return False
    if not dialog.yesno('Collections', 'These collections use add-ons that are OFF under Metadata add-ons:\n'
                        + ', '.join(off.values()) + '\nTurn them ON?'):
        return False
    for provider_id in off:
        metadata_providers.set_enabled(provider_id, True)
    settings_cache.invalidate()
    return True


def commit_collections(data, force=False):
    """Save the Home layout at once - no network check, nothing blocks (6.0.15).

    ``force`` additionally runs the catalog check and shows its report; an
    unavailable catalog is only reported, never a reason to refuse the layout.
    """
    dialog = xbmcgui.Dialog()
    groups = collection_profile.normalize(data)
    _switch_on_collection_addons(groups, dialog)
    count = collection_profile.save(groups)
    if force:
        from resources.lib import collection_validation
        from .playback import job
        import threading
        cancel = threading.Event()
        proof = job(lambda: collection_validation.validate(groups, stopped=cancel.is_set),
                    label='Checking collection catalogs', cancel=cancel)
        if proof is not None:
            collection_profile.save(groups, validation=proof)
            dialog.ok('Collection check', collection_validation.message(proof))
    else:
        dialog.notification('Collections', '%d collections saved' % count)
    return True


def toggle(key):ADDON.setSetting(key,'false' if ADDON.getSetting(key)=='true' else 'true')
def onoff(key):return 'On' if ADDON.getSetting(key)=='true' else 'Off'

def playback():
    dialog=xbmcgui.Dialog()
    def rows():return [page.item('Autoplay the best stream',enabled=ADDON.getSetting('meganexus_autoplay')=='true'),
        # 7.0.32: AIOStreams' rules - a film only in cinemas, an episode not aired yet
        page.item('Digital release filter · no cinema copies or unaired episodes',enabled=ADDON.getSetting('meganexus_digital_release_filter')=='true'),
        page.item(LAST_LINK_TITLE,last_link_summary()),
        page.item('Automatic stream choice',_stream_choice_summary()),
        page.item('Intro, credits & next episode',_skip_summary()),page.item('Back')]
    def choose(pick):
        if pick==0:toggle('meganexus_autoplay')
        elif pick==1:toggle('meganexus_digital_release_filter')
        elif pick==2:choose_last_link()
        elif pick==3:return stream_choice_page()
        elif pick==4:return skip_settings()
        elif pick==5:return page.DONE
    return page.show('Playback',rows,choose)


SKIP_MODES=(('Button','Show the Skip button'),('Automatic','Skip automatically'),('Off','Off'))


def _skip_summary():
    from resources.lib import skip_segments as seg
    mode=dict(SKIP_MODES).get(ADDON.getSetting('meganexus_skip_mode') or 'Button','Show the Skip button')
    return mode+(' · next episode from %d %%'%seg.watched_percent(ADDON) if seg.upnext_on(ADDON) else '')


def skip_settings():
    """7.0.29: intro / recap / credits from TheIntroDB, the media server's markers and
    the file's chapters; "Next episode" beside "Skip outro" at the credits - and, with
    no known credits, from the point an episode counts as watched."""
    from resources.lib import skip_segments as seg
    def build():
        mode=ADDON.getSetting('meganexus_skip_mode') or 'Button'
        return [('mode',page.item('Intro, recap and credits',dict(SKIP_MODES).get(mode,'Show the Skip button'))),
                ('upnext',page.item('Next episode when the credits are unknown · from the watched point',enabled=seg.upnext_on(ADDON))),
                ('watched',page.item('An episode counts as watched at','%d %% · also for Simkl'%seg.watched_percent(ADDON))),
                ('chapters',page.item("Use the file's chapters (Intro, Credits)",enabled=seg.chapters_on(ADDON))),
                ('sources',page.item('Where the times come from','TheIntroDB · Plex / Jellyfin / Emby · chapters'))]
    def act(key):
        if key=='mode':
            rows=[(value,page.item(label,'Chosen' if value==(ADDON.getSetting('meganexus_skip_mode') or 'Button') else '')) for value,label in SKIP_MODES]
            def pick(value):ADDON.setSetting('meganexus_skip_mode',value);return page.DONE
            return page.keyed('Intro, recap and credits',lambda:rows,pick)
        if key=='upnext':ADDON.setSetting(seg.UPNEXT,'off' if seg.upnext_on(ADDON) else 'watched')
        elif key=='chapters':ADDON.setSetting(seg.CHAPTERS,'false' if seg.chapters_on(ADDON) else 'true')
        elif key=='watched':
            rows=[(value,page.item(value+' %','Chosen' if int(value)==int(seg.watched_percent(ADDON)) else '')) for value in seg.WATCHED_CHOICES]
            def pick(value):ADDON.setSetting(seg.WATCHED,value);return page.DONE
            return page.keyed('An episode counts as watched at',lambda:rows,pick)
        elif key=='sources':api_keys()
        settings_cache.invalidate()
        return None
    return _keyed('Intro, credits & next episode',build,act)


# 7.0.29: where people look for it (Playback), and in Continue Watching too.
LAST_LINK_TITLE='Continue Watching · start with the last link'


def last_link_summary():
    from resources.lib import last_source
    hours=str(last_source.hours(ADDON))
    return 'Off · choose again' if hours=='0' else '%s · with or without choosing a source'%last_source.LABELS[hours]


def choose_last_link():
    """A title started from Continue Watching plays the link it played last time
    (with or without choosing a source) for 12 or 24 hours; then, or when the link
    fails, the usual source choice or autoplay."""
    from resources.lib import last_source
    keys=last_source.HOURS;value=str(last_source.hours(ADDON))
    labels={'0':'Off · always choose again','12':'12 hours','24':'24 hours'}
    pick=xbmcgui.Dialog().select(LAST_LINK_TITLE,[labels[k] for k in keys],preselect=keys.index(value))
    if pick>=0:ADDON.setSetting(last_source.SETTING,keys[pick]);settings_cache.invalidate()


def _gb_label(value,unit='movie'):
    return 'No limit' if value in ('','0') else ('Up to %s GB'%value)


def _stream_choice_summary():
    from resources.lib import stream_choice as sc
    prefs=sc.preferences(ADDON)
    if not prefs['sort']:return 'Add-on order'
    parts=[sc.RES_LABELS.get(ADDON.getSetting(sc.MAX_RES) or '4k','Up to 4K')]
    if prefs['movie_gb']:parts.append('films ≤ %g GB'%prefs['movie_gb'])
    if prefs['episode_gb']:parts.append('episodes ≤ %g GB'%prefs['episode_gb'])
    return ' · '.join(parts)


AUDIO_SETTING='locale.audiolanguage'


def _audio_languages():
    """Kodi's own audio language choices: [(value, label)], its current value."""
    data=rpc('Settings.GetSettings',{'level':'expert','filter':{'section':'player','category':'language'}}) or {}
    setting=next((row for row in data.get('settings') or [] if row.get('id')==AUDIO_SETTING),{})
    options=[(str(row.get('value')),str(row.get('label') or row.get('value'))) for row in setting.get('options') or []]
    return options,str(setting.get('value') or '')


def _audio_label():
    try:
        options,current=_audio_languages()
    except Exception:
        return ''
    return dict(options).get(current,current)


def _choose_audio_language(dialog):
    """7.0.21: the preferred audio language is Kodi's own (Settings > Player >
    Language): Kodi picks that track when the video opens - no switch once it
    plays. The choice is made here, with Kodi's list."""
    try:options,current=_audio_languages()
    except Exception:options,current=[],''
    if not options:
        dialog.ok('Preferred audio language','Kodi did not return its audio languages. Please try again.');return
    values=[value for value,_ in options]
    i=dialog.select('Preferred audio language',[label for _,label in options],preselect=values.index(current) if current in values else 0)
    if i>=0:
        rpc('Settings.SetSettingValue',{'setting':AUDIO_SETTING,'value':values[i]})
        # "Prefer default stream" would keep a file's default (often original)
        # track over the chosen language; Media default keeps Kodi's behaviour.
        if values[i]!='mediadefault':rpc('Settings.SetSettingValue',{'setting':'videoplayer.preferdefaultflag','value':False})


def stream_choice_page():
    """Automatic stream choice (7.0.12): the order of the source list and the
    stream Autoplay starts - resolution, size per film / episode, Dolby Vision,
    HDR and cached debrid results. Rows outside the limits move down, never away."""
    from resources.lib import stream_choice as sc
    dialog=xbmcgui.Dialog()
    def pick(title,setting,choices,labels,default):
        current=ADDON.getSetting(setting) or default
        i=dialog.select(title,[labels(c) for c in choices],preselect=choices.index(current) if current in choices else 0)
        if i>=0:ADDON.setSetting(setting,choices[i]);settings_cache.invalidate()
    def build():
        prefs=sc.preferences(ADDON)
        rows=[('sort',page.item('Choose the best stream for me',enabled=prefs['sort'])),
              ('audio',page.item('Preferred audio language',_audio_label()))]
        if prefs['sort']:
            rows+=[('res',page.item('Highest resolution',sc.RES_LABELS.get(ADDON.getSetting(sc.MAX_RES) or '4k','Up to 4K'))),
                   ('movie',page.item('Largest film',_gb_label(ADDON.getSetting(sc.MOVIE_GB) or '0'))),
                   ('episode',page.item('Largest episode',_gb_label(ADDON.getSetting(sc.EPISODE_GB) or '0'))),
                   ('dv',page.item('Dolby Vision',sc.DV_LABELS.get(prefs['dv'],'No preference'))),
                   ('hdr',page.item('HDR',sc.HDR_LABELS.get(prefs['hdr'],'Prefer HDR'))),
                   ('cached',page.item('Debrid: cached (instant) results first',enabled=prefs['cached']))]
        return rows
    def act(key):
        if key=='sort':ADDON.setSetting(sc.SORT,'false' if sc.preferences(ADDON)['sort'] else 'true')
        elif key=='res':pick('Highest resolution',sc.MAX_RES,sc.RES_CHOICES,lambda c:sc.RES_LABELS[c],'4k')
        elif key=='movie':pick('Largest film',sc.MOVIE_GB,sc.MOVIE_GB_CHOICES,_gb_label,'0')
        elif key=='episode':pick('Largest episode',sc.EPISODE_GB,sc.EPISODE_GB_CHOICES,_gb_label,'0')
        elif key=='dv':pick('Dolby Vision',sc.DOLBY_VISION,sc.DV_CHOICES,lambda c:sc.DV_LABELS[c],'neutral')
        elif key=='hdr':pick('HDR',sc.HDR,sc.HDR_CHOICES,lambda c:sc.HDR_LABELS[c],'prefer')
        elif key=='cached':ADDON.setSetting(sc.CACHED,'false' if sc.preferences(ADDON)['cached'] else 'true')
        elif key=='audio':_choose_audio_language(dialog)
        settings_cache.invalidate()
        return None
    return _keyed('Automatic stream choice',build,act)


def sport_settings():
    """Sport screen (6.0.35): which player live events use."""
    from . import sports
    def rows():return [page.item('Player',sports.PLAYER_LABELS[sports.player_mode()]),
        page.item('Play live events after resting 5 seconds',enabled=sports.autoplay_enabled()),
        page.item('Back')]
    def choose(pick):
        if pick==0:
            keys=['small','big'];current=sports.player_mode()
            i=xbmcgui.Dialog().select('Sport player',[sports.PLAYER_LABELS[k] for k in keys],preselect=keys.index(current))
            if i>=0:ADDON.setSetting(sports.PLAYER_SETTING,keys[i])
        elif pick==1:ADDON.setSetting(sports.AUTOPLAY_SETTING,'false' if sports.autoplay_enabled() else 'true')
        elif pick==2:return page.DONE
        settings_cache.invalidate()
    return page.show('Sport',rows,choose)


def trailers():
    from resources.lib import imdb_trailers
    dialog=xbmcgui.Dialog()
    def rows():return [page.item('Automatic trailers',enabled=ADDON.getSetting('meganexus_auto_trailers')=='true'),
        page.item('Trailer focus delay',(ADDON.getSetting('meganexus_trailer_delay') or '6')+' seconds'),
        page.item('Trailer duration',('Full trailer' if ADDON.getSetting('meganexus_trailer_duration')=='0' else (ADDON.getSetting('meganexus_trailer_duration') or '90')+' seconds')),
        page.item('Trailer source',imdb_trailers.LABELS[imdb_trailers.source_setting(ADDON)]),
        page.item('IMDb trailer quality · no add-on needed',imdb_trailers.QUALITY_LABELS[imdb_trailers.quality_setting(ADDON)]),
        page.item('YouTube add-on','Configure' if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)') else 'Install (only for YouTube trailers)'),page.item('Back')]
    def choose(pick):
        if pick==0:toggle('meganexus_auto_trailers')
        elif pick in (1,2):
            values=[3,5,6,8,10,15,20,30] if pick==1 else [15,20,30,45,60,90,120,0]
            key='meganexus_trailer_delay' if pick==1 else 'meganexus_trailer_duration'
            current=ADDON.getSetting(key) or ('6' if pick==1 else '90');labels=[str(v) for v in values]
            i=dialog.select('Trailer length' if pick==2 else 'Seconds', ['Full trailer' if v=='0' else v+' seconds' for v in labels],preselect=labels.index(current) if current in labels else 0)
            if i>=0:ADDON.setSetting(key,labels[i])
        elif pick==3:
            keys=list(imdb_trailers.SOURCES);current=imdb_trailers.source_setting(ADDON)
            i=dialog.select('Trailer source',[imdb_trailers.LABELS[k]+(' · default' if k==imdb_trailers.DEFAULT_SOURCE else '') for k in keys],
                            preselect=keys.index(current))
            if i>=0:ADDON.setSetting(imdb_trailers.SETTING,keys[i])
        elif pick==4:
            keys=['480','720','1080'];current=imdb_trailers.quality_setting(ADDON)
            i=dialog.select('IMDb trailer quality',[imdb_trailers.QUALITY_LABELS[k] for k in keys],preselect=keys.index(current))
            if i>=0:ADDON.setSetting(imdb_trailers.QUALITY_SETTING,keys[i])
        elif pick==5:
            if ensure_addon('plugin.video.youtube'):xbmcaddon.Addon('plugin.video.youtube').openSettings()
        elif pick==6:return page.DONE
    return page.show('Trailers',rows,choose)


_KEPT=[0.,'']


def cache_usage():
    """7.0.30: the posters Kodi keeps on the device (they survive restarts) and
    MegaNexus's image memory. The memory alone read '0 images' after every
    restart although Kodi had all posters."""
    import time
    memory=xbmcgui.Window(10000).getProperty('meganexus.art_cache.usage') or 'Starting'
    now=time.monotonic()
    if now-_KEPT[0]>10:
        from . import kodi_textures, precache
        proxy=precache.base()
        _KEPT[:]=[now,'%d pictures kept by Kodi'%kodi_textures.count(proxy) if proxy else '']   # 7.0.32: backgrounds and logos too
    return '  ·  '.join(part for part in (_KEPT[1],'memory '+memory) if part)


def clear_cache():
    """Catalog pages, titles' details, the day's ratings, the image memory and
    (7.0.32) Kodi's own copies of MegaNexus pictures - they stayed, 3000+ on a
    box, also from earlier proxy ports. The pictures are prepared again when
    Settings closes."""
    from . import browse_meta, kodi_textures, precache
    from resources.lib import mdblist
    browse_meta.clear(persistent=True)
    mdblist.clear_ratings()   # 7.0.30: the day's ratings too
    xbmc.executebuiltin('NotifyAll(meganexus,artcache.clear)')
    ids=kodi_textures.ours()
    removed=0
    if ids:
        dialog=xbmcgui.DialogProgress()
        dialog.create('Clear MegaNexus images and metadata cache','Removing the pictures Kodi keeps for MegaNexus...')
        def progress(done,total):
            if done%25==0:
                dialog.update(done*100//total,'Removing the pictures Kodi keeps for MegaNexus...[CR]%d / %d'%(done,total))
            return dialog.iscanceled()
        try:removed=kodi_textures.remove(ids,progress)
        finally:dialog.close()
    precache.forget()
    _KEPT[0]=0.
    xbmcgui.Window(10000).setProperty('meganexus.prepare.requested','1')
    xbmc.log('[MegaNexus] cache cleared: %d of %d pictures removed from Kodi'%(removed,len(ids)),xbmc.LOGINFO)
    xbmcgui.Dialog().notification('MegaNexus','Cache cleared · %d pictures removed · prepared again when you leave Settings'%removed,time=5000)


def performance():
    from resources.lib.art_cache import selected_mode
    from resources.lib import ram_profile
    # 7.0.3: three memory presets; 256 MiB is the default.
    keys=list(ram_profile.PRESETS)
    labels=[ram_profile.LABELS[k] for k in keys]
    other={'disk246':'Images on internal disk · 246 MiB','disk512':'Images on internal disk · 512 MiB','off':'Images off · Kodi texture cache only'}
    def rows():
        mode=selected_mode(ADDON)
        label=ram_profile.LABELS.get(mode) or other.get(mode,mode)
        precache=ADDON.getSetting('meganexus_poster_precache')!='false'
        return [page.item('Memory for posters and catalogs',label),
            page.item('Prepare posters, artwork and ratings when MegaNexus opens',
                      'On · about 30 KB per poster on the device' if precache else 'Off'),
            dict(page.item('Cache usage',cache_usage()),kind='info'),
            page.item('Clear MegaNexus images and metadata cache'),page.item('Back')]
    def choose(pick):
        if pick==0:
            mode=selected_mode(ADDON)
            index=xbmcgui.Dialog().select('Memory for posters and catalogs',labels,preselect=keys.index(mode) if mode in keys else 1)
            if index>=0:
                ADDON.setSetting('meganexus_art_cache',keys[index]);xbmc.executebuiltin('NotifyAll(meganexus,artcache.configure)')
        elif pick==1:
            # 7.0.8: Kodi stores the first posters of every collection while Home is idle.
            ADDON.setSetting('meganexus_poster_precache','false' if ADDON.getSetting('meganexus_poster_precache')!='false' else 'true')
            if ADDON.getSetting('meganexus_poster_precache')=='false':xbmcgui.Window(10000).clearProperty('meganexus.precache.ring')
        elif pick==2:
            _KEPT[0]=0.   # 7.0.30: Select counts again
        elif pick==3:
            clear_cache()
        elif pick==4:return page.DONE
    return page.show('Performance & image cache',rows,choose)


def screensaver_label():
    from .saver import ANIMATED,saver_mode
    kind=saver_mode(ADDON)
    if kind==ANIMATED:return 'MegaNexus animated'
    if kind=='video':return 'Custom video'
    if kind=='slideshow':return 'Slideshow · pictures from a folder'
    return 'Custom image / GIF' if ADDON.getSetting('meganexus_screensaver_art') else 'MegaNexus image'


def screensaver_media():
    from .saver import ANIMATED,saver_mode
    def current():
        kind=saver_mode(ADDON)
        if kind==ANIMATED:return 1
        if kind=='video':return 3
        if kind=='slideshow':return 4
        return 2 if ADDON.getSetting('meganexus_screensaver_art') else 0
    def rows():
        selected=current()
        return [page.item(label,'Selected' if selected==i else '') for i,label in enumerate((
                    'MegaNexus · standard image','MegaNexus · animated',
                    'Custom image / animated GIF','Custom video · MP4, MKV, WebM, MOV',
                    'Slideshow · pictures from a folder'))]+[page.item('Back')]
    def choose(pick):
        if pick==5:return page.DONE
        if pick==4:
            # 7.0.24: every picture of a folder (local or network), cross-faded.
            folder=xbmcgui.Dialog().browseSingle(0,'Choose a folder with pictures','files')
            if folder:
                ADDON.setSetting('meganexus_screensaver_folder',folder)
                ADDON.setSetting('meganexus_screensaver_type','slideshow')
            settings_cache.invalidate()
            return None
        if pick==0:
            ADDON.setSetting('meganexus_screensaver_type','image')
            ADDON.setSetting('meganexus_screensaver_art','');ADDON.setSetting('meganexus_screensaver_video','')
        elif pick==1:
            ADDON.setSetting('meganexus_screensaver_art','');ADDON.setSetting('meganexus_screensaver_video','')
            ADDON.setSetting('meganexus_screensaver_type',ANIMATED)
        else:
            video=pick==3
            mask='.mp4|.m4v|.mkv|.webm|.mov|.avi|.ts|.m2ts' if video else '.png|.jpg|.jpeg|.webp|.gif'
            path=xbmcgui.Dialog().browseSingle(1,'Choose screensaver video' if video else 'Choose image / animated GIF','files',mask)
            if path:
                ADDON.setSetting('meganexus_screensaver_video' if video else 'meganexus_screensaver_art',path)
                ADDON.setSetting('meganexus_screensaver_type','video' if video else 'image')
                if video:prepare_saver_loop(path)
        settings_cache.invalidate()
    try:return page.show('Screensaver media · videos loop silently; paused media keeps artwork',rows,choose)
    finally:
        from resources.lib import wallpaper
        wallpaper.sync(ADDON)    # 7.0.28: a wallpaper "same as the screensaver" follows


def wallpaper_label():
    from resources.lib import wallpaper
    return wallpaper.label(ADDON)


def choose_wallpaper():
    """Home and HUB wallpaper (7.0.28): off, the screensaver's picture or
    slideshow, one picture, or a folder of pictures."""
    from resources.lib import wallpaper
    keys=wallpaper.MODES
    index=xbmcgui.Dialog().select('Custom theme background',[wallpaper.LABELS[k] for k in keys],
                                  preselect=keys.index(wallpaper.mode(ADDON)))
    if index<0:return None
    choice=keys[index];path=''
    if choice=='picture':
        path=xbmcgui.Dialog().browseSingle(1,'Choose a picture','files','.png|.jpg|.jpeg|.webp')
        if not path:return None
    elif choice=='folder':
        path=xbmcgui.Dialog().browseSingle(0,'Choose a folder with pictures','files')
        if not path:return None
    wallpaper.choose(choice,path,ADDON)
    settings_cache.invalidate()
    return None


def ambient_summary():
    from . import ambient
    return ambient.scene_summary(ambient.load(ADDON))


def ambient_studio():
    """Screensaver studio (7.0.24): the screensaver itself with a side panel -
    per widget a style, a colour and a position, changed live (Left / Right)."""
    from .saver import studio
    studio()
    settings_cache.invalidate()
    return None


SAVER_ID='screensaver.meganexus'
SAVER_MINUTES=(1,2,3,5,10,15,20,30,45,60)


def _kodi_setting(name,default=None):
    return (rpc('Settings.GetSettingValue',{'setting':name}) or {}).get('value',default)


def screensaver_summary():
    if _kodi_setting('screensaver.mode','')!=SAVER_ID:return 'Off'
    return 'After %s min · %s'%(_kodi_setting('screensaver.time',3),ambient_summary())


def _plugin_addon():
    return xbmcaddon.Addon('plugin.video.meganexus')


def _dim_label():
    """7.0.32: the screensaver dimmed by 10-50 % (OLED, a dark room)."""
    from .saver import dim_level
    level=dim_level(_plugin_addon())
    return '%d %%'%level if level else 'Off'


def screensaver_settings():
    """Everything of the screensaver in one place (7.0.24): on / off, when it
    starts (Kodi's idle time), the background, the studio and a preview."""
    def build():
        on=_kodi_setting('screensaver.mode','')==SAVER_ID
        rows=[('on',page.item('MegaNexus screensaver',enabled=on))]
        if not on:return rows
        return rows+[('time',page.item('Starts after','%s min without a key press'%_kodi_setting('screensaver.time',3))),
                     ('media',page.item('Background',screensaver_label())),
                     ('dim',page.item('Dim the screen',_dim_label())),
                     ('studio',page.item('Studio · clock, weather, calendar, text (live)',ambient_summary())),
                     ('preview',page.item('Preview · any key closes it'))]
    def act(key):
        if key=='on':
            on=_kodi_setting('screensaver.mode','')==SAVER_ID
            rpc('Settings.SetSettingValue',{'setting':'screensaver.mode','value':'screensaver.xbmc.builtin.dim' if on else SAVER_ID})
        elif key=='time':
            current=_kodi_setting('screensaver.time',3)
            keys=SAVER_MINUTES if current in SAVER_MINUTES else tuple(sorted(SAVER_MINUTES+(current,)))
            index=xbmcgui.Dialog().select('Start the screensaver after',['%d min'%m for m in keys],
                                          preselect=keys.index(current) if current in keys else 0)
            if index>=0:rpc('Settings.SetSettingValue',{'setting':'screensaver.time','value':keys[index]})
        elif key=='media':screensaver_media()
        elif key=='dim':
            from .saver import DIM_LEVELS,DIM_SETTING,dim_level
            current=dim_level(_plugin_addon())
            index=xbmcgui.Dialog().select('Dim the screensaver',['Off' if v==0 else '%d %%'%v for v in DIM_LEVELS],
                                          preselect=DIM_LEVELS.index(current))
            if index>=0:_plugin_addon().setSetting(DIM_SETTING,str(DIM_LEVELS[index]))
        elif key=='studio':return ambient_studio()
        elif key=='preview':
            from .saver import preview
            preview()
        return None
    return _keyed('Screensaver',build,act)


def prepare_saver_loop(path):
    """Write the seamless silent loop copy now, so the screensaver starts with it."""
    from .saver import prepare_loop,LOOP_EXTENSIONS
    if not path.lower().endswith(LOOP_EXTENSIONS):return
    dialog=xbmcgui.DialogProgress()
    dialog.create('Screensaver video','Preparing a seamless, silent loop…')
    try:
        ready=prepare_loop(path,progress=lambda done:dialog.update(int(done*100)),stopped=dialog.iscanceled)
    finally:
        dialog.close()
    if not ready and not dialog.iscanceled():
        xbmcgui.Dialog().notification('Screensaver video','This clip loops with a short pause (format not supported for seamless looping).',xbmcgui.NOTIFICATION_INFO,5000)


def _keyed(title,build,act):
    return page.keyed(title,build,act)


def appearance():
    def build():
        return [('skin',page.item('Use MegaNexus skin','Active' if xbmc.getSkinDir()=='skin.meganexus' else 'Activate')),
                ('layout',page.item('Layout & cards',home_layout_label())),
                ('content',page.item('Home content & titles')),
                ('artwork',page.item('Artwork · posters, backgrounds and logos',_artwork_summary()))]
    def act(key):
        if key=='skin':return 'meganexus:activate_skin'
        if key=='layout':return layout_cards()
        if key=='artwork':return artwork()
        if key=='content':return _appearance_page('Home content & titles',{'hero','titles','ratings','rowtitles','animated'})
    return _keyed('Home & appearance',build,act)


def _artwork_summary():
    from resources.lib import art_provider
    return art_provider.summary(ADDON)


def artwork():
    """7.0.29: where posters, backgrounds, logos and landscape cards come from -
    the catalog, or TMDB / Fanart.tv with the keys connected in API keys."""
    from resources.lib import art_provider as art
    def label(kind):
        provider=art.choice(kind,ADDON)
        if provider!='catalog' and not art.connected(provider,ADDON):
            return art.PROVIDER_LABELS[provider]+' · connect its API key'
        return art.PROVIDER_LABELS[provider]
    def build():
        rows=[(kind,page.item(art.LABELS[kind],label(kind))) for kind in art.KINDS]
        rows.append(('language',page.item('Language of posters and logos (TMDB, Fanart.tv)',art.LANGUAGE_LABELS[art.language(ADDON)])))
        if not (art.connected('tmdb',ADDON) and art.connected('fanart',ADDON)):
            rows.append(('keys',page.item('Connect TMDB / Fanart.tv','Connections › API keys')))
        return rows
    def act(key):
        if key=='keys':return api_keys()
        if key=='language':
            rows=[(value,page.item(art.LANGUAGE_LABELS[value],'Chosen' if value==art.language(ADDON) else '')) for value in art.LANGUAGES]
            def pick(value):
                ADDON.setSetting(art.LANGUAGE,value);settings_cache.invalidate();return page.DONE
            return page.keyed('Language of posters and logos',lambda:rows,pick)
        if key in art.KINDS:
            return _artwork_provider(key)
        return None
    return _keyed('Artwork',build,act)


def _artwork_provider(kind):
    from resources.lib import art_provider as art
    notes={'catalog':'What the metadata add-on supplies','tmdb':'TMDB pictures, many languages',
           'fanart':'Fanart.tv pictures, made by fans'}
    if kind=='landscape':
        notes.update(tmdb='TMDB backgrounds',fanart='Fanart.tv thumbs with the title on them')
    def build():
        current=art.choice(kind,ADDON);rows=[]
        for provider in art.PROVIDERS:
            if art.connected(provider,ADDON):value='Chosen' if provider==current else notes[provider]
            else:value='Connect its API key first'
            rows.append((provider,page.item(art.PROVIDER_LABELS[provider],value)))
        return rows
    def act(provider):
        if not art.connected(provider,ADDON):
            xbmcgui.Dialog().notification('Artwork','Add the %s API key in Connections › API keys.'%art.PROVIDER_LABELS[provider],time=4000)
            return api_keys()
        ADDON.setSetting(art.SETTINGS[kind],provider);settings_cache.invalidate()
        return page.DONE
    return _keyed(art.LABELS[kind],build,act)


def layout_cards():
    return _appearance_page('Layout & cards',{'layout','cards','opacity'})


def clock_weather():
    return _appearance_page('Clock & weather',{'clock','weather'})


def _appearance_page(title, allowed):
    """Shared actions filtered into layout, content and clock categories."""
    from . import system_setup
    dialog=xbmcgui.Dialog()
    from resources.lib import presentation_settings
    presentation_settings.sync()
    def build():
        from resources.lib import theme
        rows=[
            ('layout',page.item('Home layout',home_layout_label())),
            ('cards',page.item('Movie and series cards','Landscape' if ADDON.getSetting('meganexus_card_shape')=='landscape' else 'Portrait posters')),
            ('opacity',page.item('Poster and catalog transparency',theme.OPACITY_LABELS[theme.card_opacity(ADDON)])),
            ('hero',page.item('Home hero and description',enabled=not xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)'))),
            ('titles',page.item('Card titles',enabled=not xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidetitles)'))),
            ('ratings',page.item('Ratings under the title (when the metadata add-on supplies them)',enabled=ADDON.getSetting('meganexus_show_ratings')!='false')),
            ('rowtitles',page.item('Row titles of collections and catalogs (each row: Collections › Home rows)',enabled=ADDON.getSetting('meganexus_row_titles')!='false')),
            ('animated',page.item('Animated collection art and GIFs (focused card)',enabled=ADDON.getSetting('meganexus_animated_art')=='true')),
            ('clock',page.item('Weather and clock · all MegaNexus screens',enabled=not presentation_settings.hidden())),
            ('weather',page.item('Weather location / provider',xbmc.getInfoLabel('Weather.Location') or 'Not configured')),
            ]
        return [(key,row) for key,row in rows if key in allowed]
    def act(key):
        if key=='layout':return choose_home_layout()
        if key=='opacity':return choose_card_opacity()
        if key=='cards':
            pick=dialog.select('Movie and series cards',['Portrait posters','Landscape'],preselect=1 if ADDON.getSetting('meganexus_card_shape')=='landscape' else 0)
            if pick>=0:ADDON.setSetting('meganexus_card_shape',('poster','landscape')[pick])
        elif key in ('hero','titles'):xbmc.executebuiltin('Skin.ToggleSetting(%s)'%{'hero':'meganexus.hidehero','titles':'meganexus.hidetitles'}[key],True)
        elif key=='ratings':
            ADDON.setSetting('meganexus_show_ratings','false' if ADDON.getSetting('meganexus_show_ratings')!='false' else 'true')
            from .browse_meta import clear
            clear()
        elif key=='animated':toggle('meganexus_animated_art')
        elif key=='rowtitles':ADDON.setSetting('meganexus_row_titles','false' if ADDON.getSetting('meganexus_row_titles')!='false' else 'true')
        elif key=='clock':presentation_settings.set_hidden(not presentation_settings.hidden())
        elif key=='weather':system_setup.weather()

        return None
    return _keyed(title,build,act)

def theme_summary():
    from resources.lib import theme, wallpaper, interface_colors as colors
    if wallpaper.resolve(ADDON)[0]:
        return 'Custom theme · %s · %d %%'%(colors.LABELS[colors.options(ADDON)[1]],colors.options(ADDON)[2])
    return theme.LABELS[theme.current(ADDON)]


def themes_screensaver():
    from resources.lib import wallpaper
    def build():
        rows=[('theme',page.item('Theme',theme_summary())),
              ('wallpaper',page.item('Wallpaper · Home, catalogs, Live TV, Sport and the HUB',wallpaper_label()))]
        rows.append(('colours',page.item('Interface colours','Your own colours · 5 variations · strength')))
        return rows+[('screensaver',page.item('Screensaver · on / off, start, background, clock and widgets',screensaver_summary())),
                     ('clock',page.item('Clock & weather · all interfaces')),
                     ('experimental',page.item('Experimental video wallpaper','Pauses for trailers and playback',enabled=ADDON.getSetting('meganexus_wallpaper_video')=='true'))]
    def act(key):
        if key=='theme':return choose_theme()
        if key=='wallpaper':return choose_wallpaper()
        if key=='colours':return custom_theme_colours()
        if key=='screensaver':return screensaver_settings()
        if key=='clock':return clock_weather()
        if key=='experimental':return experimental_appearance()
    return _keyed('Themes & screensaver',build,act)


def experimental_appearance():
    from resources.lib import wallpaper
    def build():return [('video',page.item('Video wallpaper · pause for trailers, Sport, IPTV and films',enabled=ADDON.getSetting('meganexus_wallpaper_video')=='true'))]
    def act(key):
        if ADDON.getSetting('meganexus_wallpaper_video')!='true':
            from .saver import video_file
            if not video_file(ADDON):
                xbmcgui.Dialog().notification('Video wallpaper','Choose a video in Screensaver first.',time=4000)
                return None
            wallpaper.choose('saver',addon=ADDON)
        toggle('meganexus_wallpaper_video')
    return _keyed('Experimental features',build,act)


def custom_theme_colours():
    from resources.lib import interface_colors as colors
    def build():
        own=colors.own_colours(ADDON);live=colors.publish(ADDON)
        rows=[('follow',page.item('Match interface colours to the background',enabled=colors.options(ADDON)[0])),
              ('tone',page.item('Background colour variation',colors.LABELS[colors.options(ADDON)[1]])),
              ('strength',page.item('Interface colour strength',str(colors.options(ADDON)[2])+' %'))]
        # 7.0.29: a colour of your own for each part, shown as a chip; Automatic keeps the theme's.
        for role in colors.ROLES:
            rows.append((role,page.item(colors.ROLE_LABELS[role],_colour_name(role,own.get(role)),swatch=live[role][2:])))
        if own:rows.append(('reset',page.item('Back to the theme colours','All parts Automatic')))
        return rows
    def act(key):
        if key=='follow':
            ADDON.setSetting(colors.FOLLOW,'false' if colors.options(ADDON)[0] else 'true')
            colors.publish(ADDON)
        if key=='tone':
            rows=[(tone,page.item(colors.LABELS[tone])) for tone in colors.TONES]
            def select(tone):
                from resources.lib import wallpaper
                if not wallpaper.resolve(ADDON)[0]:ADDON.setSetting(colors.FOLLOW,'false')
                ADDON.setSetting(colors.TONE,tone);colors.publish(ADDON)
                return page.DONE
            return page.keyed('Background colour variation',lambda:rows,select)
        if key=='strength':
            rows=[(str(i),page.item(str(i)+' %')) for i in sorted(set(range(0,101,10))|{35})]
            def select(value):
                from resources.lib import wallpaper
                if not wallpaper.resolve(ADDON)[0]:ADDON.setSetting(colors.FOLLOW,'false')
                ADDON.setSetting(colors.STRENGTH,value);colors.publish(ADDON)
                return page.DONE
            return page.keyed('Interface colour strength',lambda:rows,select)
        if key in colors.ROLES:return choose_colour(key)
        if key=='reset':
            for role in colors.ROLES:colors.set_own(ADDON,role,'')
            settings_cache.invalidate();colors.publish(ADDON)
        return None
    return _keyed('Interface colours',build,act)


def _colour_name(role,value):
    from resources.lib import interface_colors as colors
    if not value:return 'Automatic'
    return dict(colors.SWATCHES[role]).get(value,'#'+value)


def choose_colour(role):
    """One part's colour: Automatic, the swatches, or any hex. A pick shows at once on
    every screen - this page included - so the list itself is the preview."""
    from resources.lib import interface_colors as colors
    def build():
        current=colors.own_colours(ADDON).get(role,'')
        rows=[('',page.item('Automatic · the theme\'s colour','Chosen' if not current else ''))]
        rows+=[(value,page.item(name,'Chosen' if value==current else '',swatch=value)) for value,name in colors.SWATCHES[role]]
        own=current and current not in dict(colors.SWATCHES[role])
        rows.append(('hex',page.item('Your own colour · hex code','#'+current if own else 'e.g. 5096DC',swatch=current if own else '')))
        return rows
    def act(key):
        if key=='hex':
            key=xbmcgui.Dialog().input('Colour · six hex digits (RRGGBB)',colors.own_colours(ADDON).get(role,'')).strip()
            if not key:return None
        colors.set_own(ADDON,role,key)
        settings_cache.invalidate();colors.publish(ADDON)
        return None
    return _keyed(colors.ROLE_LABELS[role].split(' · ')[0],build,act)


def home_layout_label():
    from resources.lib import collections_home as ch
    return 'Catalog rows' if ch.layout(ADDON)=='rows' else 'MegaNexus collections'


def choose_home_layout():
    """MegaNexus collections (default) or Nuvio-style catalog rows (6.0.35, issue #9)."""
    from resources.lib import collections_home as ch
    keys=list(ch.LAYOUTS);current=ch.layout(ADDON)
    pick=xbmcgui.Dialog().select('Home layout',[ch.LAYOUT_LABELS[k] for k in keys],preselect=keys.index(current))
    if pick>=0 and keys[pick]!=current:
        ADDON.setSetting(ch.LAYOUT_SETTING,keys[pick]);settings_cache.invalidate()
    return None  # Home repaints with the new layout when Settings closes


def choose_theme():
    from resources.lib import theme, wallpaper
    keys=list(theme.THEMES);current=theme.current(ADDON);custom=bool(wallpaper.resolve(ADDON)[0])
    pick=xbmcgui.Dialog().select('Theme',[theme.LABELS[k] for k in keys]+['Custom theme · choose your background'],preselect=3 if custom else keys.index(current))
    if pick==3:return choose_wallpaper()
    if 0<=pick<len(keys):
        if custom:wallpaper.choose('off',addon=ADDON)
        if keys[pick]!=current:
            # 7.0.30: the settings close first; Kodi's skin colours change afterwards.
            theme.apply(keys[pick],ADDON,kodi=False)
            return theme.RELOAD
    return None


def choose_card_opacity():
    """Posters and catalog art slightly see-through over the glass boxes (Off/10/20/30 %)."""
    from resources.lib import theme
    keys=list(theme.OPACITY_LEVELS);current=theme.card_opacity(ADDON)
    pick=xbmcgui.Dialog().select('Poster and catalog transparency',[theme.OPACITY_LABELS[k] for k in keys],preselect=keys.index(current))
    if pick>=0:theme.set_card_opacity(keys[pick],ADDON)
    return None


def ratings_summary():
    from resources.lib import ratings_row,mdblist
    if not mdblist.configured():return 'Connect MDBList first'
    shown=[label for _,label,on in ratings_row.choices(ADDON) if on]
    return '%d of %d shown'%(len(shown),len(ratings_row.SERVICES))


def ratings_page():
    """7.0.29: which MDBList ratings the title details show (like Nuvio)."""
    from resources.lib import ratings_row,mdblist
    def build():
        rows=[(service,page.item(label,enabled=on)) for service,label,on in ratings_row.choices(ADDON)]
        if not mdblist.configured():rows.insert(0,('connect',page.item('Connect MDBList (Accounts & tracking) to see ratings')))
        return rows
    def act(key):
        if key=='connect':return mdblist_tracking_page()
        if key in ratings_row.SERVICES:
            ratings_row.set_enabled(key,not ratings_row.enabled(key,ADDON),ADDON);settings_cache.invalidate()
        return None
    return _keyed('MDBList ratings',build,act)


def tracking_accounts():
    """Accounts in setup order: Nuvio, Stremio (beta), then tracking services (7.0)."""
    from resources.lib import trakt,simkl
    def build():return [('nuvio',page.item('Nuvio account',nuvio_status())),
        ('stremio',page.item('Stremio (beta) · add-ons and Continue Watching',_stremio_status())),
        ('trakt',page.item('Trakt · tracking service','Connected' if trakt.authorized() else 'Not connected')),
        ('simkl',page.item('Simkl · tracking service','Connected' if simkl.authorized() else 'Not connected')),
        ('mdblist',page.item('MDBList · tracking service',_mdblist_status())),
        ('ratings',page.item('MDBList ratings · logos and scores in title details',ratings_summary()))]
    def act(key):
        if key=='nuvio':return accounts()
        if key=='ratings':return ratings_page()
        if key=='stremio':
            from .keys_backup import stremio
            return stremio()
        if key=='trakt':
            from .trakt_account import run as trakt_settings
            return trakt_settings()
        if key=='simkl':
            from .simkl_account import run as simkl_settings
            return simkl_settings()
        if key=='mdblist':return mdblist_tracking_page()
    return _keyed('Accounts & tracking',build,act)


def _debrid_status():
    from resources.lib import debrid
    on=[debrid.SERVICES[s]['name'] for s in debrid.active()]
    if not on:return 'Add a TorBox or Premiumize API key'
    return '%s · %s'%(' + '.join(on),'cached only' if debrid.cached_only() else 'cached and to download')


def debrid_page():
    """TorBox and Premiumize built in (7.0.12): streams straight from the
    account, found by the title's IMDb id - no stream add-on needed."""
    from resources.lib import debrid
    def build():
        rows=[]
        for service,info in debrid.SERVICES.items():
            if debrid.api_key(service):
                rows.append((service,page.item('%s · streams'%info['name'],enabled=debrid.enabled(service))))
            else:
                rows.append(('key',page.item('%s API key'%info['name'],'Not set · add it in API keys')))
        rows.append(('cached',page.item('Cached only · plays at once',enabled=debrid.cached_only())))
        if debrid.active():rows.append(('test',page.item('Test the connection')))
        return rows
    def act(key):
        if key=='key':
            from .keys_backup import keys
            return keys()
        if key in debrid.SERVICES:
            setting=debrid.SERVICES[key]['on']
            ADDON.setSetting(setting,'false' if debrid.enabled(key) else 'true')
        elif key=='cached':ADDON.setSetting(debrid.CACHED_SETTING,'false' if debrid.cached_only() else 'true')
        elif key=='test':
            lines=[]
            for service in debrid.active():
                try:lines.append('%s: %s'%(debrid.SERVICES[service]['name'],'connected' if debrid.check(service) else 'no answer'))
                except Exception as exc:lines.append('%s: %s'%(debrid.SERVICES[service]['name'],exc))
            xbmcgui.Dialog().notification('Debrid',' · '.join(lines)[:120],time=4000)
        settings_cache.invalidate()
        return None
    return _keyed('TorBox & Premiumize',build,act)


def _mdblist_status():
    from resources.lib import mdblist_tracking
    if not mdblist_tracking.api_key():return 'Needs the MDBList API key'
    return 'On' if mdblist_tracking.enabled() else 'Off'


def mdblist_tracking_page():
    """MDBList as a tracking service (7.0.12): watches go to MDBList, watched
    marks come back. Uses the MDBList API key from API keys."""
    from resources.lib import mdblist_tracking
    def build():
        have=bool(mdblist_tracking.api_key())
        rows=[('key',page.item('MDBList API key','Set' if have else 'Not set · get it at mdblist.com/preferences'))]
        if have:
            rows+=[('on',page.item('Track what I watch on MDBList',enabled=mdblist_tracking.enabled())),
                   ('test',page.item('Test the connection')),
                   ('sync',page.item('Get watched marks from MDBList now'))]
        return rows
    def act(key):
        if key=='key':
            from .keys_backup import keys
            return keys()
        if key=='on':
            ADDON.setSetting('mdblist_tracking','false' if mdblist_tracking.enabled() else 'true')
            settings_cache.invalidate()
            if not mdblist_tracking.enabled():mdblist_tracking.forget()
        elif key in ('test','sync'):
            try:
                if key=='test':
                    ok=mdblist_tracking.check()
                    xbmcgui.Dialog().notification('MDBList','Connected' if ok else 'No answer from MDBList',time=3000)
                else:
                    mdblist_tracking.refresh(force=True)
                    xbmcgui.Dialog().notification('MDBList','Watched marks updated',time=3000)
            except Exception as exc:
                xbmcgui.Dialog().notification('MDBList',str(exc)[:80],time=4000)
        return None
    return _keyed('MDBList · tracking service',build,act)


def storage():
    """Local & network storage (beta): own drives, Plex, Jellyfin and Emby."""
    from resources.lib import local_media, media_servers as servers
    def build():
        have=local_media.counts() if local_media.enabled(ADDON) else None
        return [('local',page.item('Local storage (beta) · drives and shares on this device',
                                   ('%d movies · %d series'%(have['movie'],have['series'])) if have else 'Off')),
                ('plex',page.item('Plex (beta) · your Plex servers',servers.status(servers.PLEX))),
                ('jellyfin',page.item('Jellyfin (beta) · your Jellyfin server',servers.status(servers.JELLYFIN))),
                ('emby',page.item('Emby (beta) · your Emby server',servers.status(servers.EMBY)))]
    def act(key):
        if key=='local':return local_storage()
        from . import media_servers
        return {'plex':media_servers.plex,'jellyfin':media_servers.jellyfin,'emby':media_servers.emby}[key]()
    return _keyed('Local & network storage (beta)',build,act)


def live_tv():
    """Live TV, IPTV and Sport on one page (7.0)."""
    from . import sports, iptv
    def build():
        return [('status',page.item('IPTV channels','Set up' if iptv.configured() else 'Not set up')),
                ('xtream',page.item('Set up IPTV · Xtream account')),
                ('m3u',page.item('Set up IPTV · M3U playlist + XMLTV TV guide')),
                ('open',page.item('Open Live TV channels')),
                ('sport_player',page.item('Sport player',sports.PLAYER_LABELS[sports.player_mode()])),
                ('sport_auto',page.item('Sport · play live events after resting 5 seconds',enabled=sports.autoplay_enabled())),
                ('sport_addons',page.item('Sport add-ons',_role_count('sport')))]
    def act(key):
        if key=='sport_addons':return role_addons('sport')
        if key in ('xtream','m3u'):iptv.setup(key)
        elif key in ('open','status'):
            if iptv.configured():iptv.open_iptv()   # the channel list over the hidden settings page
            else:iptv.configure()
        elif key=='sport_player':
            keys=['small','big'];current=sports.player_mode()
            i=xbmcgui.Dialog().select('Sport player',[sports.PLAYER_LABELS[k] for k in keys],preselect=keys.index(current))
            if i>=0:ADDON.setSetting(sports.PLAYER_SETTING,keys[i])
        elif key=='sport_auto':ADDON.setSetting(sports.AUTOPLAY_SETTING,'false' if sports.autoplay_enabled() else 'true')
        settings_cache.invalidate()
        return None
    return _keyed('Live TV, IPTV & Sport',build,act)


def backup_restore():
    from .keys_backup import backup,restore
    def build():return [('backup',page.item('Back up settings to a file','USB, network folder or Downloads')),
                        ('restore',page.item('Restore settings from a backup')),
                        ('phone',page.item('On the phone','Set up on phone > Backup'))]
    def act(key):
        if key=='backup':backup();return None
        if key=='restore':return restore()
        xbmcgui.Dialog().ok('Backup on the phone','HUB Settings > Set up on phone, then open the Backup tab: download a backup to your '
                            'phone, or restore one. Settings, accounts, API keys, add-ons, collections and Continue Watching move along.')
        return None
    return _keyed('Backup & restore',build,act)


def api_keys():
    from .keys_backup import keys
    return keys()


def _stremio_status():
    from resources.lib import stremio_account
    return stremio_account.status()


def continue_watching():
    """Continue Watching like the Nuvio apps (6.0.35, GitHub issue #7)."""
    from resources.lib import continue_rules as rules,last_source
    def rows():return [page.item('Show titles watched in the last',rules.PERIOD_LABELS[str(rules.period_days(ADDON))]),
        page.item('Show unaired next episodes (airs tomorrow)',enabled=rules.show_unaired(ADDON)),
        page.item('Refresh interval and Nuvio sync direction',(ADDON.getSetting('nuvio_progress_interval') or '60')+' seconds'),
        page.item(LAST_LINK_TITLE,last_link_summary()),page.item('Back')]
    def choose(pick):
        if pick==0:
            values=list(rules.PERIODS);current=str(rules.period_days(ADDON))
            selected=xbmcgui.Dialog().select('Continue Watching period',[rules.PERIOD_LABELS[v] for v in values],
                                             preselect=values.index(current) if current in values else 1)
            if selected>=0:ADDON.setSetting(rules.PERIOD_SETTING,values[selected])
        elif pick==1:ADDON.setSetting(rules.UNAIRED_SETTING,'false' if rules.show_unaired(ADDON) else 'true')
        elif pick==2:progress_settings()
        elif pick==3:choose_last_link()
        elif pick==4:return page.DONE
        settings_cache.invalidate()
        xbmcgui.Window(10000).setProperty('meganexus.progress.revision','settings-%s'%id(rows))
    return page.show('Continue Watching',rows,choose)


KOFI_URL='https://ko-fi.com/master100janovic'


class SupportWindow(xbmcgui.WindowXMLDialog):
    def onInit(self):self.setFocusId(100)
    def onClick(self,cid):self.close()
    def onAction(self,action):
        if action.getId() in (9,10,92,216,247,257,275,61448,61467):self.close()


def support():
    """Ko-fi QR code: scan with a phone to donate."""
    win=SupportWindow('meganexus_support.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i')
    try:win.doModal()
    finally:del win


def components_up_to_date(current,dialog,latest=''):
    """The backend is current; are the interface, skin and screensaver too?
    (6.0.36: an updated backend with an old interface said "up to date".)"""
    from resources.lib import bundle_installer,updater
    try:report=bundle_installer.component_report()
    except Exception:report=[]
    names={'script.meganexus':'interface','skin.meganexus':'skin','screensaver.meganexus':'screensaver'}
    missing=[r for r in report if not r['current']]
    stale=[r for r in report if r['current'] and r['kodi'] and r['kodi']!=r['wanted']]
    if not missing and not stale:
        dialog.ok('Updates','MegaNexus %s is up to date (latest release %s).'%(current,latest or current));return
    if missing:
        parts=', '.join('%s %s'%(names.get(r['id'],r['id']),r['files'] or 'missing') for r in missing)
        # Installed by the service once MegaNexus is closed; a restart does it at once.
        ADDON.setSetting(bundle_installer.VERSION_SETTING,'')
        text='MegaNexus %s is installed, but not yet: %s.\nThey are installed when MegaNexus is closed - or restart now to finish.'%(current,parts)
    else:
        parts=', '.join('%s %s'%(names.get(r['id'],r['id']),r['kodi']) for r in stale)
        text='MegaNexus %s is installed; Kodi still uses %s until it restarts.'%(current,parts)
    from resources.lib.kodi_restart import plan
    builtin,label,_=plan()
    if dialog.yesno('Updates',text,nolabel='Later',yeslabel=label):
        xbmc.executebuiltin(builtin)


def check_updates():
    """Compare with the latest GitHub release and install it on confirmation."""
    from resources.lib import updater
    from .playback import job
    backend=xbmcaddon.Addon('plugin.video.meganexus');dialog=xbmcgui.Dialog()
    current=backend.getAddonInfo('version')
    try:info=job(updater.latest,label='Checking GitHub for updates')
    except Exception:
        dialog.ok('Updates','GitHub could not be reached. Check the connection and retry.\n'+updater.RELEASES);return
    if info is None:
        dialog.ok('Updates','No MegaNexus release was found.\n'+updater.RELEASES);return
    if not updater.newer(info['version'],current):
        components_up_to_date(current,dialog,info['version']);return
    if not dialog.yesno('Update available','MegaNexus %s is available (installed %s).\nInstall it now? Kodi restarts the interface afterwards.'%(info['version'],current)):return
    if xbmc.Player().isPlayingVideo():
        dialog.ok('Updates','Stop playback first, then check again.');return
    try:
        job(lambda:updater.install(info,xbmcvfs.translatePath('special://home/addons'),
                                   xbmcvfs.translatePath(backend.getAddonInfo('profile'))),label='Installing MegaNexus %s'%info['version'])
    except Exception as exc:
        dialog.ok('Updates','The update could not be installed; your current version was kept.\n'+(str(exc) if isinstance(exc,ValueError) else ''));return
    xbmc.executebuiltin('UpdateLocalAddons')
    updater.mark_pending(backend,info['version'])
    # 7.0: ask right away (users waited for a question that only came after
    # leaving MegaNexus). Yes closes MegaNexus first, then Kodi restarts /
    # reboots / closes per platform (the command runs after the interface).
    from resources.lib.kodi_restart import plan
    builtin,label,question=plan()
    if dialog.yesno('Updates',question%info['version'],nolabel='Later',yeslabel=label):
        backend.setSetting(updater.PENDING_SETTING,'')
        return builtin
    dialog.ok('Updates','MegaNexus %s is installed. It starts after the next Kodi restart; MegaNexus reminds you when you open it.'%info['version'])
    return page.DONE


def version_label():
    """Backend version, plus the interface's when Kodi runs another one."""
    backend=xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('version')
    ui=xbmcaddon.Addon('script.meganexus').getAddonInfo('version')
    return backend if ui==backend else '%s · interface %s'%(backend,ui)


def maintenance():
    def build():return [('update',page.item('Check for updates',version_label())),
        ('auto',page.item('Automatic updates from GitHub',enabled=ADDON.getSetting('meganexus_auto_update')!='false')),
        ('check',page.item('System check · add-ons that slow MegaNexus down')),
        ('wizard',page.item('Run setup again')),
        ('stats',page.item('Diagnostics overlay · CPU, RAM, FPS, video and audio format',enabled=xbmc.getCondVisibility('Skin.HasSetting(meganexus.stats)'))),
        ('reset',page.item('Reset MegaNexus · erase all settings and start fresh')),
        ('remove',page.item('Remove MegaNexus build'))]
    def act(key):
        if key=='update':return check_updates() or None
        if key=='stats':
            # 7.0.21: a corner window of MegaNexus Skin (Custom_1111); it takes no
            # focus, so menus and the player work as usual underneath.
            if xbmc.getSkinDir()!='skin.meganexus':
                xbmcgui.Dialog().ok('Diagnostics overlay','The overlay is part of MegaNexus Skin. Switch to MegaNexus Skin in Home & appearance first.')
            else:xbmc.executebuiltin('Skin.ToggleSetting(meganexus.stats)')
            return None
        if key=='reset':return factory_reset_page()
        if key=='auto':ADDON.setSetting('meganexus_auto_update','false' if ADDON.getSetting('meganexus_auto_update')!='false' else 'true')
        elif key=='check':
            from .system_check import run as system_check
            system_check(force=True)
        elif key=='wizard':
            from .onboarding import run as wizard
            return wizard(force=True)
        elif key=='remove':
            from resources.lib.meganexus_uninstall import prepare
            return prepare()
        return None
    return _keyed('Maintenance & updates',build,act)


def factory_reset_page():
    """7.0.21: erase every MegaNexus setting and saved file, then restart Kodi."""
    dialog=xbmcgui.Dialog()
    if not dialog.yesno('Reset MegaNexus','This erases everything MegaNexus keeps on this device: your add-ons, collections, accounts and API keys, '
                        'all preferences, Continue Watching and the caches.[CR]Kodi then restarts and MegaNexus starts like a new installation.',
                        nolabel='Cancel',yeslabel='Continue'):return None
    if not dialog.yesno('Reset MegaNexus','Erase everything now? This cannot be undone.[CR]Tip: Backup & restore can save your setup to a file first.',
                        nolabel='Cancel',yeslabel='Erase everything'):return None
    from resources.lib import factory_reset, kodi_restart
    factory_reset.request()
    builtin,_,_=kodi_restart.plan()
    if builtin=='Quit':dialog.ok('Reset MegaNexus','Kodi closes now. Open Kodi again: MegaNexus starts fresh.')
    xbmc.executebuiltin(builtin)
    return page.DONE


def local_storage():
    from .local_storage import run as local
    return local()


def phone_setup():
    from .phone_setup import run as phone
    phone()


def _category(title, actions):
    def build():return [(key,page.item(label)) for key,label,_ in actions]
    def act(key):return next(fn for name,_,fn in actions if name==key)()
    return _keyed(title,build,act)


def connections():
    return _category('Connections', [('accounts','Accounts & tracking · Nuvio, Stremio, Trakt, Simkl',tracking_accounts),
        ('addons','Add-ons · metadata, streams, subtitles, sport',addons),
        ('keys','API keys · TMDb, MDBList, Fanart.tv, TheIntroDB',api_keys),
        ('check','Verify tracking connections',verify_tracking)])


def verify_tracking():
    from resources.lib.tracking_connections import check_connections
    from .playback import job
    report=job(check_connections,label='Checking tracking connections')
    if not report:return
    rows=[]
    for name,row in report.items():
        if name=='local':continue
        rows.append('%s · %s · sync %s'%(name,row['connection'],'on' if row.get('sync') else 'off'))
    xbmcgui.Dialog().select('Tracking connections',rows)


def home_library():
    return _category('Home & library', [('appearance','Home & appearance',appearance),
        ('collections','Collections & Home rows',collections),
        ('storage','Local & network storage (beta)',storage),
        ('continue','Continue Watching',continue_watching)])


def playback_category():
    return _category('Playback & subtitles', [('player','Playback',playback),
        ('subtitles','Subtitles',subtitle_settings),('trailers','Trailers',trailers),('badges','Stream badges · Nuvio JSON',badge_settings)])


def badge_settings():
    from resources.lib import quality_badges
    state=quality_badges.status()
    if state['enabled'] and not state['count']:
        from .playback import job
        job(quality_badges.prepare_rules,label='Preparing stream badges')
    def build():
        state=quality_badges.status()
        summary='%d rules · %s'%(state['count'],state.get('name') or 'Imported Nuvio JSON') if state['count'] else 'Starter image badges activate when enabled'
        return [('on',page.item('Show stream badges',summary,enabled=state['enabled'])),
                ('urls',page.item('Import badge JSON URLs','%d sets · %d rules'%(len(state['urls']),state['count']))),
                ('file',page.item('Import JSON file · badge builder',state.get('name') or 'Universal mode matches ordinary stream names')),
                ('preview',page.item('Preview · images and labels'))]
    def act(key):
        state=quality_badges.status()
        if key=='on':
            from .playback import job
            job(lambda:quality_badges.toggle(not state['enabled']),label='Preparing stream badges')
        elif key=='urls':
            urls=[]
            for index in range(3):
                old=state['urls'][index] if index<len(state['urls']) else ''
                url=xbmcgui.Dialog().input('Badge JSON URL %d · empty to finish'%(index+1),defaultt=old).strip()
                if not url:break
                urls.append(url)
            if urls:
                from .playback import job
                job(lambda:quality_badges.save(urls),label='Importing stream badges')
        elif key=='file':
            path=xbmcgui.Dialog().browseSingle(1,'Import badge JSON','files','.json')
            if path:
                from .playback import job
                job(lambda:quality_badges.save_file(path),label='Importing stream badges')
        elif key=='preview':
            from .badges import preview
            preview(state)
    return _keyed('Stream badges',build,act)


def backup_maintenance():
    return _category('Backup & maintenance', [('backup','Backup & restore · move to another device',backup_restore),
        ('maintenance','Maintenance & updates',maintenance)])


def _downloads():
    from .downloads import manage
    return manage()


def help_support():
    from .help_guide import guide
    def report():
        from resources.lib import problem_report
        if not problem_report.left_today():
            xbmcgui.Dialog().ok('Report a problem','You can send %d reports in 24 hours. Try again tomorrow.'%problem_report.PER_DAY)
            return
        from .phone_setup import run as phone
        phone(report=True)
    return _category('Help & support', [('guide','User guide · how MegaNexus works and what every setting does',guide),
        ('report','Report a problem · describe it on the phone, sent with the Kodi log',report)])


def run(back_command=''):
    actions=[('Set up on phone · QR code',phone_setup,''),
        ('Buy me a coffee · Ko-fi',support,'Support MegaNexus'),   # 7.0.29: in sight, right under the phone set-up
        ('Connections',connections,'Accounts & add-ons'),
        ('Home & library',home_library,'Layout & collections'),
        ('Playback & subtitles',playback_category,'Player & trailers'),
        ('Downloads',_downloads,'Folder & progress'),   # 7.0.29
        ('Live TV, IPTV & Sport',live_tv,''),
        ('Themes & screensaver',themes_screensaver,'Standard or custom'),
        ('Performance & image cache',performance,''),
        ('Backup & maintenance',backup_maintenance,'Restore & updates'),
        ('Help & support',help_support,'')]
    def rows():return [page.item(label,value) for label,_,value in actions]+[page.item('Done')]
    def choose(pick):
        try:
            if pick==len(actions):return page.DONE
            result=actions[pick][1]()
            return result if isinstance(result,str) else None
        except Exception as exc:xbmcgui.Dialog().ok('MegaNexus',str(exc) if isinstance(exc,ValueError) else 'This operation could not finish. Check the configuration and connection, then retry.')
        finally:settings_cache.invalidate()
    return page.show('HUB Settings',rows,choose,back_result=back_command)


def subtitle_settings():
    from resources.lib import meganexus_subtitles as subs
    def rows():return [page.item('Subtitle language',subs.language_name(subs.preferred())),
        page.item('Set subtitles on video start',enabled=ADDON.getSetting('meganexus_subtitles_on_start')=='true'),
        page.item('Subtitle add-ons',_role_count('subtitles')),
        page.item('Autosync subtitle offset',enabled=(ADDON.getSetting('meganexus_autosync_subtitles') or 'true')!='false'),
        page.item('Back')]
    def choose(pick):
        if pick==0:
            choices=subs.languages();current=subs.language(subs.preferred())
            selected=next((i for i,r in enumerate(choices) if subs.language(r['value'])==current),0)
            index=xbmcgui.Dialog().select('Subtitle language',[r['label'] for r in choices],preselect=selected)
            if index>=0:
                value=choices[index]['value']
                ADDON.setSetting('meganexus_subtitle_language',value)
                ADDON.setSetting('preferred_subtitle_langs',subs.language(value))
        elif pick==1:toggle('meganexus_subtitles_on_start')
        elif pick==2:role_addons('subtitles')
        elif pick==3:
            on=(ADDON.getSetting('meganexus_autosync_subtitles') or 'true')!='false'
            ADDON.setSetting('meganexus_autosync_subtitles','false' if on else 'true')
            if on:xbmcgui.Window(10000).clearProperty('meganexus.subtitle.syncable')
        elif pick==4:return page.DONE
    return page.show('Subtitles',rows,choose)
