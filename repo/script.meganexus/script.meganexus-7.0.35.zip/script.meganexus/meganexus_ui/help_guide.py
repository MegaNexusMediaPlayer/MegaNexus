# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""HUB Settings > Help & support > User guide (7.0.29).

What MegaNexus is, how to use it, and what every setting does - in the same
order as HUB Settings. Each topic opens as text (Kodi's text viewer).
"""
import xbmcgui

from . import settings_page as page

B, E = '[B]', '[/B]'


def _h(text):
    return '%s%s%s' % (B, text, E)


TOPICS = (
    ('start', 'Getting started', '\n'.join((
        _h('The two screens'),
        'The HUB is the start screen with the pills at the bottom: MegaNexus, IPTV Channels, Sport, '
        'HUB Settings, Kodi Settings and Power. "MegaNexus" opens Home - your rows of films and series.',
        '',
        _h('Home'),
        'Up / Down moves between rows, Left / Right along a row. OK opens a title (Continue Watching '
        'resumes it straight away). Long OK or the menu key opens Title options (Play, Trailer, Library, '
        'Mark watched, Remove from Continue Watching...). The Info key shows the full description.',
        'At the top: Home, Library, Search, Settings and HUB.',
        '',
        _h('The quickest set-up'),
        'HUB Settings > Set up on phone · QR code. Scan the code with the phone (same Wi-Fi) and do '
        'everything there: Nuvio or Stremio sign-in, add-ons, API keys, collections, screensaver and badges. '
        'Keep the QR screen open until you press "Save & start MegaNexus".',
        '',
        _h('Typing with the phone'),
        'Every on-screen keyboard has "Write with phone" above the keys: scan the QR code, type on the phone and tap '
        '"Send to TV" - the text goes into the keyboard and OK is pressed. Passwords are typed in a hidden field.',
        '',
        _h('Like MegaNexus?'),
        'HUB Settings > Buy me a coffee · Ko-fi (right under the phone set-up) - a QR code to support the development.',
    ))),
    ('addons', 'Add-ons, manifests and debrid', '\n'.join((
        _h('Where films come from'),
        'MegaNexus plays what your add-ons find - the same add-ons as the Nuvio and Stremio apps. '
        'Each add-on is a link to its manifest (it ends in manifest.json). There are four kinds:',
        '  - Metadata: catalogs, posters, descriptions (Cinemeta is built in; AIOMetadata, TMDB add-ons...).',
        '  - Streams: the links that play (Torrentio, Comet, MediaFusion, AIOStreams...).',
        '  - Subtitles: OpenSubtitles and other subtitle add-ons.',
        '  - Sport: live events and their streams.',
        '',
        _h('Adding an add-on'),
        '1. Open the add-on\'s Configure page in a browser (for example torrentio.strem.fun/configure, or the '
        'Configure link on the add-on\'s website).',
        '2. Choose its options - languages, quality, and your debrid service with its API key.',
        '3. Copy the installed link (the manifest URL).',
        '4. HUB Settings > Connections > Add-ons > Your add-ons > Add a configured add-on link - or paste it on '
        'the phone page (Add-ons tab).',
        'Already using Nuvio or Stremio? Connections > Add-ons > Import add-ons from Nuvio / Stremio brings '
        'all of them over at once.',
        '',
        _h('Debrid'),
        'A debrid service (TorBox, Real-Debrid, Premiumize, AllDebrid...) turns torrent results into fast '
        'direct links. Its key goes into the stream add-on\'s Configure page. TorBox and Premiumize can also '
        'be used without an add-on: Connections > Add-ons > TorBox & Premiumize. "Debrid: cached (instant) '
        'results first" puts links that start at once at the top.',
    ))),
    ('connections', 'Connections', '\n'.join((
        _h('Accounts & tracking'),
        'Nuvio account - sign in to bring your add-ons, collections, library and progress from the Nuvio '
        'apps; Nuvio sync direction decides whether MegaNexus only reads or also writes back.',
        'Stremio (beta) - your Stremio add-ons and Continue Watching.',
        'Trakt, Simkl, MDBList - tracking services: what you watch is marked there, their watchlists appear '
        'in the Library, Continue Watching follows them. MDBList also gives the ratings row (IMDb, Rotten '
        'Tomatoes, Metacritic, Letterboxd...) - choose the services in MDBList ratings.',
        '',
        _h('Add-ons'),
        'Metadata, stream, subtitle and sport add-ons (see "Add-ons, manifests and debrid"), Refresh add-on '
        'catalogs now, Remove an add-on, and the YouTube add-on used for some trailers.',
        '',
        _h('API keys'),
        'TMDb - actor search, recommendations and TMDB pictures. MDBList - ratings and tracking. '
        'Fanart.tv - posters, backgrounds and logos made by fans. TheIntroDB - where intros and credits are '
        '(Skip button). Keys are free from each service\'s website.',
        'A TMDb key is recommended for much more than pictures: a film\'s release badge (In cinemas or '
        'Released once it is out digitally or on Blu-ray), the Digital release filter, details and trailers '
        'for titles your metadata add-on only knows by their TMDb ID, and More like this. Without it a film '
        'shows only Released or Coming by its release date, and the Digital release filter lets everything play.',
        '',
        _h('Verify tracking connections'),
        'Checks that every connected service answers and syncs.',
    ))),
    ('home', 'Home & library', '\n'.join((
        _h('Home & appearance'),
        'Use MegaNexus skin - the HUB look; Kodi\'s own screens follow the theme too.',
        'Layout & cards - Home layout (MegaNexus collections or catalog rows), portrait posters or landscape '
        'cards, and how see-through the posters are.',
        'Home content & titles - the big title area (hero), card titles, ratings, row titles, animated art.',
        'Artwork - where posters, backgrounds, title logos and landscape cards come from: the catalog, TMDB '
        'or Fanart.tv (needs its key), and their language (English, Kodi\'s language, or without text). A title '
        'the provider has no picture for keeps the catalog\'s.',
        '',
        _h('Collections & Home rows'),
        'Which collections and catalogs are rows on Home, their order and names.',
        'Hide unreleased titles - films and series whose release date lies ahead stay out of Home, collections '
        'and search, and episodes not aired yet out of a series\' episode list.',
        '',
        _h('Local & network storage'),
        'Local storage - folders on a USB disk, NAS or SMB/NFS share. Add the folder (Kodi opens Videos > '
        'Files > Add videos); MegaNexus reads it itself and shows Local Movies and Local Series on Home and '
        'in the Library. Names like "Title (2019)" and "Show/Season 1/Show S01E02" work best.',
        'Plex, Jellyfin, Emby - sign in to your server; its Continue watching and Recently added appear on '
        'Home and in the Library, and its copy of a title is offered as a source.',
        '',
        _h('Continue Watching'),
        'How far back it shows titles, unaired next episodes, refresh interval, and "start with the last '
        'link" (resume with the same source within 12 or 24 hours).',
        '',
        _h('Library'),
        'Local: titles you saved (Title options > Add to Library), this device\'s storage and your servers. '
        'The tracking tab: Trakt / Simkl / MDBList watchlists. Calendar: everything by the month it was added.',
    ))),
    ('playback', 'Playback & subtitles', '\n'.join((
        _h('Playback'),
        'Autoplay the best stream - starts the first matching link without the source list.',
        'Digital release filter - a film only in cinemas, or an episode not aired yet, is not searched or played '
        '(also a manual search and Continue Watching); it tells you when it comes out. Films over a year old '
        'always play. Uses TMDb\'s release dates (digital, Blu-ray, TV) - needs a TMDb key for films.',
        'Continue Watching · start with the last link - reuse the source you used last time.',
        'Automatic stream choice - what "best" means: highest resolution, HDR, Dolby Vision, cached only...',
        'Intro, credits & next episode - Skip button or automatic skipping (times from TheIntroDB, your '
        'Plex / Jellyfin / Emby server and the file\'s chapters); "Next episode" appears beside "Skip outro", '
        'or from the point an episode counts as watched when the credits are unknown.',
        '',
        _h('Subtitles'),
        'Subtitle language, subtitles on video start, subtitle add-ons and Autosync subtitle offset (on by default).',
        'Subtitles come from your subtitle add-ons (their manifests, AIOStreams...), never Kodi\'s own subtitle '
        'service. When a release cannot be downloaded (its server is off or answers with an error), the next '
        'release of the same language is taken; in the list a failed version is marked with ✕.',
        _h('Autosync subtitle'),
        'A subtitle made for another release of the film starts early or late, or drifts away over the film. '
        'The Autosync subtitle button in the player (beside Offset) fixes that in a few seconds, without AI: it '
        'compares the subtitle on screen with the other subtitles of the same title from your subtitle add-ons, '
        'in any language (people speak at the same moments in every language), finds the shift and the speed '
        'difference most of them agree on, and loads the corrected subtitle at once. When they do not agree, '
        'nothing changes - then choose another version. Turn it off with Playback & subtitles > Subtitles > Autosync subtitle offset.',
        '',
        _h('Trailers'),
        'Automatic trailers on Home and the title page, their source, quality, delay and length.',
        '',
        _h('Stream badges'),
        'The pictures in the source list (4K, HDR, Dolby Vision, Atmos...). Import Nuvio badge JSON links or a '
        'file from the badge builder; preview a stream name on the phone page.',
    ))),
    ('player', 'The player', '\n'.join((
        'OK during a video opens the player bar. Buttons from the left:',
        '  Pause / Play · Sources (pause and choose another source, it carries on from the same minute) · '
        'Subtitles (search all subtitle add-ons) · Offset (subtitle delay) · Autosync subtitle · Audio · '
        'Info · Stats - and Settings at the right end.',
        'The seek line: Left / Right step back and forward; the line shows where you will land and the video '
        'jumps once you stop pressing. OK on the line pauses.',
        'Next episode and Skip intro / outro appear at the bottom right when they apply.',
        'The player bar hides after 5 seconds without a key press - not while the film is paused, and not while '
        'a menu opened from it (subtitles, audio, sources, offset, settings, info...) is still open.',
        '',
        _h('Home while a film plays'),
        'The house button (beside Settings) takes you back to where you started the film; it keeps playing. '
        '"Now playing" at the top of MegaNexus Home and on the HUB brings it back to full screen. Back from the '
        'player stops the film as before.',
        '',
        _h('Starting a film'),
        'The loading screen shows the title\'s picture and its logo filling up. Back and Esc wait while a chosen '
        'source starts (after 25 seconds a source that does not open can be left). Searching subtitles or sources '
        'during a film shows a small pill at the bottom - the film stays in view.',
        'Colours glaring when an HDR film starts or ends? Kodi Settings > System > Display > "Adjust display HDR '
        'mode" switches the screen into HDR; where the interface cannot be drawn in HDR (some Linux desktops), '
        'turn it off and Kodi converts HDR films itself.',
    ))),
    ('downloads', 'Downloads', '\n'.join((
        _h('Keep a film or an episode on this device'),
        '1. HUB Settings > Downloads > Download folder: a folder on this device, a USB disk or a network share.',
        '2. In the source list, hold OK on a source (or press the menu key) and choose Download. The list stays '
        'open, so you can still play something.',
        '3. A small blue ring by the clock fills as it downloads. Select it (Right from the top buttons of '
        'MegaNexus Home, Up on the HUB) for the box with size, speed and time left: "Close · continue" or "Stop".',
        '',
        _h('Nothing stops it'),
        'The download runs in the background - the screensaver, a film or closing MegaNexus do not stop it. When '
        'the internet drops it waits and carries on from where it was. Into a folder on this device it also '
        'carries on after Kodi restarts; on a network share that file starts again.',
        '',
        _h('What can be downloaded'),
        'Direct links (debrid services: TorBox, Real-Debrid...). Torrents, live streams (HLS) and add-on links '
        'cannot be. A debrid link can expire after some hours - then start the download again from the sources.',
        'HUB Settings > Downloads lists every download: select one to see where it was saved, or to remove it.',
    ))),
    ('livetv', 'Live TV, IPTV & Sport', '\n'.join((
        _h('IPTV'),
        'Set up IPTV with an Xtream account (server, username, password) or an M3U playlist with an XMLTV '
        'guide. Channels load in the background when Kodi starts. In IPTV Channels: categories on the left, '
        'OK plays a preview, OK again full screen; the guide shows past programmes when the playlist offers '
        'catch-up. Pause / rewind (timeshift) is experimental.',
        '',
        _h('Sport'),
        'Sport add-ons list live events; resting on an event for five seconds can start it.',
    ))),
    ('themes', 'Themes & screensaver', '\n'.join((
        'Theme - Light, Dark, Dim, or a custom theme from your own background.',
        'Wallpaper - the background of Home, catalogs, Live TV, Sport and the HUB.',
        'Interface colours - match the background, variation and strength; or your own colour for each '
        'part: accent, background, panels, pills, selection and text (swatches or a hex code).',
        'Screensaver - when it starts, its background (pictures, your posters or a video), clock and widgets.',
        'Clock & weather - on every MegaNexus screen, and the weather location.',
        'Experimental video wallpaper - a looping video behind the interface; it pauses for trailers, Sport, '
        'IPTV and films.',
    ))),
    ('performance', 'Performance & image cache', '\n'.join((
        'Memory for posters and catalogs - how much RAM pictures may use (more = faster scrolling).',
        'Prepare posters and ratings when MegaNexus opens - every time, the opening screen stays until Kodi '
        'keeps 90 % of the posters of Home and of every collection\'s first page (pictures that cannot load '
        'do not count; Back skips - a first setup runs until then, the day\'s new posters at most a minute), and fetches their MDBList ratings in a few requests '
        '(at most 60 % of your daily MDBList requests - the rest stays for titles you open). When everything '
        'is there, Home opens at once.',
        'Cache usage - the posters Kodi keeps on the device and MegaNexus\'s image memory.',
        'Clear MegaNexus images and metadata cache - when pictures look wrong or old.',
        'System check - add-ons that slow MegaNexus down.',
        'Diagnostics overlay - CPU, RAM, FPS and the video / audio format on screen.',
    ))),
    ('backup', 'Backup & maintenance', '\n'.join((
        'Backup & restore - save all settings, keys and add-ons to a file, restore them on another device.',
        'Maintenance & updates - check for updates (automatic updates from GitHub), run set-up again, reset '
        'MegaNexus, or remove the MegaNexus build.',
    ))),
    ('trouble', 'When something does not work', '\n'.join((
        _h('No sources'),
        'Check the stream add-ons (Connections > Add-ons) and their debrid key; a source that freezes - try '
        'another from the list, or turn on "Debrid: cached results first".',
        _h('Nothing on Home'),
        'Sign in to Nuvio or add a metadata add-on; Collections & Home rows decides what shows.',
        _h('Live TV empty'),
        'IPTV setup: check the playlist link; channels load about half a minute after Kodi starts.',
        _h('Video judders'),
        'Kodi Settings > Player > Adjust display refresh rate: "On start / stop". MegaNexus gives it back '
        'before every film even while the video wallpaper or a trailer plays.',
        _h('Search finds nothing'),
        'Search uses the search catalogs of your metadata add-ons (AIOMetadata, Cinemeta...). Check that one is '
        'switched on in Connections > Add-ons > Metadata.',
        _h('Still stuck'),
        'Connections > Verify tracking connections; HUB Settings > Performance > System check.',
        _h('Report a problem'),
        'Help & support > Report a problem: scan the QR code, describe what happened on the phone and send it. '
        'It reaches the MegaNexus developer as a GitHub issue together with the end of the Kodi log - add-on '
        'configurations, links, log-ins, keys and e-mail addresses are removed first. The report is public; '
        'three reports a day per device.',
    ))),
)


def guide():
    """The user guide: one row per topic, each opens as text."""
    def build():
        return [(key, page.item(title)) for key, title, _ in TOPICS]

    def act(key):
        title, text = next((t, x) for k, t, x in TOPICS if k == key)
        xbmcgui.Dialog().textviewer('MegaNexus · ' + title, text)
        return None
    return page.keyed('User guide', build, act)
