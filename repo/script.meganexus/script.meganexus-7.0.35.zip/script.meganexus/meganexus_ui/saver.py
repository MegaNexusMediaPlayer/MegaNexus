# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Image/GIF or owned video screensaver, independent of watch/progress playback.

Kodi deactivates a registered screensaver when video starts. The registered
entry therefore wakes it before handing off to a separate ordinary script.
That script owns its modal and only its own video; it never replaces paused
media, clears playlists, or changes application fullscreen/resolution.
"""
import hashlib
import json
import os
import time
import uuid
import threading
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from resources.lib import presentation_settings, saver_state
from .home_trailers import PreviewPlayer
from .system_setup import rpc
from . import mp4loop
from resources.lib.theme import folder as theme_folder

DEFAULT_ART='special://home/addons/script.meganexus/resources/media/meganexus_banner.png'
VIDEO_EXTENSIONS=('.mp4','.m4v','.mkv','.webm','.mov','.avi','.ts','.m2ts')
# The built-in MegaNexus animation is drawn by the skin (meganexus_screensaver.xml):
# no player, no mute, no audio OSD, sharp at any resolution. 6.0.20 test builds
# stored it as a bundled MP4 path; that value is read as the animation.
ANIMATED='animated'
_LEGACY_BUILTIN_VIDEO='/meganexus_saver.mp4'


SLIDESHOW='slideshow'
BLACK_AFTER=1.0          # 7.0.27: seconds the window takes to fade the screen to black (restored in 7.0.29)
FOLDER_SETTING='meganexus_screensaver_folder'


def saver_mode(addon):
    kind=addon.getSetting('meganexus_screensaver_type') or 'image'
    if kind=='video' and addon.getSetting('meganexus_screensaver_video').strip().endswith(_LEGACY_BUILTIN_VIDEO):return ANIMATED
    if kind==SLIDESHOW and not addon.getSetting(FOLDER_SETTING):return 'image'   # 7.0.24: a folder of pictures
    return kind if kind in (ANIMATED,'video',SLIDESHOW) else 'image'


# 6.0.32: MP4/MOV clips play from a silent copy that already contains the clip
# back to back for an hour (meganexus_ui/mp4loop.py): no seek at the loop point (the
# ~1 s stall) and no audio track, so Kodi is never muted. Other formats keep
# the seek loop and the temporary mute.
LOOP_DIR='special://profile/addon_data/script.meganexus/saver_loop/'
LOOP_EXTENSIONS=('.mp4','.m4v','.mov')


class _Reader:
    def __init__(self,handle):self.handle=handle
    def seek(self,pos):self.handle.seek(pos,0)
    def read(self,count):return bytes(self.handle.readBytes(count))


def _loop_paths(path):
    stat=xbmcvfs.Stat(path)
    key=hashlib.sha1(('%s|%s|%s'%(path,stat.st_size(),stat.st_mtime())).encode('utf-8')).hexdigest()[:16]
    folder=xbmcvfs.translatePath(LOOP_DIR)
    return folder,key,os.path.join(folder,key+'.mp4'),os.path.join(folder,key+'.unsupported')


def prepare_loop(path,progress=None,stopped=None):
    """Path of the seamless silent loop copy of ``path`` (written once per clip),
    or '' when this clip keeps the seek loop."""
    if not path or not path.lower().endswith(LOOP_EXTENSIONS):return ''
    try:
        folder,key,target,marker=_loop_paths(path)
        if os.path.isfile(target):return target
        if os.path.isfile(marker):return ''
        os.makedirs(folder,exist_ok=True)
    except Exception:return ''
    temp=target+'.part';handle=None
    try:
        handle=xbmcvfs.File(path)
        with open(temp,'wb') as out:
            copies=mp4loop.write_loop(_Reader(handle),handle.size(),out,progress=progress,stopped=stopped)
        os.replace(temp,target)
        xbmc.log('[MegaNexus] Screensaver loop ready: %d copies of the clip.'%copies,xbmc.LOGINFO)
    except mp4loop.Unsupported as exc:
        xbmc.log('[MegaNexus] Screensaver clip keeps the seek loop: %s'%exc,xbmc.LOGINFO)
        try:open(marker,'w').close()
        except OSError:pass
        return ''
    except Exception as exc:
        xbmc.log('[MegaNexus] Screensaver loop not prepared: %s'%exc,xbmc.LOGWARNING)
        return ''
    finally:
        if handle is not None:handle.close()
        if os.path.exists(temp):
            try:os.remove(temp)
            except OSError:pass
    # Never unlink the clip currently used by the wallpaper/screensaver, nor
    # a recent queued clip or another worker's incomplete file.
    playing=''
    try:
        player=xbmc.Player()
        if player.isPlayingVideo():playing=player.getPlayingFile()
    except Exception:pass
    for name in os.listdir(folder):
        candidate=os.path.join(folder,name)
        if not name.startswith(key) and name.endswith(('.mp4','.unsupported')) and candidate!=playing:
            try:
                if time.time()-os.path.getmtime(candidate)>30:os.remove(candidate)
            except OSError:pass
    return target


def video_file(addon):
    path=addon.getSetting('meganexus_screensaver_video').strip()
    # A chosen local/SMB file only. No arbitrary plugin routes, manifests or
    # streaming credentials are passed to the screensaver playback queue.
    return path if saver_mode(addon)=='video' and path.lower().endswith(VIDEO_EXTENSIONS) and xbmcvfs.exists(path) else ''


class SaverWindow(xbmcgui.WindowXMLDialog):
    """The screensaver; with edit=True also the Screensaver studio (7.0.24):
    a Google TV-like side panel over the live screensaver."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args)
        self.closed=False;self.ready=threading.Event();self.opened=time.monotonic()
        self.opened_at=time.time()
        self.scene=kwargs.get('scene');self.ambient=None
        self.editing=bool(kwargs.get('edit'));self.studio=None;self.studio_keys=[];self.studio_toggled=0.0
    def _background(self):
        addon=xbmcaddon.Addon('plugin.video.meganexus')
        from resources.lib import theme
        mode=saver_mode(addon)
        art=addon.getSetting('meganexus_screensaver_art') or theme.banner(addon)
        if mode=='video' and video_file(addon):
            # 7.0.29: under a video, a frame of that video - never the MegaNexus
            # picture between the fade and the first frame or at the end.
            from resources.lib import wallpaper
            video=video_file(addon)
            art=wallpaper.sharp(video) or wallpaper.still(video)
        self.setProperty('meganexus.background',art)
        self.setProperty('meganexus.saver.mode',mode if mode in (ANIMATED,SLIDESHOW) else '')
        self.setProperty('meganexus.amb.folder',addon.getSetting(FOLDER_SETTING) if mode==SLIDESHOW else '')
        return mode
    def onInit(self):
        if getattr(self,'ambient',None):return   # set up once; a dialog over the studio returns here
        editing=getattr(self,'editing',False);scene=getattr(self,'scene',None)
        mode=self._background()
        presentation_settings.sync()
        self.setProperty('meganexus.amb.dim','' if editing else dim_colour())
        # 7.0.24: the MegaNexus Ambient widgets (clock, weather, calendar, text).
        try:
            from .ambient import Ambient,Studio,load
            if editing and scene is None:scene=load()
            self.ambient=Ambient(self,scene);self.ambient.apply()
            if editing:
                from .settings import screensaver_label
                self.studio=Studio(self.ambient.scene,background=screensaver_label,slideshow=mode==SLIDESHOW)
                self.ambient.hold()
                self.setProperty('meganexus.amb.edit','1')
                self._studio_rows(0)
        except Exception:
            self.ambient=None
            xbmc.log('[MegaNexus] Screensaver widgets unavailable: '+__import__('traceback').format_exc(),xbmc.LOGWARNING)
            if editing:self.close()
        self.ready.set()
    def reveal(self):
        """Lift the black cover (7.0.27): the screen is dark, the screensaver is there."""
        if self.getProperty('meganexus.amb.reveal')!='1':self.setProperty('meganexus.amb.reveal','1')
    def dark(self):
        """The window's own fade to black has run."""
        return time.monotonic()-self.opened>=BLACK_AFTER
    def tick(self):
        if not getattr(self,'editing',False):
            try:
                wake=float(xbmcgui.Window(10000).getProperty('meganexus.saver.wake') or 0)
                if wake>getattr(self,'opened_at',time.time()):self.close();return
            except ValueError:pass
        if self.ambient:
            try:self.ambient.tick()
            except Exception:pass
    # ----------------------------------------------------------- studio ---
    def _studio_rows(self,select=None):
        from .ambient import EDIT_GROUP,EDIT_LIST
        studio=self.studio;rows=studio.rows()
        self.setProperty('meganexus.amb.edit.title',studio.title())
        self.setProperty('meganexus.amb.edit.sub','MegaNexus screensaver' if studio.page=='main' else 'Left / Right change it, live')
        try:self.getControl(EDIT_GROUP).setPosition(0 if studio.side()=='left' else 1340,0)
        except Exception:pass
        control=self.getControl(EDIT_LIST)
        keys=[r[0] for r in rows]
        if keys==self.studio_keys and select is None:
            # Same rows: update in place, the focus stays.
            for index,(key,title,value,cycles) in enumerate(rows):
                item=control.getListItem(index);item.setLabel(title);item.setLabel2(value)
            return
        items=[]
        for key,title,value,cycles in rows:
            item=xbmcgui.ListItem(title,value)
            item.setProperty('cycle','1' if cycles else '')
            items.append(item)
        control.reset();control.addItems(items)
        self.studio_keys=keys
        control.selectItem(max(0,min(select or 0,len(items)-1)))
        self.setFocusId(EDIT_LIST)
    def _studio_key(self):
        from .ambient import EDIT_LIST
        index=self.getControl(EDIT_LIST).getSelectedPosition()
        return self.studio_keys[index] if 0<=index<len(self.studio_keys) else ''
    def _studio_changed(self):
        self.ambient.apply(self.studio.scene);self.ambient.hold()
        self.studio.scene=self.ambient.scene
        self._studio_rows()
    def _studio_save(self):
        from .ambient import save
        try:save(self.studio.scene)
        except Exception:xbmc.log('[MegaNexus] Screensaver studio: scene not saved',xbmc.LOGWARNING)
    def _studio_action(self,aid):
        if self._studio_echo():return
        if self.getProperty('meganexus.amb.edit.hidden'):
            self._studio_hide(False);return
        studio=self.studio
        if aid in (1,2):
            if studio.change(self._studio_key(),-1 if aid==1 else 1):self._studio_changed()
        elif aid in (10,92):
            if studio.page=='main':self.close()
            else:
                from .ambient import WIDGETS
                page=studio.page;studio.page='main';self._studio_save();self._studio_rows(WIDGETS.index(page))
    def _studio_hide(self,hidden):
        self.setProperty('meganexus.amb.edit.hidden','1' if hidden else '')
        self.studio_toggled=time.monotonic()
    def _studio_echo(self):
        # One OK press reaches us twice (onClick and onAction, either order):
        # the second must not undo what the first just did to the panel.
        return time.monotonic()-self.studio_toggled<.5
    def _studio_click(self):
        from .ambient import WIDGETS
        if self._studio_echo():return
        studio=self.studio;key=self._studio_key()
        if key in WIDGETS:
            studio.page=key;self._studio_rows(0)
        elif key=='back':
            page=studio.page;studio.page='main';self._studio_save();self._studio_rows(WIDGETS.index(page))
        elif key in ('design','size','color','pos','speed'):
            if studio.change(key,1):self._studio_changed()
        elif key=='value':
            text=xbmcgui.Dialog().input('Text on the screensaver',studio.scene['text']['value'])
            studio.scene['text']['value']=text.strip()[:200];self._studio_changed()
        elif key=='hide':self._studio_hide(True)
        elif key=='background':
            self._studio_save()
            from .settings import screensaver_media
            screensaver_media()
            studio.slideshow=self._background()==SLIDESHOW
            self._studio_rows(self.studio_keys.index('background'))
        elif key=='done':self.close()
    def onAction(self,action):
        aid=action.getId();editing=getattr(self,'editing',False)
        if aid==0 or (aid==107 and (editing or time.monotonic()-self.opened<.4)):return
        # 7.0.27: launch() wakes Kodi's own screensaver with a context-menu
        # action once this window is up; Kodi normally consumes it.
        if aid==117 and not editing and time.monotonic()-self.opened<8:return
        if getattr(self,'studio',None):
            try:self._studio_action(aid)
            except Exception:xbmc.log('[MegaNexus] Screensaver studio: '+__import__('traceback').format_exc(),xbmc.LOGWARNING)
            return
        if editing:return
        self.close()
    def onClick(self,cid):
        if getattr(self,'studio',None):
            try:self._studio_click()
            except Exception:xbmc.log('[MegaNexus] Screensaver studio: '+__import__('traceback').format_exc(),xbmc.LOGWARNING)
            return
        if getattr(self,'editing',False):return
        self.close()
    def close(self):
        if getattr(self,'studio',None) and not getattr(self,'closed',False):self._studio_save()
        self.closed=True
        super().close()


class SaverMonitor(xbmc.Monitor):
    def __init__(self,window=None):
        super().__init__();self.window=window;self.deactivated=False
    def onScreensaverDeactivated(self):
        self.deactivated=True
        if self.window:self.window.close()
    def onAbortRequested(self):
        if self.window:self.window.close()


LOOP_RESTART_GRACE=3.0
# 6.0.31: jump back to 0 a full second before EOF and poll fast near the end,
# so a 15 s clip runs 0-14 s in an endless loop without Kodi closing/reopening
# the file (that reopen was the black break). 0.35 s was missed on slow boxes.
LOOP_SEEK_BEFORE_END=1.0
LOOP_FAST_POLL=0.02        # seconds between checks during the last LOOP_FAST_WINDOW
LOOP_FAST_WINDOW=2.5
VIDEO_GAP_GRACE=2.0        # a brief pause in video (seek, decoder refill) is not the end


class VideoPlayer(PreviewPlayer):
    def __init__(self):
        super().__init__();self.ended=False;self.ended_at=0.0
    def onPlayBackEnded(self):
        # The owner may start another loop, with a fresh playback token.
        self.ended=True;self.ended_at=time.monotonic()
    def onAVStarted(self):
        super().onAVStarted()
        if self.ready:
            try:self.showSubtitles(False)
            except Exception:pass


DIM_SETTING='meganexus_saver_dim'
DIM_LEVELS=(0,10,20,30,40,50)   # 7.0.32: how far the screensaver is dimmed
DIM_STRENGTH=1.8                 # 50 % = 90 % black: barely visible, as Kodi's Dim at its default


def dim_level(addon=None):
    try:
        value=int((addon or xbmcaddon.Addon('plugin.video.meganexus')).getSetting(DIM_SETTING) or 0)
    except (ValueError,TypeError):
        value=0
    return value if value in DIM_LEVELS else 0


def dim_colour(addon=None):
    """The black layer's colour for the chosen level ('' = not dimmed)."""
    level=dim_level(addon)
    return '%02X000000'%round(min(100,level*DIM_STRENGTH)*255/100) if level else ''


def window(scene=None,edit=False):
    return SaverWindow('meganexus_screensaver.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',scene=scene,edit=edit)


def run_image(scene=None,edit=False,curtain=None):
    """scene: a scene to show instead of the saved one; edit: the Screensaver
    studio (the live editor over the screensaver, 7.0.24); curtain: the black
    layer of the screensaver entry (7.0.27), closed once this window is up."""
    home=xbmcgui.Window(10000);token=uuid.uuid4().hex
    home.setProperty('meganexus.saver.active',token)
    win=None
    try:
        win=window(scene,edit);monitor=SaverMonitor(None if edit else win)
        win.show()
        while not win.closed and not monitor.abortRequested():
            if win.ready.is_set() and win.dark():
                win.reveal()
                if curtain:curtain.close();curtain=None
            win.tick();monitor.waitForAbort(.1)
    finally:
        if curtain:curtain.close()
        if win:win.close()
        if home.getProperty('meganexus.saver.active')==token:home.clearProperty('meganexus.saver.active')


def _release_wallpaper():
    from resources.lib import wallpaper_video
    player = xbmc.Player()
    if not wallpaper_video.is_background(player): return
    wallpaper_video.suspend(player)
    monitor = xbmc.Monitor()
    for _ in range(40):
        if not wallpaper_video.is_background(player) or monitor.waitForAbort(.05): break


def preview():
    """Preview (HUB Settings > Screensaver, "Show on TV" on the phone): the
    same screensaver Kodi starts - with the chosen video playing, not only its
    artwork (7.0.26; run_image alone showed the MegaNexus picture)."""
    addon=xbmcaddon.Addon('plugin.video.meganexus');home=xbmcgui.Window(10000)
    _release_wallpaper()
    if saver_state.active():return
    if not video_file(addon) or xbmc.Player().isPlaying():
        run_image();return
    token=uuid.uuid4().hex
    home.setProperty('meganexus.saver.active',token)
    home.setProperty('meganexus.saver.pending',json.dumps({'token':token,'issued':time.time()}))
    run_video(token)


def studio():
    """Screensaver studio over the real screensaver: with the chosen video
    playing behind the panel (7.0.27; it showed the MegaNexus picture)."""
    addon=xbmcaddon.Addon('plugin.video.meganexus');home=xbmcgui.Window(10000)
    _release_wallpaper()
    if not video_file(addon) or xbmc.Player().isPlaying():
        run_image(edit=True);return
    token=uuid.uuid4().hex
    home.setProperty('meganexus.saver.active',token)
    home.setProperty('meganexus.saver.pending',json.dumps({'token':token,'issued':time.time()}))
    run_video(token,edit=True)


SHOWN='meganexus.saver.shown'   # 7.0.27: the video screensaver's window is up (its token)


def launch(curtain=None):
    """curtain: the black layer the screensaver entry shows at once (7.0.27)."""
    addon=xbmcaddon.Addon('plugin.video.meganexus');home=xbmcgui.Window(10000)
    _release_wallpaper()
    if saver_state.active():return
    # isPlaying includes paused video/audio. Do not interrupt it to animate.
    if not video_file(addon) or xbmc.Player().isPlaying():
        run_image(curtain=curtain);return
    token=uuid.uuid4().hex;issued=time.time()
    home.setProperty('meganexus.saver.active',token)
    home.setProperty('meganexus.saver.pending',json.dumps({'token':token,'issued':issued}))
    launched=False
    try:
        monitor=SaverMonitor()
        if monitor.abortRequested() or xbmc.Player().isPlaying():return
        path=os.path.join(xbmcaddon.Addon('screensaver.meganexus').getAddonInfo('path'),'video.py')
        # 7.0.27: the video screensaver starts first, behind the black curtain;
        # Kodi's own screensaver ends only once that window is up, so the page
        # never shows between them (it used to wake Kodi first and then wait a
        # second for the new interpreter).
        xbmc.executebuiltin('RunScript("%s",%s)'%(path.replace('"',''),token))
        launched=True
        for _ in range(160):     # up to 8 s
            if home.getProperty(SHOWN)==token and (curtain is None or curtain.black()):break
            if home.getProperty('meganexus.saver.active')!=token or monitor.waitForAbort(.05):return
        if xbmc.getCondVisibility('System.ScreenSaverActive'):
            # Kodi consumes this wake action rather than navigating the page;
            # the screensaver window ignores it (SaverWindow.onAction).
            rpc('Input.ContextMenu')
            for _ in range(30):
                if monitor.deactivated or not xbmc.getCondVisibility('System.ScreenSaverActive'):break
                if monitor.waitForAbort(.05):return
        # Kodi's registered screensaver interpreter is now free to terminate.
    finally:
        if not launched and home.getProperty('meganexus.saver.active')==token:
            home.clearProperty('meganexus.saver.active');home.clearProperty('meganexus.saver.pending')


def consume_handoff(token):
    home=xbmcgui.Window(10000)
    try:data=json.loads(home.getProperty('meganexus.saver.pending') or '{}')
    except ValueError:return False
    if not isinstance(data,dict):return False
    try:age=time.time()-float(data.get('issued',0))
    except (ValueError,TypeError):return False
    if data.get('token')!=token or not 0<=age<=10 or home.getProperty('meganexus.saver.active')!=token:return False
    home.clearProperty('meganexus.saver.pending');return True


def run_video(token,edit=False):
    home=xbmcgui.Window(10000)
    if not consume_handoff(token):
        if home.getProperty('meganexus.saver.active')==token:home.clearProperty('meganexus.saver.active')
        return
    win=None;player=None;muted_by_us=False
    try:
        addon=xbmcaddon.Addon('plugin.video.meganexus');path=video_file(addon)
        if not path or xbmc.Player().isPlaying():return
        win=window(edit=edit);monitor=xbmc.Monitor();win.show()
        for _ in range(100):
            if win.ready.is_set() or win.closed or monitor.waitForAbort(.01):break
        if win.closed or not win.ready.is_set() or xbmc.Player().isPlaying():return
        home.setProperty(SHOWN,token)      # launch() may now end Kodi's own screensaver
        # 7.0.27: Kodi draws video below every window - start it only once this
        # window has faded the screen to black, and lift the cover when it plays.
        while not win.dark() and not win.closed and not monitor.abortRequested():
            monitor.waitForAbort(.05)
        revealed_at=time.monotonic()+6      # a video that does not start: show the artwork
        # Usually ready since the clip was chosen; otherwise written now while
        # the artwork shows (a key press stops it).
        loop=prepare_loop(path,stopped=lambda:win.closed or monitor.abortRequested())
        if win.closed or xbmc.Player().isPlaying():return
        win.setProperty('meganexus.saver.mode','video')
        if loop:
            path=loop  # no audio track: nothing to mute
        else:
            original=(rpc('Application.GetProperties',{'properties':['muted']}) or {}).get('muted')
            if original is False:
                if rpc('Application.SetMute',{'mute':True}) is True:muted_by_us=True
                else:path=''  # Silent video is required; do not play unexpected audio.
            elif original is not True:
                # Unknown sound state: display artwork rather than play audio.
                path=''
        begin=0;started=False;seek_guard=0.0;gone_since=0.0;remaining=None
        while not win.closed and not monitor.abortRequested():
            if path and (player is None or player.ended):
                if xbmc.Player().isPlaying():
                    # Kodi still reports "playing" for a moment after EOF, with no
                    # video left to own. Short clips looped once and then the
                    # screensaver closed; wait for the teardown instead.
                    if player and player.ended and time.monotonic()-player.ended_at<LOOP_RESTART_GRACE:
                        monitor.waitForAbort(.05);continue
                    break  # Another caller owns playback.
                if player:player.cancel();player._ended()
                player=VideoPlayer();player.token=uuid.uuid4().hex;player.path=path
                item=xbmcgui.ListItem(label='MegaNexus screensaver')
                item.setProperty('meganexus.preview',player.token);item.setProperty('IsPlayable','true')
                home.setProperty('meganexus.preview.active',player.token)
                home.setProperty('meganexus.preview.silent',player.token)
                begin=time.monotonic();started=False
                player.play(path,item,windowed=True)
            if player and path:
                now=time.monotonic()
                if player.failed or (not started and now-begin>8):
                    player.cancel();player.stop_owned();path=''
                    win.setProperty('meganexus.saver.video','');win.setProperty('meganexus.saver.mode','')
                elif player.owns() and player.ready:
                    started=True;gone_since=0.0;win.setProperty('meganexus.saver.video','1')
                    win.reveal()
                    # Seamless loop: rewind just before the end instead of letting
                    # Kodi close and reopen the file (that gap showed the artwork).
                    try:
                        total=player.getTotalTime();position=player.getTime()
                        remaining=total-position if total>2 else None
                        if remaining is not None and remaining<LOOP_SEEK_BEFORE_END and now>seek_guard:
                            player.seekTime(0);seek_guard=now+1.5;remaining=None
                    except Exception:remaining=None  # No duration yet: Kodi's EOF path still loops.
                elif started and player.isPlayingVideo() and not player.owns():break
                elif started and not player.ended and not player.isPlayingVideo():
                    if not gone_since:gone_since=now
                    elif now-gone_since>VIDEO_GAP_GRACE:break
            if not path or time.monotonic()>revealed_at:win.reveal()   # no video (yet): the artwork
            win.tick()
            monitor.waitForAbort(LOOP_FAST_POLL if remaining is not None and remaining<LOOP_FAST_WINDOW else .05)
    finally:
        # 7.0.29: the window goes first, then the video - stopping the video
        # first showed the window's own background for a moment.
        if win:win.close()
        if player:
            saver_state.cancel_play(player.token)
            player.cancel();player.stop_owned();player._ended()
            # The backend service rejects this exact item token if a queued
            # playback starts after this interpreter has already exited.
        if muted_by_us:
            try:
                current=(rpc('Application.GetProperties',{'properties':['muted']}) or {}).get('muted')
                if current is True:rpc('Application.SetMute',{'mute':False})
            except Exception:xbmc.log('[MegaNexus] Could not restore screensaver mute state.',xbmc.LOGWARNING)
        if home.getProperty(SHOWN)==token:home.clearProperty(SHOWN)
        if home.getProperty('meganexus.saver.active')==token:
            home.clearProperty('meganexus.saver.active');home.clearProperty('meganexus.saver.pending')
