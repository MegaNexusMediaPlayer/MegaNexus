# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus Sports screen (6.0.35, GitHub issue #8).

Only sports add-ons (resources.lib.sports). Rows are their catalogs (live and
today first). Resting on an event loads its streams into the glass box under
"Sports" and plays the first one in the small video; another stream can be
chosen in the box; OK on the event (or a stream) goes full screen and Back
returns here. Playback is a preview to the playback service, so sports never
reach Continue Watching or Trakt/Simkl. Header: Home (top of Sports),
Settings, HUB (leave).

Only LIVE events look for streams, after the cursor rests DWELL seconds;
upcoming events never do (not even on OK). Small player (default): OK
enlarges the video inside this window (OK there = live channels panel, Back =
small again); hold OK opens the stream choice (7.0.29 - the box of streams, left
only with Back) and Info Kodi's own full-screen player. Big player: Kodi's
player opens by itself after DWELL. A stream that cuts out reconnects. Back /
Esc never leave Sports - only the HUB button does.

7.0.24: every start and reconnect first asks the source itself (probe(), in
the background); Kodi gets the stream only once it answers, so an unavailable
source never brings Kodi's "Playback failed" window or its busy spinner - the
status stays inside the video, and after the retries the next stream is
tried. The live channels panel shows the streams of the channel under the
cursor next to it, to choose one.
"""
import queue
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qsl
from urllib.request import Request, urlopen
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import art_cache, sports
from resources.lib.settings_cache import cached_addon
from resources.lib.plain_text import without_emoji
from resources.lib.theme import folder as theme_folder
from .dialog import Dialog, BACK
from .home_trailers import PreviewPlayer
from . import listitems

ROW_BASE = 1000
MAX_ROWS = 20
STREAM_LIST = 700
FULL_BUTTON = 950            # covers the enlarged video (OK = live channels, Back = small)
CHANNEL_LIST = 960           # live channels panel over the enlarged video
CHANNEL_STREAMS = 961        # the streams of the channel under the cursor (7.0.24)
CHANNEL_DWELL = .6           # seconds on a channel before its streams load
PROBE_SECONDS = 6            # how long a source may take to answer before a start
DWELL = 5.0                  # seconds on a LIVE event before its streams load and play
AUTOPLAY_SETTING = 'meganexus_sport_autoplay'
PLAYER_SETTING = 'meganexus_sport_player'      # 'small' (default) | 'big'
PLAYER_LABELS = {'small': 'Small player · enlarge with OK, Info for Kodi\'s player',
                 'big': 'Big player · Kodi\'s full-screen player after 5 seconds'}
RECONNECT_DELAYS = (2, 3, 5, 8, 10, 10)    # seconds between reconnect attempts
HEALTHY_SECONDS = 30                       # playing this long resets the attempts
LOAD_WORKERS = 4
LOAD_SECONDS = 15
POSTERS_PER_ROW = 8
CONTEXT = (117, 101, 1009)                 # hold OK / menu: the stream choice (7.0.29)
INFO = (11,)                               # Info: Kodi's own full-screen player
# 7.0.29: what the keys do, at the bottom of the screen.
HINTS = {'rows': 'OK  Enlarge     Hold OK  Choose a stream     Info  Full-screen player     Back  HUB button',
         'streams': 'Up / Down  Choose     OK  Play this stream     Back  Return',
         'full': 'OK  Live channels     Hold OK  Choose a stream     Info  Full-screen player     Back  Small player',
         'channels': 'OK  Watch this channel     Right / Hold OK  Its streams     Back  Close',
         'channel_streams': 'Up / Down  Choose     OK  Play this stream     Back  Channels'}


def autoplay_enabled():
    return cached_addon().getSetting(AUTOPLAY_SETTING) != 'false'


def player_mode():
    return 'big' if cached_addon().getSetting(PLAYER_SETTING) == 'big' else 'small'


def probe(url, timeout=PROBE_SECONDS):
    """Does the source answer? (7.0.24) The playlist or the first bytes, with
    the stream's own headers. Only then is the stream handed to Kodi, which
    otherwise opens its modal "Playback failed" window for every failed try."""
    base, _, header_text = str(url or '').partition('|')
    if not base.startswith(('http://', 'https://')):
        return True        # local / plugin paths: Kodi knows best
    headers = {'User-Agent': xbmc.getUserAgent()}
    headers.update(dict(parse_qsl(header_text)))
    try:
        with urlopen(Request(base, headers=headers), timeout=timeout) as response:
            if getattr(response, 'status', 200) >= 400:
                return False
            data = response.read(65536)
    except Exception:
        return False
    if '.m3u8' in base.lower().split('?', 1)[0] or data.lstrip()[:7] == b'#EXTM3U':
        return b'#EXTM3U' in data[:2048]
    return bool(data)


def _hls_item(item, url):
    """Live HLS through inputstream.adaptive when installed: it rides out
    stalls instead of failing at the first gap. Returns the URL to play."""
    base, _, headers = url.partition('|')
    if '.m3u8' not in base.lower() or not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
        return url
    item.setProperty('inputstream', 'inputstream.adaptive')
    try:
        major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except ValueError:
        major = 21
    if major < 21:
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    if headers:
        item.setProperty('inputstream.adaptive.manifest_headers', headers)
        item.setProperty('inputstream.adaptive.stream_headers', headers)
    item.setMimeType('application/vnd.apple.mpegurl')
    item.setContentLookup(False)
    return base


class SportsPlayer(PreviewPlayer):
    """Ownership by the ListItem token: live HLS streams report another file
    path than the URL that was played. ``dropped`` = playback ended or failed
    without being asked to (buffer underrun, stream cut) - reconnect."""
    def __init__(self):
        super().__init__()
        self.dropped = False

    def owns(self):
        try:
            if not self.token or not self.isPlayingVideo():
                return False
            return self.getPlayingItem().getProperty('meganexus.preview') == self.token
        except Exception:
            return False

    def onAVStarted(self):
        super().onAVStarted()

    # Kodi tells every Python player about every stop: the video wallpaper
    # stopping for this stream is not this stream dropping (7.0.29).
    def onPlayBackStopped(self):
        if self.started_own and not self.cancelled:
            self.dropped = True
        self._ended()

    def onPlayBackEnded(self):
        if self.started_own and not self.cancelled:
            self.dropped = True
        self._ended()

    def onPlayBackError(self):
        if self.started_own or self.requested:
            self.failed = True
            if not self.cancelled:
                self.dropped = True
        self._ended(True)


class SportsWindow(Dialog):
    # Defaults of the 7.0.24 start / retry state (set again in __init__).
    retry_at = 0.0
    failed_at = 0.0
    pending = ''
    channel_hover = (None, 0.0)
    channel_streams = (None, [])

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.rows = list(kwargs.get('rows') or [])       # [(title, provider, catalog, items)]
        self.outcome = ''
        self.player = SportsPlayer()
        self.streams = []
        self.selection = None          # (row, pos) under the cursor
        self.changed = time.monotonic()
        self.stream_key = None         # event whose streams are shown/loading
        self.stream_job = None
        self.results = queue.Queue()
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='MegaNexusSportStreams')
        self.probes = ThreadPoolExecutor(max_workers=1, thread_name_prefix='MegaNexusSportProbe')
        self.playing_index = -1
        self.after_ready = ''          # '' | 'full' | 'native' once the stream shows
        self.retry_at = 0.0            # the next try of a stream that did not answer / cut out
        self.attempts = 0
        self.started_at = 0.0
        self.use_ia = True
        self.pending = ''              # the start waiting for its source to answer
        self.tried = set()             # streams of this event already given up on
        self.failed_at = 0.0
        self.channels = []
        self.channel_hover = (None, 0.0)
        self.channel_streams = (None, [])   # (event id, streams) shown next to the channels
        self._painted = False
        self.loading = bool(kwargs.get('loading'))

    # ---- painting ------------------------------------------------------
    def onInit(self):
        if not self._painted:
            self._paint()
            self._painted = True
        self.restore_focus()

    def _paint(self):
        shown = [r for r in self.rows if r[3]][:MAX_ROWS]
        catalogs = len(self.rows)
        self.rows = shown
        for i in range(MAX_ROWS):
            self.setProperty('meganexus.sport.row.%d' % i, without_emoji(shown[i][0]) if i < len(shown) else '')
            control = self.getControl(ROW_BASE + i)
            control.reset()
            if i < len(shown):
                control.addItems([self._item(item) for item in shown[i][3]])
        # Explicit vertical navigation (rows are hidden when empty).
        for i in range(len(shown)):
            control = self.getControl(ROW_BASE + i)
            control.controlUp(self.getControl(ROW_BASE + i - 1) if i else self.getControl(STREAM_LIST))
            control.controlDown(self.getControl(ROW_BASE + min(i + 1, len(shown) - 1)))
        if not shown and catalogs:
            # 7.0.12: sport catalogs exist (a sports add-on or e.g. AIOMetadata's) but list nothing now.
            self.setProperty('meganexus.sport.empty', 'No live or upcoming events right now in your %d sport catalogs. '
                                                  'They refresh every few minutes - open Sport again later.' % catalogs)
            self.setFocusId(101)
        elif not shown and self.loading:
            self.setProperty('meganexus.sport.empty','Loading live and upcoming events…')
            self.setFocusId(101)
        elif not shown:
            self.setProperty('meganexus.sport.empty', 'No sports add-on is installed. Add one in HUB Settings > Add-ons '
                                                  '(for example a manifest whose catalogs are of type "sport"). '
                                                  'Sports add-ons appear only here, never on the movie and series Home.')
            self.setFocusId(101)
        else:
            self.setProperty('meganexus.sport.empty', '')
            self.setFocusId(ROW_BASE)

    @staticmethod
    def _item(item):
        li = listitems.item(label=without_emoji(item['title']))
        li.setArt({'thumb': art_cache.card(item.get('art'))})
        li.setProperty('live', '1' if item.get('live') else '')
        return li

    def _selected(self):
        cid = self.getFocusId()
        index = cid - ROW_BASE
        if not 0 <= index < len(self.rows):
            return None
        pos = self.getControl(cid).getSelectedPosition()
        items = self.rows[index][3]
        return (index, pos) if 0 <= pos < len(items) else None

    def _event(self, selection):
        """The event under a (row, pos) - None when the rows changed meanwhile (7.0.29:
        a refresh of the catalogs left an old selection behind and Sport closed)."""
        if not selection:
            return None
        index, pos = selection
        if not 0 <= index < len(self.rows) or not 0 <= pos < len(self.rows[index][3]):
            return None
        return self.rows[index][3][pos]

    def _describe(self, selection):
        event = self._event(selection)
        if event is None:
            return
        self.setProperty('meganexus.sport.title', without_emoji(event['title']))
        self.setProperty('meganexus.sport.info', ' · '.join(x for x in (event.get('info'), self.rows[selection[0]][0]) if x))
        self.setProperty('meganexus.sport.bg', art_cache.url(event.get('background') or event.get('art') or ''))

    # ---- streams -------------------------------------------------------
    def _show_streams(self, rows, status=''):
        control = self.getControl(STREAM_LIST)
        control.reset()
        items = []
        for i, stream in enumerate(rows):
            li = listitems.item(label=stream['label'], label2=stream.get('detail') or '')
            li.setProperty('playing', 'Playing' if i == self.playing_index else '')
            items.append(li)
        control.addItems(items)
        self.setProperty('meganexus.sport.streams_status', status if not rows else '')

    def _request_streams(self, key, event, after=''):
        self.stream_key = key
        self.streams = []
        self.playing_index = -1
        self.after_ready = after
        self._show_streams([], 'Loading streams…')

        def work():
            try:
                found = sports.streams(event)
            except Exception:
                found = []
            self.results.put((key, found))
        self.stream_job = self.pool.submit(work)

    def _play(self, index, after='', keep_view=False, reconnect=False):
        """Start stream index - once its source answers (probe in the background)."""
        if not 0 <= index < len(self.streams):
            return
        self._stop_preview(keep_view=keep_view)
        if not reconnect:
            self.attempts = 0
            self.use_ia = True
            self.tried = set()
        self.playing_index = index
        self.after_ready = after
        self.retry_at = 0.0
        self.started_at = 0.0
        self.setProperty('meganexus.preview.loading', '1')
        if not reconnect:
            self.setProperty('meganexus.sport.video_status', 'Connecting…')
        token = uuid.uuid4().hex
        self.pending = token
        url = self.streams[index]['url']
        results = self.results
        self.probes.submit(lambda: results.put(('probe', token, index, probe(url))))
        self._show_streams(self.streams)

    def _start(self, index):
        """The source answered: hand the stream to Kodi."""
        stream = self.streams[index]
        token = uuid.uuid4().hex
        self.player = SportsPlayer()
        self.player.token = token
        item = listitems.item(label=self.getProperty('meganexus.sport.title') or 'Sports')
        item.setProperty('meganexus.preview', token)
        item.setProperty('IsPlayable', 'true')
        url = _hls_item(item, stream['url']) if self.use_ia else stream['url']
        home = xbmcgui.Window(10000)
        # A preview to the playback service: no progress, no tracking - and
        # no Kodi busy spinner over Sports (the status shows in the video).
        home.setProperty('meganexus.preview.active', token)
        home.setProperty('meganexus.preview.silent', token)
        self.player.path = url
        from resources.lib.wallpaper_video import suspend
        suspend()
        from resources.lib import refresh_guard
        refresh_guard.suspend('sports')   # no TV mode switch (issue #4)
        self.player.requested = True
        self.player.play(url, item, windowed=True)

    def _stop_preview(self, keep_view=False):
        if not keep_view:
            self._small()
        from resources.lib import refresh_guard
        if not keep_view:
            refresh_guard.restore('sports')
        self.player.cancel()
        self.player.stop_owned()
        self.player._ended()
        self.pending = ''
        xbmcgui.Window(10000).clearProperty('meganexus.preview.silent')
        self.setProperty('meganexus.preview', '')
        self.setProperty('meganexus.preview.loading', '')
        self.setProperty('meganexus.sport.video_status', '')
        self.after_ready = ''
        self.retry_at = 0.0

    def _retry(self, now, reason):
        """The source did not answer or the stream cut out: try again quietly,
        a few times with growing pauses, then the next stream of the event."""
        self.player.token = ''
        self.setProperty('meganexus.preview', '')
        if self.attempts >= len(RECONNECT_DELAYS):
            self.tried.add(self.playing_index)
            following = [i for i in range(len(self.streams)) if i not in self.tried]
            if following:
                index = following[0]
                self.attempts = 0
                self.setProperty('meganexus.sport.video_status', 'Stream unavailable · trying stream %d' % (index + 1))
                self._play(index, after=self.after_ready, keep_view=True, reconnect=True)
            else:
                self.playing_index = -1
                self.setProperty('meganexus.preview.loading', '')
                self.setProperty('meganexus.sport.video_status', 'No stream answers right now · choose one in the list')
                self._show_streams(self.streams)
            return
        delay = RECONNECT_DELAYS[self.attempts]
        self.retry_at = now + delay
        self.setProperty('meganexus.preview.loading', '1')
        self.setProperty('meganexus.sport.video_status', '%s · trying again (%d/%d)' % (reason, self.attempts + 1, len(RECONNECT_DELAYS)))

    def _close_failed_dialog(self, now):
        """A stream that answered the probe and still failed to open: Kodi's
        modal "Playback failed" window is closed (only right after our own try)."""
        if not self.failed_at or now - self.failed_at > 10:
            self.failed_at = 0.0
            return
        if (xbmc.getCondVisibility('Window.IsActive(okdialog)') and
                xbmc.getInfoLabel('Control.GetLabel(1)') == xbmc.getLocalizedString(16026)):
            xbmc.executebuiltin('Dialog.Close(okdialog)')
            self.failed_at = 0.0

    # ---- loop ------------------------------------------------------------
    def tick(self):
        now = time.monotonic()
        selection = self._selected()
        if selection is not None and selection != self.selection:
            self.selection = selection
            self.changed = now
            event = self._event(selection)
            self._describe(selection)
            # The box shows only the streams of the event under the cursor:
            # another event's stream names stayed and overlapped the status.
            if (selection, event['id']) == self.stream_key:
                self._show_streams(self.streams, '' if self.streams else 'Loading streams…')
            elif not event.get('live'):
                self._show_streams([], 'Not live yet. Streams appear when the event starts.')
            else:
                self._show_streams([], 'Live · streams load in a moment…')
        if self.selection is not None and self.getFocusId() != STREAM_LIST and self.getProperty('meganexus.sport.full') != '1':
            event = self._event(self.selection)
            if event is None:
                self.selection = None
                return
            key = (self.selection, event['id'])
            # Only live events, and only after the cursor rested DWELL seconds.
            if event.get('live') and key != self.stream_key and now - self.changed >= DWELL:
                self._stop_preview()
                self._request_streams(key, event, 'native' if player_mode() == 'big' else '')
        while not self.results.empty():
            result = self.results.get_nowait()
            if result[0] == 'catalogs':
                focus=self.getFocusId()
                try:spot=self.getControl(focus).getSelectedPosition() if ROW_BASE<=focus<ROW_BASE+MAX_ROWS else -1
                except Exception:spot=-1
                self.loading=False;self.rows=result[1];self._paint()
                if focus in (101,107,108):self.setFocusId(focus)
                elif spot>=0 and focus-ROW_BASE<len(self.rows):
                    # 7.0.29: the fresh pages land under the cursor without moving it
                    self.setFocusId(focus)
                    try:self.getControl(focus).selectItem(min(spot,len(self.rows[focus-ROW_BASE][3])-1))
                    except Exception:pass
                continue
            if result[0] == 'probe':
                _, token, index, answered = result
                if token != self.pending or index != self.playing_index:
                    continue
                self.pending = ''
                if answered:
                    self._start(index)
                else:
                    self._retry(now, 'Source unavailable')
                continue
            if result[0] == 'channel':
                _, event_id, found = result
                if self.channel_streams[0] == event_id:
                    self.channel_streams = (event_id, found)
                    self._show_channel_streams()
                continue
            key, found = result
            if key != self.stream_key:
                continue
            self.streams = found
            self._show_streams(found, '' if found else 'No streams for this event right now.')
            if found and (autoplay_enabled() or self.after_ready):
                self._play(0, after=self.after_ready, keep_view=self.getProperty('meganexus.sport.full') == '1')
        self._channel_tick(now)
        self._hint()
        self._close_failed_dialog(now)
        if self.retry_at and now >= self.retry_at:
            self.retry_at = 0.0
            self.attempts += 1
            self._play(self.playing_index, after=self.after_ready, keep_view=True, reconnect=True)
            return
        if not self.player.token:
            return
        if self.player.dropped or (self.player.failed and not self.player.owns()):
            if self.player.failed:
                self.failed_at = now
                if self.use_ia and not self.started_at:
                    self.use_ia = False      # this stream may not like inputstream.adaptive
            self._retry(now, 'Reconnecting')
        elif self.player.owns() and (self.player.ready or self.player.getTime() > .15):
            if not self.started_at:
                self.started_at = now
            elif now - self.started_at > HEALTHY_SECONDS:
                self.attempts = 0
            self.setProperty('meganexus.preview', '1')
            self.setProperty('meganexus.preview.loading', '')
            self.setProperty('meganexus.sport.video_status', '')
            after, self.after_ready = self.after_ready, ''
            if after == 'full':
                self._fullscreen()
            elif after == 'native':
                self._native()

    # ---- views -------------------------------------------------------------
    def _fullscreen(self):
        """The same player, enlarged inside this window: seamless, no new
        playback and no TV mode switch."""
        if self.getProperty('meganexus.sport.full') == '1':
            return
        self._return_focus = self.getFocusId()
        self.setProperty('meganexus.sport.full', '1')
        self.setFocusId(FULL_BUTTON)

    def _small(self):
        self._hide_channels()
        if self.getProperty('meganexus.sport.full') != '1':
            return
        self.setProperty('meganexus.sport.full', '')
        try:
            self.setFocusId(getattr(self, '_return_focus', 0) or ROW_BASE)
        except Exception:
            self.setFocusId(ROW_BASE)

    def _native(self):
        """Kodi's own full-screen player for the stream that plays (hold OK, or
        the Big player). This window steps aside - Kodi's player would open
        under it - and comes back when the player is left."""
        if not self.player.owns():
            return
        from .home_trailers import view_mode
        view_mode('normal')                # the whole picture in Kodi's own player
        monitor = xbmc.Monitor()
        self._child_active = True
        try:
            xbmcgui.WindowXMLDialog.close(self)
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            seen, start = False, time.monotonic()
            while not monitor.abortRequested():
                full = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                seen = seen or full
                if (seen and not full) or (not seen and time.monotonic() - start > 5):
                    break
                if monitor.waitForAbort(.1):
                    break
        finally:
            if not self.player.owns():
                # Stopped in Kodi's player on purpose: no reconnect.
                self.player.cancelled = True
                self.player.dropped = False
                self.player.token = ''
                self.setProperty('meganexus.preview', '')
                self.setProperty('meganexus.preview.loading', '')
            if not self._dialog_closed and not monitor.abortRequested():
                self.show_ready()
            self._child_active = False

    # ---- live channels over the enlarged video ---------------------------
    def _live_channels(self):
        seen, result = set(), []
        for index, row in enumerate(self.rows):
            for pos, item in enumerate(row[3]):
                if item.get('live') and item['id'] not in seen:
                    seen.add(item['id'])
                    result.append(((index, pos), item, row[0]))
        return result

    def _show_channels(self):
        self.channels = self._live_channels()
        control = self.getControl(CHANNEL_LIST)
        control.reset()
        items = []
        current = (self._event(self.selection) or {}).get('id', '')
        for _, item, row_title in self.channels:
            li = listitems.item(label=without_emoji(item['title']), label2=without_emoji(row_title))
            li.setArt({'thumb': art_cache.card(item.get('art'))})
            li.setProperty('playing', 'Playing' if item['id'] == current else '')
            items.append(li)
        control.addItems(items)
        playing = next((i for i, c in enumerate(self.channels) if c[1]['id'] == current), 0)
        if items:
            control.selectItem(playing)
        self.channel_hover = (None, 0.0)
        self.channel_streams = (None, [])
        self.getControl(CHANNEL_STREAMS).reset()
        self.setProperty('meganexus.sport.channel_streams_status', '')
        self.setProperty('meganexus.sport.channels', '1')
        self.setFocusId(CHANNEL_LIST)

    def _channel_tick(self, now):
        """The streams of the channel under the cursor, next to the channel list."""
        if self.getProperty('meganexus.sport.channels') != '1' or self.getFocusId() != CHANNEL_LIST:
            return
        pos = self.getControl(CHANNEL_LIST).getSelectedPosition()
        if not 0 <= pos < len(self.channels):
            return
        if self.channel_hover[0] != pos:
            self.channel_hover = (pos, now)
            return
        if now - self.channel_hover[1] < CHANNEL_DWELL:
            return
        selection, event, _ = self.channels[pos]
        if self.channel_streams[0] == event['id']:
            return
        if self.stream_key == (selection, event['id']) and self.streams:
            self.channel_streams = (event['id'], list(self.streams))
            self._show_channel_streams()
            return
        self.channel_streams = (event['id'], None)
        self._show_channel_streams()
        results = self.results

        def work():
            try:
                found = sports.streams(event)
            except Exception:
                found = []
            results.put(('channel', event['id'], found))
        self.pool.submit(work)

    def _show_channel_streams(self):
        event_id, rows = self.channel_streams
        control = self.getControl(CHANNEL_STREAMS)
        control.reset()
        current = (self._event(self.selection) or {}).get('id', '')
        items = []
        for i, stream in enumerate(rows or []):
            li = listitems.item(label=stream['label'], label2=stream.get('detail') or '')
            li.setProperty('playing', 'Playing' if event_id == current and i == self.playing_index else '')
            items.append(li)
        control.addItems(items)
        status = 'Loading streams…' if rows is None else ('' if rows else 'No streams for this channel right now.')
        self.setProperty('meganexus.sport.channel_streams_status', status)

    def _play_channel_stream(self):
        """OK on a stream next to the channels: that channel, that stream."""
        index = self.getControl(CHANNEL_STREAMS).getSelectedPosition()
        pos = self.getControl(CHANNEL_LIST).getSelectedPosition()
        event_id, rows = self.channel_streams
        if not rows or not 0 <= index < len(rows) or not 0 <= pos < len(self.channels):
            return
        selection, event, _ = self.channels[pos]
        if event['id'] != event_id:
            return
        self._hide_channels()
        self.selection = selection
        self._describe(selection)
        try:
            self.getControl(ROW_BASE + selection[0]).selectItem(selection[1])
            self._return_focus = ROW_BASE + selection[0]
        except Exception:
            pass
        self.stream_key = (selection, event['id'])
        self.streams = list(rows)
        self._play(index, keep_view=True)

    def _hide_channels(self):
        if self.getProperty('meganexus.sport.channels') == '1':
            self.setProperty('meganexus.sport.channels', '')
            if self.getProperty('meganexus.sport.full') == '1':
                self.setFocusId(FULL_BUTTON)

    def _switch_channel(self):
        pos = self.getControl(CHANNEL_LIST).getSelectedPosition()
        if not 0 <= pos < len(self.channels):
            return
        selection, event, _ = self.channels[pos]
        self._hide_channels()
        self.selection = selection
        self._describe(selection)
        try:
            self.getControl(ROW_BASE + selection[0]).selectItem(selection[1])
            self._return_focus = ROW_BASE + selection[0]
        except Exception:
            pass
        key = (selection, event['id'])
        if key != self.stream_key:
            self._stop_preview(keep_view=True)
            self._request_streams(key, event, '')

    # ---- input -----------------------------------------------------------
    def _open_event(self, native=False):
        selection = self._selected()
        if selection is None:
            return
        event = self._event(selection)
        if not event.get('live'):
            xbmcgui.Dialog().notification('Sports', 'Not live yet. Streams appear when the event starts.', time=3000)
            return
        key = (selection, event['id'])
        target = 'native' if native else 'full'
        if key == self.stream_key and self.player.owns():
            self._native() if native else self._fullscreen()
        elif key == self.stream_key and self.player.token and not self.player.dropped:
            self.after_ready = target
        elif key == self.stream_key and self.streams:
            self._play(max(0, self.playing_index), after=target)
        else:
            self.selection = selection
            self._request_streams(key, event, target)

    def onClick(self, cid):
        if cid == FULL_BUTTON:
            self._show_channels()     # OK on the enlarged video: live channels
            return
        if cid == CHANNEL_LIST:
            self._switch_channel()
            return
        if cid == CHANNEL_STREAMS:
            self._play_channel_stream()
            return
        if cid == 108:
            self.outcome = 'hub'      # the only way out of Sports
            self.close()
        elif cid == 101:
            self._stop_preview()
            if self.rows:
                self.getControl(ROW_BASE).selectItem(0)
                self.setFocusId(ROW_BASE)
        elif cid == 107:
            self._stop_preview()
            from .settings import run
            self.over(run)   # Sports stays visible behind the glass settings
        elif cid == STREAM_LIST:
            index = self.getControl(STREAM_LIST).getSelectedPosition()
            if index == self.playing_index and self.player.owns():
                self._fullscreen()     # OK on the stream that plays: enlarge
            elif index == self.playing_index and self.player.token and not self.player.dropped:
                self.after_ready = 'full'
            else:
                self._play(index)
        elif ROW_BASE <= cid < ROW_BASE + len(self.rows):
            self._open_event()

    def _hint(self):
        cid = self.getFocusId()
        if cid == STREAM_LIST:
            key = 'streams'
        elif cid == CHANNEL_STREAMS:
            key = 'channel_streams'
        elif self.getProperty('meganexus.sport.channels') == '1':
            key = 'channels'
        elif self.getProperty('meganexus.sport.full') == '1':
            key = 'full'
        else:
            key = 'rows'
        if self.getProperty('meganexus.sport.hint') != HINTS[key]:
            self.setProperty('meganexus.sport.hint', HINTS[key])

    def _stream_box(self):
        """Hold OK: into the box of streams (7.0.29); only Back leaves it."""
        cid = self.getFocusId()
        if cid == CHANNEL_LIST:
            self.setFocusId(CHANNEL_STREAMS)
        elif cid == FULL_BUTTON:
            # The channels panel, with the playing channel's streams chosen.
            self._show_channels()
            current = (self._event(self.selection) or {}).get('id', '')
            if current and self.streams and self.stream_key and self.stream_key[1] == current:
                self.channel_streams = (current, list(self.streams))
                self._show_channel_streams()
                if self.playing_index >= 0:
                    self.getControl(CHANNEL_STREAMS).selectItem(self.playing_index)
                self.setFocusId(CHANNEL_STREAMS)
        elif ROW_BASE <= cid < ROW_BASE + len(self.rows):
            selection = self._selected()
            if selection is None:
                return
            event = self._event(selection)
            if not event.get('live'):
                xbmcgui.Dialog().notification('Sports', 'Not live yet. Streams appear when the event starts.', time=3000)
                return
            key = (selection, event['id'])
            if key != self.stream_key:
                self.selection = selection
                self._stop_preview()
                self._request_streams(key, event, '')
            self._box_return = cid
            self.setFocusId(STREAM_LIST)

    def onAction(self, action):
        aid = action.getId()
        if aid in BACK:
            # 7.0.29: a box of streams is left only with Back - to where it was opened.
            cid = self.getFocusId()
            if cid == CHANNEL_STREAMS:
                self.setFocusId(CHANNEL_LIST)
                return
            if cid == STREAM_LIST:
                back = getattr(self, '_box_return', 0) or ROW_BASE
                try:
                    self.setFocusId(back)
                except Exception:
                    self.setFocusId(ROW_BASE)
                return
            # Back / Esc never leave Sports: channels -> enlarged -> small -> HUB button.
            if self.getProperty('meganexus.sport.channels') == '1':
                self._hide_channels()
            elif self.getProperty('meganexus.sport.full') == '1':
                self._small()
            else:
                self.setFocusId(108)
            return
        if aid in CONTEXT:
            self._stream_box()
            return
        if aid in INFO:
            # Info: Kodi's own full-screen player.
            cid = self.getFocusId()
            if cid in (FULL_BUTTON, CHANNEL_LIST, CHANNEL_STREAMS, STREAM_LIST):
                self._native()
            elif ROW_BASE <= cid < ROW_BASE + len(self.rows):
                self._open_event(native=True)

    def close(self):
        self.cancelled=True
        self._stop_preview()
        self.pool.shutdown(wait=False)
        self.probes.shutdown(wait=False)
        super().close()


# ---- opening ---------------------------------------------------------------

def _load(window, monitor):
    """Catalog pages (cached at once, missing/stale ones from the add-ons) and
    the first posters into the image RAM. Back skips."""
    from concurrent.futures import ThreadPoolExecutor as Pool
    pairs = sports.catalogs()
    rows, todo = [], []
    for provider, catalog in pairs:
        metas, fresh = sports.cached_page(provider, catalog)
        rows.append([str(catalog.get('name') or catalog['id']), provider, catalog, metas or []])
        todo.append(len(rows) - 1)   # 7.0.29: every entry asks every catalog again (events change)
    if todo:
        pool = Pool(max_workers=LOAD_WORKERS, thread_name_prefix='MegaNexusSportsLoad')
        futures = {pool.submit(sports.load_page, rows[i][1], rows[i][2]): i for i in todo}
        deadline = time.monotonic() + LOAD_SECONDS
        try:
            while futures and not window.cancelled and time.monotonic() < deadline:
                for future in [f for f in futures if f.done()]:
                    index = futures.pop(future)
                    try:
                        fresh = future.result()
                        if fresh or not rows[index][3]:
                            rows[index][3] = fresh   # an empty answer keeps what is shown
                    except Exception:
                        pass
                window.setProperty('meganexus.ring', '%02d' % min(19, (len(pairs) - len(futures)) * 20 // max(1, len(pairs))))   # 7.0.10: ring, no text
                if monitor.waitForAbort(.05):
                    break
        finally:
            for future in futures:
                future.cancel()
            pool.shutdown(wait=False)
    result = []
    for title, provider, catalog, metas in rows:
        items = []
        for meta in metas:
            try:
                items.append(sports.card(provider, catalog, meta))
            except Exception:
                continue
        result.append((title, provider, catalog, items))
    base = xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
    if base.startswith('http://127.0.0.1:') and not window.cancelled:
        # 7.0.7: no poster screen. Posters Kodi keeps on its disk are skipped;
        # the others load into the image RAM while the screen is already open.
        from .kodi_textures import cached, proxy_url
        kodi_has = cached(base)
        urls = [url for url in sports.poster_urls([r[3] for r in result], POSTERS_PER_ROW) if proxy_url(base, url) not in kodi_has]
        if urls:
            threading.Thread(target=_warm, args=(base, urls), name='MegaNexusSportPosters', daemon=True).start()
    return result


def settings_cache_invalidate():
    try:
        from resources.lib import settings_cache
        settings_cache.invalidate()
    except Exception:
        pass


def _cached_rows():
    """The Sport rows from cached pages only (no network)."""
    result = []
    for provider, catalog in sports.catalogs():
        metas, _ = sports.cached_page(provider, catalog)
        items = []
        for meta in metas or []:
            try:
                items.append(sports.card(provider, catalog, meta))
            except Exception:
                continue
        result.append((str(catalog.get('name') or catalog['id']), provider, catalog, items))
    return result


def _warm(base, urls):
    """Sports posters go into the same image RAM as Home's posters."""
    from urllib.parse import quote
    from urllib.request import Request, urlopen
    from concurrent.futures import ThreadPoolExecutor as Pool

    def head(url):
        try:
            with urlopen(Request(base + '/image?url=' + quote(url, safe=''), method='HEAD'), timeout=4) as response:
                response.read(0)
        except Exception:
            pass
    pool = Pool(max_workers=3, thread_name_prefix='MegaNexusSportPoster')
    try:
        for url in urls:
            pool.submit(head, url)
    finally:
        pool.shutdown(wait=True)   # a short, bounded list: the thread ends with it


def open_sports():
    # The real screen is visible before catalog/network work begins. No loading
    # window, black frame or modal busy spinner between the HUB and Sport.
    win = SportsWindow('meganexus_sports.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i', rows=[], loading=True)
    win.cancelled=False
    class Ticket:
        @property
        def cancelled(self):return win.cancelled
        def setProperty(self,*args):pass  # background jobs never paint the UI
    def load():
        try:
            sports.ensure_enabled()
            # 7.0.29: what is cached shows at once; the add-ons' fresh pages follow
            # (Sport waited for every catalog before showing anything).
            quick=_cached_rows()
            if quick and any(r[3] for r in quick) and not win.cancelled:win.results.put(('catalogs',quick))
            # 7.0.29: the sport add-ons' catalogs may have changed - their manifests first
            try:
                if sports.refresh_manifests(lambda:win.cancelled):settings_cache_invalidate()
            except Exception:
                xbmc.log('[MegaNexus] Sport manifests not refreshed.',xbmc.LOGINFO)
            rows=_load(Ticket(),xbmc.Monitor())
        except Exception:
            rows=[]
            xbmc.log('[MegaNexus] Sports catalogs unavailable.',xbmc.LOGWARNING)
        if not win.cancelled:win.results.put(('catalogs',rows))
    try:
        win.pool.submit(load)
        win.doModal()
        return win.outcome
    finally:
        win.close()
