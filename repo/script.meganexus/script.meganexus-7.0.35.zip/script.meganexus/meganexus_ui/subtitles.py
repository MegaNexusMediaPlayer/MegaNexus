# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import xbmc
import xbmcgui
from resources.lib import cache_store,meganexus_subtitles
from .system_setup import rpc
from .playback import job,plain_label

def pick(rows,playerid,context,request_id,enabled=False):
    groups=meganexus_subtitles.group_rows(rows)
    langs=sorted(groups,key=lambda x:(x!='hr',meganexus_subtitles.NAMES.get(x,x)))
    if not langs and not enabled:xbmcgui.Dialog().ok('Subtitles','No subtitle files were returned. Try searching your subtitle add-ons.');return
    dialog=xbmcgui.Dialog()
    off=['Subtitles off'] if enabled else []
    index=dialog.select('Subtitle language',off+[meganexus_subtitles.NAMES.get(l,l)+' · '+str(len(groups[l]))+' versions' for l in langs])
    if index<0:return
    if off:
        if index==0:
            xbmc.Player().showSubtitles(False);return
        index-=1
    candidates=groups[langs[index]];labels=[]
    title=meganexus_subtitles.NAMES.get(langs[index],langs[index])
    for i,row in enumerate(candidates):
        release=plain_label(row.get('displayName') or row.get('name') or row.get('release') or row.get('filename')) or 'Version '+str(i+1)
        source=plain_label(row.get('sourceName') or ('Embedded track' if row.get('embedded') else 'Subtitle provider'))
        labels.append('%d. %s — %s'%(i+1,release,source))
    player=xbmc.Player()
    while True:
        index=dialog.select(title,labels)
        if index<0:return
        row=candidates[index]
        if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
        if row.get('embedded'):
            rpc('Player.SetSubtitle',{'playerid':playerid,'subtitle':row['index'],'enable':True})
            meganexus_subtitles.remember_active('')   # the video's own track: nothing to sync
            return
        try:path=job(lambda:meganexus_subtitles.prepare_selected(row,context.get('video_id') or context.get('canonical_id') or 'selected'),label='Loading the subtitle…',quiet=True)
        except ValueError:
            # 7.0.29: its server did not deliver it - the list comes back for another version
            xbmcgui.Dialog().notification('Subtitles','This version could not be downloaded - choose another.',time=3500)
            labels[index]='✕ '+labels[index].lstrip('✕ ')
            continue
        if not path:return
        break
    # Downloads can finish after a channel/title switch. Never apply to another video.
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    player.setSubtitles(path);player.showSubtitles(True)
    meganexus_subtitles.remember_active(path,row)

def run():
    try:
        active=next((p for p in rpc('Player.GetActivePlayers') or [] if p['type']=='video'),None)
        if not active:return
        playerid=active['playerid'];player=xbmc.Player();request_id=player.getPlayingItem().getProperty('meganexus.request')
        xbmcgui.Window(10000).setProperty('meganexus.subtitle.manual',request_id)
        key=xbmcgui.Window(10000).getProperty('meganexus.subtitle.context')
        context=cache_store.get('meganexus_play',key) or {}
        if context.get('meganexus_request_id')!=request_id:context={}
        props=rpc('Player.GetProperties',{'playerid':playerid,'properties':['subtitles','subtitleenabled']}) or {}
        embedded=[dict(s,embedded=True,sourceName='Embedded track',lang=s.get('language')) for s in props.get('subtitles') or []]
        # 7.0.24: the player's subtitle button searches every subtitle add-on at
        # once and lists all versions (the timing has its own button).
        if context:
            rows=job(lambda:meganexus_subtitles.external_rows(context,search=True),label='Searching subtitles…',quiet=True)
            if rows is None:return
            rows=embedded+rows
        else:rows=embedded   # not started through MegaNexus: the video's own tracks
        pick(rows,playerid,context,request_id,enabled=props.get('subtitleenabled'))
    except Exception as exc:
        xbmcgui.Dialog().ok('Subtitles',str(exc) if isinstance(exc,ValueError) else 'Subtitle selection could not finish. Try another file or provider.')


def autosync():
    """7.0.29: the player's Autosync subtitle button - retime the subtitle on screen."""
    player=xbmc.Player()
    if not player.isPlayingVideo():return
    request_id=player.getPlayingItem().getProperty('meganexus.request')
    key=xbmcgui.Window(10000).getProperty('meganexus.subtitle.context')
    context=cache_store.get('meganexus_play',key) or {}
    if context.get('meganexus_request_id')!=request_id:context={}
    if not context:
        xbmcgui.Dialog().notification('Autosync subtitle','Works on titles started in MegaNexus.',time=4000);return
    try:result=job(lambda:meganexus_subtitles.autosync(context,context.get('video_id') or context.get('canonical_id') or 'sync'),label='Syncing subtitles…',quiet=True)
    except ValueError as exc:
        xbmcgui.Dialog().ok('Autosync subtitle',str(exc));return
    if not result:return
    path,what=result
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    if not what.startswith('Already in sync'):
        player.setSubtitles(path);player.showSubtitles(True)
        xbmcgui.Window(10000).setProperty('meganexus.subtitle.path',path)
    xbmcgui.Dialog().notification('Autosync subtitle',what,time=5000)
