# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from .dialog import Dialog
"""Channel browser with EPG and two-click preview/fullscreen playback."""
import time
import queue
import threading
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from .system_setup import rpc,ensure_addon
from .playback import plain_label,job
from . import listitems
from resources.lib.iptv_config import xtream_urls,write_instance,apply_features,ensure_client_enabled
from resources.lib.theme import folder as theme_folder
from resources.lib.settings_cache import cached_addon

ADDON=cached_addon()
_CHANNEL_CACHE=OrderedDict()
_CHANNEL_LOCK=threading.Lock()

TIMESHIFT='meganexus_iptv_timeshift'      # 7.0.29, opt-in: inputstream.ffmpegdirect asks an offline
                                          # channel on Kodi's GUI thread (30 s freezes, seen on a PC)
CATCHUP='meganexus_iptv_catchup'          # 7.0.29, default on
CATCHUP_WAIT=20                           # seconds an archive programme may take to show a picture
FEATURES_APPLIED='meganexus_iptv_features'   # '2': timeshift opt-in (7.0.29 test builds wrote it on)

# 7.0.32: as in Sport - OK on the channel that plays enlarges it in this window
# (the same playback, no new start, no display mode switch); OK there = the
# group's channels with the catch-up of the channel under the cursor beside them.
FULL_BUTTON=950
CHANNEL_LIST=960
ARCHIVE_LIST=961
CHANNEL_DWELL=.6          # seconds on a channel before its catch-up loads
ARCHIVE_HOURS=24          # the catch-up shown: this far back
INFO=(11,)                # Info: Kodi's own full-screen player
STOP=(13,)                # Stop stops the channel; Back never does
HINTS={'guide':'OK  Preview, again to enlarge     Info  Full-screen player     Back  HUB button',
       'full':'OK  Channels and catch-up     Info  Full-screen player     Back  Small video',
       'channels':'OK  Switch channel     Right  Catch-up     Back  Close',
       'archive':'OK  Play from the archive     Left  Channels     Back  Channels'}


def feature_on(key):
    if key==TIMESHIFT:return ADDON.getSetting(key)=='true'
    return ADDON.getSetting(key)!='false'


def apply_iptv_features(quiet=False):
    """Write timeshift / catch-up into MegaNexus' IPTV Simple instance (Kodi reloads the channels)."""
    instance=ADDON.getSetting('meganexus_iptv_instance')
    if not instance or xbmc.getCondVisibility('Pvr.IsPlayingTV'):return False
    if feature_on(TIMESHIFT) and not ensure_addon('inputstream.ffmpegdirect'):return False
    profile=xbmcvfs.translatePath(xbmcaddon.Addon('pvr.iptvsimple').getAddonInfo('profile'))
    rpc('Addons.SetAddonEnabled',{'addonid':'pvr.iptvsimple','enabled':False})
    try:done=apply_features(profile,instance,feature_on(TIMESHIFT),feature_on(CATCHUP))
    finally:ensure_client_enabled(rpc)
    if done:
        ADDON.setSetting(FEATURES_APPLIED,'2')
        if not quiet:xbmcgui.Dialog().notification('Live TV','Saved - the channels reload in a moment.',time=3000)
    return done


def configure():
    """IPTV setup chooser (translucent settings page, 7.0); 7.0.29: timeshift and catch-up."""
    from . import settings_page as page
    def build():return [('xtream',page.item('Xtream account')),('m3u',page.item('M3U playlist + XMLTV TV guide')),
                        ('pvr',page.item('Use an existing Kodi PVR setup')),
                        ('timeshift',page.item('Pause and rewind live TV (timeshift) · experimental: a channel that does not answer can freeze Kodi',enabled=feature_on(TIMESHIFT))),
                        ('catchup',page.item('Catch-up: past programmes in the guide, when the playlist offers an archive',enabled=feature_on(CATCHUP)))]
    def act(key):
        if key=='pvr':return page.DONE
        if key in ('timeshift','catchup'):
            setting={'timeshift':TIMESHIFT,'catchup':CATCHUP}[key]
            ADDON.setSetting(setting,'false' if feature_on(setting) else 'true')
            if configured():apply_iptv_features()
            return None
        return page.DONE if setup(key) else None
    page.keyed('IPTV setup',build,act)
    return configured()


def configured():
    return ADDON.getSetting('meganexus_iptv_configured')=='true'


def setup(kind):
    """'xtream' or 'm3u': ask the details and write MegaNexus' IPTV Simple instance."""
    dialog=xbmcgui.Dialog()
    if xbmc.getCondVisibility('Pvr.IsPlayingTV'):
        dialog.ok('IPTV','Stop live TV before changing the playlist.');return False
    choice=0 if kind=='xtream' else 1
    if choice==0:
        server=dialog.input('Xtream server URL including port').strip()
        if not server:return False
        username=dialog.input('Xtream username').strip()
        password=dialog.input('Xtream password',option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not username or not password:return False
        m3u,epg=xtream_urls(server,username,password)
    else:
        m3u=dialog.input('M3U playlist URL').strip()
        if not m3u:return False
        epg=dialog.input('XMLTV EPG URL (optional if supplied in the playlist)').strip()
    if not ensure_addon('pvr.iptvsimple'):return False
    profile=xbmcvfs.translatePath(xbmcaddon.Addon('pvr.iptvsimple').getAddonInfo('profile'))
    rpc('Addons.SetAddonEnabled',{'addonid':'pvr.iptvsimple','enabled':False})
    try:
        if feature_on(TIMESHIFT):ensure_addon('inputstream.ffmpegdirect')
        iid=write_instance(profile,m3u,epg,ADDON.getSetting('meganexus_iptv_instance'),feature_on(TIMESHIFT),feature_on(CATCHUP))
        ADDON.setSetting(FEATURES_APPLIED,'2')
        ADDON.setSetting('meganexus_iptv_instance',str(iid))
        ADDON.setSetting('meganexus_iptv_configured','true')
    finally:ensure_client_enabled(rpc)
    return True

def channels(group='alltv',refresh=False):
    with _CHANNEL_LOCK:
        cached=_CHANNEL_CACHE.get(group)
        if not refresh and cached and time.monotonic()-cached[0]<60:return list(cached[1])
    # Kodi 21 'icon' is the channel logo; 'thumbnail' can be current EPG art.
    # Programme details/artwork are not requested
    # for every channel; the selected channel's guide loads after focus settles.
    rows=(rpc('PVR.GetChannels',{'channelgroupid':group,'properties':['icon','channelnumber','subchannelnumber','uniqueid','clientid','hasarchive']}) or {}).get('channels') or []
    # The unsorted response may follow database IDs rather than channel order.
    rows=sorted(rows,key=lambda r:(int(r.get('channelnumber') or 0),int(r.get('subchannelnumber') or 0)))
    if rows:
        with _CHANNEL_LOCK:
            _CHANNEL_CACHE[group]=(time.monotonic(),rows);_CHANNEL_CACHE.move_to_end(group)
            while len(_CHANNEL_CACHE)>8:_CHANNEL_CACHE.popitem(last=False)
    return list(rows)


def groups():
    rows=(rpc('PVR.GetChannelGroups',{'channeltype':'tv'}) or {}).get('channelgroups') or []
    # Kodi's own "All channels" group is the same list as ours: shown once.
    return [{'channelgroupid':'alltv','label':'All channels'}]+[r for r in rows if r.get('channelgroupid')!='alltv'
                                                                and str(r.get('label') or '').strip().casefold()!='all channels']


def epg_time(value):
    # PVR JSON-RPC serializes UTC without a suffix. Convert once to local time.
    try:
        date=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if date.tzinfo is None:date=date.replace(tzinfo=timezone.utc)
        return date.astimezone()
    except (ValueError,TypeError):return None


def programme_time(row):
    start,end=epg_time(row.get('starttime')),epg_time(row.get('endtime'))
    if not start or not end:return 'Time unavailable'
    return start.strftime('%d %b  %H:%M')+' - '+end.strftime('%H:%M')


def catchup_ready(row):
    """A finished programme Kodi can play from the archive (IPTV Simple catch-up)."""
    end=epg_time(row.get('endtime'))
    return bool(row.get('isplayable') and row.get('broadcastid') and not row.get('isactive') and end and end<datetime.now(timezone.utc))


def broadcasts(channel):
    rows=(rpc('PVR.GetBroadcasts',{'channelid':channel,'properties':['title','plot','starttime','endtime','isactive','isplayable']}) or {}).get('broadcasts') or []
    return sorted(rows,key=lambda r:r.get('starttime') or '')

def archive(channel,hours=ARCHIVE_HOURS):
    """7.0.32: the channel's past programmes Kodi can play from the archive, newest first."""
    since=datetime.now(timezone.utc).timestamp()-hours*3600
    rows=[r for r in broadcasts(channel) if catchup_ready(r) and (epg_time(r.get('starttime')) or datetime.now(timezone.utc)).timestamp()>=since]
    return rows[::-1]


def pvr_ready():
    """Kodi's PVR has started (its clients loaded the channels and the guide)."""
    try:return bool((rpc('PVR.GetProperties',{'properties':['available']}) or {}).get('available'))
    except Exception:return False


def channel_key(row):return '%s:%s'%(row.get('clientid',''),row.get('uniqueid',row['channelid']))

def current_id():
    try:
        for p in rpc('Player.GetActivePlayers') or []:
            if p['type']=='video':return (rpc('Player.GetItem',{'playerid':p['playerid']}) or {}).get('item',{}).get('id')
    except Exception:pass
    return None


def open_preview(channel_id):
    """Kodi Player.Open(channelid) obeys the PVR fullscreen preference.

    JSON-RPC has no windowed option for a channel. Temporarily override the
    documented native preference while its synchronous PlayMedia call decides
    the playback mode, then restore it even on errors. Never change app-window
    fullscreen, video zoom, resolution, or the user's saved channel setup.
    """
    from resources.lib.wallpaper_video import suspend
    suspend()
    if _WINDOWED[0] is not None:return rpc('Player.Open',{'item':item_for(channel_id)})   # 7.0.32: set once for the screen
    setting='pvrplayback.switchtofullscreenchanneltypes'
    previous=(rpc('Settings.GetSettingValue',{'setting':setting}) or {}).get('value')
    if type(previous) is not int or previous not in (0,1,2,3):
        raise ValueError('Kodi could not enable the IPTV preview. Check PVR playback settings.')
    changed=previous!=0
    if changed and rpc('Settings.SetSettingValue',{'setting':setting,'value':0}) is not True:
        raise ValueError('Kodi did not allow windowed IPTV playback.')
    try:
        return rpc('Player.Open',{'item':item_for(channel_id)})
    finally:
        if changed:
            # Do not overwrite a preference the user changed in another window.
            current=(rpc('Settings.GetSettingValue',{'setting':setting}) or {}).get('value')
            if current==0:rpc('Settings.SetSettingValue',{'setting':setting,'value':previous})

def item_for(target):
    """A channel id, or ('broadcast', id) for a programme from the archive."""
    if isinstance(target,tuple):return {'broadcastid':target[1]}
    return {'channelid':target}


_WINDOWED=[None]
FULLSCREEN_SETTING='pvrplayback.switchtofullscreenchanneltypes'


def keep_windowed():
    """7.0.32: Kodi's "switch to full screen" for channels is off while the IPTV
    screen is open - once, not around every channel start (two settings writes
    each time) - and given back afterwards (release_windowed)."""
    previous=(rpc('Settings.GetSettingValue',{'setting':FULLSCREEN_SETTING}) or {}).get('value')
    if type(previous) is not int or previous not in (0,1,2,3):return False
    if previous!=0 and rpc('Settings.SetSettingValue',{'setting':FULLSCREEN_SETTING,'value':0}) is not True:return False
    _WINDOWED[0]=previous
    return True


def release_windowed():
    previous,_WINDOWED[0]=_WINDOWED[0],None
    if previous is None or previous==0:return
    try:
        if (rpc('Settings.GetSettingValue',{'setting':FULLSCREEN_SETTING}) or {}).get('value')==0:
            rpc('Settings.SetSettingValue',{'setting':FULLSCREEN_SETTING,'value':previous})
    except Exception:pass


class IPTV(Dialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args)
        self.rows=kwargs['rows'];self.group=kwargs.get('group','alltv')
        self.groups=kwargs.get('groups') or [{'channelgroupid':'alltv','label':'All channels'}]
        self.playing=current_id();self.fullscreen=False;self.closed=False
        self._pool=ThreadPoolExecutor(max_workers=2);self._jobs={};self._updates=queue.Queue()
        self._cache=OrderedDict();self._generation=0;self._selection=None;self._selected_at=0
        self._epg_channel=None;self._epg=[];self._epg_refresh=0;self._ready=False
        self._requested_group=self.group;self._pending_group=None
        self._initialized=False;self._selected=0;self._back_block_until=0
        self._play_requested=None
        self._started=None;self._panel=[];self._hover=(None,0.);self._archive=(None,[])
    def onInit(self):
        if self._initialized:
            self.getControl(501).reset()
            self.getControl(501).addItems([listitems.item(label=plain_label(g['label'])) for g in self.groups])
            selected=next((i for i,g in enumerate(self.groups) if g['channelgroupid']==self.group),0)
            self.getControl(501).selectItem(selected)
            self.setProperty('meganexus.group',plain_label(self.groups[selected]['label']))
            current=next((r for r in self.rows if r['channelid']==self.playing),None)
            self.setProperty('meganexus.playing',plain_label(current.get('label')) if current else '')
            self._paint()
            if self.rows:self.getControl(500).selectItem(min(self._selected,len(self.rows)-1))
            if self._epg:self._paint_epg(self._epg)
            self._ready=True;self.restore_focus()
            return
        self._initialized=True
        self.getControl(501).reset()
        self.getControl(501).addItems([listitems.item(label=plain_label(g['label'])) for g in self.groups])
        selected=next((i for i,g in enumerate(self.groups) if g['channelgroupid']==self.group),0)
        self.getControl(501).selectItem(selected)
        self.setProperty('meganexus.group',plain_label(self.groups[selected]['label']));self._paint()
        self._ready=True;self.setFocusId(500)
        last=ADDON.getSetting('meganexus_iptv_last_unique')
        row=next((r for r in self.rows if channel_key(r)==last),None)
        if row:
            self.getControl(500).selectItem(self.rows.index(row))
            # Restore selection only. A stream open in Kodi's GUI callback can
            # block rendering for 90 seconds on an offline playlist.
            if self.playing==row['channelid']:self.setProperty('meganexus.playing',plain_label(row.get('label')))
            else:self.setProperty('meganexus.iptv.status','Select a channel to start the preview.')
        self._select_channel()
    def _paint(self):
        items=[]
        for number,r in enumerate(self.rows,1):
            now=r.get('broadcastnow') or {}
            # A group has a contiguous 1..N list; provider numbers remain in the
            # PVR database and the stable playback ID is never renumbered.
            li=listitems.item(label='%d  %s'%(number,plain_label(r.get('label'))),label2=plain_label(now.get('title') or ''))
            li.setArt({'icon':r.get('icon') or '', 'thumb':'', 'fanart':''});items.append(li)
        self.getControl(500).reset();self.getControl(500).addItems(items)
        self.setProperty('meganexus.iptv.status','' if items else 'No channels in this category.')

    def _submit(self,kind,key,call):
        previous=self._jobs.get(kind)
        if previous and not previous.done():return False
        generation=self._generation
        def load():
            try:result=call()
            except Exception:result=None
            if not self.closed:self._updates.put((kind,generation,key,result))
        self._jobs[kind]=self._pool.submit(load)
        return True

    def _request_group(self,key,refresh=False):
        self._play_requested=None
        self._requested_group=key
        self._pending_group=(key,refresh)
        self.setProperty('meganexus.iptv.status','Loading category...')

    def _load_pending_group(self):
        if self._pending_group:
            key,refresh=self._pending_group
            if self._submit('group',key,lambda:channels(key,refresh=refresh)):
                self._pending_group=None

    def _select_channel(self):
        pos=self.getControl(500).getSelectedPosition()
        if not 0<=pos<len(self.rows):return
        row=self.rows[pos];cid=row['channelid']
        if cid!=self._selection:
            self._selection=cid;self._selected_at=time.monotonic();self._epg_channel=None
            self.setProperty('meganexus.epg.channel',plain_label(row.get('label')))
            # Immediate now/next, then the full guide after the focus settles.
            self._paint_epg([r for r in (row.get('broadcastnow'),row.get('broadcastnext')) if r])

    def _paint_epg(self,rows):
        self._epg=rows
        items=[]
        for row in rows:
            past=catchup_ready(row)
            title=plain_label(row.get('title') or row.get('label') or 'Programme')
            li=listitems.item(label=programme_time(row),label2=('\u25b6  '+title) if past else title)
            li.setProperty('live','1' if row.get('isactive') else '')
            li.setProperty('catchup','1' if past else '')
            items.append(li)
        self.getControl(504).reset();self.getControl(504).addItems(items)
        now=datetime.now(timezone.utc)
        index=next((i for i,r in enumerate(rows) if (epg_time(r.get('endtime')) or now)>now),0)
        if items:self.getControl(504).selectItem(index)
        self.setProperty('meganexus.epg.empty','' if items else 'No EPG available for this channel.')

    def tick(self):
        self.drain_events()
        if self.closed or not self._ready:return
        self._load_pending_group()
        self._select_channel()
        now=time.monotonic()
        self._hint()
        self._archive_tick(now)
        if self._started:
            cid,began,opened,before=self._started
            # The new channel (another file than before the click) and its picture moving.
            path=xbmc.getInfoLabel('Player.FilenameAndPath')
            if now-began>30:self._started=None
            elif path and path!=before and xbmc.getCondVisibility('Player.HasVideo + Player.Playing + !Player.Caching'):
                try:moving=xbmc.Player().getTime()>=.2
                except Exception:moving=False
                if moving:
                    self._started=None
                    xbmc.log('[MegaNexus][perf] IPTV channel start: picture after %d ms (Kodi took the channel in %d ms) channel=%s'
                             %((now-began)*1000,(opened-began)*1000,cid),xbmc.LOGINFO)
        if self.getProperty('meganexus.iptv.full')=='1' and not self._play_requested:
            status='' if xbmc.getCondVisibility('Player.HasVideo') else 'Not playing - OK for the channels.'
            if self.getProperty('meganexus.iptv.video_status')!=status and not status.startswith('Opening'):
                self.setProperty('meganexus.iptv.video_status',status)
        if self._selection is not None and now-self._selected_at>=.3 and (self._epg_channel!=self._selection or now>=self._epg_refresh):
            cid=self._selection;cached=self._cache.get(cid)
            if cached and now-cached[0]<60:
                self._paint_epg(cached[1]);self._epg_channel=cid;self._epg_refresh=cached[0]+60
            elif self._submit('epg',cid,lambda:broadcasts(cid)):
                self._epg_channel=cid;self._epg_refresh=now+60
        for _ in range(8):
            try:kind,generation,key,result=self._updates.get_nowait()
            except queue.Empty:break
            if generation!=self._generation:continue
            if kind=='group':
                if key!=self._requested_group:continue
                if result is not None:
                    self.group=key;self.rows=result;self._selection=None;self._paint()
                    self.setProperty('meganexus.group',plain_label(next(g['label'] for g in self.groups if g['channelgroupid']==key)))
                    ADDON.setSetting('meganexus_iptv_last_group',str(key));self.setFocusId(500)
                else:self.setProperty('meganexus.iptv.status','Could not load this category. Select it to retry.')
            elif kind=='epg':
                if result is not None:
                    self._cache[key]=(now,result);self._cache.move_to_end(key)
                    while len(self._cache)>24:self._cache.popitem(last=False)
                if key==self._selection:
                    if result:self._paint_epg(result)
                    elif not self._epg:self.setProperty('meganexus.epg.empty','EPG is not available yet. Check the XMLTV source in IPTV setup.')
            elif kind=='catchup' and key==self._play_requested:
                self._play_requested=None
                if result:
                    self.playing=None
                    self.setProperty('meganexus.iptv.status','');self.setProperty('meganexus.iptv.video_status','')
                    self.setProperty('meganexus.playing',getattr(self,'_catchup_title','Programme'))
                    if getattr(self,'_catchup_inline',False):self._enlarge()   # 7.0.32: stays here, enlarged
                    else:
                        self.child(self._fullscreen)
                        self._back_block_until=time.monotonic()+.3
                elif result is False:
                    if xbmc.getCondVisibility('Player.HasVideo'):xbmc.Player().stop()
                    self.setProperty('meganexus.iptv.status','The archive did not answer - this programme is not available. Try another one.')
                    self.setProperty('meganexus.iptv.video_status','The archive did not answer - try another programme.')
            elif kind=='archive':
                self._show_archive(key,result)
            elif kind=='play' and key==self._play_requested:
                if result:
                    row=next((r for r in self.rows if r['channelid']==key),None)
                    if row:self._play(row)
                else:self.setProperty('meganexus.iptv.status','This channel is not responding. Try another channel.')

    def _request_play(self,row):
        # 7.0.29: on the click, as before. The stream check guarded against an offline
        # channel freezing Kodi through timeshift (inputstream.ffmpegdirect); timeshift
        # is opt-in now, and the check (the whole playlist downloaded) cost seconds.
        if not feature_on(TIMESHIFT):
            self._play_requested=None
            self._play(row);return
        from resources.lib import iptv_probe
        profile=xbmcvfs.translatePath(xbmcaddon.Addon('pvr.iptvsimple').getAddonInfo('profile'))
        key=row['channelid'];self._play_requested=key
        self.setProperty('meganexus.iptv.status','Checking channel...')
        def check():
            clients=(rpc('PVR.GetClients') or {}).get('clients') or []
            client=next((c for c in clients if c.get('clientid')==row.get('clientid')),None)
            if client and client.get('addonid')!='pvr.iptvsimple':return True
            return iptv_probe.verify(row,profile,lambda:self.closed or self._play_requested!=key,
                                     client.get('instanceid') if client else None)
        if not self._submit('play',key,check):
            self.setProperty('meganexus.iptv.status','Checking the previous channel. Select this channel again in a moment.')

    def _play(self,row):
        # Opening a channel via JSON-RPC uses Kodi PVR's EPG, buffering and tuner.
        began=time.monotonic();before=xbmc.getInfoLabel('Player.FilenameAndPath')
        try:open_preview(row['channelid'])
        except (RuntimeError,ValueError):
            self.setProperty('meganexus.iptv.status','This channel could not start in preview. Check the playlist or try another channel.')
            return
        self.playing=row['channelid']
        self._started=(row['channelid'],began,time.monotonic(),before)   # 7.0.32: logged once the picture moves
        ADDON.setSetting('meganexus_iptv_last_unique',channel_key(row))
        self.setProperty('meganexus.playing',plain_label(row.get('label')))
        # Keep this modal visible: playback is rendered by its videowindow.
    def onClick(self,cid):
        if cid==500 and self.rows:
            row=self.rows[self.getControl(500).getSelectedPosition()]
            if self.playing==row['channelid'] and current_id()==row['channelid']:
                self._selected=self.getControl(500).getSelectedPosition()
                self._enlarge()
            else:self._request_play(row)
        elif cid==FULL_BUTTON:
            self._show_channels()
        elif cid==CHANNEL_LIST:
            self._switch_channel()
        elif cid==ARCHIVE_LIST:
            self._play_archive()
        elif cid==506:
            if xbmc.getCondVisibility('Pvr.IsPlayingTV'):xbmc.Player().stop()
            self.finish()
        elif cid==501:
            pick=self.getControl(501).getSelectedPosition()
            if not 0<=pick<len(self.groups):return
            key=self.groups[pick]['channelgroupid']
            self._request_group(key)
        elif cid==502:
            self._cache.clear();self._epg_channel=None
            self._request_group(self.group,refresh=True)
        elif cid==503:
            if configure():
                with _CHANNEL_LOCK:_CHANNEL_CACHE.clear()
                self._request_group(self.group,refresh=True)
        elif cid==504 and self._epg:
            pos=self.getControl(504).getSelectedPosition()
            if 0<=pos<len(self._epg):
                row=self._epg[pos]
                if catchup_ready(row):self._catchup(row)
                else:xbmcgui.Dialog().textviewer(plain_label(row.get('title') or 'Programme'),programme_time(row)+'\n\n'+plain_label(row.get('plot') or 'No description available.'))
    def _catchup(self,row,inline=False):
        """7.0.29: a past programme from the archive, in Kodi's player (seek, pause).
        Opened off the click: the archive can take seconds (or never answer) - the
        guide stays with "Opening…" and goes full screen once the picture is there;
        it looked frozen when the screen went black at once."""
        key=('catchup',row['broadcastid']);self._play_requested=key;self._catchup_inline=inline
        self.setProperty('meganexus.iptv.status','Opening the programme from the archive…')
        if inline:self.setProperty('meganexus.iptv.video_status','Opening the programme from the archive…')
        def open_archive():
            if rpc('Player.Open',{'item':item_for(('broadcast',row['broadcastid']))})!='OK':return False
            monitor=xbmc.Monitor();until=time.monotonic()+CATCHUP_WAIT
            while time.monotonic()<until and not monitor.abortRequested():
                if self.closed or self._play_requested!=key:return None
                if xbmc.getCondVisibility('Player.HasVideo + Player.Playing + !Player.Caching'):return True
                monitor.waitForAbort(.2)
            return False
        if not self._submit('catchup',key,open_archive):
            self.setProperty('meganexus.iptv.status','Still opening the previous programme. Select it again in a moment.')
            return
        self._catchup_title=plain_label(row.get('title') or 'Programme')
    def _fullscreen(self):
        """The SAME IPTV page survives native fullscreen, Stop and stream EOF."""
        self.fullscreen=True
        monitor=xbmc.Monitor()
        try:
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            seen=False;start=time.monotonic()
            while not monitor.waitForAbort(.05):
                full=xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                if full:seen=True
                if seen and not full:break
                if not xbmc.Player().isPlayingVideo():break
                if not seen and time.monotonic()-start>5:break
        finally:
            self.fullscreen=False
            # Stop/EOF must return to the guide without auto-restarting a channel.
            if not xbmc.Player().isPlayingVideo():
                self.playing=None
                self.setProperty('meganexus.playing','')

    def onAction(self,action):
        aid=action.getId()
        if aid in INFO:
            # Info: Kodi's own full-screen player for the channel that plays.
            if xbmc.getCondVisibility('Player.HasVideo'):
                self._hide_channels();self._small()
                self.child(self._fullscreen)
                self._back_block_until=time.monotonic()+.3
            return
        if aid not in (9,10,92,216,247,257,275,61448,61467)+STOP:return
        if time.monotonic()<self._back_block_until:return
        if aid in STOP:
            self._play_requested=None
            if xbmc.getCondVisibility('Pvr.IsPlayingTV | Player.HasVideo'):xbmc.Player().stop()
            self.playing=None;self._started=None
            self.setProperty('meganexus.playing','')
            self.setProperty('meganexus.iptv.status','Stopped. Select a channel to play.')
            self._hide_channels();self._small();self.setFocusId(500)
            return
        # 7.0.32: Back never stops the channel (as in Sport): catch-up -> channels ->
        # enlarged -> small video -> the HUB button.
        cid=self.getFocusId()
        if cid==ARCHIVE_LIST:
            self.setFocusId(CHANNEL_LIST);return
        if self.getProperty('meganexus.iptv.channels')=='1':
            self._hide_channels();return
        if self.getProperty('meganexus.iptv.full')=='1':
            self._small();return
        # HUB is deliberate, not a side effect of Escape.
        self.setFocusId(506)

    # ---- the enlarged channel (7.0.32) -------------------------------------
    def _enlarge(self):
        if self.getProperty('meganexus.iptv.full')=='1':return
        self.setProperty('meganexus.iptv.video_status','')
        self.setProperty('meganexus.iptv.full','1')
        self.setFocusId(FULL_BUTTON)

    def _small(self):
        if self.getProperty('meganexus.iptv.full')!='1':return
        self.setProperty('meganexus.iptv.full','')
        self.setFocusId(500)

    def _show_channels(self):
        """The group's channels; the one that plays is selected."""
        self._panel=list(self.rows)
        items=[]
        for number,r in enumerate(self._panel,1):
            now=r.get('broadcastnow') or {}
            li=listitems.item(label='%d  %s'%(number,plain_label(r.get('label'))),label2=plain_label(now.get('title') or ''))
            li.setArt({'icon':r.get('icon') or ''})
            li.setProperty('playing','Playing' if r['channelid']==self.playing else '')
            items.append(li)
        control=self.getControl(CHANNEL_LIST);control.reset();control.addItems(items)
        playing=next((i for i,r in enumerate(self._panel) if r['channelid']==self.playing),0)
        if items:control.selectItem(playing)
        self._hover=(None,0.);self._archive=(None,[])
        self.getControl(ARCHIVE_LIST).reset()
        self.setProperty('meganexus.iptv.archive','');self.setProperty('meganexus.iptv.archive_status','')
        self.setProperty('meganexus.iptv.channels','1')
        self.setFocusId(CHANNEL_LIST)

    def _hide_channels(self):
        if self.getProperty('meganexus.iptv.channels')!='1':return
        self.setProperty('meganexus.iptv.channels','')
        if self.getProperty('meganexus.iptv.full')=='1':self.setFocusId(FULL_BUTTON)

    def _panel_row(self):
        pos=self.getControl(CHANNEL_LIST).getSelectedPosition()
        return self._panel[pos] if 0<=pos<len(self._panel) else None

    def _switch_channel(self):
        row=self._panel_row()
        if not row:return
        self._hide_channels()
        if row['channelid']!=self.playing:
            self.setProperty('meganexus.iptv.video_status','')
            self._request_play(row)

    def _archive_tick(self,now):
        """The catch-up of the channel under the cursor, beside the channels."""
        if self.getProperty('meganexus.iptv.channels')!='1' or self.getFocusId()!=CHANNEL_LIST:return
        row=self._panel_row()
        if not row:return
        cid=row['channelid']
        if self._hover[0]!=cid:
            self._hover=(cid,now);return
        if now-self._hover[1]<CHANNEL_DWELL or self._archive[0]==cid:return
        if not row.get('hasarchive'):
            self._archive=(cid,[]);self.getControl(ARCHIVE_LIST).reset()
            self.setProperty('meganexus.iptv.archive','')
            return
        self._archive=(cid,None)
        self.getControl(ARCHIVE_LIST).reset()
        self.setProperty('meganexus.iptv.archive','1')
        self.setProperty('meganexus.iptv.archive_status','Loading the archive…')
        if not self._submit('archive',cid,lambda:archive(cid)):self._archive=(None,[])

    def _show_archive(self,cid,rows):
        if self._archive[0]!=cid:return
        self._archive=(cid,rows or [])
        items=[]
        for row in rows or []:
            li=listitems.item(label=programme_time(row),label2=plain_label(row.get('title') or 'Programme'))
            items.append(li)
        control=self.getControl(ARCHIVE_LIST);control.reset();control.addItems(items)
        self.setProperty('meganexus.iptv.archive_status','' if items else 'Nothing in the archive from the last %d hours.'%ARCHIVE_HOURS)

    def _play_archive(self):
        cid,rows=self._archive
        pos=self.getControl(ARCHIVE_LIST).getSelectedPosition()
        if not rows or not 0<=pos<len(rows):return
        self._hide_channels()
        self._catchup(rows[pos],inline=True)

    def _hint(self):
        cid=self.getFocusId()
        if cid==ARCHIVE_LIST:key='archive'
        elif self.getProperty('meganexus.iptv.channels')=='1':key='channels'
        elif self.getProperty('meganexus.iptv.full')=='1':key='full'
        else:key='guide'
        if self.getProperty('meganexus.iptv.hint')!=HINTS[key]:self.setProperty('meganexus.iptv.hint',HINTS[key])

    def finish(self):
        if self.closed:return
        self.closed=True;self._generation+=1
        for future in self._jobs.values():future.cancel()
        self._pool.shutdown(wait=False);self.close()

def _entry_channels():
    """(groups, group, channels) of the last group; None when there are none."""
    try:category_rows=groups()
    except RuntimeError:category_rows=[{'channelgroupid':'alltv','label':'All channels'}]
    saved=ADDON.getSetting('meganexus_iptv_last_group')
    group=next((g['channelgroupid'] for g in category_rows if str(g['channelgroupid'])==saved),'alltv')
    try:rows=channels(group)
    except RuntimeError:rows=[]
    if not rows and group!='alltv':
        group='alltv';rows=channels()
    if not rows:
        if not configure():return None
        def wait_channels():
            for _ in range(60):
                try:loaded=channels(refresh=True)
                except RuntimeError:loaded=[]
                if loaded:return loaded
                if xbmc.Monitor().waitForAbort(.5):break
            return []
        rows=job(wait_channels,label='Loading channels and EPG') or []
    if not rows:
        xbmcgui.Dialog().ok('IPTV','No channels are available yet. Check the playlist in IPTV Simple settings, or restart Kodi after installing the PVR client.')
        return None
    return category_rows,group,rows


def open_iptv():
    from . import perf
    if not pvr_ready():
        # 7.0.32: IPTV Simple still loading the channels and the guide (after Kodi
        # starts). Kodi keeps them through a suspend - nothing reloads them here.
        def wait_pvr():
            monitor=xbmc.Monitor()
            for _ in range(240):
                if pvr_ready() or monitor.waitForAbort(.25):return True
            return False
        job(wait_pvr,label='Loading channels and EPG')
    if configured() and ADDON.getSetting(FEATURES_APPLIED)!='2':
        try:apply_iptv_features(quiet=True)    # 7.0.29: timeshift / catch-up for an existing setup, once
        except Exception:xbmc.log('[MegaNexus] IPTV timeshift / catch-up not applied.',xbmc.LOGWARNING)
    try:
        with perf.timed('IPTV channels'):
            loaded=_entry_channels()
        if loaded is None:return
        category_rows,group,rows=loaded
        if group=='alltv':category_rows=groups()
        win=IPTV('meganexus_iptv.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',rows=rows,groups=category_rows,group=group)
        monitor=xbmc.Monitor()
        windowed=keep_windowed()
        try:
            win.show_ready()
            while not win.closed and not monitor.abortRequested():
                win.tick();monitor.waitForAbort(.1)
        finally:
            win.finish()
            if windowed:release_windowed()

    except Exception as exc:
        xbmcgui.Dialog().ok('IPTV',str(exc) if isinstance(exc,ValueError) else 'IPTV could not open. Check IPTV Simple and your playlist in Kodi PVR settings.')
