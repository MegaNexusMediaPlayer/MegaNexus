# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Compatibility import for the shared, pure Python silent-loop builder."""
import sys
from resources.lib import mp4loop as _shared
sys.modules[__name__] = _shared
