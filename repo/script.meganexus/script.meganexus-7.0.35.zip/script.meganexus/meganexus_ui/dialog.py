# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Keep Kodi callbacks short and remove parent modals while a child owns input."""
import queue
import threading
import traceback
import xbmc
import xbmcgui

BACK = (9, 10, 92, 216, 13, 247, 257, 275, 61448, 61467)
ACTIONS = (117, 101, 1009, 11)
# Touch gestures (IDs 501-599) are left entirely to Kodi, as before 6.0.37.
# 6.0.37/6.0.39 turned vertical drags into Up/Down steps; it fought Kodi's own
# panning (too fast on a small move, focus changes repainted Home) and was
# removed in 6.0.40. Never reuse window attribute names for Dialog state:
# 6.0.37 stored it as self._touch and replaced HomeWindow._touch().

class Action:
    def __init__(self, aid): self.aid = aid
    def getId(self): return self.aid

class Dialog(xbmcgui.WindowXMLDialog):
    """Callbacks are wrapped per window instance (6.0.37). Kodi 22's SWIG 4.5
    bindings make the window classes' attributes read-only after creation
    ("cannot modify read-only attribute ...onInit"), so the earlier
    class-level wrapping in __init_subclass__ stopped every MegaNexus window."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self._events = queue.Queue(maxsize=1)
        self._dispatching = False
        self._dialog_closed = False
        self._child_active = False
        self._restore_focus = None
        self._meganexus_play_hidden = False
        self._xml_ready=threading.Event()
        self._install_callbacks()

    def _install_callbacks(self):
        cls = type(self)
        for name in ('onInit', 'onClick', 'onAction'):
            owner = next((k for k in cls.__mro__ if name in k.__dict__), None)
            if owner is None or owner is Dialog or not issubclass(owner, Dialog):
                continue
            original = owner.__dict__[name]
            if name == 'onInit':
                def ready(_fn=original):
                    try:return _fn(self)
                    finally:self._xml_ready.set()
                self.onInit = ready
                continue
            def callback(value, _fn=original, _name=name):
                if self._child_active or self._dialog_closed: return
                if _name == 'onAction':
                    aid = value.getId()
                    if aid not in BACK + ACTIONS: return  # Kodi owns navigation/seek/touch.
                    value = Action(aid)
                    if aid in BACK: return _fn(self, value)
                # A busy operation already owns this click; do not replay held
                # Select after it returns. Irrelevant navigation never queues.
                if not self._dispatching:
                    self.defer(lambda: _fn(self, value))
            setattr(self, name, callback)

    def show_ready(self):
        """Restored XML controls are valid only after Kodi delivers onInit."""
        self._xml_ready.clear()
        self.show()
        monitor=xbmc.Monitor()
        for _ in range(100):
            if self._xml_ready.is_set() or self._dialog_closed or monitor.waitForAbort(.01):break

    def defer(self, fn):
        try: self._events.put_nowait(fn)
        except queue.Full: pass

    def child(self, fn, *args, **kwargs):
        """Hide the parent natively; retain its Python state for Back/Stop."""
        try: focus = self.getFocusId()
        except Exception: focus = None
        self._child_active = True
        try:
            xbmcgui.WindowXMLDialog.close(self)
            return fn(*args, **kwargs)
        finally:
            self._restore_focus = focus
            if not self._dialog_closed and not xbmc.Monitor().abortRequested():
                self.show_ready()
            self._child_active = False

    def in_place(self, fn, *args, **kwargs):
        """7.0.29: start a title over this screen - it stays while the sources are
        searched and chosen (no other screen, wallpaper or black blinks between) and
        hides only when the video starts (playback._hide_parents); back afterwards."""
        from . import playback
        try: focus = self.getFocusId()
        except Exception: focus = None
        self._child_active = True
        self._meganexus_play_hidden = False
        playback.PARENTS.append(self)
        try:
            return fn(*args, **kwargs)
        finally:
            try: playback.PARENTS.remove(self)
            except ValueError: pass
            if self._meganexus_play_hidden:
                self._meganexus_play_hidden = False
                self._restore_focus = focus
                if not self._dialog_closed and not xbmc.Monitor().abortRequested():
                    self.show_ready()
            self._child_active = False

    def over(self, fn, *args, **kwargs):
        """Run a window on top of this one while it stays visible (translucent
        HUB Settings, 6.0.35). Its own input is paused meanwhile."""
        self._child_active = True
        try:
            return fn(*args, **kwargs)
        finally:
            self._child_active = False

    def restore_focus(self):
        focus, self._restore_focus = self._restore_focus, None
        if focus is not None:
            try: self.setFocusId(focus)
            except Exception: pass

    def drain_events(self):
        if self._dialog_closed or self._dispatching or self._child_active: return
        try: fn = self._events.get_nowait()
        except queue.Empty: return
        self._dispatching = True
        try: fn()
        except Exception:
            # 6.0.39: one failing click or key never closes MegaNexus ("Could
            # not open the interface"); the window stays and the log has why.
            xbmc.log('[MegaNexus] Action failed: ' + traceback.format_exc(), xbmc.LOGERROR)
            try: xbmcgui.Dialog().notification('MegaNexus', 'That did not work. Please try again.', time=3000)
            except Exception: pass
        finally: self._dispatching = False

    def doModal(self):
        self._dialog_closed = False
        self.show_ready()
        monitor = xbmc.Monitor()
        while not self._dialog_closed and not monitor.abortRequested():
            self.drain_events()
            tick = getattr(self, 'tick', None)
            if tick and not self._dialog_closed: tick()
            monitor.waitForAbort(.05)

    def close(self):
        self._dialog_closed = True
        super().close()
