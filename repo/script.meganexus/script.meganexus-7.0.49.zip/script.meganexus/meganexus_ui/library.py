# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus Library screen (6.0.35).

Tabs: Local, the connected tracking services (named: "Trakt · Simkl"...) and
Calendar (everything by the month it was added; month and year only). Each
card has a small badge with its source (Local / Trakt / Simkl...). Opens on
the tracking tab when a service is connected, else on Local. The tracking
watchlists are refreshed in the background.

7.0.48: the gear after the tabs opens the Library's own options, as the media
apps have them (Plex, Jellyfin, Infuse): View (rows, a poster grid, wide cards,
a list with details), Sort (added, title), Show (movies, series or both) and the
titles under the cards. Saved in MegaNexus' settings (and its backup).
"""
import xbmcaddon
import xbmcgui
from resources.lib import art_cache, library
from resources.lib.settings_cache import cached_addon, invalidate as settings_invalidate
from resources.lib.theme import folder as theme_folder
from .dialog import Dialog, BACK
from . import listitems

TABS = {201: 'local', 202: 'tracking', 203: 'calendar'}
OPTIONS = 210            # the gear: the Library's options
VIEW_IDS = {'grid': 600, 'wide': 601, 'list': 602}
VIEWS = (('rows', 'Rows'), ('grid', 'Poster grid'), ('wide', 'Wide cards'), ('list', 'List with details'))
SORTS = (('added', 'Recently added'), ('oldest', 'Oldest added'), ('title', 'Title A-Z'), ('title_desc', 'Title Z-A'))
SHOWS = (('all', 'Movies and series'), ('movie', 'Movies'), ('series', 'Series'))
VIEW, SORT, SHOW, TITLES = ('meganexus_library_view', 'meganexus_library_sort', 'meganexus_library_show',
                            'meganexus_library_titles')
MAX_FLAT = 1000          # a grid / list holds this many
ROW_BASE = 500
MAX_ROWS = 14
ROW_CARDS = 20     # 7.0.29: a row shows this many, then "Browse all" opens the grid (as collections)


class LibraryWindow(Dialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.tab = 'tracking' if library.tracking_connected() else 'local'
        self.rows = []          # [(title, cards)]
        self.outcome = ''
        self._refresh = None
        self._refreshed = False
        self._extra = []        # 7.0.29: this device's storage and the media servers (Local tab)
        self._extra_job = None

    def onInit(self):
        self._show()
        if self.rows or getattr(self, '_flat', None):
            self.restore_focus()
            self._focus_view()
        else:
            self.setFocusId({v: k for k, v in TABS.items()}[self.tab])

    def _focus_view(self):
        """7.0.48: the grid, wide cards and the list take the focus themselves - the window's
        default control is the rows' group, hidden in those views, and nothing had the
        focus (no key did anything)."""
        want = VIEW_IDS.get(option(VIEW, VIEWS))
        if want and self.getFocusId() not in (want, OPTIONS) and self.getFocusId() not in TABS:
            self.setFocusId(want)

    def _rows_for(self, tab):
        if tab == 'calendar':
            return library.calendar(MAX_ROWS)
        movies, series = library.rows(library.LOCAL if tab == 'local' else library.TRACKING)
        rows = [(title, cards) for title, cards in (('Movies', movies), ('Series', series)) if cards]
        return rows + list(self._extra) if tab == 'local' else rows

    def _show(self):
        self.setProperty('meganexus.library.tab', self.tab)
        self.setProperty('meganexus.library.tracking_label', library.tracking_label())
        view = option(VIEW, VIEWS)
        self.setProperty('meganexus.library.view', view)
        self.setProperty('meganexus.library.notitles', '' if cached_addon().getSetting(TITLES) != 'false' else '1')
        arranged = arrange(self._rows_for(self.tab), option(SHOW, SHOWS), option(SORT, SORTS))
        self._flat = []
        if view != 'rows':
            self._full, self.rows = [], []
            self._fill_view(view, arranged)
        else:
            self._full = arranged[:MAX_ROWS]
            self.rows = [(title, _shown(cards)) for title, cards in self._full]
        for index, (_, cards) in enumerate(self.rows):
            if cards and cards[-1].get('browse_all', 0) is None:
                cards[-1]['browse_all'] = index
        for i in range(MAX_ROWS):
            control = self.getControl(ROW_BASE + i)
            pos = control.getSelectedPosition()      # a background update keeps the cursor
            control.reset()
            self.setProperty('meganexus.library.row.%d' % i, self.rows[i][0] if i < len(self.rows) else '')
            if i < len(self.rows):
                items = []
                for card in self.rows[i][1]:
                    item = listitems.item(label=card['title'])
                    item.setArt({'poster': art_cache.card(card.get('poster'))})
                    badges = card.get('badges') or []
                    for n in range(3):   # small pills, one under the other
                        item.setProperty('badge.%d' % n, badges[n] if n < len(badges) else '')
                    items.append(item)
                control.addItems(items)
                if 0 < pos:
                    control.selectItem(min(pos, len(items) - 1))
        for i in range(len(self.rows)):
            control = self.getControl(ROW_BASE + i)
            control.controlUp(self.getControl(ROW_BASE + i - 1) if i else self.getControl(201))
            control.controlDown(self.getControl(ROW_BASE + min(i + 1, len(self.rows) - 1)))
        status = ''
        empty = not self.rows and not self._flat
        if self.tab == 'local' and self._extra_job is None:
            from .playback import _CATALOG
            self._extra_job = _CATALOG.submit(_device_and_servers)
        if self.tab == 'tracking' and not library.tracking_connected():
            status = 'Connect Trakt or Simkl: HUB Settings > Accounts & tracking services'
        elif self.tab in ('tracking', 'calendar') and library.tracking_connected() and not self._refreshed:
            # updated quietly in the background; a word only while the tab is still empty
            status = 'Updating from %s…' % library.tracking_label() if empty else ''
            self._start_refresh()
        elif empty and self.tab == 'local' and not getattr(self, '_extra_done', False):
            status = 'Reading this device and your media servers…'
        elif empty:
            status = 'Nothing here yet. Use Title options or Details > Add to Library.'
        self.setProperty('meganexus.library.status', status)

    def _fill_view(self, view, arranged):
        """A grid or the list: every title of the tab once (in the order chosen)."""
        seen = set()
        for _, cards in arranged:
            for card in cards:
                key = id(card) if not card.get('target') else (card['target'].get('media_type'), card['target'].get('canonical_id'))
                if key not in seen and len(self._flat) < MAX_FLAT:
                    seen.add(key)
                    self._flat.append(card)
        items = []
        for card in self._flat:
            item = listitems.item(label=card['title'], label2='  ·  '.join(card.get('badges') or []))
            poster = art_cache.card(card.get('poster'))
            item.setArt({'poster': poster, 'landscape': art_cache.card(card.get('landscape') or card.get('fanart')) or poster})
            badges = card.get('badges') or []
            for n in range(3):
                item.setProperty('badge.%d' % n, badges[n] if n < len(badges) else '')
            item.setProperty('plot', card.get('plot') or '')
            items.append(item)
        control = self.getControl(VIEW_IDS[view])
        pos = control.getSelectedPosition()          # a background update keeps the cursor
        control.reset()
        control.addItems(items)
        if 0 < pos and items:
            control.selectItem(min(pos, len(items) - 1))

    def _options(self):
        """The Library's own options (the gear) - this screen shows them at once."""
        from . import settings_page as page
        def build():
            titles = cached_addon().getSetting(TITLES) != 'false'
            return [('view', page.item('View', dict(VIEWS)[option(VIEW, VIEWS)])),
                    ('sort', page.item('Sort', dict(SORTS)[option(SORT, SORTS)])),
                    ('show', page.item('Show', dict(SHOWS)[option(SHOW, SHOWS)])),
                    ('titles', page.item('Titles under the cards', enabled=titles))]
        def act(key):
            addon = cached_addon()
            if key == 'titles':
                addon.setSetting(TITLES, 'false' if addon.getSetting(TITLES) != 'false' else 'true')
            else:
                setting, choices = {'view': (VIEW, VIEWS), 'sort': (SORT, SORTS), 'show': (SHOW, SHOWS)}[key]
                keys = [k for k, _ in choices]
                pick = xbmcgui.Dialog().select(dict(view='View', sort='Sort', show='Show')[key], [label for _, label in choices],
                                               preselect=keys.index(option(setting, choices)))
                if pick < 0:
                    return None
                addon.setSetting(setting, keys[pick])
            settings_invalidate()
            return None
        page.keyed('Library', build, act)

    def _start_refresh(self):
        if self._refresh is not None:
            return
        from .playback import _CATALOG
        self._refresh = _CATALOG.submit(library.refresh_tracking)

    def tick(self):
        if self._extra_job is not None and self._extra_job.done() and not getattr(self, '_extra_done', False):
            self._extra_done = True
            try:
                self._extra = self._extra_job.result() or []
            except Exception:
                self._extra = []
            if self.tab == 'local' and self._extra:
                self._show()
        if self._refresh is None or not self._refresh.done():
            return
        future, self._refresh = self._refresh, None
        self._refreshed = True
        try:
            future.result()
        except Exception:
            pass
        if self.tab in ('tracking', 'calendar'):
            self._show()

    def _row(self, cid):
        if cid in VIEW_IDS.values():
            pos = self.getControl(cid).getSelectedPosition()
            return self._flat[pos] if 0 <= pos < len(self._flat) else None
        index = cid - ROW_BASE
        if not 0 <= index < len(self.rows):
            return None
        cards = self.rows[index][1]
        pos = self.getControl(cid).getSelectedPosition()
        return cards[pos] if 0 <= pos < len(cards) else None

    def onClick(self, cid):
        if cid == OPTIONS:
            self.over(self._options)
            self._show()
            self.setFocusId(OPTIONS)
            return
        if cid not in TABS:
            card = self._row(cid)
            if card and card.get('browse_all') is not None:
                # 7.0.29: the whole row as a grid
                from .catalog import open_catalog
                title, cards = self._full[card['browse_all']]
                self.outcome = self.child(open_catalog, {'label': 'Library · ' + title, 'rows': [c for c in cards if c.get('target')]})
                if self.outcome == 'playing' or isinstance(self.outcome, dict):
                    self.close()
                else:
                    self._show()
                return
        if cid in TABS:
            if TABS[cid] != self.tab:
                self.tab = TABS[cid]
                self._show()
            return
        row = self._row(cid)
        if not row:
            return
        if not row.get('target'):
            # 7.0.29: a file on this device or a server episode plays straight away.
            if row.get('local'):
                from .local_storage import open_item
                command = self.child(open_item, row['local'])
                if command and command != 'playing':
                    import xbmc
                    xbmc.executebuiltin(command)
            elif row.get('server_play'):
                from .home_window import _server_play
                command = _server_play(row['server_play'])
            else:
                return
            if command:
                self.outcome = 'playing'
                self.close()
            return
        from .details import open_context, plays_directly
        direct = plays_directly(row['target'], row)   # 7.0.44: else the title like on Home (hero)
        self.outcome = (self.in_place if direct else self.child)(open_context, row['target'], row=row, hero=not direct)
        if self.outcome == 'playing' or isinstance(self.outcome, dict):
            self.close()
        else:
            self._show()

    def onAction(self, action):
        aid = action.getId()
        if aid in BACK:
            self.close()
            return
        row = self._row(self.getFocusId())
        if not row or not row.get('target') or aid not in (117, 101, 1009, 11):
            return
        from .details import context_choice, quick_choice, run_choice, plays_directly
        choice = 'details' if aid == 11 else context_choice(row['target'], row)   # 7.0.36: its page, no Info window
        if not choice:
            return
        if quick_choice(choice, row['target'], row):
            self._show()
            return
        self.outcome = (self.in_place if plays_directly(row['target'], row, choice) else self.child)(run_choice, row['target'], choice, row)
        if self.outcome == 'playing' or isinstance(self.outcome, dict):
            self.close()


def option(setting, choices):
    value = cached_addon().getSetting(setting)
    return value if value in dict(choices) else choices[0][0]


def _kind(title, card):
    kind = (card.get('target') or {}).get('media_type')
    if kind:
        return kind
    return 'movie' if 'Movies' in title else 'series' if 'Series' in title else ''


def arrange(rows, show='all', sort='added'):
    """The rows with only the kind shown (movies / series) and the cards in the order chosen."""
    keys = {'added': (lambda c: -int(c.get('added_at') or 0)), 'oldest': (lambda c: int(c.get('added_at') or 0)),
            'title': (lambda c: str(c.get('title') or '').casefold()),
            'title_desc': (lambda c: str(c.get('title') or '').casefold())}
    out = []
    for title, cards in rows:
        kept = [c for c in cards if show == 'all' or _kind(title, c) in ('', show)]
        if sort != 'added' or any(c.get('added_at') for c in kept):
            kept = sorted(kept, key=keys[sort], reverse=sort == 'title_desc')
        if kept:
            out.append((title, kept))
    return out


def _shown(cards):
    """The first ROW_CARDS of a row, then "Browse all · N" (rows of titles only - a
    file of this device or a server episode has no title page for the grid)."""
    if len(cards) <= ROW_CARDS or not all(c.get('target') for c in cards):
        return cards
    more = cards[ROW_CARDS]
    return cards[:ROW_CARDS] + [{'title': 'Browse all · %d' % len(cards), 'poster': more.get('poster') or '',
                                 'badges': ['Browse all'], 'browse_all': None}]


def _device_and_servers():
    """[(title, cards)] for the Local tab: this device's storage (Kodi's library
    or the folders MegaNexus reads itself) and every connected media server."""
    from resources.lib import local_media, local_files, media_servers
    out = []
    have = local_media.counts(fresh=True)
    for kind, title in (('movie', 'On this device · Movies'), ('series', 'On this device · Series')):
        if have.get(kind) or local_files.folders():
            cards = [c for c in local_media.rows(kind) if c.get('local') and c['local'].get('type') != 'all']
            if cards:
                out.append((title, [dict(c, badges=['Device']) for c in cards]))
    for kind in media_servers.KINDS:
        if not media_servers.enabled(kind):
            continue
        name = media_servers.label(kind)
        for part, title in (('continue', 'Continue watching'), ('recent', 'Recently added')):
            cards = [c for c in media_servers.load_rows(kind, part) if c.get('target') or c.get('server_play')]
            if cards:
                out.append(('%s · %s' % (name, title), [dict(c, badges=[name]) for c in cards]))
    return out


def open_library():
    win = LibraryWindow('meganexus_library.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i')
    try:
        win.doModal()
        return win.outcome
    finally:
        win.close()
