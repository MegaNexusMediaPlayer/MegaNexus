# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""One bounded preview job, no UI-thread waits, first-frame reveal and miss cache."""
import threading
import time
import uuid
import queue
import os
from collections import OrderedDict
import json
import xbmc
import xbmcgui
from resources.lib.settings_cache import cached_addon
from resources.lib.trailer_support import selected_trailers

QUIET='meganexus.quiet'   # 7.0.42: Kodi's mute icon / volume bar hidden (skin.meganexus)
QUIET_AFTER=2.5           # seconds after the sound comes back
_CACHE=OrderedDict()

def view_mode(mode):
    """7.0.29: previews fill their 16:9 corner (Kodi's zoom crops 4:3 / 2.39:1
    instead of black bars, so the page melts into the picture, not into a bar).
    'normal' again before Kodi's own full-screen player."""
    try:
        xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Player.SetViewMode','params':{'viewmode':mode}}))
    except Exception:pass


PLAY_WAIT = 6.0      # 7.0.45: seconds a found trailer waits for the clip before to stop


def fill_corner():
    """The small video fills its corner: 7.0.45 - its window is 1.5 times the corner
    with the page drawn over the rest (review/make_blend.py FRAME), so Kodi shows the
    whole picture as it is and a trailer's own black bars (or a wider / narrower
    picture's) lie under the page or off the screen. 7.0.29-7.0.44 zoomed it - which
    Amlogic's video layer does not do (CoreELEC: not enlarged, a hard line), and the
    picture's shape was known only a moment after it started (a line flashed)."""
    view_mode('normal')
    return True


class PreviewPlayer(xbmc.Player):
    def __init__(self):
        super().__init__();self.token='';self.path='';self.av_path='';self.stop_requested=False;self.cancelled=False;self.ready=False;self.failed=False
        # Kodi tells EVERY Python player about every stop/end/error. Only our own
        # clip (it started, token on its item) or our own failed request may end us -
        # the video wallpaper stopping for this very preview must not.
        self.started_own=False;self.requested=False
    def owns(self):
        try:
            if not self.token or not self.isPlayingVideo():return False
            try:
                if self.getPlayingItem().getProperty('meganexus.preview')==self.token:return True
            except Exception:pass
            if xbmcgui.Window(10000).getProperty('meganexus.preview.active')!=self.token:return False
            if not self.av_path:return False
            current=self.getPlayingFile()
            return bool(current and current==self.av_path)
        except Exception:return False
    def onAVStarted(self):
        self.av_path=''
        self.ready=False
        if not self.token:return
        try:
            # The ListItem token survives Kodi's internal path substitution.
            # Read it once on AV start; never accept the Home token alone.
            if self.token and self.getPlayingItem().getProperty('meganexus.preview')==self.token:
                self.av_path=self.getPlayingFile();self.started_own=True
        except Exception:pass
        self.ready=self.owns()
        if self.cancelled or xbmcgui.Window(10000).getProperty('meganexus.preview.active')!=self.token:
            self.stop_owned();return
        if self.ready:fill_corner()   # 7.0.45: the picture's shape no longer matters (see fill_corner)
        if self.cancelled:self.stop_owned()
    def _ended(self,error=False):
        if not self.started_own and not (error and self.requested):return   # someone else's playback ended
        self.started_own=False
        home=xbmcgui.Window(10000)
        for key in ('meganexus.preview.active','meganexus.preview.silent','meganexus.preview.pending'):
            if home.getProperty(key)==self.token:home.clearProperty(key)
        from resources.lib.wallpaper_video import release
        release()
    def onPlayBackStopped(self):self._ended()
    def onPlayBackEnded(self):self._ended()
    def onPlayBackError(self):
        if self.requested and not self.started_own:self.failed=True
        self._ended(True)
    def cancel(self):
        # Signal-only; the owner/AV callback queues an asynchronous Kodi Stop.
        self.cancelled=True
        from resources.lib.saver_state import cancel_play
        cancel_play(self.token)
    def stop_owned(self):
        # 7.0.29: asked again after a moment - a Stop Kodi missed (decoder busy on
        # the Cube) left the clip playing in the corner while the user moved on.
        now=time.monotonic()
        if self.owns() and (not self.stop_requested or now-getattr(self,'stop_at',0.)>1.5):
            self.stop_requested=True;self.stop_at=now
            xbmc.executebuiltin('PlayerControl(Stop)')

class Controller:
    def __init__(self,window):
        self.window=window;self.stop_event=threading.Event();self.player=PreviewPlayer()
        self.job=None;self.failed_session=False;self.play_started=0;self.resolve_cancel=threading.Event()
        self.results=queue.Queue();self.previous=None;self.changed=time.monotonic();self.attempted=False;self.last_tick=0
        self.retired=[]   # earlier clips' players: stopped until they really stop
    def start(self):pass  # The window owner calls tick; workers must never call GUI/Player APIs.
    def close(self):
        self.stop_event.set();self.resolve_cancel.set();self.player.cancel()
        self.window.setProperty('meganexus.preview','')
        self.window.setProperty('meganexus.preview.loading','')
        # Never wait for network, Player.play or a lock from a Kodi onClick handler.
    def _sweep(self):
        for old in list(self.retired):
            try:playing=old.owns()
            except Exception:playing=False
            if playing:old.cancel();old.stop_owned()
            elif not old.token or time.monotonic()-getattr(old,'retired_at',0.)>30:self.retired.remove(old)
    def finish(self):
        self.close();self.player.stop_owned();self._sweep();self._clear()
    def pause(self):
        self.resolve_cancel.set();self.player.cancel();self.player.stop_owned();self._clear()
        self.previous=None;self.changed=time.monotonic();self.attempted=False
    def _mute(self,on):
        """7.0.42: automatic trailers without sound - Kodi muted while one plays, given
        back after (only when we muted it)."""
        import json as _json
        def rpc(method,params=None):
            try:return _json.loads(xbmc.executeJSONRPC(_json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params or {}}))).get('result')
            except Exception:return None
        # Kodi's mute icon and volume bar stay hidden meanwhile (skin: meganexus.quiet)
        # and a moment after the sound comes back - the bar showed as the trailer ended.
        home=xbmcgui.Window(10000)
        if on and not getattr(self,'muted_by_us',False):
            if (rpc('Application.GetProperties',{'properties':['muted']}) or {}).get('muted') is False:
                home.setProperty(QUIET,str(time.time()))
                if rpc('Application.SetMute',{'mute':True}) is True:self.muted_by_us=True
                else:home.clearProperty(QUIET)
        elif not on and getattr(self,'muted_by_us',False):
            self.muted_by_us=False
            stamp=str(time.time());home.setProperty(QUIET,stamp)
            if (rpc('Application.GetProperties',{'properties':['muted']}) or {}).get('muted') is True:rpc('Application.SetMute',{'mute':False})
            def later():
                xbmc.Monitor().waitForAbort(QUIET_AFTER)
                if home.getProperty(QUIET)==stamp:home.clearProperty(QUIET)   # no new trailer muted meanwhile
            threading.Thread(target=later,name='MegaNexusQuiet',daemon=True).start()
    def _clear(self):
        from resources.lib import refresh_guard
        refresh_guard.restore()
        self._mute(False)
        self.window.setProperty('meganexus.preview','')
        self.window.setProperty('meganexus.preview.loading','')
        home=xbmcgui.Window(10000)
        # Clear only our UI flags. The item's token and cancellation registry
        # still identify a queued clip when its AV callback arrives late.
        keys=('meganexus.preview.active','meganexus.preview.silent','meganexus.preview.pending')
        for key in keys:
            if home.getProperty(key)==self.player.token:home.clearProperty(key)
        from resources.lib.wallpaper_video import release
        release()
    def _resolve(self,key,row,direct_only,cancelled=None):
        from resources.lib.imdb_trailers import source_setting
        target=row.get('target') or {}
        cache_key=(target.get('media_type'),target.get('canonical_id'),direct_only,source_setting())
        cached=_CACHE.get(cache_key)
        if cached and cached[0]>time.monotonic() and (cached[1].startswith('https://') or os.path.isfile(cached[1])):return cached[1]
        from resources.lib.trailer_cache import prepare
        from resources.lib.trailer_support import playable
        stop=cancelled or self.resolve_cancel
        url=''
        for selected in selected_trailers(row,direct_only=direct_only):
            url=playable(selected,prepare,stop)
            if url or stop.is_set():break
        # Cancelled/busy resolution is not evidence that this title lacks a trailer.
        if url:_CACHE[cache_key]=(time.monotonic()+1800,url)
        while len(_CACHE)>64:_CACHE.popitem(last=False)
        return url
    def _work(self,key,row,direct_only,token,cancelled):
        try:
            url=self._resolve(key,row,direct_only,cancelled)
        except Exception:url=''
        self.results.put((key,row,token,url))
    def tick(self):
        now=time.monotonic()
        if self.stop_event.is_set() or now-self.last_tick<.25:return
        self.last_tick=now
        self._sweep()
        addon=cached_addon();home=xbmcgui.Window(10000)
        from resources.lib.saver_state import active as screensaver_active
        if screensaver_active():
            self.pause()
            return
        def number(key,default,low,high):
            try:return min(high,max(low,float(addon.getSetting(key) or default)))
            except ValueError:return default
        enabled=addon.getSetting('meganexus_auto_trailers')=='true'
        if not enabled and not self.player.token and not self.job:return
        selection=self.window.preview_selection();key,row=selection if selection else (None,{})
        if key!=self.previous or not enabled:
            self.resolve_cancel.set()
            self.player.cancel();self.player.stop_owned();self._clear()
            self.previous=key;self.changed=now;self.attempted=False;self.play_started=0;self.failed_session=False
        while not self.results.empty():
            resolved_key,resolved_row,token,url=self.results.get_nowait()
            if home.getProperty('meganexus.preview.pending')==token:home.clearProperty('meganexus.preview.pending')
            if not enabled or key!=resolved_key or self.player.cancelled or token!=self.player.token:continue
            if not url:
                xbmc.log('[MegaNexus] Preview: no trailer found for %s'%resolved_row.get('title',''),xbmc.LOGINFO);continue
            from resources.lib import wallpaper_video
            background = wallpaper_video.is_background(self.player)
            if self.player.isPlaying() and not background:
                # 7.0.45: the clip before is still stopping (the Cube's decoder takes its
                # time) - this one waits for it; it was dropped and the card had no trailer.
                waited=getattr(self,'waiting',None)
                if not waited or waited[0]!=token:waited=self.waiting=(token,now)
                if now-waited[1]<PLAY_WAIT:
                    self.results.put((resolved_key,resolved_row,token,url));break
                xbmc.log('[MegaNexus] Preview: another video kept playing - no trailer for %s'%resolved_row.get('title',''),xbmc.LOGINFO)
                continue
            xbmc.log('[MegaNexus] Preview: starting the trailer of %s'%resolved_row.get('title',''),xbmc.LOGINFO)
            wallpaper_video.suspend(self.player)
            item=xbmcgui.ListItem(label='Preview: '+resolved_row.get('title',''))
            item.setProperty('meganexus.preview',token);item.setProperty('IsPlayable','true')
            try:item.setContentLookup(False)
            except AttributeError:pass
            home.setProperty('meganexus.preview.active',token);home.setProperty('meganexus.preview.silent',token)
            self.window.setProperty('meganexus.preview.loading','1')
            from resources.lib import refresh_guard
            refresh_guard.suspend()  # 6.0.35: no TV mode switch for previews (issue #4)
            if addon.getSetting('meganexus_trailers_muted')=='true':self._mute(True)
            self.play_started=now;self.player.path=url;self.player.requested=True;self.player.play(url,item,windowed=True)
        if self.play_started and self.player.ready and not self.player.isPlayingVideo():
            self._clear();self.play_started=0
        if not enabled or not key or self.failed_session:return
        if not self.player.cancelled and self.player.owns():
            if self.player.ready or self.player.getTime()>.15:
                self.player.ready=True
                if not getattr(self.player,'filled',False):
                    self.player.filled=fill_corner()   # 7.0.44: also here - Kodi's view mode for this clip
                self.window.setProperty('meganexus.preview','1')
                self.window.setProperty('meganexus.preview.loading','')
            duration=number('meganexus_trailer_duration',90,0,600)
            if duration>0 and self.player.getTime()>=duration:
                self.player.cancel();self.player.stop_owned();self._clear()
        if self.player.failed or (self.play_started and not self.player.ready and now-self.play_started>20):
            xbmc.log('[MegaNexus] Preview: the trailer did not start (%s)'%('error' if self.player.failed else 'no picture in 20 s'),xbmc.LOGINFO)
            self.player.cancel();self.player.stop_owned();self.failed_session=True;self._clear();return
        if self.attempted or now-self.changed<number('meganexus_trailer_delay',6,3,30):return
        from resources.lib.wallpaper_video import is_background
        if (self.job and self.job.is_alive()) or (self.player.isPlaying() and not is_background(self.player)):return
        self.player.retired_at=now;self.retired.append(self.player)
        self.attempted=True;self.play_started=0;self.player=PreviewPlayer();self.player.token=uuid.uuid4().hex
        self.resolve_cancel=threading.Event()
        token=self.player.token;home.setProperty('meganexus.preview.pending',token)
        self.job=threading.Thread(target=self._work,args=(key,dict(row),False,token,self.resolve_cancel),name='MegaNexusPreviewFetch',daemon=True);self.job.start()
