# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Remote-friendly Nuvio-style shelves, with cancellable background catalog loading."""
import queue
import threading
import time
import json
import traceback
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import art_cache
from resources.lib import browse_cache
from resources.lib import home_data
from resources.lib import simkl_watched
from resources.lib.settings_cache import cached_addon
from resources.lib.plain_text import without_emoji
from .dialog import Dialog
from . import listitems
from . import perf
from resources.lib.theme import folder as theme_folder
from . import browse_meta
from . import kodi_textures
from . import precache
_ORIGIN = 'mnx-ceafa2d639c9'

ADDON = xbmcaddon.Addon('script.meganexus')
BACK = {9, 10, 92, 216, 247, 257, 275, 61448, 61467}
ROW_BASE = 7000
NAV = {101: ''}
LOAD_WORKERS = 4
SEED_DISK_ROWS = 6        # shelves that may read SQLite synchronously while painting
PREFETCH_DWELL = .25      # seconds a collection tile must stay selected before prefetch
DETAILS_DWELL = .6        # seconds on a title before its details load quietly (6.0.32)
PREFETCH_AGAIN = 240      # seconds before the same collection is prefetched again
PREFETCH_ART = 10         # first cards whose artwork is warmed in the image proxy (a screen)
COLD_ART_IMAGES = 600     # proxy RAM already this full: skip the session warm-up
COLD_ART_PER_SHELF = 12   # a screen of posters per collection shelf (one preload round)
COLD_ART_WORKERS = 3      # background posters in flight at once (the proxy has 6 download workers)
COLD_ART_DELAY = 20       # 7.0.23: seconds after Home opens before the background preload starts
COLD_ART_IDLE = 4         # ... and seconds without cursor movement before each next step
SHELF_MEMORY_SECONDS = 300
SELECTION_TTL = 1.        # 7.0.30: seconds a read focus / card is reused while no key is pressed
ROW_AHEAD = 12            # 7.0.32: more cards than a row shows at once
TOP_BUTTONS = (105, 106, 107, 108, 111, 113)   # search, library, settings, HUB, film waiting
AHEAD_ROWS = 2            # 7.0.32: a collection's first screen, loaded while its tile is selected
AHEAD_CARDS = 8
AHEAD_SLOTS = 18          # hidden images in the Home layout (meganexus.ahead.N)
# 7.0.48: Home holds home_data.MAX_ROWS rows; a view with more is drawn a page at a time.
# Down on a page's last row / Up on a later page's first row focus these invisible
# buttons (review/make_home_pages.py - the arrows never reach Python) and turn the page.
NEXT_PAGE, PREVIOUS_PAGE = 7099, 7098
GROW_AHEAD = 6            # 7.0.48, "Browse all" off: a row's next titles load this many cards before its end


def home_xml():
    # Viewport dimensions stay in XML, with a compact variant for a hidden hero.
    return 'meganexus_home_compact.xml' if xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)') else 'meganexus_home.xml'


def launch_command(row):
    """Only addon-owned routes are accepted from cards; provider text is never a builtin."""
    p = home_data._api()
    if row.get('target'):
        path, folder = p._content_click_path(**row['target'])
    else:
        path, folder = row.get('path') or '', bool(row.get('is_folder'))
    if not path.startswith('plugin://') or any(c in path for c in ('\n', '\r', '"')):
        return ''
    return 'ActivateWindow(Videos,"%s",return)' % path if folder else 'RunPlugin("%s")' % path


def _server_play(path):
    """Start a Plex / Jellyfin item; wait while its version picker is open so
    Home does not come back over the starting video."""
    if not path.startswith('plugin://plugin.video.meganexus/?action=') or any(c in path for c in ('\n', '\r', '"')):
        return ''
    xbmc.executebuiltin('RunPlugin("%s")' % path)
    monitor=xbmc.Monitor();start=time.monotonic()
    while not monitor.waitForAbort(.2):
        if xbmc.Player().isPlayingVideo():return 'playing'
        picking=xbmc.getCondVisibility('Window.IsVisible(selectdialog) | Window.IsVisible(contextmenu) | Window.IsVisible(busydialog)')
        if picking:start=time.monotonic()
        elif time.monotonic()-start>8:return ''
    return ''



ROW_TITLE=6600       # 7.0.42: the row names (meganexus_home*.xml), moved with their cards


def row_frame(landscape):
    """(row height, card height, cards' top) of a Home row (7.0.42). The usual
    layout shows one row: every row is as tall as a poster row and the cards
    sit on its bottom, so posters and landscape rows end on the same line. The
    compact layout keeps rows as tall as their cards."""
    card=214 if landscape else 330
    if home_xml()=='meganexus_home_compact.xml':return 62+card,card,62
    return 392,card,392-card

class HomeWindow(Dialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self._shelves = kwargs.get('shelves') or []
        self._pages = list(self._shelves)   # 7.0.48: every row of this view (_shelves: the page drawn)
        self._page = 0
        self._bucket = ''
        self._generation = 0
        self._closed = False
        self._pending = ''
        self._updates = queue.Queue()
        self._grown = queue.Queue()      # 7.0.48: a row's next titles (Browse all off)
        self._pool = None
        self._futures = []
        self._last_touch = 0
        self._focus_memory = {}
        self._previews = None
        self._suspended = False
        self._shelf_memory={}
        self._memory_lock=threading.Lock()
        self._memory_epoch=0
        self._prefetch_pool=None
        self._prefetch_futures=[]
        self._prefetched={}
        self._hover=(None,0)
        self._details_asked=None
        self._anim=[None,None,False]   # wanted, ready, worker running (7.0.21)
        self._anim_focus=None          # (card, animation) playing or played
        self._anim_until=0
        self._anim_failed={}           # animation: no new try before this time
        self._anim_seconds={}          # animation: playing time of one pass
        self._warmed_art=set()
        self._scheduled=set();self._drawn=set()
        self._watch_loaded=False
        self._progress_revision=xbmcgui.Window(10000).getProperty('meganexus.progress.revision')
        self._last_progress_check=0
        self._bucket = kwargs.get('bucket') or ''
        # 7.0.32: a collection opens in its own screen over Home (as on Android TV
        # apps); Home stays as it is behind it and Back only closes it.
        self._nested=bool(kwargs.get('nested'))
        self._parent=kwargs.get('parent')   # Home, for a collection screen
        self._collection_window=None
        self._shown=False      # the collection screen is open (nested)
        self._forward=None     # a Home button pressed in the collection screen
        self._leaving=False    # 7.0.42: on the way to the HUB, Home stays until it is ready
        self._entered=False
        self._scroll_from=0.;self._scroll_to=0.;self._scroll_started=0.
        self._covered={}
        # open_home passes the revision read before it built the shelves, so a
        # progress write racing that build is still detected in onInit.
        self._continue_fresh='progress_revision' in kwargs
        if self._continue_fresh:self._progress_revision=kwargs['progress_revision']

    def onInit(self):
        if self._entered and not self._nested:xbmc.log('[MegaNexus] Home initialised again by Kodi; the cursor stays where it was.',xbmc.LOGINFO)
        self._opened_at=time.monotonic()
        self.setProperty('meganexus.home.error','')
        reset_continue=False
        try:
            saved = json.loads(xbmcgui.Window(10000).getProperty('meganexus.home.focus') or '{}')
            if isinstance(saved, dict):
                self._focus_memory = saved
        except (ValueError, TypeError):
            pass
        try:
            window=xbmcgui.Window(10000)
            revision=window.getProperty('meganexus.progress.revision')
            if not self._bucket and self._shelves and self._shelves[0].get('continue_job'):
                # Every Home entry starts this shelf at its newest title, even
                # after a restart/import or when another view consumed revision.
                # Returning from Details/Settings keeps the selected title.
                entry=not self._entered
                reset_continue=entry
                # open_home built this shelf moments ago; rebuild only if progress changed.
                if not (entry and self._continue_fresh) or revision!=self._progress_revision:
                    self._shelves[0]=home_data.continue_shelf()
                    if not getattr(self,'_page',0) and getattr(self,'_pages',None):self._pages[0]=self._shelves[0]
                self._progress_revision=revision
                if entry and self._focus_memory.get('home',[0,0])[0]==0:self._focus_memory['home']=[0,0]
                window.setProperty('meganexus.home.progress_seen',revision)
            self._entered=True
            self._paint(self._shelves,keep_pages=True)   # 7.0.48: this page again, the others kept
            if reset_continue:self.getControl(ROW_BASE).selectItem(0)
        except Exception:
            xbmc.log('[MegaNexus] Home initialization failed:\n'+traceback.format_exc(),xbmc.LOGERROR)
            self.setProperty('meganexus.home.error','Home could not display its collections. Open Settings or reinstall the complete MegaNexus ZIP.')
            self.setFocusId(107)
            return
        try:
            from .home_trailers import Controller
            if self._previews:self._previews.finish()
            self._previews = Controller(self)
            self._previews.start()
        except Exception:
            # Optional trailers must never prevent local collection cards rendering.
            xbmc.log('[MegaNexus] Preview controller unavailable: '+traceback.format_exc(),xbmc.LOGWARNING)

        self.restore_focus()

    def _selection(self):
        """(focused control, its card, hero hidden) for the window loop (7.0.30).

        The loop runs 20 times a second; each question to Kodi waits for its
        drawing thread (on CoreELEC / Android boxes frames were lost to it).
        Focus and card change only through keys (onAction / onFocus, which clear
        this) or our own repaint, so they are read again only then - and once
        a second for anything else."""
        now=time.monotonic();cached=getattr(self,'_sel_cache',None)
        if cached and now-cached[0]<SELECTION_TTL:return cached[1]
        control_id=self.getFocusId();pos=-1
        if ROW_BASE<=control_id<ROW_BASE+len(self._shelves):
            try:pos=self.getControl(control_id).getSelectedPosition()
            except Exception:pos=-1
        hidden=xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)')
        self._sel_cache=(now,(control_id,pos,hidden))
        return control_id,pos,hidden

    def preview_selection(self):
        if self._closed or self._suspended: return None
        control_id,pos,hidden=self._selection()
        if hidden:return None
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves): return None
        rows = self._shelves[index]['rows']
        if not 0 <= pos < len(rows) or not rows[pos].get('target') or rows[pos].get('person'): return None
        return (self._generation, index, pos), dict(rows[pos])

    @staticmethod
    def _shelf_key(shelf):
        jobs=shelf.get('collection_job') or ([(*shelf['job'],shelf.get('extra') or {})] if shelf.get('job') else [])
        return json.dumps([(p.get('id'),c.get('type'),c.get('id'),extra) for p,c,extra in jobs],sort_keys=True) if jobs else ''

    def _remembered(self, key):
        if not key:return None
        with self._memory_lock:
            saved=self._shelf_memory.get(key)
            if saved and saved[0]>time.monotonic():return saved[1]
        return None

    def _remember_rows(self, key, rows, epoch=None):
        if not key or not any(row.get('target') for row in rows or []):return
        with self._memory_lock:
            if epoch is not None and epoch!=self._memory_epoch:return  # Settings changed meanwhile.
            self._shelf_memory.pop(key,None)
            self._shelf_memory[key]=(time.monotonic()+SHELF_MEMORY_SECONDS,rows)
            while len(self._shelf_memory)>32:self._shelf_memory.pop(next(iter(self._shelf_memory)))

    def _forget_rows(self):
        with self._memory_lock:
            self._memory_epoch+=1;self._shelf_memory.clear()
        self._prefetched.clear()

    @staticmethod
    def _seed(shelf, index):
        """Paint cached catalog pages synchronously so an opened collection is
        never a wall of 'Loading' cards. Point lookups only, no network."""
        if shelf.get('_loaded') or not (shelf.get('job') or shelf.get('collection_job')):return
        try:rows=home_data.load_catalog(shelf,cached_only=True if index<SEED_DISK_ROWS else 'memory')
        except Exception:return
        if rows:
            from resources.lib.art_provider import pending
            # 7.0.29: pictures from the Artwork provider not cached yet - load once more.
            shelf.update(rows=rows,_loaded=not pending(rows))

    def _paint(self, shelves, page=0, keep_pages=False):
        """``shelves``: every row of the view - page ``page`` of home_data.MAX_ROWS is drawn
        (7.0.48); ``keep_pages``: ``shelves`` is the page drawn now, drawn again."""
        if not keep_pages:
            self._pages=list(shelves);size=home_data.MAX_ROWS
            self._page=max(0,min(page,(len(self._pages)-1)//size)) if self._pages else 0
            start=self._page*size
            if any(s.get('lazy') for s in self._pages[start:start+size]):
                # a later page's rows made whole now (collections_home.catalog_rows), kept made
                from resources.lib.collections_home import resolve
                self._pages[start:start+size]=[resolve(s) for s in self._pages[start:start+size]]
            shelves=self._pages[start:start+size]
        with perf.timed('Home paint', tab=self._bucket or 'home') as step:
            self._paint_rows(shelves)
            step.details['rows']=len(self._shelves)
            step.details['cards']=sum(len(s.get('rows') or []) for s in self._shelves)

    def _paint_rows(self, shelves):
        self.setProperty('meganexus.search.query',getattr(self,'_search_query','') if self._bucket=='search' else '')
        self._anim_focus=None;self.setProperty('meganexus.anim_ready','')
        for index,shelf in enumerate(shelves):
            saved=self._remembered(self._shelf_key(shelf))
            if saved:shelf.update(rows=saved,_loaded=True)
            elif index<home_data.MAX_ROWS:self._seed(shelf,index)
        self._card_shape=cached_addon().getSetting('meganexus_card_shape') or 'poster'
        shelves = [dict(s, rows=s.get('rows') or [home_data.placeholder(
            'No titles yet', 'Open Settings to connect your metadata provider.')]) for s in shelves[:home_data.MAX_ROWS]]
        if not shelves:
            shelves = [{'title':'Welcome to MegaNexus', 'rows':[home_data.placeholder(
                'Open Settings', 'Set up on your phone (HUB Settings › Set up on phone) or add a metadata add-on to load titles.',
                'plugin://plugin.video.meganexus/?action=setup_center')]}]
        self._generation += 1
        generation = self._generation
        for future in self._futures:
            future.cancel()
        self._futures = []
        self._scheduled=set();self._drawn=set()
        self._shelves = shelves
        self.setProperty('meganexus.compact','1' if home_xml()=='meganexus_home_compact.xml' else '')
        self._browse_all=home_data.browse_all()   # read once per paint, not on every tick
        for i in range(home_data.MAX_ROWS):
            self.setProperty('meganexus.row.%d.visible' % i, '1' if i < len(shelves) else '')
            if i < len(shelves):
                landscape = shelves[i].get('shape',self._card_shape)=='landscape'
                self.setProperty('meganexus.row.%d.shape' % i, 'landscape' if landscape else 'poster')
                group,card,art_top=row_frame(landscape)
                self.getControl(6500 + i).setHeight(group)
                self.getControl(ROW_BASE + i).setHeight(card)
                # 7.0.42: the cards sit on the row's bottom (posters or landscape - the
                # bottom edge never moves), the row's name right above them
                try:
                    self.getControl(ROW_BASE + i).setPosition(0,art_top)
                    self.getControl(ROW_TITLE + i).setPosition(16,art_top-62)
                except Exception:pass
                up=ROW_BASE+i-1 if i else (PREVIOUS_PAGE if getattr(self,'_page',0) else 101)
                down=ROW_BASE+i+1 if i+1<len(shelves) else (NEXT_PAGE if self._more_pages() else ROW_BASE+i)
                self.getControl(ROW_BASE+i).controlUp(self.getControl(up))
                self.getControl(ROW_BASE+i).controlDown(self.getControl(down))
                self._set_right(i)
                # 7.0.24: row titles can be switched off (Home & appearance);
                # Continue Watching and the other built-in rows keep theirs.
                plain=shelves[i].get('catalog_row') or shelves[i].get('job') or shelves[i].get('collection_job') or any(r.get('collection_id') for r in shelves[i].get('rows') or [])
                titles=cached_addon().getSetting('meganexus_row_titles')!='false'
                self.setProperty('meganexus.row.%d.title' % i, without_emoji(shelves[i]['title']) if titles or not plain else '')
                self._set_rows(i, shelves[i]['rows'])
        try:
            saved = self._focus_memory.get(self._bucket or 'home') or [0, 0]
            saved = [int(saved[0]), int(saved[1])] + [int(x) for x in saved[2:3]]
        except (ValueError, TypeError, IndexError, KeyError):saved=[0,0]
        row = max(0, min(int(saved[0]), len(shelves) - 1))
        self.setProperty('meganexus.hero_row', str(row))
        self._row_scroll_focus(row)
        self.setProperty('meganexus.tab', self._bucket or 'home')
        # 7.0.21: the rows slide in on every repaint (a/b: each change starts the
        # skin's Conditional animation again).
        self._paint_flip='b' if getattr(self,'_paint_flip','')=='a' else 'a'
        if any(s.get('posters_refresh') for s in shelves) and not getattr(self,'_posters_checked',False):
            # 7.0.48: the saved posters wall made again in the background when the collections
            # changed or it is old - the next Home shows it (no repaint under the remote)
            self._posters_checked=True
            if self._pool is None:self._pool=ThreadPoolExecutor(max_workers=LOAD_WORKERS, thread_name_prefix='MegaNexusHome')
            self._pool.submit(self._refresh_posters)
        # 7.0.32: back from a collection the rows do not slide in: they appear
        # once they stand where they were (meganexus.paint ra / rb).
        self.setProperty('meganexus.paint',('r' if getattr(self,'_returning',False) else '')+self._paint_flip)
        self.setFocusId(ROW_BASE+row)
        self._select(self.getControl(ROW_BASE + row), int(saved[1]), len(shelves[row]['rows']), saved[2] if len(saved) > 2 else None)
        if self._pool is None:
            self._pool = ThreadPoolExecutor(max_workers=LOAD_WORKERS, thread_name_prefix='MegaNexusHome')
        self._queue_visible()
        if not getattr(self,'_watch_loaded',False):
            self._watch_loaded=True
            self._pool.submit(self._refresh_watched)
        try:
            if not self._nested:self._start_cold_art_warm()
        except Exception:pass  # Optional warm-up never blocks Home.
        self._touch()

    def _more_pages(self):
        return (getattr(self,'_page',0)+1)*home_data.MAX_ROWS<len(getattr(self,'_pages',()) or ())

    def _turn(self, step):
        """7.0.48: the next / previous page of this view's rows - the next one starts on
        its first row, the previous one ends on its last (where the cursor came from)."""
        size=home_data.MAX_ROWS;page=self._page+step
        if page<0 or page*size>=len(self._pages):
            self.setFocusId(ROW_BASE);return
        row=0 if step>0 else min(size,len(self._pages)-page*size)-1
        self._focus_memory[self._bucket or 'home']=[row,0]
        if self._previews:self._previews.pause()
        self._paint(self._pages,page)

    @staticmethod
    def _select(control, pos, count, shown=None):
        """Select a card; with ``shown`` (its place on the screen when it was left,
        7.0.32) the row is scrolled as it was: a list scrolls only as far as the
        selected card needs, so first past it, then back to the first card shown."""
        pos=min(max(0,pos),count-1)
        try:first=pos-int(shown)
        except (TypeError,ValueError):first=0
        if 0<first<pos+1:
            control.selectItem(min(count-1,first+ROW_AHEAD))
            control.selectItem(first)
        control.selectItem(pos)

    def _row_geometry(self):
        offset=0;rows=[]
        for shelf in self._shelves:
            landscape=shelf.get('shape',getattr(self,'_card_shape','poster'))=='landscape'
            height,_,art_top=row_frame(landscape)
            rows.append((offset,height,171 if landscape else 288,art_top));offset+=height+14
        return rows,max(0,offset-14)

    def _current_scroll(self):
        fraction=max(0.,min(1.,(time.monotonic()-getattr(self,'_scroll_started',0.))/.18))
        start=getattr(self,'_scroll_from',0.);end=getattr(self,'_scroll_to',0.)
        return start+(end-start)*fraction

    def _row_scroll_focus(self,row):
        """Mirror Kodi's grouplist scroll geometry without changing its layout."""
        rows,total=self._row_geometry()
        if not 0<=row<len(rows):return
        viewport=890 if home_xml()=='meganexus_home_compact.xml' else 406   # 7.0.42: one row
        current=self._current_scroll();offset,height,_,_=rows[row];target=getattr(self,'_scroll_to',0.)
        if row==0:target=0.
        elif row==len(rows)-1:target=max(0.,total-viewport)
        elif offset<current:target=float(offset)
        elif offset+height>current+viewport:target=float(offset+height-viewport)
        if target!=getattr(self,'_scroll_to',0.):
            self._scroll_from=current;self._scroll_to=target;self._scroll_started=time.monotonic()
        self._update_row_coverage()

    def _update_row_coverage(self):
        # 7.0.45: going up, the rows that will show are uncovered at once (the scroll's
        # end); they stayed faded while the estimate passed them - rows vanished for a
        # moment on Up (CoreELEC report). Going down a row is covered as it leaves.
        scroll=min(self._current_scroll(),getattr(self,'_scroll_to',0.));rows,_=self._row_geometry()
        cached=getattr(self,'_covered',{})
        for index,(offset,_,art_height,art_top) in enumerate(rows):
            # Artwork starts after the row heading (row_frame). Keep exactly 70%;
            # only the mostly clipped card fragments above that disappear.
            hidden=scroll>offset+art_top+6+art_height*.70
            if cached.get(index)!=hidden:
                self.setProperty('meganexus.row.%d.covered'%index,'1' if hidden else '')
                cached[index]=hidden
        self._covered=cached

    def _queue_visible(self):
        if not self._pool or self._closed or self._suspended:return
        row=max(0,min(self._selection()[0]-ROW_BASE,len(self._shelves)-1))
        # Load the focused shelf and its neighbours before off-screen catalogs.
        indices=list(dict.fromkeys([row,row+1,row+2,0]))
        for i in indices:
            if i>=len(self._shelves) or i in self._scheduled:continue
            shelf=self._shelves[i]
            if shelf.get('continue_job') or ((shelf.get('job') or shelf.get('collection_job') or shelf.get('people_job') or shelf.get('local_job') or shelf.get('server_job') or shelf.get('posters_job')) and not shelf.get('_loaded')):
                self._scheduled.add(i)
                shelf['progress_revision']=self._progress_revision
                self._futures.append(self._pool.submit(self._load, i, dict(shelf), self._generation))

    def _refresh_watched(self):
        try:simkl_watched.refresh()
        except Exception:return  # Keep offline status; never block Home on Simkl.
        if not self._closed:self._updates.put((self._generation,-1,[]))

    def _watched_badges(self):
        data=simkl_watched.snapshot()
        for i,shelf in enumerate(self._shelves):
            control=self.getControl(ROW_BASE+i)
            for pos,row in enumerate(shelf['rows']):
                target=row.get('target') or {}
                watched=row.get('watched') or simkl_watched.state(data,target.get('media_type'),target.get('canonical_id')).get('watched')
                control.getListItem(pos).setProperty('watched','1' if watched else '')

    def _load(self, index, shelf, generation):
        if self._closed or generation != self._generation:
            return
        try:
            if shelf.get('continue_job'):
                from resources.lib.continue_metadata import enrich
                def stopped():return self._closed or generation!=self._generation or shelf.get('progress_revision')!=self._progress_revision
                def update(rows):
                    if not stopped():
                        self._updates.put((generation, index, rows, shelf.get('progress_revision')))
                times=[time.monotonic()]
                rows=enrich(shelf['rows'],update,stopped);times.append(time.monotonic())
                update(rows)   # 7.0.45: drawn now - the network refresh below follows behind Home
                from resources.lib.watch_nextup import augment
                rows=augment(rows,refresh=True,stopped=stopped);times.append(time.monotonic())
                from resources.lib.continue_metadata import dedupe
                rows=dedupe(rows,network=True);times.append(time.monotonic())   # 7.0.29: tmdb:… and tt… of one film are one card
                rows=home_data._artwork(rows,stopped=stopped);times.append(time.monotonic())   # 7.0.29: the Artwork provider's pictures
                # 7.0.45: where Continue Watching's time goes (it came late on the Cube)
                xbmc.log('[MegaNexus][perf] Continue Watching: %d cards · titles %d ms · next episodes %d ms · same title %d ms · artwork %d ms'
                         %((len(rows),)+tuple(int((b-a)*1000) for a,b in zip(times,times[1:]))),xbmc.LOGINFO)
                if stopped():return
            elif shelf.get('posters_job'):
                # 7.0.48: MegaNexus posters made for the first time - Home draws them when done
                from resources.lib import home_posters
                if home_posters.build(stopped=lambda:self._closed or generation!=self._generation) and not self._closed:
                    self._updates.put((generation,-2,[]))
                return
            else:rows = home_data.load_catalog(shelf,stopped=lambda:self._closed or generation!=self._generation)
        except Exception:
            rows = [home_data.placeholder('Open catalog',
                'This catalog could not load right now. Select to retry in the full browser.', shelf.get('path',''))]
        if self._closed or generation != self._generation:
            return
        self._updates.put((generation, index, rows, shelf.get('progress_revision') if shelf.get('continue_job') else None))

    def _refresh_posters(self):
        from resources.lib import home_posters
        try:
            if home_posters.stale(home_posters.saved()):home_posters.build(stopped=lambda:self._closed)
        except Exception:
            xbmc.log('[MegaNexus] Posters wall not refreshed: '+traceback.format_exc(),xbmc.LOGDEBUG)

    def _align_columns(self, index, pos):
        """7.0.48: MegaNexus posters - the rows above and below keep the column the cursor
        is in, so Up / Down go straight up and down the wall (the arrows never reach
        Python: the neighbours are set ahead, once per move)."""
        if getattr(self,'_aligned',None)==(self._generation,index,pos) or not self._shelves[index].get('posters_row'):return
        self._aligned=(self._generation,index,pos)
        for other in (index-1,index+1):
            if 0<=other<len(self._shelves) and self._shelves[other].get('posters_row'):
                try:self.getControl(ROW_BASE+other).selectItem(min(pos,len(self._shelves[other]['rows'])-1))
                except Exception:pass

    def _grow_rows(self):
        """7.0.48: "Browse all" off - the focused catalog row goes on by itself: once the
        cursor is GROW_AHEAD cards from its end, its next titles load in the background
        (catalog_pages, as the grid's Load more) and are added at the end of the row; the
        row is not drawn again and the cursor stays where it is."""
        for _ in range(4):
            try:generation,index,rows,jobs=self._grown.get_nowait()
            except queue.Empty:break
            if generation==self._generation and 0<=index<len(self._shelves):self._append_rows(index,rows,jobs)
        control_id,pos,_=self._selection();index=control_id-ROW_BASE
        if not 0<=index<len(self._shelves) or pos<0:return
        self._align_columns(index,pos)
        if getattr(self,'_browse_all',True) or self._suspended or not self._pool:return
        shelf=self._shelves[index]
        if not shelf.get('_loaded') or shelf.get('_growing') or not self._grows(shelf) or pos<len(shelf['rows'])-GROW_AHEAD:return
        from urllib.parse import urlsplit,parse_qs
        params={k:v[0] for k,v in parse_qs(urlsplit(shelf['path']).query).items()}
        shelf['_growing']=True
        self._futures.append(self._pool.submit(self._grow,index,params,shelf.get('_jobs'),self._generation))

    def _grows(self,shelf):
        """7.0.48: a catalog row that goes on by itself ("Browse all" off) until its last titles are in."""
        path=shelf.get('path') or ''
        return (not getattr(self,'_browse_all',True) and not shelf.get('_grow_done')
                and ('action=meganexus_collection' in path or 'action=catalog_all' in path))

    def _set_right(self,index):
        """Right on a row's last card goes round to its first (the row points at itself) -
        except on a row that still grows: it points at the row's name (a label, never
        focused), so the cursor waits on the last card until the next titles are added."""
        try:self.getControl(ROW_BASE+index).controlRight(self.getControl((ROW_TITLE if self._grows(self._shelves[index]) else ROW_BASE)+index))
        except Exception:pass

    def _grow(self,index,params,jobs,generation):
        from resources.lib import catalog_pages
        stopped=lambda:self._closed or generation!=self._generation
        try:
            if jobs is None:jobs=catalog_pages.jobs_for(params)
            result=catalog_pages.fetch_page(jobs,stopped=stopped)
        except Exception:result=None
        if not stopped():self._grown.put((generation,index,)+(result if result else ([],None)))

    def _append_rows(self,index,rows,jobs):
        shelf=self._shelves[index];shelf['_growing']=False
        if jobs is None:shelf['_grow_done']=True;self._set_right(index);return   # failed: the row stays as it is
        shelf['_jobs']=jobs
        known=set(self._row_ids.get(index) or [self._identity(r) for r in shelf['rows']])
        new=[]
        for row in rows:
            identity=self._identity(row)
            if row.get('target') and identity not in known:known.add(identity);new.append(row)
        if all(job['done'] for job in jobs):shelf['_grow_done']=True;self._set_right(index)
        if not new:return
        watched_data=simkl_watched.snapshot();items=[];sigs=self._card_sigs.setdefault(index,[])
        for row in new:
            li=listitems.item(label=without_emoji(row.get('title') or 'Untitled'),label2=without_emoji(row.get('subtitle') or ''))
            self._fill(li,row,watched_data);sigs.append(self._filled);items.append(li)
        # Kodi binds the whole list again on addItems (the cursor goes to the first card):
        # it is put back on its card at once (a list just bound does not scroll)
        control=self.getControl(ROW_BASE+index);pos=control.getSelectedPosition()
        control.addItems(items)
        if pos>0:control.selectItem(pos)
        shelf['rows']=shelf['rows']+new
        self._row_ids.setdefault(index,[]).extend(self._identity(r) for r in new)

    def _ratings_tick(self):
        """7.0.29: the focused title's ratings beside its details line - from the
        cache at once, MDBList's request only once the cursor rests on it."""
        try:selection=self.preview_selection()
        except Exception:selection=None
        key=None
        if selection:
            target=selection[1].get('target') or {}
            key=(target.get('media_type'),target.get('canonical_id'))
        now=time.monotonic()
        if key!=getattr(self,'_ratings_key','-'):
            self._ratings_key=key;self._ratings_at=now;self._ratings_asked=False;self._release_asked=False
            from resources.lib import ratings_row
            self._release_badge(selection[1] if selection else None)
            if not selection:ratings_row.clear(self);return
            row=selection[1];target=row.get('target') or {}
            self._ratings_meta=dict(id=target.get('canonical_id'),imdb_id=target.get('imdb_id'),tmdb_id=target.get('tmdb_id'),type=target.get('media_type'))
            own=(row.get('rating_icon') or '',row.get('rating_value') or '') if row.get('rating_value') else None
            self._ratings_fetch=None
            def later(load):self._ratings_fetch=load
            ratings_row.publish_for(self,self._ratings_meta,own,later)
        if key and not getattr(self,'_release_asked',True) and now-self._ratings_at>.6:
            self._release_asked=True;self._release_dates(key,selection[1])
        if key and getattr(self,'_ratings_fetch',None) and not self._ratings_asked and now-self._ratings_at>.6:
            self._ratings_asked=True;load=self._ratings_fetch;wanted=key
            def work():
                try:ratings=load()
                except Exception:return
                if ratings and not self._closed and getattr(self,'_ratings_key',None)==wanted:
                    from resources.lib import ratings_row
                    ratings_row.publish(self,ratings)
            threading.Thread(target=work,name='MegaNexusHomeRatings',daemon=True).start()

    def _release_badge(self,row,dates=None):
        """7.0.32: the focused title's release badge under its details line (as on
        the title page): from the card's release date at once; a film's TMDB
        dates (In cinemas / Released) once the cursor rests on it."""
        from resources.lib import release_info
        kind=text=status=''
        if row and row.get('target'):
            if dates is not None:kind,text=dates   # fetched for this card
            else:kind,text=release_info.card_badge(row,cached_only=True)   # 7.0.36: TMDB's dates kept at start
            status=release_info.card_status(row) if kind else ''   # 7.0.37: a series' Ongoing / Ended
        if (kind,text,status)!=getattr(self,'_release_shown',('','','')):
            self._release_shown=(kind,text,status)
            self.setProperty('meganexus.release.status',status)
            self.setProperty('meganexus.release.date',text if kind else '');self.setProperty('meganexus.release.kind',kind)

    def _release_dates(self,key,row):
        """A card not in the start's preload: its TMDB dates once the cursor rests."""
        row=dict(row)
        def work():
            from resources.lib import release_info
            try:badge=release_info.card_badge(row,cached_only=False)
            except Exception:return
            if badge[0] and not self._closed and getattr(self,'_ratings_key',None)==key:self._release_badge(row,badge)
        threading.Thread(target=work,name='MegaNexusHomeRelease',daemon=True).start()

    def first_rows_ready(self):
        """7.0.42: the rows Home loaded first (the visible ones) are filled and drawn.
        7.0.45: a row counts once its first rows are drawn - Continue Watching's network
        refresh (next episodes, other ids, artwork) goes on behind Home, not behind the
        opening screen (it held it up to 11 s on the Cube)."""
        if set(self._scheduled)<=getattr(self,'_drawn',set()):return True
        return all(future.done() for future in list(self._futures)) and self._updates.empty()

    def first_rows_progress(self):
        """7.0.45: the share of those rows drawn, for the opening screen's ring."""
        scheduled=set(self._scheduled)
        return len(scheduled&getattr(self,'_drawn',set()))/float(len(scheduled)) if scheduled else 1.

    def drain_updates(self):
        self.drain_events()
        if self._closed:return
        self._apply_focus()
        self._ratings_tick()
        self._update_row_coverage()
        self._queue_visible()
        try:self._grow_rows()
        except Exception:
            xbmc.log('[MegaNexus] Row growth skipped: '+traceback.format_exc(),xbmc.LOGDEBUG)
        now=time.monotonic()
        if now-self._last_progress_check>=.5:
            self._last_progress_check=now
            revision=xbmcgui.Window(10000).getProperty('meganexus.progress.revision')
            if revision!=self._progress_revision and not self._navigating(0):   # 7.0.29: not under the remote
                self._progress_revision=revision
                if not self._bucket and not getattr(self,'_page',0) and self._shelves and self._shelves[0].get('continue_job'):
                    shelf=home_data.continue_shelf();shelf['progress_revision']=revision
                    self._shelves[0]=shelf;self._set_rows(0,shelf['rows'])
                    if getattr(self,'_pages',None):self._pages[0]=shelf
                    xbmcgui.Window(10000).setProperty('meganexus.home.progress_seen',revision)
                    if self._pool:self._futures.append(self._pool.submit(self._load,0,dict(shelf),self._generation))
        if self._previews:
            try:self._previews.tick()
            except Exception:
                self._previews.close()
                xbmc.log('[MegaNexus] Preview stopped after a player error.',xbmc.LOGWARNING)
        try:self._show_ahead()
        except Exception:pass
        try:self._maybe_prefetch()
        except Exception:
            xbmc.log('[MegaNexus] Collection prefetch skipped: '+traceback.format_exc(),xbmc.LOGDEBUG)
        # Workers only enqueue data. The window owner applies Kodi controls.
        for _ in range(32):
            try:
                update = self._updates.get_nowait()
                generation, index, rows = update[:3]
            except queue.Empty:return
            if self._closed or generation != self._generation:continue
            if len(update)>3 and update[3] is not None and update[3]!=self._progress_revision:continue
            if index==-1:self._watched_badges();continue
            if index==-2:   # 7.0.48: the posters wall is made - drawn now
                if not self._bucket:self._paint(home_data.initial_shelves(),self._page)
                return
            rows = rows or [home_data.placeholder('No titles found', 'Try another collection or check Settings.')]
            unchanged=self._shelves[index].get('_loaded') and rows==self._shelves[index].get('rows')
            if not unchanged and self._navigating(index):
                # 7.0.29: never under the remote - this row changes once the keys rest.
                self._updates.put(update);break
            self._shelves[index]['rows'] = rows
            self._shelves[index]['_loaded'] = True
            self._remember_rows(self._shelf_key(self._shelves[index]),rows)
            # A cache-seeded shelf that reloads identical data keeps its items,
            # textures and selection: no flicker and no wasted GUI work.
            if not unchanged:self._set_rows(index, rows)
            if not hasattr(self,'_drawn'):self._drawn=set()
            self._drawn.add(index)   # 7.0.45: drawn - the opening screen may go

    def _maybe_prefetch(self):
        """Warm the collection under the cursor (and its neighbours) off the GUI
        thread once selection settles, so Select opens it from memory."""
        if self._closed or self._suspended or browse_cache.playback_busy():return
        control_id,pos,_=self._selection();index=control_id-ROW_BASE
        if not 0<=index<len(self._shelves) or pos<0:return
        now=time.monotonic()
        if self._hover[0]!=(index,pos):
            self._hover=((index,pos),now)
            if self._anim_focus:   # the cursor moved: the next card's cover, its animation later
                self._anim_focus=None;self.setProperty('meganexus.anim_ready','')
            return
        if now-self._hover[1]<PREFETCH_DWELL:return
        rows=self._shelves[index]['rows']
        if 0<=pos<len(rows) and rows[pos].get('target') and not rows[pos].get('person'):
            # 7.0.21: once per title the cursor rests on, not on every tick of the
            # window loop (each check read the add-on settings: 15 times a second
            # on CoreELEC while a title was selected).
            asked=(self._generation,index,pos,rows[pos]['target'].get('canonical_id'))
            if now-self._hover[1]>=DETAILS_DWELL and self._details_asked!=asked:
                self._details_asked=asked
                browse_meta.prefetch(rows[pos]['target'])
            return
        if 0<=pos<len(rows) and rows[pos].get('animation'):self._animate(rows[pos]['animation'],(index,pos))
        wanted=[rows[c]['collection_id'] for c in (pos,pos+1,pos-1)
                if 0<=c<len(rows) and rows[c].get('collection_id')]
        focused=rows[pos].get('collection_id') if 0<=pos<len(rows) else None
        if focused and focused!=getattr(self,'_ahead_for',None) and self._prefetched.get(focused,0)>now and self._prefetch_pool:
            self._ahead_for=focused   # loaded before: only its pictures again (7.0.32)
            self._prefetch_futures.append((focused,self._prefetch_pool.submit(self._load_ahead,focused,self._memory_epoch)))
        wanted=[cid for cid in wanted if self._prefetched.get(cid,0)<=now]
        if not wanted:return
        # The cursor moved on: queued work for tiles it left is dropped, so
        # the single worker always serves the tile the user is looking at.
        pending=[]
        for cid,future in self._prefetch_futures:
            if future.done():continue
            if future.cancel():self._prefetched.pop(cid,None)
            else:pending.append((cid,future))
        self._prefetch_futures=pending
        if self._prefetch_pool is None:
            self._prefetch_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='MegaNexusPrefetch')
        for collection_id in wanted:
            self._prefetched[collection_id]=now+PREFETCH_AGAIN
            if len(self._prefetched)>256:self._prefetched.pop(next(iter(self._prefetched)))
            if collection_id==focused:self._ahead_for=focused
            self._prefetch_futures.append((collection_id,self._prefetch_pool.submit(self._prefetch_collection,collection_id,self._memory_epoch,collection_id==focused)))

    def _play_animation(self, ready, focus):
        """One full pass on the resting card, then its cover again."""
        self._anim_focus=(focus,ready);self._anim_until=0
        seconds=self._anim_seconds.get(ready)
        if seconds is None:
            try:
                import xbmcvfs
                path=xbmcvfs.translatePath(ready) if ready.startswith('special://') else ready
                with open(path,'rb') as handle:seconds=art_cache.gif_seconds(handle.read())
            except (OSError,ValueError):seconds=0
            self._anim_seconds[ready]=seconds
        if seconds>0:self._anim_until=time.monotonic()+seconds+.15
        self.setProperty('meganexus.anim_ready',ready)

    def _animate(self, source, focus):
        """7.0.21: the focused collection's animation plays once it is stored as
        a small GIF (converted once through the image proxy, then from disk):
        Kodi loads an animated picture on its drawing thread, so it must never
        wait for the network there. One request at a time; the latest card wins."""
        ready=art_cache.animation(source)
        if not ready:return
        if self._anim_focus==(focus,ready):
            if self._anim_until and time.monotonic()>=self._anim_until:
                self._anim_until=0;self.setProperty('meganexus.anim_ready','')
            return
        if ready==self._anim[1]:
            self._play_animation(ready,focus);return
        if time.monotonic()<self._anim_failed.get(ready,0):return
        prepare=art_cache.animation_source(source)
        if not prepare:   # a local GIF plays as it is
            self._anim[1]=ready;self._play_animation(ready,focus);return
        self._anim[0]=(ready,prepare)
        if self._anim[2]:return
        self._anim[2]=True
        def work():
            from urllib.request import Request, urlopen
            try:
                while not self._closed and self._anim[0] and self._anim[0][0]!=self._anim[1]:
                    wanted=self._anim[0]
                    try:
                        with urlopen(Request(wanted[1],method='HEAD'),timeout=12) as response:response.read(0)
                    except Exception:
                        self._anim_failed[wanted[0]]=time.monotonic()+300   # the cover stays; tried again later
                        if len(self._anim_failed)>64:self._anim_failed.pop(next(iter(self._anim_failed)))
                        if self._anim[0]==wanted:self._anim[0]=None
                        continue
                    self._anim[1]=wanted[0]   # the window loop starts it on the resting card
            finally:self._anim[2]=False
        threading.Thread(target=work,name='MegaNexusAnimation',daemon=True).start()

    def _prefetch_collection(self, collection_id, epoch, ahead=False):
        if self._closed or epoch!=self._memory_epoch:return
        from resources.lib.collections_home import collection_shelves
        for shelf in collection_shelves(collection_id):
            if self._closed or epoch!=self._memory_epoch:return
            key=self._shelf_key(shelf)
            if not key or self._remembered(key):continue
            try:rows=home_data.load_catalog(shelf,stopped=lambda:self._closed or epoch!=self._memory_epoch)
            except Exception:continue  # Opening the collection retries normally.
            self._remember_rows(key,rows,epoch)
            self._warm_art(rows)
        if ahead:self._load_ahead(collection_id,epoch)

    def _load_ahead(self, collection_id, epoch):
        """7.0.32: the pictures the collection opens with - the first cards of its
        rows, the first title's background and logo - go to Kodi's memory while
        the cursor rests on its tile (hidden images, meganexus.ahead.N), so they
        are there at once when it opens instead of appearing one by one."""
        from resources.lib.collections_home import collection_shelves
        base=xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
        if not base.startswith('http://127.0.0.1:'):return
        urls=[]
        for index,shelf in enumerate(collection_shelves(collection_id)[:AHEAD_ROWS]):
            rows=[r for r in self._remembered(self._shelf_key(shelf)) or [] if r.get('target')]
            landscape=shelf.get('shape',getattr(self,'_card_shape','poster'))=='landscape'
            for row in rows[:AHEAD_CARDS]:
                url=precache.card_art(row,landscape)
                if url.startswith(('https://','http://')) and '|' not in url:
                    urls.append(kodi_textures.texture(kodi_textures.proxy_url(base,url)))
            if index==0 and rows:
                for key in ('fanart','clearlogo'):
                    url=str(rows[0].get(key) or '')
                    if url.startswith(('https://','http://')) and '|' not in url:urls.append(art_cache.url(url))
        if not self._closed and epoch==self._memory_epoch:self._ahead=(collection_id,urls[:AHEAD_SLOTS])

    def _show_ahead(self):
        """Window owner: hand the prepared pictures to the hidden images."""
        ahead,self._ahead=getattr(self,'_ahead',None),None
        if ahead is None:return
        collection_id,urls=ahead
        control_id,pos,_=self._selection();index=control_id-ROW_BASE
        rows=self._shelves[index]['rows'] if 0<=index<len(self._shelves) else []
        if not (0<=pos<len(rows) and rows[pos].get('collection_id')==collection_id):return   # the cursor moved on
        for slot in range(AHEAD_SLOTS):
            self.setProperty('meganexus.ahead.%d'%slot,urls[slot] if slot<len(urls) else '')

    def _start_cold_art_warm(self):
        """Once per Kodi session (and again after a suspend that emptied it),
        fill the image proxy's RAM with a screen of posters for every collection.
        Cached catalog pages only - no catalog requests - one image at a time,
        pausing whenever the user is navigating, inside a collection or playing
        video. Anything opened later fills in as usual."""
        if self._bucket or getattr(self,'_cold_warm_started',False):return
        self._cold_warm_started=True
        home=xbmcgui.Window(10000)
        base=home.getProperty('meganexus.art_cache.base')
        if not base or home.getProperty('meganexus.art_warm.session')==base or home.getProperty('meganexus.art_warm.running'):return
        try:images=int((home.getProperty('meganexus.art_cache.usage') or '0 · 0').split('·')[-1].split()[0])
        except (ValueError,IndexError):images=0
        # The start screen loaded only the first rows: always continue with the rest.
        if images>=COLD_ART_IMAGES and home.getProperty('meganexus.art_warm.front')!=base:return
        home.setProperty('meganexus.art_warm.running',base)
        ids=[row['collection_id'] for shelf in self._shelves for row in shelf.get('rows') or [] if row.get('collection_id')]
        threading.Thread(target=self._cold_art_warm,args=(ids,base),name='MegaNexusArtWarm',daemon=True).start()

    def _cold_art_warm(self, collection_ids, base=''):
        """7.0.7: a screen of every catalog per round, round after round over
        the cached first pages, until they are done or the proxy holds
        kodi_textures.SHARE of the chosen image memory. Posters Kodi already
        keeps on its disk are skipped (it never asks the proxy for them)."""
        from resources.lib.collections_home import collection_shelves
        home=xbmcgui.Window(10000);started=time.monotonic()
        self._art_pool=ThreadPoolExecutor(max_workers=COLD_ART_WORKERS,thread_name_prefix='MegaNexusArtWarm')
        self._art_slots=threading.BoundedSemaphore(COLD_ART_WORKERS)
        try:
            # 7.0.23: right after Kodi starts, this work (all collections' pages
            # and Kodi's texture list) delayed the first collection by 10 s on
            # CoreELEC. It now starts once Home is idle, waits while the user
            # moves, and asks Kodi's thumbnail files instead of its database.
            if not self._wait_idle(COLD_ART_DELAY):return
            self._kodi_has=set()
            self._art_budget=kodi_textures.budget()
            self._art_counts=[0,0,0]
            pages=[]
            for collection_id in collection_ids:
                if not self._wait_idle():return  # The next Home window resumes; warmed images are instant.
                try:shelves=collection_shelves(collection_id)
                except Exception:continue
                for shelf in shelves:
                    if not self._wait_idle():return
                    try:rows=home_data.load_catalog(shelf,cached_only=True)
                    except Exception:rows=None
                    rows=[r for r in rows or [] if r.get('target')]
                    if rows:
                        if not self._warm_art(rows,COLD_ART_PER_SHELF,background=True):return
                        if len(rows)>COLD_ART_PER_SHELF:pages.append(rows)
            start=COLD_ART_PER_SHELF
            while pages:
                for rows in pages:
                    if self._closed or not self._warm_art(rows[start:],COLD_ART_PER_SHELF,background=True):return
                start+=COLD_ART_PER_SHELF
                pages=[rows for rows in pages if len(rows)>start]
            home.setProperty('meganexus.art_warm.session',base)
        finally:
            pool,self._art_pool=self._art_pool,None
            pool.shutdown(wait=False)
            home.clearProperty('meganexus.art_warm.running')
            counts=getattr(self,'_art_counts',None)
            if counts:xbmc.log('[MegaNexus] poster preload: %d loaded, %d kept by Kodi, %d stored by Kodi now, %s in %.0f s'
                               %(counts[0],counts[1],counts[2],home.getProperty('meganexus.art_cache.usage') or '-',time.monotonic()-started),xbmc.LOGINFO)

    def _wait_idle(self, after_open=0):
        """Background work waits until Home was open after_open seconds and the
        cursor rested COLD_ART_IDLE seconds (no collection or video open).
        False once the window closed."""
        monitor=xbmc.Monitor()
        while not self._closed:
            opened=getattr(self,'_opened_at',0)
            if (time.monotonic()-opened>=after_open and time.monotonic()-self._hover[1]>=COLD_ART_IDLE and
                    not self._user_busy() and not browse_cache.playback_busy()):
                return True
            if monitor.waitForAbort(.5):return False
        return False

    def _user_busy(self):
        """Moving the cursor, inside a collection/Details, or a prefetch running."""
        return (self._suspended or bool(self._bucket) or time.monotonic()-self._hover[1]<1.0 or
                any(not f.done() for _,f in self._prefetch_futures) or browse_cache.foreground_busy())

    def _card_art(self, row):
        """The artwork URL a collection card shows (poster or landscape)."""
        return precache.card_art(row,getattr(self,'_card_shape','poster')=='landscape')

    def _warm_art(self, rows, limit=PREFETCH_ART, background=False):
        """Pre-download the first visible cards into the bounded image proxy.
        Background preload: False once the window closed or the memory share
        is full (stop), True to go on."""
        base=xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
        if not base.startswith('http://127.0.0.1:'):return False
        kodi_has=getattr(self,'_kodi_has',())
        budget=getattr(self,'_art_budget',0) if background else 0
        from urllib.parse import quote
        from urllib.request import Request, urlopen
        for row in [r for r in rows if r.get('target')][:limit]:
            while not self._closed and (browse_cache.playback_busy() or (background and self._user_busy())):
                if xbmc.Monitor().waitForAbort(.5):return False
            if self._closed or (self._suspended and not background):return False
            if budget and kodi_textures.used()>=budget:return False
            url=self._card_art(row)
            if not url.startswith(('https://','http://')) or '|' in url or url in self._warmed_art:continue
            counts=getattr(self,'_art_counts',None) if background else None
            proxied=kodi_textures.proxy_url(base,url)
            # Kodi shows it from its own disk cache: never download it again
            # (7.0.23: also checked by its thumbnail file - the cursor's
            # collection prefetch downloaded posters Kodi already kept).
            if proxied in kodi_has or kodi_textures.kept([proxied]):
                if counts:counts[1]+=1
                continue
            if counts:counts[0]+=1
            self._warmed_art.add(url)
            if len(self._warmed_art)>8192:self._warmed_art.clear()
            def head(target=base+'/image?url='+quote(url,safe='')):
                try:
                    with urlopen(Request(target,method='HEAD'),timeout=4 if background else 2) as response:
                        response.read(0)
                except Exception:pass
            pool=getattr(self,'_art_pool',None) if background else None
            if pool is None:
                head();continue
            self._art_slots.acquire()   # at most COLD_ART_WORKERS in flight
            try:pool.submit(head).add_done_callback(lambda _:self._art_slots.release())
            except RuntimeError:
                self._art_slots.release();return False
        return True

    @staticmethod
    def _identity(row):
        target=row.get('target') or {}
        return json.dumps([target.get('media_type'),target.get('canonical_id'),target.get('video_id'),row.get('collection_id'),None if target.get('canonical_id') or row.get('collection_id') else row.get('path') or row.get('local') or row.get('server_play')],ensure_ascii=False)

    def _fill(self, li, row, watched_data, relabel=False, known=None):
        """One card's label, art and properties; returns its identity.
        7.0.37: ``known`` - what this card got last time (self._filled after a
        call): unchanged, Kodi is not asked again (each setArt / property call
        takes Kodi's GUI lock; Home repaints of unchanged rows took 2.3 s with
        live TV loaded on a Fire TV Cube)."""
        labels=(without_emoji(row.get('title') or 'Untitled'),without_emoji(row.get('subtitle') or ''))
        art={key: str(row.get(key) or '') for key in ('poster', 'fanart', 'clearlogo')}
        if getattr(self,'_card_shape','poster')=='landscape' and (row.get('target') or row.get('local') or row.get('server_play')):
            art['poster']=row.get('landscape') or row.get('fanart') or row.get('poster') or ''
        images=art_cache.art(art);images['poster']=art_cache.card(art['poster'])   # 7.0.30: the card at card size
        props={}
        for key in ('title', 'plot', 'meta_line', 'subtitle', 'resume_label', 'airing_banner','tomorrow'):
            value=without_emoji(row.get(key) or '') if key in ('title','subtitle') else str(row.get(key) or '')
            props[key]=value.replace(' • ','[CR]') if key=='airing_banner' else value
        props['shape']=row.get('shape') or 'poster'
        props['animation']=art_cache.animation(row.get('animation'))
        props['hide_title']=row.get('hide_title') or ''
        for key in ('rating_icon','rating_value'):props[key]=str(row.get(key) or '')
        target=row.get('target') or {}
        identity=self._identity(row)
        props['meganexus.identity']=identity
        props['meganexus.placeholder']='' if (target or row.get('collection_id') or row.get('local') or row.get('server_play')) else '1'
        props['watched']='1' if row.get('watched') or simkl_watched.state(watched_data,target.get('media_type'),target.get('canonical_id')).get('watched') else ''
        try:
            percent = min(100, max(0, int(float(row.get('percent_value') or 0))))
        except (ValueError, TypeError, OverflowError):
            percent = 0
        props['progress']=str(percent)
        props['has_progress']='1' if percent else ''
        self._filled=hash((labels,tuple(images.items()),tuple(props.items())))
        if known is not None and known==self._filled:return identity
        if relabel:li.setLabel(labels[0]);li.setLabel2(labels[1])
        li.setArt(images)
        listitems.properties(li,props)   # 7.0.30: one call, not twenty
        return identity

    def _navigating(self, index):
        """7.0.29: the cursor is on this row and a key was pressed a moment ago."""
        return time.monotonic()-getattr(self,'_last_key',0.)<1.2 and self._selection()[0]==ROW_BASE+index

    def _set_rows(self, index, rows):
        self._sel_cache=None
        control = self.getControl(ROW_BASE + index)
        watched_data=simkl_watched.snapshot()
        ids=getattr(self,'_row_ids',None)
        if ids is None:ids=self._row_ids={}
        sigs=getattr(self,'_card_sigs',None)
        if sigs is None:sigs=self._card_sigs={}
        old=sigs.get(index) or [];new=sigs[index]=[]
        def fill(li,pos,row,relabel=True):
            self._fill(li,row,watched_data,relabel=relabel,known=old[pos] if pos<len(old) else None);new.append(self._filled)
        # 7.0.29: the same titles in the same order (pictures from a provider,
        # enriched Continue Watching, a server answer): the cards change in
        # place. A reset restarted the focused poster's pop (it jerked, several
        # times on entering Home) and could move the cursor under the remote.
        try:same=control.size()==len(rows)
        except Exception:same=False
        if same and ids.get(index) and [self._identity(row) for row in rows]==ids[index]:
            for pos,row in enumerate(rows):fill(control.getListItem(pos),pos,row)
            return
        try:
            position = control.getSelectedPosition()
        except Exception:
            position = 0
        try:
            selected=control.getSelectedItem()
            # 7.0.16: "Loading titles" and "Browse all" both carry the collection's
            # link; keeping a placeholder's identity moved the cursor to the end.
            old_identity='' if selected.getProperty('meganexus.placeholder') else selected.getProperty('meganexus.identity')
        except Exception:old_identity=''
        try:old_title='' if not old_identity else selected.getLabel()
        except Exception:old_title=''
        identities=[self._identity(row) for row in rows]
        try:size=control.size()
        except Exception:size=0
        if size and rows:
            # 7.0.29: never emptied - the cards are rewritten where they are and
            # only the extra ones are added or taken away at the end. A reset
            # under the remote dropped the cursor to the first card (or ate the key).
            try:
                for pos,row in enumerate(rows[:size]):fill(control.getListItem(pos),pos,row)
                if len(rows)>size:
                    extra=[]
                    for row in rows[size:]:
                        li=listitems.item(label=without_emoji(row.get('title') or 'Untitled'),label2=without_emoji(row.get('subtitle') or ''))
                        self._fill(li,row,watched_data);new.append(self._filled);extra.append(li)
                    control.addItems(extra)
                else:
                    for pos in range(size-1,len(rows)-1,-1):control.removeItem(pos)
                ids[index]=identities
                keep=self._kept_position(rows,identities,old_identity,old_title)
                if keep is not None and keep!=position:control.selectItem(keep)
                elif keep is None and position>=len(rows):control.selectItem(len(rows)-1)
                return
            except Exception:new[:]=[]   # a list that cannot change in place is rebuilt
        items = []
        for row in rows:
            li = listitems.item(label=without_emoji(row.get('title') or 'Untitled'), label2=without_emoji(row.get('subtitle') or ''))
            self._fill(li,row,watched_data);new.append(self._filled)
            items.append(li)
        control.reset()
        control.addItems(items)
        ids[index]=identities
        if items:
            keep=self._kept_position(rows,identities,old_identity,old_title)
            if keep is not None:position=keep
            control.selectItem(min(max(0, position), len(items) - 1))

    @staticmethod
    def _kept_position(rows,identities,old_identity,old_title):
        """The card the cursor was on: by identity, else (7.0.45) by its title - Continue
        Watching's refresh moves a series on to its next episode or joins a film's IDs,
        so the identity changes while the title stays (the cursor jumped to its neighbour)."""
        if old_identity and old_identity in identities:return identities.index(old_identity)
        if old_title:
            for pos,row in enumerate(rows):
                if without_emoji(row.get('title') or 'Untitled')==old_title:return pos
        return None

    def _touch(self):
        self._sel_cache=None   # a key or a repaint: focus and card are read again
        now = time.monotonic()
        if now - self._last_touch > 2:
            self._last_touch = now
            xbmcgui.Window(10000).setProperty('meganexus.interactive_busy', str(time.time()))

    def _remember_position(self):
        """7.0.29: where the cursor is, at every move - not only on Select. A Home
        that Kodi initialises again (on the Cube: around video starts / stops)
        came back to the last clicked card, often Continue Watching."""
        try:
            cid=self.getFocusId()
            if not ROW_BASE<=cid<ROW_BASE+len(self._shelves):return
            spot=[cid-ROW_BASE,self.getControl(cid).getSelectedPosition()]
        except Exception:return
        key=self._bucket or 'home'
        if self._focus_memory.get(key)!=spot:
            self._focus_memory[key]=spot
            xbmcgui.Window(10000).setProperty('meganexus.home.focus',json.dumps(self._focus_memory))

    def onFocus(self, control_id):
        # 7.0.45: only noted here - a fast scroll through ten rows called this ten times,
        # each asking Kodi several things while it draws (0.5-1 s apiece on a Fire TV
        # Cube): the logos and rows followed row by row for seconds. The loop applies
        # the last one (_apply_focus).
        self._touch()
        self._focus_pending=control_id

    def _apply_focus(self):
        control_id=getattr(self,'_focus_pending',None)
        if control_id is None:return
        self._focus_pending=None
        if control_id in (NEXT_PAGE,PREVIOUS_PAGE):
            self._turn(1 if control_id==NEXT_PAGE else -1);return
        self._remember_position()
        if ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            self.setProperty('meganexus.hero_row', str(control_id - ROW_BASE))
            self._row_scroll_focus(control_id-ROW_BASE)

    def onAction(self, action):
        self._touch()
        self._last_key=time.monotonic()
        if action.getId() in (1,2,3,4,5,6,104,105,159,160):self._remember_position()   # moves and page moves
        if action.getId() in (117,101,1009,11):
            cid=self.getFocusId()
            if ROW_BASE <= cid < ROW_BASE+len(self._shelves):
                rows=self._shelves[cid-ROW_BASE]['rows'];pos=self.getControl(cid).getSelectedPosition()
                if 0<=pos<len(rows) and rows[pos].get('target'):
                    from .details import context_choice,quick_choice,run_choice,open_person,plays_directly
                    self._suspended=True
                    outcome='';inplace=False
                    try:
                        if rows[pos].get('person'):
                            if self._previews:self._previews.pause()
                            outcome=self.child(open_person,rows[pos]['person'])
                        else:
                            # 6.0.35: Title options float over Home; only a choice that
                            # opens a screen hides it.
                            target=rows[pos]['target']
                            choice='details' if action.getId()==11 else context_choice(target,rows[pos])
                            # 7.0.44: Details (and Info) open in place of the rows, like a click
                            inplace=choice in ('details','info') and not self._hidden_hero() and not rows[pos].get('collection_id')
                            if self._previews and not inplace:self._previews.pause()
                            if choice and not quick_choice(choice,target,rows[pos]):
                                if inplace:
                                    self.setProperty('meganexus.inplace','1')
                                    outcome=self.in_place(run_choice,target,'details',rows[pos],inplace=True,
                                                          home_tick=self._inplace_tick,home_pause=self._inplace_pause)
                                else:
                                    outcome=(self.in_place if plays_directly(target,rows[pos],choice) else self.child)(run_choice,target,choice,rows[pos])
                    finally:
                        if inplace:self.setProperty('meganexus.inplace','')
                        self._suspended=False;self._watched_badges()
                    if outcome=='playing' or isinstance(outcome,dict):
                        self._pending=outcome;self._finish()
            return
        if action.getId() in BACK:
            if self._nested:
                self._hide();return
            if self._bucket:
                if self._previews:self._previews.pause()
                self._bucket = ''
                self._returning=True   # 7.0.32: Home comes back as it was, without sliding in
                try:self._paint(home_data.initial_shelves())
                finally:self._returning=False
            else:
                self.setFocusId(101)

    @staticmethod
    def _hidden_hero():
        """Home without its top (compact layout): titles open on their own page."""
        return xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)')

    def _inplace_tick(self,last_input=0.0):
        """7.0.44: the card's trailer while its title is open in place - the page calls
        this from its loop (the same thread as Home's): no trailer yet, it starts after
        the usual wait; a key on the page waits again."""
        previews=self._previews
        if not previews:return
        if last_input and not previews.attempted:previews.changed=max(previews.changed,last_input)
        suspended,self._suspended=self._suspended,False
        try:previews.tick()
        finally:self._suspended=suspended

    def _inplace_pause(self):
        if self._previews:self._previews.pause()

    def _opens_in_place(self,row):
        """7.0.44: a film or series card opens in place of the rows (not a person, a
        collection, a resume that starts at once, or Home without its top)."""
        if not row.get('target') or row.get('person') or row.get('collection_id') or row.get('server_play') or row.get('local'):return False
        from .details import plays_directly
        return not plays_directly(row['target'],row) and not self._hidden_hero()

    def onClick(self, control_id):
        self._touch()
        if self._nested and (control_id in NAV or control_id in TOP_BUTTONS):
            self._forward=control_id;self._hide();return   # Home does it
        if control_id in NAV:
            if self._previews:self._previews.pause()
            self._bucket = NAV[control_id]
            self._paint(home_data.initial_shelves(self._bucket))
            return
        # 7.0.44: a card's trailer goes on while its title opens in place (below)
        if self._previews and not ROW_BASE <= control_id < ROW_BASE + len(self._shelves):self._previews.pause()
        if control_id in (105,111):
            self._suspended=True
            try: query=xbmcgui.Dialog().input('Search movies, series, actors & more',getattr(self,'_search_query','')).strip()
            finally:
                self._suspended=False
                self._watched_badges()
            if query:
                self._search_query=query
                self.setProperty('meganexus.search.query',query)
                self._bucket='search'
                self._paint(home_data.search_shelves(query))
            return
        elif control_id == 113:
            # 7.0.29: the film waiting behind (Back / Esc pressed while it started)
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            if xbmc.getCondVisibility('Player.Paused'):xbmc.executebuiltin('PlayerControl(Play)')
            self._pending='playing';self._finish();return
        elif control_id == 108:
            # 7.0.42: Home stays, the HUB button marked, our ring over it, until the
            # HUB under it has drawn itself (open_home); closing here first showed the
            # ring over a bare background.
            self._pending='hub'
            self._leaving=True
            try:self.setFocusId(108)
            except Exception:pass
            return
        elif control_id == 106:
            # 6.0.35: Library (Local / Tracking services).
            from .library import open_library
            self._suspended=True
            try:outcome=self.child(open_library)
            finally:
                self._suspended=False
                self._watched_badges()
            if outcome=='playing' or isinstance(outcome,dict):
                self._pending=outcome;self._finish()
            return
        elif control_id == 107:
            self._settings()
            return
        elif ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            index = control_id - ROW_BASE
            pos = self.getControl(control_id).getSelectedPosition()
            rows = self._shelves[index]['rows']
            if not 0 <= pos < len(rows):
                return
            row = dict(rows[pos])
            # 7.0.32: and where the card was on the screen, so Back finds the row as it was
            try:shown=int(xbmc.getInfoLabel('Container(%d).Position'%control_id) or 0)
            except ValueError:shown=0
            self._focus_memory[self._bucket or 'home'] = [index, pos, shown]
            xbmcgui.Window(10000).setProperty('meganexus.home.focus', json.dumps(self._focus_memory))
            if self._previews and not self._opens_in_place(row):self._previews.pause()
        else:
            return
        if row.get('collection_id') and not self._nested:
            return self._open_collection(row['collection_id'])
        if row.get('collection_id'):
            from resources.lib.collections_home import collection_shelves
            self._bucket = 'collection:' + row['collection_id']
            self._focus_memory.pop(self._bucket,None)
            with perf.timed('Collection data',id=row['collection_id']):
                shelves=collection_shelves(row['collection_id'])
            self._paint(shelves)
            return
        if row.get('group_id'):
            self._bucket='group:'+row['group_id']
            self._paint(home_data.initial_shelves(self._bucket));return
        if row.get('server_play'):
            # 6.0.39 beta: a Plex / Jellyfin episode or resume plays from the server.
            command=_server_play(row['server_play'])
        elif row.get('local'):
            # 6.0.37: a movie / series from the device's own storage (Kodi library).
            from .local_storage import open_item
            self._suspended=True
            if self._previews:self._previews.pause()
            try:command=self.child(open_item,row['local'])   # 'playing', a Kodi window or ''
            finally:
                self._suspended=False
        elif row.get('target'):
            from .details import open_context,open_person,plays_directly
            self._suspended=True
            # 7.0.44: a title opens in place of the rows - Home's top and its trailer stay
            inplace=self._opens_in_place(row)
            if self._previews and not inplace: self._previews.pause()
            try:
                if inplace:
                    self.setProperty('meganexus.inplace','1')
                    outcome=self.in_place(open_context,row['target'],row=row,inplace=True,
                                          home_tick=self._inplace_tick,home_pause=self._inplace_pause)
                else:
                    outcome=self.child(open_person,row['person']) if row.get('person') else \
                        (self.in_place if plays_directly(row['target'],row) else self.child)(open_context,row['target'],row=row)
                command=outcome if outcome=='playing' or isinstance(outcome,dict) else ''
            finally:
                if inplace:self.setProperty('meganexus.inplace','')
                self._suspended=False
                self._watched_badges()
        elif any(action in (row.get('path') or '') for action in ('action=first_run_wizard','action=setup_center')):
            self._settings();return
        elif any(action in (row.get('path') or '') for action in ('action=meganexus_collection','action=catalog_all')):
            from urllib.parse import urlsplit,parse_qs
            from .catalog import open_catalog
            self._suspended=True
            if self._previews:self._previews.pause()
            try:
                params={k:v[0] for k,v in parse_qs(urlsplit(row['path']).query).items()}
                params.setdefault('label',self._shelves[index]['title'])
                params['initial_rows']=[r for r in self._shelves[index]['rows'] if r.get('target')]
                outcome=self.child(open_catalog,params)
                command=outcome if outcome=='playing' or isinstance(outcome,dict) else ''
            finally:
                self._suspended=False
                self._watched_badges()
        else:
            command = launch_command(row)
        if command:
            self._pending = command
            self._finish()

    def _settings(self):
        from .settings import run
        previous_xml=home_xml();previous_theme=theme_folder()
        from resources.lib import art_provider
        previous_art=art_provider.signature()
        self._suspended=True
        if self._previews:self._previews.pause()
        try:command=self.over(run)   # 6.0.35: Home stays visible behind the glass settings
        finally:
            self._suspended=False
            from .browse_meta import clear
            clear()
            self._forget_rows()
        if command=='meganexus:reload':   # 7.0.30: a new theme - Home opens again in it
            self._pending='reload';self._theme_changed=True;self._finish();return
        if command:self._pending=command;self._finish();return
        home=xbmcgui.Window(10000)
        if art_provider.signature()!=previous_art or home.getProperty(PREPARE_REQUEST):
            # 7.0.32: a new Artwork provider or a cleared cache - the pictures are
            # prepared now that Settings is closed, never while choices are made.
            home.clearProperty(PREPARE_REQUEST)
            self._pending='prepare';self._finish();return
        from .setup_gate import ready
        if not ready():self._pending='reload';self._finish();return
        if home_xml()!=previous_xml or theme_folder()!=previous_theme:
            self._pending='reload';self._finish();return
        self.setProperty('meganexus.home.error','')
        if self._bucket.startswith('collection:'):
            from resources.lib.collections_home import collection_shelves
            shelves=collection_shelves(self._bucket.split(':',1)[1])
        elif self._bucket=='search':
            shelves=home_data.search_shelves(getattr(self,'_search_query',''))
        else:shelves=home_data.initial_shelves(self._bucket)
        self._paint(shelves,self._page)   # 7.0.48: back from Settings on the same page

    def _open_collection(self, collection_id):
        """7.0.32: the collection in its own screen over Home. Home keeps its rows,
        their scrolling and its cursor: Back closes the collection screen and Home
        is there as it was - nothing is filled, scrolled or animated again (it
        was repainted before: 0.4-2 s on a box, the rows sliding and scrolling
        back). The screen is made once and reused."""
        from resources.lib.collections_home import collection_shelves
        from . import playback
        bucket='collection:'+collection_id
        with perf.timed('Collection data',id=collection_id):
            shelves=collection_shelves(collection_id)
        self._focus_memory.pop(bucket,None)
        xbmcgui.Window(10000).setProperty('meganexus.home.focus',json.dumps(self._focus_memory))
        window=self._collection_window
        if window is None or window._closed:
            with perf.timed('Collection screen'):
                window=HomeWindow(home_xml(),ADDON.getAddonInfo('path'),theme_folder(),'1080i',shelves=shelves,bucket=bucket,nested=True,parent=self)
            self._collection_window=window
        else:
            window._bucket=bucket;window._shelves=shelves;window._pages=list(shelves);window._page=0
            window._clear_rows()   # never a moment of the last collection
        # The rows the cursor's prefetch loaded are Home's: the collection shows
        # them as they are (it painted the cached page and then changed it).
        window._shelf_memory=self._shelf_memory;window._memory_lock=self._memory_lock
        window._forward=None
        self._suspended=True
        if self._previews:self._previews.pause()
        # A film started there hides Home as well (playback._hide_parents).
        self._meganexus_play_hidden=False
        playback.PARENTS.append(self)
        monitor=xbmc.Monitor()
        try:
            window._shown=True
            window.show_ready()
            self.setProperty('meganexus.behind','1')   # covered: Kodi need not draw Home
            while window._shown and not window._closed and not self._closed and not monitor.abortRequested():
                window.drain_updates()
                monitor.waitForAbort(.05)
        finally:
            try:playback.PARENTS.remove(self)
            except ValueError:pass
            self.setProperty('meganexus.behind','')
            self._suspended=False
            self._touch()
        if window._closed:
            # Something to do outside MegaNexus's screens (a film, a trailer, HUB ...)
            self._collection_window=None
            if window._previews:window._previews.finish()
            if window._pending:
                self._pending=window._pending;self._finish()
            return
        if self._meganexus_play_hidden:
            self._meganexus_play_hidden=False
            self.show_ready()
        if window._forward is not None:
            forward,window._forward=window._forward,None
            if not (forward in NAV and NAV[forward]==self._bucket):   # Home itself: it is there already
                type(self).onClick(self,forward)   # the method itself, not the deferring wrapper

    def child(self, fn, *args, **kwargs):
        """A collection screen hides itself for a title, a trailer or a film -
        and Home behind it closes too: Kodi counts every MegaNexus screen as a
        dialog, and an open one kept its player from taking over (Back did not
        leave a trailer). On the way back Home opens first, not drawn
        (meganexus.behind) while it fills its rows again, then this screen."""
        parent=self._parent if self._nested else None
        if parent is None:return super().child(fn,*args,**kwargs)
        try:focus=self.getFocusId()
        except Exception:focus=None
        self._child_active=True
        try:
            xbmcgui.WindowXMLDialog.close(self)
            xbmcgui.WindowXMLDialog.close(parent)
            return fn(*args,**kwargs)
        finally:
            self._restore_focus=focus
            if not self._dialog_closed and not parent._closed and not xbmc.Monitor().abortRequested():
                parent.setProperty('meganexus.behind','1')
                parent.show()
                parent.setProperty('meganexus.behind','1')
                self.show_ready()
            self._child_active=False

    def _clear_rows(self):
        """7.0.32: a reused collection screen starts empty. Its rows kept the last
        collection's cards, and _set_rows rewrites cards in place (right within
        one collection) - the new one appeared drawn over the old."""
        self._row_ids={};self._card_sigs={};self._sel_cache=None
        for i in range(home_data.MAX_ROWS):
            self.setProperty('meganexus.row.%d.visible'%i,'')
            try:self.getControl(ROW_BASE+i).reset()
            except Exception:pass

    def _hide(self):
        """Close the collection screen; it is kept for the next collection."""
        if self._previews:
            self._previews.finish();self._previews=None
        self._generation+=1          # its loads still running are dropped
        self._shown=False
        if self._parent is not None:self._parent.setProperty('meganexus.behind','')   # Home shows before this one goes
        xbmcgui.WindowXMLDialog.close(self)

    def _finish(self):
        if self._collection_window is not None and not self._collection_window._closed:
            window,self._collection_window=self._collection_window,None
            window._finish()
            if window._previews:window._previews.finish()
        if self._previews:
            self._previews.close()
        self._closed = True
        self._generation += 1
        if self._pool:
            for future in self._futures:future.cancel()
            self._pool.shutdown(wait=False)  # Kodi Windows still embeds Python 3.8.
        if self._prefetch_pool:
            for _,future in self._prefetch_futures:future.cancel()
            self._prefetch_pool.shutdown(wait=False)
        self.close()


PREPARE_REQUEST='meganexus.prepare.requested'   # 7.0.32: Settings asks for the preparation on leaving
ENTRY_XML='meganexus_entry.xml'   # 7.0.42: the opening screen kept over Home while it fills
ENTRY_HOLD=7.0                    # ... for at most this long (Back skips)
HUB_SETTLE=1.1          # 7.0.42: the HUB's trending picture loaded and faded in under Home
HUB_SETTLE_PLAIN=.35    # ... a HUB without it


def open_home():
    from .setup_gate import ensure_ready
    if not ensure_ready():return
    from .startup import prepare,Progress
    xbmcgui.Window(10000).clearProperty(PREPARE_REQUEST)   # this preparation covers it
    # 7.0.45: one opening screen and one ring from the HUB to Home - the preparation
    # and Home's first rows fill the same ring (two screens, each from empty, before).
    entry=progress=None
    try:
        from .playback import Loading,ROOT
        entry=Loading(ENTRY_XML,ROOT,theme_folder(),'1080i',label='',full=True,hub=True)
        entry.show()
        progress=Progress(entry,after=['check','home','rows'])
    except Exception:entry=None
    try:
        prepare(entry,progress)
        if progress is not None:progress.begin('home')   # Kodi builds Home: the ring goes on by the time it took before
    except Exception:
        if progress is not None:progress.stop()
        if entry is not None:entry.close()
        raise
    xbmcgui.Window(10000).setProperty('meganexus.progress.pull_requested', str(time.time()))
    monitor=xbmc.Monitor()
    bucket='';search_query='';first_entry=True
    while not monitor.abortRequested():
        extra={}
        if bucket.startswith('collection:'):
            from resources.lib.collections_home import collection_shelves
            shelves=collection_shelves(bucket.split(':',1)[1])
        elif bucket=='search':shelves=home_data.search_shelves(search_query)
        else:
            revision=xbmcgui.Window(10000).getProperty('meganexus.progress.revision')
            shelves=home_data.initial_shelves(bucket)
            extra={'progress_revision':revision}
        window=HomeWindow(home_xml(),ADDON.getAddonInfo('path'),theme_folder(),'1080i',shelves=shelves,bucket=bucket,**extra)
        window._search_query=search_query
        if not (first_entry and not bucket) and entry is not None:
            if progress is not None:progress.stop()
            entry.close();entry=None
        # 7.0.42: entering MegaNexus - the opening screen stays over Home while
        # it fills its first rows (they jumped and vanished under the cursor),
        # at most ENTRY_HOLD seconds; then the marker is on Home.
        first_entry=False
        try:
            window.show_ready()
            from .trailers import lift_curtain
            lift_curtain()   # 7.0.32: after a film, the black fades to this Home
            if entry is not None:
                until=time.monotonic()+ENTRY_HOLD
                try:
                    if progress is not None:progress.begin('rows')
                    while time.monotonic()<until and not entry.cancelled and not window._closed and not monitor.abortRequested():
                        window.drain_updates()
                        if window.first_rows_ready():break
                        if progress is not None:progress.update(window.first_rows_progress())
                        monitor.waitForAbort(.05)
                    if not window._closed and not window.first_rows_ready():
                        # 7.0.45: what the opening screen waited for when its time ran out
                        xbmc.log('[MegaNexus] Opening: rows %s drawn %s, %d of %d loads running'
                                 %(sorted(window._scheduled),sorted(getattr(window,'_drawn',())),
                                   sum(1 for f in list(window._futures) if not f.done()),len(window._futures)),xbmc.LOGINFO)
                    if progress is not None:progress.done()
                    if not window._closed:window.setFocusId(101)
                finally:
                    if progress is not None:progress.stop()
                    entry.close();entry=None
            while not window._closed and not window._leaving and not monitor.abortRequested():
                window.drain_updates()
                monitor.waitForAbort(.05)
            pending=window._pending;bucket=window._bucket;search_query=getattr(window,'_search_query','')
        finally:
            cover=None
            if getattr(window,'_pending',None)=='hub':
                # 7.0.42: the HUB first, under this Home, then Home closes - the session's
                # base picture never shows between them (it flashed on the way out). Home
                # and our ring stay until the HUB has drawn itself: its trending picture
                # loads in the background and fades in (0.9 s) - shown earlier, the HUB
                # came as a bare background with the picture popping in after.
                try:
                    from .playback import wait_overlay
                    cover=wait_overlay('',{})
                except Exception:cover=None
                xbmc.executebuiltin('ActivateWindow(Home)')
                for _ in range(20):
                    if xbmc.getCondVisibility('Window.IsActive(Home)') or monitor.waitForAbort(.025):break
                spotlight=bool(xbmcgui.Window(10000).getProperty('meganexus.spotlight.art'))
                monitor.waitForAbort(HUB_SETTLE if spotlight else HUB_SETTLE_PLAIN)
            window._finish()
            if window._previews:window._previews.finish()
            if cover is not None:cover.close()
        if pending=='hub':
            return
        if pending=='reload':
            if getattr(window,'_theme_changed',False):
                from resources.lib import theme
                theme.sync()                 # Kodi loads its skin again now, with no page open
                monitor.waitForAbort(.5)
            continue
        if pending=='prepare':
            prepare()
            continue
        if isinstance(pending,dict) and 'trailer' in pending:
            from .trailers import play_trailer
            if not play_trailer(pending['trailer']):continue
            pending='playing'
        if pending=='playing':
            from .trailers import wait_for_playback
            wait_for_playback()
            continue
        if pending:
            xbmcgui.Window(10000).clearProperty('meganexus.frontend.running')
            from .system_setup import execute_command
            execute_command(pending)
        else:
            xbmc.executebuiltin('ActivateWindow(Home)')
        return
