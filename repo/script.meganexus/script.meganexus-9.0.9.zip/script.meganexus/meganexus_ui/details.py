# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from resources.lib import art_cache
from .dialog import Dialog
from . import browse_meta
"""Title details and a plain AIOStreams selection screen."""
import xbmc
import queue
import traceback
import threading
import time
import xbmcaddon
import xbmcgui
from . import listitems
from resources.lib import backend_api, simkl_api
from resources.lib import simkl_watched, title_details
from resources.lib.theme import folder as theme_folder
_ORIGIN = 'mnx-92521b3dbef1'



def _chosen_art(meta):
    """The title's pictures from the provider chosen in Artwork (cached only: no wait)."""
    try:
        from resources.lib import art_provider
        return art_provider.meta(meta,cached_only=True)
    except Exception:
        return meta

class Details(Dialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args)
        self.meta=_chosen_art(kwargs['meta'])
        self.action=''
        self.closed=False
        self._metadata_pending=kwargs.get('metadata_pending',False);self._metadata_job=None;self._metadata_error=False;self._after_metadata=None
        self._extra_jobs=[];self._extras_started=False
        self.context=kwargs.get('context') or {}
        self.seasons=[];self.episodes=[];self.related=list(kwargs.get('related') or []);self._related_loaded=bool(kwargs.get('related'));self._season=None;self._recommendations=queue.Queue();self._descriptions=queue.Queue();self._reviews=queue.Queue();self.review_rows=[];self._episode_ratings=queue.Queue();self._rating_jobs=set();self._description_jobs=set()
        self.landscape=xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape')=='landscape'
        self.inplace=bool(kwargs.get('inplace'))   # 7.0.44: on Home, in place of its rows (open_context)
        # 7.0.44: Home's trailer goes on - and starts after its wait when none plays yet;
        # a key here waits again; before a video or a trailer of ours it stops
        self.home_tick=kwargs.get('home_tick');self.home_pause=kwargs.get('home_pause');self._last_input=0.0
        # 8.1.2: the controller behind home_pause, so the Trailer button can step a
        # clip that is already playing up to full screen instead of replaying it
        self.home_previews=kwargs.get('home_previews')
        # 7.0.44: a page over Browse all / More like this / the Library draws Home's top
        # itself - and plays the title's trailer like Home, with its own controller
        self.card=kwargs.get('card') or {};self._own_previews=None
        if kwargs.get('hero') and not self.home_tick:
            try:
                from .home_trailers import Controller
                self._own_previews=Controller(self)
                previews=self._own_previews
                def tick(last_input=0.0):
                    if last_input and not previews.attempted:previews.changed=max(previews.changed,last_input)
                    previews.tick()
                self.home_tick=tick;self.home_pause=previews.pause
            except Exception:
                self._own_previews=None

    def _ratings(self):
        """7.0.29: MDBList's ratings row (logos + scores) when MDBList is on, else
        the title's IMDb score as IMDb's logo + the number - never as text."""
        from resources.lib import ratings_row
        from resources.lib.home_data import rating_label,rating_icon
        label=rating_label(self.meta)
        own=(rating_icon(label),label.split(' ',1)[-1]) if label else None
        def fetch(load):
            def work():
                try:ratings=load()
                except Exception:return
                if ratings and not self.closed:ratings_row.publish(self,ratings)
            threading.Thread(target=work,name='MegaNexusRatings',daemon=True).start()
        ratings_row.publish_for(self,self.meta,own,fetch)

    def _fetch_art(self):
        """7.0.29: the Artwork provider's pictures not cached yet - fetched off the UI thread."""
        def work():
            try:
                from resources.lib import art_provider
                fresh=art_provider.meta(self.meta)
            except Exception:return
            if self.closed or fresh is self.meta:return
            self.meta=fresh
            self.setProperty('meganexus.fanart',art_cache.url(fresh.get('background') or ''))
            self.setProperty('meganexus.poster',art_cache.url(fresh.get('poster') or ''))
        threading.Thread(target=work,name='MegaNexusArtwork',daemon=True).start()

    def onInit(self):
        m=self.meta
        from .trailers import lift_curtain
        lift_curtain()   # 7.0.32: after a film, the black fades to this page
        self._fetch_art()
        from .session_window import scene
        scene(art_cache.url(m.get('background') or m.get('poster') or ''), m.get('name') or m.get('title') or '')
        self._season=None
        self.setProperty('meganexus.title',m.get('name') or m.get('title') or m['id'])
        self._shown_plot=None
        self.setProperty('meganexus.plot',m.get('description') or m.get('overview') or '')
        self.setProperty('meganexus.fanart',art_cache.url(m.get('background') or ''))
        self.setProperty('meganexus.poster',art_cache.url(m.get('poster') or ''))
        logo=m.get('logo') or m.get('clearlogo') or ''
        self.setProperty('meganexus.logo',art_cache.url(logo) if logo else '')   # 7.0.44: Home's top on Browse all
        self.setProperty('meganexus.year',str(m.get('releaseInfo') or m.get('year') or ''))
        series=m.get('type')=='series'
        self.setProperty('meganexus.series','1' if series else '')
        self.getControl(100).setLabel('Play episode' if series else 'Play')
        for cid in (101,103,104,106):self.getControl(cid).setEnabled(not self._metadata_pending and not self._metadata_error)
        # 8.1.2: the mark beside the release badge, and nothing more - "Movie | 2025".
        # Opened from the Library this wrote the whole description here (runtime and
        # "Drama / Science Fiction / ..."), which is both too long for that row and
        # different from what the same title shows when it is opened from a collection
        # or from a poster on Home: "razlicite su info koje dobijam". The genres and the
        # runtime are in the title's own page below, where there is room for them.
        self.setProperty('meganexus.meta_line','  |  '.join(str(v) for v in (
            'Series' if series else 'Movie', m.get('releaseInfo') or m.get('year')) if v))
        self._people()
        self._start_reviews()
        if not self._metadata_pending:self._prefetch_trailer()   # 7.0.47
        self._ratings()
        self._fetch_release()
        self._release()
        if series:
            self.seasons=title_details.seasons(m)
            self.getControl(501).reset()
            self.getControl(501).addItems([listitems.item(label=title_details.season_label(n)) for n in self.seasons])
            if self.seasons:
                self.setProperty('meganexus.empty','')
                requested=title_details.number(self.context.get('season'),1)
                first=self.seasons.index(requested) if requested in self.seasons else 0
                self.getControl(501).selectItem(first);self._episodes(first);self.focus(501)
            else:
                # No loading banner over the episode row: rows appear when they arrive.
                self.setProperty('meganexus.empty','' if self._metadata_pending else 'No episodes supplied for this series.')
        else:
            self.setProperty('meganexus.empty','')
        if self._metadata_pending:
            self.setProperty('meganexus.related_status','')   # 7.0.42: the ring shows meanwhile (meganexus.related_busy)
            self.setProperty('meganexus.related_busy','1')
            if self._metadata_job is None:self._metadata_job=browse_meta.request(self.context)
        else:self._start_extras()
        self._favorite_label()
        self._watch_badges()
        self.restore_focus()
        if self.inplace and not getattr(self,'_inplace_focused',False):
            # 7.0.44: on Home the line of buttons first - Next SxEy (a series going on), else Play
            self._inplace_focused=True
            try:self.focus(507 if self.getProperty('meganexus.next.label') else 100)
            except Exception:pass

    def preview_selection(self):
        """7.0.44: what the page's own trailer controller plays - this title."""
        if self.closed or not getattr(self,'_own_previews',None):return None
        m=self.meta
        target=dict((self.card or {}).get('target') or {},media_type=m.get('type') or 'movie',canonical_id=m.get('id') or self.context.get('canonical_id'))
        row=dict(self.card or {},target=target,title=m.get('name') or m.get('title') or '')
        return ('page',target['media_type'],target['canonical_id']),row

    def _release(self,episode=None):
        """7.0.32: the badge and date under the ratings - the selected episode's
        air day; else the next episode still to come (or the last one out); a
        film's release (In cinemas / Released with TMDB's dates)."""
        from resources.lib import release_info
        if (self.meta.get('type') or '')=='series':
            if episode is None:
                episodes=title_details.episodes(self.meta)
                episode=release_info.next_episode(episodes)
                if episode is None:
                    aired=[e for e in episodes if release_info.episode_day(e) is not None and str(e.get('season'))!='0']
                    episode=max(aired,key=release_info.episode_day) if aired else None
            kind,text=release_info.episode_badge(episode) if episode else ('','')
            status=(getattr(self,'_series_status','') or release_info.series_status(self.meta.get('status'))) if kind else ''
        else:
            kind,text=release_info.movie_badge(self.meta,getattr(self,'_release_dates',None));status=''
        if (kind,text,status)!=getattr(self,'_release_shown',None):
            self._release_shown=(kind,text,status)
            self.setProperty('meganexus.release.status',status)   # 7.0.37: a series' Ongoing / Ended
            self.setProperty('meganexus.release.date',text if kind else '')
            self.setProperty('meganexus.release.kind',kind)

    def _fetch_release(self):
        """A film's TMDB release dates (cinema / digital), a series' status
        (Ongoing / Ended), off the GUI thread."""
        if getattr(self,'_release_started',False):return
        self._release_started=True
        from resources.lib import release_info
        from .play_jobs import _BACKGROUND
        meta=dict(self.meta)
        if (meta.get('type') or '')=='series':
            def series():
                try:status=(release_info.tmdb_series(meta) or {}).get('status') or ''
                except Exception:status=''
                if not self.closed and status:self._series_status=status;self._release_shown=None
            self._extra_jobs.append(_BACKGROUND.submit(series));return
        def work():
            try:dates=release_info.tmdb_dates(meta)
            except Exception:dates=None
            if not self.closed:self._release_dates=dates
        self._extra_jobs.append(_BACKGROUND.submit(work))

    def _start_extras(self):
        if self._related_loaded:self._recommendations.put(self.related);return
        if self._extras_started:return
        self._extras_started=True
        self.setProperty('meganexus.related_status','')
        self.setProperty('meganexus.related_busy','1')
        def load_related():
            if self.closed:return
            try:rows=title_details.related(self.meta,limit=100)
            except Exception:rows=[]
            if not self.closed:self._recommendations.put(rows)
        from .play_jobs import _BACKGROUND
        self._extra_jobs.append(_BACKGROUND.submit(load_related))

    def _people(self):
        items=[]
        for person in self.meta.get('meganexus_people',title_details.people(self.meta)):
            li=listitems.item(label=person['name'],label2=person['role'])
            li.setArt(art_cache.art({'thumb':person.get('photo') or 'special://home/addons/script.meganexus/resources/media/person.png'}))
            items.append(li)
        self.getControl(503).reset();self.getControl(503).addItems(items)
        self.setProperty('meganexus.has_people','1' if items else '')

    def _prefetch_trailer(self):
        """7.0.47: the trailer's link is found while the page is open, so the Trailer
        button starts it at once (no ring). Only a link that streams as it is (IMDb); a
        trailer that is downloaded first (YouTube) waits for the button, as before."""
        meta=dict(self.meta);key=str(meta.get('id') or meta.get('imdb_id') or '')
        if not key or getattr(self,'_trailer_for',None)==key:return
        self._trailer_for=key;self._trailer_ready=''
        def find():
            try:
                from resources.lib.trailer_support import trailer_candidates,trailer_url
                from resources.lib import imdb_trailers
                first=next(iter(trailer_candidates(trailer_url(meta),(meta,))),'')
                if first and imdb_trailers.direct_stream(first) and self._trailer_for==key:self._trailer_ready=first
            except Exception:pass
        from .play_jobs import _BACKGROUND
        self._extra_jobs.append(_BACKGROUND.submit(find))

    def _start_reviews(self):
        """7.0.45: reviews under Cast & crew, from the services that are on - in the background."""
        try:
            from resources.lib import reviews
            ids=reviews.title_ids(self.meta)
        except Exception:return
        if not any(ids) or getattr(self,'_reviews_for',None)==ids:return
        self._reviews_for=ids
        meta=dict(self.meta)
        def load():
            try:rows=reviews.for_title(meta)
            except Exception:rows=[]
            if not self.closed:self._reviews.put(rows)
        from .play_jobs import _BACKGROUND
        self._extra_jobs.append(_BACKGROUND.submit(load))

    def _show_reviews(self,rows):
        self.review_rows=rows
        items=[]
        for row in rows:
            li=listitems.item(label=row.get('author') or '',label2=row.get('source') or '')
            li.setProperty('source',row.get('source') or '')
            rating=row.get('rating')
            li.setProperty('rating','%g/10'%rating if rating is not None else '')
            li.setProperty('likes','♥ %d'%row['likes'] if row.get('likes') else '')
            # two lines of it (a label in a list does not wrap); a review that gives the story
            # away is not shown until it is opened
            lines=['Spoiler - press OK to read it.'] if row.get('spoiler') else review_lines(row.get('text'))
            li.setProperty('line1',lines[0] if lines else '');li.setProperty('line2',lines[1] if len(lines)>1 else '')
            items.append(li)
        try:
            control=self.getControl(505)
            control.reset();control.addItems(items)
        except Exception:return
        self.setProperty('meganexus.has_reviews','1' if items else '')

    def _rate(self,episode=None):
        """7.0.45: your rating (and review) of this film, show or episode - typed on the phone, sent to Trakt / TMDB."""
        from resources.lib import trakt_api, rate_title, tmdb_account
        if not trakt_api.authorized() and not tmdb_account.connected():
            xbmcgui.Dialog().ok('Rate','Sign in to Trakt or TMDB first: HUB Settings > Accounts & tracking.');return
        target=rate_title.target(self.meta,episode)
        if not (target.get('imdb') or target.get('tmdb')):
            xbmcgui.Dialog().notification('Rate','This title has no IMDb or TMDB id to rate it by.',time=4000);return
        from .phone_setup import run
        sent=run(rating=target)
        if sent:xbmcgui.Dialog().notification('Rate',sent.get('done') or 'Sent',time=4000)

    def _open_review(self):
        try:row=self.review_rows[self.getControl(505).getSelectedPosition()]
        except (IndexError,RuntimeError,TypeError):return
        head=[row.get('source') or '',row.get('author') or '']
        if row.get('rating') is not None:head.append('%g/10'%row['rating'])
        if row.get('likes'):head.append('♥ %d'%row['likes'])
        if row.get('date'):head.append(row['date'])
        xbmcgui.Dialog().textviewer('  ·  '.join(h for h in head if h),row.get('text') or '')

    def _episodes(self,index):
        if not self.seasons:return
        index=max(0,min(index,len(self.seasons)-1))
        season=self.seasons[index]
        if season==self._season:return
        self._season=season
        self.episodes=title_details.episodes(self.meta,season)
        from resources.lib import release_info
        if release_info.hide_on():
            # 7.0.32: Hide unreleased titles - episodes not aired yet too
            from datetime import date
            today=date.today()
            self.episodes=[e for e in self.episodes if (release_info.episode_day(e) or today)<=today]
        items=[]
        for e in self.episodes:
            from resources.lib.display_text import clean, episode_line
            # 7.0.29: the card says "Episode N"; its title and description go to the top of the page.
            li=listitems.item(label='Episode %s'%e['episode'])
            li.setProperty('name',clean(e.get('title') or e.get('name') or ''))
            li.setProperty('episode_meta', episode_line(e, season))
            # 7.0.12: the episode's own still in both layouts (the series poster was shown before).
            art=e.get('thumbnail') or e.get('background') or self.meta.get('background') or e.get('poster') or self.meta.get('poster')
            li.setArt({'thumb':art_cache.card(art)})
            li.setProperty('plot',title_details.episode_plot(e,self.meta))
            li.setProperty('episode_title',(self.meta.get('name') or self.meta.get('title') or '')+' - S%s E%s - %s'%(season,e['episode'],e.get('title') or e.get('name') or 'Episode'))
            items.append(li)
        self.getControl(502).reset();self.getControl(502).addItems(items)
        selected=next((i for i,e in enumerate(self.episodes) if e['id']==self.context.get('video_id')),0)
        if items:self.getControl(502).selectItem(selected)
        self.setProperty('meganexus.season',title_details.season_label(season))
        try:
            control=self.getControl(501)
            for i in range(control.size()):control.getListItem(i).setProperty('current','1' if i==index else '')
        except Exception:pass
        self._watch_badges()
        # 7.0.45: each episode's rating on its card and over the page
        if season not in self._rating_jobs:
            self._rating_jobs.add(season)
            def rate():
                try:found=title_details.season_ratings(self.meta,season)
                except Exception:found={}
                if not self.closed and found:self._episode_ratings.put((season,found))
            from .play_jobs import _BACKGROUND
            self._extra_jobs.append(_BACKGROUND.submit(rate))
        else:self._apply_episode_ratings(season,getattr(self,'_season_ratings',{}).get(season) or {})
        missing=any(not title_details.episode_description(e) for e in self.episodes)
        if missing and season not in self._description_jobs:
            self._description_jobs.add(season)
            def load():
                try:data=title_details.season_descriptions(self.meta,season)
                except Exception:data={}
                if not self.closed:self._descriptions.put((season,data))
            from .play_jobs import _BACKGROUND
            self._extra_jobs.append(_BACKGROUND.submit(load))

    def onFocus(self,cid):
        if cid==502 and self.seasons:
            self._episodes(self.getControl(501).getSelectedPosition())

    def _apply_episode_ratings(self,season,found):
        self._season_ratings=dict(getattr(self,'_season_ratings',{}));self._season_ratings[season]=found
        if season!=self._season:return
        for i,e in enumerate(self.episodes):
            value=found.get(title_details.number(e.get('episode')))
            try:
                item=self.getControl(502).getListItem(i)
                item.setProperty('rating','★ %.1f'%value if value else '');item.setProperty('rating_value','%.1f'%value if value else '')
            except Exception:return
        self._shown_plot=None   # the top line again, with its rating

    def _episode_rating(self,rating):
        """7.0.45: the episode under the cursor's rating at the end of the release line,
        with TMDB's logo; the title's own ratings stay."""
        if rating==getattr(self,'_rating_shown',None):return
        self._rating_shown=rating
        from resources.lib.ratings_row import LOGOS
        icon=LOGOS['tmdb'] if rating else ''
        self.setProperty('meganexus.release.rating',rating);self.setProperty('meganexus.release.rating_icon',icon)
        if getattr(self,'inplace',False):
            home=xbmcgui.Window(10000)
            home.setProperty('meganexus.inplace.rating',rating);home.setProperty('meganexus.inplace.rating_icon',icon)

    def _top_plot(self):
        """7.0.29: on an episode the top of the page describes it; elsewhere the series."""
        text=self.meta.get('description') or self.meta.get('overview') or ''
        rating=''
        if self.getFocusId()==502 and self.episodes:
            pos=self.getControl(502).getSelectedPosition()
            if 0<=pos<len(self.episodes):
                item=self.getControl(502).getListItem(pos)
                name=item.getProperty('name');plot=item.getProperty('plot')
                if name.lower().startswith('episode'):name=''   # no real title: "Episode 1" once
                episode=self.episodes[pos]
                head='Season %s  ·  Episode %s'%(episode.get('season') or self._season or 1,episode.get('episode'))
                text='[B]%s%s[/B][CR]%s'%(head,('  ·  '+name) if name else '',plot)
                rating=item.getProperty('rating_value')
                self._release(episode)
        if self.getFocusId()!=502 or not self.episodes:self._release()
        self._episode_rating(rating)
        if text!=getattr(self,'_shown_plot',None):
            self._shown_plot=text;self.setProperty('meganexus.plot',text)
            if getattr(self,'inplace',False):
                # 7.0.44: Home's top shows the episode under the cursor (its story there)
                xbmcgui.Window(10000).setProperty('meganexus.inplace.plot',text if self.getFocusId()==502 and self.episodes else '')

    def tick(self):
        if self.closed:return
        if getattr(self,'home_tick',None):
            try:self.home_tick(getattr(self,'_last_input',0.0))
            except Exception:pass
        if getattr(self,'_refresh_marks',False):
            self._refresh_marks=False
            self._favorite_label();self._watch_badges()
        if self.meta.get('type')=='series':self._top_plot()
        else:self._release()
        # Kodi moves horizontal list selection without another onFocus callback.
        if self.seasons and self.getFocusId()==501:
            self._episodes(self.getControl(501).getSelectedPosition())
        if self._metadata_job is not None and self._metadata_job.done():
            future,self._metadata_job=self._metadata_job,None
            try:
                meta=future.result()
                if not meta:raise ValueError('No details returned')
            except Exception:
                self._metadata_pending=False;self._metadata_error=True;self._after_metadata=None
                self.setProperty('meganexus.related_busy','')
                self.setProperty('meganexus.related_status','Details unavailable. Select Play to retry, or press Back.')
                self.getControl(100).setLabel('Retry details')
            else:
                self._metadata_pending=False;self._metadata_error=False
                try:self._restore_focus=self.getFocusId()
                except Exception:pass
                combined=dict(self.meta,**meta)
                for key in ('name','poster','background','description'):
                    if not combined.get(key):combined[key]=self.meta.get(key) or ''
                self.meta=_chosen_art(combined);self.onInit()
                # First season becomes navigable as soon as its episodes arrive.
                if self.meta.get('type')=='series' and self.seasons and self.getFocusId()==100:self.setFocusId(501)
                if self._after_metadata is not None:
                    manual=self._after_metadata;self._after_metadata=None
                    self.defer(lambda:self._play(manual))
        while not self._episode_ratings.empty():
            season,found=self._episode_ratings.get_nowait()
            self._apply_episode_ratings(season,found)
        while not self._descriptions.empty():
            season,data=self._descriptions.get_nowait()
            if data.get('season'):
                self.meta.setdefault('meganexus_season_overviews',{})[str(season)]=data['season']
            for e in title_details.episodes(self.meta,season):
                summary=data.get(title_details.number(e.get('episode')))
                if not title_details.episode_description(e) and summary:
                    e['description']=summary
            if season==self._season:
                for i,e in enumerate(self.episodes):self.getControl(502).getListItem(i).setProperty('plot',title_details.episode_plot(e,self.meta))
        try:found=self._reviews.get_nowait()
        except queue.Empty:found=None
        if found is not None:self._show_reviews(found)
        try:rows=self._recommendations.get_nowait()
        except queue.Empty:return
        self.related=rows;self._related_loaded=True
        self.setProperty('meganexus.related_busy','')
        self.setProperty('meganexus.related_status','' if rows else 'No recommendations available for this title.')
        items=[];watched=simkl_watched.snapshot()
        for row in rows[:16]:
            li=listitems.item(label=row['title'])
            li.setArt({'thumb':art_cache.card((row.get('fanart') or row.get('poster')) if self.landscape else row.get('poster'))})
            li.setProperty('plot',row.get('plot') or '')
            target=row['target'];li.setProperty('watched','1' if simkl_watched.state(watched,target['media_type'],target['canonical_id']).get('watched') else '')
            items.append(li)
        self.getControl(504).reset();self.getControl(504).addItems(items)

    def child(self,fn,*args,**kwargs):
        if self.seasons:
            self.context['season']=self._season
            if self.episodes:
                pos=max(0,min(self.getControl(502).getSelectedPosition(),len(self.episodes)-1))
                self.context['video_id']=self.episodes[pos]['id']
        return super().child(fn,*args,**kwargs)

    def _more_like(self):
        from .catalog import open_catalog
        if not self._related_loaded:
            from .play_jobs import job
            rows=job(lambda:title_details.related(self.meta,limit=100),label='Finding similar titles')
            if not rows:
                xbmcgui.Dialog().notification('More like this','No similar titles were found.',time=3000);return
            self.related=list(rows);self._related_loaded=True
        self.child(open_catalog,{'label':'More like this · '+str(self.meta.get('name') or self.meta.get('title') or ''),'rows':self.related})

    def _person(self):
        from .play_jobs import job
        from .catalog import open_catalog
        persons=self.meta.get('meganexus_people',title_details.people(self.meta))
        pos=self.getControl(503).getSelectedPosition()
        if not 0<=pos<len(persons):return
        person=persons[pos]
        self.child(open_person,person)

    def _info(self,episode=False):
        if self._metadata_pending or self._metadata_error:return
        entry=None
        if episode and self.episodes:
            entry=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
        show_info(self.meta,entry)

    def _watch_badges(self):
        m=self.meta;mid=m.get('id') or self.context.get('canonical_id')
        entry=simkl_watched.state(simkl_watched.snapshot(),m.get('type') or 'movie',mid)
        self.setProperty('meganexus.watched','1' if entry.get('watched') else '')
        # 7.0.29: the same button takes a mark away again
        try:self.getControl(104).setLabel('Unmark watched' if entry.get('watched') else 'Mark watched')
        except Exception:pass
        for i,season in enumerate(self.seasons):
            eps=title_details.episodes(m,season)
            watched=entry.get('watched') or str(season) in entry.get('seasons',[]) or (bool(eps) and all(simkl_watched.is_episode_watched(entry,season,e['episode']) for e in eps))
            self.getControl(501).getListItem(i).setProperty('watched','1' if watched else '')
        for i,e in enumerate(self.episodes):
            self.getControl(502).getListItem(i).setProperty('watched','1' if simkl_watched.is_episode_watched(entry,e.get('season',1),e['episode']) else '')
        self._watch_next(entry)

    def _watch_next(self,entry):
        """7.0.29: "Next · S5 E3" before the seasons - the episode after the last one
        watched (the latest season and episode watched, whatever is left behind)."""
        self._watch_next_target=None
        if (self.meta.get('type') or '')!='series' or not self.seasons:
            self.setProperty('meganexus.next.label','');return
        order=[(s,e) for s in self.seasons if str(s)!='0' for e in title_details.episodes(self.meta,s)]
        last=max((i for i,(s,e) in enumerate(order) if simkl_watched.is_episode_watched(entry,e.get('season',s),e['episode'])),default=None)
        if last is not None and last+1<len(order):
            season,e=order[last+1]
            self._watch_next_target=(season,e["id"])
            self.setProperty('meganexus.next.label','Next · S%s E%s'%(e.get('season',season),e['episode']))
        else:self.setProperty('meganexus.next.label','')

    def _go_next(self):
        """Select the next episode (its season pill, then the episode) - OK plays it."""
        if not getattr(self,"_watch_next_target",None):return
        season,video_id=self._watch_next_target
        if season not in self.seasons:return
        index=self.seasons.index(season)
        try:self.getControl(501).selectItem(index)
        except Exception:pass
        self._episodes(index)
        pos=next((i for i,e in enumerate(self.episodes) if e['id']==video_id),0)
        self.getControl(502).selectItem(pos);self.setFocusId(502)

    def _mark_watched(self,only=None,unmark=False):
        from .play_jobs import job
        from resources.lib import trakt_api
        # 6.0.39: Simkl and/or Trakt, whichever is connected (Trakt-only users too).
        from resources.lib import mdblist_tracking
        # 7.0.29: MDBList too, when its tracking is on - every connected service.
        services=[name for name,on in (('Simkl',simkl_api.authorized()),('Trakt',trakt_api.authorized()),('MDBList',mdblist_tracking.enabled())) if on]
        # 8.1.2: this box keeps the mark whatever is connected. It used to refuse
        # without a service and offer to sign in to Simkl, so a person with no tracking
        # account could not mark anything watched at all - and the mark it sent to the
        # services was never written here, which is why taking one back never held.
        m=self.meta;scope='title';season=episode=None
        if m.get('type')=='series' and only=='episode' and self.episodes:
            # 7.0.29: long OK on an episode - that episode, no question
            e=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
            scope='episode';season=e.get('season',1);episode=e['episode']
        elif m.get('type')=='series':
            if self.seasons:self._episodes(self.getControl(501).getSelectedPosition())
            choices=['Entire series (all aired episodes)']
            if self.seasons:
                season=self.seasons[max(0,self.getControl(501).getSelectedPosition())]
                choices.append(title_details.season_label(season))
            if self.episodes:
                e=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
                choices.append('Episode S%s E%s - %s'%(e.get('season',1),e['episode'],e.get('title') or e.get('name') or 'Episode'))
            pick=xbmcgui.Dialog().select(('Unmark watched on ' if unmark else 'Mark watched on ')+' and '.join(services),choices)
            if pick<0:return
            scope=('title','season','episode')[pick]
            if scope=='episode':season=e.get('season',1);episode=e['episode']
        from resources.lib.hub import extract_ids
        ctx=dict(extract_ids(m),media_type=m.get('type') or 'movie',canonical_id=m.get('id') or '',title=m.get('name') or m.get('title') or '')
        from resources.lib import trakt_watched
        marks={'Simkl':simkl_watched.mark,'Trakt':trakt_watched.mark,'MDBList':mdblist_tracking.mark}
        if unmark:marks={'Simkl':simkl_watched.unmark,'Trakt':trakt_watched.unmark,'MDBList':mdblist_tracking.unmark}
        # 7.0.32: saved in the background - no loading screen over the page; a
        # notification when it is done, as for everything else.
        title='Unmark watched' if unmark else 'Mark watched'
        from resources.lib import watched_local
        if scope=='title':watched_local.mark(ctx['media_type'],ctx['canonical_id'],watched=not unmark)
        elif scope=='episode':watched_local.mark(ctx['media_type'],ctx['canonical_id'],watched=not unmark,
                                                 season=season,episode=episode)
        else:
            # a whole season: every episode of it we know about
            for e in (self.episodes or []):
                if str(e.get('season',1))==str(season):
                    watched_local.mark(ctx['media_type'],ctx['canonical_id'],watched=not unmark,
                                       season=e.get('season',1),episode=e['episode'])
        self._refresh_marks=True
        if not services:
            notify(title,'Unmarked here' if unmark else 'Marked watched here')
            return
        def work():
            done,failed=[],[]
            for name in services:
                try:marks[name](ctx,scope,season,episode);done.append(name)
                except Exception as exc:failed.append('%s: %s'%(name,str(exc) if isinstance(exc,ValueError) else 'could not save'))
            if done:notify(title,('Unmarked on ' if unmark else 'Marked watched on ')+' and '.join(done))
            if failed:notify(title,' · '.join(failed),error=True)
            self._refresh_marks=True
        from .play_jobs import _BACKGROUND
        _BACKGROUND.submit(work)

    def _play(self,manual=False):
        if self._metadata_pending or self._metadata_error:
            self._after_metadata=manual;self.getControl(100).setLabel('Preparing video…')
            if self._metadata_error:
                self._metadata_error=False;self._metadata_pending=True;self._metadata_job=browse_meta.request(self.context)
            return
        context=dict(self.context)
        if manual:context['force_manual']=True
        if self.meta.get('type')=='series':
            if self.seasons:self._episodes(self.getControl(501).getSelectedPosition())
            if not self.episodes:
                xbmcgui.Dialog().ok('Episodes','The selected metadata provider has no episodes for this series.');return
            pos=max(0,self.getControl(502).getSelectedPosition())
            e=self.episodes[min(pos,len(self.episodes)-1)]
            if context.get('video_id')!=e['id']:
                context.pop('resume_seconds',None);context.pop('resume_percent',None)
            context.update(video_id=e['id'],season=e.get('season',1),episode=e['episode'])
        if context.pop('meganexus_refresh_local_resume',False):
            # Stop may be delivered after this window began opening. Read the
            # committed final position again at the actual playback click.
            from resources.lib import continue_local
            saved=next((r for r in continue_local.recent() if r.get('canonical_id')==self.meta['id'] and r.get('video_id')==(context.get('video_id') or self.meta['id'])),None)
            context.pop('resume_seconds',None);context.pop('resume_percent',None)
            if saved and saved.get('event_type')!='watched':
                context.update(resume_seconds=saved.get('position') or 0,resume_percent=saved.get('percent') or 0)
        self.context=context
        # 7.0.29: this page hides once the video starts (Kodi refuses its full-screen
        # video while a page like this is open - the page showed before the film).
        from . import play_jobs
        if getattr(self,'home_pause',None):self.home_pause()   # 7.0.44: Home's silent trailer ends (and the sound comes back)
        self._meganexus_play_hidden=False;play_jobs.PARENTS.append(self)
        try:started=choose_stream(self.meta,context)
        finally:
            try:play_jobs.PARENTS.remove(self)
            except ValueError:pass
        if started:self.action='playing';self.close()
        elif self._meganexus_play_hidden:
            self._meganexus_play_hidden=False;self.show_ready()   # it did not start: the page again

    def _favorite_label(self):
        try:
            from resources.lib import library
            inside=library.contains(self.meta.get('type') or 'movie',self.meta.get('id') or '')
        except Exception:inside=False
        self.getControl(101).setLabel('In Library' if inside else 'Add to Library')

    def _add_to_library(self):
        # 6.0.35: the MegaNexus Library (local, synced with the Nuvio account)
        # plus Trakt / Simkl when connected - no Simkl sign-in required.
        from .play_jobs import job
        from resources.lib import library
        mt=self.meta.get('type') or 'movie';mid=self.meta.get('id') or ''
        item=dict(self.meta,media_type=mt,canonical_id=mid,title=self.meta.get('name') or self.meta.get('title') or '')
        # 7.0.32: in the background - the button changes at once, a notification when saved
        try:inside=library.contains(mt,mid)
        except Exception:inside=False
        self.getControl(101).setLabel('Add to Library' if inside else 'In Library')
        def work():
            library_change(item,inside)
            self._refresh_marks=True
        from .play_jobs import _BACKGROUND
        _BACKGROUND.submit(work)

    def onClick(self,control_id):
        # 7.0.44: moving around the page leaves the trailer playing; a click on a
        # button, an episode, a person or a title (More like this...) ends it -
        # choosing a season is moving
        if control_id==103:
            # 8.1.2: Trailer, while its own preview is already playing it small. The clip is
            # decoded and on screen, so it steps up to Kodi's full-screen player as Sport and
            # IPTV do - the pause below would stop it and the whole thing would be resolved
            # and started again, which is the reload the user sees.
            from .trailers import take_over
            try:
                owner=getattr(self,'home_previews',None)
                if callable(owner):owner=owner()          # Home's, for a title opened in place
                if take_over(owner or getattr(self,'_own_previews',None),self.meta,parent=self):
                    return
            except Exception:
                xbmc.log('[MegaNexus] Trailer handover skipped: '+traceback.format_exc(),xbmc.LOGWARNING)
        if control_id!=501 and getattr(self,'home_pause',None):
            try:self.home_pause()
            except Exception:pass
        if control_id==100:
            self._play()
        elif control_id==501:
            self._episodes(self.getControl(501).getSelectedPosition());self.setFocusId(502)
        elif control_id==507:
            self._go_next()   # 7.0.29: Watch next
            if self.inplace and self.episodes:self._play()   # 7.0.44: in the line of buttons it plays at once
        elif control_id==502:self._play()
        elif control_id==103:
            # nothing was playing to step up from (take_over above said so): resolve and play
            from .trailers import show_trailer
            if not show_trailer(self.meta,parent=self,ready=getattr(self,'_trailer_ready','')):self.setProperty('meganexus.trailer_status','Trailer unavailable. Try another title, or change the trailer source in Settings > Trailers.')
        elif control_id==101:
            self._add_to_library()
        elif control_id==104:self._mark_watched(unmark=self.getProperty('meganexus.watched')=='1')
        elif control_id==105:self._more_like()
        elif control_id==106:self._more_like()   # 7.0.29: More like this took Info's place
        elif control_id==503:
            self._person()
        elif control_id==505:
            self._open_review()   # 7.0.45: the whole review
        elif control_id==504 and self.related:
            row=self.related[self.getControl(504).getSelectedPosition()]
            outcome=self.child(open_context,row['target'],row=row,hero=True)   # 7.0.44: like on Home
            if outcome=='playing' or isinstance(outcome,dict):self.action=outcome;self.close()
        elif control_id==102:self.close()

    def close(self):
        if self._metadata_job:self._metadata_job.cancel()
        for future in self._extra_jobs:future.cancel()
        self.closed=True
        super().close()

    def onAction(self,action):
        aid=action.getId()
        self._last_input=time.monotonic()
        if aid in (9,10,92,216):
            self.close()
        elif aid in (117,101,1009,11):
            focus=self.getFocusId()
            if focus==505:return   # 7.0.45: a review only opens (OK) - no menu
            if focus==504 and self.related:
                row=self.related[self.getControl(504).getSelectedPosition()]
                choice='details' if aid==11 else context_choice(row['target'],row)   # 7.0.36: Info key = its page
                if not choice or quick_choice(choice,row['target'],row):return
                outcome=(self.in_place if plays_directly(row['target'],row,choice) else self.child)(run_choice,row['target'],choice,row)
                if outcome=='playing' or isinstance(outcome,dict):self.action=outcome;self.close()
                return
            if focus==502 and aid!=11 and self.episodes:
                # 7.0.29: an episode's own options
                e=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
                pos=max(0,self.getControl(502).getSelectedPosition())
                seen=self.getControl(502).getListItem(pos).getProperty('watched')=='1'
                label=('Unmark watched · S%s E%s' if seen else 'Mark watched · S%s E%s')%(e.get('season',1),e['episode'])
                choice=context_choice(options=[('episode_watched',label),('rate_episode','Rate this episode · S%s E%s'%(e.get('season',1),e['episode'])),
                                               ('manual','Choose stream manually')])
                if choice=='episode_watched':self._mark_watched(only='episode',unmark=seen);return
                if choice=='rate_episode':self._rate(e);return
            else:
                if aid==11:return   # 7.0.36: no Info window - this page is the title's details
                # 7.0.45: rate the film / show on Trakt
                choice=context_choice(options=DEFAULT_OPTIONS+(('rate','Rate this %s'%('show' if self.meta.get('type')=='series' else 'movie')),))
            if choice=='manual':
                if focus==501:self._episodes(self.getControl(501).getSelectedPosition())
                self._play(manual=True)
            elif choice=='related':self._more_like()
            elif choice=='rate':self._rate()
            elif choice=='info':self._info(episode=focus==502)


REVIEW_LINE=64   # 7.0.45: characters on one line of a review card


def review_lines(text,width=REVIEW_LINE):
    import textwrap
    lines=textwrap.wrap(' '.join(str(text or '').split()),width) or ['']
    if len(lines)>2:lines=[lines[0],lines[1].rstrip(' .,;:')+'…']
    return lines


class Info(Dialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self.meta=kwargs['meta'];self.episode=kwargs.get('episode')
    def onInit(self):
        m=self.meta;e=self.episode
        title=m.get('name') or m.get('title') or ''
        if e:title+=' - S%s E%s - %s'%(e.get('season',1),e.get('episode'),e.get('title') or e.get('name') or 'Episode')
        self.setProperty('meganexus.title',title)
        self.setProperty('meganexus.poster',art_cache.url(m.get('poster') or ''))
        plot=title_details.episode_plot(e,m) if e else (m.get('overview') or m.get('description') or 'No description supplied.')
        self.setProperty('meganexus.plot',plot)
        self.getControl(510).setText(plot)
        self.getControl(503).reset()
        items=[]
        for person in m.get('meganexus_people',title_details.people(m)):
            li=listitems.item(label=person['name'],label2=person['role'])
            li.setArt(art_cache.art({'thumb':person.get('photo') or 'special://home/addons/script.meganexus/resources/media/person.png'}));items.append(li)
        self.getControl(503).addItems(items)
        self.setProperty('meganexus.has_people','1' if items else '')
    def onClick(self,cid):
        if cid==102:self.close()
        elif cid==503:Details._person(self)
    def onAction(self,action):
        if action.getId() in (9,10,92,216):self.close()


def show_info(meta,episode=None):
    win=Info('meganexus_info.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',meta=meta,episode=episode)
    try:win.doModal()
    finally:win.close()


class ContextMenu(Dialog):
    """Title options (6.0.35): the options depend on the card (see title_options)."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self.choice='';self.options=list(kwargs.get('options') or DEFAULT_OPTIONS)[:7]
        self.heading=kwargs.get('heading') or 'Title options'
        self._focus_ready=False
    def onInit(self):
        self.setProperty('meganexus.opt.title',self.heading)
        for i in range(7):self.setProperty('meganexus.opt.%d'%i,self.options[i][1] if i<len(self.options) else '')
        self.setProperty('meganexus.opt.count',str(len(self.options)))
        self._opened=time.monotonic()
        self.setFocusId(100)
    def tick(self):
        # 8.1.3: the first option is drawn only once its text is set (above), a frame later.
        # Asked for once, at once, Kodi refused it ("Control 100 ... asked to focus, but it
        # can't") and the menu opened with nothing focused - every long-OK menu needed a
        # press first. It is asked for until an option has the cursor (2 s at most).
        if self._focus_ready:return
        try:held=self.getFocusId()
        except Exception:held=0
        if 100<=held<100+len(self.options) or time.monotonic()-getattr(self,'_opened',0)>2:
            self._focus_ready=True;return
        self.setFocusId(100)
    def onClick(self,cid):
        if 100<=cid<100+len(self.options):
            self.choice=self.options[cid-100][0]
            self.close()
    def onAction(self,action):
        if action.getId() in (9,10,92,216):self.close()


DEFAULT_OPTIONS=(('manual','Choose stream manually'),('related','More like this'))
# Choices that open another screen (the caller hides its window for them).
SCREEN_CHOICES=('manual','start','related','details')


def title_options(context,row=None):
    """Options for one card. Continue Watching cards add Play from the
    beginning / Remove (GitHub issue #5); every title can be added to or
    removed from the Library."""
    row=row or {};options=[]
    kind=row.get('continue_card')
    if kind=='resume' and float((row.get('target') or context).get('resume_seconds') or 0)>0:
        options.append(('start','Play from the beginning'))
    options.append(('manual','Choose stream manually'))
    if kind in ('resume','next'):options.append(('remove','Remove from Continue Watching'))
    try:
        from resources.lib import library
        inside=library.contains(context.get('media_type') or 'movie',context.get('canonical_id') or '',
                                {k:context.get(k) for k in ('imdb_id','tmdb_id','tvdb_id')})
    except Exception:inside=False
    if not inside:
        options.append(('library','Add to Library'))
    else:
        # 8.1.2: with a tracking service connected, each place can be named - "Remove
        # from Library" took the title off all of them at once and there was no way to
        # say which one was meant.
        try:places=library.places()
        except Exception:places=[]
        # one entry either way: the menu holds seven and a Continue Watching card
        # already uses most of them, so the places are asked for in a second menu
        options.append(('unlibrary_where','Remove from...') if len(places)>1
                       else ('unlibrary','Remove from Library'))
    # 7.0.36: no Info here - "Details" on Continue Watching opens the title's page (with Play)
    if kind in ('resume','next'):options.append(('details','Details'))
    options.append(('related','More like this'))
    # 7.0.45: rate it on Trakt (typed on the phone)
    options.append(('rate','Rate this %s'%('show' if (context.get('media_type') or '')=='series' else 'movie')))
    return options


def context_choice(context=None,row=None,options=None,heading=None):
    """``heading``: 8.1.2 - the menu can be about one thing ("Remove"), not only
    "Title options". ContextMenu has taken it since 6.0.35; this did not pass it on,
    which made the removal menu raise a TypeError the moment it was asked for."""
    options=options or (title_options(context,row) if context else DEFAULT_OPTIONS)
    win=ContextMenu('meganexus_context.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',options=options,heading=heading)
    try:win.doModal();return win.choice
    finally:win.close()


def rate_card(context,row=None):
    """7.0.45: a card's Rate this movie / show - the phone's rate page, sent to Trakt / TMDB."""
    from resources.lib import trakt_api, rate_title, tmdb_account
    if not trakt_api.authorized() and not tmdb_account.connected():
        xbmcgui.Dialog().ok('Rate','Sign in to Trakt or TMDB first: HUB Settings > Accounts & tracking.');return
    meta={'id':context.get('canonical_id') or '','type':context.get('media_type') or 'movie',
          'name':(row or {}).get('title') or context.get('title') or '',
          'imdb_id':context.get('imdb_id') or '','tmdb_id':context.get('tmdb_id') or ''}
    target=rate_title.target(meta)
    if not (target.get('imdb') or target.get('tmdb')):
        xbmcgui.Dialog().notification('Rate','This title has no IMDb or TMDB id to rate it by.',time=4000);return
    from .phone_setup import run
    sent=run(rating=target)
    if sent:xbmcgui.Dialog().notification('Rate',sent.get('done') or 'Sent',time=4000)


def quick_choice(choice,context,row=None):
    """Choices that need no screen. Returns True when handled."""
    row=row or {}
    mt=context.get('media_type') or 'movie';mid=context.get('canonical_id') or ''
    if choice=='rate':
        rate_card(context,row);return True
    if choice=='remove':
        # Hidden until played again; progress and watched state stay as they are.
        from resources.lib import continue_rules
        continue_rules.hide(mt,mid,others=continue_rules.ids_of(dict(context,media_type=mt)))   # under all its ids (#31)
        import time
        xbmcgui.Window(10000).setProperty('meganexus.progress.revision','removed-%s'%time.time())
        xbmcgui.Dialog().notification('Continue Watching','Removed. It returns when you play it again.',time=3000)
        return True
    if choice=='unlibrary_where':
        # 8.1.2: which of them - this box's Library, Trakt, Simkl, MDBList, or all
        from resources.lib import library
        try:places=library.places()
        except Exception:places=[]
        where=[('unlibrary:'+key,'Remove from '+name) for key,name in places]
        where.append(('unlibrary','Remove from everywhere'))
        picked=context_choice(options=where,heading='Remove')
        return quick_choice(picked,context,row) if picked else True
    if choice=='library' or choice.startswith('unlibrary'):
        title=row.get('title') or context.get('title') or ''
        item=dict(row,media_type=mt,canonical_id=mid,title=title)
        only=choice.split(':',1)[1] if ':' in choice else None   # 8.1.2: one place only
        from .play_jobs import _BACKGROUND
        if choice!='library':
            # 8.1.2: what this box keeps goes now, so the screen that redraws itself
            # straight after this shows the title gone (or its badge gone). The service
            # is told on the background thread - that part can take seconds.
            from resources.lib import library
            try:library.forget(mt,mid,only)
            except Exception:pass
        _BACKGROUND.submit(lambda:library_change(item,choice!='library',only))   # 7.0.32: in the background
        return True
    return False


def notify(title,text,error=False):
    """The standard notification top right (7.0.32: after work done in the background)."""
    try:xbmcgui.Dialog().notification(title,text,xbmcgui.NOTIFICATION_WARNING if error else xbmcgui.NOTIFICATION_INFO,4000)
    except Exception:pass


def library_change(item,remove,only=None):
    """Add to / remove from the Library (and Trakt / Simkl when connected) off the
    page, then a notification (7.0.32: there was a loading screen over the page).

    8.1.2: ``only`` names one place ('local' or a tracker id) and the title stays on
    every other one."""
    from resources.lib import library
    try:
        if remove:
            library.forget(item['media_type'],item['canonical_id'],only)
            told=library.remove_on_services(item['media_type'],item['canonical_id'],only)
            where=dict(library.places()).get(only,'Library') if only else 'Library'
            if only and only!=library.LOCAL_PLACE and told and not any(ok for _,ok in told):
                # 8.1.2: it is off this box either way, but say so plainly rather than
                # claim the service did something it did not
                notify('Library','%s did not take it off - it is gone from the Library here.'%where)
            else:
                notify('Library','Removed from '+where)
        else:
            reached=library.add(item)
            notify('Library','Saved to Library'+((' and '+' + '.join(reached)) if reached else ''))
    except Exception as exc:
        notify('Library',str(exc) if isinstance(exc,ValueError) else 'The Library could not be updated.',error=True)


def run_choice(context,choice,row=None,inplace=False,hero=False,home_tick=None,home_pause=None,home_previews=None):
    """Screens opened from Title options. ``inplace`` / ``hero`` (7.0.44): Details
    opens like a click on the card - in place of Home's rows / over Browse all."""
    if choice=='related':return more_like_this(context,row)
    if choice=='info':choice='details'   # 7.0.36: the Info window is gone - the title's page instead
    ctx=dict(context,details_view=choice)
    if choice=='manual':ctx['force_manual']=True
    if choice=='start':
        ctx.pop('details_view',None)
        ctx.update(resume_seconds=0,resume_percent=0,play_from_start=True)
    if choice=='details' and (inplace or hero):return open_context(ctx,row=row,inplace=inplace,hero=hero,home_tick=home_tick,home_pause=home_pause,home_previews=home_previews)
    return open_context(ctx,row=row)


def more_like_this(context,row=None):
    """More like this opens straight as a grid (6.0.35)."""
    from .play_jobs import job
    from .catalog import open_catalog
    mt=context.get('media_type') or 'movie';mid=context.get('canonical_id') or ''
    def load():
        meta=browse_meta.cached(dict(context,media_type=mt,canonical_id=mid)) or backend_api.metadata(mt,mid)
        return meta,title_details.related(meta,limit=100)
    try:result=job(load,label='Loading recommendations')
    except Exception:result=None
    if not result:
        xbmcgui.Dialog().ok('More like this','No recommendations are available for this title.');return ''
    meta,rows=result
    if not rows:
        xbmcgui.Dialog().ok('More like this','No recommendations are available for this title.');return ''
    return open_catalog({'label':'More like this · '+str(meta.get('name') or meta.get('title') or (row or {}).get('title') or ''),'rows':rows})


def context_menu(context,info=False,row=None):
    """Title options and the chosen action in one call (callers that are
    already hidden). Home and catalog screens show the options first, over
    themselves, then hide only for screen choices."""
    choice='details' if info else context_choice(context,row)   # 7.0.36: the page, no Info window
    if not choice or quick_choice(choice,context,row):return ''
    return run_choice(context,choice,row)


def choose_stream(meta,context):
    from .play_jobs import play
    try:return play(meta,context)
    except Exception as exc:
        xbmcgui.Dialog().ok('Playback',str(exc) if isinstance(exc,ValueError) else 'Could not load this source. Check your provider configuration and connection.')
        return False


def _autoplay(context):
    return xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_autoplay')=='true' and not context.get('force_manual')


def plays_directly(context,row=None,choice=None):
    """7.0.29: does this start the video (or its source list) without the title page?
    Then the screen it comes from stays (Dialog.in_place) instead of closing first."""
    context=context or {}
    mt=context.get('media_type') or context.get('type') or 'movie'
    if choice is not None:
        if choice=='start':return True
        return choice=='manual' and (mt=='movie' or bool(context.get('video_id')))
    if context.get('details_view'):return False
    return bool(context.get('resume_seconds') or context.get('video_id') or context.get('play_from_start'))



NEXT_HANDOFF_FOR=120   # 9.0.0: s the next episode has to take the player over from the paused film


def _hand_over_to_next():
    """The playing film's stop, when the next episode replaces it, is a hand-over (the
    service's source-switch note): no stop curtain, nothing saved over its finished mark."""
    import json,time,uuid
    from resources.lib.player_session import load_session
    now=time.time();token=uuid.uuid4().hex
    note={'token':token,'old_uid':str((load_session() or {}).get('playback_uid') or ''),'created_at':now,
          'expires_at':now+NEXT_HANDOFF_FOR,'ack':False,'next_episode':True}
    xbmcgui.Window(10000).setProperty('meganexus.source_switch_handoff.v2',json.dumps(note,separators=(',',':')))
    return token


def _hand_over_failed(token):
    """No source started for the next episode: the note goes, the paused film stops as on Back."""
    import json
    home=xbmcgui.Window(10000)
    try:note=json.loads(home.getProperty('meganexus.source_switch_handoff.v2') or '{}')
    except ValueError:note={}
    if note.get('token')==token:home.clearProperty('meganexus.source_switch_handoff.v2')
    if xbmc.Player().isPlayingVideo():
        from .trailers import _darken_for_stop
        from resources.lib.foreground_guard import stop_film
        # 9.0.8: as Back does (trailers.wait_for_playback) - named as being left, stopped through
        # Kodi's JSON-RPC: the Player's own stop() kept Python's lock while the film closed
        _darken_for_stop();stop_film(home.getProperty('meganexus.playback.started'))


def open_context(context,row=None,inplace=False,hero=False,home_tick=None,home_pause=None,home_previews=None):
    """``inplace`` (7.0.44): opened from Home's rows or a collection - the title's
    buttons, seasons and episodes come in place of Home's rows (Home keeps its top
    and trailer); after playing or Back it is Home again. ``hero``: the same from
    Browse all, where the page draws Home's top itself."""
    mid=context.get('canonical_id') or context.get('id') or ''
    if not mid:return ''
    mt=context.get('media_type') or context.get('type') or 'movie'
    if mt in ('tv','show','tvshow','episode','anime'):mt='series'
    context=dict(context,canonical_id=mid,media_type=mt)
    if (row or {}).get('continue_card') in ('resume','next'):context['meganexus_continue']=True
    meta=browse_meta.cached(context)
    metadata_pending=meta is None
    if meta is None:meta=browse_meta.seed(context,row)
    view=context.get('details_view')
    direct=(view=='manual' and (mt=='movie' or context.get('video_id'))) or (not view and (context.get('resume_seconds') or context.get('video_id') or context.get('play_from_start')))
    starting=None
    if metadata_pending and (direct or view=='info'):
        from .play_jobs import job, Loading, ROOT
        if direct and not _autoplay(context):
            # 7.0.29: the sources are chosen over the screen it was started from.
            from .play_jobs import wait_overlay
            starting=wait_overlay('Loading sources…',meta)
        elif direct:
            # 7.0.29: a resume starts on the title's own picture, in ONE loading
            # screen up to the video (two in a row showed the wallpaper between).
            starting=Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label='Loading video…')
            starting.show()
        try:meta=job(lambda:backend_api.metadata(mt,mid),meta,label=('Loading video…' if _autoplay(context) else 'Loading sources…') if starting else 'Loading details',window=starting)
        except Exception:meta=None
        if starting is not None and meta:
            try:starting.apply(meta)   # the full details' picture and logo
            except Exception:pass
        if not meta:
            if starting:starting.close()
            return ''
        metadata_pending=False
    if view=='info':
        episode=next((e for e in title_details.episodes(meta) if e['id']==context.get('video_id')),None) if mt=='series' else None
        show_info(meta,episode);return ''
    if starting is not None:
        from .play_jobs import handoff
        handoff(starting)
    try:playing=bool(direct and choose_stream(meta,context))
    finally:
        if starting is not None:
            from .play_jobs import _take_handoff
            _take_handoff()           # not taken (another path): never left open
            try:starting.close()
            except Exception:pass
    if direct and not playing:
        # 7.0.44: the source list was closed without a choice (or nothing played) -
        # back where it was started from (Home, a collection...), not the title page
        return ''
    addon=xbmcaddon.Addon('script.meganexus')
    filename='meganexus_details_landscape.xml' if xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape')=='landscape' else 'meganexus_details.xml'
    if inplace:filename=filename.replace('meganexus_details','meganexus_details_inplace')
    elif hero:filename=filename.replace('meganexus_details','meganexus_details_hero')   # Browse all: the page draws Home's top
    inplace=inplace or hero
    related=None
    while True:
        if playing:
            from .trailers import wait_for_playback
            wait_for_playback(next_ok=True)
            import json
            home=xbmcgui.Window(10000);raw=home.getProperty('meganexus.next_episode')
            home.clearProperty('meganexus.next_episode')
            if raw:
                try:next_context=json.loads(raw)
                except ValueError:next_context={}
                if next_context.get('canonical_id')==mid:
                    # 9.0.0: over the paused film - its loading screen, then the next episode
                    # takes the player over; the old one's stop is a hand-over, not a leaving
                    context=next_context
                    handed=_hand_over_to_next()
                    playing=choose_stream(meta,context)
                    if playing:continue
                    _hand_over_failed(handed)   # nothing to play: the film goes as on Back
            from resources.lib import continue_local
            saved=next((r for r in continue_local.recent() if r.get('canonical_id')==mid and r.get('video_id')==context.get('video_id')),None)
            # 9.0.0: no "Next episode?" question after the film - Next episode is in the player;
            # leaving it comes back exactly where it was started
            context.pop('resume_seconds',None);context.pop('resume_percent',None)
            if saved and saved.get('event_type')!='watched':
                context.update(resume_seconds=saved.get('position') or 0,resume_percent=saved.get('percent') or 0)
            context['meganexus_refresh_local_resume']=True
            playing=False
            # 7.0.44: after the video, Home again (where it was). 7.0.45: also a video started
            # straight from a card (Continue Watching's Resume, a direct play) goes back where
            # it was started - the old dark title page opened after it.
            if inplace or direct:return ''
        window=Details(filename,addon.getAddonInfo('path'),theme_folder(),'1080i',meta=meta,context=context,metadata_pending=metadata_pending,related=related,inplace=inplace,
                       home_tick=home_tick,home_pause=home_pause,home_previews=home_previews,hero=hero,card=row)
        try:
            window.doModal();action=window.action;context=dict(window.context)
            if inplace:
                xbmcgui.Window(10000).clearProperty('meganexus.inplace.plot')
                xbmcgui.Window(10000).clearProperty('meganexus.inplace.rating')   # 7.0.45
                xbmcgui.Window(10000).clearProperty('meganexus.inplace.rating_icon')
            if getattr(window,'_own_previews',None):
                window._own_previews.finish()   # the page's trailer ends with it
                window._own_previews.release();window._own_previews=None   # 8.1.2: and its Player goes
            meta=window.meta;metadata_pending=window._metadata_pending
            # Returning from the player reuses loaded recommendations.
            related=window.related if getattr(window,'_related_loaded',False) else None
        finally:window.close()
        if action=='playing':playing=True;continue
        return action


def open_person(person):
    from .play_jobs import job
    from .person import open_page
    try:
        page = job(lambda: title_details.person_page(person), label='Loading actor · Movies and Series')
    except Exception as exc:
        xbmcgui.Dialog().ok('Actor filmography', str(exc) if isinstance(exc, ValueError) else 'Filmography could not load. Check the metadata add-ons and retry.')
        return ''
    if page is None:
        return ''
    return open_page(page)
