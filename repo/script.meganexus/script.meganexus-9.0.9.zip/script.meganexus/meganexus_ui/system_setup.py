# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import time
import xbmc
import xbmcaddon
import xbmcgui


def execute_command(command):
    """Called only after the owning MegaNexus modal window has closed."""
    while command:
        if command=='meganexus:reload':   # 7.0.30: a new theme chosen in the settings
            from resources.lib import theme
            theme.sync()
            return
        if command.startswith('meganexus:activate_skin'):
            from resources.lib import skin_activation
            xbmcgui.Window(10000).clearProperty(skin_activation.DECLINED)  # asked for it explicitly
            if skin_activation.switch()=='failed':skin_activation.report_failure()
            if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):return
            if command.endswith(':wizard'):
                from .onboarding import run
                command=run()
                continue
            xbmc.executebuiltin('ActivateWindow(Home)')
        else:xbmc.executebuiltin(command)
        return

def rpc(method,params=None):
    result=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params or {}})))
    if result.get('error'):raise RuntimeError('Kodi could not complete '+method)
    return result.get('result')

INSTALL_DIALOGS=' | '.join('Window.IsVisible(%s)'%name for name in ('yesnodialog','progressdialog','numericinput','virtualkeyboard'))
INSTALL_START=3.0   # 9.0.8: s Kodi has to put up its question (or the master lock's) after InstallAddon
INSTALL_QUIET=1.0   # ... and s without its dialogs that end the install (Cancel, or it failed)


def _install(aid):
    """9.0.8: Kodi's InstallAddon - its question, then its progress - posted, and waited for here
    with Python let go. executebuiltin(..., True) kept Python's lock (one for every add-on) for
    the whole install, which Kodi runs on its main thread (AddonInstaller.cpp InstallModal ->
    CProgressJob::DoModal); a service Kodi stops meanwhile (an add-on updated from its
    repository) needs that lock, and Kodi stood still for good. The wait ends with the add-on
    there, or once Kodi's dialogs have been gone INSTALL_QUIET s (Cancel: no 60 s poll as
    before 7.0), or none came in INSTALL_START s (not in any repository)."""
    xbmc.executebuiltin('InstallAddon(%s)'%aid)
    monitor=xbmc.Monitor();begin=time.monotonic();seen=False;quiet=None
    while not monitor.waitForAbort(.1):
        if xbmc.getCondVisibility(INSTALL_DIALOGS):
            seen=True;quiet=None;continue
        if xbmc.getCondVisibility('System.HasAddon(%s)'%aid):return
        now=time.monotonic()
        if not seen:
            if now-begin>=INSTALL_START:return
            continue
        quiet=quiet or now
        if now-quiet>=INSTALL_QUIET:return


def ensure_addon(aid):
    from resources.lib import meganexus_uninstall
    before=meganexus_uninstall.inventory()
    if not xbmc.getCondVisibility('System.HasAddon(%s)'%aid):
        # Kodi's InstallAddon is already a cancellable modal operation. Waiting
        # for that operation distinguishes Cancel from an ongoing installation;
        # polling HasAddon afterwards used to lock Nuvio for another 60 seconds.
        _install(aid)
        if not xbmc.getCondVisibility('System.HasAddon(%s)'%aid):return False
    rpc('Addons.SetAddonEnabled',{'addonid':aid,'enabled':True})
    meganexus_uninstall.record_install(aid,before,meganexus_uninstall.inventory())
    return True

def weather():
    if ensure_addon('weather.openmeteo'):
        rpc('Settings.SetSettingValue',{'setting':'weather.addon','value':'weather.openmeteo'})
        from resources.lib.kodi_keep import keep
        keep()
        xbmcaddon.Addon('weather.openmeteo').openSettings()
        xbmc.executebuiltin('Weather.Refresh')

def screensaver():
    rpc('Settings.SetSettingValue',{'setting':'screensaver.mode','value':'screensaver.meganexus'})
    from resources.lib.kodi_keep import keep
    keep()
    xbmcgui.Dialog().ok('MegaNexus screensaver','Enabled. Start time, background and widgets: HUB Settings > Home & appearance > Screensaver.')
