# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus Sports screen (6.0.35, GitHub issue #8).

Only sports add-ons (resources.lib.sports). Rows are their catalogs (live and
today first). Resting on an event loads its streams into the glass box under
"Sports" and plays the first one in the small video; another stream can be
chosen in the box; OK on the event (or a stream) opens Kodi's own full-screen
player for it and Back returns here. Playback is a preview to the playback service, so sports never
reach Continue Watching or Trakt/Simkl. Header: Home (top of Sports),
Settings, HUB (leave).

Only LIVE events look for streams, after the cursor rests DWELL seconds;
upcoming events never do. 7.0.48, as IPTV: OK (or Info) starts the event in the
small video; OK again, once its picture plays there, opens Kodi's own full-screen
player - the same playback, no new start (the player has the Sport buttons); Back
there comes down to the small video. (The Big player setting and OK before the
picture played went to Kodi's player too early: this screen stepped aside, Kodi
did not open its player yet, the HUB showed and Sport came back.) Hold OK opens
the stream choice (7.0.29 - the box of streams, left only with Back). A stream
that cuts out reconnects. Back / Esc never leave Sports - only the HUB button does.

7.0.24: every start and reconnect first asks the source itself (probe(), in
the background); Kodi gets the stream only once it answers, so an unavailable
source never brings Kodi's "Playback failed" window or its busy spinner - the
status stays inside the video, and after the retries the next stream is
tried.
"""
import queue
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qsl
from urllib.request import Request, urlopen
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import art_cache, sports
from resources.lib.settings_snapshot import cached_addon
from resources.lib.plain_text import without_emoji
from resources.lib.theme import folder as theme_folder
from .dialog import Dialog, BACK, backend_back
from .top_row import TopRow
from .home_trailers import PreviewPlayer
from . import listitems
from .player_osd import player_buttons, switched

ROW_BASE = 1000
MAX_ROWS = 20
STREAM_LIST = 700
SOURCE_LIST = 961            # 7.0.48: the picker over Kodi's player: the event's streams (Source)
STRIP = 980                  # ... the live events as posters (Channels)
OSD_COMMAND = 'meganexus.sport.osd'   # the player's Sport buttons (review/make_iptv_osd.py)
SWITCH_GRACE = 12.0          # seconds another stream may take to start in Kodi's player
PICKER_SECONDS = 15.0        # the picker over Kodi's player goes this long after the last key
PICKER_BACK = (9, 10, 92, 216, 247, 257, 275, 61448, 61467)
PROBE_SECONDS = 6            # how long a source may take to answer before a start
DWELL = 5.0                  # seconds on a LIVE event before its streams load and play
AUTOPLAY_SETTING = 'meganexus_sport_autoplay'
RECONNECT_DELAYS = (2, 3, 5, 8, 10, 10)    # seconds between reconnect attempts
HEALTHY_SECONDS = 30                       # playing this long resets the attempts
LOAD_WORKERS = 4
LOAD_SECONDS = 15
POSTERS_PER_ROW = 8
ENTRY_SECONDS = 8          # 9.0.0: the way in waits this long for the add-ons' fresh events
ENTRY_POSTERS = 4.0        # ... and this long for the first rows' posters
FIRST_POSTERS = 16         # the posters of the first two rows
CONTEXT = (117, 101, 1009)                 # hold OK / menu: the stream choice (7.0.29)
INFO = (11,)                               # Info: Kodi's own full-screen player
# 7.0.29: what the keys do, at the bottom of the screen.
HINTS = {'rows': 'OK  Play, again for full screen     Hold OK  Choose a stream     Back  HUB button',
         'streams': 'Up / Down  Choose     OK  Play this stream     Back  Return'}


def autoplay_enabled():
    return cached_addon().getSetting(AUTOPLAY_SETTING) != 'false'


def probe(url, timeout=PROBE_SECONDS):
    """Does the source answer? (7.0.24) The playlist or the first bytes, with
    the stream's own headers. Only then is the stream handed to Kodi, which
    otherwise opens its modal "Playback failed" window for every failed try."""
    base, _, header_text = str(url or '').partition('|')
    if not base.startswith(('http://', 'https://')):
        return True        # local / plugin paths: Kodi knows best
    headers = {'User-Agent': xbmc.getUserAgent()}
    headers.update(dict(parse_qsl(header_text)))
    try:
        with urlopen(Request(base, headers=headers), timeout=timeout) as response:
            if getattr(response, 'status', 200) >= 400:
                return False
            kind = str((getattr(response, 'headers', None) or {}).get('Content-Type') or '').lower()
            data = response.read(65536)
    except Exception:
        return False
    if '.m3u8' in base.lower().split('?', 1)[0] or data.lstrip()[:7] == b'#EXTM3U':
        return b'#EXTM3U' in data[:2048]
    # 8.1.3: a web page is not a stream. Add-ons list notices as streams ("We Have
    # Updated..." -> https://sports.highfly.to/configure); the page answered, so it went
    # to Kodi and the preview ended in "Playback failed".
    if 'text/html' in kind or data.lstrip()[:15].lower().startswith((b'<!doctype html', b'<html')):
        return False
    # 9.0.4: nor is a status answer. The same add-ons list a notice ("If Streams Are...")
    # whose address is the server's health check - JSON, it answered, so a channel chosen
    # in Kodi's player whose real stream was slow played that and Sport closed.
    if 'json' in kind or (data.lstrip()[:1] in (b'{', b'[') and not kind.startswith(('video/', 'audio/'))):
        return False
    return bool(data)


def _hls_item(item, url):
    """Live HLS through inputstream.adaptive when installed: it rides out
    stalls instead of failing at the first gap. Returns the URL to play."""
    base, _, headers = url.partition('|')
    if '.m3u8' not in base.lower() or not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
        return url
    item.setProperty('inputstream', 'inputstream.adaptive')
    try:
        major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except ValueError:
        major = 21
    if major < 21:
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    if headers:
        item.setProperty('inputstream.adaptive.manifest_headers', headers)
        item.setProperty('inputstream.adaptive.stream_headers', headers)
    item.setMimeType('application/vnd.apple.mpegurl')
    item.setContentLookup(False)
    return base


class SportsPlayer(PreviewPlayer):
    """Ownership by the ListItem token: live HLS streams report another file
    path than the URL that was played. ``dropped`` = playback ended or failed
    without being asked to (buffer underrun, stream cut) - reconnect."""
    def __init__(self):
        super().__init__()
        self.dropped = False

    def owns(self):
        try:
            if not self.token or not self.isPlayingVideo():
                return False
            return self.getPlayingItem().getProperty('meganexus.preview') == self.token
        except Exception:
            return False

    def onAVStarted(self):
        super().onAVStarted()

    # Kodi tells every Python player about every stop: another video
    # stopping for this stream is not this stream dropping (7.0.29).
    def onPlayBackStopped(self):
        if self.started_own and not self.cancelled:
            self.dropped = True
        self._ended()

    def onPlayBackEnded(self):
        if self.started_own and not self.cancelled:
            self.dropped = True
        self._ended()

    def onPlayBackError(self):
        if self.started_own or self.requested:
            self.failed = True
            if not self.cancelled:
                self.dropped = True
        self._ended(True)


class SportPicker(xbmcgui.WindowXMLDialog):
    """7.0.48: over Kodi's player while a Sport stream plays: the live events as posters
    (Up / Down the sport) or the event's streams in a box; the choice plays on in the player."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.mode = kwargs['mode']
        self.groups = kwargs.get('groups') or []
        self.group = kwargs.get('group', 0)
        self.rows = list(kwargs.get('rows') or [])
        self.selected = kwargs.get('selected', 0)
        self.channel = kwargs.get('channel') or ''
        # 9.0.6: the YouTube app's Up next gives its pictures as they are (never MegaNexus' image memory)
        self.picture = kwargs.get('picture') or art_cache.card
        self.chosen = None
        self._timer = None

    def onInit(self):
        self.setProperty('meganexus.picker.mode', self.mode)
        self.setProperty('meganexus.picker.channel', self.channel)
        self._fill()
        self._touch()

    def _fill(self):
        if self.mode == 'strip':
            title, self.rows = self.groups[self.group]
            items = []
            for _, event in self.rows:
                li = listitems.item(label=without_emoji(event['title']))
                li.setArt({'thumb': self.picture(event.get('art'))})
                li.setProperty('live', '1' if event.get('live', True) else '')
                items.append(li)
            control = self.getControl(STRIP)
            control.reset()
            control.addItems(items)
            control.selectItem(next((i for i, (_, event) in enumerate(self.rows) if event['id'] == self.selected), 0))
            self.setProperty('meganexus.picker.title', title)
            # 9.0.6: the strip serves the YouTube app too - one group there, nothing to switch
            self.setProperty('meganexus.picker.hint', '     Up / Down  sport' if len(self.groups) > 1 else '')
            self.setFocusId(STRIP)
        else:
            items = []
            for i, stream in enumerate(self.rows):
                li = listitems.item(label=stream['label'], label2=stream.get('detail') or '')
                li.setProperty('playing', 'Playing' if i == self.selected else '')
                items.append(li)
            control = self.getControl(SOURCE_LIST)
            control.reset()
            control.addItems(items)
            self.setProperty('meganexus.picker.status', '' if items else 'No streams for this event right now.')
            if items:
                control.selectItem(max(0, self.selected))
                self.setFocusId(SOURCE_LIST)

    def _touch(self):
        if self._timer:
            self._timer.cancel()
        self._timer = threading.Timer(PICKER_SECONDS, self._idle)
        self._timer.daemon = True
        self._timer.start()

    def _idle(self):
        """PICKER_SECONDS without a key: it goes (on the timer's thread). 9.0.8: never while Kodi
        replaces MegaNexus Hub - the close waits for Kodi's main thread holding Python's lock, and that
        main thread waits for the Hub's service (dialog.backend_back)."""
        if backend_back(xbmc.Monitor()):
            self.close()

    def onAction(self, action):
        aid = action.getId()
        self._touch()
        if aid in PICKER_BACK:
            self.close()
        elif self.mode == 'strip' and aid in (3, 4) and len(self.groups) > 1:
            self.group = (self.group + (-1 if aid == 3 else 1)) % len(self.groups)
            self.selected = None
            self._fill()

    def onClick(self, cid):
        pos = self.getControl(cid).getSelectedPosition()
        if 0 <= pos < len(self.rows):
            self.chosen = pos
        self.close()

    def close(self):
        if self._timer:
            self._timer.cancel()
        super().close()


class SportsWindow(TopRow, Dialog):
    TOP_ROW = (101, 107, 108)      # 8.1.3: Home, Settings, HUB - the row that keeps out of the way
    # Defaults of the 7.0.24 start / retry state (set again in __init__).
    retry_at = 0.0
    failed_at = 0.0
    pending = ''

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.rows = list(kwargs.get('rows') or [])       # [(title, provider, catalog, items)]
        self.outcome = ''
        self.player = SportsPlayer()
        self.streams = []
        self.selection = None          # (row, pos) under the cursor
        self.changed = time.monotonic()
        self.stream_key = None         # event whose streams are shown/loading
        self.stream_job = None
        self.results = queue.Queue()
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='MegaNexusSportStreams')
        self.probes = ThreadPoolExecutor(max_workers=1, thread_name_prefix='MegaNexusSportProbe')
        self.playing_index = -1
        self.after_ready = ''          # 'play': OK asked for it (it plays with autoplay off too)
        self.retry_at = 0.0            # the next try of a stream that did not answer / cut out
        self.attempts = 0
        self.played = False
        self.started_at = 0.0
        self.use_ia = True
        self.pending = ''              # the start waiting for its source to answer
        self.tried = set()             # streams of this event already given up on
        self.failed_at = 0.0
        self._painted = False
        self.loading = bool(kwargs.get('loading'))

    # ---- painting ------------------------------------------------------
    def onInit(self):
        if not self._painted:
            self._paint()
            self._painted = True
        self.restore_focus()
        self.row_focus()

    def onFocus(self, control_id):
        self.row_focus(control_id)

    def _paint(self):
        shown = [r for r in self.rows if r[3]][:MAX_ROWS]
        catalogs = len(self.rows)
        self.rows = shown
        # 8.1.3: the heading is the collection under the cursor, in the add-on's own words
        # ("Live Now", "Today", whatever it calls them) - no row titles under the box.
        self.setProperty('meganexus.sport.heading', without_emoji(shown[0][0]) if shown else '')
        for i in range(MAX_ROWS):
            self.setProperty('meganexus.sport.row.%d' % i, without_emoji(shown[i][0]) if i < len(shown) else '')
            control = self.getControl(ROW_BASE + i)
            control.reset()
            if i < len(shown):
                control.addItems([self._item(item) for item in shown[i][3]])
        # Explicit vertical navigation (rows are hidden when empty).
        for i in range(len(shown)):
            control = self.getControl(ROW_BASE + i)
            # 8.1.3: no box of streams beside the video any more (hold OK opens the source
            # list) - Up from the first row goes to the top row
            control.controlUp(self.getControl(ROW_BASE + i - 1) if i else self.getControl(101))
            control.controlDown(self.getControl(ROW_BASE + min(i + 1, len(shown) - 1)))
        if not shown and catalogs:
            # 7.0.12: sport catalogs exist (a sports add-on or e.g. AIOMetadata's) but list nothing now.
            self.setProperty('meganexus.sport.empty', 'No live or upcoming events right now in your %d sport catalogs. '
                                                  'They refresh every few minutes - open Sport again later.' % catalogs)
            self.setFocusId(101)
        elif not shown and self.loading:
            self.setProperty('meganexus.sport.empty','')   # 7.0.42: no loading words
            self.setFocusId(101)
        elif not shown:
            self.setProperty('meganexus.sport.empty', 'No sports add-on is installed. Add one in HUB Settings > Add-ons '
                                                  '(for example a manifest whose catalogs are of type "sport"). '
                                                  'Sports add-ons appear only here, never on the movie and series Home.')
            self.setFocusId(101)
        else:
            self.setProperty('meganexus.sport.empty', '')
            self.setFocusId(ROW_BASE)

    @staticmethod
    def _item(item):
        li = listitems.item(label=without_emoji(item['title']))
        li.setArt({'thumb': art_cache.card(item.get('art'))})
        li.setProperty('live', '1' if item.get('live') else '')
        return li

    def _selected(self):
        cid = self.getFocusId()
        index = cid - ROW_BASE
        if not 0 <= index < len(self.rows):
            return None
        pos = self.getControl(cid).getSelectedPosition()
        items = self.rows[index][3]
        return (index, pos) if 0 <= pos < len(items) else None

    def _event(self, selection):
        """The event under a (row, pos) - None when the rows changed meanwhile (7.0.29:
        a refresh of the catalogs left an old selection behind and Sport closed)."""
        if not selection:
            return None
        index, pos = selection
        if not 0 <= index < len(self.rows) or not 0 <= pos < len(self.rows[index][3]):
            return None
        return self.rows[index][3][pos]

    def _describe(self, selection):
        event = self._event(selection)
        if event is None:
            return
        self.setProperty('meganexus.sport.title', without_emoji(event['title']))
        self.setProperty('meganexus.sport.heading', without_emoji(self.rows[selection[0]][0]))
        self.setProperty('meganexus.sport.info', event.get('info') or '')
        # 9.0.4: under the section's name, the event and when it starts in Kodi's own time
        # (a start in UTC is turned into the box's time; one without a zone is shown as it is)
        try:
            from resources.lib.sport_time import kickoff
            when = kickoff(event.get('info'), live=bool(event.get('live')))
        except Exception:
            when = event.get('info') or ''
        self.setProperty('meganexus.sport.kickoff', when)
        self.setProperty('meganexus.sport.bg', art_cache.url(event.get('background') or event.get('art') or ''))

    # ---- streams -------------------------------------------------------
    def _show_streams(self, rows, status=''):
        control = self.getControl(STREAM_LIST)
        control.reset()
        items = []
        for i, stream in enumerate(rows):
            li = listitems.item(label=stream['label'], label2=stream.get('detail') or '')
            li.setProperty('playing', 'Playing' if i == self.playing_index else '')
            items.append(li)
        control.addItems(items)
        self.setProperty('meganexus.sport.streams_status', status if not rows else '')

    def _request_streams(self, key, event, after=''):
        self.stream_key = key
        self.streams = []
        self.playing_index = -1
        self.after_ready = after
        self._show_streams([], '')

        def work():
            try:
                found = sports.streams(event)
            except Exception:
                found = []
            self.results.put((key, found))
        self.stream_job = self.pool.submit(work)

    def _play(self, index, after='', keep_view=False, reconnect=False):
        """Start stream index - once its source answers (probe in the background)."""
        if not 0 <= index < len(self.streams):
            return
        self._stop_preview(keep_view=keep_view)
        if not reconnect:
            self.attempts = 0
            self.use_ia = True
            self.tried = set()
            self.played = False          # 9.0.0: this stream has shown a picture (reconnects keep it)
        self.playing_index = index
        self.after_ready = after
        self.retry_at = 0.0
        self.started_at = 0.0
        self.setProperty('meganexus.preview.loading', '1')
        if not reconnect:
            self.setProperty('meganexus.sport.video_status', 'Connecting…')
        token = uuid.uuid4().hex
        self.pending = token
        url = self.streams[index]['url']
        results = self.results
        self.probes.submit(lambda: results.put(('probe', token, index, probe(url))))
        self._show_streams(self.streams)

    def _start(self, index, windowed=True):
        """The source answered: hand the stream to Kodi (7.0.48: windowed=False in Kodi's player)."""
        stream = self.streams[index]
        token = uuid.uuid4().hex
        self.player = SportsPlayer()
        self.player.token = token
        item = listitems.item(label=self.getProperty('meganexus.sport.title') or 'Sports')
        item.setProperty('meganexus.preview', token)
        item.setProperty('IsPlayable', 'true')
        url = _hls_item(item, stream['url']) if self.use_ia else stream['url']
        home = xbmcgui.Window(10000)
        # A preview to the playback service: no progress, no tracking - and
        # no Kodi busy spinner over Sports (the status shows in the video).
        home.setProperty('meganexus.preview.active', token)
        home.setProperty('meganexus.preview.silent', token)
        self.player.path = url
        from resources.lib import refresh_guard
        refresh_guard.suspend('sports')   # no TV mode switch (issue #4)
        self.player.requested = True
        self.player.play(url, item, windowed=windowed)

    def _stop_preview(self, keep_view=False):
        """keep_view: another stream follows at once (no refresh-rate switching between)."""
        # 7.0.50: the Sport screen holds the refresh rate while it is open (refresh_guard.hold)
        self.player.cancel()
        self.player.stop_owned()
        self.player._ended()
        self.pending = ''
        xbmcgui.Window(10000).clearProperty('meganexus.preview.silent')
        self.setProperty('meganexus.preview', '')
        self.setProperty('meganexus.preview.loading', '')
        self.setProperty('meganexus.sport.video_status', '')
        self.after_ready = ''
        self.retry_at = 0.0

    def _retry(self, now, reason):
        """The source did not answer or the stream cut out: try again quietly,
        a few times with growing pauses, then the next stream of the event.
        9.0.0: the pauses are for a stream that played and cut out. One that never
        started goes to the next stream at once - a dead source held the event up to
        70 s (six tries, 38 s of pauses and a 6 s wait each)."""
        self.player.token = ''
        self.setProperty('meganexus.preview', '')
        if self.attempts >= len(RECONNECT_DELAYS) or not self.played:
            self.tried.add(self.playing_index)
            following = [i for i in range(len(self.streams)) if i not in self.tried]
            if following:
                index = following[0]
                self.attempts = 0
                self.played = False          # another stream: its own start
                self.setProperty('meganexus.sport.video_status', 'Stream unavailable · trying stream %d' % (index + 1))
                self._play(index, after=self.after_ready, keep_view=True, reconnect=True)
            else:
                self.playing_index = -1
                self.setProperty('meganexus.preview.loading', '')
                self.setProperty('meganexus.sport.video_status', 'No stream answers right now · choose one in the list')
                self._show_streams(self.streams)
            return
        delay = RECONNECT_DELAYS[self.attempts]
        self.retry_at = now + delay
        self.setProperty('meganexus.preview.loading', '1')
        self.setProperty('meganexus.sport.video_status', '%s · trying again (%d/%d)' % (reason, self.attempts + 1, len(RECONNECT_DELAYS)))

    def _close_failed_dialog(self, now):
        """A stream that answered the probe and still failed to open: Kodi's
        modal "Playback failed" window is closed (only right after our own try)."""
        if not self.failed_at or now - self.failed_at > 10:
            self.failed_at = 0.0
            return
        if (xbmc.getCondVisibility('Window.IsActive(okdialog)') and
                xbmc.getInfoLabel('Control.GetLabel(1)') == xbmc.getLocalizedString(16026)):
            xbmc.executebuiltin('Dialog.Close(okdialog)')
            self.failed_at = 0.0

    # ---- loop ------------------------------------------------------------
    def tick(self):
        self.row_tick()
        now = time.monotonic()
        selection = self._selected()
        if selection is not None and selection != self.selection:
            self.selection = selection
            self.changed = now
            event = self._event(selection)
            self._describe(selection)
            # The box shows only the streams of the event under the cursor:
            # another event's stream names stayed and overlapped the status.
            if (selection, event['id']) == self.stream_key:
                self._show_streams(self.streams, '')
            elif not event.get('live'):
                self._show_streams([], 'Not live yet. Streams appear when the event starts.')
            else:
                self._show_streams([], 'Live · streams load in a moment…')
        if self.selection is not None and self.getFocusId() != STREAM_LIST:
            event = self._event(self.selection)
            if event is None:
                self.selection = None
                return
            key = (self.selection, event['id'])
            # Only live events, and only after the cursor rested DWELL seconds.
            if event.get('live') and key != self.stream_key and now - self.changed >= DWELL:
                self._stop_preview()
                self._request_streams(key, event, '')
        while not self.results.empty():
            result = self.results.get_nowait()
            if result[0] == 'catalogs':
                focus=self.getFocusId()
                try:spot=self.getControl(focus).getSelectedPosition() if ROW_BASE<=focus<ROW_BASE+MAX_ROWS else -1
                except Exception:spot=-1
                self.loading=False;self.rows=result[1];self._paint()
                if focus in (101,107,108):self.setFocusId(focus)
                elif spot>=0 and focus-ROW_BASE<len(self.rows):
                    # 7.0.29: the fresh pages land under the cursor without moving it
                    self.setFocusId(focus)
                    try:self.getControl(focus).selectItem(min(spot,len(self.rows[focus-ROW_BASE][3])-1))
                    except Exception:pass
                continue
            if result[0] == 'probe':
                _, token, index, answered = result
                if token != self.pending or index != self.playing_index:
                    continue
                self.pending = ''
                if answered:
                    self._start(index)
                else:
                    self._retry(now, 'Source unavailable')   # never started: the next stream
                continue
            key, found = result
            if key != self.stream_key:
                continue
            self.streams = found
            self._show_streams(found, '' if found else 'No streams for this event right now.')
            if found and (autoplay_enabled() or self.after_ready):
                self._play(0, after=self.after_ready)
        self._hint()
        self._close_failed_dialog(now)
        if self.retry_at and now >= self.retry_at:
            self.retry_at = 0.0
            self.attempts += 1
            self._play(self.playing_index, after=self.after_ready, keep_view=True, reconnect=True)
            return
        if not self.player.token:
            return
        if self.player.dropped or (self.player.failed and not self.player.owns()):
            if self.player.failed:
                self.failed_at = now
                if self.use_ia and not self.started_at:
                    self.use_ia = False      # this stream may not like inputstream.adaptive
                    self._play(self.playing_index, after=self.after_ready, keep_view=True, reconnect=True)
                    return                   # 9.0.0: once more without it, at once
            self._retry(now, 'Reconnecting')
        elif self.player.owns() and (self.player.ready or self.player.getTime() > .15):
            if not self.started_at:
                self.started_at = now
                self.played = True
            elif now - self.started_at > HEALTHY_SECONDS:
                self.attempts = 0
            self.setProperty('meganexus.preview', '1')
            self.setProperty('meganexus.preview.loading', '')
            self.setProperty('meganexus.sport.video_status', '')
            self.after_ready = ''

    # ---- views -------------------------------------------------------------
    def _shows(self):
        """The stream's picture plays in the small video (only then Kodi's player opens)."""
        try:
            return self.player.owns() and (self.player.ready or self.player.getTime() > .15)
        except RuntimeError:
            return False

    def _starting(self):
        return bool(self.pending or (self.player.token and not self.player.dropped))

    def _native(self):
        """Kodi's own full-screen player for the stream that plays (OK, Info or
        the Big player) - the same playback, no new start. This window steps aside
        - Kodi's player would open under it - and comes back when the player is
        left, on the event that plays."""
        if not self._shows():
            return
        from .home_trailers import view_mode
        view_mode('normal')                # the whole picture in Kodi's own player
        monitor = xbmc.Monitor()
        home = xbmcgui.Window(10000)
        self._child_active = True
        self._restore_focus = self.getFocusId()
        try:
            xbmcgui.WindowXMLDialog.close(self)
            # 7.0.48: the player's Sport buttons (review/make_iptv_osd.py) act in the player:
            # Channels / Source over it (SportPicker), Previous / Next the event before / after
            home.clearProperty(OSD_COMMAND)
            home.setProperty('meganexus.sport.open', '1')
            home.setProperty('meganexus.sport.now.title', self.getProperty('meganexus.sport.title'))
            home.setProperty('meganexus.sport.now.info', self.getProperty('meganexus.sport.info'))
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            seen, start, switching, osd, before = False, time.monotonic(), 0.0, None, ''
            while not monitor.abortRequested():
                osd = player_buttons(osd)
                command = home.getProperty(OSD_COMMAND)
                if command:
                    home.clearProperty(OSD_COMMAND)
                    before = xbmc.getInfoLabel('Player.FilenameAndPath')
                    if self._in_player(command):
                        switching = time.monotonic() + SWITCH_GRACE
                        home.setProperty('meganexus.sport.now.title', self.getProperty('meganexus.sport.title'))
                        home.setProperty('meganexus.sport.now.info', self.getProperty('meganexus.sport.info'))
                full = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                if time.monotonic() < switching and switched(before):
                    switching = 0.0
                if time.monotonic() < switching:
                    # another stream starts: Kodi may drop its full screen for a moment
                    if not full and xbmc.Player().isPlayingVideo():
                        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                    if monitor.waitForAbort(.1):
                        break
                    continue
                seen = seen or full
                if (seen and not full) or (not seen and time.monotonic() - start > 5):
                    break
                if monitor.waitForAbort(.1):
                    break
        finally:
            home.clearProperty('meganexus.sport.open')
            home.clearProperty(OSD_COMMAND)
            if not self.player.owns():
                # Stopped in Kodi's player on purpose: no reconnect.
                self.player.cancelled = True
                self.player.dropped = False
                self.player.token = ''
                self.setProperty('meganexus.preview', '')
                self.setProperty('meganexus.preview.loading', '')
            if not self._dialog_closed and not monitor.abortRequested():
                self.show_ready()
                self._on_playing_event()
            self._child_active = False

    def _on_playing_event(self):
        """Back from Kodi's player: the cursor on the event that plays (another one may
        have been chosen there) - the cursor resting elsewhere would start that one."""
        if self.selection is None or not self.player.owns():
            return
        index, pos = self.selection
        try:
            self.getControl(ROW_BASE + index).selectItem(pos)
            if self.getFocusId() != STREAM_LIST:
                self.setFocusId(ROW_BASE + index)
        except Exception:
            pass

    # ---- the live events (the player's Channels / Previous / Next) --------
    def _live_channels(self):
        seen, result = set(), []
        for index, row in enumerate(self.rows):
            for pos, item in enumerate(row[3]):
                if item.get('live') and item['id'] not in seen:
                    seen.add(item['id'])
                    result.append(((index, pos), item, row[0]))
        return result

    def _current_event(self):
        return self._event(self.selection) or {}

    def _strip_groups(self):
        live = self._live_channels()
        groups = [('All live', [(selection, item) for selection, item, _ in live])]
        for index, row in enumerate(self.rows):
            events = [((index, pos), item) for pos, item in enumerate(row[3]) if item.get('live')]
            if events:
                groups.append((without_emoji(row[0]), events))
        return groups

    # ---- in Kodi's player (7.0.48) --------------------------------------------
    def _in_player(self, command):
        """The player's Sport buttons: True once another stream starts there."""
        path = xbmcaddon.Addon('script.meganexus').getAddonInfo('path')
        if command == 'source':
            picker = SportPicker('meganexus_sports_picker.xml', path, theme_folder(), '1080i', mode='box',
                                 rows=self.streams, selected=self.playing_index, channel=self.getProperty('meganexus.sport.title'))
            picker.doModal()
            chosen = picker.chosen
            del picker
            if chosen is None or chosen == self.playing_index or not probe(self.streams[chosen]['url']):
                return False
            self.playing_index = chosen
            self._start(chosen, windowed=False)
            return True
        if command == 'channels':
            groups = self._strip_groups()
            picker = SportPicker('meganexus_sports_picker.xml', path, theme_folder(), '1080i', mode='strip',
                                 groups=groups, selected=self._current_event().get('id'))
            picker.doModal()
            chosen, rows = picker.chosen, picker.rows
            del picker
            if chosen is None:
                return False
            selection, event = rows[chosen]
        else:
            live = self._live_channels()
            if not live:
                return False
            current = self._current_event().get('id')
            index = next((i for i, (_, item, _) in enumerate(live) if item['id'] == current), -1)
            selection, event, _ = live[(index + (-1 if command == 'previous' else 1)) % len(live)]
        if event['id'] == self._current_event().get('id'):
            return False
        return self._in_player_event(selection, event)

    def _in_player_event(self, selection, event):
        """Another live event in Kodi's player: its first stream whose source answers."""
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        try:
            try:
                streams = sports.streams(event)
            except Exception:
                streams = []
            index = next((i for i, stream in enumerate(streams) if probe(stream['url'])), None)
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        if index is None:
            xbmcgui.Dialog().notification('Sports', 'No working stream for this event right now.', time=3000)
            return False
        self.selection = selection
        self._describe(selection)
        self.stream_key = (selection, event['id'])
        self.streams = streams
        self.playing_index = index
        self._start(index, windowed=False)
        return True

    # ---- input -----------------------------------------------------------
    def _open_event(self):
        selection = self._selected()
        if selection is None:
            return
        event = self._event(selection)
        if not event.get('live'):
            xbmcgui.Dialog().notification('Sports', 'Not live yet. Streams appear when the event starts.', time=3000)
            return
        key = (selection, event['id'])
        if key == self.stream_key and self._shows():
            self._native()                 # OK again: its picture plays - Kodi's player
        elif key == self.stream_key and (self._starting() or not self.streams):
            return                         # on its way to the small video
        elif key == self.stream_key:
            self._play(max(0, self.playing_index))
        else:
            self.selection = selection
            self._stop_preview()
            self._request_streams(key, event, 'play')   # first OK: the small video (autoplay off too)

    def onClick(self, cid):
        if cid == 108:
            self.outcome = 'hub'      # the only way out of Sports
            self.close()
        elif cid == 101:
            self._stop_preview()
            if self.rows:
                self.getControl(ROW_BASE).selectItem(0)
                self.setFocusId(ROW_BASE)
        elif cid == 107:
            self._stop_preview()
            from .settings import run
            self.over(run)   # Sports stays visible behind the glass settings
        elif cid == STREAM_LIST:
            index = self.getControl(STREAM_LIST).getSelectedPosition()
            if index == self.playing_index and self._shows():
                self._native()         # OK on the stream that plays: Kodi's player
            elif index == self.playing_index and self._starting():
                pass                   # on its way to the small video
            else:
                self._play(index)
        elif ROW_BASE <= cid < ROW_BASE + len(self.rows):
            self._open_event()

    def _hint(self):
        key = 'streams' if self.getFocusId() == STREAM_LIST else 'rows'
        if self.getProperty('meganexus.sport.hint') != HINTS[key]:
            self.setProperty('meganexus.sport.hint', HINTS[key])

    def _stream_box(self):
        """Hold OK on an event (8.1.3): a small menu, no loading screen over Sport. Live:
        "Choose stream manually" - the same source list as a film's or a series', with
        the streams already found for the video (else found behind a small pill). Not
        live yet: a reminder for when it starts."""
        cid = self.getFocusId()
        if cid == STREAM_LIST or not ROW_BASE <= cid < ROW_BASE + len(self.rows):
            return
        selection = self._selected()
        if selection is None:
            return
        event = self._event(selection)
        if event is None:
            return
        if not event.get('live'):
            self._remind(event)
            return
        from .details import context_choice
        if context_choice(options=[('streams', 'Choose stream manually')], heading=event.get('title') or 'Sport') != 'streams':
            return
        key = (selection, event['id'])
        if key != self.stream_key or not self.streams:
            from .play_jobs import job
            found = job(lambda: sports.streams(event), label='Finding streams', quiet=True)
            self.selection = selection
            self.stream_key, self.streams, self.playing_index = key, list(found or []), -1
        if not self.streams:
            xbmcgui.Dialog().notification('Sport', 'No streams for this event right now.', time=3000)
            return
        from .play_jobs import select_source
        choice = select_source(self.streams, quiet=True)
        if 0 <= choice < len(self.streams):
            self._play(choice)
        self.setFocusId(cid)

    def _remind(self, event):
        """Not live yet: a reminder, or the one already set taken off again."""
        from resources.lib import sport_reminders
        from .details import context_choice
        on = sport_reminders.has(event)
        label = 'Remove reminder' if on else 'Remind me when it starts'
        if context_choice(options=[('remind', label)], heading=event.get('title') or 'Sport') != 'remind':
            return
        if on:
            sport_reminders.remove(event['id'])
            xbmcgui.Dialog().notification('Sport', 'Reminder removed', time=2500)
        else:
            sport_reminders.add(event)
            xbmcgui.Dialog().notification('Sport', 'You will be told when it starts', time=3000)

    def onAction(self, action):
        aid = action.getId()
        self.row_focus(key=True)
        if aid in BACK:
            # 7.0.29: a box of streams is left only with Back - to where it was opened.
            cid = self.getFocusId()
            if cid == STREAM_LIST:
                back = getattr(self, '_box_return', 0) or ROW_BASE
                try:
                    self.setFocusId(back)
                except Exception:
                    self.setFocusId(ROW_BASE)
                return
            # Back / Esc never leave Sports: the HUB button.
            self.setFocusId(108)
            return
        if aid in CONTEXT:
            self._stream_box()
            return
        if aid in INFO:
            # Info: Kodi's own full-screen player (as OK).
            cid = self.getFocusId()
            if cid == STREAM_LIST:
                self._native()
            elif ROW_BASE <= cid < ROW_BASE + len(self.rows):
                self._open_event()

    def close(self):
        self.cancelled=True
        self._stop_preview()
        self.pool.shutdown(wait=False)
        self.probes.shutdown(wait=False)
        super().close()


# ---- opening ---------------------------------------------------------------

def _load(window, monitor, seconds=LOAD_SECONDS, posters_wait=0.0):
    """Catalog pages (cached at once, missing/stale ones from the add-ons) and
    the first posters into the image RAM. Back skips. 9.0.0: ``posters_wait`` - seconds
    the first rows' posters are waited for (the way in prepares them behind its ring)."""
    from concurrent.futures import ThreadPoolExecutor as Pool
    pairs = sports.catalogs()
    rows, todo = [], []
    for provider, catalog in pairs:
        metas, fresh = sports.cached_page(provider, catalog)
        rows.append([str(catalog.get('name') or catalog['id']), provider, catalog, metas or []])
        todo.append(len(rows) - 1)   # 7.0.29: every entry asks every catalog again (events change)
    if todo:
        pool = Pool(max_workers=LOAD_WORKERS, thread_name_prefix='MegaNexusSportsLoad')
        futures = {pool.submit(sports.load_page, rows[i][1], rows[i][2]): i for i in todo}
        deadline = time.monotonic() + seconds
        try:
            while futures and not window.cancelled and time.monotonic() < deadline:
                for future in [f for f in futures if f.done()]:
                    index = futures.pop(future)
                    try:
                        fresh = future.result()
                        if fresh or not rows[index][3]:
                            rows[index][3] = fresh   # an empty answer keeps what is shown
                    except Exception:
                        pass
                window.setProperty('meganexus.ring', '%02d' % min(19, (len(pairs) - len(futures)) * 20 // max(1, len(pairs))))   # 7.0.10: ring, no text
                if monitor.waitForAbort(.05):
                    break
        finally:
            for future in futures:
                future.cancel()
            pool.shutdown(wait=False)
    result = []
    for title, provider, catalog, metas in rows:
        items = []
        for meta in metas:
            try:
                items.append(sports.card(provider, catalog, meta))
            except Exception:
                continue
        result.append((title, provider, catalog, items))
    from resources.lib import art_cache
    base = xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
    if art_cache.native() and not window.cancelled:
        # 8.1.0: the native cache fetches the posters ahead (Kodi keeps the ones it has)
        from .kodi_textures import kept, proxy_url
        wanted = []
        for url in sports.poster_urls([r[3] for r in result], POSTERS_PER_ROW):
            native = proxy_url('', url)
            if not kept([native]):
                art_cache.ahead(native)
                wanted.append(native)
        until = time.monotonic() + posters_wait
        first = wanted[:FIRST_POSTERS]
        while first and time.monotonic() < until and not window.cancelled:
            first = [url for url in first if not kept([url])]
            if monitor.waitForAbort(.1):
                break
    elif base.startswith('http://127.0.0.1:') and not art_cache.DIRECT and not window.cancelled:
        # 7.0.7: no poster screen. Posters Kodi keeps on its disk are skipped;
        # the others load into the image RAM while the screen is already open.
        from .kodi_textures import cached, proxy_url
        kodi_has = cached(base)
        urls = [url for url in sports.poster_urls([r[3] for r in result], POSTERS_PER_ROW) if proxy_url(base, url) not in kodi_has]
        if urls:
            if posters_wait:
                _warm(base, urls[:FIRST_POSTERS], wait=posters_wait)   # the first rows', behind the ring
                urls = urls[FIRST_POSTERS:]
            if urls:
                threading.Thread(target=_warm, args=(base, urls), name='MegaNexusSportPosters', daemon=True).start()
    return result


def settings_cache_invalidate():
    try:
        from resources.lib import settings_snapshot
        settings_snapshot.invalidate()
    except Exception:
        pass


def _cached_rows():
    """The Sport rows from cached pages only (no network)."""
    result = []
    for provider, catalog in sports.catalogs():
        metas, _ = sports.cached_page(provider, catalog)
        items = []
        for meta in metas or []:
            try:
                items.append(sports.card(provider, catalog, meta))
            except Exception:
                continue
        result.append((str(catalog.get('name') or catalog['id']), provider, catalog, items))
    return result


def _warm(base, urls, wait=None):
    """Sports posters go into the same image RAM as Home's posters. ``wait``: seconds at most
    this waits for them (the rest carry on by themselves)."""
    from urllib.parse import quote
    from urllib.request import Request, urlopen
    from concurrent.futures import ThreadPoolExecutor as Pool

    def head(url):
        try:
            with urlopen(Request(base + '/image?url=' + quote(url, safe=''), method='HEAD'), timeout=4) as response:
                response.read(0)
        except Exception:
            pass
    from concurrent.futures import wait as wait_for
    pool = Pool(max_workers=3, thread_name_prefix='MegaNexusSportPoster')
    try:
        futures = [pool.submit(head, url) for url in urls]
        if wait is not None:
            wait_for(futures, timeout=wait)
    finally:
        pool.shutdown(wait=wait is None)   # a short, bounded list: the thread ends with it


def open_sports():
    # 9.0.0: the way in as MegaNexus' own - its ring over the HUB while Sport is prepared:
    # the add-ons' fresh events (ENTRY_SECONDS at most) and the first rows' posters
    # (ENTRY_POSTERS), so Sport opens ready, never half empty. Posters are not kept beyond
    # what Kodi keeps anyway - the events change all the time.
    from .play_jobs import Loading, ROOT, job
    cover = Loading('meganexus_loading.xml', ROOT, theme_folder(), '1080i', hub=True, label='')
    cover.show()
    try:
        def prepare():
            sports.ensure_enabled()
            return _load(cover, xbmc.Monitor(), seconds=ENTRY_SECONDS, posters_wait=ENTRY_POSTERS)
        try:
            rows = job(prepare, None, label='', window=cover)
        except Exception:
            rows = None
        if not rows or not any(r[3] for r in rows):
            rows = _cached_rows()            # nothing fresh: what is kept on the device
        if cover.cancelled:
            return 'hub'
        win = SportsWindow('meganexus_sports.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i', rows=rows, loading=False)
    finally:
        cover.close()
    win.cancelled = False

    class Ticket:
        @property
        def cancelled(self):return win.cancelled
        def setProperty(self,*args):pass  # background jobs never paint the UI

    def load():
        # the sport add-ons' catalogs may have changed - their manifests, then the rows again
        try:
            if sports.refresh_manifests(lambda:win.cancelled):
                settings_cache_invalidate()
                fresh = _load(Ticket(), xbmc.Monitor())
                if fresh and not win.cancelled:win.results.put(('catalogs',fresh))
        except Exception:
            xbmc.log('[MegaNexus] Sport manifests not refreshed.',xbmc.LOGINFO)
    from resources.lib.refresh_guard import hold
    try:
        win.pool.submit(load)
        with hold('sports'):       # 7.0.50: no refresh-rate switching in Sport, small or full screen
            win.doModal()
        return win.outcome
    finally:
        win.close()
