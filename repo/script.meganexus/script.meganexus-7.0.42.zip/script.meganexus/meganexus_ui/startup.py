# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Cancellable first-page warm-up; bounded workers, no invisible infinite crawl."""
from concurrent.futures import ThreadPoolExecutor
import time
import xbmc
import xbmcgui
from resources.lib import browse_cache, collection_profile, collection_validation
from resources.lib.collections_home import matching_catalog
from resources.lib.meganexus import store
from .playback import Loading, ROOT
from resources.lib.theme import folder as theme_folder

MAX_WORKERS = 4
MAX_STARTUP_SECONDS = 40
MAX_POSTER_SECONDS = 30      # the day's new posters behind the ring, at most this long (7.0.36: was 60) ...
FULL_SETUP_SHARE = .5        # ... unless Kodi keeps fewer than half of them: then until 90 % (Back skips)
MAX_ART_SECONDS = 30         # 7.0.32: the day's new titles' TMDB / Fanart.tv pictures (no limit after a new Artwork choice)


def shown_groups():
    """Only what Home shows: hidden rows and hidden cards are not prepared."""
    return [dict(g, folders=[f for f in g.get('folders') or [] if not f.get('hidden')])
            for g in collection_profile.load() if not g.get('hidden')]


def jobs(groups=None):
    providers = store.list_providers()
    result, seen = [], set()
    shown = shown_groups() if groups is None else groups
    from resources.lib.sports import is_sports_source
    for _, source in collection_validation.sources(shown):
        if is_sports_source(source):
            continue   # 7.0.19: sport catalogs load in the Sport screen, not behind the opening screen
        match = matching_catalog(source, providers)
        if not match:
            continue
        provider, catalog = match
        extra = collection_validation.extra_for(source)
        key = browse_cache.catalog_key(provider, catalog, extra)
        if key not in seen:
            result.append((key, provider, catalog, extra))
            seen.add(key)
    return result


COLD_IMAGES = 600            # proxy RAM holding fewer images = filled after reboot/suspend


def art_cold():
    """Image proxy is on (RAM mode) and nearly empty, e.g. right after a reboot."""
    home = xbmcgui.Window(10000)
    base = home.getProperty('meganexus.art_cache.base')
    if not base.startswith('http://127.0.0.1:'):
        return ''
    try:
        images = int((home.getProperty('meganexus.art_cache.usage') or '0 · 0').split('·')[-1].split()[0])
    except (ValueError, IndexError):
        images = 0
    return base if images < COLD_IMAGES else ''


def ring_step(done, total):
    """precache/ring_00..ring_19 for the opening screen's progress."""
    return '%02d' % (min(19, done * 20 // total) if total else 0)


def _warm_catalogs(window, monitor, all_jobs, missing, report):
    pool = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix='MegaNexusWarm')
    pending, remaining = set(), iter(missing)
    deadline = time.monotonic() + MAX_STARTUP_SECONDS
    def submit():
        try:
            _, provider, catalog, extra = next(remaining)
        except StopIteration:
            return False
        pending.add(pool.submit(browse_cache.catalog, provider, catalog, extra, 5))
        return True
    try:
        for _ in range(min(MAX_WORKERS, len(missing))):
            submit()
        while pending and not window.cancelled and not monitor.abortRequested() and time.monotonic() < deadline:
            # Kodi delivers the window's onAction (Back = skip) only while the
            # script waits in Kodi (waitForAbort), never during a plain
            # concurrent.futures wait - Back did nothing here (6.0.35).
            if monitor.waitForAbort(.05):
                break
            done = [future for future in pending if future.done()]
            for future in done:
                pending.remove(future)
                try:
                    future.result()
                    report['loaded'] += 1
                except Exception:
                    report['failed'] += 1
                report['deferred'] -= 1
                submit()
            # 7.0.10: no text - the ring fills with the catalogs still to load.
            window.setProperty('meganexus.ring', ring_step(report['loaded'] + report['failed'], len(missing)))
    finally:
        for future in pending:
            future.cancel()
        pool.shutdown(wait=False)


def _start_ratings(proxy):
    """7.0.30: the MDBList ratings of the cards precache.plan() counted, in a few
    batch requests (at most 60 % of the day's MDBList requests). None when
    there is nothing to ask."""
    if not proxy:
        return None
    try:
        from resources.lib import mdblist, ratings_row
        if not (mdblist.configured() and ratings_row.any_enabled()):
            return None
    except Exception:
        return None
    from . import precache
    import threading
    titles = precache.titles()
    if not titles:
        return None
    def work():
        try:
            stored = mdblist.preload_ratings(titles)
            xbmc.log('[MegaNexus] ratings preload: %d of %d titles' % (stored, len(titles)), xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log('[MegaNexus] ratings preload skipped: %s' % exc, xbmc.LOGINFO)
    thread = threading.Thread(target=work, name='MegaNexusRatingsPreload', daemon=True)
    thread.start()
    return thread


def _start_release_dates(proxy):
    """7.0.36: TMDB's release dates of the same cards (films: cinema / digital,
    series: next episode), fetched in the background and kept a day - Home's
    release badge then shows the moment a card is selected. Stops when
    MegaNexus closes (Kodi waits for a script's threads)."""
    if not proxy:
        return None
    from . import precache
    import threading
    titles = precache.titles()
    if not titles:
        return None
    home = xbmcgui.Window(10000)
    running = home.getProperty('meganexus.frontend.running')
    monitor = xbmc.Monitor()

    def stopped():
        return monitor.abortRequested() or home.getProperty('meganexus.frontend.running') != running

    def busy():
        """The user moves through MegaNexus (keys within 3 s), a video plays or a page loads."""
        try:
            touched = time.time() - float(home.getProperty('meganexus.interactive_busy') or 0) < 3
        except ValueError:
            touched = False
        return touched or browse_cache.playback_busy() or browse_cache.foreground_busy()

    def work():
        from resources.lib import release_info
        while not stopped():
            try:
                done = release_info.preload(titles, stopped, busy, monitor.waitForAbort)
                xbmc.log('[MegaNexus] release dates preload: %d of %d titles' % (done, len(titles)), xbmc.LOGINFO)
            except Exception as exc:
                xbmc.log('[MegaNexus] release dates preload skipped: %s' % exc, xbmc.LOGINFO)
            # 7.0.36: at midnight films in cinemas and series are fetched again
            # (released films stay kept), also while MegaNexus stays open.
            until = time.monotonic() + release_info.until_midnight() + 5
            while not stopped() and time.monotonic() < until:
                if monitor.waitForAbort(5):
                    return
    thread = threading.Thread(target=work, name='MegaNexusReleasePreload', daemon=True)
    thread.start()
    return thread


def _art_names():
    try:
        from resources.lib import art_provider
        return art_provider.summary()
    except Exception:
        return 'TMDB / Fanart.tv'


def prepare():
    """Before Home: make sure every collection's first page is cached (Back
    skips). No poster screen (7.0.7): Kodi shows the posters it has shown
    before from its own disk cache, and Home's background preload loads the
    others at once - the first screen of every collection first - into the
    image RAM, so collections still open with their posters."""
    all_jobs = jobs()
    cache = browse_cache.instance()
    # One SQLite read promotes warmed disk pages to the bounded in-process LRU.
    # Stale pages count as present: Home shows them at once and they are
    # revalidated one by one in the background instead of behind a loading screen.
    state = cache.lookup_many([job[0] for job in all_jobs])
    absent = [job for job in all_jobs if job[0] not in state]
    # 7.0.11: catalogs that failed or came back empty lately are not waited for
    # again; they retry in the background and appear once they load.
    misses = cache.lookup_many([browse_cache.miss_key(job[0]) for job in absent]) if absent else {}
    missing = [job for job in absent if browse_cache.miss_key(job[0]) not in misses]
    for key, provider, catalog, extra in absent:
        if browse_cache.miss_key(key) in misses:
            browse_cache.refresh(provider, catalog, extra)
    for key, provider, catalog, extra in all_jobs:
        if state.get(key) is False:
            browse_cache.refresh(provider, catalog, extra)
    report = {'cached': len(all_jobs) - len(missing), 'loaded': 0, 'failed': 0, 'deferred': len(missing), 'posters': 0}
    base = art_cold()
    if base:
        # Home's preload continues even when the proxy already holds many images.
        xbmcgui.Window(10000).setProperty('meganexus.art_warm.front', base)
    # 7.0.30: every time MegaNexus opens, Home and every collection's first page
    # are ready first: the opening screen stays until Kodi keeps 90 % of their
    # posters (cards without a picture link and links Kodi cannot load do not
    # count), and the titles' MDBList ratings are fetched in a few requests.
    # When Kodi already has them, Home opens at once without the screen.
    # (7.0.9-7.0.29: only once per device / after an update.) Back skips.
    from . import precache, perf
    import xbmcaddon
    proxy = precache.base() if precache.enabled() else ''
    ids = [folder['id'] for group in shown_groups() for folder in group.get('folders') or [] if folder.get('id')]
    landscape = xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape') == 'landscape'
    first = bool(proxy) and precache.first_time()
    ready = True
    done = total = 0
    if proxy and not missing:
        with perf.timed('Start check', collections=len(ids)) as step:
            done, total = precache.plan(ids, landscape)
            ready = (not total or done >= total * precache.RING_DONE) and not precache.art_waiting()
            step.details.update(posters='%d/%d' % (done, total), artwork=precache.art_waiting())
    ratings = _start_ratings(proxy)
    _start_release_dates(proxy)
    xbmc.log('[MegaNexus] start: %d catalogs, %d to load, %d unavailable lately (retried in the background), posters ready: %s'
             % (len(all_jobs), len(missing), len(absent) - len(missing), 'yes' if ready else 'no'), xbmc.LOGINFO)
    if not missing and ready:
        return report
    window = Loading('meganexus_loading.xml', ROOT, theme_folder(),'1080i', label='', full=True, hub=True)
    monitor = xbmc.Monitor()
    window.show()
    try:
        if missing:
            _warm_catalogs(window, monitor, all_jobs, missing, report)
            if proxy and not window.cancelled and not monitor.abortRequested():
                window.setProperty('meganexus.ring', '00')
                done, total = precache.plan(ids, landscape, lambda: window.cancelled)
                ready = (not total or done >= total * precache.RING_DONE) and not precache.art_waiting()
                if ratings is None:
                    ratings = _start_ratings(proxy)
        if proxy and precache.art_waiting() and not window.cancelled and not monitor.abortRequested():
            # 7.0.32: the pictures of the provider chosen in Artwork (posters,
            # backgrounds, title logos) first, so collections open with them
            # instead of changing them one by one. Then the posters themselves.
            changed = first or precache.art_changed()
            # 7.0.36: words only for a new Artwork choice; the day's new titles: the ring alone
            text = ('One-time setup: getting collection artwork from %s' % _art_names()) if changed else ''
            def art_label(done, total):
                window.setProperty('meganexus.ring', ring_step(done, total))
                window.setProperty('meganexus.loading', (text + '[CR]%d / %d titles · Back to skip' % (done, total)) if text else '')
            started = time.monotonic()
            looked = precache.resolve_art(lambda: window.cancelled, monitor.waitForAbort, art_label,
                                          until=None if changed else started + MAX_ART_SECONDS)
            xbmc.log('[MegaNexus] artwork preload: %d titles in %.0f s%s'
                     % (looked, time.monotonic() - started, ' (skipped)' if window.cancelled else ''), xbmc.LOGINFO)
            if not window.cancelled and not monitor.abortRequested():
                window.setProperty('meganexus.ring', '00')
                done, total = precache.plan(ids, landscape, lambda: window.cancelled)
                ready = not total or done >= total * precache.RING_DONE
                first = first or changed
        if proxy and not ready and not window.cancelled and not monitor.abortRequested():
            # A first setup (install, update, cleared cache) runs until 90 %; the
            # day's new posters get MAX_POSTER_SECONDS.
            # 7.0.36: the One-time setup (with its words) only while Kodi keeps fewer than
            # half of the pictures (first start, a cleared cache, a new Artwork choice);
            # otherwise the few new ones come in quickly behind the ring alone.
            full = done < total * FULL_SETUP_SHARE
            text = 'One-time setup: preparing collections · posters and artwork' if full else ''
            def label(done, total):
                window.setProperty('meganexus.ring', ring_step(done, total))
                window.setProperty('meganexus.loading', (text + '[CR]%d / %d pictures · Back to skip' % (done, total)) if text else '')
            started = time.monotonic()
            report['posters'] = precache.run(window, lambda: window.cancelled, monitor.waitForAbort, label,
                                             until=None if full else started + MAX_POSTER_SECONDS)[0]
            xbmc.log('[MegaNexus] poster preload: %d stored by Kodi of %d in %.0f s%s'
                     % (report['posters'], precache.progress()[1], time.monotonic() - started, ' (skipped)' if window.cancelled else ''), xbmc.LOGINFO)
        if ratings is not None:
            until = time.monotonic() + 10
            while ratings.is_alive() and time.monotonic() < until and not window.cancelled and not monitor.abortRequested():
                monitor.waitForAbort(.1)
        return report
    finally:
        window.close()
