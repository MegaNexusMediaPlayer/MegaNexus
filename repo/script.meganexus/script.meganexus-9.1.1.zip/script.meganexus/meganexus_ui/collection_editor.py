# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Explicit layout edits; provider sync never owns the Home design."""
import json
import xbmcgui
import xbmcvfs
from resources.lib import collection_profile, settings_snapshot


def _image(title):
    dialog=xbmcgui.Dialog()
    choice=dialog.select(title,['Choose local image / GIF','Enter image URL'])
    if choice==0:return dialog.browseSingle(1,title,'files','.png|.jpg|.jpeg|.webp|.gif')
    if choice==1:
        value=dialog.input('Image URL').strip()
        if value and not value.startswith(('https://','http://')):raise ValueError('Use an HTTP or HTTPS image URL.')
        return value
    return ''


def _catalogs(folder):
    from resources.lib import metadata_providers
    from resources.lib.meganexus import addon_registry
    switches = {p['id']: on for p, on in metadata_providers.entries()}
    options = [(p, c) for p in addon_registry.list_providers()
               if switches.get(p['id'], True)
               for c in (p.get('manifest') or {}).get('catalogs') or []
               if c.get('id') and c.get('type') in ('movie', 'series')]
    if not options:
        raise ValueError('Add a manifest with movie or series catalogs first.')
    # Trakt / TMDB sources (6.0.37) are not add-on catalogs: kept as they are.
    kept = [s for s in folder.get('sources') or [] if s.get('provider') in ('trakt', 'tmdb')]
    old = {(s.get('addonId'), s.get('providerId'), s['catalogId'], s['type']): s
           for s in folder.get('sources') or [] if s.get('catalogId')}
    def identity(p, c):
        return ((p.get('manifest') or {}).get('id'), p['id'], c['id'], c['type'])
    selected = xbmcgui.Dialog().multiselect('Catalogs for ' + folder['title'],
        ['%s · %s (%s)' % (p.get('name') or p['id'], c.get('name') or c['id'], c['type']) for p, c in options],
        preselect=[i for i, (p, c) in enumerate(options) if identity(p, c) in old])
    if selected is None:
        return False
    if not selected and not kept:
        raise ValueError('Choose at least one catalog. Use Hide to remove a card from Home.')
    folder['sources'] = [dict(old.get(identity(*options[i]), {}),
        addonId=(options[i][0].get('manifest') or {}).get('id', ''), providerId=options[i][0]['id'],
        catalogId=options[i][1]['id'], type=options[i][1]['type']) for i in selected] + kept
    for source, index in zip(folder['sources'], selected):
        catalog = options[index][1]
        specs = {item['name']: item for item in catalog.get('extra') or [] if isinstance(item, dict) and item.get('name')}
        required = set(catalog.get('extraRequired') or []) | {name for name, spec in specs.items() if spec.get('isRequired')}
        extra = dict(source.get('extra') or {})
        if source.get('genre') and source['genre'] != 'None':extra['genre'] = source['genre']
        for name in sorted(required):
            if extra.get(name) not in (None, ''):continue
            values = specs.get(name, {}).get('options') or []
            if values:
                pick = xbmcgui.Dialog().select(source['catalogId'] + ' · ' + name, [str(v) for v in values])
                if pick < 0:return False
                extra[name] = str(values[pick])
            else:
                value = xbmcgui.Dialog().input(source['catalogId'] + ' · required ' + name).strip()
                if not value:return False
                extra[name] = value
        source['extra'] = extra
    return True


def _source_label(source, providers):
    from resources.lib.collections_home import matching_catalog
    kind = 'Series' if source.get('type') == 'series' else 'Movies'
    from resources.lib.collection_sources import is_virtual, label
    if is_virtual(source):
        return label(source), True
    match = matching_catalog(source, providers)
    if not match:
        return '%s (%s)' % (source.get('catalogId'), kind), False
    provider, catalog = match
    name = catalog.get('name') or catalog.get('id')
    genre = source.get('genre') if source.get('genre') not in (None, '', 'None') else ''
    return '%s · %s (%s%s)' % (provider.get('name') or provider['id'], name, kind,
                               ', ' + genre if genre else ''), True


def linked_catalogs(groups, folder):
    """Each linked catalog by name with its own On/Off switch."""
    from . import settings_page as page
    from .settings import commit_collections
    from resources.lib.meganexus import addon_registry

    def rows():
        providers = addon_registry.list_providers()
        result = []
        for source in folder['sources']:
            label, installed = _source_label(source, providers)
            if installed:
                result.append(page.item(label, enabled=source.get('enabled') is not False))
            else:
                result.append(page.item(label, 'Not installed'))
        return result + [page.item('Add or change catalogs…'), page.item('Back')]

    def choose(pick):
        sources = folder['sources']
        if pick == len(sources) + 1:
            return page.DONE
        from copy import deepcopy
        before = deepcopy(sources)
        if pick == len(sources):
            if not _catalogs(folder):
                return None
        else:
            source = sources[pick]
            turning_off = source.get('enabled') is not False
            if turning_off and sum(1 for s in sources if s.get('enabled') is not False) <= 1:
                raise ValueError('Keep at least one catalog ON. Use "Show on Home" to hide the whole card.')
            source['enabled'] = not turning_off
        if not commit_collections(groups):
            folder['sources'][:] = before
        return None

    return page.show(lambda: 'Catalogs · ' + folder['title'], rows, choose)


def _linked_summary(folder):
    from resources.lib.meganexus import addon_registry
    providers = addon_registry.list_providers()
    sources = folder.get('sources') or []
    on = [s for s in sources if s.get('enabled') is not False]
    names = [_source_label(s, providers)[0].split(' · ')[-1] for s in on[:2]]
    text = ', '.join(names) + (' …' if len(on) > 2 else '')
    return '%d of %d ON · %s' % (len(on), len(sources), text) if sources else 'None'


def edit_items():
    dialog=xbmcgui.Dialog()
    previous=0
    while True:
        groups=collection_profile.load()
        rows=[(g,i,f) for g in groups for i,f in enumerate(g['folders'])]
        pick=dialog.select('Home collection cards',[g['title']+' / '+f['title']+(' [Hidden]' if f.get('hidden') else '') for g,i,f in rows],preselect=min(previous,max(0,len(rows)-1)))
        if pick<0:return
        previous=pick
        group,index,folder=rows[pick]
        edit_card(groups,group,folder)


def edit_card(groups,group,folder):
    from . import settings_page as page
    dialog=xbmcgui.Dialog()
    def rows():return [page.item('Name',folder['title']),page.item('Cover image','Configured' if folder.get('cover') else 'Default'),
        page.item('Hero background','Configured' if folder.get('backdrop') else 'Default'),
        page.item('Focused animation / GIF','Configured' if folder.get('animation') else 'Default'),
        page.item('Show on Home',enabled=not folder.get('hidden')),page.item('Move left'),page.item('Move right'),
        page.item('Linked metadata catalogs',_linked_summary(folder)),page.item('Genre filter'),
        page.item('Show card title',enabled=not folder.get('hideTitle')),page.item('Back')]
    def choose(choice):
        if choice==10:return page.DONE
        from copy import deepcopy
        original_folder = deepcopy(folder)
        original_order = list(group['folders'])
        changed=True
        if choice==0:
            value=dialog.input('Collection title',defaultt=folder['title']).strip()
            if value:folder['title']=value
            else:changed=False
        elif choice in (1,2,3):
            value=_image(('Cover image','Hero background','Focused animation / GIF')[choice-1])
            if value:
                folder[{1:'cover',2:'backdrop',3:'animation'}[choice]]=value
                if choice==3:
                    from . import settings
                    try:overrides=json.loads(settings.ADDON.getSetting('meganexus_animation_map') or '{}')
                    except ValueError:overrides={}
                    overrides.pop(folder['id'],None)
                    settings.ADDON.setSetting('meganexus_animation_map',json.dumps(overrides))
            else:changed=False
        elif choice==4:folder['hidden']=not folder.get('hidden')
        elif choice in (5,6):
            index=next(i for i,f in enumerate(group['folders']) if f['id']==folder['id'])
            dest=max(0,min(len(group['folders'])-1,index+(-1 if choice==5 else 1)))
            group['folders'].insert(dest,group['folders'].pop(index))
        elif choice==7:
            linked_catalogs(groups,folder)
            changed=False  # Each switch in that page is saved and validated on its own.
        elif choice==8:
            from resources.lib.meganexus import addon_registry
            providers=addon_registry.list_providers()
            selected=dialog.select('Catalog genre filter',[_source_label(s,providers)[0] for s in folder['sources']])
            if selected>=0:
                source=folder['sources'][selected]
                source['genre']=dialog.input('Genre (empty means all)',defaultt=source.get('genre') or '').strip()
                extra=dict(source.get('extra') or {});extra.pop('genre',None);source['extra']=extra
            else:changed=False
        elif choice==9:folder['hideTitle']=not folder.get('hideTitle')
        if changed:
            from .settings import commit_collections
            if not commit_collections(groups):
                folder.clear();folder.update(original_folder)
                group['folders'][:]=original_order
    return page.show(lambda:folder['title'],rows,choose)


def import_json():
    from .settings import commit_collections
    path = xbmcgui.Dialog().browseSingle(1, 'Nuvio collections export', 'files', '.json')
    if not path:
        return False
    stream = xbmcvfs.File(path)
    try:
        data = json.loads(stream.read())
    finally:
        stream.close()
    return commit_collections(data)


def create_collection():
    from .settings import commit_collections
    import uuid
    title = xbmcgui.Dialog().input('Collection name').strip()
    if not title:
        return False
    groups = collection_profile.load()
    folder = {'id': 'custom.' + uuid.uuid4().hex, 'title': title, 'sources': []}
    if not _catalogs(folder):
        return False
    custom = next((g for g in groups if g['id'] == 'custom'), None)
    if custom is None:
        custom = {'id': 'custom', 'title': 'My collections', 'folders': []}
        groups.append(custom)
    custom['folders'].append(folder)
    return commit_collections(groups)


def home_shows():
    """What Home is made of, for the first row of Collections & Home rows (9.0.4: the switch said
    "Default collections" halfway down the page, and never why the Catalog was on)."""
    from . import settings
    from resources.lib import default_setup, home_source
    automatic = bool(settings.ADDON.getSetting(default_setup.AUTO_LAYOUT)) and not collection_profile.users_own()
    now = home_source.current()
    if now == home_source.BUILTIN:
        return 'MegaNexus Catalog' + (' · automatic' if automatic else '')
    if now.startswith(home_source.ADDON):
        name = next((n for key, n, _ in home_source.choices() if key == now), 'Add-on')
        return name + ' · its catalogs' + (' · automatic' if automatic else '')
    if automatic and now:
        return 'Your add-ons\' catalogs · automatic'
    return 'Your collections'


def choose_source():
    """9.0.6: where Home's one set of collections comes from - yours, the MegaNexus Catalog or one add-on's
    catalogs (resources/lib/home_source.py); its rows and cards are then shown and ordered below."""
    from resources.lib import home_source
    from .play_jobs import job
    dialog = xbmcgui.Dialog()
    options = home_source.choices()
    keys = [key for key, _, _ in options]
    now = home_source.current()
    items = [xbmcgui.ListItem(label=name, label2=detail) for _, name, detail in options]
    pick = dialog.select('Home shows', items, useDetails=True, preselect=keys.index(now) if now in keys else -1)
    if pick < 0 or keys[pick] == now:
        return False
    try:
        count = job(lambda: home_source.use(keys[pick]), label='Setting up Home')
    except ValueError as exc:
        dialog.ok('Home shows', str(exc))
        return False
    settings_snapshot.invalidate()
    dialog.notification('Home shows', '%s · %d cards' % (options[pick][1], count or 0), time=3000)
    return True


def tracking_row(name):
    """9.0.8: Watchlist / Next episodes (resources/lib/tracking_rows.py) - on Home or not, which tracking
    service fills it ("Rows from": only those that can, connected) and where it stands among the Home
    rows. Switched on it comes right under Continue Watching. 9.1.1: and a Top 10 row (top10_rows) - its
    "Rows from" the sources that have its list (TMDB, Trakt, Simkl, MDBList), and it can be taken off."""
    from . import settings_page as page
    from . import settings
    from resources.lib import tracking_rows
    dialog = xbmcgui.Dialog()
    ranked = tracking_rows.is_ranked(name)

    def title():
        return '%s · %s' % (tracking_rows.title(name, settings.ADDON), tracking_rows.where(name, collection_profile.load(), settings.ADDON))

    def rows():
        addon = settings.ADDON
        return [page.item('Show on Home', enabled=tracking_rows.shown(name, addon)),
                page.item('Rows from', tracking_rows.source_name(name, addon)),
                # moved in place: the page stays, the title above says where it stands now
                dict(page.item('Move up'), kind='info'), dict(page.item('Move down'), kind='info')] + (
                [page.item('Remove this row')] if ranked else []) + [page.item('Back')]

    def choose(pick):
        addon = settings.ADDON
        if pick == (5 if ranked else 4):
            return page.DONE
        if pick == 0:
            on = not tracking_rows.shown(name, addon)
            tracking_rows.switch(name, on, addon)
            if on:
                tracking_rows.prefill(name, addon)          # its first answer asked now, behind these pages
        elif pick == 1:
            options = tracking_rows.sources(name, addon)
            now = tracking_rows.picked(name, addon)
            keys = [key for key, _ in options]
            chosen = dialog.select('Rows from · ' + tracking_rows.title(name, addon), [label for _, label in options],
                                   preselect=keys.index(now) if now in keys else 0)
            if chosen < 0 or keys[chosen] == now:
                return None
            tracking_rows.choose(name, keys[chosen], addon)
            tracking_rows.prefill(name, addon)
        elif ranked and pick == 4:
            if dialog.yesno('Remove this row', 'Take %s off Home and off this list?' % tracking_rows.title(name, addon)):
                tracking_rows.remove_top(name, addon)
                settings_snapshot.invalidate()
                return page.DONE
            return None
        else:
            if not tracking_rows.shown(name, addon):
                raise ValueError('Switch the row on first - it comes right under Continue Watching.')
            if not tracking_rows.move(name, -1 if pick == 2 else 1,
                                      [g['id'] for g in collection_profile.load()], addon):
                dialog.notification(tracking_rows.title(name, addon), 'It is at the %s already.' % ('top' if pick == 2 else 'end'), time=2500)
        settings_snapshot.invalidate()
        return None
    return page.show(title, rows, choose)


def add_top_row():
    """9.1.1: a new Top 10 row ("top 10 akcija, top 10 horor, top 10 svega ... i iz više servisa"): its list, its
    kind and where it comes from - then on Home right under Continue Watching, moved or hidden like the others."""
    from . import settings
    from resources.lib import tracking_rows, top10_rows
    dialog = xbmcgui.Dialog()
    lists = top10_rows.lists()
    which = dialog.select('Top 10 of', [name for _, name in lists])
    if which < 0:
        return None
    kinds = list(top10_rows.KINDS)                 # Trakt has every list of both (public): one can always fill it
    kind = dialog.select('Top 10 %s' % lists[which][1], [words.capitalize() for _, words in kinds])
    if kind < 0:
        return None
    list_key, kind_key = lists[which][0], kinds[kind][0]
    found = top10_rows.sources_for(list_key, kind_key)
    options = [(tracking_rows.AUTO, 'Automatic · ' + top10_rows.NAMES[top10_rows.automatic(list_key, kind_key)])] + \
              [(key, top10_rows.NAMES[key]) for key in found]
    source = dialog.select('Rows from', [label for _, label in options])
    if source < 0:
        return None
    row = tracking_rows.add_top(list_key, kind_key, options[source][0], settings.ADDON)
    tracking_rows.prefill(row, settings.ADDON)
    settings_snapshot.invalidate()
    dialog.notification(tracking_rows.title(row, settings.ADDON), 'On Home, right under Continue Watching.', time=3000)
    return row


def home_rows():
    """Show or hide whole Home rows: Continue Watching, Local (6.0.37),
    Plex / Jellyfin (6.0.39 beta, when connected) and each collection group
    (7.0.24: and each group's row title). 9.0.8: and Watchlist / Next episodes
    (tracking_row), listed where Home shows them - off until switched on."""
    from . import settings_page as page
    from . import settings
    from resources.lib import local_media, media_servers, tracking_rows
    dialog = xbmcgui.Dialog()
    def switches():
        """[(label, setting, on)] rows above the collection groups."""
        addon = settings.ADDON
        out = [('Continue Watching', 'meganexus_home_continue', addon.getSetting('meganexus_home_continue') != 'false'),
               ('Local · movies and series on this device', local_media.HOME_SETTING, local_media.enabled(addon))]
        for kind in media_servers.KINDS:
            if media_servers.signed_in(kind):
                out.append(('%s · Continue watching and Recently added' % media_servers.label(kind),
                            media_servers.HOME[kind], addon.getSetting(media_servers.HOME[kind]) == 'true'))
        return out
    def entries(groups):
        """[(kind, value)] in Home's order: ('switch', (label, setting, on)), ('row', name), ('group', group).
        The rows switched on where they stand, those switched off right under Continue Watching."""
        addon = settings.ADDON
        top = switches()
        names = tracking_rows.rows(addon)
        on = [name for name in names if tracking_rows.shown(name, addon)]
        tokens = tracking_rows.merged([g['id'] for g in groups], tracking_rows.order(addon), on)
        lead = []
        while tokens and tokens[0][0] == 'row':
            lead.append(tokens.pop(0)[1])
        by_id = {g['id']: g for g in groups}
        return ([('switch', top[0])] + [('row', name) for name in lead] +
                [('row', name) for name in names if name not in on] +
                [('switch', item) for item in top[1:]] +
                [('group', by_id[value]) if kind == 'group' else ('row', value) for kind, value in tokens])
    def rows():
        from resources.lib import collections_home
        addon = settings.ADDON
        posters = collections_home.poster_groups(addon)
        out = []
        for kind, value in entries(collection_profile.load()):
            if kind == 'switch':
                out.append(page.item(value[0], enabled=value[2]))
            elif kind == 'row':
                out.append(page.item(tracking_rows.title(value, addon), ('On · ' + tracking_rows.source_name(value, addon))
                                     if tracking_rows.shown(value, addon) else 'Off'))
            else:
                # 9.0.9: what the row is, not an On/Off switch - it opens its page (group_row), where it is shown or
                # hidden, shown as cards or poster rows and moved ("nisam ni skuzio da mogu kliknuti")
                shown = 'Hidden' if value.get('hidden') else 'Poster rows' if value['id'] in posters else 'Cards'
                out.append(page.item(value['title'], ' · '.join(part for part in (
                    shown, '%d collection%s' % (len(value['folders']), '' if len(value['folders']) == 1 else 's'),
                    'title hidden' if value.get('hideTitle') else '') if part)))
        return out + [page.item('Add a Top 10 row', 'Trending, popular or a genre'), page.item('Back')]
    def choose(pick):
        groups = collection_profile.load()
        listed = entries(groups)
        if pick == len(listed):
            add_top_row()                  # 9.1.1
            return None
        if pick > len(listed):
            return page.DONE
        kind, value = listed[pick]
        if kind == 'switch':
            _, key, on = value
            settings.ADDON.setSetting(key, 'false' if on else 'true')
            media_servers.forget()
            return None
        if kind == 'row':
            tracking_row(value)
            return None
        group_row(value['id'])
        return None
    return page.show('Home rows · show or hide', rows, choose)


def group_row(group_id):
    """A Home row of your collections (a group): on Home or not, its title (7.0.24), shown as cards or as
    poster rows and moved up or down among the Home rows (9.0.9 - the phone only moved it; the TV had a
    choice of two). Its page stays while it moves; the title above says where it stands."""
    from . import settings_page as page
    from . import settings
    from resources.lib import collections_home, tracking_rows
    dialog = xbmcgui.Dialog()

    def mine():
        groups = collection_profile.load()
        return groups, next((g for g in groups if g['id'] == group_id), None)

    def title():
        groups, group = mine()
        if group is None:
            return 'Home row'
        on = [name for name in tracking_rows.rows(settings.ADDON) if tracking_rows.shown(name, settings.ADDON)]
        tokens = tracking_rows.merged([g['id'] for g in groups], tracking_rows.order(settings.ADDON), on)
        here = tokens.index(('group', group_id))
        if not here:
            return '%s · the first row' % group['title']
        kind, before = tokens[here - 1]
        named = tracking_rows.title(before, settings.ADDON) if kind == 'row' else next(g['title'] for g in groups if g['id'] == before)
        return '%s · after %s' % (group['title'], named)

    def every_row_posters(groups):
        # the "MegaNexus rows" / "MegaNexus posters" layouts and the MegaNexus Catalog's own collections show
        # every row as posters already - the choice of a row counts with "MegaNexus collections"
        from resources.lib.default_setup import is_builtin_layout
        return collections_home.layout(settings.ADDON) != 'collections' or is_builtin_layout(groups)

    def rows():
        groups, group = mine()
        group = group or {}
        posters = group_id in collections_home.poster_groups(settings.ADDON)
        shown_as = 'Poster rows · every row (Home layout)' if every_row_posters(groups) else 'Poster rows' if posters else 'Cards'
        return [page.item('Show this row on Home', enabled=not group.get('hidden')),
                page.item('Show the row title', enabled=not group.get('hideTitle')),
                dict(page.item('Show as', shown_as), kind='info'),
                dict(page.item('Move up'), kind='info'), dict(page.item('Move down'), kind='info'), page.item('Back')]

    def choose(pick):
        groups, group = mine()
        if pick == 5 or group is None:
            return page.DONE
        if pick in (0, 1):
            key = 'hidden' if pick == 0 else 'hideTitle'
            group[key] = not group.get(key)
            collection_profile.save(groups)
        elif pick == 2:
            if every_row_posters(groups):
                raise ValueError('Every Home row is a poster row with this Home layout. To choose row by row, set '
                                 'HUB Settings > Appearance > Home layout to "MegaNexus collections".')
            collections_home.show_as_posters(group_id, group_id not in collections_home.poster_groups(settings.ADDON),
                                             settings.ADDON)
        else:
            order = tracking_rows.move_group(group_id, -1 if pick == 3 else 1, [g['id'] for g in groups], settings.ADDON)
            if order is None:
                dialog.notification(group['title'], 'It is at the %s already.' % ('top' if pick == 3 else 'end'), time=2500)
                return None
            by_id = {g['id']: g for g in groups}
            collection_profile.save([by_id[i] for i in order])
        settings_snapshot.invalidate()
        return None
    return page.show(title, rows, choose)


def run():
    """Collections & Home rows (translucent page, 7.0)."""
    from . import settings
    from . import settings_page as page
    dialog = xbmcgui.Dialog()
    def build():
        from resources.lib import release_info
        return [('defaults', page.item('Home shows', home_shows())),      # yours or the MegaNexus Catalog's
                ('rows', page.item('Home rows · show or hide')),
                # 7.0.32: as NuvioTV - titles whose release date lies ahead stay out
                ('unreleased', page.item('Hide unreleased titles · Home, collections, search',
                                         enabled=release_info.hide_on(settings.ADDON))),
                ('cards', page.item('Edit each collection card')),
                ('nuvio', page.item('Import collections from Nuvio account')),
                ('json', page.item('Import collections JSON (no account needed)')),
                ('create', page.item('Create a collection from installed catalogs')),
                ('meta', page.item('Metadata add-ons used by collections')),
                ('check', page.item('Check collection catalogs (report only)'))]
    def act(key):
        try:
            if key == 'defaults':
                choose_source()
            elif key == 'rows':
                home_rows()
            elif key == 'unreleased':
                settings.toggle('meganexus_hide_unreleased')
                settings_snapshot.invalidate()
            elif key == 'cards':
                edit_items()
            elif key == 'meta':
                settings.metadata_addons()
            elif key == 'nuvio':
                settings.import_nuvio_collections()
            elif key == 'json':
                import_json()
            elif key == 'create':
                create_collection()
            elif key == 'check':
                groups = collection_profile.load()
                if groups:
                    settings.commit_collections(groups, force=True)
                else:
                    dialog.ok('Collection checks', 'Import or create collections first.')
        except (ValueError, OSError):
            dialog.ok('Collections', 'The change was not saved. Check the selected catalogs, filters and file format.')
        return None
    return page.keyed('Collections & Home rows', build, act)
