# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus Library screen (6.0.35; 9.0.5 one Library; 9.1.1 the services row).

9.0.5, as the streaming apps keep "My List" (Stremio's Library, Netflix, Plex's Watchlist):
one screen, every saved title once (library.everything) with the marks of every place it is
in. The date a title was added is on its card. The Local / Tracking services / Calendar tabs
are gone, and so are this device's files and the media servers' rows here (they are Home's rows).

9.1.1, as the user drew it ("library mi je nekako natrpan ... na vrhu naš logo, Home, Settings, Sort, Filter
... ispod prvi red landscaped postere sa svim servisima ... kad se klikne dole se ispod sve osvježi, ne otvara
se nova stranica"):
* the top bar is words as on every screen - Home (back to Home), Sort, Filter, View, Settings, HUB - and it
  slides away as theirs does (TopRow);
* under it the services row: MegaNexus (everything) first, the connected services, then the others, each a
  landscape tile as the HUB's apps (review/make_library_tiles.py) with its count beside it, a big number in the
  service's own colour inside the theme's text colour (review/make_rank_images.py's digits, put side by side here).
  OK on one
  shows its sections below (library_sections: MegaNexus's Movies, Series, Anime and On this device, Trakt's
  Watchlist, Next episodes and lists, the anime lists' Watching ...) - in place: nothing flashes and the cursor
  stays. On one not connected it offers HUB Settings > Accounts & tracking. It opens on MegaNexus, as it
  opened on everything ("na ulazu prikazuje sve");
* the cards: rows (a section each) or posters (every title of the place once); Filter (All / Movies / Series /
  Anime) and Sort work inside every section. View: rows or posters and the titles under the cards, saved in
  MegaNexus' settings (and its backup).

It opens from what this box keeps; the services are read again in the background and what
changed is written into the cards where they stand - nothing is emptied and drawn again
(it flashed, and the cursor jumped, every time a film or a title page closed), and the cursor
stays on its title.
"""
import json
import os
import time

import xbmcaddon
import xbmcgui
from resources.lib import art_cache, home_data, library, number_colors
from resources.lib.settings_snapshot import cached_addon, invalidate as settings_invalidate
from resources.lib.theme import folder as theme_folder
from .dialog import Dialog, BACK
from .top_row import TopRow
from . import listitems

HOME_BUTTON, SETTINGS_BUTTON, HUB_BUTTON = 101, 107, 109
LIBRARY_BUTTON = 106     # 9.1.1: the Library's own name in its top bar (Home's Library has the same id)
# 9.1.1: Sort, Filter and View under one word ("stavi pod jedno ime koje paše za sve tri i ubaci sve postavke unutra")
OPTIONS_BUTTON = 204     # a box with the order, what shows and the titles
SEARCH_BUTTON = 105      # the magnifier: it searches the Library ("lupa pretražuje dio u kojem se nalazi")
SERVICES_ROW = 230       # the services row (review/make_library_screen.py has the same numbers)
SLOT_BUTTON, SLOT_GROUP, SLOT_TILE, SLOTS = 231, 240, 250, 8
DIGIT_GROUP, DIGITS = 260, 4         # a slot's digits: groups 260 + 4 * slot + place, its count up to 9999
TINT = 'meganexus.library.svc.%d.tint'    # Window(Home): slot N's digits' colour (review/make_library_screen.py)
SORTS = (('added', 'Recently added'), ('title', 'Title A-Z'), ('year', 'Year'))
FILTERS = (('all', 'All'), ('movie', 'Movies'), ('series', 'Series'), ('anime', 'Anime'))
# 9.1.1: rows only - the wide cards, the list and the posters wall are gone (the wall mixed a service's sections with
# nothing saying which; Browse all opens one row as posters); View: the titles under the cards and the rows' own
SORT, TITLES, ROW_TITLES = 'meganexus_library_sort', 'meganexus_library_titles', 'meganexus_library_rowtitles'
HERO = 'meganexus.library.hero'      # the row whose title the top says (review/make_library_screen.py)
KINDS = {'movie': 'Movie', 'series': 'Series', 'anime': 'Anime'}
PLACE_NAMES = {library.LOCAL: 'This device', library.NUVIO: 'Nuvio'}
ROW_BASE = 500
MAX_ROWS = 14
ROW_CARDS = 20     # 7.0.29: a row shows this many, then "Browse all" opens the grid (as collections)
COVER_AFTER = .35  # 9.1.1: s the Library takes to stand (its open: 160 ms fade, 280 ms zoom) before Home is let go
# A slot of the services row: its count (the digits' pictures side by side from NUMBER_LEFT), then its tile over the
# count's right part - where the digits and the tile stand and how wide the slot is follow the count, so one digit or
# four take only their room (review/make_library_screen.py has the same numbers)
PAD, GAP, OVERLAP, TILE_W, TILE_TOP = 8, 32, 22, 352, 14
NUMBER_LEFT = PAD                  # the number from the slot's start
# each digit's picture and how wide it is (review/make_rank_images.py writes them and their sizes)
RANK = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'resources', 'media', 'rank')
_DIGIT_W = {}


def _identity(card):
    target = card.get('target') or {}
    return (target.get('media_type'), target.get('canonical_id')) if target else ('browse', card.get('title'))


def digit_widths():
    """{digit: its picture's width}, read once (rank/sizes.json, beside the pictures)."""
    if not _DIGIT_W:
        try:
            with open(os.path.join(RANK, 'sizes.json'), encoding='utf-8') as handle:
                _DIGIT_W.update(json.load(handle)['digit'])
        except (OSError, ValueError, KeyError):
            pass
    return _DIGIT_W


def digit_places(count):
    """Where each digit of ``count`` stands in its slot: [left], one for each digit, side by side from NUMBER_LEFT."""
    widths, left, out = digit_widths(), NUMBER_LEFT, []
    for digit in count:
        out.append(left)
        left += int(widths.get(digit, 0))
    return out


def number_width(count):
    widths = digit_widths()
    return sum(int(widths.get(digit, 0)) for digit in count)


def slot_layout(count):
    """(where the slot's tile stands, the slot's width) for a count that reads ``count`` ('': none shown)."""
    tile = NUMBER_LEFT + number_width(count) - OVERLAP if count else PAD
    return tile, tile + TILE_W + GAP


def _meta(card):
    """Year · kind · its first two genres - what the top says over the plot, as Home's."""
    target = card.get('target') or {}
    # (an anime by its own id only: Fribb's list is a file read per title, for the Anime filter alone)
    kind = 'anime' if str(target.get('canonical_id') or '').startswith(library.ANIME_IDS) else target.get('media_type') or ''
    genres = card.get('genres') or []
    words = [str(card.get('year') or ''), KINDS.get(kind, ''),
             ', '.join(genres[:2]) if isinstance(genres, (list, tuple)) else str(genres)]
    return '  ·  '.join(word for word in words if word and word != '0')


class LibraryWindow(TopRow, Dialog):
    TOP_ROW = (SEARCH_BUTTON, HOME_BUTTON, LIBRARY_BUTTON, OPTIONS_BUTTON, SETTINGS_BUTTON, HUB_BUTTON)   # as they stand

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        # 9.1.1: what Home does once the Library stands over it (meganexus.behind) - not before: Home gone at once, the
        # window under every screen showed through the opening fade, the HUB's trending picture ("ulaz u Library
        # bljesne TMDB artwork neki iz pozadinskog procesa")
        self._covered, self._cover_at = kwargs.get('covered'), 0.0
        # it opens on the place it was left on, everything at first ("na ulazu prikazuje sve"); 9.1.1: "uđem u pločicu
        # Trakt ... i izađem na bilo koji način - sljedeći put Trakt je odabran sa svojim sadržajem i na prvom je mjestu"
        self.place, self.kind = left_on(), 'all'
        self.query = ''          # the magnifier's words: the Library's titles called so, one row
        self._first = self.place    # its tile leads the row for this whole visit (the row never moves while in use)
        self.rows = []          # [(title, cards)] of the rows
        self._full = []
        self._cards = []        # library.everything()
        self._signature = None
        self._drawn = {}        # control id -> the identities of its cards, in order
        self._tiles = []        # library.service_tiles, in the slots' order
        self._slots = {}        # slot -> the count its tile is placed for
        self._reading = {}      # place -> its sections being read again (library_sections.refresh)
        self.outcome = ''
        self._refresh = None

    def onInit(self):
        # back from a title page or a film (Kodi set the screen up again): the title the
        # cursor was on when it left
        keep, self._leaving = getattr(self, '_leaving', None), None
        self._slots = {}        # set up again: the tiles stand where the skin has them
        self._load()
        self._show(keep)
        if getattr(self, '_covered', None) and not getattr(self, '_focused_once', False):
            self._cover_at = time.monotonic() + COVER_AFTER
        if not getattr(self, '_focused_once', False):
            self._focused_once = True
            self.setFocusId(SLOT_BUTTON + self._slot_of(self.place))   # 9.1.1: the services row, on the place shown
        else:
            self.restore_focus()
        self.row_focus()
        self._start_refresh()

    def onFocus(self, control_id):
        self.row_focus(control_id)
        if ROW_BASE <= control_id < ROW_BASE + MAX_ROWS:
            self._hero_row = control_id - ROW_BASE        # the top says this row's title (the last one the cursor was in)
            self._say(HERO, str(self._hero_row))

    def _load(self):
        """The Library again; True when anything a card shows changed."""
        try:
            cards = library.everything()
        except Exception:
            cards = []
        signature = [(_identity(c), tuple(c.get('services') or []), c.get('added_at'), c.get('poster'), c.get('title'))
                     for c in cards]
        changed = signature != self._signature
        self._signature, self._cards = signature, cards
        return changed

    # ---- drawing: only what changed, in place ------------------------------------------------
    def _focused_identity(self):
        cid = self.getFocusId()
        card = self._row(cid)
        return cid, (_identity(card) if card else None)

    def _sections(self):
        """[(title, cards)] of the place shown, in its order (library_sections, no network); a section not read yet
        has no cards."""
        from resources.lib import library_sections
        return [(s['title'], s['cards']) for s in library_sections.sections(self.place)]

    def _show(self, keep=None):
        cid, keep = keep or self._focused_identity()
        sort = option(SORT, SORTS)
        self._say('meganexus.library.norowtitles', '' if cached_addon().getSetting(ROW_TITLES) != 'false' else '1')
        # Home's: the cards read it there (a box over the Library hid it from them - make_library_screen.py)
        self._say('meganexus.library.notitles', '' if cached_addon().getSetting(TITLES) != 'false' else '1', home=True)
        # the word never changes width (Sport's buttons): the skin draws it in the accent colour while a filter is on
        self._say('meganexus.library.kind', self.kind)
        self._say('meganexus.library.options', 'Options' if self.kind == 'all' else '')
        self._services_row()
        query = getattr(self, 'query', '')
        if query:
            # the magnifier: every title of the Library called so, whatever place it is in
            wanted = query.casefold()
            found = [card for card in library.chosen(self._cards, 'all', self.kind, sort) if wanted in str(card.get('title') or '').casefold()]
            sections = [('Search · %s' % query, found)] if found else []
        else:
            sections = [(title, library.chosen(cards, 'all', self.kind, sort)) for title, cards in self._sections()]
            sections = [(title, cards) for title, cards in sections if cards]
        self._say('meganexus.library.empty', '' if sections else (
            'Nothing in the Library is called "%s".' % query if query else
            'Nothing here yet - long-press a title anywhere in MegaNexus and choose Add to Library.'
            if not self._cards and self.place == library.MEGANEXUS else 'Nothing here with this choice.'))
        up = self.getControl(SLOT_BUTTON + self._slot_of(self.place))   # Up from the cards: the place they are of
        self._full = sections[:MAX_ROWS]
        self.rows = [(title, _shown(cards)) for title, cards in self._full]
        for index, (_, row) in enumerate(self.rows):
            if row and row[-1].get('browse_all', 0) is None:
                row[-1]['browse_all'] = index
        for i in range(MAX_ROWS):
            self._say('meganexus.library.row.%d' % i, self.rows[i][0] if i < len(self.rows) else '')
            self._fill(ROW_BASE + i, self.rows[i][1] if i < len(self.rows) else [], keep if cid == ROW_BASE + i else None)
        # the row the foot shows: the one the cursor was in last (the rows' window stays on it), or the last one there
        # is when the rows are fewer now (the window then stops at that one)
        self._hero_row = min(getattr(self, '_hero_row', 0), max(0, len(self.rows) - 1))
        self._say(HERO, str(self._hero_row))
        for i in range(len(self.rows)):
            control = self.getControl(ROW_BASE + i)
            control.controlUp(self.getControl(ROW_BASE + i - 1) if i else up)
            # 9.1.1: one row at the foot; Down from the last goes round to the first ("dolje ići na ostale redove kružno")
            control.controlDown(self.getControl(ROW_BASE + (i + 1) % len(self.rows)))

    def _item(self, card):
        # a next episode (Trakt's Next episodes) says which one beside its show
        item = listitems.item(label='%s  ·  %s' % (card['title'], card['subtitle']) if card.get('subtitle') else card['title'])
        poster = art_cache.card(card.get('poster'))
        item.setArt({'poster': poster, 'landscape': art_cache.card(card.get('landscape') or card.get('fanart')) or poster,
                     'clearlogo': card.get('clearlogo') or ''})
        self._marks_on(item, card)
        item.setProperty('plot', card.get('plot') or '')
        item.setProperty('meta', _meta(card))      # the top's words of the title under the cursor
        return item

    def _marks_on(self, item, card):
        _services(item, card, self.place)
        item.setProperty('added', library.added_label(card.get('added_at')).replace('Added ', ''))

    def _fill(self, cid, cards, keep=None):
        """The cards into one list. The same titles in the same order: written in place (marks,
        date) - the list is not emptied, so nothing flashes and the cursor does not move."""
        control = self.getControl(cid)
        identities = [_identity(c) for c in cards]
        # still holding them (Kodi may have made the list anew, empty, when the screen came back)
        if self._drawn.get(cid) == identities and control.size() == len(identities):
            for pos, card in enumerate(cards):
                try:
                    self._marks_on(control.getListItem(pos), card)
                except Exception:
                    break
            return
        pos = control.getSelectedPosition()
        control.reset()
        if cards:
            control.addItems([self._item(card) for card in cards])
            at = identities.index(keep) if keep in identities else min(max(pos, 0), len(cards) - 1)
            if at > 0:
                control.selectItem(at)
        self._drawn[cid] = identities

    def _services_row(self):
        """The services row (9.1.1): each slot's tile from library.service_tiles - its name, its pictures (the
        lighter one under the cursor), its count (none while it is not connected) digit by digit and the colour its
        digits are filled with - and, when its count reads otherwise, where its digits and tile stand. A place no
        longer connected gives way to MegaNexus."""
        tiles = library.service_tiles(self._cards)
        first = getattr(self, '_first', library.MEGANEXUS)
        lead = [tile for tile in tiles if tile['id'] == first and tile['on'] and first != library.MEGANEXUS]
        tiles = lead + [tile for tile in tiles if tile not in lead]       # the place it was left on first, then the rule
        if self.place not in [tile['id'] for tile in tiles if tile['on']]:
            self.place = library.MEGANEXUS
        self._tiles = tiles
        for n in range(SLOTS):
            tile = tiles[n] if n < len(tiles) else {}
            count = str(min(tile['count'], 10 ** DIGITS - 1)) if tile.get('on') else ''   # 9999 at most: four digits' room
            for name, value in [('name', tile.get('name') or ''), ('tile', tile.get('tile') or ''), ('lit', tile.get('lit') or ''),
                                ('on', '1' if tile.get('on') else '')] + \
                    [('d%d' % k, count[k] if k < len(count) else '') for k in range(DIGITS)]:
                self._say('meganexus.library.svc.%d.%s' % (n, name), value)
            # the digits' colour (Big numbers · colour: the service's own, or the one chosen) on Home's window: Kodi
            # looks a colour's bare Window.Property up in the topmost dialog (GUIInfoColor::Update, DEFAULT_CONTEXT),
            # so the box of Sort, Filter or View took the digits' colour away while it was open
            self._say(TINT % n, number_colors.fill(tile.get('tint')) if tile else '', home=True)
            if tile and self._slots.get(n) != count:
                self._place_slot(n, count)

    def _say(self, key, value, home=False):
        """A property written only when its value is new (as HomeWindow._say): each write waits for Kodi's drawing
        thread - ~25 ms on the Cube, longer while posters decode - and a show of the Library wrote about a hundred,
        on every tile, Sort, Filter, View and read. ``home``: on Home's window (Kodi keeps a window's properties until
        the script clears them, which nothing here does)."""
        said = getattr(self, '_said', None)
        if said is None:
            said = self._said = {}
        if said.get((home, key)) == value:
            return
        said[(home, key)] = value
        if home:
            if getattr(self, '_home', None) is None:
                self._home = xbmcgui.Window(10000)
            self._home.setProperty(key, value)
        else:
            self.setProperty(key, value)

    def _place_slot(self, n, count):
        """Slot ``n`` laid out for its count: its digits side by side, its tile after them, the slot as wide as both
        (the row is a grouplist: it lays its slots out by their width, the next one moves along)."""
        tile, width = slot_layout(count)
        try:
            for k, left in enumerate(digit_places(count)):
                group = self.getControl(DIGIT_GROUP + DIGITS * n + k)
                group.setPosition(left, group.getY())
            self.getControl(SLOT_TILE + n).setPosition(tile, TILE_TOP)
            self.getControl(SLOT_GROUP + n).setWidth(width)
        except Exception:
            return
        self._slots[n] = count

    def _slot_of(self, place):
        return next((n for n, tile in enumerate(self._tiles[:SLOTS]) if tile['id'] == place), 0)

    # ---- the choices -------------------------------------------------------------------------
    def _choose_options(self):
        """Options: the order, what shows and the titles in one box ("sort filter view ... pod jedno ime"); True when
        one of them was changed."""
        addon = cached_addon()
        state = lambda key: 'Off' if addon.getSetting(key) == 'false' else 'On'
        rows = [('sort', 'Sort · %s' % dict(SORTS).get(option(SORT, SORTS), '')),
                ('filter', 'Show · %s' % dict(FILTERS).get(self.kind, '')),
                ('titles', 'Titles under the cards · %s' % state(TITLES)),
                ('rows', 'Row titles · %s' % state(ROW_TITLES))]
        pick = xbmcgui.Dialog().select('Options', [label for _key, label in rows])
        if pick < 0:
            return False
        key = rows[pick][0]
        if key == 'sort':
            return self._choose_sort()
        if key == 'filter':
            return self._choose_filter()
        setting = TITLES if key == 'titles' else ROW_TITLES
        addon.setSetting(setting, 'true' if addon.getSetting(setting) == 'false' else 'false')
        settings_invalidate()
        return True

    def _choose_sort(self):
        """The orders in a box, the one in use chosen; True when another was picked."""
        keys = [k for k, _ in SORTS]
        now = keys.index(option(SORT, SORTS))
        pick = xbmcgui.Dialog().select('Sort', [label for _, label in SORTS], preselect=now)
        if pick < 0 or pick == now:
            return False
        cached_addon().setSetting(SORT, keys[pick])
        settings_invalidate()
        return True

    def _choose_filter(self):
        """All / Movies / Series / Anime in a box; True when another was picked."""
        keys = [k for k, _ in FILTERS]
        now = keys.index(self.kind) if self.kind in keys else 0
        pick = xbmcgui.Dialog().select('Show', [label for _, label in FILTERS], preselect=now)
        if pick < 0 or pick == now:
            return False
        self.kind = keys[pick]
        return True

    def _choose_place(self, n):
        """OK on a tile: its sections below, in place - or, for a service not connected, the way to connect it."""
        tile = self._tiles[n] if n < len(self._tiles) else None
        if not tile:
            return
        if not tile['on']:
            if self.over(self._connect, tile):
                self._read_again()
                self._show()
                # connected there, its tile moved up among the connected ones: the cursor goes with it (it stayed on
                # the slot, now another service's) and its sections show below, as an OK on it
                n = self._slot_of(tile['id'])
                self.setFocusId(SLOT_BUTTON + n)
                if self._tiles[n]['on']:
                    self._choose_place(n)
            return
        if getattr(self, 'query', ''):    # a tile chosen: its rows, the search left
            self.query = ''
            if tile['id'] == self.place:
                self._show()
        if tile['id'] != self.place:
            self.place = tile['id']
            self._show()
            self._read_place(self.place)

    @staticmethod
    def _connect(tile):
        """A service not connected (9.1.1): said so, and HUB Settings > Accounts & tracking offered; True when it opened."""
        if not xbmcgui.Dialog().yesno(tile['name'], '%s is not connected. Connect it in HUB Settings › Accounts & tracking?' % tile['name'],
                                      nolabel='Close', yeslabel='Connect'):
            return False
        from .settings import tracking_accounts
        tracking_accounts()
        return True

    # ---- the services read again, behind the screen --------------------------------------------
    def _start_refresh(self):
        if self._refresh is not None or getattr(self, '_refreshed', False):
            return
        from .play_jobs import _CATALOG
        place = self.place

        def work():
            from resources.lib import library_sections
            library.refresh_tracking()
            # 8.1.2: and a picture for the titles that arrived without one (the Nuvio
            # account's library is keyed by TMDB id and often carries no artwork)
            library.fill_missing_posters()
            library.learn_ids()          # 9.0.5: one card for a title kept under two ids
            return library_sections.refresh(place)    # 9.1.1: the place shown, its sections
        self._refresh = _CATALOG.submit(work)

    def _read_again(self):
        """After HUB Settings (a service connected or not any more): the services read again, behind."""
        self._refreshed = False
        if self._refresh is None:
            self._start_refresh()

    def _read_place(self, place):
        """A place chosen: its sections read again behind the screen (library_sections.refresh, network)."""
        if place in self._reading:
            return
        from .play_jobs import _CATALOG
        from resources.lib import library_sections
        # JobPool.submit takes the job alone: the place goes in with it (handing it over beside the job raised TypeError on
        # every tile but MegaNexus - nothing was ever read: "simkl, mdblist, anime ne otvara, za svaki pritisak pravi grešku")
        self._reading[place] = _CATALOG.submit(lambda place=place: library_sections.refresh(place))

    def ready(self):
        """Before it opens (9.1.1): its titles read and the services row written, so the row stands with its first tile
        under the cursor from the first picture - it grew in a moment after the screen ("pločica prva odabrana bljesne
        kao povećanje umjesto da je sve spremno na ulazu"). The digits are placed once the window has its controls."""
        self._load()
        self._services_row()

    def tick(self):
        if getattr(self, '_cover_at', 0.0) and time.monotonic() >= self._cover_at:
            self._cover_at = 0.0
            self._covered()
        for place, job in list(self._reading.items()):
            if not job.done():
                continue
            del self._reading[place]
            try:
                changed = job.result()
            except Exception:
                changed = False
            if changed and place == self.place:
                self._show()
        if self._refresh is None or not self._refresh.done():
            return
        future, self._refresh = self._refresh, None
        self._refreshed = True
        try:
            changed = future.result()
        except Exception:
            changed = False
        if self._load() or changed:
            self._show()

    def _row(self, cid):
        index = cid - ROW_BASE
        if not 0 <= index < len(self.rows):
            return None
        cards = self.rows[index][1]
        pos = self.getControl(cid).getSelectedPosition()
        return cards[pos] if 0 <= pos < len(cards) else None

    def _back_from(self, outcome):
        """A title page or a film closed: what it changed (removed, added) is written in place."""
        self.outcome = outcome
        if outcome == 'playing' or isinstance(outcome, dict):
            self.close()
        elif self._load():
            self._show()

    def onClick(self, cid):
        if SLOT_BUTTON <= cid < SLOT_BUTTON + SLOTS:
            self._choose_place(cid - SLOT_BUTTON)
            return
        if cid == HOME_BUTTON:
            self.close()                  # the Library is over Home
            return
        if cid == LIBRARY_BUTTON:
            self._read_again()            # its own name: the services and their titles read again (the cursor stays)
            return
        if cid == HUB_BUTTON:
            self.outcome = 'hub'          # Home goes on to the HUB (home_window, as its own HUB button)
            self.close()
            return
        if cid == SETTINGS_BUTTON:
            from .settings import run
            self.over(run)                # the Library stays visible behind the glass settings
            self._read_again()
            self._show()
            return
        if cid == OPTIONS_BUTTON:
            if self.over(self._choose_options):
                self._show()
            return
        if cid == SEARCH_BUTTON:
            query = xbmcgui.Dialog().input('Search the Library', self.query).strip()
            if query != self.query:
                self.query = query
                self._show()
                if query:
                    self.setFocusId(ROW_BASE)    # the titles found
            return
        card = self._row(cid)
        if card and card.get('browse_all') is not None:
            # 7.0.29: the whole row as a grid
            from .catalog import open_catalog
            title, cards = self._full[card['browse_all']]
            self._leaving = (cid, _identity(card))
            self._back_from(self.child(open_catalog, {
                'label': 'Library · ' + title, 'rows': [dict(c, services=library.shown_places(c.get('services'), self.place))
                                                        for c in cards if c.get('target')]}))
            return
        if not card or not card.get('target'):
            return
        self._leaving = (cid, _identity(card))
        from .details import open_context, plays_directly
        direct = plays_directly(card['target'], card)   # 7.0.44: else the title like on Home (hero); a next episode plays
        self._back_from((self.in_place if direct else self.child)(open_context, card['target'], row=card, hero=not direct))

    def onAction(self, action):
        aid = action.getId()
        self.row_focus()
        if aid in BACK:
            if getattr(self, 'query', ''):  # Back first leaves the search
                self.query = ''
                self._show()
                return
            # 9.1.1: then up to Home in the top bar - it never leaves the Library ("back mora prebacivati na vrh na
            # Home fokus ... a ne smije izaći totalno"); OK there goes back to Home
            self.setFocusId(HOME_BUTTON)
            self.row_focus(HOME_BUTTON)
            return
        card = self._row(self.getFocusId())
        if not card or not card.get('target') or aid not in (117, 101, 1009, 11):
            return
        from .details import context_choice, quick_choice, run_choice, plays_directly
        choice = 'details' if aid == 11 else context_choice(card['target'], card)   # 7.0.36: its page, no Info window
        if not choice:
            return
        if quick_choice(choice, card['target'], card):
            if self._load():
                self._show()
            return
        self._leaving = (self.getFocusId(), _identity(card))
        self._back_from((self.in_place if plays_directly(card['target'], card, choice) else self.child)(
            run_choice, card['target'], choice, card))


def _place_name(place):
    return PLACE_NAMES.get(place) or dict((tid, name) for tid, name, _, _ in library.TRACKERS).get(place, place)


# this box, Nuvio, Trakt, Simkl, MDBList, WeTrakr - as many as the skin has places for
# (review/make_service_marks.py); 9.0.4: it was 5, and WeTrakr, the sixth, never got its count at the top.
# 9.1.1: AniList's and MyAnimeList's only while their place is chosen (library.shown_places)
MARKS = 6


def _services(item, card, place='all'):
    """Where this title lives, as small round marks along the top of the poster.

    8.1.2: it was three name pills stacked down the corner ("Local", "Trakt", "Simkl"),
    110 px wide each - they covered a third of the picture and three was not enough
    anyway. The marks are drawn by the skin from these properties, so a service that is
    added later needs no change there at all.
    """
    marks = [library.service_icon(name) for name in library.shown_places(card.get('services'), place, MARKS)]
    marks = [mark for mark in marks if mark]
    for n in range(MARKS):
        item.setProperty('service.%d' % n, marks[n] if n < len(marks) else '')


def option(setting, choices):
    value = cached_addon().getSetting(setting)
    return value if value in dict(choices) else choices[0][0]


def _shown(cards):
    """The first ROW_CARDS of a row, then "Browse all" (rows of titles only - a
    file of this device or a server episode has no title page for the grid)."""
    if len(cards) <= ROW_CARDS or not all(c.get('target') for c in cards):
        return cards
    # 8.1.2: nothing behind it. It used to borrow the next title's poster, so the card
    # that opens the whole row looked like one particular film - "na browse all mi je
    # Schindler's List poster... treba biti prazan, ne sa posterom nekog filma".
    # 9.1.1: Home's own Browse all picture, no count ("Browse all ne treba prikazivati broj")
    return cards[:ROW_CARDS] + [{'title': 'Browse all', 'poster': home_data.BROWSE_ALL_POSTER,
                                 'landscape': home_data.BROWSE_ALL_LANDSCAPE, 'badges': ['Browse all'], 'browse_all': None}]


LEFT_ON = 'library_place.json'   # 9.1.1: in the profile's folder - the place the Library was left on


def _left_on_path():
    from resources.lib.meganexus.paths import profile_path
    return os.path.join(profile_path(), LEFT_ON)


def left_on():
    """The place the Library was last left on (this profile's), MegaNexus when none."""
    try:
        with open(_left_on_path(), encoding='utf-8') as handle:
            place = json.load(handle).get('place')
    except (OSError, ValueError, AttributeError):
        place = None
    return place if isinstance(place, str) and place else library.MEGANEXUS


def leave_on(place):
    """Kept for the next visit (a file, not a setting: no settings-changed round for every exit)."""
    if place == left_on():
        return
    try:
        from resources.lib.meganexus.json_files import write_json
        write_json(_left_on_path(), {'place': place})
    except Exception:
        pass


def open_library(covered=None):
    """``covered``: called once the Library stands over Home (Home then draws nothing under it)."""
    win = LibraryWindow('meganexus_library.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i',
                        covered=covered)
    try:
        win.ready()
        win.doModal()
        return win.outcome
    finally:
        leave_on(win.place)     # however it was left: the next visit opens there, its tile first
        win.close()
