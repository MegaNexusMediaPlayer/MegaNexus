# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A series' episodes by their rating (9.1.1; NuvioTV #1689).

From the season pills of a series' page: "★ Ratings" opens a grid - a row for each season, a cell for each
episode, coloured by its rating (the metadata add-on's own, else TMDB's as the page's cards show them,
title_details.season_ratings); the episode under the cursor and the best ones above it, OK plays the
episode.

The grid is a Kodi panel of COLUMNS cells a row: the season's name first, then its episodes; a season
with fewer is filled up with empty cells the cursor never stays on (a longer one goes on in the next row).
The colours are the items' own (ListItem.Property(tone)): the themes' recolouring never touches them.
"""
from datetime import date

import xbmcaddon
import xbmcgui

from .dialog import Dialog
from . import listitems
from resources.lib import title_details
from resources.lib.theme import folder as theme_folder

COLUMNS = 27                 # cells a row: the season's name and 26 episodes (review/make_episode_map.py)
PANEL = 600
# IMDb-style: dark green at the top, red at the bottom; grey without a rating
TONES = ((9.0, 'FF1E8A43'), (8.0, 'FF47A84F'), (7.0, 'FFD2A626'), (6.0, 'FFE07A24'), (0.1, 'FFCC3D3D'))
NO_RATING = 'FF4A4F57'
BEST = 3


def tone(rating):
    try:
        value = float(rating or 0)
    except (TypeError, ValueError):
        value = 0.0
    return next((colour for least, colour in TONES if value >= least), NO_RATING)


def _rating(episode):
    try:
        value = float(episode.get('rating') or episode.get('imdbRating') or 0)
    except (TypeError, ValueError):
        value = 0.0
    return value if value > 0 else 0.0


def aired(episode, today=None):
    from resources.lib.release_info import episode_day
    day = episode_day(episode)
    return day is None or day <= (today or date.today())


def cells(meta, ratings=None):
    """[cell] in the grid's order: {'kind': 'season'|'episode'|'empty', 'season', 'episode', 'rating', 'title',
    'id'} - a row of COLUMNS for each season (specials left out), more rows for a long one. ``ratings``:
    {season: {episode: rating}} found later (title_details.season_ratings) over the episodes' own."""
    ratings = ratings or {}
    out = []
    for season in [s for s in title_details.seasons(meta) if s > 0]:
        rows = title_details.episodes(meta, season)
        for start in range(0, max(1, len(rows)), COLUMNS - 1):
            out.append({'kind': 'season' if not start else 'empty', 'season': season})
            part = rows[start:start + COLUMNS - 1]
            for e in part:
                number = title_details.number(e.get('episode'))
                out.append({'kind': 'episode', 'season': season, 'episode': number, 'id': e.get('id'),
                            'title': str(e.get('title') or e.get('name') or ''), 'aired': aired(e),
                            'rating': (ratings.get(season) or {}).get(number) or _rating(e)})
            out += [{'kind': 'empty', 'season': season}] * (COLUMNS - 1 - len(part))
    return out


def best(grid, most=BEST):
    """The best rated episodes of the grid, the highest first (one of two alike: the earlier)."""
    rated = [c for c in grid if c['kind'] == 'episode' and c['rating']]
    return sorted(rated, key=lambda c: (-c['rating'], c['season'], c['episode']))[:most]


def snap(grid, index):
    """Where the cursor belongs when it lands on ``index``: an episode of that row - the first after the
    season's name, the last before the empty cells."""
    if not grid:
        return 0
    index = max(0, min(index, len(grid) - 1))
    if grid[index]['kind'] == 'episode':
        return index
    row = index - index % COLUMNS
    episodes = [i for i in range(row, min(row + COLUMNS, len(grid))) if grid[i]['kind'] == 'episode']
    if not episodes:
        return index
    before = [i for i in episodes if i <= index]
    return before[-1] if before and index != row else episodes[0]


def text(cell):
    return 'S%s E%s%s' % (cell['season'], cell['episode'], ('  ·  ' + cell['title']) if cell.get('title') else '')


class EpisodeMap(Dialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.meta = kwargs['meta']
        self.grid = cells(self.meta)
        self.choice = None
        self._shown = -1
        self._jobs = []

    def onInit(self):
        m = self.meta
        self.setProperty('meganexus.map.title', str(m.get('name') or m.get('title') or ''))
        logo = m.get('logo') or m.get('clearlogo') or ''
        from resources.lib import art_cache
        self.setProperty('meganexus.map.logo', art_cache.url(logo) if logo else '')
        self.setProperty('meganexus.map.fanart', art_cache.url(m.get('background') or ''))
        items = []
        for cell in self.grid:
            li = listitems.item(label='S%s' % cell['season'] if cell['kind'] == 'season' else '')
            li.setProperty('kind', cell['kind'])
            if cell['kind'] == 'episode':
                self._paint(li, cell)
            items.append(li)
        control = self.getControl(PANEL)
        control.reset()
        control.addItems(items)
        control.selectItem(snap(self.grid, 1))
        self._best()
        self.setFocusId(PANEL)
        self._fill_ratings()

    def _paint(self, li, cell):
        li.setProperty('tone', tone(cell['rating']))
        li.setProperty('rating', '%.1f' % cell['rating'] if cell['rating'] else '–')
        li.setProperty('soon', '' if cell.get('aired', True) else '1')

    def _best(self):
        top = best(self.grid)
        self.setProperty('meganexus.map.best', '   ·   '.join('%s  ★ %.1f' % (text(c), c['rating']) for c in top))

    def _fill_ratings(self):
        """The ratings the episodes do not carry (TMDB through title_details), season by season, behind."""
        missing = sorted({c['season'] for c in self.grid if c['kind'] == 'episode' and not c['rating']})
        if not missing:
            return
        from .play_jobs import _BACKGROUND

        def work(season):
            try:
                found = title_details.season_ratings(self.meta, season)
            except Exception:
                found = {}
            if found and not self._dialog_closed:
                self._events.put(lambda: self._apply(season, found))   # drawn by the window's own loop
        for season in missing:
            self._jobs.append(_BACKGROUND.submit(lambda season=season: work(season)))

    def _apply(self, season, found):
        control = self.getControl(PANEL)
        for index, cell in enumerate(self.grid):
            if cell['kind'] == 'episode' and cell['season'] == season and not cell['rating'] and found.get(cell['episode']):
                cell['rating'] = found[cell['episode']]
                try:
                    self._paint(control.getListItem(index), cell)
                except Exception:
                    return
        self._best()
        self._shown = -1

    def tick(self):
        try:
            control = self.getControl(PANEL)
            index = control.getSelectedPosition()
        except Exception:
            return
        right = snap(self.grid, index)
        if right != index:
            control.selectItem(right)
            index = right
        if index == self._shown or not 0 <= index < len(self.grid):
            return
        self._shown = index
        cell = self.grid[index]
        if cell['kind'] == 'episode':
            self.setProperty('meganexus.map.focus', text(cell))
            self.setProperty('meganexus.map.rating', ('★ %.1f' % cell['rating']) if cell['rating'] else 'No rating yet')

    def onClick(self, cid):
        if cid != PANEL:
            return
        index = self.getControl(PANEL).getSelectedPosition()
        if 0 <= index < len(self.grid) and self.grid[index]['kind'] == 'episode':
            self.choice = (self.grid[index]['season'], self.grid[index]['episode'])
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()

    def close(self):
        for job in self._jobs:
            job.cancel()
        super().close()


def open_map(meta):
    """(season, episode) chosen in the grid, or None."""
    win = EpisodeMap('meganexus_episode_map.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i',
                     meta=meta)
    try:
        win.doModal()
        return win.choice
    finally:
        win.close()
