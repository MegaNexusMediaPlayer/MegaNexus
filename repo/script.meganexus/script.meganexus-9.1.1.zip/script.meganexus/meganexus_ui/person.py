# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A person, not a mixed catalog: portrait, Movies, then Series. 9.1.1: each row ends in Browse all's own card when it
holds more than it shows - no Back button, no "View all" pills (review/make_person_screen.py)."""
import threading

import xbmc
import xbmcaddon
import xbmcgui
from .dialog import Dialog
from . import listitems
from resources.lib import art_cache, home_data, title_details
from resources.lib.display_text import clean
from resources.lib.theme import folder as theme_folder


SHOWN = title_details.PERSON_CARDS   # a row's cards (their posters asked for); Browse all after them opens all
AT_ONCE = title_details.PERSON_AT_ONCE   # the cards seen when the page opens: their posters came with the page
ROWS = ((500, 'movies'), (501, 'series'))
MONTHS = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November',
          'December')


def _day(value):
    """(date, its 'D Month YYYY') of TMDB's 'YYYY-MM-DD'; (None, '') when it is not one."""
    import datetime
    try:
        day = datetime.date(*(int(v) for v in str(value).split('-')[:3]))
    except (TypeError, ValueError):
        return None, ''
    return day, '%d %s %d' % (day.day, MONTHS[day.month - 1], day.year)


def _years(start, end):
    return end.year - start.year - ((end.month, end.day) < (start.month, start.day))


def facts(person):
    """9.1.1: what is known of the person in one line - their department, born (where, how old), died (at what age)
    ("vrijeme rođenja i smrti ako ima"); only what TMDB gave."""
    import datetime
    parts = [clean(person.get('role') or 'Filmography')]
    born, born_text = _day(person.get('born'))
    died, died_text = _day(person.get('died'))
    place = clean(person.get('place') or '')
    if born:
        age = '' if died else ' (%d)' % _years(born, datetime.date.today())
        parts.append('Born %s%s%s' % (born_text, (' in ' + place) if place else '', age))
    elif place:
        parts.append('From ' + place)
    if died:
        parts.append('Died %s%s' % (died_text, (', aged %d' % _years(born, died)) if born else ''))
    return '  ·  '.join(parts)


class Person(Dialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.page = kwargs['page']
        self.outcome = ''
        self.positions = {500: 0, 501: 0}
        self._filling = None

    def onInit(self):
        person = self.page['person']
        self.setProperty('meganexus.person.name', clean(person.get('name')))
        self.setProperty('meganexus.person.photo', art_cache.url(person.get('photo') or 'special://home/addons/script.meganexus/resources/media/person.png'))
        self.setProperty('meganexus.person.facts', facts(person))
        self.setProperty('meganexus.person.bio', clean(person.get('biography') or ''))   # TMDB's, when it has one
        for cid, kind in ROWS:
            rows = self.page[kind]
            self.setProperty('meganexus.person.' + kind, str(len(rows)))
            self.getControl(cid).reset()
            items = []
            for row in rows[:SHOWN]:
                item = listitems.item(label=clean(row.get('title')), label2=clean(row.get('subtitle')))
                item.setArt({'poster': art_cache.card(row.get('poster') or row.get('fanart'))})
                items.append(item)
            if len(rows) > SHOWN:
                more = home_data.browse_all_card('')
                item = listitems.item(label=more['title'])
                item.setArt({'poster': more['poster']})
                items.append(item)
            if not items:
                items = [listitems.item(label='No %s returned' % kind)]
            self.getControl(cid).addItems(items)
            self.getControl(cid).selectItem(min(self.positions[cid], len(items)-1))
        self.focus(501 if self.page['series'] and not self.page['movies'] else 500)
        self.restore_focus()
        if getattr(self, '_filling', None) is None:   # once - onInit comes again after a title opened from here
            self._filling = threading.Thread(target=self.fill_posters, name='MegaNexusPersonPosters', daemon=True)
            self._filling.start()

    def fill_posters(self):
        """9.1.1: the posters past the first screen, from the artwork provider, while those cards are out of sight -
        the page came with the first ones only (title_details.person_page); a card is changed only when its poster
        did (on the window's own loop: defer). Then the rest of each row for Browse all, from the cache."""
        stopped = lambda: self._dialog_closed or xbmc.Monitor().abortRequested()
        for cid, kind in ROWS:
            rows = self.page[kind]
            if len(rows) <= AT_ONCE:
                continue
            got = home_data._artwork(rows[AT_ONCE:SHOWN], stopped=stopped, kinds=('poster',))
            for at, row in enumerate(got, AT_ONCE):
                if stopped():
                    return
                if row.get('poster') != rows[at].get('poster'):
                    rows[at] = row
                    self.defer(lambda cid=cid, at=at, row=row: self._poster(cid, at, row))
        for _cid, kind in ROWS:
            rows = self.page[kind]
            if len(rows) > SHOWN and not stopped():
                rows[SHOWN:] = home_data._artwork(rows[SHOWN:], cached_only=True, stopped=stopped, kinds=('poster',))

    def _poster(self, cid, at, row):
        try:
            self.getControl(cid).getListItem(at).setArt({'poster': art_cache.card(row.get('poster') or row.get('fanart'))})
        except (RuntimeError, IndexError):
            pass   # the page is going

    def onClick(self, cid):
        if cid in (500, 501):
            kind = 'movies' if cid == 500 else 'series'
            rows = self.page[kind]
            self.positions[cid] = self.getControl(cid).getSelectedPosition()
            if self.positions[cid] == SHOWN and len(rows) > SHOWN:
                # Browse all: the whole row as posters
                from .catalog import open_catalog
                self.outcome = self.child(open_catalog, {'label': clean(self.page['person'].get('name')) + ' · ' + kind.title(),
                                                         'rows': rows})
            elif rows and self.positions[cid] < min(len(rows), SHOWN):
                self.outcome = self._open(rows[self.positions[cid]])
        if self.outcome == 'playing' or isinstance(self.outcome, dict):
            self.close()

    def _open(self, row):
        """A title of a row: played at once when it plays directly, else its page (as on Home)."""
        from .details import open_context, plays_directly
        direct = plays_directly(row['target'], row)   # 7.0.44: else the title like on Home (hero)
        return (self.in_place if direct else self.child)(open_context, row['target'], row=row, hero=not direct)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()


def open_page(page):
    win = Person('meganexus_person.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),
                 theme_folder(),'1080i', page=page)
    try:
        win.doModal()
        return win.outcome
    finally:
        win.close()
