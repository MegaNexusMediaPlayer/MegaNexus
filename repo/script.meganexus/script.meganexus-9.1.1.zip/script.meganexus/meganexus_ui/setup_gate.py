# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Entry into MegaNexus is never blocked (6.0.15).

With nothing configured - no Nuvio import, no metadata add-on, no collections -
the MegaNexus Catalog Addon supplies metadata and a default Home layout. Collections, add-ons and
accounts are changed in Settings at any time; an unavailable catalog simply
stays empty on Home.
"""
import xbmcgui
from resources.lib import collection_profile, default_setup, metadata_providers, stream_providers


def ready():
    return bool(collection_profile.load())


def offer_switch_on(module, kind, dialog=None):
    """All installed add-ons of one kind are OFF: offer to turn them on."""
    available = module.candidates()
    if not available or module.enabled():
        return False
    dialog = dialog or xbmcgui.Dialog()
    names = ', '.join(p.get('name') or p['id'] for p in available[:4])
    if len(available) > 4:
        names += ' …'
    if not dialog.yesno('MegaNexus', 'All %s add-ons are switched OFF.\nTurn ON: %s?' % (kind, names)):
        return False
    for provider in available:
        module.set_enabled(provider['id'], True)
    return True


def ensure_defaults(job=None):
    """Automatic layout and the built-in catalog add-on's switch (rules in default_setup).
    Failures (offline) never block entry; the bundled manifest is used offline."""
    import xbmcaddon
    from resources.lib.meganexus import addon_registry

    def run(work, label):
        return job(work, label=label) if job else work()
    try:
        # 9.0.4: Cinemeta becomes it. 9.1.1: behind the loading screen only when there is one - every entry
        # opened that screen for a moment with nothing to do, before the opening screen ("refreša mi ekran s
        # kratkim pozadinskim loadom pa se ispod pojavi normalni loading naš")
        if default_setup.cinemeta() is not None:
            run(default_setup.replace_cinemeta, 'Setting up the MegaNexus Catalog')
    except (ValueError, OSError):
        pass
    try:
        default_setup.apply_defaults(xbmcaddon.Addon('plugin.video.meganexus'), addon_registry.list_providers(),
                                     collection_profile.load(), collection_profile.save,
                                     lambda: run(default_setup.install_builtin, 'Setting up the MegaNexus Catalog'),
                                     lambda: run(default_setup.add_builtin_off, 'Adding the MegaNexus Catalog'))
    except (ValueError, OSError):
        pass


def ensure_ready():
    # 6.0.35: the one-time 6.0.12 "keep one stream add-on" repair is gone. On a
    # fresh install it ran after the phone setup and switched off add-ons the
    # user had just chosen (GitHub issue #3).
    try:
        from resources.lib import sports
        sports.ensure_enabled()   # sports add-ons: metadata and streams ON
    except Exception:
        pass
    from .play_jobs import job
    ensure_defaults(job)
    offer_switch_on(metadata_providers, 'metadata')
    return True
