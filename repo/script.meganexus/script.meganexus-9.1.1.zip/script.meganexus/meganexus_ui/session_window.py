# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Retained native base window for a frontend session.

Dialogs may close while the native fullscreen player owns input. Kodi returns
first to this ordinary WindowXML, NOT to the launcher's HUB window. The caller
then restores its existing Details/Catalog/Home objects and selection. This
base has no routing/timers and never starts another frontend instance.
"""
import threading
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.theme import folder as theme_folder


class SessionWindow(xbmcgui.WindowXML):
    def __init__(self, *args):
        super().__init__(*args)
        self.ready = threading.Event()

    def onInit(self):
        self.ready.set()

    def onAction(self, action):
        # A Back received between dialogs must not pop the base back to HUB.
        pass


def scene(art='', title=''):
    window=xbmcgui.Window(10000)
    window.setProperty('meganexus.scene.art', str(art or ''))
    window.setProperty('meganexus.scene.title', str(title or ''))


def has_video_layer(os_release='/etc/os-release'):
    """Boxes that show hardware video on a plane under Kodi's interface
    (CoreELEC/LibreELEC/OSMC and similar, Android). PCs draw video in the GUI."""
    if xbmc.getCondVisibility('System.Platform.Android'):
        return True
    try:
        with open(os_release, encoding='utf-8', errors='replace') as stream:
            text = stream.read().lower()
    except OSError:
        return False
    return any(name in text for name in ('coreelec', 'libreelec', 'osmc', 'alexelec'))


ENTERING='meganexus.entering'   # 9.1.1: Window(Home) - MegaNexus is being entered from the HUB
ENTER_HOLD=.15                  # s the HUB's brighter picture stays before it fades (review/make_entry_fade.py)


def open_session(entering=False):
    """``entering`` (9.1.1): from the HUB - with a wallpaper of your own the HUB shows it brighter than the
    MegaNexus screens, and opening this window halved its light at once ("na ulazu ... bljesak"): it opens with
    the HUB's picture, which fades to the screens' darkening once the window is up."""
    home=xbmcgui.Window(10000)
    # Skin XML adds a black frame over small videos only where Kodi's own
    # translucent shade over the video plane does not show.
    home.setProperty('meganexus.videolayer', '1' if has_video_layer() else '')
    scene()
    if entering:home.setProperty(ENTERING,'1')
    win=SessionWindow('meganexus_session.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(),'1080i')
    win.show()
    monitor=xbmc.Monitor()
    for _ in range(100):
        if win.ready.is_set() or monitor.waitForAbort(.01):
            break
    if entering:
        # drawn once with it first, then the mark goes and the picture darkens (the skin's Hidden fade)
        timer=threading.Timer(ENTER_HOLD,home.clearProperty,(ENTERING,))
        timer.daemon=True
        timer.start()
    return win
