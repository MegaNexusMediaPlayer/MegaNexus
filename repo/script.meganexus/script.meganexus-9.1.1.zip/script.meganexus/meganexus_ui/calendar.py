# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.1: the Calendar - the months as the Library's services row, starting with the month we are in ("gore na vrhu
mora biti u redu prvi mjesec u kojem smo"), a tile for each in its own colour with its year's last two digits beside
it in the big numbers; under it one row of the day, as Home's (its poster cards, the date in the Top 10's big
numbers at the row's left - "samo jedan red, s posterom veličine kao na Home"). What a day holds - what comes out,
then what you finished - is asked from the internet when the day comes (resources/lib/calendar_data.py, "ništa ne
keširaj"), the day before and after asked meanwhile so going there is at once ("sporo je ovo učitavanje"); it is
kept only while the month stays on the screen. Up and Down go to the day before and after and stop at the month's
ends ("od 1 do 30, na 30. stane"); another month only from the months row, and it starts on its 1st. The magnifier
searches the Calendar: a title, when it comes out or came out and when you watched it.

Kodi keeps the cursor's moves to itself (meganexus_ui/dialog.py forwards no move): a month is known from its tile's
focus, a day and the months past the row's ends from the click the skin sends there (SendClick). Every property is
written only when it says something new: each write waits for Kodi's drawing (~25 ms on the Cube), and writing the
row's twelve tiles on every move made it jerk ("micanje gore mjeseci i godina malo refresha, nije glatko"). The
screen: review/make_calendar_screen.py."""
import colorsys
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta

import xbmcaddon
import xbmcgui

from .dialog import Dialog
from . import listitems
from .library import TILE_TOP, digit_places, slot_layout
from .top_row import TopRow
from resources.lib import art_cache, calendar_data, number_colors
from resources.lib.display_text import clean
from resources.lib.settings_snapshot import cached_addon, invalidate as settings_invalidate
from resources.lib.theme import folder as theme_folder

SEARCH_BUTTON, HOME_BUTTON, CALENDAR_BUTTON, OPTIONS_BUTTON, SETTINGS_BUTTON, HUB_BUTTON = 105, 101, 115, 204, 107, 109
# Options: the Calendar's own titles under the cards and its row's title ("samo za taj dio, kao što mogu u Library")
TITLES, ROW_TITLES = 'meganexus_calendar_titles', 'meganexus_calendar_rowtitles'
MONTH_BUTTON, SLOT_GROUP, SLOT_TILE, DIGIT_GROUP, DIGITS, SLOTS = 381, 400, 420, 440, 2, 12
DAY_LIST = 600
YEAR_BEFORE, YEAR_AFTER, DAY_BEFORE, DAY_AFTER = 394, 395, 398, 399
# the months' own colours: their birthstones (review/make_calendar_screen.py draws the tiles in them)
MONTH_COLOURS = ('#9B111E', '#9966CC', '#7FFFD4', '#B9F2FF', '#50C878', '#C9B6E4',
                 '#E0115F', '#B4C424', '#0F52BA', '#F7A8C8', '#F2A93B', '#30D5C8')
YEARS = (1900, 2100)
SETTLE = .25                      # s the cursor rests on a month's tile before its day is drawn
NEUTRAL = 'D9333333'              # a date whose first poster gave no colour: dark, as a Top 10 number without one
DAY_LEFT, OVERLAP, ROW_END = 56, 22, 1880   # the row's left and right; px of the date under the first poster (Top 10's)
COVER_AFTER = .35                 # s it takes to stand before Home under it may stop drawing (as the Library)
ASKING_AT_ONCE = 2                # days asked at the same time
DATES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'resources', 'media', 'calendar',
                     'sizes.json')
_DATE_W = {}


def tint_of(colour):
    """'D9RRGGBB' - a dark, rich version of ``colour`` ('#RRGGBB') for a number's fill, as the Top 10's from a poster."""
    hue, light, sat = colorsys.rgb_to_hls(*(int(colour[i:i + 2], 16) / 255.0 for i in (1, 3, 5)))
    red, green, blue = colorsys.hls_to_rgb(hue, max(0.18, min(light, 0.42)), max(sat, 0.55))
    return 'D9%02X%02X%02X' % tuple(int(round(v * 255)) for v in (red, green, blue))


def date_width(number):
    """The width of the date's picture (calendar/sizes.json, beside the pictures)."""
    if not _DATE_W:
        try:
            with open(DATES, encoding='utf-8') as handle:
                _DATE_W.update(json.load(handle)['date'])
        except (OSError, ValueError, KeyError):
            pass
    return int(_DATE_W.get(str(number), 160))


def shifted(year, month, step):
    """(year, month) ``step`` months on (back when it is less than 0)."""
    index = year * 12 + month - 1 + step
    return index // 12, index % 12 + 1


def day_title(when, today):
    words = '%s %d %s' % (when.strftime('%A'), when.day, when.strftime('%B'))
    if when.year != today.year:
        words += ' %d' % when.year
    return words + ('  ·  Today' if when == today else '')


def last_day(year, month):
    return calendar_data.bounds(year, month)[1].day


def day_held(when, known=None):
    """(what ``when`` holds, its first poster's colour) - asked now (calendar_data.day_rows; the colour as the Top
    10 numbers take theirs, from a small poster)."""
    rows = calendar_data.day_rows(when, known)
    first = next((card.get('poster') for key in ('coming', 'watched') for card in rows.get(key) or [] if card.get('poster')), '')
    return rows, calendar_data.poster_tint(first)


class CalendarWindow(TopRow, Dialog):
    TOP_ROW = (SEARCH_BUTTON, HOME_BUTTON, CALENDAR_BUTTON, OPTIONS_BUTTON, SETTINGS_BUTTON, HUB_BUTTON)

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.today = kwargs.get('today') or date.today()
        self.year, self.month, self.day = self.today.year, self.today.month, self.today.day
        self.first = (self.year, self.month)               # the row's first month
        self.held = dict(kwargs.get('held') or {})          # {date: (rows, tint)} of the month on the screen
        self.known = kwargs.get('known')                    # what the device says (calendar_data.local), once
        self._asked = {}                                    # {date: future} being asked
        self._dressing = {}                                 # {date: future} its cards' logos and plots being asked
        self._items = []                                    # the row's list items, as drawn
        self._pool = None
        self._covered, self._cover_at = kwargs.get('covered'), 0.0
        self.outcome = ''
        self._month_at = None                               # (the slot the cursor came to, when)
        self._placed = {}                                   # slot -> the digits it stands for
        self._said = {}
        self._drawn = None                                  # (the day, what it held) the row shows
        self._leaving = None

    def _say(self, key, value, home=False):
        """A property written only when it is new (as the Library's)."""
        if self._said.get((home, key)) == value:
            return
        self._said[(home, key)] = value
        (xbmcgui.Window(10000) if home else self).setProperty(key, value)

    # --- drawing -----------------------------------------------------------------------------------------------
    def onInit(self):
        keep, self._leaving = getattr(self, '_leaving', None), None
        self._said, self._placed, self._drawn = {}, {}, None   # set up anew: nothing of it is there any more
        self._flags()
        self._months()
        self._day()
        if not getattr(self, '_focused_once', False):
            self._focused_once = True
            if self._covered:
                self._cover_at = time.monotonic() + COVER_AFTER
            self.focus(DAY_LIST)
        elif keep:
            self.getControl(DAY_LIST).selectItem(keep)
            self.setFocusId(DAY_LIST)
        else:
            self.restore_focus()
        self.row_focus()

    def onFocus(self, control_id):
        self.row_focus(control_id)
        if MONTH_BUTTON <= control_id < MONTH_BUTTON + SLOTS:
            self._month_at = (control_id - MONTH_BUTTON, time.monotonic())

    def _chosen(self):
        """The slot of the month shown (None when it is not in the row)."""
        at = (self.year * 12 + self.month) - (self.first[0] * 12 + self.first[1])
        return at if 0 <= at < SLOTS else None

    def _months(self):
        """The months row: each slot's month, its year's two digits and their colour (the tile's own, or the Big
        numbers colour chosen), where they stand - written only where they changed - and the month shown."""
        for n in range(SLOTS):
            year, month = shifted(self.first[0], self.first[1], n)
            digits = '%02d' % (year % 100)
            self._say('meganexus.cal.m%d.n' % n, str(month))
            for k in range(DIGITS):
                self._say('meganexus.cal.m%d.d%d' % (n, k), digits[k])
            self._say('meganexus.cal.m%d.tint' % n, number_colors.fill(tint_of(MONTH_COLOURS[month - 1])), home=True)
            if self._placed.get(n) != digits:
                self._place(n, digits)
        chosen = self._chosen()
        self._say('meganexus.cal.chosen', '' if chosen is None else str(chosen))

    def _place(self, n, digits):
        tile, width = slot_layout(digits)
        try:
            for k, left in enumerate(digit_places(digits)):
                group = self.getControl(DIGIT_GROUP + DIGITS * n + k)
                group.setPosition(left, group.getY())
            self.getControl(SLOT_TILE + n).setPosition(tile, TILE_TOP)
            self.getControl(SLOT_GROUP + n).setWidth(width)
        except Exception:
            return
        self._placed[n] = digits

    def _day(self):
        """The day's row: its date at the row's left (its cards right after it), what it holds or that it is being
        asked; the days either side asked meanwhile."""
        when = date(self.year, self.month, self.day)
        held = self.held.get(when)
        if self._drawn == (when, held):
            return
        self._drawn = (when, held)
        self._say('meganexus.cal.r0.day', str(self.day))
        self._say('meganexus.cal.r0.title', day_title(when, self.today))
        control = self.getControl(DAY_LIST)
        control.reset()
        left = DAY_LEFT + date_width(self.day) - OVERLAP
        try:
            control.setPosition(left, control.getPosition()[1])
            control.setWidth(ROW_END - left)
        except (RuntimeError, TypeError):
            pass
        if held is None:
            words, tint, cards = 'Asking...', NEUTRAL, []
        else:
            rows, tint = held
            cards = [(card, False) for card in rows.get('coming') or []] + [(card, True) for card in rows.get('watched') or []]
            words = 'Nothing out and nothing watched'
        self._say('meganexus.cal.r0.tint', number_colors.fill(tint or NEUTRAL), home=True)
        # an empty row cannot take the cursor in Kodi (it went up to the months): a card of words holds it, Home's
        # empty card ("fokus kad se otvori kalendar je na datumu dolje, u redu postera s današnjim datumom")
        self._items = [self._item(card, seen) for card, seen in cards]
        control.addItems(self._items or [self._words(words)])
        if held is not None:
            self._dress(when, [card for card, _seen in cards])
        last = last_day(self.year, self.month)
        for number in (self.day, self.day + 1, self.day - 1):
            if 1 <= number <= last:
                self._ask(date(self.year, self.month, number))

    @staticmethod
    def _item(card, seen):
        """A card as Home's: the poster, the title under it, its line on it (S1 E2, Movie, the hour), the watched
        mark on what was watched - and for the top, as Home's: its logo, background, words and plot."""
        item = listitems.item(label=clean(card.get('title')))
        CalendarWindow._dressed(item, card)
        listitems.properties(item, {'airing_banner': clean(card.get('subtitle')), 'watched': '1' if seen else ''})
        return item

    @staticmethod
    def _dressed(item, card):
        item.setArt({'poster': art_cache.card(card.get('poster') or card.get('fanart')), 'fanart': card.get('fanart') or '',
                     'clearlogo': card.get('clearlogo') or ''})
        words = [str(card.get(key) or '') for key in ('year', 'genres', 'subtitle')]
        listitems.properties(item, {'plot': clean(card.get('plot')), 'meta': clean('  ·  '.join(w for w in words if w))})

    def _dress(self, when, cards):
        """The logos and plots TMDB has not told MegaNexus yet, asked once the day is on the screen - put on its cards
        in place when they come (nothing flashes, the cursor stays)."""
        if when in self._dressing or not any(calendar_data.bare(card) for card in cards):
            return
        if self._pool is None:
            self._pool = ThreadPoolExecutor(max_workers=ASKING_AT_ONCE, thread_name_prefix='MegaNexusCalendarDay')
        self._dressing[when] = (cards, self._pool.submit(calendar_data.dress, [dict(card) for card in cards]))

    def _flags(self):
        addon = cached_addon()
        self._say('meganexus.cal.notitles', '1' if addon.getSetting(TITLES) == 'false' else '', home=True)
        self._say('meganexus.cal.norowtitles', '1' if addon.getSetting(ROW_TITLES) == 'false' else '')

    def _choose_options(self):
        """Options: the titles under the cards and the row's title, the Calendar's own (Home's stay as they are)."""
        addon = cached_addon()
        state = lambda key: 'Off' if addon.getSetting(key) == 'false' else 'On'
        rows = [(TITLES, 'Titles under the cards · %s' % state(TITLES)), (ROW_TITLES, 'Row titles · %s' % state(ROW_TITLES))]
        pick = xbmcgui.Dialog().select('Options', [label for _key, label in rows])
        if pick < 0:
            return
        setting = rows[pick][0]
        addon.setSetting(setting, 'true' if addon.getSetting(setting) == 'false' else 'false')
        settings_invalidate()

    @staticmethod
    def _words(words):
        """The card of a day with nothing (yet): the words in the poster's place, no title under it."""
        item = listitems.item(label=words)
        listitems.properties(item, {'hide_title': '1'})
        return item

    # --- asking ------------------------------------------------------------------------------------------------
    def _ask(self, when):
        if when in self._asked or when in self.held:
            return
        if self._pool is None:
            self._pool = ThreadPoolExecutor(max_workers=ASKING_AT_ONCE, thread_name_prefix='MegaNexusCalendarDay')
        self._asked[when] = self._pool.submit(day_held, when, self.known)

    def tick(self):
        if self._cover_at and time.monotonic() >= self._cover_at:
            self._cover_at = 0.0
            self._covered()
        if self._month_at and time.monotonic() - self._month_at[1] >= SETTLE:
            slot, _since = self._month_at
            self._month_at = None
            year, month = shifted(self.first[0], self.first[1], slot)
            if (year, month) != (self.year, self.month):
                self._go(year, month)
        done = [when for when, future in self._asked.items() if future.done()]
        for when in done:
            future = self._asked.pop(when)
            try:
                held = future.result()
            except Exception:
                held = ({}, '')
            if (when.year, when.month) == (self.year, self.month):
                self.held[when] = held
        if date(self.year, self.month, self.day) in done:
            self._day()
        for when in [when for when, (_cards, future) in self._dressing.items() if future.done()]:
            cards, future = self._dressing.pop(when)
            try:
                dressed = future.result()
            except Exception:
                continue
            for card, new in zip(cards, dressed):
                card.update(new)                  # kept with the day: going back to it shows them at once
            if self._drawn and self._drawn[0] == when:
                for item, card in zip(self._items, cards):
                    self._dressed(item, card)

    # --- moving ------------------------------------------------------------------------------------------------
    def _go(self, year, month, number=1):
        """To ``month`` of ``year`` on its ``number``th (the 1st when another month is chosen); what was held of the
        month before is let go."""
        year = min(max(int(year), YEARS[0]), YEARS[1])
        if (year, month) != (self.year, self.month):
            self.held = {}
        self.year, self.month = year, month
        self.day = min(int(number), last_day(year, month))
        self._months()
        self._day()

    def onAction(self, action):
        self.row_focus()
        if action.getId() in (9, 10, 92, 216):
            # Back goes up to Home in the top bar, it never leaves the Calendar ("back mora prebacivati na vrh na
            # Home fokus ... a ne smije izaći totalno"); OK there goes back to Home
            self.setFocusId(HOME_BUTTON)
            self.row_focus(HOME_BUTTON)

    def onClick(self, cid):
        if cid == HOME_BUTTON:
            self.close()
        elif cid == HUB_BUTTON:
            self.outcome = 'hub'          # Home goes on to the HUB (as from the Library)
            self.close()
        elif cid == SETTINGS_BUTTON:
            from .settings import run
            self.over(run)
            self._said = {}               # (the Big numbers colour may be another now)
            self._months()
            self._drawn = None
            self._day()
        elif cid == SEARCH_BUTTON:
            self._search()
        elif cid == OPTIONS_BUTTON:
            self.over(self._choose_options)
            self._flags()
        elif cid == CALENDAR_BUTTON:      # its own name: back to today, the row from this month
            self.first = (self.today.year, self.today.month)
            self._go(self.today.year, self.today.month, self.today.day)
            self.setFocusId(DAY_LIST)
        elif cid == YEAR_BEFORE:          # Left past the row's first: the twelve months before
            self.first = shifted(self.first[0], self.first[1], -SLOTS)
            self._months()
            self.setFocusId(MONTH_BUTTON + SLOTS - 1)
        elif cid == YEAR_AFTER:           # Right past its last: the twelve after
            self.first = shifted(self.first[0], self.first[1], SLOTS)
            self._months()
            self.setFocusId(MONTH_BUTTON)
        elif MONTH_BUTTON <= cid < MONTH_BUTTON + SLOTS:
            self._month_at = None
            self._go(*shifted(self.first[0], self.first[1], cid - MONTH_BUTTON))
            self.setFocusId(DAY_LIST)
        elif cid == DAY_BEFORE:           # Up: the day before - from the 1st, up to the month's tile
            if self.day > 1:
                self.day -= 1
                self._day()
            else:
                chosen = self._chosen()
                self.setFocusId(MONTH_BUTTON + (chosen or 0))
        elif cid == DAY_AFTER:            # Down: the next day; at the month's last it stays
            if self.day < last_day(self.year, self.month):
                self.day += 1
                self._day()
        elif cid == DAY_LIST:
            self._card()

    def _card(self):
        when = date(self.year, self.month, self.day)
        rows = (self.held.get(when) or ({}, ''))[0]
        cards = (rows.get('coming') or []) + (rows.get('watched') or [])
        position = self.getControl(DAY_LIST).getSelectedPosition()
        if not 0 <= position < len(cards):
            return
        self._leaving = position
        from .details import open_context, plays_directly
        card = cards[position]
        direct = plays_directly(card['target'], card)
        self.outcome = (self.in_place if direct else self.child)(open_context, card['target'], row=card, hero=not direct)
        if self.outcome == 'playing' or isinstance(self.outcome, dict):
            self.close()

    def _search(self):
        """The magnifier: a title - when it comes out or came out, and when you watched it; the day chosen opens,
        the months row from its month."""
        query = xbmcgui.Dialog().input('Search the Calendar').strip()
        if not query:
            return
        from .play_jobs import job
        try:
            found = job(lambda: calendar_data.search(query), label='Calendar · %s' % query, quiet=True) or []
        except Exception:
            found = []
        if not found:
            xbmcgui.Dialog().notification('Calendar', 'Nothing found for "%s"' % query, time=3000)
            return
        items = []
        for _when, words, card in found:
            item = listitems.item(label=clean(card.get('title')), label2=words)
            item.setArt({'thumb': art_cache.card(card.get('poster')), 'poster': art_cache.card(card.get('poster'))})
            items.append(item)
        pick = xbmcgui.Dialog().select('Calendar · %s' % query, items, useDetails=True)
        if pick < 0:
            return
        when = found[pick][0]
        self.first = (when.year, when.month)
        self._go(when.year, when.month, when.day)
        self.setFocusId(DAY_LIST)

    def close(self):
        if getattr(self, '_pool', None) is not None:
            self._pool.shutdown(wait=False)
        super().close()


_AHEAD = {'day': None, 'at': 0.0, 'done': None, 'answer': None}
AHEAD_FOR = 120                   # s today's day asked ahead stays good for an opening


def _first(today):
    known = calendar_data.local()
    return known, {today: day_held(today, known)}


def prepare():
    """Today's day asked ahead while the cursor stands on Home's Calendar ("prespor je otvaranje ... otvaranje bi
    trebalo biti super brzo"): the click then finds it there and the Calendar opens at once. It is asked anew for an
    opening more than AHEAD_FOR later, nothing is kept beyond that."""
    today = date.today()
    if _AHEAD['day'] == today and time.monotonic() - _AHEAD['at'] < AHEAD_FOR:
        return
    done = threading.Event()
    _AHEAD.update(day=today, at=time.monotonic(), done=done, answer=None)

    def work():
        try:
            answer = _first(today)
            if _AHEAD['done'] is done:              # not overtaken by a later prepare
                _AHEAD['answer'] = answer
        except Exception:
            pass
        finally:
            done.set()
    threading.Thread(target=work, name='MegaNexusCalendarAhead', daemon=True).start()


def _ahead(today):
    """What prepare() asked for ``today`` - waiting for it when it is on its way; None when there is none fresh."""
    done = _AHEAD.get('done')
    if _AHEAD['day'] != today or done is None or time.monotonic() - _AHEAD['at'] >= AHEAD_FOR:
        return None
    done.wait(15)
    answer, _AHEAD['day'] = _AHEAD.get('answer'), None    # used once: the next opening asks anew
    return answer


def open_calendar(covered=None):
    """The Calendar over Home: today's titles there before it shows - asked ahead while the cursor was on Calendar
    (prepare), else now with Home staying as it is meanwhile (the small "loading" at its foot, no empty loading
    screen - "ulaz u kalendar krene loading na praznom ekranu umjesto da direkt s Home uđe bez bljeskanja Homea")."""
    from .play_jobs import job
    today = date.today()
    done = _AHEAD.get('done')
    answer = _ahead(today) if done is not None and done.is_set() else None    # there already: no loading at all
    if answer is None:
        try:
            answer = job(lambda: _ahead(today) or _first(today), label='Calendar', quiet=True)
        except Exception:
            answer = (None, {})
    if answer is None:                   # Back meanwhile
        return ''
    known, held = answer
    win = CalendarWindow('meganexus_calendar.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(),
                         '1080i', today=today, held=held, known=known, covered=covered)
    try:
        win.doModal()
        return win.outcome
    finally:
        win.close()
