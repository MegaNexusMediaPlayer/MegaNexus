# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The top row that keeps out of the way, for Sport and IPTV (8.1.3), the Library and the Calendar - as on Home.

It is there while the cursor is on it and goes the moment the cursor leaves. 9.1.1: standing on it, it stays ("ako
se stoji na njoj ne smije nestati, kao na Homeu dok stojim tu stoji, tek nestane kad se maknem") - it went after five
seconds there and came back with the next press. The skin slides everything in the row up while the window's own
property is empty (review/make_screen_tops.py). It is the window's own property, not Home's: Home keeps its row in
step with Python, and another screen writing it would leave Home out of step.
"""

ROW_PROPERTY = 'meganexus.toprow'


class TopRow(object):
    TOP_ROW = ()

    def _row_show(self, shown):
        if getattr(self, '_row_shown', None) is shown:
            return
        self._row_shown = shown
        self.setProperty(ROW_PROPERTY, '1' if shown else '')

    def row_focus(self, control_id=None):
        """The cursor moved (``control_id``) or a key was pressed: the row while the cursor is on it."""
        try:
            where = control_id if control_id is not None else self.getFocusId()
        except Exception:
            return
        self._row_show(where in self.TOP_ROW)
