# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.4: the HUB's Plex, Jellyfin and Emby apps - each MegaNexus' own Home, with its server in it ("svaka u svoj dio,
ponasanje i izgled kao na meganexus home").

The same screen as Home and the YouTube app: its rows go round, the top bar slides away, the card under the cursor at
the top. Its rows are the server's own (resources.lib.media_apps): Plex's home hubs, Jellyfin's / Emby's Continue
Watching, Next Up and each library's Latest, then every library, which goes on as the cursor nears its end. The posters
come through MegaNexus' picture path and cache, as Home's do.

The top bar: Home · Libraries (a library's own view: newest, A to Z, not watched) · Options (titles under the cards,
row titles, which rows, only what is not watched) · Settings (the server's account and servers) · HUB. A film or a
series the ids tell opens MegaNexus' title page (the server's copy its first source), the rest plays from the server;
Watch next works over it as on Home (home_window.wait_for_film).
"""
import json
import traceback

import xbmc
import xbmcgui

from resources.lib import art_cache, home_data, media_apps, media_servers, screen_guard, settings_snapshot
from resources.lib.theme import folder as theme_folder
from .home_window import ADDON, BACK, HUB_SETTLE_PLAIN, ROW_BASE, HomeWindow, app_bar, to_player, wait_for_film

HOME = 'app'
LIBRARY = 'app:library:'
SEARCH = 'app:search'
XML = 'meganexus_home.xml'
OPTIONS_BUTTON = 115
CONTEXT = (117, 101, 1009)
APP_TITLES = 'meganexus.app.titles'      # Window(Home): its titles under the cards on / off while it is open


def _key(kind, name):
    return 'meganexus_%sapp_%s' % (kind, name)


def _on(kind, name, default=True):
    value = settings_snapshot.cached_addon().getSetting(_key(kind, name))
    return default if value == '' else value == 'true'


def _set(kind, name, value):
    settings_snapshot.cached_addon().setSetting(_key(kind, name), value if isinstance(value, str) else ('true' if value else 'false'))
    settings_snapshot.invalidate()


def hidden(kind):
    try:
        return set(json.loads(settings_snapshot.cached_addon().getSetting(_key(kind, 'hidden')) or '[]'))
    except ValueError:
        return set()


def _shelf(title, job):
    return {'title': title, 'rows': [home_data.placeholder(' ', '')], 'server_app_job': job}


def shelves(kind, view, offered, query=''):
    """Every row of one of the app's views, none asked for yet (the window's workers load them)."""
    if view == SEARCH:
        return [_shelf('Results', ('search', query))]
    if view.startswith(LIBRARY):
        server_id, key, of_kind, title = json.loads(view[len(LIBRARY):])
        return [_shelf(name, job) for name, job in media_apps.library_rows(server_id, key, of_kind, title)]
    off = hidden(kind)
    rows = [_shelf(title, job) for row_id, title, job in offered if row_id not in off]
    return rows or [{'title': media_servers.label(kind), 'rows': [home_data.placeholder(
        'Nothing to show', 'Options > Rows switches rows on; Settings connects a server.')]}]


def _titles(kind, on=None):
    """The app's titles under the cards (Window(Home), as Kodi reads a card's words there); '' gives Home its own back."""
    if on is not None and on != '':
        _set(kind, 'titles', on)
    value = '' if on == '' else ('on' if _on(kind, 'titles') else 'off')
    xbmcgui.Window(10000).setProperty(APP_TITLES, value)
    return value


class ServerWindow(HomeWindow):
    """Home, with a Plex, Jellyfin or Emby server in it."""

    def __init__(self, *args, **kwargs):
        self._kind = kwargs.pop('kind')
        self._offered = kwargs.pop('offered')
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('meganexus.app', self._kind)       # its logo and top (review/make_app_home.py)
        super().onInit()
        try:
            self.getControl(106).setLabel('Libraries')
            self.getControl(OPTIONS_BUTTON).setLabel('Options')
            app_bar(self, options=True)
        except Exception:
            pass

    def _row_titles(self):
        return _on(self._kind, 'rowtitles')

    def drain_updates(self):
        super().drain_updates()
        if not self._closed:
            self._hero_tick()

    def _hero_tick(self):
        """The app's top (review/make_app_home.py): the card under the cursor - its title, its line, what it is about,
        its picture - set only when the card changes; on the top bar the last card stays."""
        control_id, pos, _ = self._selection()
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves):
            return
        rows = self._shelves[index].get('rows') or []
        card = rows[pos] if 0 <= pos < len(rows) else {}
        key = self._identity(card) if card else None
        if key == getattr(self, '_hero_key', None):
            return
        self._hero_key = key
        fanart = card.get('fanart') or ''
        for name, value in (('title', card.get('title')), ('meta', card.get('meta_line')), ('plot', card.get('plot')),
                            ('fanart', art_cache.url(fanart) if fanart else '')):     # MegaNexus' picture path and cache
            self.setProperty('meganexus.app.' + name, str(value or '').strip())

    # ---- rows ----------------------------------------------------------------------------------------
    def _load(self, index, shelf, generation):
        job = shelf.get('server_app_job')
        if not job:
            return super()._load(index, shelf, generation)
        if self._closed or generation != self._generation:
            return
        total = 0
        try:
            found, total = media_apps.cards(self._kind, job, 0, media_apps.PAGE, _on(self._kind, 'unwatched', False))
            rows = found or [home_data.placeholder('Nothing here', 'The server has nothing for this row.')]
        except Exception:
            xbmc.log('[MegaNexus] %s row did not load: %s' % (media_servers.label(self._kind), traceback.format_exc(limit=2)),
                     xbmc.LOGWARNING)
            found, rows = [], [dict(home_data.placeholder('The server did not answer', 'Select to ask again.'),
                                    server_app={'retry': True})]
        if not self._closed and generation == self._generation:
            shelf['_app_count'], shelf['_app_total'] = len(found), total
            live = self._shelves[index] if 0 <= index < len(self._shelves) else {}
            if live.get('server_app_job') == job and live.get('_ring_g') == shelf.get('_ring_g'):
                live['_app_count'], live['_app_total'] = len(found), total     # _grows reads the row Home holds
            g = shelf.get('_ring_g')
            if g is not None and 0 <= g < len(self._pages) and self._pages[g].get('server_app_job') == job:
                self._pages[g].update(rows=rows, _loaded=True, _app_count=len(found), _app_total=total)
            self._updates.put((generation, index, rows, None, g))

    def _grows(self, shelf):
        job = shelf.get('server_app_job')
        if not job:
            return super()._grows(shelf)
        return job[0] == 'library' and 0 < shelf.get('_app_count', 0) < shelf.get('_app_total', 0) and not shelf.get('_grow_done')

    def _grow_what(self, shelf):
        return shelf.get('server_app_job') or super()._grow_what(shelf)

    def _grow(self, index, params, jobs, generation, g=None):
        if not isinstance(params, tuple):
            return super()._grow(index, params, jobs, generation, g)
        shelf = self._shelves[index]
        count = shelf.get('_app_count', 0)
        try:
            rows, total = media_apps.cards(self._kind, params, count, media_apps.PAGE, _on(self._kind, 'unwatched', False))
            shelf['_app_count'], shelf['_app_total'] = count + len(rows), total
            done = [{'done': not rows or count + len(rows) >= total}]
        except Exception:
            xbmc.log('[MegaNexus] %s row did not go on: %s' % (media_servers.label(self._kind), traceback.format_exc(limit=2)),
                     xbmc.LOGWARNING)
            rows, done = [], None
        if not self._closed and generation == self._generation:
            self._grown.put((generation, index, rows, done, g))

    def _paint_rows(self, shelves):
        super()._paint_rows(shelves)
        self.setProperty('meganexus.search.query', getattr(self, '_app_query', '') if self._bucket == SEARCH else '')

    def _card(self, control_id):
        if not ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            return None, -1
        index = control_id - ROW_BASE
        rows = self._shelves[index].get('rows') or []
        pos = self.getControl(control_id).getSelectedPosition()
        return (rows[pos] if 0 <= pos < len(rows) else None), index

    def _go(self, view, query=None):
        """Another of the app's views, drawn in this screen."""
        if query is not None:
            self._app_query = query
        self._bucket = view
        self._focus_memory.pop(view, None)
        self._paint(shelves(self._kind, view, self._offered, getattr(self, '_app_query', '')))

    # ---- keys ------------------------------------------------------------------------------------------
    def onClick(self, control_id):
        self._touch()
        if control_id == 101:
            if self._bucket != HOME:
                self._go(HOME)
            return
        if control_id in (105, 111):
            return self._search()
        if control_id == 106:
            return self._libraries()
        if control_id == 107:
            return self._settings_page()
        if control_id == OPTIONS_BUTTON:
            return self._choose_options()
        row, index = self._card(control_id)
        if row is not None and (row.get('server_app') or {}).get('retry'):
            self._shelves[index]['_loaded'] = False
            self._scheduled.discard(index)
            return
        super().onClick(control_id)           # a card (title page / the server plays it), the HUB, the film waiting

    def onAction(self, action):
        if action.getId() in BACK:
            self._touch()
            if self._bucket != HOME:
                self._go(HOME)
            else:
                self.setFocusId(108)          # on the app's Home: to its HUB button, as the YouTube app
            return
        super().onAction(action)

    def _search(self):
        self._suspended = True
        try:
            query = xbmcgui.Dialog().input('Search %s' % media_servers.label(self._kind), getattr(self, '_app_query', '')).strip()
        finally:
            self._suspended = False
        if query:
            self._go(SEARCH, query)

    def _libraries(self):
        self._suspended = True
        try:
            found = media_apps.libraries_of(self._kind)
            if not found:
                xbmcgui.Dialog().notification(media_servers.label(self._kind), 'No movie or series libraries on the server.', time=4000)
                return
            pick = xbmcgui.Dialog().select('Libraries', [title for _sid, _key, _kind, title in found])
        finally:
            self._suspended = False
        if pick >= 0:
            self._go(LIBRARY + json.dumps(list(found[pick])))

    def _settings_page(self):
        """The server's own page: its account, its servers, switching it on and off."""
        from . import media_servers as page
        self._suspended = True
        try:
            self.over(getattr(page, self._kind))
        finally:
            self._suspended = False
        if not media_servers.signed_in(self._kind):
            self._pending = 'hub'
            self._leaving = True
            return
        media_apps.forget()
        self._offered = media_apps.offered(self._kind)
        self._go(self._bucket or HOME)

    def _choose_options(self):
        """The app's Options: its titles under the cards and its row titles, which rows it shows, only what is not watched."""
        state = lambda on: 'On' if on else 'Off'
        kind = self._kind
        choices = [('titles', 'Titles under the cards · %s' % state(_on(kind, 'titles'))),
                   ('rowtitles', 'Row titles · %s' % state(_on(kind, 'rowtitles'))),
                   ('rows', 'Rows · %d of %d' % (len([r for r in self._offered if r[0] not in hidden(kind)]), len(self._offered))),
                   ('unwatched', 'Libraries show · %s' % ('Only what is not watched' if _on(kind, 'unwatched', False) else 'Everything'))]
        self._suspended = True
        try:
            pick = xbmcgui.Dialog().select('Options', [label for _key, label in choices])
            if pick < 0:
                return
            what = choices[pick][0]
            if what == 'titles':
                _titles(kind, not _on(kind, 'titles'))
            elif what == 'rowtitles':
                _set(kind, 'rowtitles', not _on(kind, 'rowtitles'))
                for index, shelf in enumerate(self._shelves[:home_data.MAX_ROWS]):
                    self._row_look(index, shelf, _on(kind, 'rowtitles'))
            elif what == 'rows':
                self._choose_rows()
            elif what == 'unwatched':
                _set(kind, 'unwatched', not _on(kind, 'unwatched', False))
                self._go(self._bucket or HOME)
        finally:
            self._suspended = False

    def _choose_rows(self):
        """Which rows show - each switched on or off, the new ones the server adds shown."""
        off = hidden(self._kind)
        chosen = xbmcgui.Dialog().multiselect('Rows', [title for _id, title, _job in self._offered],
                                              preselect=[i for i, row in enumerate(self._offered) if row[0] not in off])
        if chosen is None:
            return
        kept = {self._offered[i][0] for i in chosen}
        _set(self._kind, 'hidden', json.dumps(sorted(row[0] for row in self._offered if row[0] not in kept)))
        if self._bucket == HOME:
            self._go(HOME)


def _ready(kind):
    """Signed in and on - else the server's own page first (connect); False when it is still not."""
    if media_servers.signed_in(kind) and media_servers.enabled(kind):
        return True
    from . import media_servers as page
    getattr(page, kind)()
    return media_servers.signed_in(kind) and media_servers.enabled(kind)


def open_server_app(kind):
    if kind not in media_servers.KINDS or not _ready(kind):
        xbmc.executebuiltin('ActivateWindow(Home)')
        return
    from .play_jobs import ring_job
    offered = ring_job(lambda: media_apps.offered(kind)) or []
    monitor = xbmc.Monitor()
    view, query, pending = HOME, '', ''
    _titles(kind)
    try:
        while not monitor.abortRequested():
            window = ServerWindow(XML, ADDON.getAddonInfo('path'), theme_folder(), '1080i', shelves=shelves(kind, view, offered, query),
                                  bucket=view, kind=kind, offered=offered)
            window._app_query = query
            window.setProperty('meganexus.app', kind)        # before it shows: never MegaNexus' wordmark first
            cover = None
            try:
                screen_guard.hold()
                window.show_ready()
                from .trailers import lift_curtain
                lift_curtain()
                while not window._closed and not window._leaving and not monitor.abortRequested():
                    window.drain_updates()
                    monitor.waitForAbort(.05)
                pending, view, query = window._pending, window._bucket or HOME, getattr(window, '_app_query', '')
                offered = window._offered
            finally:
                if getattr(window, '_pending', None) == 'hub':
                    try:
                        from .play_jobs import wait_overlay
                        cover = wait_overlay('', {})
                    except Exception:
                        cover = None
                    xbmc.executebuiltin('ActivateWindow(Home)')
                    for _ in range(20):
                        if xbmc.getCondVisibility('Window.IsActive(Home)') or monitor.waitForAbort(.025):
                            break
                    monitor.waitForAbort(HUB_SETTLE_PLAIN)
                window._finish()
                window._release()
                screen_guard.release()
                if cover is not None:
                    cover.close()
            if isinstance(pending, dict) and 'trailer' in pending:
                from .trailers import play_trailer
                if not play_trailer(pending['trailer']):
                    continue
                pending = 'playing'
            if pending == 'player':
                to_player()
                pending = 'playing'
            if pending == 'playing':
                wait_for_film()                   # Watch next too, as on Home
                continue
            if pending == 'reload':
                if getattr(window, '_theme_changed', False):
                    from resources.lib import theme
                    theme.sync()
                    monitor.waitForAbort(.5)
                continue
            if pending and pending != 'hub':
                from .system_setup import execute_command
                from .session_window import leave_for
                leave_for(pending, execute_command)
            break
    finally:
        _titles(kind, '')
        media_apps.forget()
        if not pending:
            xbmc.executebuiltin('ActivateWindow(Home)')
