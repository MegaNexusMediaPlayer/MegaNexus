# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Remote-friendly Nuvio-style shelves, with cancellable background catalog loading."""
import os
import queue
import threading
import time
import json
import traceback
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import art_cache, number_colors
from resources.lib import screen_guard
from resources.lib import browse_cache
from resources.lib import home_data
from resources.lib import simkl_watched
from resources.lib import logo_size
from . import meta_fit
from resources.lib.settings_snapshot import cached_addon
from resources.lib.plain_text import without_emoji
from .dialog import Dialog
from . import listitems
from . import perf
from resources.lib.theme import folder as theme_folder
from . import browse_meta
from . import kodi_textures
from . import precache
_ORIGIN = 'mnx-ceafa2d639c9'

ADDON = xbmcaddon.Addon('script.meganexus')
BACK = {9, 10, 92, 216, 247, 257, 275, 61448, 61467}
ROW_BASE = 7000
RELOAD_TRIES = 1        # 8.1.2: once (was 3) - see _load, and _may_retry for the rest
RELOAD_PAUSE = 2.0      # s between those asks - the background refresh needs a moment
RELOAD_AGAIN = 90.0     # s before the same row may ask again
NAV = {101: ''}
HOME_PILL = 101          # the top bar's Home
LOAD_WORKERS = 4
ROW_BUDGET = .12          # 8.1.2: seconds of card drawing per pass of the window's loop
SEED_DISK_ROWS = 3        # shelves that may read SQLite synchronously while painting
PAINT_ROWS = 4            # 8.1.3: rows drawn while the screen is held - the rest follow
PREFETCH_DWELL = .25      # seconds a collection tile must stay selected before prefetch
DETAILS_DWELL = .6        # seconds on a title before its details load quietly (6.0.32)
RATINGS_DWELL = .15       # 8.1.3: seconds on a title before its ratings / dates are asked for (was .6)
LOOK_AHEAD = 5            # 8.1.3: the next titles in the row get theirs in the background
PREFETCH_AGAIN = 240      # seconds before the same collection is prefetched again
PREFETCH_ART = 10         # first cards whose artwork is warmed in the image proxy (a screen)
COLD_ART_IMAGES = 600     # proxy RAM already this full: skip the session warm-up
COLD_ART_PER_SHELF = 12   # a screen of posters per collection shelf (one preload round)
COLD_ART_WORKERS = 3      # background posters in flight at once (the proxy has 6 download workers)
COLD_ART_DELAY = 20       # 7.0.23: seconds after Home opens before the background preload starts
COLD_ART_IDLE = 4         # ... and seconds without cursor movement before each next step
SHELF_MEMORY_SECONDS = 300
SELECTION_TTL = 1.        # 7.0.30: seconds a read focus / card is reused while no key is pressed
ROW_AHEAD = 12            # 7.0.32: more cards than a row shows at once
TOP_BUTTONS = (105, 106, 107, 108, 111, 113, 115)   # search, library, settings, HUB, film waiting, calendar
# 8.1.2: the whole row keeps out of the way (the skin slides it up while
# meganexus.topbar is empty - review/make_top_bar.py). It is there while the cursor is
# on it, and goes again a few seconds after the last press: "kad stojim na njemu 5
# sekundi i nestane dok ne napravim klik".
TOP_BAR = (101, 105, 106, 107, 108, 111, 113, 114, 115)
# 9.1.1: in an app (YouTube, Music) the Calendar and Party are MegaNexus's own and not there - Settings takes the
# Calendar's place and HUB comes after it, the row's gap between (review/make_top_bar.py: Settings' width, GAP)
CALENDAR_BUTTON, SETTINGS_W, BAR_GAP = 115, 170, 20
BAR_PROPERTY = 'meganexus.topbar'
BAR_LINGER = 5.0
AHEAD_ROWS = 2            # 7.0.32: a collection's first screen, loaded while its tile is selected
AHEAD_CARDS = 8
AHEAD_SLOTS = 18          # hidden images in the Home layout (meganexus.ahead.N)
# 9.0.4: Home holds home_data.MAX_ROWS rows; a view with more goes round them (review/make_home_ring.py):
# the skin moves the cursor, row g of the view lives in row g % MAX_ROWS of Home, and the rows out of
# sight get the titles RING_BEHIND before and RING_AHEAD after the cursor - empty until their cards come.
RING_BEHIND, RING_AHEAD = 5, 6
RING_BLANKS = 8          # a ring row's empty cards until its titles come: a screen's width
GROW_AHEAD = 6            # 7.0.48, "Browse all" off: a row's next titles load this many cards before its end
GROW_SLOTS = 20           # 9.0.4: ...and this many empty cards wait at its end meanwhile - Right never stops


def home_xml():
    # Viewport dimensions stay in XML, with a compact variant for a hidden hero.
    return 'meganexus_home_compact.xml' if xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)') else 'meganexus_home.xml'


def launch_command(row):
    """Only addon-owned routes are accepted from cards; provider text is never a builtin."""
    p = home_data._api()
    if row.get('target'):
        path, folder = p._item_click_url(**row['target'])
    else:
        path, folder = row.get('path') or '', bool(row.get('is_folder'))
    if not path.startswith('plugin://') or any(c in path for c in ('\n', '\r', '"')):
        return ''
    return 'ActivateWindow(Videos,"%s",return)' % path if folder else 'RunPlugin("%s")' % path


def _server_play(path):
    """Start a Plex / Jellyfin item; wait while its version picker is open so
    Home does not come back over the starting video."""
    if not path.startswith('plugin://plugin.video.meganexus/?action=') or any(c in path for c in ('\n', '\r', '"')):
        return ''
    xbmc.executebuiltin('RunPlugin("%s")' % path)
    monitor=xbmc.Monitor();start=time.monotonic()
    while not monitor.waitForAbort(.2):
        if xbmc.Player().isPlayingVideo():return 'playing'
        picking=xbmc.getCondVisibility('Window.IsVisible(selectdialog) | Window.IsVisible(contextmenu) | Window.IsVisible(busydialog)')
        if picking:start=time.monotonic()
        elif time.monotonic()-start>8:return ''
    return ''



ROW_TITLE=6600       # 7.0.42: the row names (meganexus_home*.xml), moved with their cards


def row_frame(landscape, page=None, square=False):
    """(row height, card height, cards' top) of a Home row (7.0.42). The usual
    layout shows one row: every row is as tall as a poster row and the cards
    sit on its bottom, so posters and landscape rows end on the same line. The
    compact layout keeps rows as tall as their cards. ``page``: the window's own layout
    (9.0.6: the YouTube app always has its top), else the one Home uses. 9.0.6 ``square``:
    the Music app's covers (review/make_square_cards.py)."""
    card=300 if square else 214 if landscape else 330   # square: the cards (276) with room to grow (list clips)
    if (page or home_xml())=='meganexus_home_compact.xml':return 62+card,card,62
    return 392,card,392-card


def _continue_signature(shelf):
    """9.0.0: what Continue Watching shows - the titles, their episode, how far and how much
    is left (to the minute). A sync that changes none of it is no reason to rebuild the row."""
    def one(row):
        target=row.get('target') or {}
        return (target.get('canonical_id'),target.get('video_id'),target.get('season'),target.get('episode'),
                row.get('title'),row.get('percent'),int(row.get('remaining_seconds') or 0)//60)
    return tuple(one(row) for row in (shelf or {}).get('rows') or ())


REVEAL_WAIT = 1.5     # 9.0.1: s at most a new screen stays invisible while it fills
FOCUS_SETTLE = .26    # the focused card's grow (the skin's Focus zoom, 240 ms) is over


def reveal(window, monitor=None):
    """9.0.1: a screen opened invisible (meganexus.behind) shows itself once the cursor is
    on a card and that card has finished growing - or after REVEAL_WAIT, whatever a row
    still waiting for the network shows by then. Returns True when it was shown whole."""
    monitor=monitor or xbmc.Monitor()
    start=time.monotonic();held=None;whole=False
    try:
        while not window._closed and not monitor.abortRequested():
            window.drain_updates()
            now=time.monotonic()
            if held is None:
                try:
                    cid=window.getFocusId()
                    if ROW_BASE<=cid<ROW_BASE+len(window._shelves) and window.getControl(cid).size():
                        # the card under the cursor began to grow when its row was drawn
                        held=min(now,getattr(window,'_row_ready_at',None) or now)
                except Exception:pass
            if held is not None and now-held>=FOCUS_SETTLE:whole=True;break
            if now-start>=REVEAL_WAIT:break
            monitor.waitForAbort(.01)
    finally:
        window.setProperty('meganexus.behind','')
    return whole


def app_bar(win, options=False):
    """9.1.1: an app's top bar (YouTube, Music) without MegaNexus's Calendar and Party: Settings where the Calendar
    stands, HUB after it - the row keeps its even gaps. 9.1.2 ``options``: the app's Options in the Calendar's place
    (YouTube), Settings and HUB after it."""
    calendar = win.getControl(CALENDAR_BUTTON)
    x, y = calendar.getPosition()
    if options:
        x += calendar.getWidth() + BAR_GAP
    win.getControl(107).setPosition(x, y)
    win.getControl(108).setPosition(x + SETTINGS_W + BAR_GAP, y)


class HomeWindow(Dialog):
    _ring_g = None      # 9.0.4: also for a window Kodi hands over without __init__
    _ring_at = 0

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self._page_xml = args[0] if args else ''   # 7.0.55: its trailers play only while this page shows
        self._shelves = kwargs.get('shelves') or []
        self._arrive_on_home = bool(kwargs.get('arrive_on_home'))   # 9.1.1: the way into MegaNexus (open_home)
        self._pages = list(self._shelves)   # every row of this view (_shelves: what Home's rows hold)
        self._ring_g = None                 # 9.0.4: going round - the view's row each Home row holds
        self._ring_at = 0
        self._row_queue = []      # 8.1.3: rows a paint left for the loop to draw
        self._bucket = ''
        self._generation = 0
        self._closed = False
        self._pending = ''
        self._updates = queue.Queue()
        self._grown = queue.Queue()      # 7.0.48: a row's next titles (Browse all off)
        self._pool = None
        self._futures = []
        self._last_touch = 0
        self._focus_memory = {}
        self._previews = None
        self._suspended = False
        self._shelf_memory={}
        self._memory_lock=threading.Lock()
        self._memory_epoch=0
        self._prefetch_pool=None
        self._prefetch_futures=[]
        self._prefetched={}
        self._hover=(None,0)
        self._details_asked=None
        self._anim=[None,None,False]   # wanted, ready, worker running (7.0.21)
        self._anim_focus=None          # (card, animation) playing or played
        self._anim_until=0
        self._anim_failed={}           # animation: no new try before this time
        self._anim_seconds={}          # animation: playing time of one pass
        self._warmed_art=set()
        self._scheduled=set();self._drawn=set()
        self._watch_loaded=False
        self._progress_revision=xbmcgui.Window(10000).getProperty('meganexus.progress.revision')
        self._last_progress_check=0
        self._bucket = kwargs.get('bucket') or ''
        # 7.0.32: a collection opens in its own screen over Home (as on Android TV
        # apps); Home stays as it is behind it and Back only closes it.
        self._nested=bool(kwargs.get('nested'))
        self._parent=kwargs.get('parent')   # Home, for a collection screen
        self._collection_window=None
        self._shown=False      # the collection screen is open (nested)
        self._forward=None     # a Home button pressed in the collection screen
        self._leaving=False    # 7.0.42: on the way to the HUB, Home stays until it is ready
        self._entered=False
        self._scroll_from=0.;self._scroll_to=0.;self._scroll_started=0.
        self._covered={}
        # open_home passes the revision read before it built the shelves, so a
        # progress write racing that build is still detected in onInit.
        self._continue_fresh='progress_revision' in kwargs
        if self._continue_fresh:self._progress_revision=kwargs['progress_revision']

    def onInit(self):
        if self._entered and not self._nested:xbmc.log('[MegaNexus] Home initialised again by Kodi; the cursor stays where it was.',xbmc.LOGINFO)
        self._nav={}   # 7.0.50: Kodi made the controls anew - their links are set again
        # 8.1.2: ...and their heights and positions. 9.0.5: Kodi makes them as the skin draws them -
        # a poster row's frame - so a poster row is not told again where it already is (a new
        # screen per collection sent each row four of these, ~25 ms each on the Cube)
        self._row_frames=dict((i,row_frame(False,getattr(self,'_page_xml',''))) for i in range(home_data.MAX_ROWS))
        self._row_props={}    # ...and the properties they carry are written again once
        # 9.0.5: a window shown for the first time has none of them yet - an empty one is not written
        self._props_blank=not self._entered
        self._opened_at=time.monotonic()
        self.setProperty('meganexus.home.error','')
        reset_continue=False
        try:
            saved = json.loads(xbmcgui.Window(10000).getProperty('meganexus.home.focus') or '{}')
            if isinstance(saved, dict):
                self._focus_memory = saved
        except (ValueError, TypeError):
            pass
        try:
            window=xbmcgui.Window(10000)
            revision=window.getProperty('meganexus.progress.revision')
            # This is the way in, not a return from a title or Settings. Read before the
            # branch below: it is needed whatever the first shelf is, and 8.1.2 read it
            # inside the branch - on a collection tab, or a Home whose first shelf is not
            # Continue Watching, onInit died with UnboundLocalError and Home showed
            # "Home could not display its collections."
            entry=not self._entered
            if not self._bucket and self._shelves and self._shelves[0].get('continue_job'):
                # Every Home entry starts this shelf at its newest title, even
                # after a restart/import or when another view consumed revision.
                # Returning from Details/Settings keeps the selected title.
                reset_continue=entry
                # open_home built this shelf moments ago; rebuild only if progress changed.
                if not (entry and self._continue_fresh) or revision!=self._progress_revision:
                    self._shelves[0]=home_data.continue_shelf()
                    self._shelves[0]['_signature']=_continue_signature(self._shelves[0])
                    if self._holds_first() and getattr(self,'_pages',None):self._pages[0]=self._shelves[0]
                self._progress_revision=revision
                if entry and self._focus_memory.get('home',[0,0])[0]==0:self._focus_memory['home']=[0,0]
                window.setProperty('meganexus.home.progress_seen',revision)
            self._entered=True
            # 8.1.2: nothing ever puts the cursor on the Home pill by itself. It was tried
            # - the way in used to land there - and it was wrong both times it showed: a
            # collection opens in a window of its own, so it flashed there before moving
            # to the first poster, and on Home it took the cursor away from the row the
            # person left it on. The Home pill is where you go when you press Home.
            # 9.0.1: Kodi initialising Home again (around a film) is not the person's doing:
            # the page is drawn again quietly - see _paint_rows
            self._quiet=not entry
            try:self._paint(self._shelves,keep_pages=True)   # 7.0.48: this page again, the others kept
            finally:self._quiet=False
            if reset_continue:self.getControl(ROW_BASE).selectItem(0)
        except Exception:
            xbmc.log('[MegaNexus] Home initialization failed:\n'+traceback.format_exc(),xbmc.LOGERROR)
            self.setProperty('meganexus.home.error','Home could not display its collections. Open Settings or reinstall the complete MegaNexus ZIP.')
            self.focus(107)
            return
        try:
            from .home_trailers import Controller
            if self._previews:self._previews.finish()
            self._previews = Controller(self)
            self._previews.start()
        except Exception:
            # Optional trailers must never prevent local collection cards rendering.
            xbmc.log('[MegaNexus] Preview controller unavailable: '+traceback.format_exc(),xbmc.LOGWARNING)

        self.restore_focus()

    def _selection(self):
        """(focused control, its card, hero hidden) for the window loop (7.0.30).

        The loop runs 20 times a second; each question to Kodi waits for its
        drawing thread (on CoreELEC / Android boxes frames were lost to it).
        Focus and card change only through keys (onAction / onFocus, which clear
        this) or our own repaint, so they are read again only then - and once
        a second for anything else."""
        now=time.monotonic();cached=getattr(self,'_sel_cache',None)
        # 8.1.3: and once more just after a key - read in the same instant as the key,
        # the list could still say the card it was leaving, and that stood for a second
        stale=getattr(self,'_sel_stale_at',0.)
        if cached and now-cached[0]<SELECTION_TTL and not cached[0]<stale<=now:return cached[1]
        control_id=self.getFocusId();pos=-1
        if ROW_BASE<=control_id<ROW_BASE+len(self._shelves):
            try:pos=self.getControl(control_id).getSelectedPosition()
            except Exception:pos=-1
        hidden=xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)')
        self._sel_cache=(now,(control_id,pos,hidden))
        return control_id,pos,hidden

    def preview_selection(self):
        if self._closed or self._suspended: return None
        control_id,pos,hidden=self._selection()
        if hidden:return None
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves): return None
        rows = self._shelves[index]['rows']
        if not 0 <= pos < len(rows) or not rows[pos].get('target') or rows[pos].get('person'): return None
        return (self._generation, index, pos), dict(rows[pos])

    def mark_preview(self, key, on):
        """9.0.1: the card of ``key`` (preview_selection) marked as the one whose trailer
        plays (the skin's meganexus.previewing). True when the card was found."""
        try:
            generation,index,pos=key
            if generation!=self._generation:return False
            control=self.getControl(ROW_BASE+index)
            if not 0<=pos<control.size():return False
            control.getListItem(pos).setProperty('meganexus.previewing','1' if on else '')
            return True
        except Exception:
            return False

    @staticmethod
    def _shelf_key(shelf):
        jobs=shelf.get('collection_job') or ([(*shelf['job'],shelf.get('extra') or {})] if shelf.get('job') else [])
        return json.dumps([(p.get('id'),c.get('type'),c.get('id'),extra) for p,c,extra in jobs],sort_keys=True) if jobs else ''

    def _remembered(self, key):
        if not key:return None
        with self._memory_lock:
            saved=self._shelf_memory.get(key)
            if saved and saved[0]>time.monotonic():return saved[1]
        return None

    def _remember_rows(self, key, rows, epoch=None):
        if not key or not any(row.get('target') for row in rows or []):return
        with self._memory_lock:
            if epoch is not None and epoch!=self._memory_epoch:return  # Settings changed meanwhile.
            self._shelf_memory.pop(key,None)
            self._shelf_memory[key]=(time.monotonic()+SHELF_MEMORY_SECONDS,rows)
            while len(self._shelf_memory)>32:self._shelf_memory.pop(next(iter(self._shelf_memory)))

    def _forget_rows(self):
        with self._memory_lock:
            self._memory_epoch+=1;self._shelf_memory.clear()
        self._prefetched.clear()

    @staticmethod
    def _settings_signature():
        """Everything Settings can change that would make Home's remembered rows wrong.

        8.1.2: leaving Settings used to throw every remembered row away whatever had
        been done in there, so Home was rebuilt from nothing every time - "izlaz iz
        settingsa refresha cijeli home", and the cursor moved with it. Most visits to
        Settings change none of this; some are only a look.

        The settings file's own timestamp is the honest signal: Kodi writes it when a
        setting changes and leaves it alone when nothing does, so no list of individual
        settings can fall behind. The skin file, the theme, the Artwork provider and the
        collections are named as well - they live outside that file.
        """
        def stamp(path):
            try:return os.stat(xbmcvfs.translatePath(path)).st_mtime_ns
            except OSError:return 0
        try:
            from resources.lib import art_provider
            art=art_provider.signature()
        except Exception:
            art=''
        return (home_xml(), theme_folder(), art,
                stamp('special://profile/addon_data/plugin.video.meganexus/settings.xml'),
                stamp('special://profile/addon_data/plugin.video.meganexus/meganexus_collections.json'))

    @staticmethod
    def _seed(shelf, index):
        """Paint cached catalog pages synchronously so an opened collection is
        never a wall of 'Loading' cards. Point lookups only, no network."""
        if shelf.get('_loaded') or not (shelf.get('job') or shelf.get('collection_job')):return
        try:rows=home_data.load_catalog(shelf,cached_only=True if index<SEED_DISK_ROWS else 'memory')
        except Exception:return
        if rows:
            from resources.lib.art_provider import pending
            # 7.0.29: pictures from the Artwork provider not cached yet - load once more.
            shelf.update(rows=rows,_loaded=not pending(rows))

    def _paint(self, shelves, keep_pages=False):
        """``shelves``: every row of the view - up to home_data.MAX_ROWS drawn as they are, more go
        round (9.0.4, _ring_window); ``keep_pages``: ``shelves`` is what Home's rows hold, drawn again."""
        if xbmc.Monitor().abortRequested():return   # 8.1.4: Kodi is closing - nothing is drawn any more
        # the first drawing of a window (onInit) passes the whole view as "what Home's rows hold"
        if not keep_pages or len(shelves)>home_data.MAX_ROWS:
            self._pages=list(shelves)
            if len(self._pages)>home_data.MAX_ROWS:
                try:at=int((self._focus_memory.get(self._bucket or 'home') or [0])[0])
                except (ValueError,TypeError,IndexError):at=0
                self._ring_at=max(0,min(at,len(self._pages)-1))
                self._ring_g=[None]*home_data.MAX_ROWS
                shelves=self._ring_window(self._ring_at)
            else:
                self._ring_g=None
                if any(s.get('lazy') for s in self._pages):
                    # rows made whole now (collections_home.catalog_rows), kept made
                    from resources.lib.collections_home import resolve
                    self._pages=[resolve(s) for s in self._pages]
                shelves=self._pages
        self._painted_at=time.monotonic()   # 8.1.1: rows arriving later are timed from here
        with perf.timed('Home paint', tab=self._bucket or 'home') as step:
            self._paint_rows(shelves)
            step.details['rows']=len(self._pages)
            step.details['cards']=sum(len(s.get('rows') or []) for s in self._shelves)

    def _view_row(self, index):
        """The view's row Home row ``index`` holds (9.0.4: going round they differ)."""
        return index if self._ring_g is None else self._ring_g[index]

    def _holds_first(self):
        return self._ring_g is None or self._ring_g[0]==0

    def _ring_shelf(self, g):
        """Row ``g`` of the view as a Home row holds it: made whole, its cards from memory when
        they are there - else none yet (never another row's cards). Out of the view: empty."""
        if not 0<=g<len(self._pages):return {'title':'','rows':[],'_ring_empty':True,'_ring_g':g}
        shelf=self._pages[g]
        if shelf.get('lazy'):
            from resources.lib.collections_home import resolve
            shelf=self._pages[g]=resolve(shelf)
        saved=self._remembered(self._shelf_key(shelf))
        if saved:shelf.update(rows=saved,_loaded=True)
        else:self._seed(shelf,SEED_DISK_ROWS)          # memory only: going round never waits for the disk
        return dict(shelf,_ring_g=g)

    def _ring_window(self, at):
        """Home's rows holding the view's rows around ``at`` (RING_BEHIND before, RING_AHEAD after)."""
        size=home_data.MAX_ROWS;shelves=[None]*size
        for g in range(at-RING_BEHIND,at+RING_AHEAD+1):
            shelves[g%size]=self._ring_shelf(g);self._ring_g[g%size]=g
        return shelves

    def _ring_move(self, slot):
        """9.0.4: the skin moved the cursor to Home row ``slot``: the view's row it holds is where the
        cursor is; the rows out of sight that now stand for other rows are emptied, then filled."""
        size=home_data.MAX_ROWS
        step=(slot-self._ring_at%size+size//2)%size-size//2
        self._ring_at=max(0,min(self._ring_at+step,len(self._pages)-1))
        for g in sorted(range(self._ring_at-RING_BEHIND,self._ring_at+RING_AHEAD+1),key=lambda g:abs(g-self._ring_at)):
            index=g%size
            if self._ring_g[index]==g:continue
            shelf=self._ring_shelf(g)
            self._ring_g[index]=g;self._shelves[index]=shelf
            for kept in (self._scheduled,getattr(self,'_drawn',set()),getattr(self,'_grow_later',set())):kept.discard(index)
            for kept in (getattr(self,'_row_ids',None) or {},getattr(self,'_card_sigs',None) or {}):kept.pop(index,None)
            if index in self._row_queue:self._row_queue.remove(index)
            self._ring_row(index,shelf)
            self._ring_blank(index,shelf)
            if shelf.get('rows'):self._row_queue.append(index)   # drawn by the loop, nearest first
        self._ring_edges()
        self.setProperty('meganexus.ring.slot',str(self._ring_at%size))   # what shows while the cursor is on the tabs

    def _ring_blank(self, index, shelf):
        """Nobody else's cards, ever: the row out of sight is emptied and given empty cards. Kodi
        cannot focus an empty list - Down held stopped at a row not loaded yet ("asked to focus,
        but it can't"); its titles are then written into these cards where they stand."""
        try:
            control=self.getControl(ROW_BASE+index);control.reset()
            blank=[]
            for _ in range(RING_BLANKS):
                li=listitems.item(label='');li.setProperty('meganexus.placeholder','1');blank.append(li)
            control.addItems(blank)
            shelf['_ring_blank']=True
        except Exception:pass

    def _say(self, key, value):
        """8.1.2: a row's property written only when its value is new - every call waits for Kodi's
        drawing thread (12 rows x four of them measured 6.5 s on the Cube while posters decoded)."""
        said=getattr(self,'_row_props',None)
        if said is None:said=self._row_props={}
        if said.get(key,'' if getattr(self,'_props_blank',False) else None)==value:return
        said[key]=value
        self.setProperty(key,value)

    def _row_look(self, i, shelf, titles):
        """Home row ``i`` shaped for ``shelf``: its height and card shape, its name, Right on its last card."""
        shape = shelf.get('shape',self._card_shape)
        landscape = shape=='landscape'
        # 9.1.1: 'rank' - a Top 10 row (tracking_rows.TOP10): posters with their number beside them, a layout of
        # its own (review/make_home_rank.py); as tall as a poster row everywhere else
        self._say('meganexus.row.%d.shape' % i, shape if shape in ('landscape','square','rank') else 'poster')
        group,card,art_top=row_frame(landscape,getattr(self,'_page_xml',''),shape=='square')
        # 8.1.2: only when it moves. Each of these four waits for Kodi's drawing
        # thread - about 25 ms a call on a CoreELEC box, so 400 ms of a collection's
        # paint went on putting two rows back exactly where they already were. The
        # shape only changes between a poster row and a landscape one.
        frames=getattr(self,'_row_frames',None)
        if frames is None:frames=self._row_frames={}
        if frames.get(i)!=(group,card,art_top):
            frames[i]=(group,card,art_top)
            self.getControl(6500 + i).setHeight(group)
            self.getControl(ROW_BASE + i).setHeight(card)
            # 7.0.42: the cards sit on the row's bottom (posters or landscape - the
            # bottom edge never moves), the row's name right above them
            try:
                self.getControl(ROW_BASE + i).setPosition(0,art_top)
                self.getControl(ROW_TITLE + i).setPosition(16,art_top-62)
            except Exception:pass
        self._set_right(i)
        # 7.0.24: row titles can be switched off (What Home shows). 9.1.1: every row's - Continue Watching, Top 10,
        # Watchlist, Next episodes and any row added later too ("neko želi superclean, minimalistički sve")
        self._say('meganexus.row.%d.title' % i, without_emoji(shelf.get('title') or '') if titles else '')

    def _arrival(self, row):
        """Where a fresh screen's cursor goes: its remembered row - 9.1.1: coming into MegaNexus, the Home pill ("na ulaz u
        MegaNexus fokus mora biti na Home prvo, ne na Continue Watching"); only then: a return, a tab and a collection
        keep their row (8.1.2)."""
        if getattr(self,'_arrive_on_home',False):
            self._arrive_on_home=False
            return HOME_PILL
        return ROW_BASE+row

    def _ring_row(self, i, shelf):
        self._say('meganexus.row.%d.visible' % i, '' if shelf.get('_ring_empty') else '1')
        self._row_look(i,shelf,self._row_titles())

    def _row_titles(self):
        """The rows' titles shown (What Home shows); 9.1.2: an app has its own (the YouTube app's Options)."""
        return cached_addon().getSetting('meganexus_row_titles')!='false'

    def _ring_edges(self):
        """The first and the last row of the view stop Up / Down (the skin reads these)."""
        last=len(self._pages)-1
        for i,g in enumerate(self._ring_g):
            self._say('meganexus.row.%d.first' % i, '1' if g==0 else '')
            self._say('meganexus.row.%d.last' % i, '1' if g==last else '')

    def _paint_rows(self, shelves):
        # 8.1.2: one line per phase. "Home paint: 2433 ms" on a CoreELEC box says a
        # collection takes two and a half seconds and nothing about which part of it
        # does, and that is the difference between fixing it and guessing at it.
        from . import perf
        self.setProperty('meganexus.search.query',getattr(self,'_search_query','') if self._bucket=='search' else '')
        # 9.0.1: a repaint nobody asked for (Kodi initialising Home again, the posters wall
        # ready) changes nothing that is seen beyond the cards: no slide-in, no scroll to
        # a remembered row while the cursor is on a button, no card chosen again.
        quiet=getattr(self,'_quiet',False)
        held=self.getFocusId() if quiet else 0
        if not quiet:self._anim_focus=None;self.setProperty('meganexus.anim_ready','')
        with perf.timed('  paint/seed', rows=len(shelves)):
            for index,shelf in enumerate(shelves):
                saved=self._remembered(self._shelf_key(shelf))
                if saved:shelf.update(rows=saved,_loaded=True)
                elif index<home_data.MAX_ROWS:self._seed(shelf,index)
        self._card_shape=cached_addon().getSetting('meganexus_card_shape') or 'poster'
        shelves = [s if '_ring_g' in s else dict(s, rows=s.get('rows') or [home_data.placeholder(
            'No titles yet', 'Open Settings to connect your metadata provider.')]) for s in shelves[:home_data.MAX_ROWS]]
        if not shelves:
            shelves = [{'title':'Welcome to MegaNexus', 'rows':[home_data.placeholder(
                'Open Settings', 'Set up on your phone (HUB Settings › Set up on phone) or add a metadata add-on to load titles.',
                'plugin://plugin.video.meganexus/?action=setup_center')]}]
        self._generation += 1
        for future in self._futures:
            future.cancel()
        self._futures = []
        self._scheduled=set();self._drawn=set()
        self._shelves = shelves
        self.setProperty('meganexus.compact','1' if (getattr(self,'_page_xml','') or home_xml())=='meganexus_home_compact.xml' else '')
        self._browse_all=home_data.browse_all()   # read once per paint, not on every tick
        self._paint_cards=0
        # 8.1.3: where the cursor will stand. Read here, not at the end, because the rows
        # are drawn around it: the one under the cursor and its neighbours now, the rest
        # a couple of passes later (self._row_queue).
        try:
            saved = self._focus_memory.get(self._bucket or 'home') or [0, 0]
            saved = [int(saved[0]), int(saved[1])] + [int(x) for x in saved[2:3]]
        except (ValueError, TypeError, IndexError, KeyError):saved=[0,0]
        if self._ring_g is not None:   # 9.0.4: going round - the view's row is remembered, Home's row holds it
            row = self._ring_at % home_data.MAX_ROWS
            order = sorted(range(len(shelves)), key=lambda i: (abs(self._ring_g[i] - self._ring_at), i))
        else:
            row = max(0, min(int(saved[0]), len(shelves) - 1))
            order = sorted(range(len(shelves)), key=lambda i: (abs(i - row), i))
        now_drawn = set(order[:PAINT_ROWS])
        self._row_queue = [i for i in order[PAINT_ROWS:]]
        _geometry=perf.timed('  paint/controls', rows=len(shelves));_geometry.__enter__()
        # 8.1.2: every setProperty and every getSetting here is a call that waits for
        # Kodi's drawing thread. Twelve rows x four of them, while Kodi is decoding a
        # hundred posters, measured 6,549 ms on the Cube - the screen is dead for all of
        # it ("kad dojem na dno smrzne sve"). The row titles are read once instead of
        # twelve times, and a property is written only when its value is new.
        titles=self._row_titles()
        _watched=simkl_watched.snapshot()        # once for the whole paint
        self.setProperty('meganexus.ring','1' if self._ring_g is not None else '')
        for i in range(home_data.MAX_ROWS):
            self._say('meganexus.row.%d.visible' % i, '1' if i < len(shelves) and not shelves[i].get('_ring_empty') else '')
            if i < len(shelves):
                self._row_look(i,shelves[i],titles)
                # 8.1.3: the screen is held for as long as this loop runs - 12 rows of
                # cards measured 3.4 s on the Cube when Home turned to its next page, and
                # for all of it the picture stood still while the remote still clicked
                # ("slika je staticna, zvuk daljinskog se cuje"). Only the rows at the
                # cursor are drawn here; the others are drawn by the window's own loop, a
                # budget at a time, with the remote answered in between.
                if i in now_drawn:
                    with perf.timed('  paint/row %d' % i, cards=len(shelves[i]['rows'])):
                        self._set_rows(i, shelves[i]['rows'], watched=_watched)
                    if i==row:self._row_ready_at=time.monotonic()   # 9.0.1: its card starts to grow now (reveal)
                    self._paint_cards+=len(shelves[i]['rows'])
        if self._ring_g is not None:
            self._ring_edges();self.setProperty('meganexus.ring.slot',str(row))
        _geometry.details['cards']=self._paint_cards;_geometry.__exit__()
        _tail=perf.timed('  paint/finish');_tail.__enter__()
        if not quiet:
            self.setProperty('meganexus.hero_row', str(row))
            self._row_scroll_focus(row)
        elif ROW_BASE<=held<ROW_BASE+len(shelves):
            self.setProperty('meganexus.hero_row', str(held-ROW_BASE))
            self._row_scroll_focus(held-ROW_BASE)
        self.setProperty('meganexus.tab', self._bucket or 'home')
        # 7.0.21: the rows slide in on every repaint (a/b: each change starts the
        # skin's Conditional animation again).
        self._paint_flip='b' if getattr(self,'_paint_flip','')=='a' else 'a'
        if any(s.get('posters_refresh') for s in shelves) and not getattr(self,'_posters_checked',False):
            # 7.0.48: the saved posters wall made again in the background when the collections
            # changed or it is old - the next Home shows it (no repaint under the remote)
            self._posters_checked=True
            if self._pool is None:self._pool=ThreadPoolExecutor(max_workers=LOAD_WORKERS, thread_name_prefix='MegaNexusHome')
            self._pool.submit(self._refresh_posters)
        # 7.0.32: back from a collection the rows do not slide in: they appear
        # once they stand where they were (meganexus.paint ra / rb).
        if quiet:self._paint_flip='b' if self._paint_flip=='a' else 'a'   # the slide-in is not started again
        else:self.setProperty('meganexus.paint',('r' if getattr(self,'_returning',False) else '')+self._paint_flip)
        # 8.1.2: this asks for the first row and gets it only while nothing holds the
        # cursor (Dialog._take_focus) - a fresh screen. On a repaint the cursor is
        # already somewhere and stays there, which is the whole of the rule now:
        # "ako kliknem na nesto da se fokus zapamti i ostane na tome dok ne izadem".
        # Coming back from a screen that was opened from a button, the button is where
        # the cursor belongs (restore_focus, right after this) and nothing asks for a row.
        if self._restore_focus is None and not (quiet and held):self.focus(self._arrival(row))
        # the row still gets its remembered card, so Down from the tab lands where it left off
        # (9.0.1: on a quiet repaint only when the row lost it - choosing it again scrolls the row)
        control=self.getControl(ROW_BASE + row)
        if not quiet or control.getSelectedPosition()!=min(max(0,int(saved[1])),len(shelves[row]['rows'])-1):
            self._select(control, int(saved[1]), len(shelves[row]['rows']), saved[2] if len(saved) > 2 else None)
        if self._pool is None:
            self._pool = ThreadPoolExecutor(max_workers=LOAD_WORKERS, thread_name_prefix='MegaNexusHome')
        self._queue_visible()
        if not getattr(self,'_watch_loaded',False):
            self._watch_loaded=True
            self._pool.submit(self._refresh_watched)
        try:
            if not self._nested:self._start_cold_art_warm()
            self._learn_logos()
            # 8.1.3: the first cards of every row get their ratings and dates now - the
            # cursor lands on one of them whichever row it goes to
            self._lookahead([row for shelf in self._shelves for row in (shelf.get('rows') or [])[:4]],first=True)
        except Exception:pass  # Optional warm-up never blocks Home.
        _tail.__exit__()
        self._touch()

    @staticmethod
    def _select(control, pos, count, shown=None):
        """Select a card; with ``shown`` (its place on the screen when it was left,
        7.0.32) the row is scrolled as it was: a list scrolls only as far as the
        selected card needs, so first past it, then back to the first card shown."""
        pos=min(max(0,pos),count-1)
        try:first=pos-int(shown)
        except (TypeError,ValueError):first=0
        if 0<first<pos+1:
            control.selectItem(min(count-1,first+ROW_AHEAD))
            control.selectItem(first)
        control.selectItem(pos)

    def _row_geometry(self):
        offset=0;rows=[]
        for shelf in self._shelves:
            shape=shelf.get('shape',getattr(self,'_card_shape','poster'))
            height,_,art_top=row_frame(shape=='landscape',getattr(self,'_page_xml',''),shape=='square')
            rows.append((offset,height,230 if shape=='square' else 171 if shape=='landscape' else 288,art_top));offset+=height+14
        return rows,max(0,offset-14)

    def _current_scroll(self):
        fraction=max(0.,min(1.,(time.monotonic()-getattr(self,'_scroll_started',0.))/.18))
        start=getattr(self,'_scroll_from',0.);end=getattr(self,'_scroll_to',0.)
        return start+(end-start)*fraction

    def _row_scroll_focus(self,row):
        """Mirror Kodi's grouplist scroll geometry without changing its layout."""
        if self._ring_g is not None:   # 9.0.4: going round, the row with the cursor is the only one, in place
            self._scroll_from=self._scroll_to=0.;self._update_row_coverage();return
        rows,total=self._row_geometry()
        if not 0<=row<len(rows):return
        viewport=890 if home_xml()=='meganexus_home_compact.xml' else 406   # 7.0.42: one row
        current=self._current_scroll();offset,height,_,_=rows[row];target=getattr(self,'_scroll_to',0.)
        if row==0:target=0.
        elif row==len(rows)-1:target=max(0.,total-viewport)
        elif offset<current:target=float(offset)
        elif offset+height>current+viewport:target=float(offset+height-viewport)
        if target!=getattr(self,'_scroll_to',0.):
            self._scroll_from=current;self._scroll_to=target;self._scroll_started=time.monotonic()
        self._update_row_coverage()

    def _update_row_coverage(self):
        # 7.0.45: going up, the rows that will show are uncovered at once (the scroll's
        # end); they stayed faded while the estimate passed them - rows vanished for a
        # moment on Up (CoreELEC report). Going down a row is covered as it leaves.
        scroll=min(self._current_scroll(),getattr(self,'_scroll_to',0.));rows,_=self._row_geometry()
        cached=getattr(self,'_covered',{})
        for index,(offset,_,art_height,art_top) in enumerate(rows):
            # Artwork starts after the row heading (row_frame). Keep exactly 70%;
            # only the mostly clipped card fragments above that disappear.
            hidden=self._ring_g is None and scroll>offset+art_top+6+art_height*.70
            if cached.get(index)!=hidden:
                self.setProperty('meganexus.row.%d.covered'%index,'1' if hidden else '')
                cached[index]=hidden
        self._covered=cached

    def _queue_visible(self):
        if not self._pool or self._closed or self._suspended:return
        row=max(0,min(self._selection()[0]-ROW_BASE,len(self._shelves)-1))
        # Load the focused shelf and its neighbours before off-screen catalogs.
        if self._ring_g is not None:   # 9.0.4: going round - the next ones and the one before, wrapping
            size=len(self._shelves);indices=[(row+k)%size for k in (0,1,2,-1,3)]
        else:indices=list(dict.fromkeys([row,row+1,row+2,0]))
        for i in indices:
            if i>=len(self._shelves) or i in self._scheduled:continue
            shelf=self._shelves[i]
            if shelf.get('continue_job') or ((shelf.get('job') or shelf.get('collection_job') or shelf.get('people_job') or shelf.get('local_job') or shelf.get('server_job') or shelf.get('posters_job') or shelf.get('youtube_job') or shelf.get('music_job') or shelf.get('tracking_job')) and not shelf.get('_loaded')):
                self._scheduled.add(i)
                shelf['progress_revision']=self._progress_revision
                self._futures.append(self._pool.submit(self._load, i, dict(shelf), self._generation))

    def _refresh_watched(self):
        try:simkl_watched.refresh()
        except Exception:return  # Keep offline status; never block Home on Simkl.
        if not self._closed:self._updates.put((self._generation,-1,[]))

    @staticmethod
    def _watched_mark(row, data):
        target=row.get('target') or {}
        # 9.1.1: a series only once nothing of it is still to come (simkl_watched.watched_mark)
        seen=row.get('watched') or simkl_watched.watched_mark(data,target.get('media_type'),target.get('canonical_id'),(target.get('imdb_id'),))
        return '1' if seen else ''

    def _watched_badges(self):
        """The watched marks on the cards, written only where one really changed.

        8.1.2: this ran on the way back from Library, from a title and from Settings, and
        set the property on EVERY card of EVERY shelf. Each of those is a call into Kodi,
        which costs 10-25 ms on a box: three hundred cards is seconds of a screen that
        answers nothing, and that is the wait felt on the way out of Library.

        simkl_watched.snapshot() hands back the very same object while nothing has
        changed, so the usual case is one identity test. When it has changed, the mark is
        worked out with the old snapshot as well - plain Python, no calls - and only the
        cards whose answer is different are written.
        """
        data=simkl_watched.snapshot()
        previous=getattr(self,'_badges_data',None)
        if data is previous:return
        self._badges_data=data
        for i,shelf in enumerate(self._shelves):
            control=None
            for pos,row in enumerate(shelf['rows']):
                mark=self._watched_mark(row,data)
                if previous is not None and mark==self._watched_mark(row,previous):continue
                if control is None:control=self.getControl(ROW_BASE+i)
                control.getListItem(pos).setProperty('watched',mark)

    def _load(self, index, shelf, generation):
        if self._closed or generation != self._generation:
            return
        if shelf.get('tracking_job'):
            return self._load_tracking(index,shelf,generation)
        try:
            if shelf.get('continue_job'):
                from resources.lib.continue_metadata import enrich
                def stopped():return self._closed or generation!=self._generation or shelf.get('progress_revision')!=self._progress_revision
                def update(rows):
                    if not stopped():
                        self._updates.put((generation, index, rows, shelf.get('progress_revision'), shelf.get('_ring_g')))
                times=[time.monotonic()]
                rows=enrich(shelf['rows'],update,stopped);times.append(time.monotonic())
                update(rows)   # 7.0.45: drawn now - the network refresh below follows behind Home
                from resources.lib.watch_nextup import augment
                rows=augment(rows,refresh=True,stopped=stopped);times.append(time.monotonic())
                from resources.lib.continue_metadata import dedupe
                rows=dedupe(rows,network=True);times.append(time.monotonic())   # 7.0.29: tmdb:… and tt… of one film are one card
                rows=home_data._artwork(rows,stopped=stopped);times.append(time.monotonic())   # 7.0.29: the Artwork provider's pictures
                # 7.0.45: where Continue Watching's time goes (it came late on the Cube)
                xbmc.log('[MegaNexus][perf] Continue Watching: %d cards · titles %d ms · next episodes %d ms · same title %d ms · artwork %d ms'
                         %((len(rows),)+tuple(int((b-a)*1000) for a,b in zip(times,times[1:]))),xbmc.LOGINFO)
                if stopped():return
            elif shelf.get('posters_job'):
                # 7.0.48: MegaNexus posters made for the first time - Home draws them when done
                from resources.lib import home_posters
                if home_posters.build(stopped=lambda:self._closed or generation!=self._generation) and not self._closed:
                    self._updates.put((generation,-2,[]))
                return
            elif self._bucket=='search' and shelf.get('collection_job'):
                # 9.0.5: the add-ons' results at once - the chosen pictures (TMDB, fanart) follow into the
                # same cards. Asked for first, they held every row: "batman" answered in 1.6 s and showed
                # at 5.7 s on the PC, 1.8 s of it the pictures of 19 films ("search zna raditi predugo").
                stopped=lambda:self._closed or generation!=self._generation
                rows = home_data.load_catalog(shelf,stopped=stopped,art_later=True)
                from resources.lib.art_provider import pending
                if pending(rows) and not stopped():
                    self._updates.put((generation,index,rows,None,shelf.get('_ring_g')))   # shown now
                    rows = home_data.load_catalog(shelf,stopped=stopped)   # the answers are kept: pictures only
            else:
                stopped=lambda:self._closed or generation!=self._generation
                rows = home_data.load_catalog(shelf,stopped=stopped)
                # 8.1.1: a collection source that did not answer used to leave the row
                # as it was and the shelf counted as loaded, so the collection stayed
                # half empty until the next visit - by then the background refresh had
                # cached it. It is asked again, here, while the screen is still open.
                #
                # 8.1.2: one row at a time, once, and not the same row again for a
                # while. Only collections report a missing source, and in the
                # Collections view EVERY row is one: with a provider that answers
                # "(empty)" or times out - which is what the Cube's log is full of -
                # twelve rows each took a worker for three tries two seconds apart and
                # pushed an update after every one. The pool was full, the rows were
                # redrawn over and over, and reaching the bottom of Home felt frozen.
                # Stable has no retry here at all and does not have the problem.
                for attempt in range(RELOAD_TRIES if self._may_retry(index) else 0):
                    if not shelf.get('_sources_missing') or stopped():break
                    self._updates.put((generation,index,rows,None,shelf.get('_ring_g')))   # what did answer, now
                    if xbmc.Monitor().waitForAbort(RELOAD_PAUSE):break
                    if stopped():break
                    better = home_data.load_catalog(shelf,stopped=stopped)
                    if len(better)>=len(rows):rows=better
                    if not shelf.get('_sources_missing'):
                        xbmc.log('[MegaNexus][perf] Row refilled: %d cards · %s · try %d'
                                 %(len(rows),str(shelf.get('title') or '?')[:40],attempt+1),xbmc.LOGINFO)
        except Exception:
            rows = [home_data.placeholder('Open catalog',
                'This catalog could not load right now. Select to retry in the full browser.', shelf.get('path',''))]
        if self._closed or generation != self._generation:
            return
        self._updates.put((generation, index, rows, shelf.get('progress_revision') if shelf.get('continue_job') else None, shelf.get('_ring_g')))

    def _load_tracking(self, index, shelf, generation):
        """9.0.8: Watchlist / Next episodes (resources/lib/tracking_rows.py): what the local stores and the
        kept answers hold, at once - a service that is due is asked on a thread of its own behind Home, and
        its cards follow into the row where they stand. Continue Watching's shows stay out of Next episodes."""
        from resources.lib import tracking_rows
        job=shelf['tracking_job'];g=shelf.get('_ring_g')
        def stopped():return self._closed or generation!=self._generation
        def deliver(rows):
            if rows is None or stopped():return
            rows=rows or [tracking_rows.nothing(job,shelf.get('tracking_from') or '')]
            # kept with the view's row: going round, it comes back with these cards (not loaded: it is worked out again)
            if g is not None and 0<=g<len(self._pages) and self._pages[g].get('tracking_job')==job:self._pages[g]['rows']=rows
            self._updates.put((generation,index,rows,None,g))
        def again():
            if not stopped():deliver(tracking_rows.load(job,self._continue_rows(),stopped))
        try:deliver(tracking_rows.load(job,self._continue_rows(),stopped,later=again))
        except Exception:
            xbmc.log('[MegaNexus] %s row not loaded: %s'%(job,traceback.format_exc(limit=3)),xbmc.LOGWARNING)

    def _continue_rows(self):
        """9.0.8: the cards Continue Watching shows now ([] when it is not on this view)."""
        shelves=self._shelves if self._holds_first() else (getattr(self,'_pages',None) or [])
        shelf=shelves[0] if shelves else None
        return list(shelf.get('rows') or []) if shelf and shelf.get('continue_job') else []

    def _tracking_dedupe(self):
        """9.0.8: a show Continue Watching took in (its next episode came behind Home) leaves Next episodes at
        once - plain Python on the cards, no file read; the row's own load works it out again later."""
        try:
            from resources.lib import tracking_rows
            shown=None
            for index,shelf in enumerate(self._shelves):
                if shelf.get('tracking_job')!=tracking_rows.NEXT or not any(r.get('target') for r in shelf.get('rows') or []):continue
                if shown is None:shown=tracking_rows.continue_keys(self._continue_rows())
                rows=shelf.get('rows') or []
                kept=[r for r in rows if not r.get('target') or not tracking_rows.card_keys(r)&shown]
                if len(kept)==len(rows):continue
                kept=kept or [tracking_rows.nothing(tracking_rows.NEXT)]
                shelf['rows']=kept
                self._set_rows(index,kept,background=True)   # nothing moves under the cursor
        except Exception:
            xbmc.log('[MegaNexus] Next episodes not checked: '+traceback.format_exc(limit=3),xbmc.LOGDEBUG)

    def _reload_tracking(self, job=None):
        """9.0.8: the Watchlist / Next episodes rows worked out again by their load (a worker) - after a change
        to what they show (progress synced, a title removed from the Library); the cards change where they stand."""
        for index,shelf in enumerate(self._shelves):
            if shelf.get('tracking_job') and (job is None or shelf['tracking_job']==job):
                shelf['_loaded']=False
                self._scheduled.discard(index)
        self._queue_visible()

    def _refresh_posters(self):
        from resources.lib import home_posters
        try:
            if home_posters.stale(home_posters.saved()):home_posters.build(stopped=lambda:self._closed)
        except Exception:
            xbmc.log('[MegaNexus] Posters wall not refreshed: '+traceback.format_exc(),xbmc.LOGDEBUG)

    def _align_columns(self, index, pos):
        """7.0.48: MegaNexus posters - the rows above and below keep the column the cursor
        is in, so Up / Down go straight up and down the wall (the arrows never reach
        Python: the neighbours are set ahead, once per move)."""
        if getattr(self,'_aligned',None)==(self._generation,index,pos) or not self._shelves[index].get('posters_row'):return
        self._aligned=(self._generation,index,pos)
        for other in (index-1,index+1):
            if 0<=other<len(self._shelves) and self._shelves[other].get('posters_row'):
                try:self.getControl(ROW_BASE+other).selectItem(min(pos,len(self._shelves[other]['rows'])-1))
                except Exception:pass

    def _may_retry(self,index):
        """True when this row may ask a missing source again: one row at a time, and
        not the same row more often than RELOAD_AGAIN.

        Without this the Collections view turns every failing provider into twelve
        workers doing nothing but waiting - the screen stops answering while they do.
        """
        now=time.monotonic()
        held=getattr(self,'_retrying',None)
        if held is None:held=self._retrying={}
        if held.get('busy') and now-held.get('since',0)<30:return False
        if now-held.get(index,0)<RELOAD_AGAIN:return False
        held[index]=now;held['busy']=True;held['since']=now
        return True

    def _retry_done(self):
        held=getattr(self,'_retrying',None)
        if held is not None:held['busy']=False

    def _grow_rows(self):
        """7.0.48: "Browse all" off - the focused catalog row goes on by itself: once the
        cursor is GROW_AHEAD cards from its end, its next titles load in the background
        (catalog_pages, as the grid's Load more) and are added at the end of the row; the
        row is not drawn again and the cursor stays where it is."""
        _seen=None
        for _ in range(4):
            try:generation,index,rows,jobs,g=self._grown.get_nowait()
            except queue.Empty:break
            if self._ring_g is not None and (not 0<=index<len(self._shelves) or self._ring_g[index]!=g):continue   # that row went round
            if generation==self._generation and 0<=index<len(self._shelves):
                if _seen is None:_seen=simkl_watched.snapshot()   # once for all four
                self._append_rows(index,rows,jobs,watched=_seen)
        control_id,pos,_=self._selection();index=control_id-ROW_BASE
        if not 0<=index<len(self._shelves) or pos<0:return
        self._align_columns(index,pos)
        if self._suspended or not self._pool:return
        shelf=self._shelves[index]
        if not shelf.get('_loaded') or shelf.get('_growing') or not self._grows(shelf) or pos<len(shelf['rows'])-GROW_AHEAD:return
        shelf['_growing']=True
        self._pend(index)
        self._futures.append(self._pool.submit(self._grow,index,self._grow_what(shelf),shelf.get('_jobs'),self._generation,shelf.get('_ring_g')))

    def _grow_what(self,shelf):
        """What a growing row's next titles are asked with: its catalog's query (9.1.2: an app's rows their own)."""
        from urllib.parse import urlsplit,parse_qs
        return {k:v[0] for k,v in parse_qs(urlsplit(shelf['path']).query).items()}

    def _grows(self,shelf):
        """7.0.48: a catalog row that goes on by itself ("Browse all" off) until its last titles are in."""
        path=shelf.get('path') or ''
        return (not getattr(self,'_browse_all',True) and not shelf.get('_grow_done')
                and ('action=meganexus_collection' in path or 'action=catalog_all' in path))

    def _set_right(self,index):
        """Right on a row's last card goes round to its first (the row points at itself) -
        except on a row that still grows: it points at the row's name (a label, never
        focused), so the cursor waits on the last card until the next titles are added."""
        self._link_right(index,(ROW_TITLE if self._grows(self._shelves[index]) else ROW_BASE)+index)

    def _link_right(self,index,target):
        """7.0.50: a row's Right set only when it changes - every call waits for Kodi's drawing
        thread (on the Cube Home took a second longer to draw). 9.0.4: Up / Down are the skin's."""
        nav=getattr(self,'_nav',None)
        if nav is None:nav=self._nav={}
        if nav.get(index)==target:return
        try:
            self.getControl(ROW_BASE+index).controlRight(self.getControl(target))
            nav[index]=target
        except Exception:pass

    def _pend(self,index):
        """9.0.4: empty cards at the row's end while its next titles load - Right goes on into them
        (as the rows going round: a card not ready yet comes empty, never waits), filled in place."""
        shelf=self._shelves[index];missing=GROW_SLOTS-shelf.get('_pending',0)
        if missing<=0:return
        control=self.getControl(ROW_BASE+index);pos=control.getSelectedPosition()
        empty=[]
        for _ in range(missing):
            empty.append(listitems.item(label=''))
        control.addItems(empty)
        if pos>0:control.selectItem(pos)
        shelf['_pending']=GROW_SLOTS

    def _grow(self,index,params,jobs,generation,g=None):
        from resources.lib import catalog_pages
        stopped=lambda:self._closed or generation!=self._generation
        try:
            if jobs is None:jobs=catalog_pages.jobs_for(params)
            result=catalog_pages.fetch_page(jobs,stopped=stopped)
        except Exception:result=None
        if not stopped():self._grown.put((generation,index,)+(result if result else ([],None))+(g,))

    def _append_rows(self,index,rows,jobs,watched=None):
        shelf=self._shelves[index];shelf['_growing']=False
        if jobs is None:   # failed: the row stays as it is
            shelf['_grow_done']=True;self._unpend(index);self._set_right(index);return
        shelf['_jobs']=jobs
        known=set(self._row_ids.get(index) or [self._identity(r) for r in shelf['rows']])
        new=[]
        for row in rows:
            identity=self._identity(row)
            if (row.get('target') or row.get('youtube')) and identity not in known:known.add(identity);new.append(row)
        if all(job['done'] for job in jobs):shelf['_grow_done']=True
        if not new:
            if shelf.get('_grow_done'):self._unpend(index);self._set_right(index)
            return
        # 8.1.2: handed down by the caller when it is drawing more than one row - this
        # asks five files whether they changed, and twelve of those per paint is what
        # the loop watchdog caught Home sitting in.
        watched_data=self._badges_data=watched if watched is not None else simkl_watched.snapshot();sigs=self._card_sigs.setdefault(index,[])
        control=self.getControl(ROW_BASE+index);start=len(shelf['rows'])
        # 9.0.4: the empty cards at the end take the titles where they stand - no list bound again
        pending=min(shelf.get('_pending',0),len(new))
        for k,row in enumerate(new[:pending]):
            li=control.getListItem(start+k)
            self._fill(li,row,watched_data,relabel=True);sigs.append(self._filled)
        shelf['_pending']=shelf.get('_pending',0)-pending
        items=[]
        for row in new[pending:]:
            li=listitems.item(label=without_emoji(row.get('title') or 'Untitled'),label2=without_emoji(row.get('subtitle') or ''))
            self._fill(li,row,watched_data);sigs.append(self._filled);items.append(li)
        if items:
            # Kodi binds the whole list again on addItems (the cursor goes to the first card):
            # it is put back on its card at once (a list just bound does not scroll)
            pos=control.getSelectedPosition()
            control.addItems(items)
            if pos>0:control.selectItem(pos)
        shelf['rows']=shelf['rows']+new
        self._row_ids.setdefault(index,[]).extend(self._identity(r) for r in new)
        if shelf.get('_grow_done'):self._unpend(index);self._set_right(index)

    def _unpend(self,index):
        """The row is whole: the empty cards left at its end go (the cursor on one of them goes to its last title)."""
        shelf=self._shelves[index];left=shelf.get('_pending',0)
        if not left:return
        control=self.getControl(ROW_BASE+index);last=len(shelf['rows'])-1
        if control.getSelectedPosition()>last:control.selectItem(max(0,last))
        for _ in range(left):control.removeItem(control.size()-1)
        shelf['_pending']=0

    def _ratings_tick(self):
        """7.0.29: the focused title's ratings beside its details line - from the
        cache at once, MDBList's request only once the cursor rests on it."""
        try:selection=self.preview_selection()
        except Exception:selection=None
        key=None
        if selection:
            target=selection[1].get('target') or {}
            key=(target.get('media_type'),target.get('canonical_id'))
        now=time.monotonic()
        if key!=getattr(self,'_ratings_key','-'):
            self._ratings_key=key;self._ratings_at=now;self._ratings_asked=False;self._release_asked=False
            # 8.1.3: when it would end if started now - worked out the moment it is focused
            left=int((selection[1].get('remaining_seconds') or 0) if selection else 0)
            ends=('Ends %s'%time.strftime('%H:%M',time.localtime(time.time()+left))) if left>=60 else ''
            if ends!=getattr(self,'_ends_shown',''):
                self._ends_shown=ends;self.setProperty('meganexus.ends',ends)
            from resources.lib import ratings_row
            self._release_badge(selection[1] if selection else None)
            if not selection:ratings_row.clear(self);return
            row=selection[1];target=row.get('target') or {}
            self._ratings_meta=dict(id=target.get('canonical_id'),imdb_id=target.get('imdb_id'),tmdb_id=target.get('tmdb_id'),type=target.get('media_type'))
            own=(row.get('rating_icon') or '',row.get('rating_value') or '') if row.get('rating_value') else None
            self._ratings_fetch=None
            def later(load):self._ratings_fetch=load
            ratings_row.publish_for(self,self._ratings_meta,own,later)
        if key and not getattr(self,'_release_asked',True) and now-self._ratings_at>RATINGS_DWELL:
            self._release_asked=True;self._release_dates(key,selection[1])
            self._look_ahead()
        if key and getattr(self,'_ratings_fetch',None) and not self._ratings_asked and now-self._ratings_at>RATINGS_DWELL:
            self._ratings_asked=True;load=self._ratings_fetch;wanted=key
            def work():
                try:ratings=load()
                except Exception:return
                # 8.1.4: and not once Kodi is closing - this thread would draw on its way down
                if ratings and not self._closed and not xbmc.Monitor().abortRequested() and getattr(self,'_ratings_key',None)==wanted:
                    from resources.lib import ratings_row
                    ratings_row.publish(self,ratings)
            threading.Thread(target=work,name='MegaNexusHomeRatings',daemon=True).start()

    def _look_ahead(self):
        """8.1.3: "ocjene se pojavljuju presporo". The titles after the one the cursor
        rests on (and the one before) get their ratings and release dates now, one by
        one in a thread of their own, so moving on shows them at once from memory."""
        try:
            cid,pos,_=self._selection();index=cid-ROW_BASE
            rows=self._shelves[index]['rows'] if 0<=index<len(self._shelves) else []
        except Exception:
            return
        picks=[rows[i] for i in range(max(0,pos-1),min(len(rows),pos+LOOK_AHEAD+1)) if i!=pos]
        # and the cards Up / Down land on - the rows above and below, at this place
        for near in (index+1,index-1):
            if 0<=near<len(self._shelves):
                other=self._shelves[near].get('rows') or []
                picks+=other[max(0,pos-1):pos+3]
        self._lookahead(picks)

    def _lookahead(self,picks,first=False):
        picks=[row for row in picks if (row.get('target') or {}).get('canonical_id') and not row.get('person')]
        if not first:
            self._lookahead_rows=(self._generation,picks)
        else:                                    # after a paint: the start of every row
            self._lookahead_rows=(self._generation,picks+[r for r in getattr(self,'_lookahead_rows',(None,[]))[1] if r not in picks])
        job=getattr(self,'_lookahead_job',None)
        if (picks or first) and (job is None or not job.is_alive()):
            self._lookahead_job=threading.Thread(target=self._lookahead_work,name='MegaNexusLookAhead',daemon=True)
            self._lookahead_job.start()

    def _lookahead_work(self):
        from resources.lib import ratings_row,release_info
        try:
            from resources.lib import mdblist_api
            mdb=mdblist_api.configured() and ratings_row.any_enabled()
        except Exception:
            mdb=False
        def keys_rest():
            # never while keys are being pressed: on a CoreELEC box this thread's Python
            # would take its turns from the one that draws and reads the remote
            monitor=xbmc.Monitor()
            while not self._closed and time.monotonic()-getattr(self,'_last_key',0.)<.4:
                if monitor.waitForAbort(.1):return False
            return not self._closed
        if not keys_rest():return
        if mdb:
            # 8.1.3: every card's ratings in one request (MDBList takes 200 a time; the
            # ones known today are skipped) - moving shows them at once from memory
            # only cards not handed over before: this runs after every paint and after
            # every row that arrives, and Home holds hundreds of cards
            sent=getattr(self,'_ratings_sent',None)
            if sent is None:sent=self._ratings_sent=set()
            titles=[]
            for shelf in self._shelves:
                for row in shelf.get('rows') or []:
                    target=row.get('target') or {}
                    cid=target.get('canonical_id')
                    if cid and cid not in sent and not row.get('person'):
                        sent.add(cid)
                        imdb,tmdb,kind=ratings_row.ids(dict(id=cid,imdb_id=target.get('imdb_id'),
                                                             tmdb_id=target.get('tmdb_id'),type=target.get('media_type')))
                        titles.append((kind,imdb,tmdb))
            if titles:
                try:mdblist_api.preload_ratings(titles,stopped=lambda:self._closed)
                except Exception:pass
        done=set()
        while not self._closed:
            generation,picks=getattr(self,'_lookahead_rows',(None,[]))
            todo=[row for row in picks if id(row) not in done]
            if not todo or generation!=self._generation:return
            row=todo[0];done.add(id(row))
            if not keys_rest() or browse_cache.playback_busy():return
            target=row.get('target') or {}
            meta=dict(id=target.get('canonical_id'),imdb_id=target.get('imdb_id'),tmdb_id=target.get('tmdb_id'),type=target.get('media_type'))
            try:
                if mdb:
                    imdb,tmdb,kind=ratings_row.ids(meta)
                    if (imdb or tmdb) and not mdblist_api.cached_ratings(imdb_id=imdb,media_type=kind,tmdb_id=tmdb):
                        mdblist_api.ratings_of(imdb_id=imdb,media_type=kind,tmdb_id=tmdb)
                release_info.card_badge(row,cached_only=False)
            except Exception:
                pass

    def _release_badge(self,row,dates=None):
        """7.0.32: the focused title's release badge under its details line (as on
        the title page): from the card's release date at once; a film's TMDB
        dates (In cinemas / Released) once the cursor rests on it."""
        from resources.lib import release_info
        kind=text=status=''
        if row and row.get('target'):
            if dates is not None:kind,text=dates   # fetched for this card
            else:kind,text=release_info.card_badge(row,cached_only=True)   # 7.0.36: TMDB's dates kept at start
            status=release_info.card_status(row) if kind else ''   # 7.0.37: a series' Ongoing / Ended
        if (kind,text,status)!=getattr(self,'_release_shown',('','','')):
            self._release_shown=(kind,text,status)
            self.setProperty('meganexus.release.status',status)
            self.setProperty('meganexus.release.date',text if kind else '');self.setProperty('meganexus.release.kind',kind)
        # 8.1.3: the words after the badges, cut to the room the badges leave (meta_fit) -
        # "Series | 2012 | S15 · E2 | 38% watched | 41 min left" and "Ends 14:05" ran out
        # of the row behind a status and a weekday badge
        line=meta_fit.fit((row or {}).get('meta_line') or '',getattr(self,'_ends_shown',''),
                          meta_fit.room(kind,status,text if kind else ''))
        if line!=getattr(self,'_meta_shown',None):
            self._meta_shown=line;self.setProperty('meganexus.metaline',line)

    def _release_dates(self,key,row):
        """A card not in the start's preload: its TMDB dates once the cursor rests."""
        row=dict(row)
        def work():
            from resources.lib import release_info
            try:badge=release_info.card_badge(row,cached_only=False)
            except Exception:return
            if badge[0] and not self._closed and not xbmc.Monitor().abortRequested() and getattr(self,'_ratings_key',None)==key:self._release_badge(row,badge)
        threading.Thread(target=work,name='MegaNexusHomeRelease',daemon=True).start()

    def first_rows_ready(self):
        """7.0.42: the rows Home loaded first (the visible ones) are filled and drawn.
        7.0.45: a row counts once its first rows are drawn - Continue Watching's network
        refresh (next episodes, other ids, artwork) goes on behind Home, not behind the
        opening screen (it held it up to 11 s on the Cube)."""
        if set(self._scheduled)<=getattr(self,'_drawn',set()):return True
        return all(future.done() for future in list(self._futures)) and self._updates.empty()

    def first_rows_progress(self):
        """7.0.45: the share of those rows drawn, for the opening screen's ring."""
        scheduled=set(self._scheduled)
        return len(scheduled&getattr(self,'_drawn',set()))/float(len(scheduled)) if scheduled else 1.

    FROM_PLAYER='meganexus.home.from_player'   # the player's Home button (foreground_guard.park)

    def _came_from_the_player(self):
        """Home was asked for from the film: the cursor belongs on the Home pill.

        8.1.2: the film plays on behind Home and the round Now playing brings it back.
        Home may already be open behind the player, so this is read in the loop rather
        than only when the window starts."""
        if self._nested:return      # a collection screen: Home gets it when it is back
        # 8.1.2: once a second. This runs in the window's loop, twenty times a second,
        # and every ask is a call into Kodi - the rows are drawn through the same door.
        now=time.monotonic()
        if now-getattr(self,'_asked_player',0.0)<1.0:return
        self._asked_player=now
        window=xbmcgui.Window(10000)
        if not window.getProperty(self.FROM_PLAYER):return
        window.clearProperty(self.FROM_PLAYER)
        try:self.setFocusId(101)
        except Exception:pass

    def drain_updates(self):
        # 8.1.1: Home and the collection screen run their own loops, not Dialog.doModal,
        # so this is where a focus Kodi could not give yet is asked for again.
        self._came_from_the_player()
        self._bar_tick()
        self._take_focus()
        self.drain_events()
        if self._closed:return
        self._draw_queued()
        self._apply_focus()
        self._ratings_tick()
        self._update_row_coverage()
        self._queue_visible()
        try:self._grow_rows()
        except Exception:
            xbmc.log('[MegaNexus] Row growth skipped: '+traceback.format_exc(),xbmc.LOGDEBUG)
        now=time.monotonic()
        if now-self._last_progress_check>=.5:
            self._last_progress_check=now
            # 7.0.53: Watch Party - the host's film starts from here, like a click (beside the
            # interface it played behind Home and the film guard paused it)
            if xbmcgui.Window(10000).getProperty('meganexus.party.start') and not self._suspended:
                from .party import take_handover
                if take_handover(self):
                    self._pending='playing';self._finish();return
            revision=xbmcgui.Window(10000).getProperty('meganexus.progress.revision')
            if revision not in (self._progress_revision,getattr(self,'_seen_revision',None)) and not self._navigating(0):   # 7.0.29: not under the remote
                self._seen_revision=revision
                if not self._bucket and self._holds_first() and self._shelves and self._shelves[0].get('continue_job'):
                    shelf=home_data.continue_shelf();shelf['progress_revision']=revision
                    # 9.0.0: a sync that brings back what is already shown (Nuvio returns the
                    # progress we have just sent) is no change: no new row, no 5 s of next
                    # episodes on a TV box, no second redraw after every film. The row's own
                    # revision stays, so a load still running for it is not cut off.
                    shelf['_signature']=_continue_signature(shelf)
                    xbmcgui.Window(10000).setProperty('meganexus.home.progress_seen',revision)
                    if shelf['_signature']!=self._shelves[0].get('_signature'):
                        self._progress_revision=revision
                        self._shelves[0]=shelf;self._set_rows(0,shelf['rows'],background=True)
                        if getattr(self,'_pages',None):self._pages[0]=shelf
                        if self._pool:self._futures.append(self._pool.submit(self._load,0,dict(shelf),self._generation))
                        # 9.0.8: and Next episodes follows - its shows now in Continue Watching go, episodes watched move on
                        self._tracking_dedupe();self._reload_tracking('next_episodes')
        if self._previews:
            try:self._previews.tick()
            except Exception:
                self._previews.close()
                xbmc.log('[MegaNexus] Preview stopped after a player error.',xbmc.LOGWARNING)
        try:self._show_ahead()
        except Exception:pass
        try:self._maybe_prefetch()
        except Exception:
            xbmc.log('[MegaNexus] Collection prefetch skipped: '+traceback.format_exc(),xbmc.LOGDEBUG)
        # 9.0.1: cards held back while the cursor was on their row join it once it left
        for index in list(getattr(self,'_grow_later',()) or ()):
            if self._selection()[0]==ROW_BASE+index:continue
            self._grow_later.discard(index)
            if index<len(self._shelves):self._set_rows(index,self._shelves[index]['rows'],background=True)
        # Workers only enqueue data. The window owner applies Kodi controls.
        #
        # 8.1.2: one update per shelf - the newest. Continue Watching reports every title
        # as its details arrive (7.0.45, so the row is never blank while it waits), and
        # twenty of those landed in a single drain here: 44 cards taken down and rebuilt
        # twenty times inside 70 ms. Every one but the last was already out of date, and
        # rebuilding for each of them is what made the first poster flash as the row was
        # replaced under the cursor - it looked like the card being selected twice.
        collected = {}
        badges = posters = False
        for _ in range(32):
            try:
                update = self._updates.get_nowait()
            except queue.Empty:
                break
            generation, index, _rows = update[:3]
            if self._closed or generation != self._generation:continue
            if len(update)>3 and update[3] is not None and update[3]!=self._progress_revision:continue
            if index==-1:badges=True;continue
            if index==-3:self._refit_logos();continue
            if index==-2:posters=True;continue
            if self._ring_g is not None and len(update)>4 and update[4]!=self._ring_g[index]:continue   # 9.0.4: that row went round
            collected[index]=update              # a later one for this shelf replaces it
        if badges:self._watched_badges()
        if posters:   # 7.0.48: the posters wall is made - drawn now
            if not self._bucket:
                self._quiet=True
                try:self._paint(home_data.initial_shelves())
                finally:self._quiet=False
            return
        # 8.1.2: a few rows at a time, with the remote asked in between.
        #
        # Every arriving row was drawn in this one pass - twelve of them, 16-120 ms
        # each - while key presses are only taken at the top of the pass. Scrolling to
        # the bottom of Home starts a dozen loads at once, so Home stopped answering for
        # as long as they took: "home je smrznut kad se spustam dolje i treba da ucita
        # postere". Kodi itself was never stuck - the screensaver still came and went.
        #
        # The rows that do not fit in ROW_BUDGET go back in the queue and are drawn by
        # the next pass, fifty milliseconds later.
        waiting = sorted(collected)
        continued = False
        _seen = simkl_watched.snapshot() if waiting else None     # once for this pass
        until = time.monotonic() + ROW_BUDGET
        for position, index in enumerate(waiting):
            if position and time.monotonic() >= until:
                for later in waiting[position:]:
                    self._updates.put(collected[later])
                break
            update = collected[index]
            rows = update[2]
            rows = rows or [home_data.placeholder('No titles found', 'Try another collection or check Settings.')]
            # 9.0.4: "the same cards" only counts when they are on screen - a row filled from memory and
            # waiting to be drawn (going round: emptied first) stayed empty for good when its load said the same
            unchanged=(self._shelves[index].get('_loaded') and rows==self._shelves[index].get('rows')
                       and bool((getattr(self,'_row_ids',None) or {}).get(index)))
            if not unchanged and self._navigating(index):
                # 7.0.29: never under the remote - this row changes once the keys rest.
                self._updates.put(update);continue
            self._shelves[index]['rows'] = rows
            self._shelves[index]['_loaded'] = True
            self._remember_rows(self._shelf_key(self._shelves[index]),rows)
            # A cache-seeded shelf that reloads identical data keeps its items,
            # textures and selection: no flicker and no wasted GUI work.
            if not unchanged:self._set_rows(index, rows, watched=_seen, background=True)
            if not unchanged and self._shelves[index].get('continue_job'):continued=True   # 9.0.8: Next episodes follows
            if index in getattr(self,'_row_queue',()):self._row_queue.remove(index)
            if not hasattr(self,'_drawn'):self._drawn=set()
            # 8.1.1: a row arriving after the screen opened was the one step nothing
            # recorded, so "the collection opens empty" could not be told apart from
            # "it filled and the pictures were slow". Now the log says which, when.
            if not unchanged:
                try:
                    xbmc.log('[MegaNexus][perf] Row filled: %d cards · %s · %s · %d ms after the screen'
                             % (len(rows), self._bucket or 'home',
                                str(self._shelves[index].get('title') or '?')[:40],
                                int((time.monotonic() - getattr(self, '_painted_at', time.monotonic())) * 1000)),
                             xbmc.LOGINFO)
                except Exception:
                    pass
            self._drawn.add(index)   # 7.0.45: drawn - the opening screen may go
        if continued:self._tracking_dedupe()
        if waiting:
            self._learn_logos()   # 8.1.3: rows that came later bring logos of their own
            self._lookahead([],first=True)   # ... and titles whose ratings are not known yet

    def _draw_queued(self):
        """8.1.3: the rows a paint left for later, a budget of them per pass.

        A page of Home is twelve rows of cards and drawing them all in one go held the
        window's own loop for seconds: no key was read and nothing was redrawn, which
        is the freeze at the bottom of Home. _paint_rows draws the rows at the cursor
        and leaves the rest here, nearest first."""
        queue_=getattr(self,'_row_queue',None)
        if not queue_:return
        watched=simkl_watched.snapshot()
        until=time.monotonic()+ROW_BUDGET
        drawn=0
        while queue_:
            index=queue_[0]
            if drawn and time.monotonic()>=until:break
            queue_.pop(0)
            if not 0<=index<len(self._shelves):continue
            rows=self._shelves[index].get('rows') or []
            if not rows:continue
            try:
                with perf.timed('  paint/row %d late' % index, cards=len(rows)):
                    self._set_rows(index,rows,watched=watched)
            except Exception:
                xbmc.log('[MegaNexus] Row %d skipped: %s'%(index,traceback.format_exc()),xbmc.LOGDEBUG)
            self._paint_cards=getattr(self,'_paint_cards',0)+len(rows)
            if not hasattr(self,'_drawn'):self._drawn=set()
            self._drawn.add(index)
            drawn+=1

    def _learn_logos(self):
        """8.1.3: the sizes of logos not seen before - their first bytes only, in the
        background, kept for good (logo_size). Then the row under the cursor is fitted."""
        job=getattr(self,'_logo_job',None)
        if job is not None and job.is_alive():return
        urls=[row.get('clearlogo') for shelf in self._shelves for row in (shelf.get('rows') or [])]
        if not logo_size.missing(urls):return
        generation=self._generation

        def work():
            if logo_size.learn(urls,stopped=lambda:self._closed) and not self._closed:
                self._updates.put((generation,-3,None))
        # its own thread, never one of the workers that load the rows
        self._logo_job=threading.Thread(target=work,name='MegaNexusLogoSizes',daemon=True)
        self._logo_job.start()

    def _refit_logos(self):
        try:
            cid,_,_=self._selection();index=cid-ROW_BASE
            if not 0<=index<len(self._shelves):return
            control=self.getControl(cid);rows=self._shelves[index].get('rows') or []
            for at,row in enumerate(rows[:control.size()]):
                fit=logo_size.fit(row.get('clearlogo'),collection=bool(row.get('collection_id')))
                if fit:control.getListItem(at).setProperty('logo_fit',fit)
        except Exception:
            pass

    def _playback_busy(self):
        """8.1.3: browse_cache.playback_busy, asked twice a second at most. The loop asked
        it on every pass - two or three calls into Kodi twenty times a second, all the
        time Home was on screen (10-25 ms a call on a CoreELEC box)."""
        now=time.monotonic()
        if now-getattr(self,'_busy_asked',0.)>=.5:
            self._busy_asked=now;self._busy_value=browse_cache.playback_busy()
        return self._busy_value

    def _maybe_prefetch(self):
        """Warm the collection under the cursor (and its neighbours) off the GUI
        thread once selection settles, so Select opens it from memory."""
        if self._closed or self._suspended or self._playback_busy():return
        control_id,pos,_=self._selection();index=control_id-ROW_BASE
        if not 0<=index<len(self._shelves) or pos<0:return
        now=time.monotonic()
        if self._hover[0]!=(index,pos):
            self._hover=((index,pos),now)
            if self._anim_focus:   # the cursor moved: the next card's cover, its animation later
                self._anim_focus=None;self.setProperty('meganexus.anim_ready','')
            return
        if now-self._hover[1]<PREFETCH_DWELL:return
        rows=self._shelves[index]['rows']
        if 0<=pos<len(rows) and rows[pos].get('target') and not rows[pos].get('person'):
            # 7.0.21: once per title the cursor rests on, not on every tick of the
            # window loop (each check read the add-on settings: 15 times a second
            # on CoreELEC while a title was selected).
            asked=(self._generation,index,pos,rows[pos]['target'].get('canonical_id'))
            if now-self._hover[1]>=DETAILS_DWELL and self._details_asked!=asked:
                self._details_asked=asked
                browse_meta.prefetch(rows[pos]['target'])
            return
        if 0<=pos<len(rows) and rows[pos].get('animation'):self._animate(rows[pos]['animation'],(index,pos))
        wanted=[rows[c]['collection_id'] for c in (pos,pos+1,pos-1)
                if 0<=c<len(rows) and rows[c].get('collection_id')]
        focused=rows[pos].get('collection_id') if 0<=pos<len(rows) else None
        if focused and focused!=getattr(self,'_ahead_for',None) and self._prefetched.get(focused,0)>now and self._prefetch_pool:
            self._ahead_for=focused   # loaded before: only its pictures again (7.0.32)
            self._prefetch_futures.append((focused,self._prefetch_pool.submit(self._load_ahead,focused,self._memory_epoch)))
        wanted=[cid for cid in wanted if self._prefetched.get(cid,0)<=now]
        if not wanted:return
        # The cursor moved on: queued work for tiles it left is dropped, so
        # the single worker always serves the tile the user is looking at.
        pending=[]
        for cid,future in self._prefetch_futures:
            if future.done():continue
            if future.cancel():self._prefetched.pop(cid,None)
            else:pending.append((cid,future))
        self._prefetch_futures=pending
        if self._prefetch_pool is None:
            self._prefetch_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='MegaNexusPrefetch')
        for collection_id in wanted:
            self._prefetched[collection_id]=now+PREFETCH_AGAIN
            if len(self._prefetched)>256:self._prefetched.pop(next(iter(self._prefetched)))
            if collection_id==focused:self._ahead_for=focused
            self._prefetch_futures.append((collection_id,self._prefetch_pool.submit(self._prefetch_collection,collection_id,self._memory_epoch,collection_id==focused)))

    def _play_animation(self, ready, focus):
        """One full pass on the resting card, then its cover again."""
        self._anim_focus=(focus,ready);self._anim_until=0
        seconds=self._anim_seconds.get(ready)
        if seconds is None:
            try:
                import xbmcvfs
                path=xbmcvfs.translatePath(ready) if ready.startswith('special://') else ready
                with open(path,'rb') as handle:seconds=art_cache.gif_seconds(handle.read())
            except (OSError,ValueError):seconds=0
            self._anim_seconds[ready]=seconds
        if seconds>0:self._anim_until=time.monotonic()+seconds+.15
        self.setProperty('meganexus.anim_ready',ready)

    def _animate(self, source, focus):
        """7.0.21: the focused collection's animation plays once it is stored as
        a small GIF (converted once through the image proxy, then from disk):
        Kodi loads an animated picture on its drawing thread, so it must never
        wait for the network there. One request at a time; the latest card wins."""
        ready=art_cache.animation(source)
        if not ready:return
        if self._anim_focus==(focus,ready):
            if self._anim_until and time.monotonic()>=self._anim_until:
                self._anim_until=0;self.setProperty('meganexus.anim_ready','')
            return
        if ready==self._anim[1]:
            self._play_animation(ready,focus);return
        if time.monotonic()<self._anim_failed.get(ready,0):return
        prepare=art_cache.animation_source(source)
        if not prepare:   # a local GIF plays as it is
            self._anim[1]=ready;self._play_animation(ready,focus);return
        self._anim[0]=(ready,prepare)
        if self._anim[2]:return
        self._anim[2]=True
        def work():
            from urllib.request import Request, urlopen
            try:
                while not self._closed and self._anim[0] and self._anim[0][0]!=self._anim[1]:
                    wanted=self._anim[0]
                    try:
                        with urlopen(Request(wanted[1],method='HEAD'),timeout=12) as response:response.read(0)
                    except Exception:
                        self._anim_failed[wanted[0]]=time.monotonic()+300   # the cover stays; tried again later
                        if len(self._anim_failed)>64:self._anim_failed.pop(next(iter(self._anim_failed)))
                        if self._anim[0]==wanted:self._anim[0]=None
                        continue
                    self._anim[1]=wanted[0]   # the window loop starts it on the resting card
            finally:self._anim[2]=False
        threading.Thread(target=work,name='MegaNexusAnimation',daemon=True).start()

    def _prefetch_collection(self, collection_id, epoch, ahead=False):
        if self._closed or epoch!=self._memory_epoch:return
        from resources.lib.collections_home import collection_shelves
        for shelf in collection_shelves(collection_id):
            if self._closed or epoch!=self._memory_epoch:return
            key=self._shelf_key(shelf)
            if not key or self._remembered(key):continue
            try:rows=home_data.load_catalog(shelf,stopped=lambda:self._closed or epoch!=self._memory_epoch)
            except Exception:continue  # Opening the collection retries normally.
            self._remember_rows(key,rows,epoch)
            self._warm_art(rows)
        if ahead:self._load_ahead(collection_id,epoch)

    def _load_ahead(self, collection_id, epoch):
        """7.0.32: the pictures the collection opens with - the first cards of its
        rows, the first title's background and logo - go to Kodi's memory while
        the cursor rests on its tile (hidden images, meganexus.ahead.N), so they
        are there at once when it opens instead of appearing one by one."""
        from resources.lib.collections_home import collection_shelves
        base=xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
        if not base.startswith('http://127.0.0.1:') and not art_cache.native():return
        urls=[]
        for index,shelf in enumerate(collection_shelves(collection_id)[:AHEAD_ROWS]):
            rows=[r for r in self._remembered(self._shelf_key(shelf)) or [] if r.get('target')]
            landscape=shelf.get('shape',getattr(self,'_card_shape','poster'))=='landscape'
            for row in rows[:AHEAD_CARDS]:
                url=precache.card_art(row,landscape)
                if url.startswith(('https://','http://')) and '|' not in url:
                    urls.append(kodi_textures.texture(kodi_textures.proxy_url(base,url)))
            if index==0 and rows:
                for key in ('fanart','clearlogo'):
                    url=str(rows[0].get(key) or '')
                    if url.startswith(('https://','http://')) and '|' not in url:urls.append(art_cache.url(url))
        if art_cache.native():   # 8.1.0: fetched on 12 connections before Kodi asks for them
            for url in urls[:AHEAD_SLOTS]:art_cache.ahead(art_cache.uncard(url))
        if not self._closed and epoch==self._memory_epoch:self._ahead=(collection_id,urls[:AHEAD_SLOTS])

    def _show_ahead(self):
        """Window owner: hand the prepared pictures to the hidden images."""
        ahead,self._ahead=getattr(self,'_ahead',None),None
        if ahead is None:return
        collection_id,urls=ahead
        control_id,pos,_=self._selection();index=control_id-ROW_BASE
        rows=self._shelves[index]['rows'] if 0<=index<len(self._shelves) else []
        if not (0<=pos<len(rows) and rows[pos].get('collection_id')==collection_id):return   # the cursor moved on
        for slot in range(AHEAD_SLOTS):
            self.setProperty('meganexus.ahead.%d'%slot,urls[slot] if slot<len(urls) else '')

    def _start_cold_art_warm(self):
        """Once per Kodi session (and again after a suspend that emptied it),
        fill the image proxy's RAM with a screen of posters for every collection.
        Cached catalog pages only - no catalog requests - one image at a time,
        pausing whenever the user is navigating, inside a collection or playing
        video. Anything opened later fills in as usual."""
        if self._bucket or getattr(self,'_cold_warm_started',False):return
        self._cold_warm_started=True
        home=xbmcgui.Window(10000)
        base=home.getProperty('meganexus.art_cache.base')
        if art_cache.DIRECT or art_cache.native():return   # 8.1.0: nothing to fill - Kodi keeps them on its disk
        if not base or home.getProperty('meganexus.art_warm.session')==base or home.getProperty('meganexus.art_warm.running'):return
        try:images=int((home.getProperty('meganexus.art_cache.usage') or '0 · 0').split('·')[-1].split()[0])
        except (ValueError,IndexError):images=0
        # The start screen loaded only the first rows: always continue with the rest.
        if images>=COLD_ART_IMAGES and home.getProperty('meganexus.art_warm.front')!=base:return
        home.setProperty('meganexus.art_warm.running',base)
        ids=[row['collection_id'] for shelf in self._shelves for row in shelf.get('rows') or [] if row.get('collection_id')]
        threading.Thread(target=self._cold_art_warm,args=(ids,base),name='MegaNexusArtWarm',daemon=True).start()

    def _cold_art_warm(self, collection_ids, base=''):
        """7.0.7: a screen of every catalog per round, round after round over
        the cached first pages, until they are done or the proxy holds
        kodi_textures.SHARE of the chosen image memory. Posters Kodi already
        keeps on its disk are skipped (it never asks the proxy for them)."""
        from resources.lib.collections_home import collection_shelves
        home=xbmcgui.Window(10000);started=time.monotonic()
        self._art_pool=ThreadPoolExecutor(max_workers=COLD_ART_WORKERS,thread_name_prefix='MegaNexusArtWarm')
        self._art_slots=threading.BoundedSemaphore(COLD_ART_WORKERS)
        try:
            # 7.0.23: right after Kodi starts, this work (all collections' pages
            # and Kodi's texture list) delayed the first collection by 10 s on
            # CoreELEC. It now starts once Home is idle, waits while the user
            # moves, and asks Kodi's thumbnail files instead of its database.
            if not self._wait_idle(COLD_ART_DELAY):return
            self._kodi_has=set()
            self._art_budget=kodi_textures.budget()
            self._art_counts=[0,0,0]
            pages=[]
            for collection_id in collection_ids:
                if not self._wait_idle():return  # The next Home window resumes; warmed images are instant.
                try:shelves=collection_shelves(collection_id)
                except Exception:continue
                for shelf in shelves:
                    if not self._wait_idle():return
                    try:rows=home_data.load_catalog(shelf,cached_only=True)
                    except Exception:rows=None
                    rows=[r for r in rows or [] if r.get('target')]
                    if rows:
                        if not self._warm_art(rows,COLD_ART_PER_SHELF,background=True):return
                        if len(rows)>COLD_ART_PER_SHELF:pages.append(rows)
            start=COLD_ART_PER_SHELF
            while pages:
                for rows in pages:
                    if self._closed or not self._warm_art(rows[start:],COLD_ART_PER_SHELF,background=True):return
                start+=COLD_ART_PER_SHELF
                pages=[rows for rows in pages if len(rows)>start]
            home.setProperty('meganexus.art_warm.session',base)
        finally:
            pool,self._art_pool=self._art_pool,None
            pool.shutdown(wait=False)
            home.clearProperty('meganexus.art_warm.running')
            counts=getattr(self,'_art_counts',None)
            if counts:xbmc.log('[MegaNexus] poster preload: %d loaded, %d kept by Kodi, %d stored by Kodi now, %s in %.0f s'
                               %(counts[0],counts[1],counts[2],home.getProperty('meganexus.art_cache.usage') or '-',time.monotonic()-started),xbmc.LOGINFO)

    def _wait_idle(self, after_open=0):
        """Background work waits until Home was open after_open seconds and the
        cursor rested COLD_ART_IDLE seconds (no collection or video open).
        False once the window closed."""
        monitor=xbmc.Monitor()
        while not self._closed:
            opened=getattr(self,'_opened_at',0)
            if (time.monotonic()-opened>=after_open and time.monotonic()-self._hover[1]>=COLD_ART_IDLE and
                    not self._user_busy() and not browse_cache.playback_busy()):
                return True
            if monitor.waitForAbort(.5):return False
        return False

    def _user_busy(self):
        """Moving the cursor, inside a collection/Details, or a prefetch running."""
        return (self._suspended or bool(self._bucket) or time.monotonic()-self._hover[1]<1.0 or
                any(not f.done() for _,f in self._prefetch_futures) or browse_cache.foreground_busy())

    def _card_art(self, row):
        """The artwork URL a collection card shows (poster or landscape)."""
        return precache.card_art(row,getattr(self,'_card_shape','poster')=='landscape')

    def _warm_art(self, rows, limit=PREFETCH_ART, background=False):
        """Pre-download the first visible cards into the bounded image proxy.
        Background preload: False once the window closed or the memory share
        is full (stop), True to go on."""
        base=xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
        if art_cache.native():
            # 8.1.0: the native cache fetches the next cards ahead - Kodi keeps the ones it has
            for row in [r for r in rows if r.get('target')][:limit]:
                url=self._card_art(row)
                if url.startswith(('https://','http://')) and '|' not in url and url not in self._warmed_art:
                    self._warmed_art.add(url)
                    native=kodi_textures.proxy_url(base,url)
                    if not kodi_textures.kept([native]):art_cache.ahead(native)
            return True
        if art_cache.DIRECT or not base.startswith('http://127.0.0.1:'):return False   # 8.1.0: Kodi loads them
        kodi_has=getattr(self,'_kodi_has',())
        budget=getattr(self,'_art_budget',0) if background else 0
        from urllib.parse import quote
        from urllib.request import Request, urlopen
        for row in [r for r in rows if r.get('target')][:limit]:
            while not self._closed and (browse_cache.playback_busy() or (background and self._user_busy())):
                if xbmc.Monitor().waitForAbort(.5):return False
            if self._closed or (self._suspended and not background):return False
            if budget and kodi_textures.used()>=budget:return False
            url=self._card_art(row)
            if not url.startswith(('https://','http://')) or '|' in url or url in self._warmed_art:continue
            counts=getattr(self,'_art_counts',None) if background else None
            proxied=kodi_textures.proxy_url(base,url)
            # Kodi shows it from its own disk cache: never download it again
            # (7.0.23: also checked by its thumbnail file - the cursor's
            # collection prefetch downloaded posters Kodi already kept).
            if proxied in kodi_has or kodi_textures.kept([proxied]):
                if counts:counts[1]+=1
                continue
            if counts:counts[0]+=1
            self._warmed_art.add(url)
            if len(self._warmed_art)>8192:self._warmed_art.clear()
            def head(target=base+'/image?url='+quote(url,safe='')):
                try:
                    with urlopen(Request(target,method='HEAD'),timeout=4 if background else 2) as response:
                        response.read(0)
                except Exception:pass
            pool=getattr(self,'_art_pool',None) if background else None
            if pool is None:
                head();continue
            self._art_slots.acquire()   # at most COLD_ART_WORKERS in flight
            try:pool.submit(head).add_done_callback(lambda _:self._art_slots.release())
            except RuntimeError:
                self._art_slots.release();return False
        return True

    @staticmethod
    def _identity(row):
        target=row.get('target') or {}
        return json.dumps([target.get('media_type'),target.get('canonical_id'),target.get('video_id'),row.get('collection_id'),None if target.get('canonical_id') or row.get('collection_id') else row.get('path') or row.get('local') or row.get('server_play') or row.get('youtube') or row.get('music')],ensure_ascii=False)

    def _fill(self, li, row, watched_data, relabel=False, known=None):
        """One card's label, art and properties; returns its identity.
        7.0.37: ``known`` - what this card got last time (self._filled after a
        call): unchanged, Kodi is not asked again (each setArt / property call
        takes Kodi's GUI lock; Home repaints of unchanged rows took 2.3 s with
        live TV loaded on a Fire TV Cube)."""
        labels=(without_emoji(row.get('title') or 'Untitled'),without_emoji(row.get('subtitle') or ''))
        art={key: str(row.get(key) or '') for key in ('poster', 'fanart', 'clearlogo')}
        # 9.1.1: a Top 10 card keeps its poster - its number stands beside a poster also with landscape cards
        # 9.1.1: and a Browse all card its own landscape picture (home_data.browse_all_card)
        if getattr(self,'_card_shape','poster')=='landscape' and not row.get('rank') and (row.get('target') or row.get('local') or row.get('server_play') or row.get('landscape')):
            art['poster']=row.get('landscape') or row.get('fanart') or row.get('poster') or ''
        if row.get('youtube') or row.get('music'):images=art   # 9.0.6: the HUB apps' pictures stay out of MegaNexus' image memory
        else:images=art_cache.art(art);images['poster']=art_cache.card(art['poster'])   # 7.0.30: the card at card size
        props={}
        for key in ('title', 'plot', 'meta_line', 'subtitle', 'resume_label', 'airing_banner','tomorrow'):
            value=without_emoji(row.get(key) or '') if key in ('title','subtitle') else str(row.get(key) or '')
            props[key]=value.replace(' • ','[CR]') if key=='airing_banner' else value
        props['shape']=row.get('shape') or 'poster'
        props['font']=row.get('font') or ''   # 9.0.6: 'world' - the card's words in MegaNexus' own font (kodi_text.world)
        props['youtube.video']=(row.get('youtube') or {}).get('video') or ''   # ... and its play mark (meganexus.app.playing)
        music=row.get('music') or {}   # 9.0.6: the HUB apps' cards - round for an artist or a channel, the play mark on the song that plays
        props['round']='1' if row.get('round') or music.get('kind')=='artist' else ''
        props['music.id']=(music.get('id') or '') if music.get('kind')=='track' else ''
        props['animation']=art_cache.animation(row.get('animation'))
        props['hide_title']=row.get('hide_title') or ''
        props['rank']=str(row.get('rank') or '')   # 9.1.1: a Top 10 card's number (1-10)
        # ... its fill's colour: its poster's ('' : a dark neutral), or the one chosen for every number (Big numbers · colour)
        props['rank_tint']=number_colors.fill(row.get('rank_tint')) if row.get('rank') else ''
        # 8.1.3: the logo's box, from its shape (logo_size) - every logo about the same size
        props['logo_fit']=logo_size.fit(row.get('clearlogo'),collection=bool(row.get('collection_id')))
        for key in ('rating_icon','rating_value'):props[key]=str(row.get(key) or '')
        target=row.get('target') or {}
        identity=self._identity(row)
        props['meganexus.identity']=identity
        props['meganexus.placeholder']='' if (target or row.get('collection_id') or row.get('local') or row.get('server_play')) else '1'
        props['watched']='1' if row.get('watched') or simkl_watched.watched_mark(watched_data,target.get('media_type'),target.get('canonical_id'),(target.get('imdb_id'),)) else ''
        try:
            percent = min(100, max(0, int(float(row.get('percent_value') or 0))))
        except (ValueError, TypeError, OverflowError):
            percent = 0
        props['progress']=str(percent)
        props['has_progress']='1' if percent else ''
        self._filled=hash((labels,tuple(images.items()),tuple(props.items())))
        if known is not None and known==self._filled:return identity
        if relabel:li.setLabel(labels[0]);li.setLabel2(labels[1])
        li.setArt(images)
        listitems.properties(li,props)   # 7.0.30: one call, not twenty
        return identity

    def _navigating(self, index):
        """7.0.29: the cursor is on this row and a key was pressed a moment ago."""
        return time.monotonic()-getattr(self,'_last_key',0.)<1.2 and self._selection()[0]==ROW_BASE+index

    def _drop_card(self, index, pos, empty=('Nothing to continue','Titles you start show here.')):
        """9.0.6: a title taken out of Continue Watching (or of an app's library) leaves its row at once -
        "Removed" said so and the card stayed until Home was entered again. The cursor stays where it was
        (on the next one); the last one gone, ``empty`` says so."""
        shelf=self._shelves[index]
        rows=[r for n,r in enumerate(shelf.get('rows') or []) if n!=pos]
        if not rows:rows=[dict(home_data.placeholder(*empty),shape=shelf.get('shape') or 'poster')]
        shelf['rows']=rows
        self._progress_revision=xbmcgui.Window(10000).getProperty('meganexus.progress.revision')   # nothing to draw again on return
        self._set_rows(index,rows)
        try:self.getControl(ROW_BASE+index).selectItem(min(pos,len(rows)-1))
        except Exception:pass

    def _set_rows(self, index, rows, watched=None, background=False):
        self._sel_cache=None
        if 0<=index<len(self._shelves) and self._shelves[index].get('_pending'):
            self._shelves[index]['_pending']=0
            self._row_ids=getattr(self,'_row_ids',None) or {};self._row_ids.pop(index,None)   # drawn anew, the empty cards with it
        control = self.getControl(ROW_BASE + index)
        # 8.1.2: handed down by a caller that is drawing more than one row. This asks
        # five files whether they have changed, and twelve of those in one paint is
        # where the loop watchdog caught Home sitting on the Cube's eMMC.
        watched_data=self._badges_data=watched if watched is not None else simkl_watched.snapshot()
        ids=getattr(self,'_row_ids',None)
        if ids is None:ids=self._row_ids={}
        sigs=getattr(self,'_card_sigs',None)
        if sigs is None:sigs=self._card_sigs={}
        old=sigs.get(index) or [];new=sigs[index]=[]
        def fill(li,pos,row,relabel=True):
            self._fill(li,row,watched_data,relabel=relabel,known=old[pos] if pos<len(old) else None);new.append(self._filled)
        # 7.0.29: the same titles in the same order (pictures from a provider,
        # enriched Continue Watching, a server answer): the cards change in
        # place. A reset restarted the focused poster's pop (it jerked, several
        # times on entering Home) and could move the cursor under the remote.
        try:same=control.size()==len(rows)
        except Exception:same=False
        if same and ids.get(index) and [self._identity(row) for row in rows]==ids[index]:
            for pos,row in enumerate(rows):fill(control.getListItem(pos),pos,row)
            return
        try:
            position = control.getSelectedPosition()
        except Exception:
            position = 0
        try:
            selected=control.getSelectedItem()
            # 7.0.16: "Loading titles" and "Browse all" both carry the collection's
            # link; keeping a placeholder's identity moved the cursor to the end.
            old_identity='' if selected.getProperty('meganexus.placeholder') else selected.getProperty('meganexus.identity')
        except Exception:old_identity=''
        try:old_title='' if not old_identity else selected.getLabel()
        except Exception:old_title=''
        identities=[self._identity(row) for row in rows]
        try:size=control.size()
        except Exception:size=0
        # 8.1.2: writing a card that is ALREADY in a container costs Kodi's drawing thread
        # - about 10-25 ms a call on a CoreELEC box, and two calls a card (art, properties).
        # Building fresh ListItems costs nothing (0.007 ms each, measured) and addItems
        # hands the whole row over in ONE call. So rewriting in place is only worth it when
        # the cards really are mostly the same ones - a Continue Watching refresh, a
        # provider's pictures arriving - where it also keeps the cursor where it is
        # (7.0.29). Moving to another collection shares almost nothing, and there the
        # rebuild is both faster and no worse for the cursor, which starts at the top
        # anyway: a collection of 32 cards went from ~700 ms of card writing to one call.
        before=ids.get(index) or []
        shared=len(set(identities) & set(before)) if before else 0
        mostly_same=bool(before) and shared >= max(1, len(identities)) // 2
        later=getattr(self,'_grow_later',None)
        if later is None:later=self._grow_later=set()
        later.discard(index)
        # 9.0.4: a ring row's empty cards take its titles where they stand, the cursor on them or not
        blank=0<=index<len(self._shelves) and bool(self._shelves[index].pop('_ring_blank',False))
        if blank and not rows:   # nothing came: the empty cards stay, so Down still goes through it
            self._shelves[index]['_ring_blank']=True
            return
        try:waiting=size==1 and control.getListItem(0).getProperty('meganexus.placeholder')=='1'
        except Exception:waiting=False
        # 9.0.6: a row still showing its one "loading" card takes its cards at once, cursor on it or
        # not - nothing of it can move (the Music app's first row stayed empty until a key was pressed)
        if background and size and not blank and not waiting and self.getFocusId()==ROW_BASE+index:
            # 9.0.1: nothing a background load brings may move the cursor or the cards under
            # it. Adding, taking away or reordering cards binds the list again (Kodi puts
            # the cursor on the first card, the focused card pops again), and a new order
            # puts another title under the cursor. While the cursor is on this row only
            # cards that keep their place are written, in place; the rest of the change
            # waits until the cursor leaves the row (drain_updates). Continue Watching
            # grows like this a few seconds after a film, when its next episodes arrive.
            later.add(index)
            if len(rows)>=size and identities[:size]==before[:size]:
                for pos,row in enumerate(rows[:size]):fill(control.getListItem(pos),pos,row)
            else:sigs[index]=old
            return
        if size and rows and (mostly_same or blank):
            # 7.0.29: never emptied - the cards are rewritten where they are and
            # only the extra ones are added or taken away at the end. A reset
            # under the remote dropped the cursor to the first card (or ate the key).
            try:
                for pos,row in enumerate(rows[:size]):fill(control.getListItem(pos),pos,row)
                bound=len(rows)>size
                if bound:
                    extra=[]
                    for row in rows[size:]:
                        li=listitems.item(label=without_emoji(row.get('title') or 'Untitled'),label2=without_emoji(row.get('subtitle') or ''))
                        self._fill(li,row,watched_data);new.append(self._filled);extra.append(li)
                    control.addItems(extra)
                else:
                    for pos in range(size-1,len(rows)-1,-1):control.removeItem(pos)
                ids[index]=identities
                keep=self._kept_position(rows,identities,old_identity,old_title)
                # 9.0.1: addItems binds the whole list again and Kodi puts the cursor on the
                # first card - so after cards were added it is put back even when its card
                # kept its place. Continue Watching growing by one (the next episodes, a few
                # seconds after a film) took the cursor from the fifth card back to the first.
                if keep is None:keep=min(position,len(rows)-1)
                if keep!=position or bound:control.selectItem(keep)
                return
            except Exception:new[:]=[]   # a list that cannot change in place is rebuilt
        items = []
        for row in rows:
            li = listitems.item(label=without_emoji(row.get('title') or 'Untitled'), label2=without_emoji(row.get('subtitle') or ''))
            self._fill(li,row,watched_data);new.append(self._filled)
            items.append(li)
        control.reset()
        control.addItems(items)
        ids[index]=identities
        if items:
            # 8.1.2: the card the cursor was on, by identity or by title - and the FIRST
            # card when it is on neither. The old position used to be carried over and
            # clamped with min(position, len-1), which on a row that had genuinely
            # changed meant "stick to the end": leaving Settings landed the cursor on the
            # last card of Continue Watching. A row the cursor was never really in starts
            # at the top, and the place Home remembers is restored by _select afterwards.
            keep=self._kept_position(rows,identities,old_identity,old_title)
            control.selectItem(keep if keep is not None else 0)

    @staticmethod
    def _kept_position(rows,identities,old_identity,old_title):
        """The card the cursor was on: by identity, else (7.0.45) by its title - Continue
        Watching's refresh moves a series on to its next episode or joins a film's IDs,
        so the identity changes while the title stays (the cursor jumped to its neighbour)."""
        if old_identity and old_identity in identities:return identities.index(old_identity)
        if old_title:
            for pos,row in enumerate(rows):
                if without_emoji(row.get('title') or 'Untitled')==old_title:return pos
        return None

    def _touch(self):
        self._sel_cache=None   # a key or a repaint: focus and card are read again
        now = time.monotonic()
        self._sel_stale_at=now+.12
        if now - self._last_touch > 2:
            self._last_touch = now
            xbmcgui.Window(10000).setProperty('meganexus.interactive_busy', str(time.time()))

    def _remember_position(self):
        """7.0.29: where the cursor is, at every move - not only on Select. A Home
        that Kodi initialises again (on the Cube: around video starts / stops)
        came back to the last clicked card, often Continue Watching."""
        try:
            cid=self.getFocusId()
            if not ROW_BASE<=cid<ROW_BASE+len(self._shelves):return
            spot=[self._view_row(cid-ROW_BASE),self.getControl(cid).getSelectedPosition()]
        except Exception:return
        key=self._bucket or 'home'
        if self._focus_memory.get(key)!=spot:
            self._focus_memory[key]=spot
            xbmcgui.Window(10000).setProperty('meganexus.home.focus',json.dumps(self._focus_memory))

    def _top_bar(self, control_id=None, awake=False):
        """Show the row while the cursor is on it, hide it when it is not.

        ``awake`` keeps it for another BAR_LINGER seconds - a key press. The property
        lives on Home (window 10000) because that is where the skin reads it from.
        """
        # getattr: Kodi can hand us a window that never ran __init__
        if getattr(self, '_nested', False) and control_id is None:
            return
        where = control_id if control_id is not None else self.getFocusId()
        # 8.1.2: what Kodi has been told is remembered here. Asking it (getProperty) on
        # every focus change and every key is a call that waits for the drawing thread -
        # exactly while the rows are being filled, which is when it costs most.
        shown = getattr(self, '_bar_shown', False)
        if where in TOP_BAR:
            self._bar_until = time.monotonic() + BAR_LINGER
            if not shown:
                self._bar_shown = True
                xbmcgui.Window(10000).setProperty(BAR_PROPERTY, '1')
        elif not awake:
            self._bar_until = 0.0
            if shown:
                self._bar_shown = False
                xbmcgui.Window(10000).clearProperty(BAR_PROPERTY)

    def _bar_tick(self):
        """Standing on it changes nothing by itself, so it goes after a while."""
        until = getattr(self, '_bar_until', 0.0)
        if until and time.monotonic() >= until:
            self._bar_until = 0.0
            self._bar_shown = False
            xbmcgui.Window(10000).clearProperty(BAR_PROPERTY)

    def onFocus(self, control_id):
        # 7.0.45: only noted here - a fast scroll through ten rows called this ten times,
        # each asking Kodi several things while it draws (0.5-1 s apiece on a Fire TV
        # Cube): the logos and rows followed row by row for seconds. The loop applies
        # the last one (_apply_focus).
        self._touch()
        self._focus_pending=control_id
        self._top_bar(control_id)
        if control_id==CALENDAR_BUTTON:
            # 9.1.1: today's day asked while the cursor stands here - the Calendar then opens at once
            from .calendar import prepare
            prepare()

    def _apply_focus(self):
        control_id=getattr(self,'_focus_pending',None)
        if control_id is None:return
        self._focus_pending=None
        if self._ring_g is not None and ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            self._ring_move(control_id-ROW_BASE)   # 9.0.4: the rows out of sight follow the cursor
        elif self._ring_g is not None:
            self.clearProperty('meganexus.dir')     # off the rows (tabs, Back): back on one, nothing slides in
        self._remember_position()
        if ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            self.setProperty('meganexus.hero_row', str(control_id - ROW_BASE))
            self._row_scroll_focus(control_id-ROW_BASE)

    def onAction(self, action):
        self._touch()
        self._last_key=time.monotonic()
        self._top_bar(awake=True)   # 8.1.2: a press keeps the row a little longer
        if action.getId() in (1,2,3,4,5,6,104,105,159,160):self._remember_position()   # moves and page moves
        if action.getId() in (117,101,1009,11):
            cid=self.getFocusId()
            if ROW_BASE <= cid < ROW_BASE+len(self._shelves):
                rows=self._shelves[cid-ROW_BASE]['rows'];pos=self.getControl(cid).getSelectedPosition()
                if 0<=pos<len(rows) and rows[pos].get('target'):
                    from .details import context_choice,quick_choice,run_choice,open_person,plays_directly
                    self._suspended=True
                    outcome='';inplace=False
                    try:
                        if rows[pos].get('person'):
                            if self._previews:self._previews.pause()
                            outcome=self.child(open_person,rows[pos]['person'])
                        else:
                            # 6.0.35: Title options float over Home; only a choice that
                            # opens a screen hides it.
                            target=rows[pos]['target']
                            choice='details' if action.getId()==11 else context_choice(target,rows[pos])
                            # 7.0.44: Details (and Info) open in place of the rows, like a click
                            inplace=choice in ('details','info') and not self._hidden_hero() and not rows[pos].get('collection_id')
                            if self._previews and not inplace:self._previews.pause()
                            job=self._shelves[cid-ROW_BASE].get('tracking_job')
                            if choice=='remove' and quick_choice(choice,target,rows[pos]):
                                if job:   # 9.0.8: Next episodes - its own words when its last card goes
                                    from resources.lib import tracking_rows
                                    empty=tracking_rows.nothing(job)
                                    self._drop_card(cid-ROW_BASE,pos,empty=(empty['title'],empty['plot']))
                                else:self._drop_card(cid-ROW_BASE,pos)
                            elif job=='watchlist' and choice and (choice=='library' or choice.startswith('unlibrary')) \
                                    and quick_choice(choice,target,rows[pos]):
                                self._reload_tracking('watchlist')   # 9.0.8: the Watchlist row shows the change
                            elif choice and not quick_choice(choice,target,rows[pos]):
                                if inplace:
                                    self.setProperty('meganexus.inplace','1')
                                    outcome=self.in_place(run_choice,target,'details',rows[pos],inplace=True,
                                                          home_tick=self._inplace_tick,home_pause=self._inplace_pause,
                                                          home_previews=self._inplace_previews)
                                else:
                                    outcome=(self.in_place if plays_directly(target,rows[pos],choice) else self.child)(run_choice,target,choice,rows[pos])
                    finally:
                        if inplace:self.setProperty('meganexus.inplace','')
                        self._suspended=False;self._watched_badges()
                    if outcome=='playing' or isinstance(outcome,dict):
                        self._pending=outcome;self._finish()
            return
        if action.getId() in BACK:
            if self._nested:
                self._hide();return
            if self._bucket:
                if self._previews:self._previews.pause()
                self._bucket = ''
                self._returning=True   # 7.0.32: Home comes back as it was, without sliding in
                try:self._paint(home_data.initial_shelves())
                finally:self._returning=False
            # 8.1.2: and nothing here. Back used to put the cursor on the Home pill,
            # which is the one place it may never land on its own - Home is where you
            # go by pressing Home, and that is a different button for a reason.

    @staticmethod
    def _hidden_hero():
        """Home without its top (compact layout): titles open on their own page."""
        return xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)')

    def _inplace_tick(self,last_input=0.0):
        """7.0.44: the card's trailer while its title is open in place - the page calls
        this from its loop (the same thread as Home's): no trailer yet, it starts after
        the usual wait; a key on the page waits again."""
        previews=self._previews
        if not previews:return
        if last_input and not previews.attempted:previews.changed=max(previews.changed,last_input)
        suspended,self._suspended=self._suspended,False
        try:previews.tick()
        finally:self._suspended=suspended

    def _inplace_pause(self):
        if self._previews:self._previews.pause()

    def _inplace_previews(self):
        """8.1.2: Home's trailer controller, for the title page opened over Home.

        The page had only _inplace_pause - a bound method - so the Trailer button could
        not step the running clip up to full screen (trailers.take_over needs the
        controller) and fell back to stopping it and playing the whole thing again. That
        is the reload the user sees: "zaustavi prijasnji video".
        """
        return self._previews

    def _opens_in_place(self,row):
        """7.0.44: a film or series card opens in place of the rows (not a person, a
        collection, a resume that starts at once, or Home without its top)."""
        if not row.get('target') or row.get('person') or row.get('collection_id') or row.get('server_play') or row.get('local'):return False
        from .details import plays_directly
        return not plays_directly(row['target'],row) and not self._hidden_hero()

    def onClick(self, control_id):
        self._touch()
        if self._nested and (control_id in NAV or control_id in TOP_BUTTONS):
            self._forward=control_id;self._hide();return   # Home does it
        if control_id in NAV:
            if self._previews:self._previews.pause()
            self._bucket = NAV[control_id]
            # 8.1.2: the cursor is on Home already - it was just clicked - and the
            # repaint does not move it.
            self._paint(home_data.initial_shelves(self._bucket))
            return
        # 7.0.44: a card's trailer goes on while its title opens in place (below)
        if self._previews and not ROW_BASE <= control_id < ROW_BASE + len(self._shelves):self._previews.pause()
        if control_id in (105,111):
            self._suspended=True
            try: query=xbmcgui.Dialog().input('Search movies, series, actors & more',getattr(self,'_search_query','')).strip()
            finally:
                self._suspended=False
                self._watched_badges()
            if query:
                self._search_query=query
                self.setProperty('meganexus.search.query',query)
                self._bucket='search'
                with perf.timed('Search',query=query):shelves=home_data.search_shelves(query)
                self._paint(shelves)
            return
        elif control_id == 113:
            # 7.0.29: the film waiting behind (Back / Esc pressed while it started). 9.0.5: to the
            # player once Home is closed (open_home) - asked from here, with Home (and a collection)
            # still open, Kodi refused it ("Activate of window '12005' refused because there are
            # active modal dialogs") and Home came straight back over the film
            self._pending='player';self._finish();return
        elif control_id == 108:
            # 7.0.42: Home stays, the HUB button marked, our ring over it, until the
            # HUB under it has drawn itself (open_home); closing here first showed the
            # ring over a bare background.
            self._pending='hub'
            self._leaving=True
            try:self.setFocusId(108)
            except Exception:pass
            return
        elif control_id == 106:
            # 6.0.35: Library (Local / Tracking services).
            # 8.1.2: over Home, not instead of it. child() closed Home while the Library
            # was up, so coming back meant onInit and a full repaint of every shelf -
            # seconds on a box, with the cursor arriving afterwards on top of whatever
            # the person had already pressed ("na izlaz iz library opet ima neki pricek
            # ja hodam dalje on vrati"). Home is covered instead: nothing of it is drawn
            # (meganexus.behind, as under a collection screen), its controls stay as they
            # are, and the way out costs nothing at all. in_place keeps that true even
            # when a film is started in there - only then is Home shown again.
            from .library import open_library
            self._suspended=True
            outcome=None
            try:
                # 9.1.1: covered once the Library stands over Home, not before it opens - Home gone at once let the
                # window under every screen show through the Library's opening fade (the HUB's trending picture)
                outcome=self.in_place(open_library,covered=lambda:self.setProperty('meganexus.behind','1'))
            finally:
                # what the way out costs, which is the part that was felt - the time
                # spent in the Library itself says nothing
                with perf.timed('Library exit'):
                    # 9.1.1: on to the HUB from the Library's own top bar, Home stays covered until the
                    # HUB is there (open_home) - uncovered, its rows came up between the two
                    hub=outcome=='hub'
                    self.setProperty('meganexus.behind','1' if hub else '')   # (covered even when left in a moment)
                    self._suspended=False
                    if not hub:self._watched_badges()
            if outcome=='playing' or isinstance(outcome,dict):
                self._pending=outcome;self._finish()
            elif outcome=='hub':
                # 9.1.1: the Library's own HUB (its top bar) - on as Home's HUB button goes
                self._pending='hub';self._leaving=True
            return
        elif control_id == CALENDAR_BUTTON:
            # 9.1.1: the Calendar, over Home as the Library is (Home covered once it stands)
            from .calendar import open_calendar
            self._suspended=True
            outcome=None
            try:outcome=self.in_place(open_calendar,covered=lambda:self.setProperty('meganexus.behind','1'))
            finally:
                hub=outcome=='hub'
                self.setProperty('meganexus.behind','1' if hub else '')
                self._suspended=False
                if not hub:self._watched_badges()
            if outcome=='playing' or isinstance(outcome,dict):
                self._pending=outcome;self._finish()
            elif hub:
                self._pending='hub';self._leaving=True
            return
        elif control_id == 107:
            self._settings()
            return
        elif ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            index = control_id - ROW_BASE
            # 8.1.3: a row the paint left for later still shows the cards of the page
            # before it, so the card under the cursor is not the one this row holds.
            # It is drawn now and the click is let go.
            if index in getattr(self,'_row_queue',()):
                self._row_queue.remove(index)
                self._set_rows(index,self._shelves[index].get('rows') or [])
                return
            pos = self.getControl(control_id).getSelectedPosition()
            rows = self._shelves[index]['rows']
            if not 0 <= pos < len(rows):
                return
            row = dict(rows[pos])
            # 7.0.32: and where the card was on the screen, so Back finds the row as it was
            try:shown=int(xbmc.getInfoLabel('Container(%d).Position'%control_id) or 0)
            except ValueError:shown=0
            self._focus_memory[self._bucket or 'home'] = [self._view_row(index), pos, shown]
            xbmcgui.Window(10000).setProperty('meganexus.home.focus', json.dumps(self._focus_memory))
            if self._previews and not self._opens_in_place(row):self._previews.pause()
        else:
            return
        if row.get('collection_id') and not self._nested:
            return self._open_collection(row['collection_id'])
        if row.get('collection_id'):
            from resources.lib.collections_home import collection_shelves
            self._bucket = 'collection:' + row['collection_id']
            self._focus_memory.pop(self._bucket,None)
            with perf.timed('Collection data',id=row['collection_id']):
                shelves=collection_shelves(row['collection_id'])
            self._paint(shelves)
            return
        if row.get('group_id'):
            self._bucket='group:'+row['group_id']
            self._paint(home_data.initial_shelves(self._bucket));return
        if row.get('server_play'):
            # 6.0.39 beta: a Plex / Jellyfin episode or resume plays from the server.
            command=_server_play(row['server_play'])
        elif row.get('local'):
            # 6.0.37: a movie / series from the device's own storage (Kodi library).
            from .local_storage import open_item
            self._suspended=True
            if self._previews:self._previews.pause()
            try:command=self.child(open_item,row['local'])   # 'playing', a Kodi window or ''
            finally:
                self._suspended=False
        elif row.get('target'):
            from .details import open_context,open_person,plays_directly
            self._suspended=True
            # 7.0.44: a title opens in place of the rows - Home's top and its trailer stay
            inplace=self._opens_in_place(row)
            if self._previews and not inplace: self._previews.pause()
            try:
                if inplace:
                    self.setProperty('meganexus.inplace','1')
                    outcome=self.in_place(open_context,row['target'],row=row,inplace=True,
                                          home_tick=self._inplace_tick,home_pause=self._inplace_pause,
                                          home_previews=self._inplace_previews)
                else:
                    outcome=self.child(open_person,row['person']) if row.get('person') else \
                        (self.in_place if plays_directly(row['target'],row) else self.child)(open_context,row['target'],row=row)
                command=outcome if outcome=='playing' or isinstance(outcome,dict) else ''
            finally:
                if inplace:self.setProperty('meganexus.inplace','')
                self._suspended=False
                self._watched_badges()
        elif any(action in (row.get('path') or '') for action in ('action=first_run_wizard','action=setup_center')):
            self._settings();return
        elif any(action in (row.get('path') or '') for action in ('action=meganexus_collection','action=catalog_all')):
            from urllib.parse import urlsplit,parse_qs
            from .catalog import open_catalog
            self._suspended=True
            if self._previews:self._previews.pause()
            try:
                params={k:v[0] for k,v in parse_qs(urlsplit(row['path']).query).items()}
                params.setdefault('label',self._shelves[index]['title'])
                params['initial_rows']=[r for r in self._shelves[index]['rows'] if r.get('target')]
                outcome=self.child(open_catalog,params)
                command=outcome if outcome=='playing' or isinstance(outcome,dict) else ''
            finally:
                self._suspended=False
                self._watched_badges()
        else:
            command = launch_command(row)
        if command:
            self._pending = command
            self._finish()

    def _settings(self):
        from .settings import run
        previous_xml=home_xml();previous_theme=theme_folder()
        from resources.lib import art_provider
        previous_art=art_provider.signature()
        self._suspended=True
        if self._previews:self._previews.pause()
        before=self._settings_signature()
        changed=True
        try:
            with perf.timed('Settings'):command=self.over(run)   # 6.0.35: Home stays visible behind the glass settings
        finally:
            self._suspended=False
            changed=before!=self._settings_signature()
            if changed:
                # Only when something in there actually changed - see _settings_signature
                from .browse_meta import clear
                clear()
                self._forget_rows()
        if command=='meganexus:reload':   # 7.0.30: a new theme - Home opens again in it
            self._pending='reload';self._theme_changed=True;self._finish();return
        if command:self._pending=command;self._finish();return
        home=xbmcgui.Window(10000)
        if art_provider.signature()!=previous_art or home.getProperty(PREPARE_REQUEST):
            # 7.0.32: a new Artwork provider or a cleared cache - the pictures are
            # prepared now that Settings is closed, never while choices are made.
            home.clearProperty(PREPARE_REQUEST)
            self._pending='prepare';self._finish();return
        from .setup_gate import ready
        if not ready():self._pending='reload';self._finish();return
        if home_xml()!=previous_xml or theme_folder()!=previous_theme:
            self._pending='reload';self._finish();return
        self.setProperty('meganexus.home.error','')
        if not changed:
            # 8.1.2: nothing in Settings was changed, so there is nothing to show
            # differently. Settings opens over Home (over(), not child()): Home was
            # never closed, its rows are drawn and the cursor is on the Settings
            # button where it was left. Rebuilding and repainting them here cost
            # seconds on a box and moved the cursor for no reason at all.
            return
        if self._bucket.startswith('collection:'):
            from resources.lib.collections_home import collection_shelves
            shelves=collection_shelves(self._bucket.split(':',1)[1])
        elif self._bucket=='search':
            shelves=home_data.search_shelves(getattr(self,'_search_query',''))
        else:shelves=home_data.initial_shelves(self._bucket)
        self._paint(shelves)   # back from Settings around the remembered row

    def _open_collection(self, collection_id):
        """7.0.32: the collection in its own screen over Home. Home keeps its rows,
        their scrolling and its cursor: Back closes the collection screen and Home
        is there as it was - nothing is filled, scrolled or animated again (it
        was repainted before: 0.4-2 s on a box, the rows sliding and scrolling
        back). The screen is made once and reused."""
        from resources.lib.collections_home import collection_shelves
        from . import play_jobs
        bucket='collection:'+collection_id
        with perf.timed('Collection data',id=collection_id):
            shelves=collection_shelves(collection_id)
        self._focus_memory.pop(bucket,None)
        xbmcgui.Window(10000).setProperty('meganexus.home.focus',json.dumps(self._focus_memory))
        window=self._collection_window
        if window is None or window._closed:
            with perf.timed('Collection screen'):
                window=HomeWindow(home_xml(),ADDON.getAddonInfo('path'),theme_folder(),'1080i',shelves=shelves,bucket=bucket,nested=True,parent=self)
            self._collection_window=window
        else:
            window._bucket=bucket;window._shelves=shelves;window._pages=list(shelves);window._ring_g=None
            window._clear_rows()   # never a moment of the last collection
        # The rows the cursor's prefetch loaded are Home's: the collection shows
        # them as they are (it painted the cached page and then changed it).
        window._shelf_memory=self._shelf_memory;window._memory_lock=self._memory_lock
        window._forward=None
        self._suspended=True
        if self._previews:self._previews.pause()
        # A film started there hides Home as well (playback._hide_parents).
        self._meganexus_play_hidden=False
        play_jobs.PARENTS.append(self)
        monitor=xbmc.Monitor()
        try:
            window._shown=True
            # 9.0.1: shown only when it is whole - "mora biti jedan ekran, iza njega drugi
            # spreman sa fokusom". It opened empty (the page with no cards for half a
            # second), then a row at a time, then the first poster grew as the cursor
            # landed on it. Now it opens invisible over Home, which stays on the screen,
            # draws its rows and takes the cursor, and appears in one piece (reveal).
            window.setProperty('meganexus.behind','1');window._row_ready_at=None
            window.show_ready()
            reveal(window)
            self.setProperty('meganexus.behind','1')   # covered: Kodi need not draw Home
            while window._shown and not window._closed and not self._closed and not monitor.abortRequested():
                window.drain_updates()
                monitor.waitForAbort(.05)
        finally:
            try:play_jobs.PARENTS.remove(self)
            except ValueError:pass
            self.setProperty('meganexus.behind','')
            self._suspended=False
            self._touch()
        if window._closed:
            # Something to do outside MegaNexus's screens (a film, a trailer, HUB ...)
            self._collection_window=None
            if window._previews:window._previews.finish()
            if window._pending:
                self._pending=window._pending;self._finish()
            return
        if self._meganexus_play_hidden:
            self._meganexus_play_hidden=False
            self.show_ready()
        if window._forward is not None:
            forward,window._forward=window._forward,None
            if not (forward in NAV and NAV[forward]==self._bucket):   # Home itself: it is there already
                type(self).onClick(self,forward)   # the method itself, not the deferring wrapper

    def child(self, fn, *args, **kwargs):
        """A collection screen hides itself for a title, a trailer or a film -
        and Home behind it closes too: Kodi counts every MegaNexus screen as a
        dialog, and an open one kept its player from taking over (Back did not
        leave a trailer). On the way back Home opens first, not drawn
        (meganexus.behind) while it fills its rows again, then this screen."""
        parent=self._parent if self._nested else None
        if parent is None:return super().child(fn,*args,**kwargs)
        try:focus=self.getFocusId()
        except Exception:focus=None
        self._child_active=True
        try:
            xbmcgui.WindowXMLDialog.close(self)
            xbmcgui.WindowXMLDialog.close(parent)
            return fn(*args,**kwargs)
        finally:
            self._restore_focus=focus
            if not self._dialog_closed and not parent._closed and not xbmc.Monitor().abortRequested():
                parent.setProperty('meganexus.behind','1')
                parent.show()
                parent.setProperty('meganexus.behind','1')
                self.show_ready()
            self._child_active=False

    def _clear_rows(self):
        """7.0.32: a reused collection screen starts empty. Its rows kept the last
        collection's cards, and _set_rows rewrites cards in place (right within
        one collection) - the new one appeared drawn over the old."""
        self._row_ids={};self._card_sigs={};self._sel_cache=None
        said=getattr(self,'_row_props',None)
        for i in range(home_data.MAX_ROWS):
            self.setProperty('meganexus.row.%d.visible'%i,'')
            if said is not None:said['meganexus.row.%d.visible'%i]=''   # what _say knows stays what Kodi has
            try:self.getControl(ROW_BASE+i).reset()
            except Exception:pass

    def _hide(self):
        """Close the collection screen; it is kept for the next collection."""
        if self._previews:
            self._previews.finish();self._previews=None
        self._generation+=1          # its loads still running are dropped
        self._shown=False
        if self._parent is not None:self._parent.setProperty('meganexus.behind','')   # Home shows before this one goes
        xbmcgui.WindowXMLDialog.close(self)

    def _finish(self):
        if self._collection_window is not None and not self._collection_window._closed:
            window,self._collection_window=self._collection_window,None
            window._finish()
            if window._previews:
                window._previews.finish()
                window._previews.release();window._previews=None
        if self._previews:
            self._previews.close()
            # 8.1.2: and let go of it. The controller holds this window and an
            # xbmc.Player, and this window held the controller: a cycle of SWIG objects
            # that the refcount cannot break, which is what Kodi reported at every
            # script exit (SwigDirector_Player, SwigDirector_WindowXMLDialog).
            self._previews.release()
            self._previews=None
        self._closed = True
        self._generation += 1
        # 8.1.2: the row's mark goes with the window, so nothing else reads it as "shown"
        try:xbmcgui.Window(10000).clearProperty(BAR_PROPERTY)
        except Exception:pass
        if self._pool:
            for future in self._futures:future.cancel()
            self._pool.shutdown(wait=False)  # Kodi Windows still embeds Python 3.8.
        if self._prefetch_pool:
            for _,future in self._prefetch_futures:future.cancel()
            self._prefetch_pool.shutdown(wait=False)
        self.close()


PREPARE_REQUEST='meganexus.prepare.requested'   # 7.0.32: Settings asks for the preparation on leaving
ENTRY_XML='meganexus_entry.xml'   # 7.0.42: the opening screen kept over Home while it fills
ENTRY_HOLD=7.0                    # ... for at most this long (Back skips)
HUB_SETTLE=1.1          # 7.0.42: the HUB's trending picture loaded and faded in under Home
HUB_SETTLE_PLAIN=.35    # ... a HUB without it


PLAYER_WAIT = 3.0    # s for Kodi's full-screen player to come up


def to_player():
    """9.0.5: Now playing - the film playing behind MegaNexus back in Kodi's full-screen player, playing.
    Called with every MegaNexus screen closed: Kodi opens no window over an open dialog."""
    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    monitor, until = xbmc.Monitor(), time.monotonic() + PLAYER_WAIT
    while not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') and time.monotonic() < until:
        if monitor.waitForAbort(.05):
            return
    if xbmc.getCondVisibility('Player.Paused'):
        xbmc.executebuiltin('PlayerControl(Play)')


def open_home():
    from .setup_gate import ensure_ready
    if not ensure_ready():return
    from .startup import prepare,Progress
    xbmcgui.Window(10000).clearProperty(PREPARE_REQUEST)   # this preparation covers it
    # 7.0.45: one opening screen and one ring from the HUB to Home - the preparation
    # and Home's first rows fill the same ring (two screens, each from empty, before).
    entry=progress=None
    try:
        from .play_jobs import Loading, ROOT
        entry=Loading(ENTRY_XML,ROOT,theme_folder(),'1080i',label='',full=True,hub=True)
        entry.show()
        progress=Progress(entry,after=['check','home','rows'])
    except Exception:entry=None
    try:
        prepare(entry,progress)
        if progress is not None:progress.begin('home')   # Kodi builds Home: the ring goes on by the time it took before
    except Exception:
        if progress is not None:progress.stop()
        if entry is not None:entry.close()
        raise
    xbmcgui.Window(10000).setProperty('meganexus.progress.pull_requested', str(time.time()))
    monitor=xbmc.Monitor()
    bucket='';search_query='';first_entry=True
    while not monitor.abortRequested():
        extra={}
        try:
            from . import perf
            # 9.0.5: measured - between the start check and Home's screen a second went unaccounted on the Cube
            with perf.timed('Home rows built', tab=bucket or 'home'):
                if bucket.startswith('collection:'):
                    from resources.lib.collections_home import collection_shelves
                    shelves=collection_shelves(bucket.split(':',1)[1])
                elif bucket=='search':shelves=home_data.search_shelves(search_query)
                else:
                    revision=xbmcgui.Window(10000).getProperty('meganexus.progress.revision')
                    shelves=home_data.initial_shelves(bucket)
                    # 9.1.1: entering MegaNexus, the cursor first on the Home pill (only this first Home)
                    extra={'progress_revision':revision,'arrive_on_home':first_entry}
            window=HomeWindow(home_xml(),ADDON.getAddonInfo('path'),theme_folder(),'1080i',shelves=shelves,bucket=bucket,**extra)
        except Exception:
            # 8.1.3: the opening screen goes before the error does. It stayed on top with
            # its ring at 70 %, the "could not open" message under it, and neither Back
            # nor Esc got anywhere ("smrzne slika na tom loadingu").
            if progress is not None:progress.stop()
            if entry is not None:entry.close();entry=None
            raise
        window._search_query=search_query
        if not (first_entry and not bucket) and entry is not None:
            if progress is not None:progress.stop()
            entry.close();entry=None
        # 7.0.42: entering MegaNexus - the opening screen stays over Home while
        # it fills its first rows (they jumped and vanished under the cursor),
        # at most ENTRY_HOLD seconds; then the marker is on Home.
        first_entry=False
        try:
            # 8.1.2: nothing reloads the skin while this screen is up. doModal takes this
            # mark for every other window; Home drives itself and went without - and the
            # component installer reloads the skin at Kodi's start, exactly when Home is
            # on screen (that reload crashed Kodi on the profile picker).
            screen_guard.hold()
            window.show_ready()
            from .trailers import lift_curtain
            lift_curtain()   # 7.0.32: after a film, the black fades to this Home
            if entry is not None:
                until=time.monotonic()+ENTRY_HOLD
                try:
                    if progress is not None:progress.begin('rows')
                    while time.monotonic()<until and not entry.cancelled and not window._closed and not monitor.abortRequested():
                        window.drain_updates()
                        if window.first_rows_ready():break
                        if progress is not None:progress.update(window.first_rows_progress())
                        monitor.waitForAbort(.05)
                    if not window._closed and not window.first_rows_ready():
                        # 7.0.45: what the opening screen waited for when its time ran out
                        xbmc.log('[MegaNexus] Opening: rows %s drawn %s, %d of %d loads running'
                                 %(sorted(window._scheduled),sorted(getattr(window,'_drawn',())),
                                   sum(1 for f in list(window._futures) if not f.done()),len(window._futures)),xbmc.LOGINFO)
                    if progress is not None:progress.done()
                    # 8.1.2: and the cursor stays where Home put it (its first row) -
                    # the way in used to end on the Home pill, so every collection and
                    # every start flashed there before moving on.
                finally:
                    if progress is not None:progress.stop()
                    entry.close();entry=None
            while not window._closed and not window._leaving and not monitor.abortRequested():
                window.drain_updates()
                monitor.waitForAbort(.05)
            pending=window._pending;bucket=window._bucket;search_query=getattr(window,'_search_query','')
        finally:
            cover=None
            if getattr(window,'_pending',None)=='hub':
                # 7.0.42: the HUB first, under this Home, then Home closes - the session's
                # base picture never shows between them (it flashed on the way out). Home
                # and our ring stay until the HUB has drawn itself: its trending picture
                # loads in the background and fades in (0.9 s) - shown earlier, the HUB
                # came as a bare background with the picture popping in after.
                try:
                    from .play_jobs import wait_overlay
                    cover=wait_overlay('',{})
                except Exception:cover=None
                xbmc.executebuiltin('ActivateWindow(Home)')
                for _ in range(20):
                    if xbmc.getCondVisibility('Window.IsActive(Home)') or monitor.waitForAbort(.025):break
                spotlight=bool(xbmcgui.Window(10000).getProperty('meganexus.spotlight.art'))
                monitor.waitForAbort(HUB_SETTLE if spotlight else HUB_SETTLE_PLAIN)
            window._finish()
            if window._previews:
                window._previews.finish()
                window._previews.release();window._previews=None
            # 8.1.2: Home drives itself (show_ready + drain_updates) instead of doModal,
            # so the release doModal does in its finally never ran for it - and a new
            # HomeWindow is built for every tab switch. Kodi reported six of them still
            # held at script exit; this is the one place each of them ends.
            window._release()
            screen_guard.release()
            if cover is not None:cover.close()
        if pending=='hub':
            return
        if pending=='reload':
            if getattr(window,'_theme_changed',False):
                from resources.lib import theme
                theme.sync()                 # Kodi loads its skin again now, with no page open
                monitor.waitForAbort(.5)
            continue
        if pending=='prepare':
            # 9.0.0: a new Artwork choice is carried out to the end first (switch_artwork)
            from .startup import switch_artwork
            if not switch_artwork():
                prepare(requested=True)   # 8.1.5: asked for in Settings - the opening never waits for these
            continue
        if isinstance(pending,dict) and 'trailer' in pending:
            from .trailers import play_trailer
            if not play_trailer(pending['trailer']):continue
            pending='playing'
        if pending=='player':
            to_player()
            pending='playing'
        if pending=='playing':
            from .trailers import wait_for_playback
            wait_for_playback()
            continue
        if pending:
            xbmcgui.Window(10000).clearProperty('meganexus.frontend.running')
            from .system_setup import execute_command
            execute_command(pending)
        else:
            xbmc.executebuiltin('ActivateWindow(Home)')
        return
