# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""8.1.4: a trailer's sound comes up from nothing to your volume in two seconds.

Kodi has no volume of its own for one video, so its volume is used: 0 before the clip
starts (begin), raised step by step to where it was once the picture moves (ramp), and
given back at once when the clip goes earlier (restore). Kodi's volume bar stays hidden
meanwhile (skin.meganexus: meganexus.quiet). Kodi keeps its volume over a restart, so
the volume to come back to is also written down: the service gives it back if Kodi went
down in those two seconds (hub_service).
"""
import json
import os
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

SECONDS = 2.0
STEPS = 20
QUIET = 'meganexus.quiet'
QUIET_AFTER = 2.5
MARK = 'special://profile/addon_data/plugin.video.meganexus/volume_fade.json'
_state = {'volume': None, 'round': 0}
_lock = threading.Lock()


def _rpc(method, params=None):
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method,
                                                          'params': params or {}}))).get('result')
    except Exception:
        return None


def _quiet():
    stamp = str(time.time())
    xbmcgui.Window(10000).setProperty(QUIET, stamp)
    return stamp


def _quiet_later(stamp):
    def later():
        xbmc.Monitor().waitForAbort(QUIET_AFTER)
        home = xbmcgui.Window(10000)
        if home.getProperty(QUIET) == stamp:
            home.clearProperty(QUIET)
    threading.Thread(target=later, name='MegaNexusQuiet', daemon=True).start()


def _mark(volume):
    path = xbmcvfs.translatePath(MARK)
    try:
        if volume is None:
            if os.path.exists(path):
                os.remove(path)
        else:
            with open(path, 'w', encoding='utf-8') as handle:
                json.dump({'volume': int(volume)}, handle)
    except OSError:
        pass


def click_seconds():
    """9.0.0: how long the sound of OK plays in the sounds Kodi uses (Settings > Interface >
    Sounds): the sound pack's own file for "select". 0 without sounds or when unreadable."""
    if _state.get('click') is not None:
        return _state['click']
    seconds = 0.0
    try:
        import wave
        import xml.etree.ElementTree as ET
        pack = (_rpc('Settings.GetSettingValue', {'setting': 'lookandfeel.soundskin'}) or {}).get('value') or ''
        if pack.upper() == 'SKINDEFAULT':
            folder = xbmcvfs.translatePath('special://skin/sounds')
        elif pack and pack.upper() != 'OFF':
            import xbmcaddon
            folder = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon(pack).getAddonInfo('path')), 'resources')
        else:
            folder = ''
        if folder:
            for action in ET.parse(os.path.join(folder, 'sounds.xml')).getroot().iter('action'):
                if (action.findtext('name') or '').strip() == 'select':
                    with wave.open(os.path.join(folder, (action.findtext('file') or '').strip())) as sound:
                        seconds = sound.getnframes() / float(sound.getframerate())
                    break
    except Exception:
        seconds = 0.0
    _state['click'] = seconds
    return seconds


def begin(muted_ok=False, after_click=False):
    """Before a trailer starts: the volume to 0 (not when Kodi is muted - nothing to fade).
    ``muted_ok``: muted by us a moment ago (a silent preview that becomes the trailer).
    ``after_click`` (9.0.0): started by OK - its click is heard to the end first; the
    trailer starts at once now, and the volume going to 0 cut the click off."""
    if after_click:
        xbmc.Monitor().waitForAbort(click_seconds())
    with _lock:
        _state['round'] += 1
        if _state['volume'] is None:
            now = _rpc('Application.GetProperties', {'properties': ['volume', 'muted']}) or {}
            if (now.get('muted') and not muted_ok) or not now.get('volume'):
                return False
            _state['volume'] = int(now['volume'])
            _mark(_state['volume'])
        _quiet()
        _rpc('Application.SetVolume', {'volume': 0})
        return True


def ramp():
    """The picture moves: up to the volume it was, in SECONDS."""
    with _lock:
        target = _state['volume']
        if target is None:
            return
        round_ = _state['round']

    def work():
        monitor = xbmc.Monitor()
        stamp = None
        for step in range(1, STEPS + 1):
            if monitor.waitForAbort(SECONDS / STEPS):
                break
            with _lock:
                if round_ != _state['round'] or _state['volume'] is None:
                    return                      # another trailer, or given back already
                stamp = _quiet()
                _rpc('Application.SetVolume', {'volume': int(round(target * step / float(STEPS)))})
        with _lock:
            if round_ == _state['round']:
                _state['volume'] = None
                _mark(None)
        if stamp:
            _quiet_later(stamp)
    threading.Thread(target=work, name='MegaNexusVolumeFade', daemon=True).start()


def restore():
    """The trailer went before its sound was up: the volume back at once."""
    with _lock:
        _state['round'] += 1
        target = _state['volume']
        _state['volume'] = None
        if target is None:
            return
        stamp = _quiet()
        _rpc('Application.SetVolume', {'volume': int(target)})
        _mark(None)
    _quiet_later(stamp)
