# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Kodi's player opened from our small video (IPTV, Sport) - 7.0.48."""
import time
import xbmc

OSD_IDLE = 5                # seconds without a key before the buttons shown on entry go


def switched(before):
    """7.0.48: the channel / stream chosen in Kodi's player plays there (another file than
    ``before``, its picture moving, full screen): the switch is over and Back is the
    user's again - kept for the whole grace, Back brought the player straight back."""
    return (xbmc.getCondVisibility('Window.IsActive(fullscreenvideo) + Player.HasVideo + Player.Playing + !Player.Caching')
            and xbmc.getInfoLabel('Player.FilenameAndPath') != before)


def player_buttons(state):
    """From our small video into Kodi's player its buttons show at once, and go
    when nothing is pressed for OSD_IDLE seconds (only this first time). Call it in the loop
    that waits on the player: None (not opened yet) -> the time it was opened -> 'done'."""
    if state=='done':return state
    if state is None:
        if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            xbmc.executebuiltin('ActivateWindow(videoosd)')
            return time.monotonic()
        return None
    if not xbmc.getCondVisibility('Window.IsVisible(videoosd)'):
        return state if time.monotonic()-state<1.5 else 'done'   # it takes a moment to open; then closed by the user
    if xbmc.getCondVisibility('System.IdleTime(%d)'%OSD_IDLE):
        xbmc.executebuiltin('Dialog.Close(videoosd)')
        return 'done'
    return state
