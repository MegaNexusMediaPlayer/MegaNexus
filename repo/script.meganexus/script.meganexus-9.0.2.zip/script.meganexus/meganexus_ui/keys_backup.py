# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""HUB Settings (7.0): API keys, the Stremio account and backup /
restore of every MegaNexus choice to move it to another device."""
import xbmcgui
import xbmcvfs
from resources.lib import api_keys, settings_snapshot, settings_backup, stremio_account
from . import settings_page as page


# 8.1.5: every key in one place, in groups - the other pages send you here to set one
SECTIONS = (('Metadata & artwork', ('tmdb', 'mdblist', 'fanarttv')),
            ('Skip, next episode & AI subtitles', ('introdb', 'gemini', 'gemini2')),
            ('Debrid', ('torbox', 'realdebrid', 'alldebrid', 'premiumize', 'offcloud', 'prowlarr')),
            ('Usenet', ('easynews', 'usenet', 'newznab')))
FREE = 'SkipDB and TVmaze stand in for TheIntroDB and the next episode - no key needed'


def keys():
    """Every API key with where to get it, in groups; Select adds / replaces / removes."""
    def build():
        status = {k['id']: k for k in api_keys.status()}
        rows = []
        for title, ids in SECTIONS + (('Other keys', tuple(k for k in status if not any(k in s for _, s in SECTIONS))),):
            shown = [status[k] for k in ids if k in status]
            if not shown:
                continue
            rows.append(('head:' + title, dict(page.item(title.upper()), kind='info')))
            for k in shown:
                part = api_keys.shown(k['id']) if k['set'] else ''   # 8.1.5: which key it is, in part
                rows.append((k['id'], page.item(k['name'] + ' \u00b7 ' + k['purpose'],
                                                ('Set \u00b7 ' + part if part else 'Set') if k['set'] else 'Not set')))
            if title.startswith('Skip'):
                rows.append(('head:free', dict(page.item(FREE), kind='info')))
        return rows

    def act(key):
        if key.startswith('head:'):
            return None
        from . import settings as hub
        if key == 'usenet':              # 7.0.43: the guided set-up (port and SSL found by themselves)
            hub._usenet_server()
        elif key == 'newznab':           # 7.0.45: add / remove / test one indexer at a time
            hub._newznab_indexers()
        elif key == 'prowlarr':          # 7.0.45: address, key, checked with the server
            hub._prowlarr_server()
        else:
            from resources.lib import debrid
            if key in debrid.SERVICES:   # a service's key: its streams on, replaced or removed
                hub._service_key(key)
            else:
                k = next((row for row in api_keys.status() if row['id'] == key), None)
                if k is None:
                    return None
                dialog = xbmcgui.Dialog()
                choice = dialog.select(k['name'], ['Show the key', 'Replace the key', 'Remove the key']) if k['set'] else 1
                if choice < 0:
                    return None
                if choice == 0:              # 8.1.5: the whole key, on this screen only
                    dialog.ok(k['name'], api_keys.shown(k['id'], whole=True) or 'Not set')
                    return None
                if choice == 2:
                    api_keys.save(k['id'], '')
                else:
                    value = dialog.input('%s API key (get it at %s)' % (k['name'], k['url']),
                                         option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
                    if value:
                        api_keys.save(k['id'], value)
        settings_snapshot.invalidate()
        return None
    return page.keyed('API keys', build, act)


def stremio():
    def rows():
        return [page.item('Stremio account', stremio_account.status()),
                page.item('Import add-ons and Continue Watching now'),
                page.item('Keep Continue Watching in sync', enabled=stremio_account.keep_in_sync()),
                page.item('Back')]

    def choose(pick):
        dialog = xbmcgui.Dialog()
        if pick == 0:
            if stremio_account.linked():
                if dialog.yesno('Stremio', 'Sign out of Stremio on this device?'):
                    stremio_account.sign_out()
                return None
            email = dialog.input('Stremio email').strip()
            if not email:
                return None
            password = dialog.input('Stremio password', option=xbmcgui.ALPHANUM_HIDE_INPUT)
            stremio_account.sign_in(email, password)
            _import(dialog)
        elif pick == 1:
            if not stremio_account.linked():
                raise ValueError('Sign in to Stremio first.')
            _import(dialog)
        elif pick == 2:
            if not stremio_account.linked():
                raise ValueError('Sign in to Stremio first.')
            stremio_account.set_keep_in_sync(not stremio_account.keep_in_sync())
        elif pick == 3:
            return page.DONE
        return None
    return page.show('Stremio', rows, choose)


def _import(dialog):
    from .play_jobs import job
    report = job(stremio_account.import_now, label='Importing from Stremio')
    if report is not None:
        dialog.ok('Stremio', '%d add-on(s) and %d Continue Watching title(s) imported.%s' % (
            report.get('providers', 0), report.get('progress', 0) or 0,
            ('[CR]' + ' '.join(report['errors'])) if report.get('errors') else ''))
    settings_snapshot.invalidate()


def backup():
    """Save a backup file to a folder the user picks (USB, network, Downloads)."""
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(3, 'Where should the backup go?', 'files')
    if not folder:
        return
    # 8.1.5: complete, or without what signs in anywhere (to hand on or keep safely)
    kind = dialog.select('What goes in the backup?', ['Everything - with sign-ins, passwords and API keys',
                                                     'Everything except sign-ins, passwords, user names and API keys'])
    if kind < 0:
        return
    private = kind == 0
    from .play_jobs import job
    text = job(lambda: settings_backup.export_text(private=private), label='Writing the backup')
    if text is None:
        return
    target = folder.rstrip('/\\') + '/' + settings_backup.filename(private)
    handle = xbmcvfs.File(target, 'w')
    try:
        if not handle.write(text.encode('utf-8')):
            raise ValueError('The backup could not be written there. Choose another folder.')
    finally:
        handle.close()
    note = ('It holds your sign-ins, passwords and API keys: keep it private.' if private else
            'No sign-ins, passwords, user names or API keys are in it; add-ons whose link holds your own set-up '
            'stayed out. A restore keeps those of the device it goes to.')
    dialog.ok('Backup', 'Saved as %s.[CR][CR]%s On another device: Settings > Backup & updates > Restore '
              '(or Set up on phone > Backup).' % (target, note))


def restore():
    dialog = xbmcgui.Dialog()
    path = dialog.browse(1, 'Choose the MegaNexus backup', 'files', '.json')
    if not path:
        return None
    if not dialog.yesno('Restore', 'Replace the settings, accounts, profiles, add-ons, collections, IPTV lists and pictures '
                        'on this device with the backup?'):
        return None
    handle = xbmcvfs.File(path)
    try:
        text = handle.read()
    finally:
        handle.close()
    from .play_jobs import job
    report = job(lambda: settings_backup.import_text(text), label='Restoring the backup')
    if report is None:
        return None
    dialog.ok('Restore', 'Restored %d settings, %d files, %d libraries, %d profile and picture files and %d look choices. '
              'MegaNexus reloads now.' % (report['settings'], report['files'], report['databases'],
                                          report.get('folders', 0), report.get('skin', 0)))
    return 'reload'
