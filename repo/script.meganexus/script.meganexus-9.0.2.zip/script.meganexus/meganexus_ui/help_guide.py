# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""HUB Settings > Help & support > User guide (7.0.29).

What MegaNexus is, how to use it, and what every setting does - in the same
order as HUB Settings. Each topic opens as text (Kodi's text viewer); the topics themselves are in
plugin.video.meganexus resources/lib/help_topics.py (the phone page shows them too).
"""
import xbmcgui

from resources.lib.help_topics import TOPICS

from . import settings_page as page


def guide():
    """The user guide: one row per topic, each opens as text."""
    def build():
        return [(key, page.item(title)) for key, title, _ in TOPICS]

    def act(key):
        title, text = next((t, x) for k, t, x in TOPICS if k == key)
        xbmcgui.Dialog().textviewer('MegaNexus · ' + title, text)
        return None
    return page.keyed('User guide', build, act)
