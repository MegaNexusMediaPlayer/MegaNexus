# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""7.0.45: the Power menu's dual-boot entries on CoreELEC (Amlogic) boxes."""
import xbmc

PARAM = '/run/systemd/reboot-param'


def reboot_recovery(path=PARAM):
    """Restart into the box's recovery partition (TWRP on dual-boot boxes). systemd hands
    the saved word to the kernel on the next reboot, so Kodi still closes cleanly."""
    try:
        with open(path, 'w') as handle: handle.write('recovery')
    except OSError:
        xbmc.log('[MegaNexus] Reboot to recovery is not available on this system.', xbmc.LOGWARNING)
        return False
    xbmc.executebuiltin('Reset()')
    return True
