# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Posters Kodi already keeps, and the image memory the preload may fill (7.0.7).

Kodi stores every poster it has shown in its own texture cache on disk
(userdata/Thumbnails + Textures DB) and never asks the image proxy for it
again, also after a restart. Preloading those into the proxy's RAM only cost
time, data and memory (the poster screen after each Kodi start). The preload
now skips them and fills the proxy with the posters Kodi does not have yet, up
to SHARE of the chosen image memory (RAM 128 / 256 / 512 MiB).
"""
import json
import os
from urllib.parse import quote

import xbmc
import xbmcgui

from resources.lib import art_cache

SHARE = .8


def proxy_url(base, url):
    """The link Kodi gets for a picture: 8.1.0 the native one (mnxart, vfs.meganexus) when Kodi
    has it, else the image proxy's (its own address with art_cache.DIRECT)."""
    if art_cache.native():
        return art_cache.native_url(art_cache.raster(str(url or '')))
    if art_cache.DIRECT:
        return art_cache.raster(str(url or ''))
    return base + '/image?url=' + quote(url, safe='')


FULL = 'full:'   # 7.0.32: a picture Home shows at full size (a background, a title logo)


def full(url):
    return FULL + url


def link(url):
    """The proxy link itself, without the full-size mark."""
    url = str(url or '')
    return url[len(FULL):] if url.startswith(FULL) else url


def texture(url):
    """The link Kodi gets for a card's picture (7.0.30: at card size), so the
    preload stores exactly what the cards later ask for. Backgrounds and title
    logos (marked full:) and other pictures (the ratings logos) are shown by
    their own link."""
    url = str(url or '')
    if url.startswith(FULL):
        return url[len(FULL):]
    if not url.startswith(('http://127.0.0.1:', 'mnxart://') if not art_cache.DIRECT else ('http://', 'https://')):
        return url
    return art_cache.card(url)


def _plain(url):
    """8.1.2: art_cache owns this - the switch (art_switch) deletes by the same reading."""
    return art_cache.plain(url)


def _textures(marker='127.0.0.1'):
    """(texture id, url) of every picture Kodi keeps from 127.0.0.1.

    7.0.32: Kodi unwraps an image:// value in a JSON-RPC filter, so the
    'startswith image://<proxy>' filter of 7.0.30 found only the full-size
    copies, never the card-size ones the cards ask for: Kodi seemed to lack
    most posters and the opening screen prepared them on every start."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.GetTextures',
               'params': {'properties': ['url'], 'filter': {'field': 'url', 'operator': 'contains', 'value': marker}}}
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        textures = (reply.get('result') or {}).get('textures') or []
    except Exception:
        return []
    return [(item.get('textureid'), str(item['url'])) for item in textures if isinstance(item, dict) and item.get('url')]


def _card(url):
    return '/transform?' in url or '%2ftransform%3f' in url.lower()


def cached(base):
    """Proxy URLs Kodi has in its texture cache; empty when unknown (preload all). 8.1.0: with
    direct links Kodi's list can not tell our pictures - kept() reads its files instead; the
    native links (mnxart) it can."""
    if art_cache.native():
        return _cached(art_cache.NATIVE_PREFIX, 'mnxart')
    if art_cache.DIRECT or not str(base or '').startswith('http://127.0.0.1:'):
        return set()
    return _cached(base + '/', '127.0.0.1')


def _cached(prefix, marker):
    # 7.0.30: cards ask for card-size pictures - only those count.
    card = art_cache.card_size()
    found = set()
    for _, url in _textures(marker):
        plain = _plain(url)
        if not plain.startswith(prefix):
            continue
        if _card(url) == card:
            found.add(plain)
        if not _card(url):
            found.add(FULL + plain)   # a background / title logo at full size
    return found


def count(base):
    """How many pictures Kodi keeps from the image proxy (Settings > Cache usage)."""
    if art_cache.native():
        return sum(1 for _, url in _textures('mnxart') if _plain(url).startswith(art_cache.NATIVE_PREFIX))
    if art_cache.DIRECT or not str(base or '').startswith('http://127.0.0.1:'):
        return 0
    return sum(1 for _, url in _textures() if _plain(url).startswith(base + '/'))


def _ours(url):
    """8.1.2: art_cache.ours - the same test the picture-path switch deletes by."""
    return bool(art_cache.ours(url))


def ours():
    """Texture ids of every MegaNexus picture Kodi keeps (7.0.32): image-proxy
    links on any port (the proxy may get a new one after a restart), at card
    size or not, animations included."""
    found = _textures() + (_textures('mnxart') if art_cache.native() else [])
    return [texture_id for texture_id, url in found if texture_id is not None and _ours(url)]


def remove(ids, progress=None):
    """Kodi deletes each copy from its Textures database and Thumbnails folder.
    ``progress(done, total)`` returning True stops. Returns how many went."""
    removed = 0
    for index, texture_id in enumerate(ids):
        if progress and progress(index, len(ids)):
            break
        request = {'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.RemoveTexture', 'params': {'textureid': texture_id}}
        try:
            reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            if 'error' not in reply:
                removed += 1
        except Exception:
            pass
    return removed


CLEANED = 'meganexus_proxy_pictures_cleaned'   # 8.1.0: the proxy-era copies are gone ('true')
CLEAN_BATCH = 40


def clean_proxy_era(stopped, wait):
    """8.1.0: Kodi's copies of pictures from the image proxy (127.0.0.1 links) are not used any
    more - Kodi now keeps them under their own addresses. They go a few at a time, only while the
    screensaver runs (``stopped()`` ends it); True once none is left.

    Only in direct or native mode. While the proxy is in use those links ARE the live cache and
    removing them would throw away working posters - and 8.1.0 found that removing thousands
    through Kodi while it draws closes Kodi (saver.CLEAN_OLD is off for that reason). Pictures
    left behind by a port that changed are dealt with by not letting the port change:
    art_cache keeps the last one and falls back to one known port, never a random one.
    """
    import xbmcaddon
    from resources.lib import art_switch
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    if not (art_cache.DIRECT or art_cache.native()) or addon.getSetting(CLEANED) == 'true' or stopped():
        return False
    if art_switch.pending():
        # 8.1.2: a switch of the picture path owns these rows until it is finished (it
        # removes them in one go). Two things deleting the same ids is only wasted work.
        return False
    ids = [i for i, url in _textures() if i is not None and _plain(url).startswith('http://127.0.0.1:')]
    removed = 0
    while ids and not stopped():
        batch, ids = ids[:CLEAN_BATCH], ids[CLEAN_BATCH:]
        removed += remove(batch)
        if wait(0.5):
            return False
    if not ids and not stopped():
        addon.setSetting(CLEANED, 'true')
        xbmc.log('[MegaNexus] Pictures of the old image proxy removed from Kodi\'s cache: %d' % removed, xbmc.LOGINFO)
        return True
    return False


def kept(urls):
    """Those of these (proxy) URLs Kodi keeps in its texture cache.

    7.0.17: read from Kodi's thumbnail files, not its Textures database - polling
    the database while Kodi writes to it for every new poster blocked Kodi's
    interface on CoreELEC (clicks did nothing for 20 s). Kodi names the file
    after the CRC-32 of the lower-case URL: Thumbnails/<h[0]>/<h>.jpg|png."""
    root = _thumbnails()
    if not root:
        return set()
    found = set()
    for url in urls:
        digest = kodi_crc(texture(url))
        folder = os.path.join(root, digest[0])
        if os.path.exists(os.path.join(folder, digest + '.jpg')) or os.path.exists(os.path.join(folder, digest + '.png')):
            found.add(url)
    return found


_THUMBS = []


def _thumbnails():
    if not _THUMBS:
        try:
            import xbmcvfs
            _THUMBS.append(xbmcvfs.translatePath('special://thumbnails/'))
        except Exception:
            return ''
    return _THUMBS[0]


def _crc_table():
    table = []
    for i in range(256):
        c = i << 24
        for _ in range(8):
            c = ((c << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if c & 0x80000000 else (c << 1) & 0xFFFFFFFF
        table.append(c)
    return table


_CRC = _crc_table()


_CRCS = {}


def kodi_crc(text):
    """Kodi's Crc32::ComputeFromLowerCase (MSB-first CRC-32, no final xor), hex. 8.1.0: kept for
    the session - the start check asks for the same thousands of links each time."""
    text = str(text)
    known = _CRCS.get(text)
    if known is not None:
        return known
    if len(_CRCS) > 50000:
        _CRCS.clear()
    _CRCS[text] = known = _crc(text)
    return known


def _crc(text):
    crc = 0xFFFFFFFF
    for byte in str(text).lower().encode('utf-8'):
        crc = ((crc << 8) & 0xFFFFFFFF) ^ _CRC[((crc >> 24) ^ byte) & 0xFF]
    return '%08x' % crc


def budget():
    """Bytes the preload may fill: SHARE of the chosen image memory."""
    try:
        import xbmcaddon
        from resources.lib import art_cache, ram_profile
        mode = ram_profile.chosen(xbmcaddon.Addon('plugin.video.meganexus'))
        return int(art_cache.LIMITS.get(mode, 0) * SHARE)
    except Exception:
        return 0


def used():
    """Bytes in the image proxy now (its 'x.x MB · n images' Home property)."""
    text = xbmcgui.Window(10000).getProperty('meganexus.art_cache.usage') or ''
    try:
        return int(float(text.split('MB')[0].strip()) * 1024 * 1024)
    except ValueError:
        return 0
