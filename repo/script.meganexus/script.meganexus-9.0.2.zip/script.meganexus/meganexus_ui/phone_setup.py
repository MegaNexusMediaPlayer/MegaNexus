# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""TV side of "Set up on phone": QR window that owns the local setup service.

The service (resources.lib.phone_setup) starts when this window opens and is
stopped when it closes: Save on the phone, Back/Cancel on the TV, or 15 idle
minutes. Nothing keeps listening afterwards.
"""
import os
import time
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import settings_snapshot
from resources.lib.theme import folder as theme_folder

POLL = .25
ACTIVE_HOLD = 5 * 60   # seconds after the phone's last request the screensaver stays away
SETUP_TITLE = 'Set up on your phone'
SETUP_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
               '3. Set up accounts, add-ons and collections, then tap [B]Save & start MegaNexus[/B].[CR][CR]'
               'The setup service runs only while this screen is open.')
TYPE_TITLE = 'Write with phone'
TYPE_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
              '3. Type the text and tap [B]Send to TV[/B] - it goes into the keyboard and OK is pressed.')
REPORT_TITLE = 'Report a problem'
REPORT_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
                '3. Describe what went wrong and tap [B]Send report[/B].[CR][CR]It reaches the MegaNexus developer as a '
                'GitHub issue with the Kodi log - personal data removed.')
PROFILE_TITLE = 'Profile on your phone'
PROFILE_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
                 '3. Choose a picture, change the name or the PIN and tap [B]Save[/B].')
RATE_TITLE = 'Rate'
RATE_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
              '3. Choose your rating, write a review if you like, choose Trakt and / or TMDB and tap [B]Send[/B].')
TMDB_TITLE = 'TMDB account'
TMDB_STEPS = ('1. Scan the code with the phone camera.[CR]2. Sign in to TMDB and tap [B]Approve[/B].[CR]'
              '3. This screen closes by itself - your ratings can then go to TMDB.')
HINT_AFTER = 30   # seconds without the phone -> say what usually blocks it


class PhoneWindow(xbmcgui.WindowXMLDialog):
    # Callbacks only set flags; the owning loop in run() does the work.
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.qr = kwargs.get('qr') or ''
        self.url = kwargs.get('url') or ''
        self.title = kwargs.get('title') or SETUP_TITLE
        self.steps = kwargs.get('steps') or SETUP_STEPS
        self.cancelled = False

    def onInit(self):
        self.setProperty('meganexus.phone.qr', self.qr)
        self.setProperty('meganexus.phone.url', self.url)
        self.setProperty('meganexus.phone.title', self.title)
        self.setProperty('meganexus.phone.steps', self.steps)
        self.setProperty('meganexus.phone.status', 'Waiting for the phone…')
        from resources.lib.open_link import desktop
        self.setProperty('meganexus.phone.urlhint', 'Or select this address to open it on this computer:' if desktop()
                         else 'Or open in the phone browser:')
        self.focus(100)

    def onClick(self, cid):
        if cid == 100:
            self.cancelled = True
            self.close()
        elif cid == 101:
            # 7.0.52: on a computer (recording the setup, no phone at hand) the page opens here
            from resources.lib.open_link import open_here
            opened, copied = open_here(self.url)
            if opened or copied:
                self.setProperty('meganexus.phone.status', 'Opened in your browser%s.' % (' · the address is copied' if copied else '')
                                 if opened else 'The address is copied - paste it into your browser.')
            else:
                self.setProperty('meganexus.phone.status', 'Type this address into the phone browser.')

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61448, 61467):
            self.cancelled = True
            self.close()


def run(report=False, typing=None, rating=None, profile=None):
    """Returns True when the phone saved the setup (or sent the report). With
    ``typing`` (the keyboard's heading / text / hidden): the phone's text, or None.
    With ``rating`` (rate_title.target): what was sent to Trakt, or None."""
    from resources.lib.phone_setup import SetupService, REPORT_PAGE, TYPE_PAGE, RATE_PAGE, PROFILE_PAGE, IDLE_TIMEOUT
    from resources.lib.plex_link_window import qr_png
    from resources.lib.phone_setup import lan_ip
    host = lan_ip()
    if host.startswith('127.'):
        xbmcgui.Dialog().ok('Set up on phone', 'This device is not connected to a network. Connect it to the same Wi-Fi '
                            'as your phone and try again.')
        return False
    try:
        if profile is not None:
            service = SetupService(host=host, page=PROFILE_PAGE, only={'/api/profile'})
            service.profile = profile
            service.start()
        elif rating is not None:
            service = SetupService(host=host, page=RATE_PAGE, only={'/api/rate'})
            service.rating = dict(rating)
            service.start()
        elif typing is not None:
            service = SetupService(host=host, page=TYPE_PAGE, only={'/api/type'})
            service.typing = dict(typing)
            service.start()
        else:
            service = (SetupService(host=host, page=REPORT_PAGE, only={'/api/report'}) if report
                       else SetupService(host=host)).start()
        SetupService.last_report = None
    except OSError:
        xbmcgui.Dialog().ok('Set up on phone', 'The setup service could not start on this device. '
                            'Check the network connection and try again.')
        return False
    qr = ''
    window = None
    saved = False
    try:
        qr = qr_png(service.url, box_size=10, border=2) or ''
        window = PhoneWindow('meganexus_phone_setup.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),
                             theme_folder(),'1080i', qr=qr, url=service.url,
                             title=PROFILE_TITLE if profile is not None else RATE_TITLE if rating is not None else TYPE_TITLE if typing is not None else REPORT_TITLE if report else SETUP_TITLE,
                             steps=PROFILE_STEPS if profile is not None else RATE_STEPS if rating is not None else TYPE_STEPS if typing is not None else REPORT_STEPS if report else SETUP_STEPS)
        window.show()
        monitor = xbmc.Monitor()
        connected = False
        held = False
        waited = 0.0
        while not window.cancelled and not monitor.abortRequested():
            waited += POLL
            # 7.0.29: no screensaver while the phone is in use - it broke the phone's
            # connection. Only then: with no phone, or one left unused for ACTIVE_HOLD,
            # the screensaver comes as usual (the TV never stayed on the QR code for ever).
            in_use = service.connected and time.monotonic() - service.last_seen < ACTIVE_HOLD
            if in_use != held:
                held = in_use
                xbmc.executebuiltin('InhibitScreensaver(%s)' % ('true' if held else 'false'))
            if not connected and abs(waited - HINT_AFTER) < POLL / 2:
                window.setProperty('meganexus.phone.status', 'No phone yet? Use the same Wi-Fi. A firewall here must allow TCP port %d.' % service.port)
            if service.saved:
                saved = True
                break
            if service.connected and not connected:
                connected = True
                window.setProperty('meganexus.phone.status', 'Phone connected · waiting for Save' if profile is not None
                                   else 'Phone connected · waiting for your rating' if rating is not None
                                   else 'Phone connected · waiting for the text' if typing is not None
                                   else 'Phone connected · waiting for the report' if report
                                   else 'Phone connected · waiting for Save')
            if service.idle():
                xbmc.log('[MegaNexus] Phone setup closed: no request from the phone for %d minutes' % (IDLE_TIMEOUT // 60), xbmc.LOGINFO)
                break
            if monitor.waitForAbort(POLL):
                break
    finally:
        xbmc.executebuiltin('InhibitScreensaver(false)')
        if window:
            window.close()
        service.stop()
        if qr:
            try:
                os.remove(qr)  # the QR carries this session's key
            except OSError:
                pass
    if profile is not None:
        return saved
    if rating is not None:
        return service.rated if saved else None
    if typing is not None:
        return service.typed if saved else None
    if saved and report:
        sent = SetupService.last_report or {}
        xbmcgui.Dialog().ok('Report a problem', 'Thank you! Report #%s was sent.[CR]%s' % (sent.get('number') or '', sent.get('url') or ''))
        return True
    if saved:
        settings_snapshot.invalidate()
        try:
            from resources.lib import theme
            theme.sync_and_settle()   # 7.0.45: the theme chosen on the phone - now the QR screen is closed
        except Exception:
            pass
        try:
            from .browse_meta import clear
            clear()  # card shape, ratings or catalogs may have changed
        except Exception:
            pass
        xbmcgui.Dialog().notification('MegaNexus', 'Setup saved from the phone', xbmcgui.NOTIFICATION_INFO, 3000)
    return saved


def tmdb_sign_in():
    """7.0.45: your TMDB account for ratings - approved once on the phone (TMDB's own page)."""
    from resources.lib import tmdb_account
    from resources.lib.plex_link_window import qr_png
    try:
        token, url = tmdb_account.start()
    except Exception as exc:
        xbmcgui.Dialog().ok(TMDB_TITLE, str(exc) if isinstance(exc, ValueError) else 'TMDB could not be reached. Try again.')
        return False
    qr = qr_png(url, box_size=10, border=2) or ''
    window = PhoneWindow('meganexus_phone_setup.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),
                         theme_folder(), '1080i', qr=qr, url=url, title=TMDB_TITLE, steps=TMDB_STEPS)
    window.show()
    done = False
    try:
        window.setProperty('meganexus.phone.status', 'Waiting for your approval on TMDB…')
        monitor = xbmc.Monitor()
        until = time.monotonic() + 15 * 60
        while not window.cancelled and time.monotonic() < until:
            if monitor.waitForAbort(3):
                break
            try:
                done = tmdb_account.finish(token)
            except Exception as exc:
                xbmc.log('[MegaNexus] TMDB sign-in: %s' % type(exc).__name__, xbmc.LOGINFO)
            if done:
                break
    finally:
        window.close()
        if qr:
            try:
                os.remove(qr)
            except OSError:
                pass
    if done:
        name = tmdb_account.session().get('username') or ''
        xbmcgui.Dialog().notification(TMDB_TITLE, 'Signed in%s' % (' as %s' % name if name else ''), time=4000)
    return done


def write_with_phone():
    """7.0.29: the keyboard's "Write with phone" - the phone's text into the keyboard, then OK."""
    import json
    if not xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)'):
        return
    hidden = bool(xbmc.getCondVisibility('System.HasHiddenInput'))
    # the phone's field starts empty (what the keyboard holds is not sent there)
    typing = {'heading': xbmc.getInfoLabel('Control.GetLabel(311)'), 'hidden': hidden}
    text = run(typing=typing)
    if text is None or not xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)'):
        return
    xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Input.SendText',
                                    'params': {'text': text, 'done': True}}))
