# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""8.1.3: Home's release line always fits.

Badges, the date, then "Series | 2012 | S15 · E2 | 2% watched | 41 min left", then
"Ends 14:05" - with a series status and a weekday badge that came to about 1,300 px in a
row of 980, and Kodi simply cut it off. The line is measured here (font12: Kodi's own
font at 25, its widths below) against what the badges in front of it take, and what does
not fit goes, least needed first: the year, "Series" / "Movie", the time left, then other
words from the end. The episode, how much was seen and when it ends stay longest.

The badge widths are read from the skin itself, so a changed picture changes the sum.
"""
import os
import re

# font12 (special://xbmc/media/Fonts/arial.ttf at 25), characters 32-126, in pixels
_WIDTHS = (8, 10, 12, 21, 16, 24, 20, 7, 10, 10, 13, 21, 8, 9, 8, 9, 16, 16, 16, 16, 16, 16, 16, 16,
           16, 16, 9, 9, 21, 21, 21, 13, 25, 17, 17, 18, 19, 16, 14, 19, 19, 7, 11, 16, 14, 22, 19, 20,
           15, 20, 17, 16, 17, 18, 17, 25, 17, 17, 17, 10, 9, 10, 21, 15, 13, 15, 16, 14, 16, 15, 9, 16,
           16, 7, 9, 15, 7, 24, 16, 15, 16, 16, 10, 13, 10, 16, 15, 21, 15, 15, 13, 16, 9, 16, 21)
OTHER = 16                       # any other character
GAP = '  |  '
ROW = 980                        # the release row's width (read from the skin when it can be)
_skin = {}


def width(text):
    return sum(_WIDTHS[ord(c) - 32] if 32 <= ord(c) <= 126 else (8 if c == '·' else OTHER) for c in text or '')


def _layout():
    """{'row': width, 'images': {name: width}} of the HOME RELEASE row, read once."""
    if _skin:
        return _skin
    images, row = {}, ROW
    try:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        with open(os.path.join(here, 'resources/skins/Default/1080i/meganexus_home.xml'), encoding='utf-8') as handle:
            text = handle.read()
        at = text.index('<!-- HOME RELEASE -->')
        found = re.search(r'<width>(\d+)</width>', text[at:at + 400])
        row = int(found.group(1)) if found else ROW
        for size, name in re.findall(r'<width>(\d+)</width><height>\d+</height><aspectratio>keep</aspectratio>'
                                     r'<texture>[^<]*/release/(\w+)\.png</texture>', text[at:at + 20000]):
            images.setdefault(name, int(size))
    except (OSError, ValueError):
        pass
    _skin.update(row=row, images=images)
    return _skin


def room(kind='', status='', date=''):
    """The pixels left for the words after the badges and the date (the skin's gaps)."""
    layout = _layout()
    used = 0
    if status:
        used += layout['images'].get(status, 121) + 10
    if kind:
        used += layout['images'].get(kind, 224)
    if date:
        used += 14 + width(date)
    if kind or status:
        used += 18
    return max(0, layout['row'] - used - 6)            # a few pixels to spare


def _kind(part):
    if part in ('Series', 'Movie'):
        return 'kind'
    if re.fullmatch(r'\d{4}', part):
        return 'year'
    if part.endswith(' left'):
        return 'left'
    if part.endswith('% watched'):
        return 'watched'
    if part.startswith('Ends '):
        return 'ends'
    if re.match(r'S\d+ · E\d+', part):
        return 'episode'
    return ''


def fit(line, ends='', space=ROW):
    """``line`` ("a  |  b  |  c") and ``ends`` as one line no wider than ``space`` px."""
    parts = [p for p in (line or '').split(GAP) if p] + ([ends] if ends else [])
    text = GAP.join(parts)
    if width(text) <= space:
        return text
    for drop in ('year', 'kind', 'left'):
        parts = [p for p in parts if _kind(p) != drop]
        text = GAP.join(parts)
        if width(text) <= space:
            return text
    # other words, from the end - not the episode, how much was seen or when it ends
    keep = ('episode', 'watched', 'ends')
    while any(_kind(p) not in keep for p in parts):
        last = max(i for i, p in enumerate(parts) if _kind(p) not in keep)
        parts.pop(last)
        text = GAP.join(parts)
        if width(text) <= space:
            return text
    parts = [p.replace('% watched', '%') for p in parts]
    for gap in (GAP, ' | '):                           # last, the gaps closer together
        text = gap.join(parts)
        if width(text) <= space:
            return text
    while parts and width(text) > space:
        parts.pop()                                    # what is left, from the end
        text = ' | '.join(parts)
    return text
