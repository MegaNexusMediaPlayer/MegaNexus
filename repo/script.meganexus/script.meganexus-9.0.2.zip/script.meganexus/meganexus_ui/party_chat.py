# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Watch Party friends on the TV like a messaging app (7.0.55, meganexus_party_chat.xml).

Friends on the left - their initial, a green dot when online, the last message and how many
are new; the conversation with the friend chosen on the right (theirs left, mine right).
Writing opens Kodi's keyboard; the phone (Watch Party > Friends) is quicker for long ones.
Pairing codes show only when a request is accepted, never in the list.
"""
import textwrap
import time

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.kodi_text import for_kodi
from resources.lib.party_service import has_emoji

from .dialog import Dialog

TITLE = 'Friends'
REFRESH = 2.0                 # s between looks at the party service (new messages, who is online)
FRIENDS, MESSAGES = 500, 600
WRITE, INVITE, ADD, REMOVE = 700, 701, 702, 703
CONTEXT = 117
LINE_CHARS = 52               # 8.1.0: characters of a bubble's line (652 px, font12, a little short on purpose)


def _ago(at):
    seconds = max(0, time.time() - float(at or 0))
    if seconds < 60:
        return 'now'
    if seconds < 3600:
        return '%d min' % (seconds // 60)
    if seconds < 86400:
        return '%d h' % (seconds // 3600)
    return '%d d' % (seconds // 86400)


class FriendsWindow(Dialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.api = kwargs['api']
        self.talking = ''
        self.state = None
        self.friend_rows = []
        self.shown_friends = None
        self.shown_talk = None
        self.looked = 0.0

    # --- what is shown -------------------------------------------------------------------------
    def onInit(self):
        self.refresh(force=True)
        if not self.friend_rows:
            self.focus(ADD)

    def tick(self):
        if time.monotonic() - self.looked >= REFRESH:
            self.refresh()

    def refresh(self, force=False):
        self.looked = time.monotonic()
        try:
            self.state = self.api('/api/party/state')
        except ValueError:
            return
        people = [f for f in self.state['friends'] if f['state'] in ('friend', 'asking')]
        people.sort(key=lambda f: (f['state'] != 'asking', not f.get('online'),
                                   -((f.get('messages') or [{}])[-1].get('at') or 0), f['name'].lower()))
        rows = []
        for friend in people:
            last = (friend.get('messages') or [{}])[-1]
            if friend['state'] == 'asking':
                line = 'Wants to be your friend'
            elif last.get('text'):
                line = ('You: ' if last.get('from') != friend['public'] else '') + last['text']
            else:
                line = 'Online' if friend.get('online') else 'Offline'
            rows.append((friend['public'], friend['name'], line, bool(friend.get('online')),
                         str(friend.get('unread') or '') if friend.get('unread') else ''))
        party = self.state.get('party')
        self.setProperty('meganexus.chat.hosting', '1' if party and party.get('hosting') else '')
        if force or rows != self.shown_friends:
            self.shown_friends = rows
            self._fill_friends(rows)
        if not self.talking and rows:
            self.talking = rows[0][0]
        self._show_talk(force)

    def _fill_friends(self, rows):
        control = self.getControl(FRIENDS)
        keep = control.getSelectedPosition()
        items = []
        for public, name, line, online, unread in rows:
            item = xbmcgui.ListItem(name, for_kodi(line) if has_emoji(line) else line)
            item.setProperty('initial', (name.strip()[:1] or '?').upper())
            item.setProperty('online', '1' if online else '')
            item.setProperty('unread', unread)
            item.setProperty('public', public)
            item.setProperty('lineemoji', '1' if has_emoji(line) else '')   # 7.0.61: emoji in the chat font
            items.append(item)
        self.friend_rows = rows
        if control.size() == len(items) and items:
            for index, item in enumerate(items):        # in place: the cursor stays where it is
                row = control.getListItem(index)
                row.setLabel(item.getLabel()); row.setLabel2(item.getLabel2())
                for key in ('initial', 'online', 'unread', 'public', 'lineemoji'):
                    row.setProperty(key, item.getProperty(key))
            return
        control.reset()
        control.addItems(items)
        if items:
            control.selectItem(max(0, min(keep, len(items) - 1)))

    def _show_talk(self, force=False):
        friend = next((f for f in self.state['friends'] if f['public'] == self.talking), None)
        if friend is None:
            self.setProperty('meganexus.chat.friend', '')
            self.setProperty('meganexus.chat.name', '')
            self.setProperty('meganexus.chat.state', '')
            self.setProperty('meganexus.chat.empty', 'Choose a friend on the left.')
            self.getControl(MESSAGES).reset()
            self.shown_talk = None
            return
        self.setProperty('meganexus.chat.name', friend['name'])
        self.setProperty('meganexus.chat.friend', '1' if friend['state'] == 'friend' else '')
        if friend['state'] == 'asking':
            self.setProperty('meganexus.chat.state', 'Wants to be your friend - select their name to accept')
        else:
            self.setProperty('meganexus.chat.state', 'Online' if friend.get('online') else 'Offline')
        self.setProperty('meganexus.chat.empty', 'No messages yet - write to %s.' % friend['name'])
        messages = friend.get('messages') or []
        key = (friend['public'], tuple((m.get('at'), m.get('from'), m.get('text')) for m in messages))
        if not force and key == self.shown_talk:
            return
        self.shown_talk = key
        control = self.getControl(MESSAGES)
        control.reset()
        items = []
        me = (self.state.get('me') or {}).get('name') or 'You'
        for message in messages:
            mine = message.get('from') != friend['public']
            text = message.get('text') or ''
            emoji = has_emoji(text)
            # 8.1.0: a bubble holds two lines - a long message goes on in the bubbles under it
            # (it was cut after its first line)
            lines = textwrap.wrap(text, LINE_CHARS) or ['']
            pieces = [lines[:1]] + [lines[i:i + 2] for i in range(1, len(lines), 2)]
            for index, piece in enumerate(pieces):
                body = '[CR]'.join(piece)
                body = for_kodi(body) if emoji else body
                if index == 0:      # who wrote it (and when) above the text - mine with my name
                    body = '[B]%s[/B]  [COLOR %s]· %s[/COLOR][CR]%s' % (
                        me if mine else friend['name'], '99FFFFFF' if mine else '99A0A8C0', _ago(message.get('at')), body)
                item = xbmcgui.ListItem(body)
                item.setProperty('mine', '1' if mine else '')
                item.setProperty('emoji', '1' if emoji else '')
                items.append(item)
        control.addItems(items)
        if items:
            control.selectItem(len(items) - 1)            # the newest at the bottom, in view
        if friend.get('unread'):
            try:
                self.api('/api/party/read', {'public': friend['public']})
            except ValueError:
                pass

    # --- what the remote does --------------------------------------------------------------------
    def _selected(self):
        position = self.getControl(FRIENDS).getSelectedPosition()
        return self.friend_rows[position][0] if 0 <= position < len(self.friend_rows) else ''

    def onClick(self, cid):
        if cid == FRIENDS:
            public = self._selected()
            friend = next((f for f in self.state['friends'] if f['public'] == public), None)
            if friend is None:
                return
            self.talking = public
            if friend['state'] == 'asking':
                if xbmcgui.Dialog().yesno(TITLE, 'Be friends with %s?' % friend['name']):
                    pair = self.api('/api/party/friend/accept', {'public': public}).get('pair')
                    xbmcgui.Dialog().ok(TITLE, 'You and %s are friends.[CR][CR]Both TVs show [B]%s[/B] - check it is the '
                                               'same on theirs.' % (friend['name'], pair))
            self.refresh(force=True)
            self.setFocusId(WRITE)
        elif cid == WRITE:
            self._write()
        elif cid == INVITE:
            friend = next((f for f in self.state['friends'] if f['public'] == self.talking), None)
            if friend:
                self.api('/api/party/invite', {'public': friend['public']})
                xbmcgui.Dialog().ok(TITLE, 'Invited %s.' % friend['name'])
        elif cid == REMOVE:
            self._remove(self.talking)
        elif cid == ADD:
            from .party import _find_friend
            self.child(_find_friend)
            self.refresh(force=True)

    def _write(self):
        friend = next((f for f in self.state['friends'] if f['public'] == self.talking), None)
        if friend is None or friend['state'] != 'friend':
            return
        text = xbmcgui.Dialog().input('Message to %s' % friend['name'])
        if text and text.strip():
            self.api('/api/party/dm', {'public': friend['public'], 'text': text})
            self.refresh(force=True)

    def _remove(self, public):
        friend = next((f for f in self.state['friends'] if f['public'] == public), None)
        if friend and xbmcgui.Dialog().yesno(TITLE, 'Remove %s from your friends?' % friend['name']):
            self.api('/api/party/friend/remove', {'public': public})
            if self.talking == public:
                self.talking = ''
            self.refresh(force=True)
            self.setFocusId(FRIENDS if self.friend_rows else ADD)

    def onAction(self, action):
        if action.getId() == CONTEXT and self.getFocusId() == FRIENDS:
            self._remove(self._selected())          # the long press does the same
            return
        from .dialog import BACK
        if action.getId() in BACK:
            self.close()


def open_friends(api):
    from resources.lib.theme import folder as theme_folder
    window = FriendsWindow('meganexus_party_chat.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),
                           theme_folder(), '1080i', api=api)
    try:
        window.doModal()
    finally:
        try:
            window.close()
        except Exception:
            pass
    del window
