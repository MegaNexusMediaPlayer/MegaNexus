# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Who is watching (7.0.45): the profile picker.

The first screen when Kodi starts - over the HUB, which shows only its picture
meanwhile (its pills, spotlight and corner wait, Home.xml) and gets ready behind it
(its theme and colours), so it opens finished. A circle per profile
(its picture, else its initials), + for a new one; OK opens it (its PIN first),
holding OK opens its settings. Also from Settings > Profiles. The work is in
resources.lib.user_profiles.
"""
import threading
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import screen_guard, user_profiles
from resources.lib.theme import folder as theme_folder

TONES = user_profiles.TONES
PICKER = 300
STEER = (1, 2, 3, 4, 7, 100)   # left, right, up, down, OK, mouse click


initials = user_profiles.initials


class _Picking(object):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.startup = kwargs.get('startup', False)
        self.chosen = None
        self.busy = False
        self.rows = []
        self.readying = False
        self.filled = False

    def onInit(self):
        # 7.0.60: the circles first - the window opens with an empty list that cannot take the
        # focus, so a press before this ran did nothing (the Cube: OK pressed several times)
        #
        # 8.1.2: Kodi sends onInit again when it has loaded a skin, after freeing and
        # rebuilding this window's controls. Counting it is the one signal the Python API
        # really gives for that - see generation() and alive().
        self._generation = getattr(self, '_generation', 0) + 1
        self.fill(focus=user_profiles.active())
        self.setProperty('meganexus.profiles.heading', "Who's watching?")
        if self.startup and not self.readying:
            # the HUB gets ready behind the picker only now - beside the opening it slowed
            # this window's own start
            self.readying = True
            threading.Thread(target=_hub_ready, name='MegaNexusHubReady', daemon=True).start()

    def generation(self):
        """Which build of this window's controls we are looking at.

        Kodi raises it by sending onInit, which it does for a fresh window and again
        every time it has loaded a skin. Code that opens a dialog of its own notes the
        generation first and checks it after: a different one means the controls it was
        about to touch have been freed and rebuilt, and the onInit that rebuilt them has
        already drawn everything. Touching them from the older run is what crashed Kodi
        on a rename in 8.1.1.
        """
        return getattr(self, '_generation', 0)

    def alive(self, generation):
        """The controls are still the ones that were there when `generation` was taken."""
        return self.generation() == generation

    def fill(self, focus=None):
        self.rows = user_profiles.profiles()
        items = []
        for index, row in enumerate(self.rows):
            li = xbmcgui.ListItem(row['name'], 'PIN' if row.get('pin') else '', offscreen=True)
            li.setProperties({'picture': row.get('picture') or '', 'initials': initials(row['name']),
                              'tone': str(index % TONES + 1)})
            items.append(li)
        if len(self.rows) < user_profiles.MAX_PROFILES:
            add = xbmcgui.ListItem('Add profile', '', offscreen=True)
            add.setProperties({'add': '1', 'initials': '+'})
            items.append(add)
        control = self.getControl(PICKER)
        control.reset()
        control.addItems(items)
        self.filled = bool(items)
        width = 260 * len(items)
        control.setWidth(min(width, 1820))
        control.setPosition(max(50, (1920 - width) // 2), 430)
        position = next((i for i, row in enumerate(self.rows) if row['id'] == focus), 0)
        control.selectItem(position)
        self.setFocusId(PICKER)

    def selected(self):
        position = self.getControl(PICKER).getSelectedPosition()
        return self.rows[position] if 0 <= position < len(self.rows) else None

    def onClick(self, cid):
        if cid != PICKER or self.busy:
            return
        row = self.selected()
        if row is None:
            self.add()
        else:
            self.open(row)

    def onAction(self, action):
        aid = action.getId()
        if aid in STEER and self.filled and not self.busy and self._focus() != PICKER:
            # 7.0.60: the first press never goes nowhere - the circles take the focus (OK opens
            # the one shown, as it would with the focus there)
            self.setFocusId(PICKER)
            if aid in (7, 100):
                self.onClick(PICKER)
            return
        if aid in (117, 101, 1009) and self.getFocusId() == PICKER and not self.busy:
            row = self.selected()
            if row is not None:
                # 8.1.2: the menu runs dialogs of its own (the keyboard for the new name,
                # the phone page, a question), which can take seconds. If a skin is loaded
                # meanwhile - the component installer did exactly that, here - these controls
                # are freed and rebuilt, and refilling the old ones crashed Kodi. The onInit
                # that rebuilt them has already drawn the new name, so there is nothing left
                # to do in that case.
                generation = self.generation()
                profile_menu(row['id'], parent=self)
                if self.alive(generation):
                    self.fill(focus=row['id'])
        elif aid in (9, 10, 92, 216, 247, 257, 275, 61448, 61467):
            # at Kodi's start a profile is chosen (the one in use stays with Back
            # only when it has no PIN); from Settings, Back just closes
            if not self.startup:
                self.close()
            elif not user_profiles.has_pin(user_profiles.active()):
                self.chosen = user_profiles.active()
                self.close()

    def _focus(self):
        try:
            return self.getFocusId()
        except RuntimeError:                      # nothing has the focus
            return 0

    def add(self):
        name = xbmcgui.Dialog().input('Name of the new profile').strip()
        if not name:
            return
        try:
            pid = user_profiles.add(name)
        except ValueError as exc:
            xbmcgui.Dialog().notification('Profiles', str(exc), time=4000)
            return
        self.fill(focus=pid)

    def open(self, row):
        if row.get('pin') and not ask_pin(row):
            return
        self.busy = True
        self.setProperty('meganexus.profiles.status', 'Opening %s…' % row['name'])
        try:
            ok = switch_to(row['id'])
        finally:
            self.busy = False
        if ok:
            self.chosen = row['id']
            self.close()
        else:
            self.setProperty('meganexus.profiles.status', '')
            xbmcgui.Dialog().notification('Profiles', 'The profile could not be opened. Try again.', time=4000)


class Picker(_Picking, xbmcgui.WindowXMLDialog):
    """Over the HUB (Kodi's start) or the Settings page it was opened from."""


def ask_pin(row):
    pin = xbmcgui.Dialog().numeric(0, 'PIN · %s' % row['name'], '', True)
    if not pin:
        return False
    if user_profiles.pin_ok(row['id'], pin):
        return True
    xbmcgui.Dialog().notification('Profiles', 'Wrong PIN.', time=3000)
    return False


def switch_to(pid):
    try:
        ok = user_profiles.request(pid)
    except Exception as exc:
        xbmc.log('[MegaNexus] profiles: %s' % exc, xbmc.LOGERROR)
        return False
    if ok:
        from resources.lib import settings_snapshot
        settings_snapshot.invalidate()
    return ok


def profile_menu(pid, parent=None):
    """A profile's settings: name, picture and PIN on the phone, its Nuvio profile, remove."""
    from .details import context_choice
    row = user_profiles.get(pid)
    if not row:
        return
    options = [('rename', 'Rename'), ('phone', 'Picture and PIN on your phone')]
    if row.get('pin'):
        options.append(('nopin', 'Remove the PIN'))
    options.append(('nuvio', 'Nuvio profile for %s' % row['name']))
    if not row.get('primary'):
        options.append(('remove', 'Remove %s' % row['name']))
    choice = context_choice(options=options)
    if not choice:
        return
    if row.get('pin') and choice in ('rename', 'phone', 'nopin', 'nuvio', 'remove') and not ask_pin(row):
        return
    try:
        if choice == 'rename':
            name = xbmcgui.Dialog().input('Name', row['name']).strip()
            if name:
                user_profiles.rename(pid, name)
        elif choice == 'phone':
            from .phone_setup import run
            run(profile=pid)
        elif choice == 'nopin':
            user_profiles.set_pin(pid, '')
        elif choice == 'nuvio':
            link_nuvio(pid)
        elif choice == 'remove':
            if xbmcgui.Dialog().yesno('Remove %s' % row['name'], 'Its sign-ins, Continue Watching and Library on this box '
                                      'are removed. Your accounts themselves are not touched.'):
                user_profiles.remove(pid)
    except ValueError as exc:
        xbmcgui.Dialog().notification('Profiles', str(exc), time=4000)


def link_nuvio(pid):
    """The profile follows one Nuvio profile of the account (the first profile's account
    when it has none): its Continue Watching, Library and watched come from there."""
    row = user_profiles.get(pid) or {}
    if pid != user_profiles.active():
        if not xbmcgui.Dialog().yesno('Nuvio profile', 'Open %s to choose its Nuvio profile?' % row.get('name', '')):
            return
        if not switch_to(pid):
            raise ValueError('The profile could not be opened.')
    if not user_profiles.nuvio_account_from_first():
        raise ValueError('Sign in to Nuvio first: HUB Settings > Accounts & tracking > Nuvio account.')
    from resources.lib.meganexus.cloud_sync import NuvioCloud
    try:
        rows = NuvioCloud.profiles()
    except Exception as exc:
        raise ValueError('Nuvio profiles could not be loaded (%s).' % exc)
    current = str(NuvioCloud.token().get('profile_index') or '')
    labels = [('● ' if str(r['profile_index']) == current else '') + r['profile_name'] for r in rows]
    pick = xbmcgui.Dialog().select('Nuvio profile for %s' % row.get('name', ''), labels)
    if pick < 0:
        return
    from resources.lib.phone_setup import nuvio_select_profile
    nuvio_select_profile(rows[pick]['profile_index'])
    xbmcgui.Window(10000).setProperty('meganexus.library_dirty', '1')
    xbmcgui.Dialog().notification('Nuvio profile', '%s follows %s' % (row.get('name', ''), rows[pick]['profile_name']), time=4000)


def choose(startup=False):
    """The picker; the chosen profile's id (None when closed from Settings)."""
    win = Picker('meganexus_profiles.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i',
               startup=startup)
    # 8.1.2: while this is on screen nothing of ours reloads the skin. At Kodi's start the
    # component installer runs behind this very window, and its ReloadSkin used to destroy
    # these controls under a key press that was still running (a crash on rename). This
    # window does not go through ui_entry.launch(), so it has to take the mark itself.
    screen_guard.hold()
    try:
        win.doModal()
        return win.chosen
    finally:
        screen_guard.release()
        del win


COVER = 'meganexus.profilesfirst'   # skin bool: at Kodi's start the HUB waits for who is watching (Home.xml)


def cover_rule(addon=None):
    """Whether the next Kodi start shows only the HUB's picture until a profile is chosen."""
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    wanted = addon.getSetting('meganexus_setup_offered') == 'true' and addon.getSetting('meganexus_profiles_at_start') != 'false'
    if wanted != bool(xbmc.getCondVisibility('Skin.HasSetting(%s)' % COVER)):
        xbmc.executebuiltin('Skin.SetBool(%s)' % COVER if wanted else 'Skin.Reset(%s)' % COVER)
    return wanted


def show_hub():
    """The HUB's pills, spotlight and corner (the service shows them after 25 s anyway)."""
    xbmcgui.Window(10000).setProperty('meganexus.profiles.done', '1')


def at_start():
    """Kodi's start: who is watching, over the HUB - it gets ready meanwhile and shows
    its pills once a profile is chosen. Not before the first-start setup (that one
    comes first, as before)."""
    try:
        home = xbmcgui.Window(10000)
        if not cover_rule() or home.getProperty('meganexus.profiles.asked'):
            return
        home.setProperty('meganexus.profiles.asked', '1')   # once per Kodi start
        choose(startup=True)                                # the HUB gets ready once it shows (onInit)
    finally:
        show_hub()


def _hub_ready():
    """Behind the picker: the HUB's theme, look and colours, so it opens finished."""
    for name, call in (('colours', lambda: __import__('resources.lib.interface_colors', fromlist=['x']).publish()),
                       ('look', lambda: __import__('resources.lib.presentation_settings', fromlist=['x']).sync()),
                       ('theme', lambda: __import__('resources.lib.theme', fromlist=['x']).sync())):
        try:
            call()
        except Exception as exc:
            xbmc.log('[MegaNexus] profiles: HUB %s not ready: %s' % (name, exc), xbmc.LOGINFO)
