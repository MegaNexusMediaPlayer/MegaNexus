# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The top row that keeps out of the way, for Sport and IPTV (8.1.3) - as on Home.

It is there while the cursor is on it and goes the moment the cursor leaves. Standing on
it, it goes after ROW_LINGER seconds and comes back with the next press. The skin slides
everything in the row up while the window's own property is empty
(review/make_screen_tops.py). It is the window's own property, not Home's: Home keeps
its row in step with Python, and another screen writing it would leave Home out of step.
"""
import time

ROW_PROPERTY = 'meganexus.toprow'
ROW_LINGER = 5.0


class TopRow(object):
    TOP_ROW = ()

    def _row_show(self, shown):
        if getattr(self, '_row_shown', None) is shown:
            return
        self._row_shown = shown
        self.setProperty(ROW_PROPERTY, '1' if shown else '')

    def row_focus(self, control_id=None, key=False):
        """The cursor moved (``control_id``) or a key was pressed (``key``)."""
        try:
            where = control_id if control_id is not None else self.getFocusId()
        except Exception:
            return
        if where in self.TOP_ROW:
            self._row_until = time.monotonic() + ROW_LINGER
            self._row_show(True)
        elif not key:
            self._row_until = 0.0
            self._row_show(False)

    def row_tick(self):
        until = getattr(self, '_row_until', 0.0)
        if until and time.monotonic() >= until:
            self._row_until = 0.0
            self._row_show(False)
