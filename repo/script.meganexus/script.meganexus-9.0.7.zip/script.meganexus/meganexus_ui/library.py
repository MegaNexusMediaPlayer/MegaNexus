# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus Library screen (6.0.35; 9.0.5 one Library).

9.0.5, as the streaming apps keep "My List" (Stremio's Library, Netflix, Plex's Watchlist):
one screen, every saved title once (library.everything) with the marks of every place it is
in. One row at the top: the places - All, this box, the Nuvio account, each tracking service,
with how many titles each holds - are the filters; the filter (an icon: a box with All, Movies,
Series, Anime); the order (an icon: a box with recently added, A-Z, year); the gear. It always
opens on everything. The date a title was added is on its card. The Local / Tracking
services / Calendar tabs are gone, and so are this device's files and the media servers'
rows here (they are Home's rows).

It opens from what this box keeps; the services are read again in the background and what
changed is written into the cards where they stand - nothing is emptied and drawn again
(it flashed, and the cursor jumped, every time a film or a title page closed), and the cursor
stays on its title.

The gear: View (rows, a poster grid, wide cards, a list with details) and the titles under
the cards. Saved in MegaNexus' settings (and its backup).
"""
import xbmcaddon
import xbmcgui
from resources.lib import art_cache, library
from resources.lib.settings_snapshot import cached_addon, invalidate as settings_invalidate
from resources.lib.theme import folder as theme_folder
from .dialog import Dialog, BACK
from . import listitems

PLACES_LIST = 220        # the places at the top: All, this box, Nuvio, the tracking services
FILTER_BUTTON = 205      # an icon: a box with All / Movies / Series / Anime
SORT_BUTTON = 204        # an icon: a box with the orders
OPTIONS = 210            # the gear: the view and the titles under the cards
VIEW_IDS = {'grid': 600, 'wide': 601, 'list': 602}
VIEWS = (('rows', 'Rows'), ('grid', 'Poster grid'), ('wide', 'Wide cards'), ('list', 'List with details'))
SORTS = (('added', 'Recently added'), ('title', 'Title A-Z'), ('year', 'Year'))
FILTERS = (('all', 'All'), ('movie', 'Movies'), ('series', 'Series'), ('anime', 'Anime'))
VIEW, SORT, TITLES = 'meganexus_library_view', 'meganexus_library_sort', 'meganexus_library_titles'
PLACE_NAMES = {library.LOCAL: 'This device', library.NUVIO: 'Nuvio'}
MAX_FLAT = 1000          # a grid / list holds this many
ROW_BASE = 500
MAX_ROWS = 14
ROW_CARDS = 20     # 7.0.29: a row shows this many, then "Browse all" opens the grid (as collections)


def _identity(card):
    target = card.get('target') or {}
    return (target.get('media_type'), target.get('canonical_id')) if target else ('browse', card.get('title'))


class LibraryWindow(Dialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.place = self.kind = 'all'      # it opens on everything ("na ulazu prikazuje sve")
        self.rows = []          # [(title, cards)] of the rows view
        self._flat = []         # the cards of a grid / list
        self._full = []
        self._cards = []        # library.everything()
        self._signature = None
        self._drawn = {}        # control id -> the identities of its cards, in order
        self._places_drawn = None
        self.outcome = ''
        self._refresh = None

    def onInit(self):
        # back from a title page or a film (Kodi set the screen up again): the title the
        # cursor was on when it left
        keep, self._leaving = getattr(self, '_leaving', None), None
        self._load()
        self._show(keep)
        if not getattr(self, '_focused_once', False):
            self._focused_once = True
            self.setFocusId(VIEW_IDS.get(option(VIEW, VIEWS), 9001) if self._cards else PLACES_LIST)
        else:
            self.restore_focus()
        self._start_refresh()

    def _load(self):
        """The Library again; True when anything a card shows changed."""
        try:
            cards = library.everything()
        except Exception:
            cards = []
        signature = [(_identity(c), tuple(c.get('services') or []), c.get('added_at'), c.get('poster'), c.get('title'))
                     for c in cards]
        changed = signature != self._signature
        self._signature, self._cards = signature, cards
        return changed

    # ---- drawing: only what changed, in place ------------------------------------------------
    def _focused_identity(self):
        cid = self.getFocusId()
        card = self._row(cid)
        return cid, (_identity(card) if card else None)

    def _show(self, keep=None):
        cid, keep = keep or self._focused_identity()
        view = option(VIEW, VIEWS)
        self.setProperty('meganexus.library.view', view)
        self.setProperty('meganexus.library.notitles', '' if cached_addon().getSetting(TITLES) != 'false' else '1')
        self.setProperty('meganexus.library.kind', self.kind)
        self.setProperty('meganexus.library.sort', dict(SORTS)[option(SORT, SORTS)])
        self._places()
        cards = library.chosen(self._cards, self.place, self.kind, option(SORT, SORTS))
        self.setProperty('meganexus.library.empty', '' if cards else (
            'Nothing here yet - long-press a title anywhere in MegaNexus and choose Add to Library.'
            if not self._cards else 'Nothing here with this choice.'))
        if view != 'rows':
            self._full, self.rows = [], []
            self._flat = cards[:MAX_FLAT]
            self._fill(VIEW_IDS[view], self._flat, keep if cid == VIEW_IDS[view] else None)
            return
        self._flat = []
        groups = [('Movies', [c for c in cards if c['target']['media_type'] == 'movie']),
                  ('Series', [c for c in cards if c['target']['media_type'] == 'series'])]
        self._full = [(title, group) for title, group in groups if group][:MAX_ROWS]
        self.rows = [(title, _shown(group)) for title, group in self._full]
        for index, (_, row) in enumerate(self.rows):
            if row and row[-1].get('browse_all', 0) is None:
                row[-1]['browse_all'] = index
        for i in range(MAX_ROWS):
            self.setProperty('meganexus.library.row.%d' % i, self.rows[i][0] if i < len(self.rows) else '')
            self._fill(ROW_BASE + i, self.rows[i][1] if i < len(self.rows) else [], keep if cid == ROW_BASE + i else None)
        for i in range(len(self.rows)):
            control = self.getControl(ROW_BASE + i)
            control.controlUp(self.getControl(ROW_BASE + i - 1) if i else self.getControl(PLACES_LIST))
            control.controlDown(self.getControl(ROW_BASE + min(i + 1, len(self.rows) - 1)))

    def _item(self, card):
        label2 = '  ·  '.join(x for x in (library.added_label(card.get('added_at')),
                                          '  '.join(_place_name(p) for p in card.get('services') or [])) if x)
        item = listitems.item(label=card['title'], label2=label2)
        poster = art_cache.card(card.get('poster'))
        item.setArt({'poster': poster, 'landscape': art_cache.card(card.get('landscape') or card.get('fanart')) or poster})
        self._marks_on(item, card)
        item.setProperty('plot', card.get('plot') or '')
        return item

    @staticmethod
    def _marks_on(item, card):
        _services(item, card)
        item.setProperty('added', library.added_label(card.get('added_at')).replace('Added ', ''))

    def _fill(self, cid, cards, keep=None):
        """The cards into one list. The same titles in the same order: written in place (marks,
        date) - the list is not emptied, so nothing flashes and the cursor does not move."""
        control = self.getControl(cid)
        identities = [_identity(c) for c in cards]
        # still holding them (Kodi may have made the list anew, empty, when the screen came back)
        if self._drawn.get(cid) == identities and control.size() == len(identities):
            for pos, card in enumerate(cards):
                try:
                    self._marks_on(control.getListItem(pos), card)
                except Exception:
                    break
            return
        pos = control.getSelectedPosition()
        control.reset()
        if cards:
            control.addItems([self._item(card) for card in cards])
            at = identities.index(keep) if keep in identities else min(max(pos, 0), len(cards) - 1)
            if at > 0:
                control.selectItem(at)
        self._drawn[cid] = identities

    def _places(self):
        """The places at the top - All and every place that holds titles, with how many."""
        found = [('all', len(self._cards))] + library.place_counts(self._cards)
        if self.place not in [place for place, _ in found]:
            self.place = 'all'
        drawn = (tuple(found), self.place)
        control = self.getControl(PLACES_LIST)
        if drawn == self._places_drawn and control.size() == len(found):
            return
        same = self._places_drawn is not None and [p for p, _ in self._places_drawn[0]] == [p for p, _ in found] \
            and control.size() == len(found)
        if not same:
            pos = control.getSelectedPosition()
            control.reset()
            items = []
            for place, count in found:
                item = listitems.item(label='All' if place == 'all' else _place_name(place), label2=str(count))
                item.setProperty('place', place)
                item.setProperty('mark', '' if place == 'all' else library.service_icon(place))
                items.append(item)
            control.addItems(items)
            if pos > 0:
                control.selectItem(min(pos, len(items) - 1))
        for index, (place, count) in enumerate(found):
            item = control.getListItem(index)
            item.setLabel2(str(count))
            item.setProperty('chosen', '1' if place == self.place else '')
        self._places_drawn = drawn

    # ---- the choices -------------------------------------------------------------------------
    def _options(self):
        """The gear: how the Library is laid out."""
        from . import settings_page as page
        def build():
            titles = cached_addon().getSetting(TITLES) != 'false'
            return [('view', page.item('View', dict(VIEWS)[option(VIEW, VIEWS)])),
                    ('titles', page.item('Titles under the cards', enabled=titles))]
        def act(key):
            addon = cached_addon()
            if key == 'titles':
                addon.setSetting(TITLES, 'false' if addon.getSetting(TITLES) != 'false' else 'true')
            else:
                keys = [k for k, _ in VIEWS]
                pick = xbmcgui.Dialog().select('View', [label for _, label in VIEWS], preselect=keys.index(option(VIEW, VIEWS)))
                if pick < 0:
                    return None
                addon.setSetting(VIEW, keys[pick])
            settings_invalidate()
            return None
        page.keyed('Library', build, act)

    def _choose_sort(self):
        """The orders in a box, the one in use chosen; True when another was picked."""
        keys = [k for k, _ in SORTS]
        now = keys.index(option(SORT, SORTS))
        pick = xbmcgui.Dialog().select('Sort', [label for _, label in SORTS], preselect=now)
        if pick < 0 or pick == now:
            return False
        cached_addon().setSetting(SORT, keys[pick])
        settings_invalidate()
        return True

    def _choose_filter(self):
        """All / Movies / Series / Anime in a box; True when another was picked."""
        keys = [k for k, _ in FILTERS]
        now = keys.index(self.kind) if self.kind in keys else 0
        pick = xbmcgui.Dialog().select('Show', [label for _, label in FILTERS], preselect=now)
        if pick < 0 or pick == now:
            return False
        self.kind = keys[pick]
        return True

    # ---- the services read again, behind the screen --------------------------------------------
    def _start_refresh(self):
        if self._refresh is not None or getattr(self, '_refreshed', False):
            return
        from .play_jobs import _CATALOG

        def work():
            library.refresh_tracking()
            # 8.1.2: and a picture for the titles that arrived without one (the Nuvio
            # account's library is keyed by TMDB id and often carries no artwork)
            library.fill_missing_posters()
            library.learn_ids()          # 9.0.5: one card for a title kept under two ids
        self._refresh = _CATALOG.submit(work)

    def tick(self):
        if self._refresh is None or not self._refresh.done():
            return
        future, self._refresh = self._refresh, None
        self._refreshed = True
        try:
            future.result()
        except Exception:
            pass
        if self._load():
            self._show()

    def _row(self, cid):
        if cid in VIEW_IDS.values():
            pos = self.getControl(cid).getSelectedPosition()
            return self._flat[pos] if 0 <= pos < len(self._flat) else None
        index = cid - ROW_BASE
        if not 0 <= index < len(self.rows):
            return None
        cards = self.rows[index][1]
        pos = self.getControl(cid).getSelectedPosition()
        return cards[pos] if 0 <= pos < len(cards) else None

    def _back_from(self, outcome):
        """A title page or a film closed: what it changed (removed, added) is written in place."""
        self.outcome = outcome
        if outcome == 'playing' or isinstance(outcome, dict):
            self.close()
        elif self._load():
            self._show()

    def onClick(self, cid):
        if cid == PLACES_LIST:
            item = self.getControl(cid).getSelectedItem()
            if item is not None and item.getProperty('place') != self.place:
                self.place = item.getProperty('place')
                self._show()
            return
        if cid == FILTER_BUTTON:
            if self.over(self._choose_filter):
                self._show()
            return
        if cid == SORT_BUTTON:
            if self.over(self._choose_sort):
                self._show()
            return
        if cid == OPTIONS:
            self.over(self._options)
            self._show()
            self.setFocusId(OPTIONS)
            return
        card = self._row(cid)
        if card and card.get('browse_all') is not None:
            # 7.0.29: the whole row as a grid
            from .catalog import open_catalog
            title, cards = self._full[card['browse_all']]
            self._leaving = (cid, _identity(card))
            self._back_from(self.child(open_catalog, {
                'label': 'Library · ' + title, 'rows': [c for c in cards if c.get('target')]}))
            return
        if not card or not card.get('target'):
            return
        self._leaving = (cid, _identity(card))
        from .details import open_context, plays_directly
        direct = plays_directly(card['target'], card)   # 7.0.44: else the title like on Home (hero)
        self._back_from((self.in_place if direct else self.child)(open_context, card['target'], row=card, hero=not direct))

    def onAction(self, action):
        aid = action.getId()
        if aid in BACK:
            self.close()
            return
        card = self._row(self.getFocusId())
        if not card or not card.get('target') or aid not in (117, 101, 1009, 11):
            return
        from .details import context_choice, quick_choice, run_choice, plays_directly
        choice = 'details' if aid == 11 else context_choice(card['target'], card)   # 7.0.36: its page, no Info window
        if not choice:
            return
        if quick_choice(choice, card['target'], card):
            if self._load():
                self._show()
            return
        self._leaving = (self.getFocusId(), _identity(card))
        self._back_from((self.in_place if plays_directly(card['target'], card, choice) else self.child)(
            run_choice, card['target'], choice, card))


def _place_name(place):
    return PLACE_NAMES.get(place) or dict((tid, name) for tid, name, _, _ in library.TRACKERS).get(place, place)


# this box, Nuvio, Trakt, Simkl, MDBList, WeTrakr - as many as the skin has places for
# (review/make_service_marks.py); 9.0.4: it was 5, and WeTrakr, the sixth, never got its count at the top
MARKS = 6


def _services(item, card):
    """Where this title lives, as small round marks along the top of the poster.

    8.1.2: it was three name pills stacked down the corner ("Local", "Trakt", "Simkl"),
    110 px wide each - they covered a third of the picture and three was not enough
    anyway. The marks are drawn by the skin from these properties, so a service that is
    added later needs no change there at all.
    """
    marks = [library.service_icon(name) for name in (card.get('services') or [])]
    marks = [mark for mark in marks if mark]
    for n in range(MARKS):
        item.setProperty('service.%d' % n, marks[n] if n < len(marks) else '')


def option(setting, choices):
    value = cached_addon().getSetting(setting)
    return value if value in dict(choices) else choices[0][0]


def _shown(cards):
    """The first ROW_CARDS of a row, then "Browse all · N" (rows of titles only - a
    file of this device or a server episode has no title page for the grid)."""
    if len(cards) <= ROW_CARDS or not all(c.get('target') for c in cards):
        return cards
    # 8.1.2: nothing behind it. It used to borrow the next title's poster, so the card
    # that opens the whole row looked like one particular film - "na browse all mi je
    # Schindler's List poster... treba biti prazan, ne sa posterom nekog filma".
    return cards[:ROW_CARDS] + [{'title': 'Browse all · %d' % len(cards), 'poster': '',
                                 'badges': ['Browse all'], 'browse_all': None}]


def open_library():
    win = LibraryWindow('meganexus_library.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i')
    try:
        win.doModal()
        return win.outcome
    finally:
        win.close()
