# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The HUB's Music app (9.0.6): MegaNexus' Home with music in it, as the YouTube app is.

Home's own screen, top bar, corner (profile, clock) and rows that go round; the cards square
(make_music_home.py: an artist round), the top showing the card under the cursor with its artwork
where Home's small player is, and along the bottom, always, the bar of what plays (701-705).

* Home: what you listen to first (Recently played, your playlists brought in from Spotify, Deezer,
  YouTube or a file - Settings > Music - For you: a mix of your artists' songs - and your artists), your Deezer, what you saved, your sources' rows, the catalogue's charts (Deezer's, Apple
  Music's or Spotify's - Settings > Music), your debrid cloud and your folders.
* Library (106): what you saved, your folders, your debrid cloud, Kodi's music library.
* Search (105): your music, then songs, albums, artists and playlists of the catalogue and your sources.
* Settings (107): MegaNexus' Settings > Music - the sources, the catalogue, your Deezer, your folders.
* HUB (108): the app closes; Back steps back (the bar to the rows, a page to the one before) and
  never closes it.

OK on a song plays its row from there; on an album or a playlist opens its page (meganexus_music.xml:
its songs beside the cover); on an artist, their rows. The menu key: Play next, Add to queue, Save.
Music plays in Kodi's music player and goes on when the app closes; a song's address is asked for
only as it comes to play (music_play) - a catalogue's songs from your sources, your cloud or YouTube.
"""
import json
import queue
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import home_data, music, music_cloud, music_import, music_play, music_watch, screen_guard
from resources.lib.kodi_text import world
from resources.lib.music_play import FROM, KEYS, PICTURE, LOADING, MISSED, PLAYING, QUEUED, QUEUE_MAX, ROUND, queue_item
from resources.lib.theme import folder as theme_folder
from .dialog import Dialog, BACK
from .home_window import ADDON, HUB_SETTLE_PLAIN, ROW_BASE, HomeWindow
from . import listitems

HOME, LIBRARY, SEARCH, ARTIST = 'music', 'music:library', 'music:search', 'music:artist:'
XML, PAGE, MINI, NOW = 'meganexus_home.xml', 'meganexus_music.xml', 'meganexus_music_mini.xml', 'meganexus_music_now.xml'
ROUND_PLAY = 113                 # by HUB, while music plays (make_music_home.py): Now playing
CONTEXT = (117, 101, 1009)
MUSIC_ON = '[!String.IsEmpty(Window(10000).Property(meganexus.music.playing)) + !String.IsEmpty(MusicPlayer.Title)]'   # OUR song plays - an IPTV channel or a film is no song
MUSIC_WORKERS = 8               # the app's rows at once (each a few questions to a catalogue)
KINDS = (('tracks', 'Songs'), ('albums', 'Albums'), ('artists', 'Artists'), ('playlists', 'Playlists'))
LABELS = {'album': 'Album', 'artist': 'Artist', 'playlist': 'Playlist', 'track': 'Song'}


# ---- what the rows hold ---------------------------------------------------------------------------
def _shelf(title, job):
    return {'title': title, 'rows': [home_data.placeholder(' ', '')], 'music_job': job, 'shape': 'square'}


def shelves(view, query=''):
    """Every row of one of the app's views - none of them asked for yet (the window loads them)."""
    if view == SEARCH:
        return [_shelf('Yours · folders and cloud', ('search', query, 'mine'))] + [_shelf(title, ('search', query, kind)) for kind, title in KINDS]
    if view.startswith(ARTIST):
        # the artist's discography first - albums, then singles and EPs - then their popular songs and who is like them
        source, _, item_id = view[len(ARTIST):].partition(':')
        return [_shelf(title, ('artist', source, item_id, part)) for part, title in
                (('albums', 'Albums'), ('singles', 'Singles & EPs'), ('tracks', 'Popular'), ('related', 'Fans also like'))]
    profile = music.deezer_profile()
    rows = []
    mine = [_shelf('Your playlists', ('imported',))] if music_import.playlists() else []      # brought in from elsewhere
    if view == LIBRARY:
        saved = {e['kind'] for e in music.library()}
        rows += mine
        rows += [_shelf('Artists you follow', ('follows',))] if music.follows() else []
        rows += [_shelf('Saved %s' % title.lower(), ('saved', kind[:-1])) for kind, title in KINDS if kind[:-1] in saved]
        rows += [_shelf('Deezer · %s' % title, ('deezer_mine', n)) for n, title in
                 enumerate(('Favourite songs', 'Favourite albums', 'Favourite artists', 'Playlists'))] if profile else []
        rows += [_shelf(name, ('catalog', source, catalog, kind)) for source, catalog, name, kind in music.catalogs()[:6]]
    else:
        # what this profile listens to and follows first; the catalogue's charts after
        if music.history():
            rows.append(_shelf('Recently played', ('recent',)))
        rows += mine
        if music.follows() or music.history():
            rows += [_shelf('For you', ('for_you',)), _shelf('Your artists', ('top_artists',)),
                     _shelf('New from your artists', ('new_from_yours',)), _shelf('Artists like yours', ('like_them',))]
        rows += [_shelf(title, ('chart', n)) for n, title in enumerate(music.CHART_ROWS[music.catalogue()])]
        rows += [_shelf('Saved', ('saved', ''))] if music.library() else []
    if music_cloud.services() and music_cloud.known() != []:       # its music, or not looked at yet
        rows += [_shelf('Debrid cloud · albums', ('cloud', 'albums')), _shelf('Debrid cloud · artists', ('cloud', 'artists'))]
    if music.folders():
        rows += [_shelf('Your folders · albums', ('folders', 'albums')), _shelf('Your folders · artists', ('folders', 'artists'))]
    if view == LIBRARY:
        rows += [_shelf('Kodi music library', ('kodi', 'albums')), _shelf('Kodi music library · artists', ('kodi', 'artists'))]
    return rows


def entries(job):
    """The songs, albums, artists or playlists of one row (asked for in the window's workers)."""
    kind = job[0]
    if kind == 'search':
        query, what = job[1], job[2]
        if what == 'mine':
            lowered = query.lower()
            mine = [t for songs in list(music.scan()[1].values()) + list(music_cloud.library()[1].values()) for t in songs]
            return [t for t in mine if lowered in ('%s %s' % (t['title'], t['artist'])).lower()][:40]
        found = music.search(query).get(what) or []
        try:
            found += music.lookup(query).get(what) or []
        except music.MusicError:
            pass
        return found
    if kind == 'artist':
        tracks, albums, related = _artist(job[1], job[2])
        records, singles = music.discography(albums)
        return {'tracks': tracks, 'albums': records, 'singles': singles, 'related': related}[job[3]]
    if kind == 'recent':
        return music.recent()
    if kind == 'for_you':
        return music.for_you()
    if kind == 'top_artists':
        return music.top_artists()
    if kind == 'new_from_yours':
        return music.new_from_yours()
    if kind == 'like_them':
        return music.like_them()
    if kind == 'follows':
        return music.follows()
    if kind == 'imported':
        return [{k: v for k, v in p.items() if k != 'tracks'} for p in music_import.playlists()]
    if kind == 'saved':
        return [e for e in music.library() if not job[1] or e['kind'] == job[1]][:60]
    if kind == 'deezer_mine':
        return music.deezer_mine(music.deezer_profile())[job[1]][1]
    if kind == 'catalog':
        return music.catalog(job[1], job[2], kind=job[3])
    if kind == 'chart':
        return music.charts()[job[1]][1]
    if kind in ('cloud', 'folders'):
        albums = (music_cloud.library() if kind == 'cloud' else music.scan())[0]
        return albums if job[1] == 'albums' else music.artists(albums)
    if kind == 'kodi':
        return music.local(job[1])
    return []


def _artist(source, item_id):
    """(songs, albums, related artists) of an artist - a catalogue's, or yours (your folders, your cloud,
    Kodi's music library) by their name."""
    if source != 'local':
        head, tracks, albums = music.details(source, 'artist', item_id)
        return tracks, albums, head.get('related') or []
    if not item_id.startswith('artist:'):
        return music.local('songs', artist=item_id), [], []
    name = item_id[len('artist:'):]
    mine, cloud = music.scan(), music_cloud.library()
    albums = [a for a in mine[0] + cloud[0] if a.get('artist') == name]
    songs = dict(mine[1], **cloud[1])
    return [s for a in albums for s in songs.get(a['id'], [])], albums, []


def _line(entry):
    """A card's line: what it is and by whom - ' · ' between."""
    parts = [entry.get('artist')]
    if entry['kind'] in ('album', 'playlist'):
        parts += [entry.get('year'), '%d songs' % entry['count'] if entry.get('count') else '']
    elif entry['kind'] == 'track':
        parts += [entry.get('album')]
    return '  ·  '.join(p for p in parts if p)


def card(entry):
    """One of the app's cards as Home draws it (home_window._fill)."""
    font, (title, line) = world(entry.get('title'), entry.get('artist') or '')
    meta = '  ·  '.join(p for p in (LABELS.get(entry['kind'], ''), _line(entry)) if p)
    # the card at a card's size, the big picture only in the top (Kodi drew a row of 1000 px covers slowly)
    return {'title': title, 'subtitle': line, 'poster': entry.get('thumb') or entry.get('picture') or '', 'fanart': entry.get('picture') or '',
            'meta_line': meta, 'plot': entry.get('about') or '', 'shape': 'square', 'font': font, 'music': entry}


def _pictures(found):
    """Covers and artists' photos for the cards without one (your folders, your cloud): Deezer's, the same name only."""
    wanted = [e for e in found if not e.get('picture') and e['kind'] in ('album', 'artist')][:40]
    if wanted:
        with ThreadPoolExecutor(max_workers=4, thread_name_prefix='MegaNexusMusic') as pool:
            for entry, picture in zip(wanted, pool.map(music.picture, wanted)):
                entry['picture'] = picture
    return found


# ---- playing ---------------------------------------------------------------------------------------
def stop_music():
    """The music off: Kodi's player stopped, its queue and the songs waiting for it cleared."""
    xbmc.Player().stop()
    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    home = xbmcgui.Window(10000)
    for key in json.loads(home.getProperty(KEYS) or '[]'):
        home.clearProperty(QUEUED + key)
    for name in (KEYS, PLAYING, MISSED, FROM, PICTURE, ROUND):
        home.clearProperty(name)


def play(tracks, start=0, shuffle=False, round_=False):
    """``tracks`` in Kodi's music queue from ``start``. That song's address is found here first, in the
    background while the ring turns by the profile (Kodi's screen stands still while it waits for an
    address), then Kodi starts it - behind; no player opens by itself (the circle by the profile and the
    round play by HUB open them)."""
    tracks = [t for t in tracks if t.get('kind') == 'track'][:QUEUE_MAX]
    if not tracks:
        return
    if not music.can_play() and all(t.get('source') != 'local' for t in tracks):
        xbmcgui.Dialog().notification('Music', 'Nothing plays songs yet - Settings > Music: a source, YouTube or your debrid cloud.', time=5000)
        return
    if shuffle:
        tracks = random.sample(tracks, len(tracks))
        start = 0
    xbmcgui.Window(10000).setProperty(LOADING, '1')
    threading.Thread(target=_start, args=(tracks, max(0, min(start, len(tracks) - 1)), round_),
                     name='MegaNexusMusicStart', daemon=True).start()


def _start(tracks, start, round_=False):
    """The song chosen and nothing else: when it cannot play, it says so and the music that plays goes on
    (never another song in its place - the next one was played instead, 2026-11-03)."""
    home = xbmcgui.Window(10000)
    try:
        try:
            tracks[start] = dict(tracks[start], **dict(zip(('ready', 'ready_from'), music.playable(tracks[start]))))
        except music.MusicError as exc:
            xbmcgui.Dialog().notification('%s - %s' % (tracks[start].get('artist') or 'Music', tracks[start].get('title') or ''),
                                          music.safe(exc) or 'This song cannot play.', time=5000)
            return
        stop_music()
        if round_:
            home.setProperty(ROUND, json.dumps(tracks))      # a playlist: at its end it starts again
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        playlist.clear()
        for track in tracks:
            playlist.add(*queue_item(track))
        # windowed: Kodi stays where it is - no full-screen visualisation over the app
        xbmc.Player().play(playlist, startpos=start, windowed=True)
    finally:
        home.clearProperty(LOADING)


def resume():
    """The song a film, a trailer or a video took the player from (music_watch.RESUME): its queue again,
    from that song and that second - in the background (the screen is never held for it)."""
    home = xbmcgui.Window(10000)
    try:
        saved = json.loads(home.getProperty(music_watch.RESUME) or 'null')
    except ValueError:
        saved = None
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    if not saved or not playlist.size():
        return False

    pos = min(max(0, int(saved.get('pos') or 0)), playlist.size() - 1)
    music_play.go_on_from(playlist[pos].getPath(), saved.get('time'))

    def work():
        xbmc.Player().play(playlist, startpos=pos, windowed=True)
    for name in (music_watch.RESUME, music_watch.RESUME + '.title', music_watch.RESUME + '.artist'):
        home.clearProperty(name)
    threading.Thread(target=work, name='MegaNexusMusicResume', daemon=True).start()
    return True


def enqueue(track, after_current=False):
    if not xbmc.getCondVisibility(MUSIC_ON):
        return play([track])
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    url, item = queue_item(track)
    if after_current:
        playlist.add(url, item, index=playlist.getposition() + 1)
    else:
        playlist.add(url, item)
    xbmcgui.Dialog().notification('Music', 'Plays next.' if after_current else 'Added to the queue.', time=2000)


def options(entry):
    """The menu key on a song, an album, an artist or a playlist. True: it was taken out (of your library,
    of the artists you follow)."""
    if entry.get('source') == music_import.SOURCE and entry['kind'] == 'playlist':
        if xbmcgui.Dialog().yesno(entry.get('title') or 'Music', 'Remove this playlist from MegaNexus?'):
            music_import.remove(entry['id'])
            return True
        return False
    kept = music.saved(entry)
    follows = entry['kind'] == 'artist' and entry.get('source') == music.DEEZER
    choices = (['Play next', 'Add to queue'] if entry['kind'] == 'track' else []) + \
              (['Unfollow' if music.following(entry) else 'Follow'] if follows else []) + \
              ['Remove from your library' if kept else 'Save in your library']
    pick = xbmcgui.Dialog().select(entry.get('title') or 'Music', choices)
    if pick < 0:
        return False
    if choices[pick] == 'Play next':
        enqueue(entry, after_current=True)
    elif choices[pick] == 'Add to queue':
        enqueue(entry)
    elif choices[pick] in ('Follow', 'Unfollow'):
        music.follow(entry, choices[pick] == 'Follow')
        xbmcgui.Dialog().notification('Music', 'You follow %s.' % entry['title'] if choices[pick] == 'Follow'
                                      else 'You no longer follow %s.' % entry['title'], time=2000)
        return choices[pick] == 'Unfollow'
    else:
        music.keep(entry, not kept)
        xbmcgui.Dialog().notification('Music', 'Taken out of your library.' if kept else 'Saved in your library.', time=2000)
        return kept
    return False


# ---- the app's screen (Home) ------------------------------------------------------------------------
class MusicWindow(HomeWindow):
    """Home, with music in it."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._hero = None
        self._history = []        # the views before this one (Back)
        # the app's rows load on workers of their own: on Home's four, a new view's rows waited up to 10 s
        # behind the slow rows of the view before (an artist's Popular behind Home's For you)
        self._music_pool = ThreadPoolExecutor(max_workers=MUSIC_WORKERS, thread_name_prefix='MegaNexusMusicRows')

    def onInit(self):
        self.setProperty('meganexus.app', 'music')   # the app's logo and top (review/make_app_home.py)
        super().onInit()
        try:
            self.getControl(106).setLabel('Library')
            # HUB in Watch Party's place (that one is MegaNexus' own): the bar keeps its even gaps
            self.getControl(108).setPosition(*self.getControl(114).getPosition())
        except Exception:
            pass

    def _paint_rows(self, rows):
        super()._paint_rows(rows)
        self.setProperty('meganexus.search.query', getattr(self, '_music_query', '') if self._bucket == SEARCH else '')

    def _load(self, index, shelf, generation):
        if not shelf.get('music_job'):
            return super()._load(index, shelf, generation)
        if not self._closed and generation == self._generation:
            self._music_pool.submit(self._load_music, index, shelf, generation)

    def _load_music(self, index, shelf, generation):
        job = shelf['music_job']
        if self._closed or generation != self._generation:
            return                       # a view left before its turn came
        try:
            found = _pictures(entries(job))
            cards = [card(e) for e in found] or [dict(home_data.placeholder('Nothing here', ''), shape='square', music={'empty': True})]
        except music.MusicError as exc:
            cards = [dict(home_data.placeholder('Did not answer', music.safe(exc)), shape='square', music={'retry': True})]
        except Exception as exc:
            xbmc.log('[MegaNexus] Music row did not load: %s' % music.safe(exc), xbmc.LOGWARNING)
            cards = [dict(home_data.placeholder('Did not answer', 'Select to ask again.'), shape='square', music={'retry': True})]
        if not self._closed and generation == self._generation:
            g = shelf.get('_ring_g')
            if g is not None and 0 <= g < len(self._pages) and self._pages[g].get('music_job') == job:
                self._pages[g].update(rows=cards, _loaded=True)
            self._updates.put((generation, index, cards, None, g))

    def drain_updates(self):
        super().drain_updates()
        if not self._closed:
            self._hero_tick()

    # ---- the top: the card under the cursor ---------------------------------------------------------
    def _hero_tick(self):
        """Its title, its line (what it is, by whom - ' · ' between), its about and its artwork - set
        only when the card changes."""
        control_id, pos, _ = self._selection()
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves):
            return                                     # on the top bar: the last card stays
        rows = self._shelves[index].get('rows') or []
        row = rows[pos] if 0 <= pos < len(rows) else {}
        if row is self._hero:
            return
        self._hero = row
        self.setProperty('meganexus.app.font', row.get('font') or '')
        for name, key in (('title', 'title'), ('meta', 'meta_line'), ('plot', 'plot'), ('fanart', 'fanart')):
            self.setProperty('meganexus.app.' + name, str(row.get(key) or '').strip())

    # ---- keys ------------------------------------------------------------------------------------------
    def _go(self, view, query=None, back=False):
        """Another of the app's views, drawn in this screen (the music plays on)."""
        if not back and view != self._bucket:
            self._history.append((self._bucket, getattr(self, '_music_query', '')))
        if query is not None:
            self._music_query = query
        self._bucket = view
        self._focus_memory.pop(view, None)
        self._paint(shelves(view, getattr(self, '_music_query', '')))

    def onClick(self, control_id):
        self._touch()
        if control_id == 101:
            self._history = []
            return self._go(HOME, back=True) if self._bucket != HOME else None
        if control_id in (105, 111):
            return self._search()
        if control_id == 106:
            return self._go(LIBRARY) if self._bucket != LIBRARY else None
        if control_id == 107:
            return self._settings()
        if control_id == ROUND_PLAY and xbmc.getCondVisibility(MUSIC_ON):
            # over the app: closing it for Kodi's own music window was refused (a Python window was open)
            # and the app came back drawn anew
            self._suspended = True
            try:
                self.over(open_now)
            finally:
                self._suspended = False
            return
        row, index = self._card(control_id)
        if row is None:
            if index < 0:
                super().onClick(control_id)     # the HUB
            return
        found = row.get('music') or {}
        if found.get('retry'):
            self._shelves[index]['_loaded'] = False
            self._scheduled.discard(index)
            return
        if found.get('kind') == 'track':
            songs = [r['music'] for r in self._shelves[index].get('rows') or () if (r.get('music') or {}).get('kind') == 'track']
            return play(songs, songs.index(found))         # it plays behind; its buttons open by the profile
        if found.get('kind') == 'artist':
            return self._go(ARTIST + '%s:%s' % (found['source'], found['id']))
        if found.get('kind') in ('album', 'playlist'):
            self.child(open_page, found)

    def _card(self, control_id):
        if not ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            return None, -1
        index = control_id - ROW_BASE
        rows = self._shelves[index].get('rows') or []
        pos = self.getControl(control_id).getSelectedPosition()
        return (rows[pos] if 0 <= pos < len(rows) else None), index

    def onAction(self, action):
        focus = self.getFocusId()
        if action.getId() in CONTEXT:
            row, index = self._card(focus)
            entry = (row or {}).get('music') or {}
            if entry.get('kind') in ('track', 'album', 'artist', 'playlist') and options(entry) and \
                    (self._bucket == LIBRARY or entry.get('source') == music_import.SOURCE):
                # out of your library: its card leaves the row where it stands (nothing else is drawn again)
                self._drop_card(index, self.getControl(focus).getSelectedPosition(), ('Nothing here', ''))
            return
        if action.getId() in BACK:
            # a step back - a view to the one before, the rows to the top bar; never out (HUB closes the app)
            self._touch()
            if self._history:
                view, query = self._history.pop()
                return self._go(view or HOME, query, back=True)
            if ROW_BASE <= focus < ROW_BASE + len(self._shelves):
                return self.setFocusId(101)
            return
        super().onAction(action)

    def _search(self):
        self._suspended = True
        try:
            query = xbmcgui.Dialog().input('Search music', getattr(self, '_music_query', '')).strip()
        finally:
            self._suspended = False
        if query:
            self._go(SEARCH, query)

    def _finish(self):
        self._music_pool.shutdown(wait=False, cancel_futures=True)
        super()._finish()

    def _settings(self):
        """MegaNexus' Settings > Music over the app; the rows again after (a source, the catalogue)."""
        from .settings import music_settings
        self._suspended = True
        try:
            self.over(music_settings)
        finally:
            self._suspended = False
        music.forget()
        self._go(self._bucket or HOME, back=True)


# ---- an album's or a playlist's page ---------------------------------------------------------------
def _song_line(entry, number, playing):
    font, (title, artist, album) = world(entry.get('title'), entry.get('artist'), entry.get('album'))
    li = listitems.item(label=title, label2=artist)
    li.setArt({'thumb': entry.get('picture') or ''})
    seconds = int(entry.get('seconds') or 0)
    listitems.properties(li, {'number': str(number), 'album': album, 'length': '%d:%02d' % divmod(seconds, 60) if seconds else '',
                              'font': font, 'playing': '1' if entry.get('id') == playing else ''})
    return li


class MusicPage(Dialog):
    """meganexus_music.xml: along the top the cover and its words; the songs under them - OK on one plays
    from there (the small player opens by the profile)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.entry = kwargs.get('entry')
        self.songs = []
        self.answers = queue.Queue()
        self.playing = None

    def onInit(self):
        self.setProperty('music.empty', 'Loading…')
        entry = self.entry

        def work():
            try:
                if entry['source'] == music_import.SOURCE:
                    found = music_import.songs(entry['id'])
                elif entry['source'] == 'local':
                    found = music.local('songs', album=entry['id']) if str(entry['id']).isdigit() else music.scan()[1].get(entry['id'], [])
                elif entry['source'] == music_cloud.SOURCE:
                    found = music_cloud.library()[1].get(entry['id'], [])
                else:
                    head, found, _ = music.details(entry['source'], entry['kind'], entry['id'])
                    entry.update({k: v for k, v in head.items() if v and k in ('picture', 'about', 'year', 'count', 'artist')})
                self.answers.put((entry, found))
            except music.MusicError as exc:
                self.answers.put((entry, music.safe(exc)))
        ThreadPoolExecutor(max_workers=1).submit(work)

    def _show(self, entry, songs):
        if isinstance(songs, str):
            self.setProperty('music.empty', songs)
            return
        self.songs = [s for s in songs if s.get('kind') == 'track']
        font, (title,) = world(entry.get('title') or '')
        for key, value in (('title', title), ('kind', LABELS.get(entry.get('kind'), entry.get('kind', '')).upper()),
                           ('line', _line(dict(entry, count=entry.get('count') or len(self.songs)))),
                           ('about', entry.get('about') or ''), ('picture', entry.get('picture') or (self.songs[0]['picture'] if self.songs else '')),
                           ('font', font)):
            self.setProperty('music.hero.' + key, value)
        self._list()
        self.setProperty('music.empty', '' if self.songs else 'No songs here.')
        self.setFocusId(600)

    def _list(self):
        self.playing = xbmcgui.Window(10000).getProperty(PLAYING)
        control = self.getControl(600)
        position = control.getSelectedPosition()
        control.reset()
        control.addItems([_song_line(s, n, self.playing) for n, s in enumerate(self.songs, 1)])
        if position > 0:
            control.selectItem(min(position, len(self.songs) - 1))
        self.setProperty('music.tracks', '1' if self.songs else '')

    def tick(self):
        try:
            entry, songs = self.answers.get_nowait()
            self._show(entry, songs)
        except queue.Empty:
            pass
        if self.songs and xbmcgui.Window(10000).getProperty(PLAYING) != self.playing:
            self._list()        # the play mark moves with the music

    def onClick(self, control_id):
        if control_id == 600:
            # from there on; its buttons open by the profile - a playlist goes round, an album goes on with like songs
            play(self.songs, self.getControl(600).getSelectedPosition(), round_=(self.entry or {}).get('kind') == 'playlist')

    def onAction(self, action):
        if action.getId() in BACK:
            return self.close()
        if action.getId() in CONTEXT and self.getFocusId() == 600:
            pos = self.getControl(600).getSelectedPosition()
            if 0 <= pos < len(self.songs):
                options(self.songs[pos])


def open_page(entry):
    """An album's or a playlist's page."""
    window = MusicPage(PAGE, xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i', entry=entry)
    try:
        window.doModal()
    finally:
        window._release()
        del window


# ---- the small player by the profile ----------------------------------------------------------------
class Seeking:
    """A player's seek bar (its slider SEEK_BAR): it follows the song; Left / Right on it move its mark only,
    and the song goes there SEEK_REST seconds after the last press - one jump, the screen never held up."""
    SEEK_BAR = 0
    SEEK_REST = .8
    moved = None

    def seek_action(self, action):
        if action.getId() in (1, 2) and self.getFocusId() == self.SEEK_BAR:
            self.moved = time.monotonic()

    def seek_tick(self):
        try:
            bar, player = self.getControl(self.SEEK_BAR), xbmc.Player()
            total = player.getTotalTime() if player.isPlaying() else 0
        except Exception:
            return
        if not total:
            return
        if self.moved is not None:
            if time.monotonic() - self.moved >= self.SEEK_REST:
                player.seekTime(total * bar.getPercent() / 100.0)
                self.moved = None
            return
        bar.setPercent(100.0 * player.getTime() / total)


class MusicMini(Seeking, Dialog):
    """The small player by the music in the corner (meganexus_music_mini.xml): Previous / Play-Pause / Next
    and Stop (14: the music off); a song a film took the player from goes on with its Play (resume()). It goes with Back and by itself when the music has stopped - and, opened
    by a song starting (``auto``), after AUTO_HIDE seconds without a key, as the player's OSD does: open, it
    holds the cursor, and Kodi opens no other screen meanwhile (going to the HUB was refused)."""
    AUTO_HIDE = 6.0
    SEEK_BAR = 15

    def onClick(self, control_id):
        self.touched = time.monotonic()
        if control_id == 12 and not xbmc.getCondVisibility(MUSIC_ON) and resume():
            self.close()                       # the song a film took the player from, from where it was
        elif control_id == 14:
            stop_music()
            for name in (music_watch.RESUME, music_watch.RESUME + '.title', music_watch.RESUME + '.artist'):
                xbmcgui.Window(10000).clearProperty(name)
            self.close()

    def onAction(self, action):
        self.touched = time.monotonic()
        self.seek_action(action)
        if action.getId() in BACK:
            self.close()

    def tick(self):
        waiting = xbmcgui.Window(10000).getProperty(music_watch.RESUME)     # paused for a film: it stays to go on
        if not (xbmc.getCondVisibility(MUSIC_ON) or waiting) or (self.auto and time.monotonic() - self.touched > self.AUTO_HIDE):
            return self.close()
        if not waiting:
            self.seek_tick()


def open_mini(auto=False):
    window = MusicMini(MINI, xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i')
    window.auto, window.touched = auto, time.monotonic()
    try:
        window.doModal()
    finally:
        window._release()
        del window


class MusicNow(Seeking, Dialog):
    """Now playing (meganexus_music_now.xml): what plays, big - a place to seek on, Shuffle / Previous /
    Play-Pause / Next / Repeat and Stop. Opened with a song still being found it waits for it; it closes
    with Back, and by itself once nothing has played for GRACE seconds."""
    GRACE = 15.0
    SEEK_BAR = 710

    def onClick(self, control_id):
        if control_id == 705:
            stop_music()
            self.close()

    def onAction(self, action):
        self.seek_action(action)
        if action.getId() in BACK:
            self.close()

    def tick(self):
        if xbmc.getCondVisibility(MUSIC_ON) or xbmcgui.Window(10000).getProperty(LOADING):
            self.heard = time.monotonic()
        elif time.monotonic() - self.heard > self.GRACE:
            return self.close()
        self.seek_tick()


def open_now():
    window = MusicNow(NOW, xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(), '1080i')
    window.heard = time.monotonic()
    try:
        window.doModal()
    finally:
        window._release()
        del window


# ---- the app ----------------------------------------------------------------------------------------
def choose_artists():
    """The artists you like, from the most played in the United States, the world, Europe, Asia and the Balkans
    (music.REGIONS) - Home is made of them. A part of the world opens its artists with yours already ticked;
    what you tick or untick is kept at once, so going in and out of the parts never loses a choice. The first
    time by itself; Settings > Music > Artists you follow, and the menu key on any artist, later."""
    from .play_jobs import ring_job
    dialog, found = xbmcgui.Dialog(), {}
    while True:
        mine = {a['id'] for a in music.follows()}
        rows = []
        for index, (name, *_) in enumerate(music.REGIONS):
            chosen = len([a for a in found.get(index, []) if a['id'] in mine])
            rows.append('%s%s' % (name, '  ·  %d chosen' % chosen if chosen else ''))
        pick = dialog.select('Music · the artists you like (%d chosen)' % len(mine), rows + ['Done'])
        if pick < 0 or pick == len(rows):
            return
        if pick not in found:
            try:
                found[pick] = ring_job(lambda: music.region_artists(pick)) or []
            except Exception:
                found[pick] = []
        artists = found[pick]
        if not artists:
            dialog.notification('Music', '%s has no chart to choose from now.' % music.REGIONS[pick][0], time=3500)
            continue
        ticked = dialog.multiselect('Music · %s' % music.REGIONS[pick][0], [a['title'] for a in artists],
                                    preselect=[n for n, a in enumerate(artists) if a['id'] in mine])
        if ticked is None:
            continue                                          # Back: nothing changed in this part
        for n, artist in enumerate(artists):
            if (n in ticked) != (artist['id'] in mine):
                music.follow(artist, n in ticked)


def open_music():
    monitor = xbmc.Monitor()
    if not music.follows() and not music.history():
        choose_artists()
    view, query, pending = HOME, '', ''
    try:
        while not monitor.abortRequested():
            window = MusicWindow(XML, ADDON.getAddonInfo('path'), theme_folder(), '1080i', shelves=shelves(view, query), bucket=view)
            window._music_query = query
            window.setProperty('meganexus.app', 'music')   # before it shows: never MegaNexus' wordmark first
            cover = None
            try:
                screen_guard.hold()
                window.show_ready()
                from .trailers import lift_curtain
                lift_curtain()
                while not window._closed and not window._leaving and not monitor.abortRequested():
                    window.drain_updates()
                    monitor.waitForAbort(.05)
                pending, view, query = window._pending, window._bucket or HOME, getattr(window, '_music_query', '')
            finally:
                if getattr(window, '_pending', None) == 'hub':
                    # the HUB first, under the app - nothing flashes between them
                    try:
                        from .play_jobs import wait_overlay
                        cover = wait_overlay('', {})
                    except Exception:
                        cover = None
                    xbmc.executebuiltin('ActivateWindow(Home)')
                    for _ in range(20):
                        if xbmc.getCondVisibility('Window.IsActive(Home)') or monitor.waitForAbort(.025):
                            break
                    monitor.waitForAbort(HUB_SETTLE_PLAIN)
                window._finish()
                window._release()
                screen_guard.release()
                if cover is not None:
                    cover.close()
            if pending and pending != 'hub':
                from .system_setup import execute_command
                execute_command(pending)
            break
    finally:
        if not pending:
            xbmc.executebuiltin('ActivateWindow(Home)')
