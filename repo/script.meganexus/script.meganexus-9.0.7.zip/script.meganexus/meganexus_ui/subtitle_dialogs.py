# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import xbmc
import xbmcgui
from resources.lib import meganexus_subtitles
from resources.lib.meganexus import keyed_cache
from .system_setup import rpc
from .play_jobs import job,plain_label

def pick(rows,playerid,context,request_id,enabled=False):
    groups=meganexus_subtitles.group_rows(rows)
    langs=sorted(groups,key=lambda x:(x!='hr',meganexus_subtitles.NAMES.get(x,x)))
    if not langs and not enabled:
        # 7.0.50: a TV channel has only what it sends (subtitle tracks, teletext) - nothing to search
        live=xbmc.getCondVisibility('VideoPlayer.Content(LiveTV)') or xbmc.getCondVisibility('PVR.IsPlayingTV')
        xbmc.log('[MegaNexus] Subtitles: none in this %s'%('channel' if live else 'video'),xbmc.LOGINFO)
        xbmcgui.Dialog().ok('Subtitles','This channel sends no subtitles right now.' if live else
                            'No subtitle files were returned. Try searching your subtitle add-ons.');return
    dialog=xbmcgui.Dialog()
    off=['Subtitles off'] if enabled else []
    index=dialog.select('Subtitle language',off+[meganexus_subtitles.NAMES.get(l,l)+' · '+str(len(groups[l]))+' versions' for l in langs])
    if index<0:return
    if off:
        if index==0:
            xbmc.Player().showSubtitles(False);return
        index-=1
    candidates=groups[langs[index]];labels=[]
    title=meganexus_subtitles.NAMES.get(langs[index],langs[index])
    for i,row in enumerate(candidates):
        release=plain_label(row.get('displayName') or row.get('name') or row.get('release') or row.get('filename')) or 'Version '+str(i+1)
        source=plain_label(row.get('sourceName') or ('Embedded track' if row.get('embedded') else 'Subtitle provider'))
        labels.append('%d. %s — %s'%(i+1,release,source))
    player=xbmc.Player()
    while True:
        index=dialog.select(title,labels)
        if index<0:return
        row=candidates[index]
        if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
        if row.get('embedded'):
            rpc('Player.SetSubtitle',{'playerid':playerid,'subtitle':row['index'],'enable':True})
            meganexus_subtitles.remember_active('')   # the video's own track: nothing to sync
            return
        try:path=job(lambda:meganexus_subtitles.prepare_selected(row,context.get('video_id') or context.get('canonical_id') or 'selected'),label='Loading the subtitle…',quiet=True)
        except ValueError:
            # 7.0.29: its server did not deliver it - the list comes back for another version
            xbmcgui.Dialog().notification('Subtitles','This version could not be downloaded - choose another.',time=3500)
            labels[index]='✕ '+labels[index].lstrip('✕ ')
            continue
        if not path:return
        break
    # Downloads can finish after a channel/title switch. Never apply to another video.
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    player.setSubtitles(path);player.showSubtitles(True)
    meganexus_subtitles.remember_active(path,row)

def run():
    try:
        active=next((p for p in rpc('Player.GetActivePlayers') or [] if p['type']=='video'),None)
        if not active:return
        playerid=active['playerid'];player=xbmc.Player();request_id=player.getPlayingItem().getProperty('meganexus.request')
        xbmcgui.Window(10000).setProperty('meganexus.subtitle.manual',request_id)
        key=xbmcgui.Window(10000).getProperty('meganexus.subtitle.context')
        context=keyed_cache.get('meganexus_play',key) or {}
        if context.get('meganexus_request_id')!=request_id:context={}
        props=rpc('Player.GetProperties',{'playerid':playerid,'properties':['subtitles','subtitleenabled']}) or {}
        embedded=[dict(s,embedded=True,sourceName='Embedded track',lang=s.get('language')) for s in props.get('subtitles') or []]
        if context:
            # 9.0.0: the list opens at once and fills as the add-ons answer (as the source list);
            # it waited for the slowest add-on - 15 s for one that did not answer at all
            live_pick(embedded,playerid,context,request_id,enabled=props.get('subtitleenabled'))
            return
        pick(embedded,playerid,context,request_id,enabled=props.get('subtitleenabled'))   # not started through MegaNexus: the video's own tracks
    except Exception as exc:
        xbmcgui.Dialog().ok('Subtitles',str(exc) if isinstance(exc,ValueError) else 'Subtitle selection could not finish. Try another file or provider.')


# ---- 9.0.0: the subtitle list that fills while the add-ons answer -----------------------
EMBEDDED_KEY,OWN_NAME='embedded','Embedded'
FLAGS='special://home/addons/skin.meganexus/media/windows/subtitles/flags/%s.png'


# the regional variants add-ons send as codes of their own - kept apart, by their full name
VARIANTS={}
for _codes,_variant in ((('pob','pt-br','ptbr','pb'),('pt-br','Portuguese (Brazil)')),
                        (('zht','zh-tw','zh-hant','zh-hk'),('zh-tw','Chinese (Traditional)')),
                        (('zhs','zh-cn','zh-hans'),('zh-cn','Chinese (Simplified)')),
                        (('spn','es-419','es-la','es-mx','ea'),('es-419','Spanish (Latin America)'))):
    for _code in _codes:VARIANTS[_code]=_variant


def language_of(row):
    """(key, full name) of a subtitle's language - "Croatian", not "hr": Kodi's English name
    for the code; "Unknown language" when the add-on did not say."""
    for field in ('_lang_raw','lang','language','languageCode'):
        raw=str(row.get(field) or '').strip().lower().replace('_','-')
        if raw in VARIANTS:return VARIANTS[raw]
    code=meganexus_subtitles.language(row.get('lang'))
    if not code or code=='und':return ('und','Unknown language')
    name=meganexus_subtitles.NAMES.get(code) or meganexus_subtitles.language_name(code)
    return (code,name if name and name.lower()!=code else code.upper())


def _subtitle_list_class():
    from .play_jobs import Sources

    class SubtitleList(Sources):
        """The source list's window and add-on row, for subtitles: each add-on (and the
        video's own tracks) a tab with its count, "searching..." or "nothing found"; on the
        right the languages, the one from Settings first and chosen when the list opens."""
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.lang=language_of({'lang':meganexus_subtitles.preferred()})[0]
            self.langs=[];self._lang_order=[self.lang];self.lang_moved=False

        def _item(self,i,row):
            from . import listitems
            if row.get('_off'):
                item=listitems.item(label='Subtitles off',label2='')
                item.setProperty('line2','No subtitles on screen');item.setProperty('line3','')
                return item
            code,name=language_of(row)
            release=plain_label(row.get('displayName') or row.get('name') or row.get('release') or row.get('filename') or row.get('label') or '')
            item=listitems.item(label=release or name,label2='')
            where='Embedded in the video' if row.get('embedded') else 'From '+(plain_label(row.get('sourceName') or '') or 'a subtitle add-on')
            notes=[name,where]
            from resources.lib.video_hash import matched
            if matched(row):notes.append('made for this file')
            if row.get('isforced') or row.get('forced'):notes.append('forced')
            item.setProperty('line2','  ·  '.join(notes));item.setProperty('line3','')
            if code!='und':item.setProperty('badge0.img',FLAGS%code.split('-')[0])
            return item

        @staticmethod
        def _key(row):
            if row.get('_off'):return ('off',)
            if row.get('embedded'):return ('embedded',row.get('index'))
            return (str(row.get('sourceName') or ''),str(row.get('url') or row.get('id') or ''),meganexus_subtitles.language(row.get('lang')))

        def _wanted(self,row):
            if row.get('_off'):return True          # "Subtitles off" under every language
            return Sources._wanted(self,row) and (self.lang is None or language_of(row)[0]==self.lang)

        def _tab_list(self):
            shown,self.rows=self.rows,[row for row in self.rows if not row.get('_off')]
            try:return Sources._tab_list(self)
            finally:self.rows=shown

        # ---- the languages, from the top down: Settings' first, the rest as they come ----
        def _lang_list(self):
            counts={};names={}
            for row in self.rows:
                if row.get('_off'):continue
                key,name=language_of(row);counts[key]=counts.get(key,0)+1;names[key]=name
            for key in counts:
                if key not in self._lang_order:self._lang_order.append(key)
            done=(getattr(self,'feed',None) or {}).get('done',True)
            langs=[]
            for key in self._lang_order:
                name=names.get(key) or language_of({'lang':key})[1]
                count=counts.get(key,0)
                langs.append((key,'%s · %d'%(name,count) if count else '%s · %s'%(name,'none found' if done else 'searching…')))
            total=sum(counts.values())
            return langs+[(None,'All languages · %d'%total)]

        def _show_langs(self):
            langs=self._lang_list();control=self.getControl(700)
            if [key for key,_ in langs]!=[key for key,_ in self.langs]:
                # a new language: in above "All languages"; the cursor stays on its language
                at=control.getSelectedPosition()
                held=self.langs[at][0] if 0<=at<len(self.langs) else self.lang
                control.reset();control.addItems([listitems_item(label) for _,label in langs])
                control.selectItem(next((n for n,(key,_) in enumerate(langs) if key==held),0))
            else:
                for index,(was,now) in enumerate(zip(self.langs,langs)):
                    if was[1]!=now[1]:control.getListItem(index).setLabel(now[1])
            self.langs=langs
            for index,(key,_) in enumerate(langs):
                control.getListItem(index).setProperty('current','1' if key==self.lang else '')

        def _show_tabs(self):
            Sources._show_tabs(self)
            self._show_langs()
            self._settle()

        def _settle(self):
            """Settings' language found nothing when every add-on has answered: the list
            moves to the language that has the most, unless the languages were touched."""
            feed=getattr(self,'feed',None) or {}
            if self.lang_moved or not feed.get('done',True) or any(not self.rows[i].get('_off') for i in self.visible):return
            counts={}
            for row in self.rows:
                if not row.get('_off'):key=language_of(row)[0];counts[key]=counts.get(key,0)+1
            if not counts:return
            self.lang=max(counts,key=lambda key:(key=='en',counts[key]));self.lang_moved=True
            self._fill();self._show_langs()
            at=next((n for n,(key,_) in enumerate(self.langs) if key==self.lang),0)
            self.getControl(700).selectItem(at)

        def onInit(self):
            self.langs=[]
            Sources.onInit(self)

        def tick(self):
            Sources.tick(self)
            if not self.ready or self.closed or self.getFocusId()!=700:return
            pos=self.getControl(700).getSelectedPosition()
            if 0<=pos<len(self.langs) and self.langs[pos][0]!=self.lang:
                self.lang=self.langs[pos][0];self.lang_moved=True
                self._fill();self._show_langs()

        def onClick(self,cid):
            if cid==700:self.setFocusId(500)
            else:Sources.onClick(self,cid)
    return SubtitleList


def listitems_item(label):
    from . import listitems
    return listitems.item(label=label)


def _tagged(row,embedded=False):
    """A subtitle row with the add-on it comes from, as the source list groups by it."""
    if embedded:row['_meganexus_source']={'id':EMBEDDED_KEY,'name':OWN_NAME}
    else:
        name=plain_label(row.get('sourceName') or '') or 'Subtitle add-on'
        row['_meganexus_source']={'id':name,'name':name}
    return row


def _preferred_first(rows):
    wanted=meganexus_subtitles.language(meganexus_subtitles.preferred())
    return sorted(rows,key=lambda row:(meganexus_subtitles.language(row.get('lang'))!=wanted,
                                       meganexus_subtitles.language(row.get('lang'))!='en'))


def live_pick(embedded,playerid,context,request_id,enabled=False):
    import threading,time
    from resources.lib import subtitle_search
    from .play_jobs import ROOT,source_header
    from resources.lib.theme import folder
    rows=([{'_off':True,'_meganexus_source':{'id':'off','name':'Off'}}] if enabled else [])+[_tagged(dict(r),True) for r in embedded]
    try:asked=[plain_label(a.get('name') or a.get('id') or '') for a in subtitle_search.addons_for(context)]
    except Exception:asked=[]
    feed={'rows':list(rows),'version':0,'done':False,'pending':set(asked),
          'addons':([(EMBEDDED_KEY,OWN_NAME)] if embedded else [])+[(name,name) for name in asked if name]}
    seen=set()
    def take(found):
        fresh=[]
        for raw in found or ():
            row=subtitle_search.as_subtitle(raw)   # as the finished search gives them (url, lang, name)
            if not row:continue
            mark=(str(row.get('sourceName') or ''),str(row.get('url') or row.get('id') or ''),str(row.get('lang') or ''))
            if mark in seen:continue
            given=[raw.get(field) for field in ('lang','language','languageCode')] if isinstance(raw,dict) else []
            variant=next((str(v).strip().lower().replace('_','-') for v in given+[row.get('lang')]
                          if str(v or '').strip().lower().replace('_','-') in VARIANTS),'')
            seen.add(mark);fresh.append(_tagged(dict(row,lang=meganexus_subtitles.language(row.get('lang')),_lang_raw=variant)))
        if fresh:
            feed['rows']=feed['rows']+_preferred_first(fresh);feed['version']+=1
            for row in fresh:feed['pending'].discard(plain_label(row.get('sourceName') or ''))
        return False                    # never "enough": every add-on gets its answer in
    def search():
        try:take(meganexus_subtitles.external_rows(context,search=True,enough=take))
        except Exception as exc:xbmc.log('[MegaNexus] Subtitle list search failed: %s'%exc,xbmc.LOGWARNING)
        finally:feed['done']=True;feed['pending']=set();feed['version']+=1
    threading.Thread(target=search,name='MegaNexusSubtitleList',daemon=True).start()
    try:header=dict(source_header({'name':context.get('show_title') or context.get('title') or '',
                                   'background':context.get('background') or '','logo':context.get('clearlogo') or ''},context),standalone='1')
    except Exception:header={}
    # the film waits while the list is open and goes on as soon as it closes (unless it was
    # paused already), as when the source is switched
    player=xbmc.Player();paused_here=False
    try:
        if player.isPlayingVideo() and not xbmc.getCondVisibility('Player.Paused'):player.pause();paused_here=True
    except Exception:pass
    win=_subtitle_list_class()('meganexus_subtitles.xml',ROOT,folder(),'1080i',rows=list(feed['rows']),header=header,feed=feed)
    choice=None
    try:
        win.show();monitor=xbmc.Monitor();version=-1;ended=False;asked_at=0.0;focused=False
        while not win.closed and not monitor.abortRequested():
            monitor.waitForAbort(.05)
            win.tick()
            if win.ready and (feed['version']!=version or feed['done']!=ended):
                version=feed['version'];ended=feed['done']
                win.update_rows(feed['rows'],'' if feed['done'] else 'Searching subtitle add-ons…')
            if win.ready and not focused:
                asked_at=asked_at or time.monotonic()
                try:held=win.getFocusId()
                except Exception:held=0
                if held in (500,600,610,611,700) or time.monotonic()-asked_at>2:focused=True
                else:win.setFocusId(500)
        if 0<=win.choice<len(win.rows):choice=win.rows[win.choice]
    finally:
        win.close()
        if paused_here and xbmc.getCondVisibility('Player.Paused'):player.pause()
    if choice is None:return
    _apply_choice(choice,playerid,context,request_id)


def _apply_choice(row,playerid,context,request_id):
    """The chosen line of the list: off, the video's own track, or a subtitle to download."""
    player=xbmc.Player()
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    if row.get('_off'):
        player.showSubtitles(False);return
    if row.get('embedded'):
        rpc('Player.SetSubtitle',{'playerid':playerid,'subtitle':row['index'],'enable':True})
        meganexus_subtitles.remember_active('');return
    try:path=job(lambda:meganexus_subtitles.prepare_selected(row,context.get('video_id') or context.get('canonical_id') or 'selected'),label='Loading the subtitle…',quiet=True)
    except ValueError:
        xbmcgui.Dialog().notification('Subtitles','This version could not be downloaded - choose another.',time=3500);return
    if not path:return
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    player.setSubtitles(path);player.showSubtitles(True)
    meganexus_subtitles.remember_active(path,row)


SYNC_TRIES='meganexus.subtitle.sync_tries'   # Window(Home): {request, attempt, tried} of this playback
SYNC_LABELS={1:'Syncing subtitles…',2:'Syncing subtitles · a closer look…',3:'Syncing subtitles · another subtitle…'}


def autosync():
    """7.0.29: the player's Autosync subtitle button - retime the subtitle on screen."""
    player=xbmc.Player()
    if not player.isPlayingVideo():return
    request_id=player.getPlayingItem().getProperty('meganexus.request')
    key=xbmcgui.Window(10000).getProperty('meganexus.subtitle.context')
    context=keyed_cache.get('meganexus_play',key) or {}
    if context.get('meganexus_request_id')!=request_id:context={}
    if not context:
        xbmcgui.Dialog().notification('Autosync subtitle','Works on titles started in MegaNexus.',time=4000);return
    try:duration=float(player.getTotalTime() or 0)   # 7.0.45: the film's length tells its version and a subtitle that fits
    except Exception:duration=0
    import json
    home=xbmcgui.Window(10000)
    # 7.0.50: each press on this film goes further (more subtitles, piece by piece, then another
    # subtitle in your language) - the count and the subtitles tried belong to this playback
    try:tries=json.loads(home.getProperty(SYNC_TRIES) or '{}')
    except ValueError:tries={}
    if tries.get('request')!=request_id:tries={'request':request_id,'attempt':0,'tried':[]}
    tries['attempt']=attempt=int(tries.get('attempt') or 0)+1
    label=SYNC_LABELS.get(attempt,SYNC_LABELS[3])
    home.setProperty('meganexus.subtitle.syncing',label)   # 7.0.45: the player's pill
    try:
        try:result=job(lambda:meganexus_subtitles.autosync(context,context.get('video_id') or context.get('canonical_id') or 'sync',
                                                           duration=duration,attempt=attempt,tried=tries['tried']),label=label,quiet=True)
        except ValueError as exc:   # 7.0.45: told in passing, the film plays on - no dialog to close
            home.setProperty(SYNC_TRIES,json.dumps(tries))
            xbmc.log('[MegaNexus] Autosync subtitle (press %d): %s'%(attempt,exc),xbmc.LOGINFO)   # 7.0.50: why, in the log
            xbmcgui.Dialog().notification('Autosync subtitle',str(exc),time=8000);return
    finally:
        home.clearProperty('meganexus.subtitle.syncing')
    if result and len(result)>2 and isinstance(result[2],dict) and result[2].get('url'):
        tries['tried'].append(str(result[2]['url']))
    home.setProperty(SYNC_TRIES,json.dumps(tries))
    if not result:return
    path,what=result[:2]
    xbmc.log('[MegaNexus] Autosync subtitle (press %d): %s'%(attempt,what),xbmc.LOGINFO)
    if len(result)>2:   # 7.0.45: another subtitle in your language, one that belongs to this film
        home.setProperty('meganexus.subtitle.row',json.dumps(result[2]))
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    if not what.startswith('Already in sync'):
        player.setSubtitles(path);player.showSubtitles(True)
        home.setProperty('meganexus.subtitle.path',path)
    xbmcgui.Dialog().notification('Autosync subtitle',what,time=5000)
    # 7.0.45: kept with the film while it is in Continue Watching - not synced again next time
    try:row=result[2] if len(result)>2 else json.loads(home.getProperty('meganexus.subtitle.row') or '{}')
    except ValueError:row={}
    try:meganexus_subtitles.keep_synced(context,path,row)
    except Exception as exc:xbmc.log('[MegaNexus] kept subtitle not saved: %s'%exc,xbmc.LOGINFO)


AI_WORKING='meganexus.ai.working'   # Window(Home): the playback being translated, and how far


def ai_translate():
    """8.1.3: the player's AI button - the subtitles of this film in your language, by Gemini,
    in the background; put on the moment they are ready (never synced afterwards)."""
    import json
    from resources.lib import ai_subtitles, gemini_api
    player=xbmc.Player()
    if not player.isPlayingVideo():return
    home=xbmcgui.Window(10000)
    title='AI subtitles'
    request_id=player.getPlayingItem().getProperty('meganexus.request')
    context=keyed_cache.get('meganexus_play',home.getProperty('meganexus.subtitle.context')) or {}
    if context.get('meganexus_request_id')!=request_id:context={}
    if not context:
        xbmcgui.Dialog().notification(title,'Works on titles started in MegaNexus.',time=4000);return
    work=ai_subtitles.key_of(context,meganexus_subtitles.language(context.get('meganexus_subtitle_language') or meganexus_subtitles.preferred()))
    if home.getProperty(AI_WORKING).startswith(work+'|'):   # this title, also after a restart
        xbmcgui.Dialog().notification(title,'Already translating - %s'%home.getProperty(AI_WORKING).split('|',1)[1],time=4000);return
    if not gemini_api.configured():
        xbmcgui.Dialog().notification(title,'Add your free Gemini API key in HUB Settings > API keys.',time=6000);return
    target=meganexus_subtitles.language(context.get('meganexus_subtitle_language') or meganexus_subtitles.preferred())
    name=meganexus_subtitles.language_name(target)
    def same(other):
        keys=('canonical_id','season','episode')
        return bool(other) and all(str(other.get(k) or '')==str(context.get(k) or '') for k in keys)

    def current():
        # 8.1.3: the same film or episode, also when it was stopped and started again
        # (the translation goes on and goes on screen there) - not one particular start
        try:
            if not player.isPlayingVideo():return False
            if player.getPlayingItem().getProperty('meganexus.request')==request_id:return True
            return same(keyed_cache.get('meganexus_play',home.getProperty('meganexus.subtitle.context')) or {})
        except Exception:return False

    def put_on(path,row):
        # 8.1.3: no Autosync afterwards - the translation keeps its source's timing, and
        # the source is the video's own subtitle, made for this very release. ("nemoj
        # praviti sync na kraj"). The player's Sync button is there for a subtitle from online.
        if not current():return
        player.setSubtitles(path);player.showSubtitles(True)
        meganexus_subtitles.remember_active(path,row)
        try:meganexus_subtitles.keep_synced(context,path,row)
        except Exception:pass

    log=lambda text:xbmc.log('[MegaNexus] AI subtitles: '+text,xbmc.LOGINFO)
    log('asked for %s'%target)
    # 1. the video itself carries your language - its own track, text or picture, never one
    # added from online: that one, no AI. It is the best there is ("embedded za naš jezik =
    # bez prijevoda"). 9.0.5: the video says which tracks are its own (ai_subtitles.own_track) -
    # Kodi's list took the translation itself for the video's Croatian track.
    try:
        reply=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Player.GetProperties',
                                                         'params':{'playerid':1,'properties':['subtitles']}})))
        own=ai_subtitles.own_track(context,target,(reply.get('result') or {}).get('subtitles') or [])
    except Exception:own=None
    if own:
        player.setSubtitleStream(int(own['index']));player.showSubtitles(True)
        log('the video has %s - its own track switched on'%target)
        xbmcgui.Dialog().notification(title,'%s is in the video already - switched on.'%name,time=4000);return
    # 2. translated before for this film and source: at once
    kept=ai_subtitles.kept(context,target)
    if kept:
        log('translated before - put on')
        put_on(kept,{'lang':target,'sourceName':'MegaNexus AI'})
        xbmcgui.Dialog().notification(title,'%s subtitles on.'%name,time=3000);return
    home.setProperty(AI_WORKING,work+'|starting');home.setProperty('meganexus.ai.status','starting')
    xbmcgui.Dialog().notification(title,'Translating into %s in the background - they switch on when ready.'%name,time=5000)
    # it stops only with Kodi: stopped or not, the translation is finished and kept, so the
    # next time this title plays it goes on at once
    stopped=lambda:xbmc.Monitor().abortRequested()
    said=[0]

    def progress(done,total):
        percent=int(done*100/max(1,total))
        home.setProperty(AI_WORKING,'%s|%d%%'%(work,percent))
        home.setProperty('meganexus.ai.status','translating %d%%'%percent)   # the line under the player's buttons
        home.setProperty('meganexus.ai.ring','%02d'%max(1,min(20,percent//5)))   # the ring round the AI button
        log('%d of %d requests done'%(done,total))
        if percent>=said[0]+34 and percent<100:   # a word now and then, never a stream of them
            said[0]=percent
            xbmcgui.Dialog().notification(title,'%s · %d%%'%(name,percent),time=2500)
    try:
        home.setProperty('meganexus.ai.status','reading the subtitles')
        found=ai_subtitles.from_video(context,target,stopped=stopped)   # 8.1.3: read only now - not when a kept one goes on
        log('source: the video\'s own subtitles (%d lines, %s)'%(len(found[0]),found[1]) if found else 'source: not in the video')
        online=False
        if not found:
            path=home.getProperty('meganexus.subtitle.path')
            try:row=json.loads(home.getProperty('meganexus.subtitle.row') or '{}')
            except ValueError:row={}
            cues=ai_subtitles.from_file(path) if path and meganexus_subtitles.language(row.get('lang'))!=target else []
            if len(cues)>=30:found=(cues,meganexus_subtitles.language(row.get('lang')) or 'en')
            else:
                online=ai_subtitles.from_online(context,target)
                if online:found,row=online[:2],online[2]
            online=True
            # 8.1.5: a subtitle from online lined up first (once, only when clearly off) - the
            # translation then comes timed right and is kept so
            if found:
                try:length=float(player.getTotalTime() or 0) if current() else 0.0
                except Exception:length=0.0
                try:moved=meganexus_subtitles.quiet_shift(context,found[0],row,length)
                except Exception as exc:
                    moved=None;log('the source not lined up (%s)'%exc)
                if moved:
                    from resources.lib import subtitle_sync
                    found=(subtitle_sync.retime(found[0],moved[0],moved[1]),found[1])
                    log('the source lined up first: %s by %s'%(subtitle_sync.describe(moved[0],moved[1]),moved[2]))
        if not found:
            if context.get('meganexus_video_subtitles')=='pictures':
                raise ai_subtitles.Failed('The video\'s subtitles are pictures, not text, and none were found online to translate.')
            raise ai_subtitles.Failed('No subtitles to translate were found for this video.')
        cues,source=found
        # 9.0.5: no [sound effects] - a line that was only that goes, each other keeps its time
        sounds=len(cues);cues=ai_subtitles.without_sounds(cues);sounds-=len(cues)
        if len(cues)<30:raise ai_subtitles.Failed('No subtitles to translate were found for this video.')
        log('translating %d lines from %s (%s)%s'%(len(cues),source,'from online' if online else 'the video\'s own',
                                                   ', %d sound descriptions left out'%sounds if sounds else ''))
        # 8.1.5: from where you are watching, and on screen as it comes - every 5 %
        try:now=float(player.getTime() or 0) if current() else 0.0
        except Exception:now=0.0
        def partial(done):
            if not current():return
            lines=[(s,e,done[i]) for i,(s,e,_) in enumerate(cues) if i in done]
            path=ai_subtitles.keep(context,target,lines,partial=True)
            player.setSubtitles(path);player.showSubtitles(True)
            log('%d of %d lines on screen so far'%(len(lines),len(cues)))
        translated=ai_subtitles.translate(cues,meganexus_subtitles.language_name(source) or 'English',name,
                                          context=context,progress=progress,stopped=stopped,start_at=now,partial=partial)
        # 9.0.5: from the video's lines read only part of the way: on now, not kept as finished
        short=bool(context.pop('meganexus_video_lines_short',False)) and not online
        if context.pop('meganexus_translation_short',False):   # 9.0.5: lines Gemini could not do yet
            short=True
        path=ai_subtitles.keep(context,target,translated,partial=short,any_stream=online)   # online: for every source of the title
        if short:log('not complete yet - kept unfinished, the next press completes it')
        put_on(path,{'lang':target,'sourceName':'MegaNexus AI'})
        log('done - %d lines on'%len(translated))
        if current():xbmcgui.Dialog().notification(title,'%s subtitles on.'%name,time=4000)
        else:log('kept for the next time this title plays')
    except ai_subtitles.Failed as exc:
        if current():xbmcgui.Dialog().notification(title,str(exc),time=7000)
        xbmc.log('[MegaNexus] AI subtitles: %s'%exc,xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] AI subtitles failed: %r'%exc,xbmc.LOGWARNING)
        if current():xbmcgui.Dialog().notification(title,'The translation did not work this time.',time=6000)
    finally:
        home.clearProperty(AI_WORKING);home.clearProperty('meganexus.ai.status');home.clearProperty('meganexus.ai.ring')
