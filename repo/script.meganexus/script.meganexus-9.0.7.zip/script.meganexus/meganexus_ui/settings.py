# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""HUB Settings: accounts, add-ons and presentation preferences."""
import xbmc
import xbmcaddon
import time
import xbmcgui
import xbmcvfs
from resources.lib import settings_snapshot, collection_profile
from resources.lib.meganexus import addon_registry
from resources.lib.setup_wizard import add_manifest
from .system_setup import rpc,ensure_addon
from . import settings_page as page
from resources.lib.theme import folder as theme_folder

ADDON=settings_snapshot.cached_addon()

def select_provider(role):
    # Compatibility entry point for the existing wizard and collection editor.
    return metadata_addons() if role == 'metadata' else stream_addons()


def catalog_choice_summary():
    from resources.lib import default_setup
    lists, now = default_setup.options(), default_setup.chosen(ADDON)
    return '%s · %s' % (dict(lists['languages']).get(now['language'], now['language']), dict(lists['regions']).get(now['region'], now['region']))


def choose_catalog_language():
    """9.0.4: the MegaNexus Catalog Addon's language, then its region - the add-on's own lists."""
    from resources.lib import default_setup
    from .play_jobs import job
    dialog, lists, now = xbmcgui.Dialog(), default_setup.options(), default_setup.chosen(ADDON)
    picked = {}
    for key, title in (('language', 'Language of titles and plots'), ('region', 'Region of the catalogs')):
        rows = lists[key + 's']
        pick = dialog.select(title, ['%s · %s' % (name, code) for code, name in rows],
                             preselect=next((i for i, (code, _) in enumerate(rows) if code == now[key]), 0))
        if pick < 0:
            return
        picked[key] = rows[pick][0]
    if picked == now:
        return
    try:job(lambda: default_setup.choose(picked['language'], picked['region']), label='MegaNexus Catalog')
    except Exception:dialog.ok('MegaNexus Catalog', 'The catalog for this choice could not be reached now. Check the connection and retry.')


def metadata_addons():
    from resources.lib import metadata_providers, default_setup
    try:default_setup.replace_cinemeta()   # 9.0.4: also when Settings come before Home's entry
    except (ValueError, OSError):pass
    def builtin_missing():
        return default_setup.builtin_provider(addon_registry.list_providers()) is None
    def rows():
        entries = metadata_providers.entries()
        result = [page.item(p.get('name') or p['id'],
                            'Built-in · no setup' if (p.get('manifest') or {}).get('id') == default_setup.CATALOG_ID
                            else 'Metadata and compatible catalogs', enabled=on)
                  for p, on in entries]
        if builtin_missing():
            result.append(page.item('MegaNexus Catalog Addon · built-in, no setup', 'Add'))
        # 9.0.4: its titles, plots and catalogs in this language, its lists for this region
        result.append(page.item('MegaNexus Catalog · language & region', catalog_choice_summary()))
        return result + [page.item('Add metadata manifest URL'), page.item('Back')]
    def choose(pick):
        entries = metadata_providers.entries()
        extra = 1 if builtin_missing() else 0
        if pick < len(entries):
            provider, on = entries[pick]
            metadata_providers.set_enabled(provider['id'], not on)
            if (provider.get('manifest') or {}).get('id') == default_setup.CATALOG_ID:
                # A manual choice: never switched back automatically.
                ADDON.setSetting(default_setup.BUILTIN_AUTO, '' if not on else 'off')
        elif extra and pick == len(entries):
            from .play_jobs import job
            try:job(default_setup.install_builtin, label='Adding the MegaNexus Catalog')
            except Exception:xbmcgui.Dialog().ok('MegaNexus Catalog','It could not be added now. Check the connection and retry.')
            ADDON.setSetting(default_setup.BUILTIN_AUTO, '')
        elif pick == len(entries) + extra:
            choose_catalog_language()
        elif pick == len(entries) + extra + 1:
            before = {p['id'] for p in addon_registry.list_providers()}
            if add_manifest(xbmcgui.Dialog()):
                start_on({p['id'] for p in addon_registry.list_providers()} - before)
        else:
            return page.DONE
    return page.show('Metadata add-ons · enable each provider', rows, choose)


def start_on(provider_ids):
    """Newly added add-ons start ON in what they offer - their metadata and streams used at once (as from
    the phone); Home keeps its one layout, your collections."""
    from resources.lib import stream_providers, metadata_providers
    for provider in addon_registry.list_providers():
        if provider.get('id') not in provider_ids:
            continue
        if any(p['id'] == provider['id'] for p in metadata_providers.candidates()):
            metadata_providers.set_enabled(provider['id'], True)
        if any(p['id'] == provider['id'] for p in stream_providers.candidates()):
            stream_providers.set_enabled(provider['id'], True)


def stream_addons():
    from resources.lib import stream_providers
    def rows():
        providers=stream_providers.entries()
        return [page.item(p.get('name') or p['id'], 'Stream results', enabled=on)
                for p,on in providers]+[page.item('Add stream add-on manifest URL'),page.item('Back')]
    def choose(pick):
        providers=stream_providers.entries()
        if pick<len(providers):
            provider,on=providers[pick]
            stream_providers.set_enabled(provider['id'],not on)
        elif pick==len(providers):
            before={p['id'] for p in stream_providers.candidates()}
            if add_manifest(xbmcgui.Dialog()):
                for p in stream_providers.candidates():
                    if p['id'] not in before:stream_providers.set_enabled(p['id'],True)
        else:return page.DONE
    return page.show('Stream add-ons · enable each provider',rows,choose)


DIM='[COLOR 59FFFFFF]%s[/COLOR]'
ROLES=(('streams','Streams'),('metadata','Metadata'),('subtitles','Subtitles'),('sport','Sport'))


def _role_modules():
    from resources.lib import stream_providers, metadata_providers, subtitle_providers, sport_providers
    return {'streams':stream_providers,'metadata':metadata_providers,'subtitles':subtitle_providers,'sport':sport_providers}


def _roles_of(provider):
    """{role: None (not offered) | True | False} for one add-on."""
    result={}
    for role,module in _role_modules().items():
        switches={p['id']:on for p,on in module.entries()}
        result[role]=switches.get(provider['id']) if provider['id'] in switches else None
    return result


def addon_roles(provider_id):
    """7.0.17: what one add-on is used for - streams, metadata, subtitles and
    (7.0.20) the Sport screen - each switched on its own. A role the add-on's
    manifest does not offer is dimmed (AIOStreams may serve all three,
    AIOMetadata only metadata and its sport catalogs, a subtitle add-on only
    subtitles)."""
    def provider():
        return next((p for p in addon_registry.list_providers() if p.get('id')==provider_id),None)
    def build():
        p=provider()
        if not p:return []
        roles=_roles_of(p)
        rows=[]
        for role,label in ROLES:
            if roles.get(role) is None:
                rows.append((role,page.item(DIM%label,DIM%'Not offered by this add-on')))
            else:
                rows.append((role,page.item(label,enabled=roles.get(role))))
        return rows
    def act(role):
        p=provider()
        if not p:return page.DONE
        on=_roles_of(p).get(role)
        if on is None:return None
        _role_modules()[role].set_enabled(provider_id,not on)
        settings_snapshot.invalidate()
        return None
    p=provider()
    return _keyed((p or {}).get('name') or provider_id,build,act)


def your_addons():
    """Every add-on with what it is used for (7.0.17)."""
    def summary(p):
        roles=_roles_of(p)
        parts=[label for role,label in ROLES if roles.get(role)]
        return ' · '.join(parts) if parts else 'Not used'
    def build():
        return [(p['id'],page.item(p.get('name') or p['id'],summary(p))) for p in addon_registry.list_providers() if p.get('id')]
    def act(provider_id):
        return addon_roles(provider_id)
    return _keyed('Your add-ons · streams, metadata, subtitles, sport',build,act)


ROLE_PAGES={'subtitles':('Subtitle add-ons · enable each provider','Subtitles','Add-ons that offer subtitles (OpenSubtitles, AIOStreams...) appear here.'),
            'sport':('Sport add-ons · shown in the Sport screen','Sport catalogs','Add-ons with sport catalogs (sports add-ons, AIOMetadata sport catalogs) appear here.')}


def role_addons(role):
    """7.0.20: every add-on offering subtitles or sport, switched on its own
    (the same switches as the add-on's own page)."""
    title,detail,empty=ROLE_PAGES[role]
    module=_role_modules()[role]
    def build():
        rows=[(p['id'],page.item(p.get('name') or p['id'],detail,enabled=on)) for p,on in module.entries()]
        return rows or [('none',page.item(empty))]
    def act(provider_id):
        if provider_id=='none':return None
        on=dict((p['id'],on) for p,on in module.entries()).get(provider_id)
        if on is not None:module.set_enabled(provider_id,not on)
        settings_snapshot.invalidate()
        return None
    return _keyed(title,build,act)


def _role_count(role):
    try:rows=_role_modules()[role].entries()
    except Exception:return ''
    return '%d / %d on'%(sum(1 for _,on in rows if on),len(rows))


def _add_and_choose_roles(dialog):
    """Add a manifest, then choose what it is used for (7.0.17)."""
    before={p.get('id') for p in addon_registry.list_providers()}
    if not add_manifest(dialog):return False
    added={p.get('id') for p in addon_registry.list_providers()}-before
    start_on(added)       # 9.0.6: ON in what it offers - it is used at once; switched off on its page
    for p in addon_registry.list_providers():
        if p.get('id') in added:addon_roles(p['id'])
    return True


def addons():
    """Add-ons (translucent page, 7.0): which add-ons are used, adding and importing them."""
    from resources.lib import stream_providers, metadata_providers
    dialog=xbmcgui.Dialog()
    def build():
        metadata=metadata_providers.entries();providers=stream_providers.entries()
        return [('yours',page.item('Your add-ons · streams, metadata, subtitles, sport','%d add-ons'%len(addon_registry.list_providers()))),
                ('meta',page.item('Metadata add-ons','%d / %d on'%(sum(1 for _,on in metadata if on),len(metadata)))),
                ('streams',page.item('Stream add-ons','%d / %d on'%(sum(1 for _,on in providers if on),len(providers)))),
                ('subtitles',page.item('Subtitle add-ons',_role_count('subtitles'))),
                ('sport',page.item('Sport add-ons',_role_count('sport'))),
                ('add',page.item('Add a configured add-on link')),
                ('nuvio',page.item('Import add-ons from Nuvio',nuvio_status())),
                ('stremio',page.item('Import add-ons from Stremio')),
                ('remove',page.item('Remove an add-on')),
                ('refresh',page.item('Refresh add-on catalogs now'))]
    def act(key):
        if key=='yours':return your_addons()
        if key=='meta':select_provider('metadata')
        elif key=='streams':stream_addons()
        elif key in ('subtitles','sport'):return role_addons(key)
        elif key=='add':_add_and_choose_roles(dialog)
        elif key=='nuvio':sync_nuvio()
        elif key=='stremio':
            from .keys_backup import stremio
            stremio()
        elif key=='refresh':
            # 6.0.36: catalogs added in an add-on's configuration (e.g. streaming
            # services in AIOMetadata / Xperience) appear without re-adding it.
            from resources.lib import manifest_refresh
            from .play_jobs import job
            changed=job(manifest_refresh.refresh_all,label='Reading the add-ons\' catalogs')
            if changed is not None:
                dialog.ok('Add-ons','Updated: %s.'%', '.join(changed) if changed else 'All add-ons were already up to date.')
        elif key=='remove':
            providers=addon_registry.list_providers()
            i=dialog.select('Remove an add-on',[p.get('name') or p['id'] for p in providers])
            if i>=0 and dialog.yesno('Remove an add-on','Remove this add-on from MegaNexus?'):
                addon_registry.remove_provider(providers[i]['id'])
                for role in ('metadata','streams'):
                    if ADDON.getSetting('meganexus_'+role+'_provider')==providers[i]['id']:ADDON.setSetting('meganexus_'+role+'_provider','')
        settings_snapshot.invalidate()
        return None
    return _keyed('Add-ons',build,act)


def sync_nuvio():
    from resources.lib.meganexus import cloud_sync as sync
    from .play_jobs import job
    if not sync.NuvioCloud.is_linked():xbmcgui.Dialog().ok('Nuvio account','Sign in to Nuvio in Account first.');return
    if not sync.NuvioCloud.token().get('profile_index') and not choose_nuvio_profile():return False
    from resources.lib import nuvio_import
    result=job(nuvio_import.fetch,label='Importing Nuvio - '+nuvio_status())
    if result is None:return False
    report=nuvio_import.apply(result)
    settings_snapshot.invalidate()
    message='%d add-ons saved. Home layout kept. Import and validate your collections in Settings > Collections before browsing.'%report['providers']
    if not report['providers']:message+=' No add-ons imported; check your selected profile.'
    if report['errors']:message+='\n'+'\n'.join(dict.fromkeys(report['errors']))
    xbmcgui.Dialog().ok('Nuvio import - '+nuvio_status(),message)
    return bool(report['providers'] or report['collections']) and not report['errors']


def nuvio_status():
    from resources.lib.meganexus import cloud_sync as sync
    token=sync.NuvioCloud.token()
    if not token.get('access_token'):return 'Not connected'
    return 'Connected / '+str(token.get('profile_name') or ('Profile '+str(token['profile_index']) if token.get('profile_index') else 'Choose profile'))


def choose_nuvio_profile():
    from resources.lib.meganexus import cloud_sync as sync
    from .play_jobs import job
    profiles=job(sync.NuvioCloud.profiles,label='Loading Nuvio profiles')
    if not profiles:return False
    pick=0 if len(profiles)==1 else xbmcgui.Dialog().select('Choose the Nuvio profile with your collections',[p['profile_name'] for p in profiles])
    if pick<0:return False
    sync.NuvioCloud.select_profile(profiles[pick])
    return True

def sign_in_nuvio():
    from resources.lib.meganexus import cloud_sync as sync
    dialog=xbmcgui.Dialog()
    email=dialog.input('Nuvio email').strip()
    if not email:return False
    password=dialog.input('Nuvio password',option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not password:return False
    from .play_jobs import job
    try:token=job(lambda:sync.NuvioCloud.authenticate(email,password),label='Signing in to Nuvio')
    except Exception:token=None
    if not token:
        dialog.ok('Nuvio account','Sign-in did not complete. Check your account and connection, or skip and connect later.')
        return False
    sync.NuvioCloud.save_token(token)
    sync.NuvioCloud.remember(email,password)   # 8.1.5: signed in again by itself when Nuvio ends the session
    ADDON.setSetting('nuvio_sync_enabled','true')
    settings_snapshot.invalidate()
    if not choose_nuvio_profile():return False
    import_from_nuvio()  # 6.0.25: connecting imports everything; no extra steps
    return True


def import_from_nuvio():
    """Connected account: add-ons, progress and the profile's collections, with
    the metadata add-ons those collections use switched ON, so Home loads at once.
    A Home layout the user made is replaced only after a yes."""
    from resources.lib import nuvio_import
    from .play_jobs import job
    dialog=xbmcgui.Dialog()
    collections=True
    if nuvio_import.layout_is_users_own():
        collections=dialog.yesno('Nuvio account','Replace your current Home layout with the collections of your Nuvio profile?')
    result=job(lambda:nuvio_import.fetch(collections=collections),label='Importing your Nuvio add-ons and collections')
    if result is None:return False
    report=nuvio_import.apply(result)
    settings_snapshot.invalidate()
    try:
        from .browse_meta import clear
        clear()
    except Exception:pass
    lines=['%d add-ons imported.'%report['providers']]
    if report.get('collections'):lines.append('%d collections are on Home.'%report['collections'])
    if report.get('metadata_on'):lines.append('Metadata switched ON: '+', '.join(report['metadata_on'])+'.')
    if report['errors']:lines.append('\n'.join(dict.fromkeys(report['errors'])))
    dialog.ok('Nuvio account - '+nuvio_status(),'\n'.join(lines))
    return bool(report['providers'] or report.get('collections')) and not report['errors']


def accounts():
    from resources.lib.meganexus import cloud_sync as sync
    def rows():return [page.item('Sign in',nuvio_status()),page.item('Sign in with phone · QR code'),page.item('Sync add-ons and progress','Keep Home layout'),page.item('Sign out'),page.item('Choose Nuvio profile',sync.NuvioCloud.token().get('profile_name') or ''),page.item('Nuvio sync · Continue Watching and Library', _nuvio_sync_label()),page.item('Back')]
    def choose(pick):
        if pick==0:sign_in_nuvio()
        elif pick==1:phone_setup()
        elif pick==2:sync_nuvio()
        elif pick==3:sync.NuvioCloud.clear();ADDON.setSetting('nuvio_sync_enabled','false')
        elif pick==4:choose_nuvio_profile()
        elif pick==5:progress_settings()
        elif pick==6:return page.DONE
    return page.show('Nuvio account',rows,choose)

def _nuvio_sync_label():
    parts=[name for name,key in (('Continue Watching','nuvio_sync_progress'),('Library','nuvio_sync_library')) if ADDON.getSetting(key)!='false']
    return (' + '.join(parts)+' · '+(ADDON.getSetting('nuvio_progress_interval') or '60')+' s') if parts else 'Off'


def progress_settings():
    """7.0.44: automatic Nuvio sync - Continue Watching and the Library (Nuvio's
    watchlist / saved titles), each switchable; both ways by default: added or
    removed on any Nuvio app or here, the same everywhere."""
    dialog=xbmcgui.Dialog()
    def build():return [('progress',page.item('Auto-sync Continue Watching',enabled=ADDON.getSetting('nuvio_sync_progress')!='false')),
                        ('library',page.item('Auto-sync Library · Nuvio watchlist',enabled=ADDON.getSetting('nuvio_sync_library')!='false')),
                        ('interval',page.item('Refresh interval (Nuvio + Simkl)',(ADDON.getSetting('nuvio_progress_interval') or '60')+' seconds')),
                        ('direction',page.item('Nuvio sync direction',ADDON.getSetting('nuvio_sync_direction') or 'Two-way')),
                        ('now',page.item('Sync now'))]
    def act(key):
        if key in ('progress','library'):
            setting='nuvio_sync_'+key
            ADDON.setSetting(setting,'false' if ADDON.getSetting(setting)!='false' else 'true')
            if ADDON.getSetting(setting)=='true':ADDON.setSetting('nuvio_sync_enabled','true')
        elif key=='now':
            from resources.lib.meganexus import cloud_sync as sync
            from .play_jobs import job
            result=job(lambda:sync.sync_round(targets=['nuvio']),label='Syncing with Nuvio')
            ok=bool((result or {}).get('ok'))
            xbmcgui.Dialog().notification('Nuvio sync','Done' if ok else 'Could not sync - check the Nuvio account',time=3000)
        elif key=='interval':
            values=['30','60','120','300']
            current=ADDON.getSetting('nuvio_progress_interval') or '60'
            selected=dialog.select('Refresh in seconds · retries respect server limits', values, preselect=values.index(current) if current in values else 1)
            if selected>=0:ADDON.setSetting('nuvio_progress_interval',values[selected])
        else:
            values=['Two-way','Upload only','Download only']
            current=ADDON.getSetting('nuvio_sync_direction') or 'Two-way'
            selected=dialog.select('Nuvio progress direction',values,preselect=values.index(current) if current in values else 0)
            if selected>=0:ADDON.setSetting('nuvio_sync_direction',values[selected])
        settings_snapshot.invalidate()
        return None
    return _keyed('Nuvio sync',build,act)


def collections():
    from .collection_editor import run
    return run()


def import_nuvio_collections():
    from resources.lib.meganexus import cloud_sync as sync
    from .play_jobs import job
    dialog=xbmcgui.Dialog()
    if not sync.NuvioCloud.is_linked():dialog.ok('Collections','Connect a Nuvio account first.');return False
    if not sync.NuvioCloud.token().get('profile_index') and not choose_nuvio_profile():return False
    if not dialog.yesno('Import collection layout','Replace Home collection titles, pictures and order with the selected Nuvio profile? Sports stay in the Sport screen.'):return False
    data=job(lambda:sync.NuvioCloud.cloud_collections([],direction='pull'),label='Importing collection layout')
    if data is None:return False
    return commit_collections(data)


def _switch_on_collection_addons(groups, dialog):
    """Collections reference catalogs of metadata add-ons that are OFF: ask once."""
    from resources.lib import collection_validation, metadata_providers
    from resources.lib.collections_home import matching_catalog
    providers = addon_registry.list_providers()
    switches = {p['id']: on for p, on in metadata_providers.entries(providers)}
    off = {}
    for _, source in collection_validation.sources(groups):
        match = matching_catalog(source, providers)
        if match and switches.get(match[0]['id']) is False:
            off[match[0]['id']] = match[0].get('name') or match[0]['id']
    if not off:
        return False
    if not dialog.yesno('Collections', 'These collections use add-ons that are OFF under Metadata add-ons:\n'
                        + ', '.join(off.values()) + '\nTurn them ON?'):
        return False
    for provider_id in off:
        metadata_providers.set_enabled(provider_id, True)
    settings_snapshot.invalidate()
    return True


def commit_collections(data, force=False):
    """Save the Home layout at once - no network check, nothing blocks (6.0.15).

    ``force`` additionally runs the catalog check and shows its report; an
    unavailable catalog is only reported, never a reason to refuse the layout.
    """
    dialog = xbmcgui.Dialog()
    groups = collection_profile.normalize(data)
    _switch_on_collection_addons(groups, dialog)
    count = collection_profile.save(groups)
    if force:
        from resources.lib import collection_validation
        from .play_jobs import job
        import threading
        cancel = threading.Event()
        proof = job(lambda: collection_validation.validate(groups, stopped=cancel.is_set),
                    label='Checking collection catalogs', cancel=cancel)
        if proof is not None:
            collection_profile.save(groups, validation=proof)
            dialog.ok('Collection check', collection_validation.message(proof))
    else:
        dialog.notification('Collections', '%d collections saved' % count)
    return True


START_INFO='meganexus_start_info'


def toggle(key):ADDON.setSetting(key,'false' if ADDON.getSetting(key)=='true' else 'true')
def onoff(key):return 'On' if ADDON.getSetting(key)=='true' else 'Off'

def _watched_percent_value():
    value=(ADDON.getSetting('meganexus_watched_percent') or '90').strip()
    return value.split('.')[0] or '90'


def _watched_percent_summary():
    return '%s %%' % _watched_percent_value()


def playback():
    dialog=xbmcgui.Dialog()
    def rows():return [page.item('Autoplay the best stream',enabled=ADDON.getSetting('meganexus_autoplay')=='true'),
        # 7.0.32: AIOStreams' rules - a film only in cinemas, an episode not aired yet
        page.item('Digital releases only · no cinema copies',enabled=ADDON.getSetting('meganexus_digital_release_filter')=='true'),
        page.item(LAST_LINK_TITLE,last_link_summary()),
        page.item('Automatic stream choice',_stream_choice_summary()),
        page.item('Intro, credits & next episode',_skip_summary()),
        # 7.0.45: also a video of Kodi's own (Videos, a file) stops when its player is left
        page.item('Back stops a video · also videos started in Kodi',enabled=ADDON.getSetting('meganexus_back_stops_video')!='false'),
        # 8.1.2 (GitHub #23): ninety per cent of a long episode still has five minutes to run
        page.item('Counts as watched at',_watched_percent_summary()),
        # 9.0.4: the display's mode, the age rating and the parents guide as a film starts
        page.item('Age rating & content warnings at the start',enabled=ADDON.getSetting(START_INFO)!='false'),
        page.item('Back')]
    def choose(pick):
        if pick==0:toggle('meganexus_autoplay')
        elif pick==1:toggle('meganexus_digital_release_filter')
        elif pick==2:choose_last_link()
        elif pick==3:return stream_choice_page()
        elif pick==4:return skip_settings()
        elif pick==5:
            ADDON.setSetting('meganexus_back_stops_video','false' if ADDON.getSetting('meganexus_back_stops_video')!='false' else 'true')
            settings_snapshot.invalidate()
        elif pick==6:
            choices=[('80','80 %'),('85','85 %'),('90','90 % · as the Nuvio apps'),('95','95 %'),('98','98 % · the credits')]
            now=_watched_percent_value()
            pick_one=dialog.select('Counts as watched at',[label for _,label in choices],
                                   preselect=next((i for i,(value,_) in enumerate(choices) if value==now),2))
            if pick_one>=0:
                ADDON.setSetting('meganexus_watched_percent',choices[pick_one][0]);settings_snapshot.invalidate()
        elif pick==7:
            ADDON.setSetting(START_INFO,'false' if ADDON.getSetting(START_INFO)!='false' else 'true')
            settings_snapshot.invalidate()
        elif pick==8:return page.DONE
    return page.show('Playback',rows,choose)


SKIP_MODES=(('Button','Show the Skip button'),('Automatic','Skip automatically'),('Off','Off'))


def _skip_summary():
    from resources.lib import skip_segments as seg
    mode=dict(SKIP_MODES).get(ADDON.getSetting('meganexus_skip_mode') or 'Button','Show the Skip button')
    return mode+(' · next episode 1:30 before the end' if seg.upnext_on(ADDON) else '')


def skip_settings():
    """7.0.29: intro / recap / credits from TheIntroDB, the media server's markers and
    the file's chapters; "Next episode" beside "Skip outro" at the credits - and, with
    no known credits, 1 min 30 s before the end (7.0.42)."""
    from resources.lib import skip_segments as seg
    def build():
        mode=ADDON.getSetting('meganexus_skip_mode') or 'Button'
        return [('mode',page.item('Intro, recap and credits',dict(SKIP_MODES).get(mode,'Show the Skip button'))),
                ('outro',page.item('Skip outro at the credits',enabled=seg.outro_on(ADDON))),   # 7.0.50: on its own; 8.1.4: on
                ('upnext',page.item('Next episode 1:30 before the end (no credits known)',enabled=seg.upnext_on(ADDON))),
                ('watched',page.item('An episode counts as watched at','%d %% · also for Simkl'%seg.watched_percent(ADDON))),
                ('chapters',page.item("Use the file's chapters (Intro, Credits)",enabled=seg.chapters_on(ADDON))),
                ('sources',page.item('Where the times come from','TheIntroDB · SkipDB · servers'))]
    def act(key):
        if key=='mode':
            rows=[(value,page.item(label,'Chosen' if value==(ADDON.getSetting('meganexus_skip_mode') or 'Button') else '')) for value,label in SKIP_MODES]
            def pick(value):ADDON.setSetting('meganexus_skip_mode',value);return page.DONE
            return page.keyed('Intro, recap and credits',lambda:rows,pick)
        if key=='upnext':ADDON.setSetting(seg.UPNEXT,'off' if seg.upnext_on(ADDON) else 'watched')
        elif key=='chapters':ADDON.setSetting(seg.CHAPTERS,'false' if seg.chapters_on(ADDON) else 'true')
        elif key=='outro':ADDON.setSetting(seg.OUTRO,'false' if seg.outro_on(ADDON) else 'true')
        elif key=='watched':
            rows=[(value,page.item(value+' %','Chosen' if int(value)==int(seg.watched_percent(ADDON)) else '')) for value in seg.WATCHED_CHOICES]
            def pick(value):ADDON.setSetting(seg.WATCHED,value);return page.DONE
            return page.keyed('An episode counts as watched at',lambda:rows,pick)
        elif key=='sources':api_keys()
        settings_snapshot.invalidate()
        return None
    return _keyed('Intro, credits & next episode',build,act)


# 7.0.29: where people look for it (Playback), and in Continue Watching too.
LAST_LINK_TITLE='Continue Watching · start with the last link'


def last_link_summary():
    from resources.lib import last_source
    hours=str(last_source.hours(ADDON))
    return 'Off · choose again' if hours=='0' else '%s · with or without choosing a source'%last_source.LABELS[hours]


def choose_last_link():
    """A title started from Continue Watching plays the link it played last time
    (with or without choosing a source) for 12 or 24 hours; then, or when the link
    fails, the usual source choice or autoplay."""
    from resources.lib import last_source
    keys=last_source.HOURS;value=str(last_source.hours(ADDON))
    labels={'0':'Off · always choose again','12':'12 hours','24':'24 hours'}
    pick=xbmcgui.Dialog().select(LAST_LINK_TITLE,[labels[k] for k in keys],preselect=keys.index(value))
    if pick>=0:ADDON.setSetting(last_source.SETTING,keys[pick]);settings_snapshot.invalidate()


def _gb_label(value,unit='movie'):
    return 'No limit' if value in ('','0') else ('Up to %s GB'%value)


def _stream_choice_summary():
    from resources.lib import stream_choice as sc
    prefs=sc.preferences(ADDON)
    if not prefs['sort']:return 'Add-on order'
    parts=[sc.RES_LABELS.get(ADDON.getSetting(sc.MAX_RES) or '4k','Up to 4K')]
    if prefs['movie_gb']:parts.append('films ≤ %g GB'%prefs['movie_gb'])
    if prefs['episode_gb']:parts.append('episodes ≤ %g GB'%prefs['episode_gb'])
    return ' · '.join(parts)


AUDIO_SETTING='locale.audiolanguage'


def _audio_languages():
    """Kodi's own audio language choices: [(value, label)], its current value."""
    data=rpc('Settings.GetSettings',{'level':'expert','filter':{'section':'player','category':'language'}}) or {}
    setting=next((row for row in data.get('settings') or [] if row.get('id')==AUDIO_SETTING),{})
    options=[(str(row.get('value')),str(row.get('label') or row.get('value'))) for row in setting.get('options') or []]
    return options,str(setting.get('value') or '')


def _audio_label():
    try:
        options,current=_audio_languages()
    except Exception:
        return ''
    return dict(options).get(current,current)


def _choose_audio_language(dialog):
    """7.0.21: the preferred audio language is Kodi's own (Settings > Player >
    Language): Kodi picks that track when the video opens - no switch once it
    plays. The choice is made here, with Kodi's list."""
    try:options,current=_audio_languages()
    except Exception:options,current=[],''
    if not options:
        dialog.ok('Preferred audio language','Kodi did not return its audio languages. Please try again.');return
    values=[value for value,_ in options]
    i=dialog.select('Preferred audio language',[label for _,label in options],preselect=values.index(current) if current in values else 0)
    if i>=0:
        rpc('Settings.SetSettingValue',{'setting':AUDIO_SETTING,'value':values[i]})
        # "Prefer default stream" would keep a file's default (often original)
        # track over the chosen language; Media default keeps Kodi's behaviour.
        if values[i]!='mediadefault':rpc('Settings.SetSettingValue',{'setting':'videoplayer.preferdefaultflag','value':False})
        from resources.lib.kodi_keep import keep
        keep()


def stream_choice_page():
    """Automatic stream choice (7.0.12): the order of the source list and the
    stream Autoplay starts - resolution, size per film / episode, Dolby Vision,
    HDR and cached debrid results. Rows outside the limits move down, never away."""
    from resources.lib import stream_choice as sc
    dialog=xbmcgui.Dialog()
    def pick(title,setting,choices,labels,default):
        current=ADDON.getSetting(setting) or default
        i=dialog.select(title,[labels(c) for c in choices],preselect=choices.index(current) if current in choices else 0)
        if i>=0:ADDON.setSetting(setting,choices[i]);settings_snapshot.invalidate()
    def build():
        prefs=sc.preferences(ADDON)
        rows=[('sort',page.item('Choose the best stream for me',enabled=prefs['sort'])),
              ('audio',page.item('Preferred audio language',_audio_label()))]
        if prefs['sort']:
            rows+=[('res',page.item('Highest resolution',sc.RES_LABELS.get(ADDON.getSetting(sc.MAX_RES) or '4k','Up to 4K'))),
                   ('movie',page.item('Largest film',_gb_label(ADDON.getSetting(sc.MOVIE_GB) or '0'))),
                   ('episode',page.item('Largest episode',_gb_label(ADDON.getSetting(sc.EPISODE_GB) or '0'))),
                   ('dv',page.item('Dolby Vision',sc.DV_LABELS.get(prefs['dv'],'No preference'))),
                   ('hdr',page.item('HDR',sc.HDR_LABELS.get(prefs['hdr'],'Prefer HDR'))),
                   ('cached',page.item('Debrid: cached (instant) results first',enabled=prefs['cached'])),
                   ('groups',page.item('Release groups: TRaSH Guides tiers',enabled=prefs['groups'])),
                   ('net',page.item('No limit: fit the network speed (80 %)',_net_label(prefs),
                                    enabled=ADDON.getSetting('stream_bandwidth_auto')!='false'))]
        return rows
    def act(key):
        if key=='sort':ADDON.setSetting(sc.SORT,'false' if sc.preferences(ADDON)['sort'] else 'true')
        elif key=='res':pick('Highest resolution',sc.MAX_RES,sc.RES_CHOICES,lambda c:sc.RES_LABELS[c],'4k')
        elif key in ('movie','episode'):
            setting=sc.MOVIE_GB if key=='movie' else sc.EPISODE_GB
            pick('Largest film' if key=='movie' else 'Largest episode',setting,
                 sc.MOVIE_GB_CHOICES if key=='movie' else sc.EPISODE_GB_CHOICES,_gb_label,'0')
            # 7.0.42: a size limit of your own replaces "fit the network speed"
            if (ADDON.getSetting(setting) or '0')!='0':ADDON.setSetting('stream_bandwidth_auto','false')
        elif key=='dv':pick('Dolby Vision',sc.DOLBY_VISION,sc.DV_CHOICES,lambda c:sc.DV_LABELS[c],'neutral')
        elif key=='hdr':pick('HDR',sc.HDR,sc.HDR_CHOICES,lambda c:sc.HDR_LABELS[c],'prefer')
        elif key=='cached':ADDON.setSetting(sc.CACHED,'false' if sc.preferences(ADDON)['cached'] else 'true')
        elif key=='groups':ADDON.setSetting(sc.GROUPS,'false' if sc.preferences(ADDON)['groups'] else 'true')   # 7.0.43
        elif key=='audio':_choose_audio_language(dialog)
        elif key=='net':
            on=ADDON.getSetting('stream_bandwidth_auto')=='false'
            ADDON.setSetting('stream_bandwidth_auto','true' if on else 'false')
            if on:   # 7.0.42: fitting the network means no size limit of its own
                ADDON.setSetting(sc.MOVIE_GB,'0');ADDON.setSetting(sc.EPISODE_GB,'0')
        settings_snapshot.invalidate()
        return None
    return _keyed('Automatic stream choice',build,act)


def _net_label(prefs):
    """7.0.42: the measured speed and what a stream may use of it."""
    if ADDON.getSetting('stream_bandwidth_auto')=='false':return 'Off'
    if not prefs.get('mbps'):return 'Measured within an hour, while nothing plays'
    return '%.0f Mbit/s measured · streams up to %.0f Mbit/s'%(prefs['mbps'],prefs['mbps']*.8)


def sport_settings():
    """Sport screen (6.0.35). 7.0.48: no player choice - OK plays in the small video,
    OK again in Kodi's full-screen player (as IPTV)."""
    from . import sports
    def rows():return [page.item('Play live events after resting 5 seconds',enabled=sports.autoplay_enabled()),
        page.item('Back')]
    def choose(pick):
        if pick==0:ADDON.setSetting(sports.AUTOPLAY_SETTING,'false' if sports.autoplay_enabled() else 'true')
        elif pick==1:return page.DONE
        settings_snapshot.invalidate()
    return page.show('Sport',rows,choose)


def youtube_settings():
    """9.0.6: the HUB's YouTube app - its videos play through Kodi's YouTube add-on (quality,
    sign-in and its own keys are set there)."""
    from resources.lib import youtube
    def rows():
        mine=youtube.my_channels()
        return [page.item('Autoplay · the next video by itself',enabled=ADDON.getSetting(youtube.AUTONEXT)=='true'),
            page.item('Steady playback · 360p, seeking works',enabled=youtube.steady()),
            page.item('Your channels',str(len(mine)) if mine else 'None yet'),
            page.item('YouTube add-on · quality, sign-in','Configure' if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)') else 'Install'),
            page.item('Back')]
    def choose(pick):
        if pick==0:toggle(youtube.AUTONEXT)
        elif pick==1:
            # the YouTube add-on's own MPEG-DASH setting (off: the one stream YouTube still serves whole)
            if ensure_addon('plugin.video.youtube'):youtube.steady(not youtube.steady())
        elif pick==2:
            mine=youtube.my_channels()
            if not mine:
                xbmcgui.Dialog().ok('YouTube','Add a channel in the YouTube app: Channels › Add channel.')
                return
            i=xbmcgui.Dialog().select('Remove a channel',[c.get('name') or c['id'] for c in mine])
            if i>=0:youtube.remove_channel(mine[i]['id'])
        elif pick==3:
            if ensure_addon('plugin.video.youtube'):xbmcaddon.Addon('plugin.video.youtube').openSettings()
        elif pick==4:return page.DONE
    return page.show('YouTube',rows,choose)


def music_settings():
    """9.0.6: the HUB's Music app - where its songs play from (your sources, in their order: Eclipse
    music add-ons by their install link - the phone page has the same; YouTube; your debrid cloud with
    the keys of API keys), the catalogue it shows and searches, your Deezer, your music folders."""
    from resources.lib import music,music_cloud
    dialog=xbmcgui.Dialog()
    def build():
        rows=[('add',page.item('Add a music source','With phone (QR) or install link'))]
        rows+=[(('source',s['manifest'].get('id')),page.item(s['manifest'].get('name',''),'%s · %s'%('On' if s.get('on',True) else 'Off',music.host(s))))
               for s in music.sources()]
        cloud=', '.join(music_cloud.debrid.SERVICES[s]['name'] for s in music_cloud.services())
        rows+=[('import',page.item('Import a playlist','A link or a CSV / M3U file')),
               ('artists',page.item('Artists you follow',str(len(music.follows())) if music.follows() else 'Choose them')),
               ('youtube',page.item('YouTube · when no source has a song',enabled=music.youtube_on())),
               ('cloud',page.item('Your debrid cloud',cloud or 'A TorBox or Real-Debrid key in API keys')),
               ('order',page.item('Songs play from',' › '.join(dict(music.PLACES)[k].replace('Your ','') for k in music.order()))),
               ('catalogue',page.item('Catalogues',' › '.join(dict(music.CATALOGUES)[k] for k in music.catalogues()))),
               ('deezer',page.item('Deezer profile',('Linked · %s'%music.deezer_profile()) if music.deezer_profile() else 'Your public playlists')),
               ('folder',page.item('Add a music folder','On this device or the network'))]
        rows+=[(('folders',f),page.item(f.rstrip('/').rsplit('/',1)[-1] or f,'Your folder · select to remove')) for f in music.folders()]
        return rows
    def act(key):
        if key=='add':return _music_source_add(music,dialog)
        if isinstance(key,tuple) and key[0]=='source':
            found=next((s for s in music.sources() if s['manifest'].get('id')==key[1]),None)
            return _music_source(music,dialog,found) if found else None
        if key=='import':return _music_import(dialog)
        if key=='artists':
            mine=music.follows()
            if not mine:
                from .music import choose_artists
                return choose_artists()
            pick=dialog.select('Artists you follow',['Choose more artists']+[a['title'] for a in mine])
            if pick==0:
                from .music import choose_artists
                choose_artists()
            elif pick>0 and dialog.yesno('Music','Stop following %s?'%mine[pick-1]['title']):music.follow(mine[pick-1],False)
            return
        if key=='youtube':
            if not xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
                return dialog.ok('YouTube','Kodi\'s YouTube add-on is not installed - the YouTube app on the HUB installs it.')
            ADDON.setSetting(music.YOUTUBE_SETTING,'false' if music.youtube_on() else 'true');music.forget()
        elif key=='cloud':
            dialog.ok('Your debrid cloud','The music already in your TorBox or Real-Debrid account shows in the app (Library, Home) '
                      'and plays a song no source has. Its key: Settings > API keys > Debrid.')
        elif key=='order':
            # as the films' sources: the one chosen goes first, the others keep their order after it
            now=music.order()
            i=dialog.select('Songs play from - first',[dict(music.PLACES)[k] for k in now])
            if i>=0:music.order(value=[now[i]]+[k for k in now if k!=now[i]])
        elif key=='catalogue':
            keys=[k for k,_ in music.CATALOGUES]
            now=music.catalogues()+[k for k in keys if k not in music.catalogues()]
            i=dialog.select('Catalogues - first',[dict(music.CATALOGUES)[k]+(' · needs your Spotify app (API keys)' if k=='spotify' else '') for k in now])
            if i>=0:
                try:music.catalogue(value=now[i])
                except music.MusicError as exc:dialog.ok('Catalogues',music.safe(exc))
        elif key=='deezer':
            typed=dialog.input('Your Deezer profile - its address (deezer.com/profile/…) or number; empty: unlink',music.deezer_profile()).strip()
            try:music.deezer_profile(value=typed)
            except music.MusicError as exc:dialog.ok('Deezer profile',music.safe(exc))
        elif key=='folder':
            path=dialog.browse(0,'Music folder','files')
            if path:music.set_folders(music.folders()+[path])
        elif isinstance(key,tuple) and key[0]=='folders':
            if dialog.yesno('Music','Remove this folder from the app?[CR]%s'%key[1]):music.set_folders([f for f in music.folders() if f!=key[1]])
    return page.keyed('Music',build,act)


def _music_import(dialog):
    """9.0.6: a playlist of Spotify, Deezer or YouTube by its link, or a CSV / M3U file (Spotify's whole
    library through Exportify, any service through TuneMyMusic or Soundiiz) - on the Music app's Home."""
    from resources.lib import music,music_import
    how=dialog.select('Import a playlist',['Its link · Spotify, Deezer, YouTube','A file · CSV or M3U'])
    if how<0:return
    try:
        if how==0:
            link=dialog.input('Link of the playlist').strip()
            if not link:return
            from .play_jobs import ring_job
            added=ring_job(lambda:music_import.from_link(link))
        else:
            path=dialog.browse(1,'Playlist file','files','.csv|.m3u|.m3u8')
            if not path:return
            added=music_import.from_file(path)
    except music.MusicError as exc:
        return dialog.ok('Import a playlist',music.safe(exc))
    dialog.notification('Music','%s · %d songs on Home'%(added['title'],added['count']),time=3500)


def _music_source_add(music,dialog):
    if dialog.yesno('Add a music source','Set the add-on up on its own page and copy its install link (it ends with manifest.json). '
                    'Paste it on your phone, or type it here?',nolabel='Type it',yeslabel='With phone'):
        from .phone_setup import run as phone
        phone(apps=True);music.forget();return
    address=dialog.input('Install link of the source (…/manifest.json)').strip()
    if address:
        try:
            added=music.add(address)
            dialog.notification('Music','%s added.'%added['manifest'].get('name',''),time=2500)
            if music.client_only(added):
                dialog.ok('Music','%s plays its songs only in Eclipse\'s own app - here it searches, and your other sources, '
                          'your cloud or YouTube play.'%added['manifest'].get('name',''))
        except music.MusicError as exc:dialog.ok('Music',music.safe(exc))


def _music_source(music,dialog,source):
    """A source: its own settings (as its manifest describes them, sent with every question), its place
    in the order (the first that has a song plays it), on / off, remove."""
    manifest=source['manifest'];on=source.get('on',True)
    settings=[s for s in manifest.get('settings') or () if isinstance(s,dict) and s.get('key')]
    choices=(['Settings'] if settings else [])+['Earlier in the order','Later in the order','Turn off' if on else 'Turn on','Remove']
    pick=dialog.select(manifest.get('name','Source'),choices)
    if pick<0:return
    choice=choices[pick]
    if choice=='Settings':
        while True:
            values=source.get('settings') or {}
            i=dialog.select('Settings',['%s  ·  %s'%(s.get('label') or s['key'],values.get(s['key'],s.get('default',''))) for s in settings])
            if i<0:return
            spec=settings[i];key,kind,now=spec['key'],spec.get('type'),values.get(spec['key'],spec.get('default'))
            if kind=='toggle':value=not bool(now)
            elif kind=='select':
                options=[o for o in spec.get('options') or () if isinstance(o,dict)]
                j=dialog.select(spec.get('label') or key,[str(o.get('label') or o.get('value')) for o in options])
                if j<0:continue
                value=options[j].get('value')
            elif kind=='number':
                typed=dialog.numeric(0,spec.get('label') or key,str(now if now is not None else ''))
                if not typed:continue
                value=float(typed) if '.' in typed else int(typed)
            else:value=dialog.input(spec.get('label') or key,str(now or ''))
            music.configure(manifest['id'],key,value)
            source=next((s for s in music.sources() if s['manifest'].get('id')==manifest['id']),source)
    elif choice.startswith('Earlier'):music.move(manifest['id'],-1)
    elif choice.startswith('Later'):music.move(manifest['id'],1)
    elif choice.startswith('Turn'):music.switch(manifest['id'],not on)
    elif dialog.yesno('Music','Remove %s?'%manifest.get('name','this source')):music.remove(manifest['id'])


def trailers():
    from resources.lib import imdb_trailers
    dialog=xbmcgui.Dialog()
    def rows():return [page.item('Automatic trailers',enabled=ADDON.getSetting('meganexus_auto_trailers')=='true'),
        page.item('Trailer focus delay',(ADDON.getSetting('meganexus_trailer_delay') or '6')+' seconds'),
        page.item('Trailer duration',('Full trailer' if ADDON.getSetting('meganexus_trailer_duration')=='0' else (ADDON.getSetting('meganexus_trailer_duration') or '90')+' seconds')),
        page.item('Trailer source',imdb_trailers.LABELS[imdb_trailers.source_setting(ADDON)]),
        page.item('IMDb trailer quality · no add-on needed',imdb_trailers.QUALITY_LABELS[imdb_trailers.quality_setting(ADDON)]),
        page.item('YouTube add-on','Configure' if xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)') else 'Install (only for YouTube trailers)'),
        page.item('Mini-player trailers without sound',enabled=ADDON.getSetting('meganexus_trailers_muted')=='true'),   # 7.0.42
        page.item('Back')]
    def choose(pick):
        if pick==0:toggle('meganexus_auto_trailers')
        elif pick in (1,2):
            values=[3,5,6,8,10,15,20,30] if pick==1 else [15,20,30,45,60,90,120,0]
            key='meganexus_trailer_delay' if pick==1 else 'meganexus_trailer_duration'
            current=ADDON.getSetting(key) or ('6' if pick==1 else '90');labels=[str(v) for v in values]
            i=dialog.select('Trailer length' if pick==2 else 'Seconds', ['Full trailer' if v=='0' else v+' seconds' for v in labels],preselect=labels.index(current) if current in labels else 0)
            if i>=0:ADDON.setSetting(key,labels[i])
        elif pick==3:
            keys=list(imdb_trailers.SOURCES);current=imdb_trailers.source_setting(ADDON)
            i=dialog.select('Trailer source',[imdb_trailers.LABELS[k]+(' · default' if k==imdb_trailers.DEFAULT_SOURCE else '') for k in keys],
                            preselect=keys.index(current))
            if i>=0:ADDON.setSetting(imdb_trailers.SETTING,keys[i])
        elif pick==4:
            keys=['480','720','1080'];current=imdb_trailers.quality_setting(ADDON)
            i=dialog.select('IMDb trailer quality',[imdb_trailers.QUALITY_LABELS[k] for k in keys],preselect=keys.index(current))
            if i>=0:ADDON.setSetting(imdb_trailers.QUALITY_SETTING,keys[i])
        elif pick==5:
            if ensure_addon('plugin.video.youtube'):xbmcaddon.Addon('plugin.video.youtube').openSettings()
        elif pick==6:toggle('meganexus_trailers_muted')
        elif pick==7:return page.DONE
    return page.show('Trailers',rows,choose)


_KEPT=[0.,'']


def cache_usage():
    """7.0.30: the posters Kodi keeps on the device (they survive restarts) and
    MegaNexus's image memory. The memory alone read '0 images' after every
    restart although Kodi had all posters."""
    import time
    memory=xbmcgui.Window(10000).getProperty('meganexus.art_cache.usage') or 'Starting'
    now=time.monotonic()
    if now-_KEPT[0]>10:
        from . import kodi_textures, precache
        proxy=precache.base()
        _KEPT[:]=[now,'%d pictures kept by Kodi'%kodi_textures.count(proxy) if proxy else '']   # 7.0.32: backgrounds and logos too
    return '  ·  '.join(part for part in (_KEPT[1],'memory '+memory) if part)


def clear_cache():
    """Catalog pages, titles' details, the day's ratings, the image memory and
    (7.0.32) Kodi's own copies of MegaNexus pictures - they stayed, 3000+ on a
    box, also from earlier proxy ports. The pictures are prepared again when
    Settings closes."""
    from . import browse_meta, kodi_textures, precache
    from resources.lib import mdblist_api
    browse_meta.clear(persistent=True)
    mdblist_api.clear_ratings()   # 7.0.30: the day's ratings too
    xbmc.executebuiltin('NotifyAll(meganexus,artcache.clear)')
    ids=kodi_textures.ours()
    removed=0
    if ids:
        dialog=xbmcgui.DialogProgress()
        dialog.create('Clear MegaNexus images and metadata cache','Removing the pictures Kodi keeps for MegaNexus...')
        def progress(done,total):
            if done%25==0:
                dialog.update(done*100//total,'Removing the pictures Kodi keeps for MegaNexus...[CR]%d / %d'%(done,total))
            return dialog.iscanceled()
        try:removed=kodi_textures.remove(ids,progress)
        finally:dialog.close()
    precache.forget()
    _KEPT[0]=0.
    xbmcgui.Window(10000).setProperty('meganexus.prepare.requested','1')
    xbmc.log('[MegaNexus] cache cleared: %d of %d pictures removed from Kodi'%(removed,len(ids)),xbmc.LOGINFO)
    xbmcgui.Dialog().notification('MegaNexus','Cache cleared · %d pictures removed · prepared again when you leave Settings'%removed,time=5000)


def picture_path_label():
    """8.1.1: which address Kodi gets our pictures at (Settings > Performance & image cache)."""
    from resources.lib import art_cache
    if not art_cache.native_available():
        return 'Image proxy  ·  vfs.meganexus 1.1.0 not installed yet'
    return 'vfs.meganexus (mnxart)  ·  no port, no Python' if art_cache.chosen() else 'Image proxy  ·  127.0.0.1'


def switch_picture_path():
    """Ask for the other picture path and clear out the one Kodi is leaving.

    The progress box has no Cancel on purpose. Kodi keeps a separate copy of every
    poster per address, so a switch that stops half way leaves the whole library stored
    twice - the fault this exists to prevent. It is written down before anything is
    touched, so even pulling the plug here only delays it to the next start.
    """
    from resources.lib import art_cache
    if not art_cache.native_available():
        xbmcgui.Dialog().ok('MegaNexus', 'The native picture path needs vfs.meganexus 1.1.0.[CR][CR]'
                            'MegaNexus installs it by itself (it also plays Usenet) - try again after '
                            'the next start.')
        return
    to_native = not art_cache.chosen()
    leaving = 'vfs.meganexus (mnxart)' if not to_native else 'the image proxy'
    arriving = 'vfs.meganexus (mnxart)' if to_native else 'the image proxy'
    if not xbmcgui.Dialog().yesno('Picture path',
                                  'Serve MegaNexus pictures through %s?[CR][CR]'
                                  'Kodi keeps its own copy of every picture per address, so the copies it '
                                  'has from %s are removed now. This can not be stopped once it starts, and '
                                  'the pictures are prepared again afterwards.' % (arriving, leaving),
                                  yeslabel='Switch', nolabel='Keep'):
        return
    _switch_pictures(to_native)


NATIVE_OFFERED = 'meganexus_art_native_offered'


def offer_native_pictures():
    """9.0.0: asked once when MegaNexus opens, on a device that kept the image proxy when it
    was updated (8.1.2 kept the path its pictures were already at) and can serve them through
    vfs.meganexus now. Never while a video plays - then it waits for the next opening."""
    from resources.lib import art_cache
    if ADDON.getSetting(NATIVE_OFFERED) == '1' or art_cache.chosen():
        return
    if xbmc.getCondVisibility('Player.HasVideo') or not art_cache.native_available():
        return
    ADDON.setSetting(NATIVE_OFFERED, '1')
    if xbmcgui.Dialog().yesno('Faster posters',
                              'MegaNexus can now load its pictures through its own native add-on '
                              '(vfs.meganexus) instead of the image proxy. Kodi gets faster and lighter.'
                              '[CR][CR]Every poster is loaded once more after the switch - the first '
                              'pages fill a little slower until then. You can switch later in '
                              'Settings > Performance & image cache.',
                              yeslabel='Switch now', nolabel='Later'):
        _switch_pictures(True)


def _switch_pictures(to_native):
    """The switch itself: written down first, then Kodi's copies from the old path removed."""
    from resources.lib import art_switch
    leaving = 'vfs.meganexus (mnxart)' if not to_native else 'the image proxy'
    arriving = 'vfs.meganexus (mnxart)' if to_native else 'the image proxy'
    art_switch.request(to_native)
    # The service runs in its own Python: it asks the setting again at once rather than
    # keeping its 30 s answer, or the first pictures after the switch go to the old path.
    xbmc.executebuiltin('NotifyAll(meganexus,artcache.path)')
    dialog = xbmcgui.DialogProgress()
    dialog.create('Picture path', 'Switching to %s...' % arriving)
    def step(done, total):
        dialog.update(min(99, done * 100 // total) if total else 99,
                      'Removing the pictures Kodi keeps from %s...[CR]%d / %d' % (leaving, done, total))
    try:
        rows, files, _done = art_switch.finish(step)
    finally:
        dialog.close()
    from . import precache
    precache.forget()
    _KEPT[0] = 0.
    xbmcgui.Window(10000).setProperty('meganexus.prepare.requested', '1')
    xbmcgui.Dialog().notification('MegaNexus', 'Pictures now through %s  ·  %d old copies removed'
                                  % (arriving, rows), time=5000)


def performance():
    from resources.lib.art_cache import selected_mode
    from resources.lib import ram_profile
    # 7.0.3: three memory presets; 256 MiB is the default.
    keys=list(ram_profile.PRESETS)
    labels=[ram_profile.LABELS[k] for k in keys]
    other={'disk246':'Images on internal disk · 246 MiB','disk512':'Images on internal disk · 512 MiB','off':'Images off · Kodi texture cache only'}
    def rows():
        mode=selected_mode(ADDON)
        label=ram_profile.LABELS.get(mode) or other.get(mode,mode)
        precache=ADDON.getSetting('meganexus_poster_precache')!='false'
        return [page.item('Memory for posters and catalogs',label),
            page.item('Prepare posters, artwork and ratings when MegaNexus opens',
                      'On · ~30 KB per poster' if precache else 'Off'),
            dict(page.item('Cache usage',cache_usage()),kind='info'),
            page.item('Picture path',picture_path_label()),
            page.item('Clear MegaNexus images and metadata cache'),page.item('Back')]
    def choose(pick):
        if pick==0:
            mode=selected_mode(ADDON)
            index=xbmcgui.Dialog().select('Memory for posters and catalogs',labels,preselect=keys.index(mode) if mode in keys else 1)
            if index>=0:
                ADDON.setSetting('meganexus_art_cache',keys[index]);xbmc.executebuiltin('NotifyAll(meganexus,artcache.configure)')
        elif pick==1:
            # 7.0.8: Kodi stores the first posters of every collection while Home is idle.
            ADDON.setSetting('meganexus_poster_precache','false' if ADDON.getSetting('meganexus_poster_precache')!='false' else 'true')
            if ADDON.getSetting('meganexus_poster_precache')=='false':xbmcgui.Window(10000).clearProperty('meganexus.precache.ring')
        elif pick==2:
            _KEPT[0]=0.   # 7.0.30: Select counts again
        elif pick==3:
            switch_picture_path()
        elif pick==4:
            clear_cache()
        elif pick==5:return page.DONE
    return page.show('Performance & image cache',rows,choose)


def screensaver_label():
    from .saver import ANIMATED,saver_mode
    kind=saver_mode(ADDON)
    if kind==ANIMATED:return 'MegaNexus animated'
    if kind=='video':return 'Custom video'
    if kind=='slideshow':return 'Slideshow · pictures from a folder'
    return 'Custom image / GIF' if ADDON.getSetting('meganexus_screensaver_art') else 'MegaNexus image'


def screensaver_media():
    from .saver import ANIMATED,saver_mode
    def current():
        kind=saver_mode(ADDON)
        if kind==ANIMATED:return 1
        if kind=='video':return 3
        if kind=='slideshow':return 4
        return 2 if ADDON.getSetting('meganexus_screensaver_art') else 0
    def rows():
        selected=current()
        return [page.item(label,'Selected' if selected==i else '') for i,label in enumerate((
                    'MegaNexus · standard image','MegaNexus · animated',
                    'Custom image / animated GIF','Custom video · MP4, MKV, WebM, MOV',
                    'Slideshow · pictures from a folder'))]+[page.item('Back')]
    def choose(pick):
        if pick==5:return page.DONE
        if pick==4:
            # 7.0.24: every picture of a folder (local or network), cross-faded.
            folder=xbmcgui.Dialog().browseSingle(0,'Choose a folder with pictures','files')
            if folder:
                ADDON.setSetting('meganexus_screensaver_folder',folder)
                ADDON.setSetting('meganexus_screensaver_type','slideshow')
            settings_snapshot.invalidate()
            return None
        if pick==0:
            ADDON.setSetting('meganexus_screensaver_type','image')
            ADDON.setSetting('meganexus_screensaver_art','');ADDON.setSetting('meganexus_screensaver_video','')
        elif pick==1:
            ADDON.setSetting('meganexus_screensaver_art','');ADDON.setSetting('meganexus_screensaver_video','')
            ADDON.setSetting('meganexus_screensaver_type',ANIMATED)
        else:
            video=pick==3
            mask='.mp4|.m4v|.mkv|.webm|.mov|.avi|.ts|.m2ts' if video else '.png|.jpg|.jpeg|.webp|.gif'
            path=xbmcgui.Dialog().browseSingle(1,'Choose screensaver video' if video else 'Choose image / animated GIF','files',mask)
            if path:
                ADDON.setSetting('meganexus_screensaver_video' if video else 'meganexus_screensaver_art',path)
                ADDON.setSetting('meganexus_screensaver_type','video' if video else 'image')
                if video:prepare_saver_loop(path)
        settings_snapshot.invalidate()
    try:return page.show('Screensaver media · videos loop silently; paused media keeps artwork',rows,choose)
    finally:
        from resources.lib import wallpaper
        wallpaper.follow_saver(ADDON)    # 7.0.42: your own picture / slideshow / video is the wallpaper too


def wallpaper_label():
    from resources.lib import wallpaper
    return wallpaper.label(ADDON)


def choose_wallpaper():
    """Home and HUB wallpaper (7.0.28): off, the screensaver's picture or
    slideshow, one picture, or a folder of pictures."""
    from resources.lib import wallpaper
    keys=wallpaper.MODES
    index=xbmcgui.Dialog().select('Custom theme background',[wallpaper.LABELS[k] for k in keys],
                                  preselect=keys.index(wallpaper.mode(ADDON)))
    if index<0:return None
    choice=keys[index];path=''
    if choice=='picture':
        path=xbmcgui.Dialog().browseSingle(1,'Choose a picture','files','.png|.jpg|.jpeg|.webp')
        if not path:return None
    elif choice=='folder':
        path=xbmcgui.Dialog().browseSingle(0,'Choose a folder with pictures','files')
        if not path:return None
    wallpaper.choose(choice,path,ADDON)
    settings_snapshot.invalidate()
    return None


def ambient_summary():
    from . import ambient
    return ambient.scene_summary(ambient.load(ADDON))


def ambient_studio():
    """Screensaver studio (7.0.24): the screensaver itself with a side panel -
    per widget a style, a colour and a position, changed live (Left / Right)."""
    from .saver import studio
    studio()
    settings_snapshot.invalidate()
    return None


SAVER_ID='screensaver.meganexus'
SAVER_MINUTES=(1,2,3,5,10,15,20,30,45,60)


def _kodi_setting(name,default=None):
    return (rpc('Settings.GetSettingValue',{'setting':name}) or {}).get('value',default)


def screensaver_summary():
    if _kodi_setting('screensaver.mode','')!=SAVER_ID:return 'Off'
    return 'After %s min · %s'%(_kodi_setting('screensaver.time',3),ambient_summary())


def _plugin_addon():
    return xbmcaddon.Addon('plugin.video.meganexus')


OFF_SETTING='meganexus_saver_off'      # 7.0.42: what Kodi does while the MegaNexus screensaver is off
OFF_MODES={'dim':'screensaver.xbmc.builtin.dim','none':''}


def _off_mode():
    return 'none' if _plugin_addon().getSetting(OFF_SETTING)=='none' else 'dim'


def screensaver_settings():
    """Everything of the screensaver in one place (7.0.24): on / off, when it
    starts (Kodi's idle time), the background, the studio and a preview."""
    def build():
        on=_kodi_setting('screensaver.mode','')==SAVER_ID
        rows=[('on',page.item('MegaNexus screensaver',enabled=on))]
        if not on:   # 7.0.42: Kodi has one screensaver - its Dim or nothing while ours is off
            return rows+[('offmode',page.item('With the MegaNexus screensaver off',
                                              'Kodi dims the screen' if _off_mode()=='dim' else 'Nothing · the screen stays as it is'))]
        return rows+[('time',page.item('Starts after','%s min without a key press'%_kodi_setting('screensaver.time',3))),
                     ('media',page.item('Background',screensaver_label())),
                     ('studio',page.item('Studio · clock, weather, calendar, text (live)',ambient_summary())),
                     ('preview',page.item('Preview · any key closes it'))]
    def act(key):
        if key=='on':
            on=_kodi_setting('screensaver.mode','')==SAVER_ID
            rpc('Settings.SetSettingValue',{'setting':'screensaver.mode','value':OFF_MODES[_off_mode()] if on else SAVER_ID})
        elif key=='offmode':
            mode='none' if _off_mode()=='dim' else 'dim'
            _plugin_addon().setSetting(OFF_SETTING,mode)
            rpc('Settings.SetSettingValue',{'setting':'screensaver.mode','value':OFF_MODES[mode]})
        elif key=='time':
            current=_kodi_setting('screensaver.time',3)
            keys=SAVER_MINUTES if current in SAVER_MINUTES else tuple(sorted(SAVER_MINUTES+(current,)))
            index=xbmcgui.Dialog().select('Start the screensaver after',['%d min'%m for m in keys],
                                          preselect=keys.index(current) if current in keys else 0)
            if index>=0:rpc('Settings.SetSettingValue',{'setting':'screensaver.time','value':keys[index]})
        elif key=='media':screensaver_media()
        elif key=='studio':return ambient_studio()
        elif key=='preview':
            from .saver import preview
            preview()
        if key in ('on','offmode','time'):
            from resources.lib.kodi_keep import keep
            keep()   # 7.0.60: on disk at once - Kodi alone saves it only when it closes cleanly
        return None
    return _keyed('Screensaver',build,act)


def prepare_saver_loop(path):
    """Write the seamless silent loop copy now, so the screensaver starts with it."""
    from .saver import prepare_loop,LOOP_EXTENSIONS
    if not path.lower().endswith(LOOP_EXTENSIONS):return
    dialog=xbmcgui.DialogProgress()
    dialog.create('Screensaver video','Preparing a seamless, silent loop…')
    try:
        ready=prepare_loop(path,progress=lambda done:dialog.update(int(done*100)),stopped=dialog.iscanceled)
    finally:
        dialog.close()
    if not ready and not dialog.iscanceled():
        xbmcgui.Dialog().notification('Screensaver video','This clip loops with a short pause (format not supported for seamless looping).',xbmcgui.NOTIFICATION_INFO,5000)


def _keyed(title,build,act):
    return page.keyed(title,build,act)


def appearance():
    def build():
        return [('skin',page.item('Use MegaNexus skin','Active' if xbmc.getSkinDir()=='skin.meganexus' else 'Activate')),
                ('layout',page.item('Layout & cards',home_layout_label())),
                ('content',page.item('Home content & titles')),
                ('artwork',page.item('Artwork · posters, backgrounds and logos',_artwork_summary())),
                ('spotlight',page.item('HUB · Trending now on TMDB (needs a TMDb key)',enabled=ADDON.getSetting('meganexus_hub_spotlight')!='false'))]
    def act(key):
        if key=='spotlight':   # 7.0.42: the HUB's spotlight; the screensaver has its own switch in its studio
            ADDON.setSetting('meganexus_hub_spotlight','false' if ADDON.getSetting('meganexus_hub_spotlight')!='false' else 'true')
            try:
                from resources.lib import hub_spotlight
                hub_spotlight.logo_rule(xbmcgui.Window(10000),hub_spotlight.logo_off(ADDON))   # 7.0.42: the logo follows at once
            except Exception:pass
            settings_snapshot.invalidate();return None
        if key=='skin':return 'meganexus:activate_skin'
        if key=='layout':return layout_cards()
        if key=='artwork':return artwork()
        if key=='content':return _appearance_page('Home content & titles',{'hero','titles','ratings','rowtitles','animated'})
    return _keyed('Home & appearance',build,act)


def _artwork_summary():
    from resources.lib import art_provider
    return art_provider.summary(ADDON)


def artwork():
    """7.0.29: where posters, backgrounds, logos and landscape cards come from -
    the catalog, or TMDB / Fanart.tv with the keys connected in API keys."""
    from resources.lib import art_provider as art
    def label(kind):
        provider=art.choice(kind,ADDON)
        if provider!='catalog' and not art.connected(provider,ADDON):
            return art.PROVIDER_LABELS[provider]+' · connect its API key'
        return art.PROVIDER_LABELS[provider]
    def build():
        rows=[(kind,page.item(art.LABELS[kind],label(kind))) for kind in art.KINDS]
        rows.append(('language',page.item('Language of posters and logos (TMDB, Fanart.tv)',art.LANGUAGE_LABELS[art.language(ADDON)])))
        if not (art.connected('tmdb',ADDON) and art.connected('fanart',ADDON)):
            rows.append(('keys',page.item('Connect TMDB / Fanart.tv','Connections › API keys')))
        return rows
    def act(key):
        if key=='keys':return api_keys()
        if key=='language':
            rows=[(value,page.item(art.LANGUAGE_LABELS[value],'Chosen' if value==art.language(ADDON) else '')) for value in art.LANGUAGES]
            def pick(value):
                ADDON.setSetting(art.LANGUAGE,value);settings_snapshot.invalidate();return page.DONE
            return page.keyed('Language of posters and logos',lambda:rows,pick)
        if key in art.KINDS:
            return _artwork_provider(key)
        return None
    return _keyed('Artwork',build,act)


def _artwork_provider(kind):
    from resources.lib import art_provider as art
    notes={'catalog':'What the metadata add-on supplies','tmdb':'TMDB pictures, many languages',
           'fanart':'Fanart.tv pictures, made by fans'}
    if kind=='landscape':
        notes.update(tmdb='TMDB backgrounds',fanart='Fanart.tv thumbs with the title on them')
    def build():
        current=art.choice(kind,ADDON);rows=[]
        for provider in art.PROVIDERS:
            if art.connected(provider,ADDON):value='Chosen' if provider==current else notes[provider]
            else:value='Connect its API key first'
            rows.append((provider,page.item(art.PROVIDER_LABELS[provider],value)))
        return rows
    def act(provider):
        if not art.connected(provider,ADDON):
            xbmcgui.Dialog().notification('Artwork','Add the %s API key in Connections › API keys.'%art.PROVIDER_LABELS[provider],time=4000)
            return api_keys()
        ADDON.setSetting(art.SETTINGS[kind],provider);settings_snapshot.invalidate()
        return page.DONE
    return _keyed(art.LABELS[kind],build,act)


def layout_cards():
    return _appearance_page('Layout & cards',{'layout','psort','pshow','cards','opacity','browseall'})


def clock_weather():
    return _appearance_page('Clock & weather',{'clock','weather'})


def _appearance_page(title, allowed):
    """Shared actions filtered into layout, content and clock categories."""
    from . import system_setup
    dialog=xbmcgui.Dialog()
    from resources.lib import presentation_settings
    presentation_settings.sync()
    from resources.lib import home_posters as hp, collections_home
    def build():
        from resources.lib import theme
        rows=[
            ('layout',page.item('Home layout',home_layout_label())),
            # 7.0.48: MegaNexus posters - their order and kind
            ('psort',page.item('Posters · order',dict(hp.SORTS)[hp.option(hp.SORT_SETTING,hp.SORTS,ADDON)])),
            ('pshow',page.item('Posters · show',dict(hp.SHOWS)[hp.option(hp.SHOW_SETTING,hp.SHOWS,ADDON)])),
            ('cards',page.item('Movie and series cards','Landscape' if ADDON.getSetting('meganexus_card_shape')=='landscape' else 'Portrait posters')),
            ('opacity',page.item('Poster and catalog transparency',theme.OPACITY_LABELS[theme.card_opacity(ADDON)])),
            # 7.0.48: off - a row goes on by itself near its end (no Browse all card)
            ('browseall',page.item('"Browse all" at the end of a row',
                                   enabled=ADDON.getSetting('meganexus_browse_all')!='false')),
            ('hero',page.item('Home hero and description',enabled=not xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidehero)'))),
            ('titles',page.item('Card titles',enabled=not xbmc.getCondVisibility('Skin.HasSetting(meganexus.hidetitles)'))),
            ('ratings',page.item('Ratings under the title',enabled=ADDON.getSetting('meganexus_show_ratings')!='false')),
            ('rowtitles',page.item('Row titles of collections and catalogs',enabled=ADDON.getSetting('meganexus_row_titles')!='false')),
            ('animated',page.item('Animated collection art and GIFs (focused card)',enabled=ADDON.getSetting('meganexus_animated_art')=='true')),
            ('clock',page.item('Weather and clock · all MegaNexus screens',enabled=not presentation_settings.hidden())),
            ('weather',page.item('Weather location / provider',xbmc.getInfoLabel('Weather.Location') or 'Not configured')),
            ]
        posters=collections_home.layout(ADDON)=='posters'
        return [(key,row) for key,row in rows if key in allowed and (posters or key not in ('psort','pshow'))]
    def act(key):
        if key=='layout':return choose_home_layout()
        if key in ('psort','pshow'):
            setting,choices=(hp.SORT_SETTING,hp.SORTS) if key=='psort' else (hp.SHOW_SETTING,hp.SHOWS)
            keys=[k for k,_ in choices]
            pick=dialog.select('Posters · '+('order' if key=='psort' else 'show'),[label for _,label in choices],
                               preselect=keys.index(hp.option(setting,choices,ADDON)))
            if pick>=0:ADDON.setSetting(setting,keys[pick]);settings_snapshot.invalidate()
            return None
        if key=='opacity':return choose_card_opacity()
        if key=='cards':
            pick=dialog.select('Movie and series cards',['Portrait posters','Landscape'],preselect=1 if ADDON.getSetting('meganexus_card_shape')=='landscape' else 0)
            if pick>=0:ADDON.setSetting('meganexus_card_shape',('poster','landscape')[pick])
        elif key in ('hero','titles'):xbmc.executebuiltin('Skin.ToggleSetting(%s)'%{'hero':'meganexus.hidehero','titles':'meganexus.hidetitles'}[key],True)
        elif key=='ratings':
            ADDON.setSetting('meganexus_show_ratings','false' if ADDON.getSetting('meganexus_show_ratings')!='false' else 'true')
            from .browse_meta import clear
            clear()
        elif key=='animated':toggle('meganexus_animated_art')
        elif key=='rowtitles':ADDON.setSetting('meganexus_row_titles','false' if ADDON.getSetting('meganexus_row_titles')!='false' else 'true')
        elif key=='browseall':
            ADDON.setSetting('meganexus_browse_all','false' if ADDON.getSetting('meganexus_browse_all')!='false' else 'true')
            settings_snapshot.invalidate()
        elif key=='clock':presentation_settings.set_hidden(not presentation_settings.hidden())
        elif key=='weather':system_setup.weather()

        return None
    return _keyed(title,build,act)

def theme_summary():
    from resources.lib import theme, wallpaper, interface_colors as colors
    if wallpaper.resolve(ADDON)[0]:
        return 'Custom theme · %s · %d %%'%(colors.LABELS[colors.options(ADDON)[1]],colors.options(ADDON)[2])
    return theme.LABELS[theme.current(ADDON)]


def themes_screensaver():
    def build():
        rows=[('theme',page.item('Theme',theme_summary())),
              ('wallpaper',page.item('Wallpaper · Home, catalogs, Live TV, Sport and the HUB',wallpaper_label()))]
        rows.append(('colours',page.item('Interface colours','Own colours · 5 styles')))
        return rows+[('screensaver',page.item('Screensaver · on / off, start, background, clock and widgets',screensaver_summary())),
                     ('clock',page.item('Clock & weather · all interfaces'))]
    def act(key):
        if key=='theme':return choose_theme()
        if key=='wallpaper':return choose_wallpaper()
        if key=='colours':return custom_theme_colours()
        if key=='screensaver':return screensaver_settings()
        if key=='clock':return clock_weather()
    return _keyed('Themes & screensaver',build,act)


def custom_theme_colours():
    from resources.lib import interface_colors as colors
    def build():
        own=colors.own_colours(ADDON);live=colors.publish(ADDON)
        rows=[('follow',page.item('Match interface colours to the background',enabled=colors.options(ADDON)[0])),
              ('tone',page.item('Background colour variation',colors.LABELS[colors.options(ADDON)[1]])),
              ('strength',page.item('Interface colour strength',str(colors.options(ADDON)[2])+' %'))]
        # 7.0.29: a colour of your own for each part, shown as a chip; Automatic keeps the theme's.
        for role in colors.ROLES:
            rows.append((role,page.item(colors.ROLE_LABELS[role],_colour_name(role,own.get(role)),swatch=live[role][2:])))
        if own:rows.append(('reset',page.item('Back to the theme colours','All parts Automatic')))
        return rows
    def act(key):
        if key=='follow':
            ADDON.setSetting(colors.FOLLOW,'false' if colors.options(ADDON)[0] else 'true')
            colors.publish(ADDON)
        if key=='tone':
            rows=[(tone,page.item(colors.LABELS[tone])) for tone in colors.TONES]
            def select(tone):
                from resources.lib import wallpaper
                if not wallpaper.resolve(ADDON)[0]:ADDON.setSetting(colors.FOLLOW,'false')
                ADDON.setSetting(colors.TONE,tone);colors.publish(ADDON)
                return page.DONE
            return page.keyed('Background colour variation',lambda:rows,select)
        if key=='strength':
            rows=[(str(i),page.item(str(i)+' %')) for i in sorted(set(range(0,101,10))|{35})]
            def select(value):
                from resources.lib import wallpaper
                if not wallpaper.resolve(ADDON)[0]:ADDON.setSetting(colors.FOLLOW,'false')
                ADDON.setSetting(colors.STRENGTH,value);colors.publish(ADDON)
                return page.DONE
            return page.keyed('Interface colour strength',lambda:rows,select)
        if key in colors.ROLES:return choose_colour(key)
        if key=='reset':
            for role in colors.ROLES:colors.set_own(ADDON,role,'')
            settings_snapshot.invalidate();colors.publish(ADDON)
        return None
    return _keyed('Interface colours',build,act)


def _colour_name(role,value):
    from resources.lib import interface_colors as colors
    if not value:return 'Automatic'
    return dict(colors.SWATCHES[role]).get(value,'#'+value)


def choose_colour(role):
    """One part's colour: Automatic, the swatches, or any hex. A pick shows at once on
    every screen - this page included - so the list itself is the preview."""
    from resources.lib import interface_colors as colors
    def build():
        current=colors.own_colours(ADDON).get(role,'')
        rows=[('',page.item('Automatic · the theme\'s colour','Chosen' if not current else ''))]
        rows+=[(value,page.item(name,'Chosen' if value==current else '',swatch=value)) for value,name in colors.SWATCHES[role]]
        own=current and current not in dict(colors.SWATCHES[role])
        rows.append(('hex',page.item('Your own colour · hex code','#'+current if own else 'e.g. 5096DC',swatch=current if own else '')))
        return rows
    def act(key):
        if key=='hex':
            key=xbmcgui.Dialog().input('Colour · six hex digits (RRGGBB)',colors.own_colours(ADDON).get(role,'')).strip()
            if not key:return None
        colors.set_own(ADDON,role,key)
        settings_snapshot.invalidate();colors.publish(ADDON)
        return None
    return _keyed(colors.ROLE_LABELS[role].split(' · ')[0],build,act)


def home_layout_label():
    from resources.lib import collections_home as ch
    return {'rows':'MegaNexus rows','posters':'MegaNexus posters'}.get(ch.layout(ADDON),'MegaNexus collections')


def choose_home_layout():
    """MegaNexus collections (default) or Nuvio-style catalog rows (6.0.35, issue #9)."""
    from resources.lib import collections_home as ch
    keys=list(ch.LAYOUTS);current=ch.layout(ADDON)
    pick=xbmcgui.Dialog().select('Home layout',[ch.LAYOUT_LABELS[k] for k in keys],preselect=keys.index(current))
    if pick>=0 and keys[pick]!=current:
        ADDON.setSetting(ch.LAYOUT_SETTING,keys[pick]);settings_snapshot.invalidate()
    return None  # Home repaints with the new layout when Settings closes


def choose_theme():
    from resources.lib import theme, wallpaper
    keys=list(theme.THEMES);current=theme.current(ADDON);custom=bool(wallpaper.resolve(ADDON)[0])
    pick=xbmcgui.Dialog().select('Theme',[theme.LABELS[k] for k in keys]+['Custom theme · choose your background'],preselect=3 if custom else keys.index(current))
    if pick==3:return choose_wallpaper()
    if 0<=pick<len(keys):
        if custom:wallpaper.choose('off',addon=ADDON)
        if keys[pick]!=current:
            # 7.0.30: the settings close first; Kodi's skin colours change afterwards.
            theme.apply(keys[pick],ADDON,kodi=False)
            return theme.RELOAD
    return None


def choose_card_opacity():
    """Posters and catalog art slightly see-through over the glass boxes (Off/10/20/30 %)."""
    from resources.lib import theme
    keys=list(theme.OPACITY_LEVELS);current=theme.card_opacity(ADDON)
    pick=xbmcgui.Dialog().select('Poster and catalog transparency',[theme.OPACITY_LABELS[k] for k in keys],preselect=keys.index(current))
    if pick>=0:theme.set_card_opacity(keys[pick],ADDON)
    return None


def ratings_summary():
    from resources.lib import ratings_row,mdblist_api
    if not mdblist_api.configured():return 'Connect MDBList first'
    shown=[label for _,label,on in ratings_row.choices(ADDON) if on]
    return '%d of %d shown'%(len(shown),len(ratings_row.SERVICES))


def ratings_page():
    """7.0.29: which MDBList ratings the title details show (like Nuvio)."""
    from resources.lib import ratings_row,mdblist_api
    def build():
        rows=[(service,page.item(label,enabled=on)) for service,label,on in ratings_row.choices(ADDON)]
        if not mdblist_api.configured():rows.insert(0,('connect',page.item('Connect MDBList (Accounts & tracking) to see ratings')))
        return rows
    def act(key):
        if key=='connect':return mdblist_tracking_page()
        if key in ratings_row.SERVICES:
            ratings_row.set_enabled(key,not ratings_row.enabled(key,ADDON),ADDON);settings_snapshot.invalidate()
        return None
    return _keyed('MDBList ratings',build,act)


def tracking_accounts():
    """Accounts in setup order: Nuvio, Stremio, then tracking services (7.0)."""
    from resources.lib import trakt_api,simkl_api
    def build():return [('nuvio',page.item('Nuvio account',nuvio_status())),
        ('stremio',page.item('Stremio · add-ons and Continue Watching',_stremio_status())),
        ('trakt',page.item('Trakt · tracking service','Connected' if trakt_api.authorized() else 'Not connected')),
        ('simkl',page.item('Simkl · tracking service','Connected' if simkl_api.authorized() else 'Not connected')),
        ('mdblist',page.item('MDBList · tracking service',_mdblist_status())),
        ('wetrakr',page.item('WeTrakr · tracking service',_wetrakr_status())),
        ]+_history_row()+[
        ('ratings',page.item('MDBList ratings · logos and scores in title details',ratings_summary())),
        ('reviews',page.item('Reviews · under Cast & crew in title details',_reviews_status())),
        ('tmdb_account',page.item('TMDB account · ratings',_tmdb_account_status()))]
    def act(key):
        if key=='nuvio':return accounts()
        if key=='tmdb_account':   # 7.0.45: your ratings to TMDB
            from resources.lib import tmdb_account
            if tmdb_account.connected():
                if xbmcgui.Dialog().yesno('TMDB account','Sign out of TMDB on this profile? Your ratings stay on TMDB.'):tmdb_account.disconnect()
            else:
                from .phone_setup import tmdb_sign_in
                tmdb_sign_in()
            return None
        if key=='reviews':return reviews_page()   # 7.0.45
        if key=='ratings':return ratings_page()
        if key=='stremio':
            from .keys_backup import stremio
            return stremio()
        if key=='trakt':
            from .trakt_account import run as trakt_settings
            return trakt_settings()
        if key=='simkl':
            from .simkl_account import run as simkl_settings
            return simkl_settings()
        if key=='mdblist':return mdblist_tracking_page()
        if key=='wetrakr':return wetrakr_page()
        if key=='history':return same_history()
    return _keyed('Accounts & tracking',build,act)


def _linked_clouds():
    try:
        from resources.lib.meganexus.cloud_sync import NuvioCloud,StremioCloud
        return [name for name,cloud in (('Nuvio',NuvioCloud),('Stremio',StremioCloud)) if cloud.is_linked()]
    except Exception:return []


def _history_row():
    """9.0.1: with any tracking service or Nuvio / Stremio - MegaNexus's own history is the
    other side, so one service is enough (only MDBList, only Nuvio...)."""
    try:
        from resources.lib import history_sync
        found=[history_sync.NAMES[name] for name in history_sync.services()]+_linked_clouds()
    except Exception:found=[]
    if not found:return []
    return [('history',page.item('Same watch history everywhere',' · '.join(['MegaNexus']+found)))]


def same_history():
    """9.0.1: what was watched on one tracking service sent to the others (history_sync) -
    after the comparison is shown and confirmed; only what each one is missing."""
    import threading
    from resources.lib import history_sync
    names=history_sync.services();clouds=_linked_clouds()
    shown=', '.join([history_sync.NAMES[n] for n in names]+clouds) or 'your accounts'
    dialog=xbmcgui.DialogProgress();dialog.create('Same watch history everywhere','Comparing %s and MegaNexus…'%shown)
    found={};monitor=xbmc.Monitor()
    def work():
        try:found['plan']=history_sync.plan(names)
        except Exception as exc:found['error']=exc
    worker=threading.Thread(target=work,name='MegaNexusHistoryPlan',daemon=True);worker.start()
    tick=0
    while worker.is_alive() and not monitor.abortRequested():
        tick=min(95,tick+1);dialog.update(tick);monitor.waitForAbort(.3)
    dialog.close()
    if 'error' in found:
        xbmcgui.Dialog().ok('Same watch history everywhere','The services could not be compared:[CR]%s'%found['error']);return None
    plan=found.get('plan') or {}
    sizes={name:(len(plan[name]['films']),len(plan[name]['episodes'])) for name in names}
    pauses=plan.get('trakt',{});drop,put=pauses.get('pauses_drop') or [],pauses.get('pauses_put') or []
    finished=plan.get('clouds_finished') or [] if clouds else []
    if not any(sum(size) for size in sizes.values()) and not (drop or put or finished):
        xbmcgui.Dialog().ok('Same watch history everywhere','%s and MegaNexus already have the same history.'%shown);return None
    lines=['%s gets %d films and %d episodes'%(history_sync.NAMES[name],films,episodes) for name,(films,episodes) in sizes.items() if films or episodes]
    if drop or put:lines.append('Trakt: %d pauses brought up to date, %d old ones removed'%(len(put),len(drop)))
    if finished:lines.append('%s: %d finished titles no longer shown as under way'%(' and '.join(clouds),len(finished)))
    note=('[CR]%d anime episodes are left out: the services number their seasons differently.'%plan['anime_left_out']
          if plan.get('anime_left_out') else '')
    if not xbmcgui.Dialog().yesno('Same watch history everywhere','[CR]'.join(lines)+'[CR][CR]Only what each service is missing, '
                                  'with the date it was watched. Nothing is removed or counted twice.'+note,
                                  yeslabel='Send',nolabel='Cancel'):
        return None
    dialog=xbmcgui.DialogProgress();dialog.create('Same watch history everywhere','')
    done=[]
    for name,(films,episodes) in sizes.items():
        if not films and not episodes:continue
        label='Sending to %s…'%history_sync.NAMES[name]
        try:
            taken=history_sync.send(name,plan[name]['films'],plan[name]['episodes'],
                                    step=lambda index,total,label=label:dialog.update(index*100//max(1,total),label))
            done.append('%s: %d films, %d episodes added'%(history_sync.NAMES[name],taken[0],taken[1]))
        except Exception as exc:
            done.append('%s: stopped - %s'%(history_sync.NAMES[name],exc))
    if drop or put:
        try:
            removed,sent=history_sync.send_pauses(drop,put,step=lambda index,total:dialog.update(index*100//max(1,total),'Trakt pauses…'))
            done.append('Trakt pauses: %d sent, %d old ones removed'%(sent,removed))
        except Exception as exc:
            done.append('Trakt pauses: stopped - %s'%exc)
    if finished:
        try:done.append('%s: %d titles marked finished (sent with the next sync)'%(' and '.join(clouds),history_sync.finish_clouds(finished)))
        except Exception as exc:done.append('%s: stopped - %s'%(' and '.join(clouds),exc))
    dialog.close()
    xbmcgui.Dialog().ok('Same watch history everywhere','[CR]'.join(done))
    return None


def reviews_page():
    """7.0.45: reviews under Cast & crew - on or off, and from which sources."""
    from resources.lib import reviews
    hints={'Trakt':'switch on Trakt in Accounts & tracking','TMDB':'add a TMDB key in Connections › API keys'}
    def build():
        rows=[('on',page.item('Reviews under Cast & crew',enabled=reviews.enabled(ADDON)))]
        ready=reviews.available(ADDON)
        for name in ('Trakt','TMDB'):
            if name in ready:rows.append((name,page.item('%s reviews'%name,enabled=reviews.source_on(name,ADDON))))
            else:rows.append((name,page.item('%s reviews'%name,'Not available · %s'%hints[name])))
        return rows
    def act(key):
        if key=='on':ADDON.setSetting(reviews.SETTING,'false' if reviews.enabled(ADDON) else 'true')
        elif key in reviews.SOURCE_SETTINGS and key in reviews.available(ADDON):
            ADDON.setSetting(reviews.SOURCE_SETTINGS[key],'false' if reviews.source_on(key,ADDON) else 'true')
        settings_snapshot.invalidate()
        return None
    return _keyed('Reviews',build,act)


def _profiles_status():
    try:
        from resources.lib import user_profiles
        rows=user_profiles.profiles();now=user_profiles.get(user_profiles.active()) or {}
        return '%s · %d profile%s'%(now.get('name') or '',len(rows),'' if len(rows)==1 else 's')
    except Exception:return ''


def profiles_page():
    """7.0.45: profiles - each its own tracking and watching; add-ons and the rest one for all."""
    from resources.lib import user_profiles
    from . import profiles
    def build():
        now=user_profiles.active()
        rows=[('switch',page.item('Switch profile',(user_profiles.get(now) or {}).get('name') or ''))]
        for row in user_profiles.profiles():
            label='%s%s'%(row['name'],' · in use' if row['id']==now else '')
            rows.append((row['id'],page.item(label,'First profile' if row.get('primary') else ('PIN' if row.get('pin') else ''))))
        if len(rows)-1<user_profiles.MAX_PROFILES:rows.append(('add',page.item('Add profile')))
        rows.append(('start',page.item("Who's watching when Kodi starts",enabled=ADDON.getSetting('meganexus_profiles_at_start')!='false')))
        return rows
    def act(key):
        if key=='switch':
            if profiles.choose():return 'meganexus:reload'
            return None
        if key=='add':
            name=xbmcgui.Dialog().input('Name of the new profile').strip()
            if name:
                try:user_profiles.add(name)
                except ValueError as exc:xbmcgui.Dialog().notification('Profiles',str(exc),time=4000)
            return None
        if key=='start':
            ADDON.setSetting('meganexus_profiles_at_start','false' if ADDON.getSetting('meganexus_profiles_at_start')!='false' else 'true')
            settings_snapshot.invalidate();profiles.cover_rule(ADDON);return None
        profiles.profile_menu(key)
        return None
    return _keyed('Profiles',build,act)


def _tmdb_account_status():
    try:
        from resources.lib import tmdb_account
        found=tmdb_account.session()
        if found.get('session_id'):return 'Connected%s'%(' · %s'%found['username'] if found.get('username') else '')
    except Exception:pass
    return 'Not connected'


def _reviews_status():
    from resources.lib import reviews
    if not reviews.enabled(ADDON):return 'Off'
    found=reviews.sources(ADDON)
    return 'On · %s'%' + '.join(found) if found else 'On · switch on Trakt or add a TMDB key'


def _debrid_status():
    from resources.lib import debrid,prowlarr
    on=[debrid.SERVICES[s]['name'] for s in debrid.active() if s in debrid.TORRENTS]
    if not on:return 'Add a TorBox, Premiumize or Offcloud key'
    return '%s · %s%s'%(' + '.join(on),'cached only' if debrid.cached_only() else 'cached and to download',' · Prowlarr' if prowlarr.server(ADDON) else '')


def _usenet_status():
    from resources.lib import debrid,newznab,usenet_stream
    parts=[]
    if usenet_stream.own_servers(ADDON):parts.append('your server')
    found=newznab.indexers(ADDON)
    if found:parts.append('%d indexer%s'%(len(found),'' if len(found)==1 else 's'))
    if debrid.enabled('easynews'):parts.append('Easynews')
    return ' · '.join(parts) if parts else 'Set up · your provider, then your indexers'


def debrid_page():
    """TorBox and Premiumize built in (7.0.12), Offcloud (7.0.37): streams straight from
    the account, found by the title's IMDb id - no stream add-on needed. 7.0.45: the
    torrents of your own Prowlarr too; Usenet has its own page (usenet_page)."""
    from resources.lib import debrid,prowlarr
    def build():
        rows=[]
        for service in debrid.TORRENTS:
            info=debrid.SERVICES[service]
            if debrid.api_key(service):
                rows.append((service,page.item('%s · streams'%info['name'],enabled=debrid.enabled(service))))
            else:
                rows.append((service,page.item('%s API key'%info['name'],'Not set · set it in API keys')))
        rows.append(('cached',page.item('Cached only · plays at once',enabled=debrid.cached_only())))
        found=prowlarr.server(ADDON)
        rows.append(('prowlarr',page.item('Your Prowlarr · torrent search for these services',
                                          prowlarr.name(found[0]) if found else 'Not set · your own Prowlarr server and its torrent indexers')))
        if any(s in debrid.TORRENTS for s in debrid.active()):rows.append(('test',page.item('Test the connection')))
        return rows
    def act(key):
        # 8.1.5: the keys live in API keys - a key not set is set there; a set one only
        # turns the service's streams on or off here (replaced / removed in API keys)
        if key in debrid.SERVICES:
            if not debrid.api_key(key):api_keys()
            else:ADDON.setSetting(debrid.SERVICES[key]['on'],'false' if debrid.enabled(key) else 'true')
        elif key=='cached':ADDON.setSetting(debrid.CACHED_SETTING,'false' if debrid.cached_only() else 'true')
        elif key=='prowlarr':_prowlarr_server()
        elif key=='test':
            lines=[]
            for service in [s for s in debrid.active() if s in debrid.TORRENTS]:
                try:lines.append('%s: %s'%(debrid.SERVICES[service]['name'],'connected' if debrid.check(service) else 'no answer'))
                except Exception as exc:lines.append('%s: %s'%(debrid.SERVICES[service]['name'],exc))
            found=prowlarr.server(ADDON)
            if found:lines.append('Prowlarr: %s'%(prowlarr.check(*found) or 'works'))
            xbmcgui.Dialog().notification('Debrid',' · '.join(lines)[:120],time=4000)
        settings_snapshot.invalidate()
        return None
    return _keyed('Debrid & Prowlarr',build,act)


def _spotnet_build():
    """7.0.45: read the newest spots now (the first time about a month of them)."""
    from resources.lib import spotnet
    progress=xbmcgui.DialogProgress()
    progress.create('Spotnet','Reading the newest spots from your Usenet provider…')
    def step(done,total,added):
        progress.update(int(100*done/max(1,total)),'Reading the newest spots from your Usenet provider…[CR]%d films and series found'%added)
    try:added=spotnet.sync(stop=progress.iscanceled,progress=step)
    except Exception as exc:
        progress.close()
        xbmcgui.Dialog().ok('Spotnet','The index could not be read: %s'%(exc if str(exc) else type(exc).__name__));return
    finally:progress.close()
    xbmcgui.Dialog().notification('Spotnet','%d films and series added'%added,time=3500)


def _service_key(service):
    """7.0.45: a service's key on its own page - added, its streams on/off, replaced or removed."""
    from resources.lib import api_keys,debrid
    info=debrid.SERVICES[service];dialog=xbmcgui.Dialog()
    login=bool(info.get('usenet'))
    if debrid.api_key(service):
        choice=dialog.select(info['name'],['Streams %s'%('off' if debrid.enabled(service) else 'on'),
                                          'Replace the %s'%('login' if login else 'key'),'Remove the %s'%('login' if login else 'key')])
        if choice==0:ADDON.setSetting(info['on'],'false' if debrid.enabled(service) else 'true')
        elif choice==2:api_keys.save(service,'')
        if choice!=1:return
    row=api_keys.KEYS[service]
    value=dialog.input('%s %s (%s)'%(info['name'],'login as username:password' if login else 'API key',row['url'].split('//',1)[-1].rstrip('/')),
                       option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
    if value:
        try:api_keys.save(service,value)
        except ValueError as exc:dialog.ok(info['name'],str(exc));return
        ADDON.setSetting(info['on'],'true')
        dialog.notification(info['name'],'Saved',time=2500)


def _prowlarr_server():
    """7.0.45: the user's own Prowlarr - names and info hashes only, the film comes
    from the debrid service (prowlarr.py)."""
    from resources.lib import prowlarr
    dialog=xbmcgui.Dialog()
    found=prowlarr.server(ADDON)
    if found:
        choice=dialog.select('Your Prowlarr',['Change','Test','Remove'])
        if choice==1:
            reason=prowlarr.check(*found)
            dialog.notification('Prowlarr','Works' if not reason else reason,time=4000);return
        if choice==2:
            ADDON.setSetting(prowlarr.SETTING,'');settings_snapshot.invalidate();return
        if choice!=0:return
    url=dialog.input('Prowlarr address (e.g. http://192.168.1.10:9696)',found[0] if found else '').strip()
    if not url:return
    key=dialog.input('Prowlarr API key (Prowlarr > Settings > General)',option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
    if not key:return
    progress=xbmcgui.DialogProgress();progress.create('Prowlarr','Asking your Prowlarr…')
    try:prowlarr.save_value('%s %s'%(url,key),ADDON)
    except ValueError as exc:
        progress.close();dialog.ok('Prowlarr',str(exc));return
    finally:progress.close()
    dialog.notification('Prowlarr','Works - its torrents join TorBox, Premiumize and Offcloud',time=4000)


def usenet_page():
    """7.0.45: everything Usenet on one page - the guided set-up, your provider (plays
    every NZB source), your indexers (searched from this box) and Easynews."""
    from resources.lib import debrid,newznab,usenet_stream
    def build():
        rows=[('wizard',page.item('Set up Usenet · step by step','Provider, then indexers')),
              ('usenet',page.item('Usenet server · plays NZB sources',_usenet_label())),
              ('newznab',page.item('Newznab indexers · searched from this box',_newznab_label()))]
        # 7.0.45: Spotnet - an index of films and series built on this box from Usenet itself
        from resources.lib import spotnet
        rows.append(('spotnet',page.item('Spotnet · your own index, built on this box',enabled=spotnet.enabled(ADDON))))
        if spotnet.enabled(ADDON):
            count,updated=spotnet.status()
            when=('updated %s'%time.strftime('%d.%m. %H:%M',time.localtime(updated))) if updated else 'not built yet'
            rows.append(('spotnet_build',page.item('Update the Spotnet index now','%d films and series · %s'%(count,when))))
        if debrid.api_key('easynews'):
            rows.append(('easynews',page.item('Easynews · streams',enabled=debrid.enabled('easynews'))))
        else:
            rows.append(('easynews',page.item('Easynews login','Not set · set it in API keys')))
        # 8.0: the fast Usenet player (vfs.meganexus, C++) - installed by MegaNexus for this system
        from resources.lib import usenet_native
        if usenet_native.platform_tag():
            rows.append(('native',page.item('Fast Usenet player · %s'%('ready' if usenet_native.ready() else
                                            'installs itself' if usenet_native.in_use(ADDON) else 'comes when you use Usenet'),
                                            enabled=usenet_native.wanted(ADDON))))
        # 7.0.52: CoreELEC / Linux - the Usenet player in its own process, decoding on all cores
        from resources.lib import usenet_engine
        if usenet_engine.python():
            rows.append(('engine',page.item('Usenet on all cores · faster 4K on this box',enabled=usenet_engine.wanted(ADDON))))
        if usenet_stream.own_servers(ADDON) or newznab.indexers(ADDON):rows.append(('test',page.item('Test the connection')))
        return rows
    def act(key):
        if key=='easynews':
            from resources.lib import debrid
            if not debrid.api_key('easynews'):api_keys()                 # 8.1.5: set in API keys
            else:ADDON.setSetting(debrid.SERVICES['easynews']['on'],'false' if debrid.enabled('easynews') else 'true')
        elif key=='spotnet':
            from resources.lib import spotnet
            if spotnet.enabled(ADDON):ADDON.setSetting(spotnet.SETTING,'false')
            elif not usenet_stream.own_servers(ADDON):
                xbmcgui.Dialog().ok('Spotnet','Spotnet is read with your Usenet provider: add your Usenet server first.')
            else:
                ADDON.setSetting(spotnet.SETTING,'true')
                if not spotnet.status()[0]:_spotnet_build()
        elif key=='spotnet_build':_spotnet_build()
        elif key=='native':
            from resources.lib import usenet_native
            turn=not usenet_native.wanted(ADDON)
            ADDON.setSetting(usenet_native.SETTING,'true' if turn else 'false')
            if turn:
                from resources.lib import settings_snapshot
                settings_snapshot.invalidate()
                if usenet_native.install_now():   # 8.0: turned on here - it comes now
                    xbmcgui.Dialog().notification('Usenet','The fast Usenet player is being installed',time=3000)
        elif key=='engine':
            from resources.lib import usenet_engine
            ADDON.setSetting(usenet_engine.SETTING,'false' if usenet_engine.wanted(ADDON) else 'true')
            xbmcgui.Dialog().notification('Usenet','From the next start of Kodi',time=3000)
        elif key=='usenet':
            _usenet_server()
            if usenet_stream.own_servers(ADDON):   # 8.0: Usenet set up - the fast player comes
                from resources.lib import usenet_native
                usenet_native.install_now()
        elif key=='newznab':_newznab_indexers()
        elif key=='wizard':
            # the provider (port and SSL found by themselves), then the indexers from the list
            _usenet_server()
            if usenet_stream.own_servers(ADDON):
                from resources.lib import usenet_native
                usenet_native.install_now()
                _newznab_indexers()
        elif key=='test':
            lines=[]
            servers=usenet_stream.own_servers(ADDON)
            if servers:
                reason=usenet_stream.check(servers[0])
                lines.append('Server: %s'%('login works' if not reason else reason))
            for url,api in newznab.indexers(ADDON):
                reason=newznab.check(url,api)
                lines.append('%s: %s'%(newznab.name(url),'works' if not reason else reason))
            xbmcgui.Dialog().ok('Usenet','[CR]'.join(lines) or 'Nothing set yet.')
        settings_snapshot.invalidate()
        return None
    return _keyed('Usenet',build,act)


def _usenet_label():
    from resources.lib import usenet_nntp,usenet_stream
    servers=[usenet_nntp.parse_server(v) for v in usenet_stream.own_servers(ADDON)]
    servers=[s for s in servers if s]
    if not servers:return 'Not set · NZB sources play with the servers their add-on gives'
    return ' + '.join('%s · %d connections'%(usenet_nntp.server_label(s),s['connections']) for s in servers)


def _newznab_label():
    from resources.lib import newznab,usenet_stream
    found=newznab.indexers(ADDON)
    if not found:return 'Not set · add NZBgeek, DrunkenSlug or any Newznab indexer'
    names=', '.join(newznab.name(url) for url,_ in found)
    return names if usenet_stream.own_servers(ADDON) else names+' · needs your Usenet server'


def _newznab_indexers():
    """7.0.45: the user's own Newznab indexers - searched straight from this box with
    their API keys (no add-on server in between); the keys are never shown again."""
    from resources.lib import newznab
    dialog=xbmcgui.Dialog()
    while True:
        found=newznab.indexers(ADDON)
        options=['Remove %s · %s'%(newznab.name(url),newznab.today(url)) for url,_ in found]+['Add an indexer']+(['Test the indexers'] if found else [])
        pick=dialog.select('Newznab indexers',options)
        if pick<0:return
        if pick<len(found):
            if dialog.yesno('Newznab indexers','Remove %s?'%newznab.name(found[pick][0])):
                newznab.store([entry for n,entry in enumerate(found) if n!=pick],ADDON)
            continue
        if options[pick]=='Test the indexers':
            lines=[]
            for url,key in found:
                reason=newznab.check(url,key)
                lines.append('%s: %s'%(newznab.name(url),'works' if not reason else reason))
            dialog.ok('Newznab indexers','[CR]'.join(lines))
            continue
        # 7.0.45: picked from the well-known indexers - only the API key is typed
        from resources.lib import debrid
        torbox=debrid.api_key('torbox')
        names=[('%s · your TorBox key, nothing to type'%label) if label==newznab.TORBOX and torbox else label for label,_,_ in newznab.PRESETS]
        pick2=dialog.select('Add an indexer',names+['Another indexer (its address and API key)'])
        if pick2<0:continue
        if pick2<len(newznab.PRESETS):
            label,url,where=newznab.PRESETS[pick2]
            key=torbox if label==newznab.TORBOX and torbox else \
                dialog.input('%s API key (%s)'%(label,where),option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
        else:
            url=dialog.input('Indexer address (e.g. https://indexer.example/api, a Prowlarr or NZBHydra link)').strip()
            if not url:continue
            key=dialog.input('API key (on the indexer\'s profile or API page)',option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
        if not key:continue
        progress=xbmcgui.DialogProgress();progress.create('Newznab indexers','Checking the indexer…')
        try:newznab.add(url,key,ADDON)
        except ValueError as exc:
            progress.close();dialog.ok('Newznab indexers',str(exc));continue
        finally:progress.close()
        dialog.notification('Newznab indexers','Indexer added',time=3000)


def _usenet_server():
    """7.0.43: the user's Usenet provider (NNTP) for NZB sources - also the backup
    for articles a source's own server lacks. Kept as nntps://user:password@host:563/10
    (hidden setting); the login is never shown or logged."""
    from resources.lib import usenet_nntp,usenet_stream
    dialog=xbmcgui.Dialog()
    old=next((s for s in (usenet_nntp.parse_server(v) for v in usenet_stream.own_servers(ADDON)) if s),None) or {}
    if old:
        choice=dialog.select('Usenet server',['Change','Test the login','Remove'])
        if choice==1:
            reason=usenet_stream.check(ADDON.getSetting(usenet_stream.SETTING).split()[0])
            dialog.notification('Usenet server','Login works' if not reason else reason,time=4000);return
        if choice==2:
            ADDON.setSetting(usenet_stream.SETTING,'');settings_snapshot.invalidate();return
        if choice!=0:return
    shown=old.get('host','')+(':%s'%old['port'] if old and old.get('port') not in (563,443,119) else '')
    typed=dialog.input('Usenet server address (e.g. news.provider.com)',shown).strip()
    # only the name (a port may follow: news.x.com:563); "https://", "nntps://", "/" are dropped
    typed=typed.split('://',1)[-1].split('/',1)[0].split('@')[-1].strip()
    host,_,port=typed.partition(':')
    if not host:return
    user=dialog.input('Username',old.get('user','')).strip()
    password=dialog.input('Password',option=xbmcgui.ALPHANUM_HIDE_INPUT).strip() or old.get('password','')
    connections=dialog.input('Connections (your plan allows how many?)',str(old.get('connections') or 10),type=xbmcgui.INPUT_NUMERIC).strip() or '10'
    # 7.0.43: port and SSL found by themselves (563 / 443 SSL, then 119)
    progress=xbmcgui.DialogProgress();progress.create('Usenet server','Finding the port…')
    try:value,reason=usenet_stream.detect(host,user,password,connections,int(port) if port.isdigit() else None)
    finally:progress.close()
    if reason and not dialog.yesno('Usenet server','%s.[CR]Keep it anyway?'%(reason[:1].upper()+reason[1:])):return
    ADDON.setSetting(usenet_stream.SETTING,value);settings_snapshot.invalidate()
    if not reason:dialog.notification('Usenet server','Login works',time=3000)


def _wetrakr_status():
    from resources.lib import wetrakr_api
    return {'connected':'Connected','ready':'Not connected',
            'needs_api':'Not connected'}.get(wetrakr_api.authorization_status(),'Not connected')


def wetrakr_page():
    """WeTrakr as a tracking service (8.1.2): the Library and what is watched go both
    ways. 8.1.5: each WeTrakr account registers its own app (wetrakr.com > Settings > API)
    - its client ID is entered here, once, and the sign-in is Trakt's: a code on the TV,
    entered on wetrakr.com. Connect asks for the client ID first when it is missing."""
    from resources.lib import wetrakr_api
    def ask_app():
        typed=xbmcgui.Dialog().input('Your WeTrakr app\'s client ID (wetrakr.com › Settings › API)',
                                     option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
        if typed:
            ADDON.setSetting(wetrakr_api.KEY_SETTING,typed);settings_snapshot.invalidate()
        return bool(typed)
    def build():
        have=bool(wetrakr_api.client_id())
        # 9.0.1: MegaNexus's app is built in - the own-app row only for one entered before
        own=bool((ADDON.getSetting(wetrakr_api.KEY_SETTING) or '').strip())
        rows=[] if (wetrakr_api.DEFAULT_CLIENT_ID and not own) else \
             [('app',page.item('Your WeTrakr app','Client ID set' if have else 'Not set · wetrakr.com › Settings › API'))]
        if have and wetrakr_api.authorized():
            rows+=[('link',page.item('Account','Connected · select to sign out')),
                   ('on',page.item('Use WeTrakr',enabled=wetrakr_api.enabled())),
                   ('sync',page.item('Read the Library and watched marks now'))]
        else:
            rows.append(('link',page.item('Connect WeTrakr','A code is shown on screen')))
        return rows
    def act(key):
        if key=='app':
            if wetrakr_api.client_id() and xbmcgui.Dialog().select('Your WeTrakr app',['Replace the client ID','Remove it']) == 1:
                ADDON.setSetting(wetrakr_api.KEY_SETTING,'');settings_snapshot.invalidate()
            else:
                ask_app()
            return None
        if key=='link' and not wetrakr_api.client_id() and not ask_app():
            return None
        if key=='on':
            ADDON.setSetting(wetrakr_api.ENABLE_SETTING,'false' if wetrakr_api.enabled() else 'true')
            settings_snapshot.invalidate()
        elif key=='link':
            if wetrakr_api.authorized():
                if xbmcgui.Dialog().yesno('WeTrakr','Sign out of WeTrakr on this profile? What is on WeTrakr stays there.'):
                    wetrakr_api.logout()
            else:
                try:
                    if wetrakr_api.device_auth():settings_snapshot.invalidate()
                except Exception as exc:
                    xbmcgui.Dialog().notification('WeTrakr',str(exc)[:80],time=4000)
        elif key=='sync':
            try:
                wetrakr_api.invalidate_cache()
                found=len(wetrakr_api.watchlist_copy_rows())
                wetrakr_api.watched_items()
                from resources.lib import library_titles
                library_titles.refresh_list_copy()
                xbmcgui.Dialog().notification('WeTrakr','%d titles read'%found,time=3000)
            except Exception as exc:
                xbmcgui.Dialog().notification('WeTrakr',str(exc)[:80],time=4000)
        return None
    return _keyed('WeTrakr · tracking service',build,act)


def _mdblist_status():
    from resources.lib import mdblist_tracking
    if not mdblist_tracking.api_key():return 'Needs the MDBList API key'
    return 'On' if mdblist_tracking.enabled() else 'Off'


def mdblist_tracking_page():
    """MDBList as a tracking service (7.0.12): watches go to MDBList, watched
    marks come back. Uses the MDBList API key from API keys."""
    from resources.lib import mdblist_tracking
    def build():
        have=bool(mdblist_tracking.api_key())
        rows=[('key',page.item('MDBList API key','Set' if have else 'Not set · set it in API keys'))]
        if have:
            rows+=[('on',page.item('Track what I watch on MDBList',enabled=mdblist_tracking.enabled())),
                   ('test',page.item('Test the connection')),
                   ('sync',page.item('Get watched marks from MDBList now'))]
        return rows
    def act(key):
        if key=='key':
            return api_keys()
        if key=='on':
            ADDON.setSetting('mdblist_tracking','false' if mdblist_tracking.enabled() else 'true')
            settings_snapshot.invalidate()
            if not mdblist_tracking.enabled():mdblist_tracking.forget()
        elif key in ('test','sync'):
            try:
                if key=='test':
                    ok=mdblist_tracking.check()
                    xbmcgui.Dialog().notification('MDBList','Connected' if ok else 'No answer from MDBList',time=3000)
                else:
                    mdblist_tracking.refresh(force=True)
                    xbmcgui.Dialog().notification('MDBList','Watched marks updated',time=3000)
            except Exception as exc:
                xbmcgui.Dialog().notification('MDBList',str(exc)[:80],time=4000)
        return None
    return _keyed('MDBList · tracking service',build,act)


def storage():
    """Local & network storage: own drives, Plex, Jellyfin and Emby."""
    from resources.lib import local_media, media_servers as servers
    def build():
        have=local_media.counts() if local_media.enabled(ADDON) else None
        return [('local',page.item('Local storage · drives and shares on this device',
                                   ('%d movies · %d series'%(have['movie'],have['series'])) if have else 'Off')),
                ('plex',page.item('Plex · your Plex servers',servers.status(servers.PLEX))),
                ('jellyfin',page.item('Jellyfin · your Jellyfin server',servers.status(servers.JELLYFIN))),
                ('emby',page.item('Emby · your Emby server',servers.status(servers.EMBY)))]
    def act(key):
        if key=='local':return local_storage()
        from . import media_servers
        return {'plex':media_servers.plex,'jellyfin':media_servers.jellyfin,'emby':media_servers.emby}[key]()
    return _keyed('Local & network storage',build,act)


def live_tv():
    """Live TV, IPTV and Sport on one page (7.0)."""
    from . import sports, iptv
    def build():
        lists=iptv._lists()     # 7.0.37: several lists, each with Live TV / IPTV VOD / groups
        return [('status',page.item('IPTV channels','Set up' if iptv.configured() else 'Not set up')),
                ('lists',page.item('IPTV lists','%d · channels, VOD, groups'%len(lists) if lists else 'None yet')),
                ('xtream',page.item('Add an Xtream account')),
                ('m3u',page.item('Add an M3U playlist + XMLTV TV guide')),
                ('live_only',page.item('Only live TV in the channel list (less RAM, faster start)',
                                       enabled=ADDON.getSetting('meganexus_iptv_live_only')!='false')),
                ('open',page.item('Open Live TV channels')),
                ('sport_auto',page.item('Sport · play live events after resting 5 seconds',enabled=sports.autoplay_enabled())),
                ('sport_addons',page.item('Sport add-ons',_role_count('sport')))]
    def act(key):
        if key=='sport_addons':return role_addons('sport')
        if key in ('xtream','m3u'):iptv.setup(key)
        elif key=='lists':return iptv.lists_page()
        elif key=='live_only':   # 7.0.37: made at once (not while live TV plays)
            ADDON.setSetting('meganexus_iptv_live_only','false' if iptv.live_only() else 'true')
            if iptv.configured():iptv.apply_lists()
        elif key in ('open','status'):
            if iptv.configured():iptv.open_iptv()   # the channel list over the hidden settings page
            else:iptv.configure()
        elif key=='sport_auto':ADDON.setSetting(sports.AUTOPLAY_SETTING,'false' if sports.autoplay_enabled() else 'true')
        settings_snapshot.invalidate()
        return None
    return _keyed('Live TV, IPTV & Sport',build,act)


def backup_restore():
    from .keys_backup import backup,restore
    def build():return [('backup',page.item('Back up settings to a file','USB, network or Downloads')),
                        ('restore',page.item('Restore settings from a backup')),
                        ('phone',page.item('On the phone','Set up on phone > Backup'))]
    def act(key):
        if key=='backup':backup();return None
        if key=='restore':return restore()
        xbmcgui.Dialog().ok('Backup on the phone','HUB Settings > Set up on phone, then open the Backup tab: download a backup to your '
                            'phone, or restore one. Settings, accounts, API keys, add-ons, collections and Continue Watching move along.')
        return None
    return _keyed('Backup & restore',build,act)


def api_keys():
    from .keys_backup import keys
    return keys()


def _stremio_status():
    from resources.lib import stremio_account
    return stremio_account.status()


def continue_watching():
    """Continue Watching like the Nuvio apps (6.0.35, GitHub issue #7)."""
    from resources.lib import continue_rules as rules
    def rows():return [page.item('Show titles watched in the last',rules.PERIOD_LABELS[str(rules.period_days(ADDON))]),
        page.item('Show unaired next episodes (airs tomorrow)',enabled=rules.show_unaired(ADDON)),
        page.item('Refresh interval and Nuvio sync direction',(ADDON.getSetting('nuvio_progress_interval') or '60')+' seconds'),
        page.item(LAST_LINK_TITLE,last_link_summary()),page.item('Back')]
    def choose(pick):
        if pick==0:
            values=list(rules.PERIODS);current=str(rules.period_days(ADDON))
            selected=xbmcgui.Dialog().select('Continue Watching period',[rules.PERIOD_LABELS[v] for v in values],
                                             preselect=values.index(current) if current in values else 1)
            if selected>=0:ADDON.setSetting(rules.PERIOD_SETTING,values[selected])
        elif pick==1:ADDON.setSetting(rules.UNAIRED_SETTING,'false' if rules.show_unaired(ADDON) else 'true')
        elif pick==2:progress_settings()
        elif pick==3:choose_last_link()
        elif pick==4:return page.DONE
        settings_snapshot.invalidate()
        xbmcgui.Window(10000).setProperty('meganexus.progress.revision','settings-%s'%id(rows))
    return page.show('Continue Watching',rows,choose)


KOFI_URL='https://ko-fi.com/master100janovic'


class SupportWindow(xbmcgui.WindowXMLDialog):
    def onInit(self):self.setFocusId(100)
    def onClick(self,cid):self.close()
    def onAction(self,action):
        if action.getId() in (9,10,92,216,247,257,275,61448,61467):self.close()


def support():
    """Ko-fi QR code: scan with a phone to donate."""
    win=SupportWindow('meganexus_support.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i')
    try:win.doModal()
    finally:del win


def components_up_to_date(current,dialog,latest=''):
    """The backend is current; are the interface, skin and screensaver too?
    (6.0.36: an updated backend with an old interface said "up to date".)"""
    from resources.lib import bundle_installer
    try:report=bundle_installer.component_report()
    except Exception:report=[]
    names={'script.meganexus':'interface','skin.meganexus':'skin','screensaver.meganexus':'screensaver'}
    missing=[r for r in report if not r['current']]
    stale=[r for r in report if r['current'] and r['kodi'] and r['kodi']!=r['wanted']]
    if not missing and not stale:
        dialog.ok('Updates','MegaNexus %s is up to date (latest release %s).'%(current,latest or current));return
    if missing:
        parts=', '.join('%s %s'%(names.get(r['id'],r['id']),r['files'] or 'missing') for r in missing)
        # Installed by the service once MegaNexus is closed; a restart does it at once.
        ADDON.setSetting(bundle_installer.VERSION_SETTING,'')
        text='MegaNexus %s is installed, but not yet: %s.\nThey are installed when MegaNexus is closed - or restart now to finish.'%(current,parts)
    else:
        parts=', '.join('%s %s'%(names.get(r['id'],r['id']),r['kodi']) for r in stale)
        text='MegaNexus %s is installed; Kodi still uses %s until it restarts.'%(current,parts)
    from resources.lib.kodi_restart import plan
    builtin,label,_=plan()
    if dialog.yesno('Updates',text,nolabel='Later',yeslabel=label):
        xbmc.executebuiltin(builtin)


def check_updates():
    """Compare with the latest GitHub release and install it on confirmation."""
    from resources.lib import updater
    from .play_jobs import job
    backend=xbmcaddon.Addon('plugin.video.meganexus');dialog=xbmcgui.Dialog()
    current=backend.getAddonInfo('version')
    try:info=job(updater.latest,label='Checking GitHub for updates')
    except Exception:
        dialog.ok('Updates','GitHub could not be reached. Check the connection and retry.\n'+updater.RELEASES);return
    if info is None:
        dialog.ok('Updates','No MegaNexus release was found.\n'+updater.RELEASES);return
    if not updater.newer(info['version'],current):
        components_up_to_date(current,dialog,info['version']);return
    if not updater.ask(dialog,'Update available','MegaNexus %s is available (installed %s).\nInstall it now? Kodi restarts the interface afterwards.'%(info['version'],current),
                       info.get('notes'),"What's new in MegaNexus %s"%info['version']):return
    if xbmc.Player().isPlayingVideo():
        dialog.ok('Updates','Stop playback first, then check again.');return
    try:
        job(lambda:updater.install(info,xbmcvfs.translatePath('special://home/addons'),
                                   xbmcvfs.translatePath(backend.getAddonInfo('profile'))),label='Installing MegaNexus %s'%info['version'])
    except Exception as exc:
        dialog.ok('Updates','The update could not be installed; your current version was kept.\n'+(str(exc) if isinstance(exc,ValueError) else ''));return
    xbmc.executebuiltin('UpdateLocalAddons')
    updater.mark_pending(backend,info['version'])
    # 7.0: ask right away (users waited for a question that only came after
    # leaving MegaNexus). Yes closes MegaNexus first, then Kodi restarts /
    # reboots / closes per platform (the command runs after the interface).
    from resources.lib.kodi_restart import plan
    builtin,label,question=plan()
    if dialog.yesno('Updates',question%info['version'],nolabel='Later',yeslabel=label):
        backend.setSetting(updater.PENDING_SETTING,'')
        return builtin
    dialog.ok('Updates','MegaNexus %s is installed. It starts after the next Kodi restart; MegaNexus reminds you when you open it.'%info['version'])
    return page.DONE


def version_label():
    """Backend version, plus the interface's when Kodi runs another one."""
    backend=xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('version')
    ui=xbmcaddon.Addon('script.meganexus').getAddonInfo('version')
    return backend if ui==backend else '%s · interface %s'%(backend,ui)


def maintenance():
    def build():return [('update',page.item('Check for updates',version_label())),
        ('auto',page.item('Automatic updates from GitHub',enabled=ADDON.getSetting('meganexus_auto_update')!='false')),
        ('wizard',page.item('Run setup again')),
        ('reset',page.item('Reset MegaNexus · erase all settings and start fresh')),
        ('remove',page.item('Remove MegaNexus build'))]
    def act(key):
        if key=='update':return check_updates() or None
        if key=='reset':return factory_reset_page()
        if key=='auto':ADDON.setSetting('meganexus_auto_update','false' if ADDON.getSetting('meganexus_auto_update')!='false' else 'true')
        elif key=='wizard':
            from .onboarding import run as wizard
            return wizard(force=True)
        elif key=='remove':
            from resources.lib.meganexus_uninstall import prepare
            return prepare()
        return None
    return _keyed('Updates',build,act)


def diagnostics():
    """8.1.5: what helps find a problem, with the help - it was under Maintenance & updates."""
    def build():return [('stats',page.item('Diagnostics overlay · CPU, RAM, FPS, video and audio format',enabled=xbmc.getCondVisibility('Skin.HasSetting(meganexus.stats)'))),
        ('check',page.item('System check · add-ons that slow MegaNexus down')),
        ('tracking',page.item('Check the tracking connections · Nuvio, Trakt, Simkl, MDBList'))]
    def act(key):
        if key=='stats':
            # 7.0.21: a corner window of MegaNexus Skin (Custom_1111); it takes no
            # focus, so menus and the player work as usual underneath.
            if xbmc.getSkinDir()!='skin.meganexus':
                xbmcgui.Dialog().ok('Diagnostics overlay','The overlay is part of MegaNexus Skin. Switch to MegaNexus Skin in Home & appearance first.')
            else:xbmc.executebuiltin('Skin.ToggleSetting(meganexus.stats)',True)   # 7.0.58: done before the row reads it again
        elif key=='check':
            from .system_check import run as system_check
            system_check(force=True)
        elif key=='tracking':verify_tracking()
        return None
    return _keyed('Diagnostics',build,act)


def factory_reset_page():
    """7.0.21: erase every MegaNexus setting and saved file, then restart Kodi."""
    dialog=xbmcgui.Dialog()
    if not dialog.yesno('Reset MegaNexus','This erases everything MegaNexus keeps on this device: your add-ons, collections, accounts and API keys, '
                        'all preferences, Continue Watching and the caches.[CR]Kodi then restarts and MegaNexus starts like a new installation.',
                        nolabel='Cancel',yeslabel='Continue'):return None
    if not dialog.yesno('Reset MegaNexus','Erase everything now? This cannot be undone.[CR]Tip: Backup & restore can save your setup to a file first.',
                        nolabel='Cancel',yeslabel='Erase everything'):return None
    from resources.lib import factory_reset, kodi_restart
    factory_reset.request()
    builtin,_,_=kodi_restart.plan()
    if builtin=='Quit':dialog.ok('Reset MegaNexus','Kodi closes now. Open Kodi again: MegaNexus starts fresh.')
    xbmc.executebuiltin(builtin)
    return page.DONE


def local_storage():
    from .local_storage import run as local
    return local()


def phone_setup():
    from .phone_setup import run as phone
    phone()


def _category(title, actions):
    def build():return [(key,page.item(label)) for key,label,_ in actions]
    def act(key):return next(fn for name,_,fn in actions if name==key)()
    return _keyed(title,build,act)


def connections():
    """Kept for old links (the onboarding, Home): 8.1.5 put these on the first page."""
    return _category('Accounts, add-ons & keys', [('accounts','Accounts & tracking · Nuvio, Stremio, Trakt, Simkl',tracking_accounts),
        ('addons','Add-ons · metadata, streams, subtitles, sport',addons),
        ('keys','API keys · every key in one place',api_keys)])


def debrid_usenet():
    """8.1.5: the streaming services in one place - their keys are in API keys."""
    return _category('Debrid & Usenet', [('debrid','Debrid & Prowlarr · TorBox, Real-Debrid, AllDebrid, Premiumize, Offcloud',debrid_page),
        ('usenet','Usenet · your provider, indexers, Easynews',usenet_page)])


def verify_tracking():
    from resources.lib.tracking_connections import check_connections
    from .play_jobs import job
    report=job(check_connections,label='Checking tracking connections')
    if not report:return
    rows=[]
    for name,row in report.items():
        if name=='local':continue
        rows.append('%s · %s · sync %s'%(name,row['connection'],'on' if row.get('sync') else 'off'))
    xbmcgui.Dialog().select('Tracking connections',rows)


def home_library():
    return _category('Home & library', [('appearance','Home & appearance',appearance),
        ('collections','Collections & Home rows',collections),
        ('continue','Continue Watching',continue_watching)])


def playback_category():
    return _category('Playback & subtitles', [('player','Playback',playback),
        ('subtitles','Subtitles',subtitle_settings),('trailers','Trailers',trailers),('badges','Stream badges · Nuvio JSON',badge_settings),
        ('formats','Source list text · formatter',source_format_settings)])


def source_format_settings():
    """7.0.44: how sources read in the source list - MegaNexus's formatters, the
    add-on's own text, or a template of your own (source_formats.py)."""
    from resources.lib import source_formats as sf
    dialog=xbmcgui.Dialog()
    def current():
        return ADDON.getSetting(sf.SETTING) or 'cinema'
    def build():
        rows=[(key,page.item(name,enabled=current()==key)) for key,name,_ in sf.FORMATS]
        rows.append(('addon',page.item(sf.NAMES['addon'],'As each add-on writes it',enabled=current()=='addon')))
        own=ADDON.getSetting(sf.CUSTOM)
        rows.append(('custom',page.item(sf.NAMES['custom'],own[:60] if own else 'Type a template',enabled=current()=='custom')))
        rows.append(('help',page.item('How a template is written')))
        return rows
    def act(key):
        if key=='help':
            dialog.textviewer('Source list text',
                'Each source has two lines; | separates them.\n\n{field} writes a fact; [ ... ] is written only when every field '
                'inside it has a value.\n\nFields: '+', '.join(sf.FIELDS)+'.\n\nExample:\n'+sf.TEMPLATES['cinema']+
                '\n\nOnly plain characters - Kodi has no emoji in its font.')
            return None
        if key=='custom':
            value=dialog.input('Your template (first line | second line)',ADDON.getSetting(sf.CUSTOM) or sf.TEMPLATES['cinema']).strip()
            if not value:return None
            reason=sf.check(value)
            if reason:
                dialog.ok('Source list text','This template can not be used: %s.'%reason);return None
            ADDON.setSetting(sf.CUSTOM,value)
        ADDON.setSetting(sf.SETTING,key);settings_snapshot.invalidate()
        return None
    return _keyed('Source list text',build,act)


def badge_settings():
    from resources.lib import quality_badges
    state=quality_badges.status()
    if state['enabled'] and not state['count']:
        from .play_jobs import job
        job(quality_badges.prepare_rules,label='Preparing stream badges')
    def build():
        state=quality_badges.status()
        summary='%d rules · %s'%(state['count'],state.get('name') or 'Imported Nuvio JSON') if state['count'] else 'Starter image badges activate when enabled'
        names={row['id']:row['name'] for row in state.get('sets') or []}
        return [('on',page.item('Show stream badges',summary,enabled=state['enabled'])),
                # 7.0.42: ready sets to choose from (review/make_badge_sets.py)
                ('set',page.item('Badge set',names.get(state.get('set'),'Your own import'))),
                ('urls',page.item('Import badge JSON URLs','%d links · %d rules'%(len(state['urls']),state['count']))),
                ('file',page.item('Import JSON file · badge builder',state.get('name') or 'Universal mode matches ordinary stream names')),
                ('preview',page.item('Preview · images and labels'))]
    def act(key):
        state=quality_badges.status()
        if key=='on':
            from .play_jobs import job
            job(lambda:quality_badges.toggle(not state['enabled']),label='Preparing stream badges')
        elif key=='set':
            rows=state.get('sets') or []
            if not rows:return
            labels=[('✓ ' if row['id']==state.get('set') else '')+'%s · %s · %d badges'%(row['name'],row.get('look') or '',row.get('count') or 0) for row in rows]
            index=xbmcgui.Dialog().select('Badge set',labels)
            if index<0:return
            from .play_jobs import job
            chosen=rows[index]['id']
            job(lambda:quality_badges.choose(chosen),label='')
            from .badges import preview
            preview(quality_badges.status())
        elif key=='urls':
            urls=[]
            for index in range(3):
                old=state['urls'][index] if index<len(state['urls']) else ''
                url=xbmcgui.Dialog().input('Badge JSON URL %d · empty to finish'%(index+1),defaultt=old).strip()
                if not url:break
                urls.append(url)
            if urls:
                from .play_jobs import job
                job(lambda:quality_badges.save(urls),label='Importing stream badges')
        elif key=='file':
            path=xbmcgui.Dialog().browseSingle(1,'Import badge JSON','files','.json')
            if path:
                from .play_jobs import job
                job(lambda:quality_badges.save_file(path),label='Importing stream badges')
        elif key=='preview':
            from .badges import preview
            preview(state)
    return _keyed('Stream badges',build,act)


def backup_maintenance():
    return _category('Backup & updates', [('backup','Backup & restore · move to another device',backup_restore),
        ('maintenance','Updates · setup again · reset',maintenance)])


def _watch_party():
    from .party import settings_page
    return settings_page()


def _downloads():
    from .downloads import manage
    return manage()


def help_support():
    from .help_guide import guide
    def report():
        from resources.lib import problem_report
        if not problem_report.left_today():
            xbmcgui.Dialog().ok('Report a problem','You can send %d reports in 24 hours. Try again tomorrow.'%problem_report.PER_DAY)
            return
        from .phone_setup import run as phone
        phone(report=True)
    def license_text():
        # 7.0.42: the MegaNexus License as shipped with the add-on
        import os
        path=os.path.join(xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('path'),'LICENSE.txt')
        try:
            with open(path,encoding='utf-8') as handle:text=handle.read()
        except OSError:text='MegaNexus License: https://github.com/MegaNexusMediaPlayer/MegaNexus/blob/main/LICENSE.md'
        xbmcgui.Dialog().textviewer('MegaNexus · License',text)
    return _category('Help & diagnostics', [('guide','User guide · how MegaNexus works and what every setting does',guide),
        ('report','Report a problem · describe it on the phone, sent with the Kodi log',report),
        ('diagnostics','Diagnostics · overlay, system check, tracking connections',diagnostics),
        ('license','License · what you may and may not do with MegaNexus',license_text)])


def run(back_command=''):
    actions=[('Set up on phone · QR code',phone_setup,''),
        ('Buy me a coffee · Ko-fi',support,'Support MegaNexus'),   # 7.0.29: in sight, right under the phone set-up
        ('Profiles',profiles_page,_profiles_status()),   # 7.0.45: who is watching
        # 8.1.5: what was under Connections is on the first page, every key in one place
        ('API keys',api_keys,'Every key in one place'),
        ('Accounts & tracking',tracking_accounts,'Nuvio, Stremio, Trakt, Simkl'),
        ('Add-ons',addons,'Metadata, streams, subtitles, sport'),
        ('Debrid & Usenet',debrid_usenet,'TorBox, Real-Debrid, Usenet'),
        ('Local & network storage',storage,'Drives, Plex, Jellyfin, Emby'),   # 8.1.5: on the first page
        ('Home & library',home_library,'Layout & collections'),
        ('Playback & subtitles',playback_category,'Player & trailers'),
        ('Watch Party',_watch_party,'Friends, messages, phone'),   # 7.0.55: what is set once
        ('Downloads',_downloads,'Folder & progress'),   # 7.0.29
        ('Live TV, IPTV & Sport',live_tv,''),
        ('YouTube',youtube_settings,'The HUB app'),   # 9.0.6
        ('Music',music_settings,'Sources, YouTube, cloud & folders'),   # 9.0.6
        ('Themes & screensaver',themes_screensaver,'Standard or custom'),
        ('Performance & image cache',performance,''),
        ('Backup & updates',backup_maintenance,'Restore & updates'),
        ('Help & diagnostics',help_support,'')]
    def rows():return [page.item(label,value) for label,_,value in actions]+[page.item('Done')]
    def choose(pick):
        try:
            if pick==len(actions):return page.DONE
            result=actions[pick][1]()
            return result if isinstance(result,str) else None
        except Exception as exc:xbmcgui.Dialog().ok('MegaNexus',str(exc) if isinstance(exc,ValueError) else 'This operation could not finish. Check the configuration and connection, then retry.')
        finally:settings_snapshot.invalidate()
    return page.show('HUB Settings',rows,choose,back_result=back_command)


def subtitle_settings():
    from resources.lib import meganexus_subtitles as subs
    def rows():return [page.item('Subtitle language',subs.language_name(subs.preferred())),
        page.item('Set subtitles on video start',enabled=ADDON.getSetting('meganexus_subtitles_on_start')=='true'),
        page.item('Subtitle add-ons',_role_count('subtitles')),
        page.item('Autosync subtitle offset',enabled=(ADDON.getSetting('meganexus_autosync_subtitles') or 'true')!='false'),
        # 8.1.3: the player's AI button - Gemini translates the film's subtitles into your language
        page.item('AI subtitles (Gemini)',enabled=(ADDON.getSetting('meganexus_ai_subtitles') or 'true')!='false'),
        page.item('Back')]
    def choose(pick):
        if pick==0:
            choices=subs.languages();current=subs.language(subs.preferred())
            selected=next((i for i,r in enumerate(choices) if subs.language(r['value'])==current),0)
            index=xbmcgui.Dialog().select('Subtitle language',[r['label'] for r in choices],preselect=selected)
            if index>=0:
                value=choices[index]['value']
                ADDON.setSetting('meganexus_subtitle_language',value)
                ADDON.setSetting('preferred_subtitle_langs',subs.language(value))
        elif pick==1:toggle('meganexus_subtitles_on_start')
        elif pick==2:role_addons('subtitles')
        elif pick==3:
            on=(ADDON.getSetting('meganexus_autosync_subtitles') or 'true')!='false'
            ADDON.setSetting('meganexus_autosync_subtitles','false' if on else 'true')
            xbmcgui.Window(10000).setProperty('meganexus.subtitle.syncable','' if on else ('1' if xbmc.Player().isPlayingVideo() else ''))
        elif pick==4:
            on=(ADDON.getSetting('meganexus_ai_subtitles') or 'true')!='false'
            ADDON.setSetting('meganexus_ai_subtitles','false' if on else 'true');settings_snapshot.invalidate()   # publish() reads the new value
            from resources.lib import ai_subtitles
            if not on and not ai_subtitles.configured():
                xbmcgui.Dialog().ok('AI subtitles','The AI button in the player needs your free Gemini API key: '
                                    'aistudio.google.com/apikey - then HUB Settings > API keys (or on your phone).')
            ai_subtitles.publish()
        elif pick==5:return page.DONE
    return page.show('Subtitles',rows,choose)
