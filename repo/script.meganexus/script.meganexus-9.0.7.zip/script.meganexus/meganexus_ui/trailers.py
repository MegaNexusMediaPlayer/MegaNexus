# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import xbmc
import xbmcgui
from resources.lib.trailer_support import trailer_url
from . import volume_fade
import time
import threading

_PLAYER=None
_CURTAIN=[None]


class _StopCurtain(xbmcgui.WindowXMLDialog):
    """Back / Esc do not lift it."""
    def onAction(self, action):
        pass


def _darken_for_stop():
    """7.0.32: leaving a film with Kodi's "Adjust display refresh rate" on - black
    at once, as at the film's start. The service's stop callback came 2 s late on
    CoreELEC, after the TV had blinked. It stays (zorder 10) while the TV switches
    back and the next screen opens behind it, then fades away (lift_curtain).
    7.0.42: with the setting off, the same cover in the theme's page colour with our
    ring - the window under the player flashed before the title page came back."""
    try:
        from resources.lib import curtain
        afr=curtain.afr_on()
        from .play_jobs import ROOT
        home=xbmcgui.Window(10000)
        if afr:home.clearProperty(curtain.RELEASE);home.setProperty(curtain.STOPPING,str(time.time()))
        from resources.lib.theme import folder
        window=_StopCurtain('meganexus_curtain.xml',ROOT,folder(),'1080i')
        if not afr:window.setProperty('meganexus.curtain.plain','1')
        window.show()
    except Exception as exc:
        xbmc.log('[MegaNexus] Stop curtain unavailable: %r'%exc,xbmc.LOGWARNING)
        return
    lifted=threading.Event()
    # 8.1.3: "izlazak iz filma u max 1 sekundi". The black waited for the service's stop
    # callback (2.3 s late on the Cube) and then 1.2 s more, whatever the TV did - 3.5 s
    # and more of black. Now it watches for itself: the player gone and the TV back in
    # the interface's mode (System.ScreenMode, kept as the film started), a breath for
    # the TV to show it, and away.
    film_mode=xbmc.getInfoLabel('System.ScreenMode');gui_mode=home.getProperty('meganexus.gui.mode')
    def run():
        monitor=xbmc.Monitor()
        if afr:
            until=time.monotonic()+4;gone=None
            while time.monotonic()<until and not home.getProperty(curtain.RELEASE):
                mode=xbmc.getInfoLabel('System.ScreenMode')
                if mode!=film_mode or (gui_mode and mode==gui_mode):
                    if mode!=film_mode:monitor.waitForAbort(.35)   # switched: the TV shows it
                    break
                if not xbmc.getCondVisibility('Player.HasVideo'):
                    gone=gone or time.monotonic()
                    if not gui_mode and time.monotonic()-gone>1.5:break   # nothing to tell us more
                if monitor.waitForAbort(.05):break
        lifted.wait(1.5 if afr else 3)                        # the next screen is drawn behind
        try:window.close()
        except Exception:pass
        monitor.waitForAbort(.8)                              # the fade ends while we live
        if afr:home.clearProperty(curtain.STOPPING);home.clearProperty(curtain.RELEASE)
    _CURTAIN[0]=lifted
    threading.Thread(target=run,name='MegaNexusStopCurtain',daemon=True).start()


def lift_curtain():
    """The screen after the film is shown: the black may fade away."""
    lifted,_CURTAIN[0]=_CURTAIN[0],None
    if lifted is not None:lifted.set()



def wait_for_playback(next_ok=False):
    """Close all dialogs before calling; don't reopen Home during AV/window startup.
    ``next_ok`` (9.0.0): the caller plays the next episode the player asked for
    (Window(Home).Property(meganexus.next_episode)) over the film - the wait ends at once,
    the film left as it is."""
    monitor=xbmc.Monitor();seen=False;start=time.monotonic()
    home=xbmcgui.Window(10000);request=home.getProperty('meganexus.playback.started')
    # 9.0.0: the film is on screen when this starts (the start waits for its picture). Kodi's
    # full-screen window already gone, with MegaNexus' base window up, is a Back pressed in
    # between - honoured: this used to bring the player straight back
    if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):seen=True
    elif xbmc.getCondVisibility('Window.IsActive(meganexus_session.xml)') and xbmc.Player().isPlayingVideo():seen=True
    else:xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    asked=0.;playing=False;away=None
    while not monitor.waitForAbort(.05):
        now=time.monotonic()
        if now-asked>=.5:            # 7.0.52: twice a second (it was 20 times), the window every turn
            playing=xbmc.Player().isPlayingVideo();asked=now
        if home.getProperty('meganexus.next_episode'):
            if next_ok:return
            # nothing here plays a next episode (a film started from Home's own paths):
            # the paused film is not left waiting - it plays on
            home.clearProperty('meganexus.next_episode')
            if xbmc.getCondVisibility('Player.Paused'):xbmc.executebuiltin('PlayerControl(Play)')
        full=xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
        if full:seen=True;away=None
        elif seen:away=away or now
        # 9.0.0: the player left for AWAY seconds - not for a blink. When a subtitle went on,
        # the TV switched modes and Kodi's full-screen window was gone for 0.2 s: that was
        # taken for Back and the film stopped by itself.
        # Back from the player lands on MegaNexus' base window: that one counts at once
        if seen and not full and (now-away>=AWAY or xbmc.getCondVisibility('Window.IsActive(meganexus_session.xml)')):
            # Leaving the player is Stop, so the service commits resume before
            # the same title page returns. Closing an OSD keeps fullscreen active.
            # 7.0.29: the player's Home button leaves the film playing behind Home,
            # "Now playing" brings it back.
            if not home.getProperty('meganexus.background_film'):
                playing=xbmc.Player().isPlayingVideo()
                if playing:
                    from resources.lib.player_state import leaving
                    leaving()           # 7.0.52: a Usenet film stops without waiting for an article
                    xbmc.log('[MegaNexus] The player was left (not by its Home button) - the film stops.',xbmc.LOGINFO)
                _darken_for_stop()
                if playing:xbmc.Player().stop()
            break
        if not playing and time.monotonic()-start>2:break
        if not seen and time.monotonic()-start>10:break
    if not xbmc.Player().isPlaying():
        home.clearProperty('meganexus.preview.active')
        # Let the service commit Stop before the details screen reads resume.
        # A missing service must not leave the UI waiting indefinitely.
        # The service saves progress and flags it within milliseconds; do not
        # keep the user staring at an empty screen longer than 0.8 s.
        for _ in range(40):
            if not request or home.getProperty('meganexus.playback.finished')==request:break
            if monitor.waitForAbort(.02):break

COVER_MAX=8.0         # 9.0.0: s at most the page a trailer starts from waits for the full-screen window
AWAY=.4               # 9.0.0: s without the player that mean it was left (a mode switch blinks shorter)
HANDOVER_SETTLE=1.5   # s Kodi gets to move a running clip into its full-screen window
BACK_WAIT=1.5         # 9.0.0: s at most the screens a trailer closes take to come back under its black
TRAILER_COVER='meganexus.trailer.cover'   # Window(Home): the session window shows black (meganexus_session.xml)


def take_over(previews,meta,parent=None):
    """A preview that is already playing this trailer steps up to full screen (8.1.2).

    Nothing is resolved and nothing is started: the clip is decoded and on screen, so
    this only takes the player over from the preview controller and asks Kodi for its
    full-screen window - the same step Sport and IPTV make. Clicking Trailer used to
    stop the preview and play the whole thing again from the beginning.

    Returns True when it took over; False means there was no live preview and the
    caller resolves and plays as before.
    """
    if previews is None:return False
    try:player=previews.hand_over()
    except Exception:player=None
    if player is None:return False
    return _full_screen_trailer('',meta,parent,player=player)


def _full_screen_trailer(url,meta,parent=None,player=None):
    """Kodi's own full-screen player, like a film: the screen behind it is hidden
    (a MegaNexus screen in front keeps Kodi's player from opening), Back or the
    end of the trailer brings it back."""
    import uuid
    from .home_trailers import PreviewPlayer
    from resources.lib import refresh_guard
    # `player` given: it is already playing this trailer small (take_over) - nothing to
    # start, only the screen to change.
    handed=player is not None
    if not handed:
        player=PreviewPlayer();player.token=uuid.uuid4().hex
    monitor=xbmc.Monitor();home=xbmcgui.Window(10000)
    item=xbmcgui.ListItem(label='Trailer: '+str(meta.get('name') or meta.get('title') or ''))
    item.setProperty('meganexus.preview',player.token);item.setProperty('IsPlayable','true')
    home.setProperty('meganexus.preview.active',player.token)
    started=False;hidden=False;others=[];fading=False;waiting=not handed
    def hide_screens():
        nonlocal hidden
        if parent is not None:
            xbmcgui.WindowXMLDialog.close(parent);hidden=True
        # 7.0.46: the screens under it hide too, as for a film (playback._hide_parents) -
        # a title opened in place keeps Home open under it, and Home stayed over the trailer
        from .play_jobs import PARENTS
        for other in list(PARENTS):
            if other is parent or getattr(other,'_meganexus_play_hidden',True):continue
            try:xbmcgui.WindowXMLDialog.close(other);others.append(other)
            except Exception:pass
    try:
        home.setProperty(TRAILER_COVER,player.token)   # 9.0.0: black under it, never the bare picture
        refresh_guard.suspend('trailer')
        # 9.0.0: a trailer that starts here plays under the page it was opened from, which
        # goes once Kodi shows it full screen - no loading screen and no moment of the bare
        # picture between them (the page used to go first)
        if handed:hide_screens()
        if handed:
            # already decoded and running: Kodi's own full-screen window, no reload
            started=True
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        else:
            fading=volume_fade.begin(after_click=True)   # 8.1.4: the sound comes up as the trailer starts
            from .home_trailers import tell_type
            tell_type(item,url)
            player.path=url;player.play(url,item)
        begin=time.monotonic();full_since=None
        while not monitor.abortRequested():
            if player.owns() and (player.ready or player.getTime()>.15):
                if not started and fading:volume_fade.ramp()
                started=True
            full=xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
            if waiting and started:
                # the trailer's picture moves: Kodi's full-screen window, then the page goes
                # (one that never starts leaves the page where it is)
                if full or time.monotonic()-begin>COVER_MAX:
                    waiting=False;hide_screens()
                else:xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            if full and full_since is None:full_since=time.monotonic()
            # A handed-over clip is already running, so `started` is true from the first
            # round - and Kodi can answer isPlayingVideo() false for a moment while it
            # swaps the video to its full-screen window. Without this grace the loop
            # would break at once and the finally below would stop the very trailer it
            # was asked to enlarge (8.1.2).
            settled=not handed or time.monotonic()-begin>HANDOVER_SETTLE
            if player.failed or (started and settled and not player.isPlayingVideo()):break
            if full_since is not None and not full and time.monotonic()-full_since>1:break   # Back
            if not started and time.monotonic()-begin>8:break
            monitor.waitForAbort(.1)
    finally:
        volume_fade.restore()                 # gone before its sound was up: back at once
        player.cancel();player.stop_owned();player._ended()
        home.clearProperty('meganexus.preview.active')
        refresh_guard.restore('trailer')
        _bring_back(others+([parent] if hidden else []))
        home.clearProperty(TRAILER_COVER)
    return started


def _bring_back(screens):
    """9.0.0: the screens the trailer was opened from, back all at once - Home first, the title
    page over it - and the black under them goes once every one of them is ready. One by one,
    Home stood alone for a moment (it waited for Kodi to open it) before the title page came,
    and the bare picture showed before either."""
    waiting=[]
    for screen in screens:
        ready=getattr(screen,'_xml_ready',None)
        try:
            if ready is None:screen.show_ready();continue
            ready.clear();screen.show();waiting.append(screen)
        except Exception:pass
    monitor=xbmc.Monitor();until=time.monotonic()+BACK_WAIT
    while waiting and time.monotonic()<until and not monitor.abortRequested():
        waiting=[s for s in waiting if not (s._xml_ready.is_set() or getattr(s,'_dialog_closed',False))]
        if waiting:monitor.waitForAbort(.01)


def play_trailer(meta):
    return show_trailer(meta)


def show_trailer(meta,parent=None,ready=''):
    """Resolve/cache first, then play it in Kodi's own full-screen player
    (7.0.31, every device: the user prefers it, and boxes whose video is a
    hardware layer under the interface showed the trailer window black on
    Kodi 22). ``parent`` - the screen it was started from - is hidden meanwhile."""
    from .play_jobs import job
    from resources.lib.trailer_cache import prepare
    if xbmc.Player().isPlayingVideo():
        xbmcgui.Dialog().ok('Trailer','Stop the current video before opening a trailer.');return False
    # 7.0.47: the link found while the title page was open - no ring; when it does not
    # play (an old link), it is looked up again as before
    if ready and _full_screen_trailer(ready,meta,parent):return True
    cancelled=threading.Event()
    def resolve():
        # Trailer source order from Settings > Trailers (YouTube and/or IMDb).
        from resources.lib.trailer_support import trailer_candidates,playable
        for candidate in trailer_candidates(trailer_url(meta),(meta,)):
            path=playable(candidate,prepare,cancelled)
            if path or cancelled.is_set():return path
        return ''
    try: url=job(resolve,None,label='')   # 7.0.37: only the blue ring until the trailer shows
    finally: cancelled.set()
    if not url:
        # A resolution failure never reaches Kodi's playback queue.
        return False
    return _full_screen_trailer(url,meta,parent)
