"""MegaNexus interface entry point."""
import os
import sys
import uuid
import xbmc
import xbmcaddon
import xbmcgui

backend = xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('path')
for path in (backend, os.path.join(backend, 'resources', 'lib')):
    if path not in sys.path: sys.path.insert(0, path)

home = xbmcgui.Window(10000)
try:
    # 7.0.21: opened before the service carried out a requested reset.
    from resources.lib import factory_reset
    factory_reset.apply()
except Exception as exc:
    xbmc.log('[MegaNexus] factory reset check failed: %s' % exc, xbmc.LOGERROR)
try:
    # 7.0: opened before the service moved the previous installation.
    from resources.lib import rename_migration
    rename_migration.run()
except Exception as exc:
    xbmc.log('[MegaNexus] move from previous IDs failed: %s' % exc, xbmc.LOGERROR)
def finish_jobs():
    module=sys.modules.get('meganexus_ui.playback')
    if module:module._JOBS.shutdown();module._BACKGROUND.shutdown();module._CATALOG.shutdown()
    try:
        from resources.lib import script_exit
        script_exit.stop()   # 7.0.5: idle workers kept Kodi from closing
    except Exception:
        pass
    if xbmc.Monitor().abortRequested():
        # 7.0.29: what is still busy while Kodi closes (it hung waiting on it).
        import threading
        busy=[t.name for t in threading.enumerate() if t is not threading.current_thread() and t.is_alive()]
        if busy:xbmc.log('[MegaNexus] Interface still running at exit: %s'%', '.join(sorted(busy)),xbmc.LOGINFO)

def launch():
    token=uuid.uuid4().hex
    home.setProperty('meganexus.frontend.running', token)
    session=None
    try:
        from resources.lib.saver_state import wake_for_entry
        wake_for_entry()
        # 7.0.16: the HUB picture first - on Android the rest of the start takes a
        # moment and Kodi showed its own busy spinner meanwhile.
        from resources.lib import interface_colors
        interface_colors.publish()
        if mode not in ('settings','skinsettings','themes','badges'):
            from meganexus_ui.session import open_session
            session=open_session()
        from resources.lib import settings_cache
        from meganexus_ui.system_setup import execute_command
        settings_cache.invalidate()
        from resources.lib.presentation_settings import sync as sync_appearance
        sync_appearance()
        try:
            from resources.lib import theme
            theme.sync()  # MegaNexus skin follows the chosen theme (6.0.28)
        except Exception:xbmc.log('[MegaNexus] Theme sync skipped.',xbmc.LOGWARNING)
        try:
            from resources.lib.seek_profile import apply
            apply()
        except Exception:xbmc.log("[MegaNexus] Could not restore original Kodi seek controls.",xbmc.LOGWARNING)
        if mode == 'iptv':
            from meganexus_ui.iptv import open_iptv
            open_iptv()
        elif mode == 'sports':
            # 6.0.35: sports add-ons have their own screen (GitHub issue #8).
            from meganexus_ui.sports import open_sports
            open_sports()
        elif mode == 'wizard':
            from meganexus_ui.onboarding import run as setup
            command=setup(force=True)
            if command:execute_command(command)
            from meganexus_ui.home_window import open_home
            if not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):open_home()
        elif mode == 'phone':
            # HUB / backend entry: after Save on the phone MegaNexus starts.
            from meganexus_ui.phone_setup import run as phone
            if phone():
                from meganexus_ui.onboarding import _finish
                _finish()
                from meganexus_ui.home_window import open_home
                open_home()
            else:xbmc.executebuiltin('ActivateWindow(Home)')
        elif mode == 'badges':
            from meganexus_ui.settings import badge_settings
            command=badge_settings()
            if command:execute_command(command)
        elif mode == 'themes':
            from meganexus_ui.settings import themes_screensaver
            command=themes_screensaver()
            if command:execute_command(command)
        elif mode == 'skinsettings':
            from meganexus_ui.settings import run
            command=run(back_command='ActivateWindow(Home)')
            if command:execute_command(command)
        elif mode == 'settings':
            from meganexus_ui.settings import run
            command=run()
            if command:execute_command(command)
            else:xbmc.executebuiltin('ActivateWindow(Home)')
        elif mode == 'open' and len(sys.argv) > 2:
            from resources.lib import cache_store
            from meganexus_ui.details import open_context
            command = open_context(cache_store.get('meganexus_open', sys.argv[2]) or {})
            if isinstance(command,dict) and 'trailer' in command:
                from meganexus_ui.trailers import play_trailer,wait_for_playback
                if play_trailer(command['trailer']):wait_for_playback()
                command=''
            if command=='playing':
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            elif command: xbmc.executebuiltin(command)
        else:
            # 7.0: MegaNexus Skin is required. Nothing else starts (system check,
            # first-start setup) until it is active, so Kodi's "Keep this skin?"
            # question is never covered.
            from resources.lib import skin_activation
            if xbmc.getSkinDir()!=skin_activation.SKIN:
                # "No" in Kodi's question is respected this session (no second ask).
                status=skin_activation.switch() if skin_activation.wanted() else 'declined'
                if status!='ok':
                    if status=='failed':skin_activation.report_failure()
                    else:xbmcgui.Dialog().ok('MegaNexus','MegaNexus needs MegaNexus Skin. Open MegaNexus again and choose Yes when Kodi asks to keep the skin.')
                    return
            try:
                # 6.0.37: add-ons that overload Kodi - clean install, turn off or Skip.
                from meganexus_ui.system_check import run as system_check
                system_check()
            except Exception:xbmc.log('[MegaNexus] System check skipped.',xbmc.LOGWARNING)
            from meganexus_ui.onboarding import run as setup
            command=setup()
            if command:execute_command(command)
            from meganexus_ui.home_window import open_home
            if not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):open_home()
    except Exception:
        import traceback
        # The cause belongs in kodi.log (6.0.37): the message alone hid it.
        xbmc.log('[MegaNexus] Interface failed: ' + traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('MegaNexus', 'Could not open the interface. Open MegaNexus settings to repair the bundled components or check your provider configuration.')
    finally:
        if session:session.close()
        finish_jobs()
        if home.getProperty('meganexus.frontend.running')==token:
            home.clearProperty('meganexus.frontend.running')


mode = sys.argv[1] if len(sys.argv) > 1 else 'home'
if mode=='subtitles':
    from meganexus_ui.subtitles import run
    try:run()
    finally:finish_jobs()
elif mode=='autosync':
    # 7.0.29: the player's Autosync subtitle button.
    from meganexus_ui.subtitles import autosync
    try:autosync()
    finally:finish_jobs()
elif mode=='audio':
    # 7.0.24: the player's audio button.
    from meganexus_ui.audio_streams import run
    try:run()
    finally:finish_jobs()
elif mode=='switch_source':
    # 7.0.29: the player's Sources button - pause, choose another source, carry on.
    from meganexus_ui.playback import switch_source
    try:switch_source()
    finally:finish_jobs()
elif mode=='downloads':
    # 7.0.29: the corner's download ring - the progress box (or the list).
    from meganexus_ui.downloads import progress
    try:progress()
    finally:finish_jobs()
elif mode=='phonetype':
    # 7.0.29: the keyboard's "Write with phone" (also while MegaNexus is open).
    from meganexus_ui.phone_setup import write_with_phone
    try:write_with_phone()
    finally:finish_jobs()
elif mode=='player_home':
    # 7.0.29: the player's Home button - the film pauses, "Now playing" brings it back.
    from resources.lib.foreground_guard import park
    park()
elif mode=='tracking-check':
    import json,time
    from resources.lib.tracking_connections import check_connections
    try:
        result=check_connections();result['checked_at']=time.time()
        home.setProperty('meganexus.tracking.check',json.dumps(result))
    finally:finish_jobs()
elif mode=='saverpreview':
    # 7.0.25: "Show on TV" of the phone page - the screensaver over the QR
    # screen until a key is pressed.
    from meganexus_ui.saver import preview
    try:preview()
    finally:finish_jobs()
elif home.getProperty('meganexus.frontend.running'):
    # One modal interface at a time, including on skin reload/activation.
    pass
else:
    restarting=False
    try:
        # An installed update waiting for a Kodi restart: ask before the
        # interface opens ("Later" asks again at the next entry).
        from resources.lib import updater
        restarting=updater.prompt_at_entry()
    except Exception:
        xbmc.log('[MegaNexus] Restart reminder skipped.',xbmc.LOGDEBUG)
    if not restarting:
        launch()
