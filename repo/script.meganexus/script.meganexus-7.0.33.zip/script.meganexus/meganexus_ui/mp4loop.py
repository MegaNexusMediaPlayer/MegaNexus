"""Compatibility import for the shared, pure Python silent-loop builder."""
import sys
from resources.lib import mp4loop as _shared
sys.modules[__name__] = _shared
