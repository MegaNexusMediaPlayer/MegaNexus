"""The imported badge set's sample: the same Nuvio-style strip as the source rows."""
import xbmcaddon
from .dialog import Dialog,BACK
from resources.lib.theme import folder


class Preview(Dialog):
    def onInit(self):self.setFocusId(100)
    def onClick(self,cid):self.close()
    def onAction(self,action):
        if action.getId() in BACK:self.close()


def preview(state):
    win=Preview('meganexus_badges.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),folder(),'1080i')
    win.setProperty('example',state['example'])
    badges=state.get('preview') or []
    pictures=[p for p in (badge.get('kodi_image') or badge.get('image') for badge in badges) if p][:8]
    for index,picture in enumerate(pictures):win.setProperty('badge%d.img'%index,picture)
    win.setProperty('badgetext','' if pictures else '  ·  '.join(badge['name'] for badge in badges))
    try:win.doModal()
    finally:win.close()
