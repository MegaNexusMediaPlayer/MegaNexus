"""TV side of "Set up on phone": QR window that owns the local setup service.

The service (resources.lib.phone_setup) starts when this window opens and is
stopped when it closes: Save on the phone, Back/Cancel on the TV, or 15 idle
minutes. Nothing keeps listening afterwards.
"""
import os
import time
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import settings_cache
from resources.lib.theme import folder as theme_folder

POLL = .25
ACTIVE_HOLD = 5 * 60   # seconds after the phone's last request the screensaver stays away
SETUP_TITLE = 'Set up on your phone'
SETUP_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
               '3. Set up accounts, add-ons and collections, then tap [B]Save & start MegaNexus[/B].[CR][CR]'
               'The setup service runs only while this screen is open.')
TYPE_TITLE = 'Write with phone'
TYPE_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
              '3. Type the text and tap [B]Send to TV[/B] - it goes into the keyboard and OK is pressed.')
REPORT_TITLE = 'Report a problem'
REPORT_STEPS = ('1. Connect the phone to the same Wi-Fi as this TV.[CR]2. Scan the code with the phone camera.[CR]'
                '3. Describe what went wrong and tap [B]Send report[/B].[CR][CR]It reaches the MegaNexus developer as a '
                'GitHub issue with the Kodi log - personal data removed.')
HINT_AFTER = 30   # seconds without the phone -> say what usually blocks it


class PhoneWindow(xbmcgui.WindowXMLDialog):
    # Callbacks only set flags; the owning loop in run() does the work.
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.qr = kwargs.get('qr') or ''
        self.url = kwargs.get('url') or ''
        self.title = kwargs.get('title') or SETUP_TITLE
        self.steps = kwargs.get('steps') or SETUP_STEPS
        self.cancelled = False

    def onInit(self):
        self.setProperty('meganexus.phone.qr', self.qr)
        self.setProperty('meganexus.phone.url', self.url)
        self.setProperty('meganexus.phone.title', self.title)
        self.setProperty('meganexus.phone.steps', self.steps)
        self.setProperty('meganexus.phone.status', 'Waiting for the phone…')
        self.setFocusId(100)

    def onClick(self, cid):
        if cid == 100:
            self.cancelled = True
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61448, 61467):
            self.cancelled = True
            self.close()


def run(report=False, typing=None):
    """Returns True when the phone saved the setup (or sent the report). With
    ``typing`` (the keyboard's heading / text / hidden): the phone's text, or None."""
    from resources.lib.phone_setup import SetupService, REPORT_PAGE, TYPE_PAGE
    from resources.lib.plex_qr import qr_png
    from resources.lib.phone_setup import lan_ip
    host = lan_ip()
    if host.startswith('127.'):
        xbmcgui.Dialog().ok('Set up on phone', 'This device is not connected to a network. Connect it to the same Wi-Fi '
                            'as your phone and try again.')
        return False
    try:
        if typing is not None:
            service = SetupService(host=host, page=TYPE_PAGE, only={'/api/type'})
            service.typing = dict(typing)
            service.start()
        else:
            service = (SetupService(host=host, page=REPORT_PAGE, only={'/api/report'}) if report
                       else SetupService(host=host)).start()
        SetupService.last_report = None
    except OSError:
        xbmcgui.Dialog().ok('Set up on phone', 'The setup service could not start on this device. '
                            'Check the network connection and try again.')
        return False
    qr = ''
    window = None
    saved = False
    try:
        qr = qr_png(service.url, box_size=10, border=2) or ''
        window = PhoneWindow('meganexus_phone_setup.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),
                             theme_folder(),'1080i', qr=qr, url=service.url,
                             title=TYPE_TITLE if typing is not None else REPORT_TITLE if report else SETUP_TITLE,
                             steps=TYPE_STEPS if typing is not None else REPORT_STEPS if report else SETUP_STEPS)
        window.show()
        monitor = xbmc.Monitor()
        connected = False
        held = False
        waited = 0.0
        while not window.cancelled and not monitor.abortRequested():
            waited += POLL
            # 7.0.29: no screensaver while the phone is in use - it broke the phone's
            # connection. Only then: with no phone, or one left unused for ACTIVE_HOLD,
            # the screensaver comes as usual (the TV never stayed on the QR code for ever).
            in_use = service.connected and time.monotonic() - service.last_seen < ACTIVE_HOLD
            if in_use != held:
                held = in_use
                xbmc.executebuiltin('InhibitScreensaver(%s)' % ('true' if held else 'false'))
            if not connected and abs(waited - HINT_AFTER) < POLL / 2:
                window.setProperty('meganexus.phone.status', 'No phone yet? Use the same Wi-Fi. A firewall here must allow TCP port %d.' % service.port)
            if service.saved:
                saved = True
                break
            if service.connected and not connected:
                connected = True
                window.setProperty('meganexus.phone.status', 'Phone connected · waiting for the text' if typing is not None
                                   else 'Phone connected · waiting for the report' if report
                                   else 'Phone connected · waiting for Save')
            if service.idle():
                break
            if monitor.waitForAbort(POLL):
                break
    finally:
        xbmc.executebuiltin('InhibitScreensaver(false)')
        if window:
            window.close()
        service.stop()
        if qr:
            try:
                os.remove(qr)  # the QR carries this session's key
            except OSError:
                pass
    if typing is not None:
        return service.typed if saved else None
    if saved and report:
        sent = SetupService.last_report or {}
        xbmcgui.Dialog().ok('Report a problem', 'Thank you! Report #%s was sent.[CR]%s' % (sent.get('number') or '', sent.get('url') or ''))
        return True
    if saved:
        settings_cache.invalidate()
        try:
            from .browse_meta import clear
            clear()  # card shape, ratings or catalogs may have changed
        except Exception:
            pass
        xbmcgui.Dialog().notification('MegaNexus', 'Setup saved from the phone', xbmcgui.NOTIFICATION_INFO, 3000)
    return saved


def write_with_phone():
    """7.0.29: the keyboard's "Write with phone" - the phone's text into the keyboard, then OK."""
    import json
    if not xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)'):
        return
    hidden = bool(xbmc.getCondVisibility('System.HasHiddenInput'))
    # the phone's field starts empty (what the keyboard holds is not sent there)
    typing = {'heading': xbmc.getInfoLabel('Control.GetLabel(311)'), 'hidden': hidden}
    text = run(typing=typing)
    if text is None or not xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)'):
        return
    xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Input.SendText',
                                    'params': {'text': text, 'done': True}}))
