"""Timings in kodi.log (7.0.30): ``[MegaNexus][perf] <what>: <ms> ms``.

How long Home, a collection or a grid takes on this device - read on a box
before and after a change. One line per step, only for steps a person waits for.
"""
import time

import xbmc


class timed:
    def __init__(self, what, **details):
        self.what, self.details = what, details

    def __enter__(self):
        self.start = time.monotonic()
        return self

    def __exit__(self, *_):
        ms = (time.monotonic() - self.start) * 1000
        extra = ''.join(' %s=%s' % item for item in self.details.items())
        try:
            xbmc.log('[MegaNexus][perf] %s: %d ms%s' % (self.what, ms, extra), xbmc.LOGINFO)
        except Exception:
            pass
        return False
