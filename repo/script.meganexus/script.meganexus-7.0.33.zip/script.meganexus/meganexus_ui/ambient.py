"""MegaNexus Ambient - the screensaver's own widget engine (7.0.24).

Google TV-like: the picture (or slideshow) with a slow pan, soft scrims at
the top and bottom, and widgets - clock, weather, calendar, a text. Each
widget has only a few choices: a ready-made design (or off), its size (small,
normal, large), a colour and a position (eight places; the top-right corner keeps the weather and clock of
every MegaNexus screen). The scene is JSON in the setting
meganexus_ambient_scene and is edited live over the screensaver itself
(Screensaver studio: Left / Right change, the result shows at once).

The window (meganexus_screensaver.xml, made by review/make_ambient_window.py)
draws the designs with the MegaNexus Ambient fonts (Google Sans, Fraunces,
Oxanium in skin.meganexus/fonts/ambient); this module sets its properties
meganexus.amb.*, places the widget groups and keeps time, date, weather and
calendar current. Every three minutes the widgets move a few pixels (OLED burn-in).
"""
import calendar
import copy
import json
import random
import re
import time

import xbmc
import xbmcaddon

SETTING = 'meganexus_ambient_scene'
GROUPS = {'clock': 8100, 'weather': 8200, 'calendar': 8300, 'text': 8400}
CALENDAR_PANEL = 8350
EDIT_GROUP, EDIT_LIST = 8900, 8901
WIDGETS = ('clock', 'weather', 'calendar', 'text')
WIDGET_LABELS = {'clock': 'Clock', 'weather': 'Weather', 'calendar': 'Calendar', 'text': 'Text'}
# Top right is the weather / clock corner of every MegaNexus screen.
POSITIONS = ('bottom-left', 'bottom-center', 'bottom-right', 'middle-left', 'center', 'middle-right',
             'top-left', 'top-center')
POSITION_LABELS = {'top-left': 'Top left', 'top-center': 'Top centre',
                   'middle-left': 'Middle left', 'center': 'Centre', 'middle-right': 'Middle right',
                   'bottom-left': 'Bottom left', 'bottom-center': 'Bottom centre', 'bottom-right': 'Bottom right'}
# Ready-made designs: (key, label, width, height as drawn at 1080p).
DESIGNS = {
    'clock': (('google', 'Ambient · time and weather', 1000, 210), ('stack', 'Stacked', 440, 420),
              ('chip', 'Chip', 600, 112), ('classic', 'Classic serif', 900, 290), ('digital', 'Digital', 900, 240)),
    'weather': (('chip', 'Chip', 520, 104), ('card', 'Card', 460, 300), ('forecast', 'Forecast · 5 days', 660, 450)),
    'calendar': (('month', 'Month', 500, 476), ('date', 'Today', 280, 300), ('week', 'Week', 640, 150)),
    'text': (('caption', 'Caption', 1000, 120), ('quote', 'Quote', 1000, 280)),
}
OFF = 'off'
# Material You tones: the accent, and its tonal surface for cards and chips.
COLORS = {'white': 'FFE8EAED', 'blue': 'FFA8C7FA', 'teal': 'FF7FD8D4', 'green': 'FFA8DAB5',
          'yellow': 'FFFDD663', 'orange': 'FFFFB68A', 'pink': 'FFFFB1C8', 'purple': 'FFD3BBFF'}
COLOR_LABELS = {'white': 'White', 'blue': 'Blue', 'teal': 'Teal', 'green': 'Green',
                'yellow': 'Yellow', 'orange': 'Orange', 'pink': 'Pink', 'purple': 'Purple'}
SURFACE_BASE, SURFACE_ALPHA, SURFACE_TINT = (0x1E, 0x1F, 0x22), 'C7', .16
SOFT = 'CCFFFFFF'            # secondary text (date, condition, low)
ON_ACCENT = 'FF1F1F1F'       # text on an accent fill (today)
SPEEDS = (15, 30, 60)
MARGIN_X, MARGIN_Y, GAP = 96, 80, 48
SHIFT = 6                    # OLED: pixels the widgets wander every SHIFT_EVERY seconds
SHIFT_EVERY = 180            # 7.0.25: rarer and smaller (12 px each minute was visible)
WEATHER_ICON = 'special://home/addons/script.meganexus/resources/media/ambient/weather/%s.png'
# Kodi's weather codes (the Yahoo set every weather add-on uses) -> our colour
# icons; review/make_weather_icons.py reads this table for the corner icons.
WEATHER_KINDS = {}
for _kind, _codes in (('thunder', (0, 1, 2, 3, 4, 37, 38, 39, 45, 47)), ('sleet', (5, 6, 7, 8, 10, 17, 18, 35)),
                      ('rain', (9, 11, 12)), ('showers', (40,)), ('snow', (13, 14, 15, 16, 41, 42, 43, 46)),
                      ('fog', (19, 20, 21, 22)), ('wind', (23, 24)), ('cloudy', (25, 26)),
                      ('partly_night', (27, 29)), ('partly_day', (28, 30, 44)), ('moon', (31, 33)), ('sun', (32, 34, 36))):
    for _code in _codes:
        WEATHER_KINDS[str(_code)] = _kind

# 7.0.26: widget sizes - Large is the 7.0.24 size, Normal 25 % and Small 50 %
# smaller; every size is its own layout in the window (no zoom).
SIZES = ('S', 'M', 'L')
SIZE_LABELS = {'S': 'Small', 'M': 'Normal', 'L': 'Large'}
SIZE_SCALE = {'S': .5, 'M': .75, 'L': 1.0}
WIDGET_DEFAULTS = {
    'clock': {'design': 'google', 'color': 'white', 'pos': 'bottom-left', 'size': 'M'},
    'weather': {'design': OFF, 'color': 'white', 'pos': 'top-left', 'size': 'M'},
    'calendar': {'design': OFF, 'color': 'blue', 'pos': 'bottom-right', 'size': 'M'},
    'text': {'design': OFF, 'color': 'white', 'pos': 'bottom-center', 'size': 'M', 'value': ''},
}
SCENE_DEFAULTS = {'speed': 30}
# Scenes saved by the first 7.0.24 test builds (on / style / size / card).
_OLD_CLOCK = {'thin': 'google', 'rounded': 'google', 'bold': 'stack', 'digital': 'digital', 'elegant': 'classic'}
_OLD_COLOR = {'ice': 'blue', 'gold': 'yellow', 'mint': 'green', 'rose': 'pink'}


def designs(name):
    return tuple(d[0] for d in DESIGNS[name])


def design_label(name, key):
    return 'Off' if key == OFF else dict((d[0], d[1]) for d in DESIGNS[name])[key]


# --------------------------------------------------------------- scene ---

def _migrate(name, saved):
    saved = dict(saved)
    if 'design' not in saved and 'on' in saved:
        if not saved.get('on'):
            saved['design'] = OFF
        elif name == 'clock':
            saved['design'] = _OLD_CLOCK.get(saved.get('style'), 'google')
        elif name == 'weather':
            saved['design'] = 'forecast' if saved.get('forecast') else 'card'
        else:
            saved['design'] = {'calendar': 'month', 'text': 'caption'}[name]
    saved['color'] = _OLD_COLOR.get(saved.get('color'), saved.get('color'))
    if saved.get('pos') == 'top-right':
        saved['pos'] = 'middle-right'
    return saved


def normalize(data):
    """A complete, valid scene from whatever was saved."""
    data = data if isinstance(data, dict) else {}
    scene = copy.deepcopy(SCENE_DEFAULTS)
    if data.get('speed') in SPEEDS:
        scene['speed'] = data['speed']
    for name, defaults in WIDGET_DEFAULTS.items():
        saved = _migrate(name, data.get(name) if isinstance(data.get(name), dict) else {})
        widget = copy.deepcopy(defaults)
        if saved.get('design') in designs(name) + (OFF,):
            widget['design'] = saved['design']
        if saved.get('color') in COLORS:
            widget['color'] = saved['color']
        if saved.get('pos') in POSITIONS:
            widget['pos'] = saved['pos']
        if saved.get('size') in SIZES:
            widget['size'] = saved['size']
        if 'value' in defaults and isinstance(saved.get('value'), str):
            widget['value'] = saved['value'].strip()[:200]
        scene[name] = widget
    return scene


def load(addon=None):
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    try:
        return normalize(json.loads(addon.getSetting(SETTING) or '{}'))
    except (ValueError, TypeError):
        return normalize({})


def save(scene, addon=None):
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    addon.setSetting(SETTING, json.dumps(normalize(scene), sort_keys=True))


def summary(scene, name):
    widget = scene[name]
    if widget['design'] == OFF:
        return 'Off'
    return '%s · %s · %s · %s' % (design_label(name, widget['design']).split(' · ')[0], SIZE_LABELS[widget['size']],
                                  COLOR_LABELS[widget['color']], POSITION_LABELS[widget['pos']])


def scene_summary(scene):
    shown = [WIDGET_LABELS[n] for n in WIDGETS if scene[n]['design'] != OFF]
    return ', '.join(shown) if shown else 'Picture only'


# -------------------------------------------------------------- layout ---

def box(name, widget):
    """(width, height) of a widget's design at its size (rounded as the window draws it)."""
    k = SIZE_SCALE.get(widget.get('size'), 1.0)
    for key, _, width, height in DESIGNS[name]:
        if key == widget['design']:
            return int(round(width * k)), int(round(height * k))
    return 0, 0


def layout(scene, width=1920, height=1080):
    """{widget: (x, y, align)} - shown widgets on the screen; a widget in a
    corner grows from that corner. Two in the same place stack (downwards
    from the top, upwards from the bottom)."""
    result = {}
    used = {}
    for name in [n for n in WIDGETS if scene[n]['design'] != OFF]:
        widget = scene[name]
        w, h = box(name, widget)
        if widget['pos'] == 'center':
            row, col = 'middle', 'center'
        else:
            row, _, col = widget['pos'].partition('-')
        if col == 'center':
            left, align = (width - w) / 2, 'center'
        elif col == 'left':
            left, align = MARGIN_X, 'left'
        else:
            left, align = width - MARGIN_X - w, 'right'
        stack = used.get(widget['pos'], 0)
        if row == 'top':
            top = MARGIN_Y + stack
        elif row == 'bottom':
            top = height - MARGIN_Y - h - stack
        else:
            top = (height - h) / 2 + stack
        used[widget['pos']] = stack + h + GAP
        result[name] = (int(round(left)), int(round(top)), align)
    return result


def surface(color):
    """The accent's tonal surface: a dark card lightly tinted by it."""
    accent = [int(COLORS[color][i:i + 2], 16) for i in (2, 4, 6)]
    tinted = [int(round(b + (a - b) * SURFACE_TINT)) for a, b in zip(accent, SURFACE_BASE)]
    return SURFACE_ALPHA + ''.join('%02X' % v for v in tinted)


def main_color(color):
    """Big text: white for White, the accent otherwise."""
    return 'FFFFFFFF' if color == 'white' else COLORS[color]


# ------------------------------------------------------------- content ---

def twelve_hour():
    """Kodi's region decides (Settings > Interface > Regional), like the corner clock."""
    try:
        region = xbmc.getRegion('time')
        return '%I' in region or '%l' in region
    except Exception:
        return False


def clock_parts(now=None, twelve=False):
    """(time, hours, minutes) - Google TV style, no AM / PM."""
    now = time.localtime(now)
    hour = (now.tm_hour % 12 or 12) if twelve else now.tm_hour
    hours = ('%d' % hour) if twelve else ('%02d' % hour)
    minutes = '%02d' % now.tm_min
    return '%s:%s' % (hours, minutes), hours, minutes


def degrees(value):
    """'18°C' / '18 °C' / '18' -> '18°'."""
    value = str(value or '').strip()
    found = re.match(r'(-?\d+(?:[.,]\d+)?)', value)
    return (found.group(1) + '°') if found else value


def weather_icon(code):
    code = str(code or '').strip()
    kind = WEATHER_KINDS.get(code)
    return WEATHER_ICON % kind if kind else ''


def weather(info, days=5):
    """Window properties of the weather designs from Kodi's weather labels:
    now (icon, temperature, condition, today's high / low, place) and the
    next days (Day0 = today)."""
    prop = lambda key: info('Window(Weather).Property(%s)' % key)
    if not info('Weather.Location') and not weather_icon(info('Weather.FanartCode')):
        # No place set in the weather add-on: Kodi still reports 0 °C (32 °F)
        # and Weather.IsFetched - an empty reading, so the widget stays hidden.
        days = 0
        info = lambda label: ''
    high, low = prop('Day0.HighTemp'), prop('Day0.LowTemp')
    values = {'w.temp': degrees(info('Weather.Temperature')), 'w.cond': info('Weather.Conditions'),
              'w.place': info('Weather.Location').split(',')[0].strip(),
              'w.icon': weather_icon(info('Weather.FanartCode')),
              'w.hilo': ('↑%s  ↓%s' % (degrees(high), degrees(low))) if high and low else ''}
    for day in range(5):
        title = prop('Day%d.Title' % day) if day < days else ''
        values['w.d%d.name' % day] = title[:3]
        values['w.d%d.high' % day] = degrees(prop('Day%d.HighTemp' % day)) if title else ''
        values['w.d%d.low' % day] = degrees(prop('Day%d.LowTemp' % day)) if title else ''
        values['w.d%d.icon' % day] = weather_icon(prop('Day%d.FanartCode' % day)) if title else ''
    return values


def _names(localized):
    """Kodi's month names, weekday names and short weekday names (Monday first)."""
    localized = localized or (lambda number: '')
    months = [localized(21 + i) or calendar.month_name[i + 1] for i in range(12)]
    days = [localized(11 + i) or calendar.day_name[i] for i in range(7)]
    short = [localized(41 + i) or calendar.day_abbr[i] for i in range(7)]
    return months, days, short


def month(today=None, localized=None):
    """(title, weekday headers, 42 cells [(day or '', today)]) - Monday first."""
    today = time.localtime(today)
    months, _, short = _names(localized)
    heads = [day[:2].upper() for day in short]
    first, count = calendar.monthrange(today.tm_year, today.tm_mon)
    cells = [('', False)] * first + [(str(d), d == today.tm_mday) for d in range(1, count + 1)]
    cells += [('', False)] * (42 - len(cells))   # index % 7 >= 5: Saturday, Sunday
    return '%s %d' % (months[today.tm_mon - 1], today.tm_year), heads, cells[:42]


def dates(now=None, localized=None):
    """Properties of the date lines, the Today tile and the Week strip."""
    moment = time.localtime(now)
    months, days, short = _names(localized)
    month_name = months[moment.tm_mon - 1]
    values = {'date': '%s, %d %s' % (days[moment.tm_wday], moment.tm_mday, month_name),
              'date.short': '%s %d %s' % (short[moment.tm_wday], moment.tm_mday, month_name[:3]),
              'cal.wday': days[moment.tm_wday], 'cal.day': str(moment.tm_mday),
              'cal.month': month_name, 'wk.today': str(moment.tm_wday)}
    noon = time.mktime((moment.tm_year, moment.tm_mon, moment.tm_mday, 12, 0, 0, 0, 0, -1))
    for i in range(7):
        day = time.localtime(noon + (i - moment.tm_wday) * 86400)   # noon: safe across a DST change
        values['wk.h%d' % i] = short[i][:2].upper()
        values['wk.d%d' % i] = str(day.tm_mday)
    return values


# --------------------------------------------------------------- studio ---

class Studio(object):
    """The live editor over the screensaver: the side panel's rows and what
    Left / Right do to the scene (Google TV settings, one panel)."""

    def __init__(self, scene, background=None, slideshow=False):
        self.scene = normalize(scene)
        self.page = 'main'
        self.background = background or (lambda: '')
        self.slideshow = slideshow

    def title(self):
        return 'Ambient mode' if self.page == 'main' else WIDGET_LABELS[self.page]

    def rows(self):
        """[(key, title, value, cycles)] - cycles: Left / Right change the value."""
        scene = self.scene
        if self.page == 'main':
            rows = [(name, WIDGET_LABELS[name], summary(scene, name), False) for name in WIDGETS]
            rows.append(('background', 'Background', self.background(), False))
            if self.slideshow:
                rows.append(('speed', 'Slideshow speed', '%d seconds per picture' % scene['speed'], True))
            rows.append(('hide', 'Hide this panel', 'Any key brings it back', False))
            rows.append(('done', 'Done', 'Changes are saved as you go', False))
            return rows
        name = self.page
        widget = scene[name]
        rows = [('design', 'Style', design_label(name, widget['design']), True)]
        if widget['design'] != OFF:
            rows += [('size', 'Size', SIZE_LABELS[widget['size']], True),
                     ('color', 'Colour', COLOR_LABELS[widget['color']], True),
                     ('pos', 'Position', POSITION_LABELS[widget['pos']], True)]
            if name == 'text':
                rows.append(('value', 'Your text', widget['value'] or 'Not set · press OK', False))
        rows.append(('back', 'Back', '', False))
        return rows

    def change(self, key, step):
        """Left (-1) / Right (+1) on a cycling row; True when the scene changed."""
        scene = self.scene
        if key == 'speed' and self.page == 'main':
            target, field, options = scene, 'speed', SPEEDS
        elif self.page in WIDGETS and key in ('design', 'size', 'color', 'pos'):
            target, field = scene[self.page], key
            options = {'design': designs(self.page) + (OFF,), 'size': SIZES, 'color': tuple(COLORS), 'pos': POSITIONS}[key]
        else:
            return False
        index = options.index(target[field]) if target[field] in options else 0
        target[field] = options[(index + step) % len(options)]
        return True

    def side(self):
        """The panel docks opposite the widget being edited."""
        if self.page in WIDGETS and self.scene[self.page]['design'] != OFF:
            if self.scene[self.page]['pos'].endswith('right'):
                return 'left'
        return 'right'


class Ambient(object):
    """Drives the widgets of one screensaver window."""

    def __init__(self, window, scene=None):
        self.window = window
        self.scene = normalize(scene) if scene is not None else load()
        self.places = {}
        self.shift = (0, 0)
        self.last_time = ''
        self.next_minute = 0.0
        self.next_shift = 0.0
        self.twelve = twelve_hour()
        self.moving = True

    def _set(self, key, value):
        self.window.setProperty('meganexus.amb.' + key, value)

    def apply(self, scene=None):
        if scene is not None:
            self.scene = normalize(scene)
        scene = self.scene
        # 7.0.29: no zoom / pan - a picture is framed exactly like a video (the
        # slow Ken Burns looked like a zoomed picture next to the video).
        self._set('motion', '')
        self._set('speed', str(scene['speed']))
        self._set('soft', SOFT)
        self._set('onaccent', ON_ACCENT)
        self.places = layout(scene)
        for name in WIDGETS:
            widget = scene[name]
            on = name in self.places
            self._set(name, widget['design'] if on else '')
            if not on:
                continue
            self._set(name + '.align', self.places[name][2])
            self._set(name + '.size', widget['size'])
            self._set(name + '.accent', COLORS[widget['color']])
            self._set(name + '.main', main_color(widget['color']))
            self._set(name + '.surface', surface(widget['color']))
        self._set('text.value', scene['text']['value'])
        self.last_time = ''
        self._place()
        self.tick(force=True)

    def _place(self):
        dx, dy = self.shift
        for name, (x, y, _) in self.places.items():
            try:
                self.window.getControl(GROUPS[name]).setPosition(x + dx, y + dy)
            except Exception:
                pass

    def tick(self, force=False, now=None):
        """Called from the screensaver's loop (every 0.1 s)."""
        now = time.time() if now is None else now
        if 'clock' in self.places:
            text, hours, minutes = clock_parts(now, self.twelve)
            if text != self.last_time:
                self.last_time = text
                self._set('time', text)
                self._set('hh', hours)
                self._set('mm', minutes)
        if force or now >= self.next_minute:
            self.next_minute = now + 30
            self._minute(now)
        if self.moving and now >= self.next_shift:
            if self.next_shift:
                self.shift = (random.randint(-SHIFT, SHIFT), random.randint(-SHIFT, SHIFT))
                self._place()
            self.next_shift = now + SHIFT_EVERY

    def hold(self):
        """Studio: the widgets stay exactly where the layout puts them."""
        self.moving = False
        self.shift = (0, 0)
        self._place()

    def _minute(self, now):
        for key, value in dates(now, xbmc.getLocalizedString).items():
            self._set(key, value)
        if 'weather' in self.places or self.places.get('clock') and self.scene['clock']['design'] == 'google':
            for key, value in weather(xbmc.getInfoLabel).items():
                self._set(key, value)
        if 'calendar' in self.places and self.scene['calendar']['design'] == 'month':
            self._calendar(now)

    def _calendar(self, now):
        import xbmcgui
        title, heads, cells = month(now, xbmc.getLocalizedString)
        self._set('cal.title', title)
        for i, head in enumerate(heads):
            self._set('cal.h%d' % i, head)
        try:
            panel = self.window.getControl(CALENDAR_PANEL + SIZES.index(self.scene['calendar']['size']))
        except Exception:
            return
        items = []
        for index, (day, today) in enumerate(cells):
            item = xbmcgui.ListItem(day)
            item.setProperty('today', '1' if today else '')
            item.setProperty('weekend', '1' if index % 7 >= 5 else '')
            items.append(item)
        panel.reset()
        panel.addItems(items)
