# MegaNexus interface

Independent presentation component for the MegaNexus backend. Owns Home, Details, the simplified settings menu, rounded-poster artwork, collection covers and optional trailer-preview presentation. All provider access, account data, playback contexts and progress storage remain in plugin.video.meganexus.

Requires Kodi 21 and the bundled backend. Installed by the MegaNexus local bundle installer. Standard Kodi dialogs and OSD are supplied by the separate skin.meganexus component. No legacy backend skins or source-picker themes are included.

This is an unofficial community build. Original MIT notices and artwork attribution are retained in LICENSE.txt and resources/licenses. Runtime behavior still requires testing in Kodi on the target device.
