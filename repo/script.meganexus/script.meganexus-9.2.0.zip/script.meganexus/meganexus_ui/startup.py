# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Cancellable first-page warm-up; bounded workers, no invisible infinite crawl."""
from concurrent.futures import ThreadPoolExecutor
import time
import xbmc
import xbmcgui
from resources.lib import browse_cache, collection_profile, collection_validation
from resources.lib.collections_home import matching_catalog
from resources.lib.meganexus import addon_registry
from resources.lib.meganexus.net.options import timeout_seconds
from .play_jobs import Loading, ROOT
from resources.lib.theme import folder as theme_folder

MAX_WORKERS = 4
MAX_STARTUP_SECONDS = 40
FULL_SETUP_SHARE = .5        # the posters are waited for only while Kodi keeps fewer than half of them (until 90 %, Back skips)
MAX_POSTER_SECONDS = 30      # ... and, without our screensaver, the day's new ones at most this long, as before 7.0.47
SAVER = 'screensaver.meganexus'
MAX_ART_SECONDS = 30         # 7.0.32: the day's new titles' TMDB / Fanart.tv pictures (no limit after a new Artwork choice)


def shown_groups():
    """Only what Home shows: hidden rows and hidden cards are not prepared."""
    return [dict(g, folders=[f for f in g.get('folders') or [] if not f.get('hidden')])
            for g in collection_profile.load() if not g.get('hidden')]


def jobs(groups=None):
    providers = addon_registry.list_providers()
    result, seen = [], set()
    shown = shown_groups() if groups is None else groups
    from resources.lib.sports import is_sports_source
    for _, source in collection_validation.sources(shown):
        if is_sports_source(source):
            continue   # 7.0.19: sport catalogs load in the Sport screen, not behind the opening screen
        match = matching_catalog(source, providers)
        if not match:
            continue
        provider, catalog = match
        extra = collection_validation.extra_for(source)
        key = browse_cache.catalog_key(provider, catalog, extra)
        if key not in seen:
            result.append((key, provider, catalog, extra))
            seen.add(key)
    return result


COLD_IMAGES = 600            # proxy RAM holding fewer images = filled after reboot/suspend


def art_cold():
    """Image proxy is on (RAM mode) and nearly empty, e.g. right after a reboot."""
    from resources.lib import art_cache
    if art_cache.DIRECT or art_cache.native():
        return ''         # 8.1.0: no pictures in the proxy's memory - Kodi keeps them on its disk
    home = xbmcgui.Window(10000)
    base = home.getProperty('meganexus.art_cache.base')
    if not base.startswith('http://127.0.0.1:'):
        return ''
    try:
        images = int((home.getProperty('meganexus.art_cache.usage') or '0 · 0').split('·')[-1].split()[0])
    except (ValueError, IndexError):
        images = 0
    return base if images < COLD_IMAGES else ''


def saver_stores():
    """7.0.47: our screensaver is Kodi's screensaver - it stores the posters Kodi does
    not keep yet (saver._store_posters), so the opening does not wait for them."""
    try:
        from .system_setup import rpc
        return ((rpc('Settings.GetSettingValue', {'setting': 'screensaver.mode'}) or {}).get('value') or '') == SAVER
    except Exception:
        return False


def ring_step(done, total):
    """precache/ring_00..ring_19 for the opening screen's progress."""
    return '%02d' % (min(19, done * 20 // total) if total else 0)


# 7.0.45: the way into MegaNexus is one ring that only fills - each step had its own
# ring from empty (catalogs, artwork, posters, then Home's first rows on another
# screen) and the ring stood empty while Home was built (4 s on the Cube).
STEPS = ('check', 'catalogs', 'artwork', 'posters', 'home', 'rows')
EXPECTED = {'check': 1.5, 'catalogs': 4.0, 'artwork': 8.0, 'posters': 12.0, 'home': 1.5, 'rows': 1.5}   # seconds, until learned
TIMED = ('check', 'home')           # steps without a count: the ring goes on by the time
TIMES = 'entry_times.json'          # how long each step took on this device (profile)


def _times_path():
    try:
        from resources.lib.meganexus.paths import profile_path
        import os
        return os.path.join(profile_path(), TIMES)
    except Exception:
        return ''


def learned_times(path=None):
    path = _times_path() if path is None else path
    times = dict(EXPECTED)
    try:
        import json
        with open(path, encoding='utf-8') as handle:
            for step, seconds in (json.load(handle) or {}).items():
                if step in times and isinstance(seconds, (int, float)) and 0 < seconds < 600:
                    times[step] = float(seconds)
    except Exception:
        pass
    return times


def learn_times(taken, path=None):
    """Remember how long the steps took (an even mix with what was known)."""
    path = _times_path() if path is None else path
    if not path or not taken:
        return
    times = learned_times(path)
    for step, seconds in taken.items():
        if step in times and 0 < seconds < 600:
            times[step] = round(.5 * times[step] + .5 * seconds, 2)
    try:
        import json
        import os
        temp = path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(times, handle)
        os.replace(temp, path)
    except Exception:
        pass


class Progress(object):
    """One ring for every step on the way in. A step's share is the time it took
    last time on this device, so the ring fills evenly with time; within a step
    it follows the work done (catalogs, pictures, rows) or, where Kodi gives no
    count (Home being built), the time. Under the ring the time left - from the
    remembered times, corrected by the pace now - or the One-time setup's words.
    A step that is not needed is passed over (the ring goes on, never back)."""

    def __init__(self, window, steps=(), after=(), clock=time.monotonic, times=None, tick=.2):
        import threading
        self.window = window
        self.clock = clock
        self.times = dict(times) if times is not None else learned_times()
        self.after = list(after)          # steps the caller runs after prepare() (Home, its first rows)
        self.lock = threading.RLock()
        self.value = 0.0
        self.step = None
        self.step_started = clock()
        self.fraction = 0.0
        self.text = ''
        self.count = ''
        self.taken = {}
        self.plan(steps)
        self.stopped = threading.Event()
        if tick:
            threading.Thread(target=self._ticking, args=(tick,), name='MegaNexusOpeningRing', daemon=True).start()

    def plan(self, steps):
        with self.lock:
            steps = list(steps) + self.after
            self.weights = [(name, self.times[name]) for name in STEPS if name in steps]
            self.total = sum(weight for _, weight in self.weights) or 1.0

    def _base(self, name):
        base = 0.0
        for step, weight in self.weights:
            if step == name:
                return base, weight
            base += weight
        return base, 0.0

    def begin(self, name, text=''):
        with self.lock:
            now = self.clock()
            if self.step:
                self.taken[self.step] = now - self.step_started
            self.step, self.text, self.count, self.fraction, self.step_started = name, text, '', 0.0, now
            self._set(0.0)

    def update(self, fraction, count=''):
        with self.lock:
            self.count = count
            self._set(fraction)

    def _set(self, fraction):
        self.fraction = max(self.fraction, max(0.0, min(1.0, fraction)))
        base, weight = self._base(self.step)
        self.value = max(self.value, min(1.0, (base + weight * self.fraction) / self.total))
        self._show()

    def _ticking(self, every):
        while not self.stopped.wait(every):
            with self.lock:
                if self.step in TIMED:            # no count from Kodi meanwhile: the time it took before
                    _, weight = self._base(self.step)
                    self._set(min(.95, (self.clock() - self.step_started) / (weight or 1)))

    def done(self):
        with self.lock:
            if self.step:
                self.taken[self.step] = self.clock() - self.step_started
            self.step = None
            self.value = 1.0
            self._show()
        self.stop()
        learn_times(self.taken)

    def stop(self):
        self.stopped.set()

    def _show(self):
        # no time-left words under the ring (the user's choice); the remembered
        # times only make the ring fill evenly
        try:
            self.window.setProperty('meganexus.ring', '%02d' % min(19, int(self.value * 20)))
            lines = [self.text] if self.text else []
            words = ' · '.join(part for part in (self.count, 'Back to skip' if self.text else '') if part)
            if words:
                lines.append(words)
            self.window.setProperty('meganexus.loading', '[CR]'.join(lines))
        except Exception:
            pass


RETRY_ROUNDS = 2          # 7.0.52: catalogs that failed are asked again before the setup ends
RETRY_TIMEOUT = 15        # ... with more time each (a new metadata add-on answers slowly at first)
RETRY_WORKERS = 2         # ... and fewer at once (a public instance limits bursts)
RETRY_PAUSE = 3


def _warm_catalogs(window, monitor, all_jobs, missing, report, progress=None, retry=False):
    """The catalogs not cached yet, MAX_WORKERS at once. 7.0.52: in a one-time setup (``retry``)
    the ones that failed are asked again (RETRY_ROUNDS) while the screen shows - a fresh quick
    setup had 135 of 172 fail the first time, and the setup counted 700 posters, then 1,400, then
    2,500 on later starts. 7.0.55: only then - on an ordinary entry Home waited up to half a
    minute for a slow catalog; those load in the background as before."""
    deadline = time.monotonic() + MAX_STARTUP_SECONDS
    total = float(len(missing) or 1)
    state = {'finished': 0}

    def tick():
        done = state['finished']
        if progress is not None:
            progress.update(min(1.0, done / total))
            return
        window.setProperty('meganexus.ring', ring_step(done, int(total)))
        # 8.1.1: say what it is doing. 7.0.10 took the words away when this took a
        # moment; with a slow metadata add-on it can take forty seconds, and a ring
        # that barely moves with nothing beside it reads as a hang.
        window.setProperty('meganexus.loading', 'Loading your collections — %d of %d' % (min(done, int(total)), int(total)))

    def run(jobs, timeout, workers, first):
        failed = []
        pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix='MegaNexusWarm')
        pending, remaining = {}, iter(jobs)

        def submit():
            try:
                job = next(remaining)
            except StopIteration:
                return False
            _, provider, catalog, extra = job
            pending[pool.submit(browse_cache.catalog, provider, catalog, extra, timeout)] = job
            return True
        try:
            for _ in range(min(workers, len(jobs))):
                submit()
            while pending and not window.cancelled and not monitor.abortRequested() and time.monotonic() < deadline:
                # Kodi delivers the window's onAction (Back = skip) only while the
                # script waits in Kodi (waitForAbort), never during a plain
                # concurrent.futures wait - Back did nothing here (6.0.35).
                if monitor.waitForAbort(.05):
                    break
                for future in [f for f in pending if f.done()]:
                    job = pending.pop(future)
                    try:
                        future.result()
                        report['loaded'] += 1
                        if first:
                            state['finished'] += 1
                        else:
                            report['failed'] -= 1
                        report['deferred'] -= 1 if first else 0
                    except Exception:
                        if first:
                            report['failed'] += 1
                            report['deferred'] -= 1
                            state['finished'] += 1
                        failed.append(job)
                    submit()
                # 7.0.10: no text - the ring fills with the catalogs still to load.
                tick()
        finally:
            left = list(pending.values()) + list(remaining)
            for future in pending:
                future.cancel()
            pool.shutdown(wait=False)
            if left and not monitor.abortRequested():   # issue #51: not dropped - in the background, not waited for soon
                for _, provider, catalog, extra in left:
                    browse_cache.later(provider, catalog, extra)
        return failed

    # issue #51: the person's Timeout (Settings), as every other page - a fixed 5 s failed the add-ons that answer in 8
    failed = run(missing, timeout_seconds(), MAX_WORKERS, True)
    for _ in range(RETRY_ROUNDS if retry else 0):
        if not failed or window.cancelled or monitor.abortRequested() or time.monotonic() + RETRY_PAUSE >= deadline:
            break
        if monitor.waitForAbort(RETRY_PAUSE):
            break
        xbmc.log('[MegaNexus] start: %d catalogs asked again' % len(failed), xbmc.LOGINFO)
        failed = run(failed, RETRY_TIMEOUT, RETRY_WORKERS, False)


def _start_ratings(proxy):
    """7.0.30: the MDBList ratings of the cards precache.plan() counted, in a few
    batch requests (at most 60 % of the day's MDBList requests). None when
    there is nothing to ask."""
    if not proxy:
        return None
    try:
        from resources.lib import mdblist_api, ratings_row
        if not (mdblist_api.configured() and ratings_row.any_enabled()):
            return None
    except Exception:
        return None
    from . import precache
    import threading
    titles = precache.titles()
    if not titles:
        return None
    def work():
        try:
            stored = mdblist_api.preload_ratings(titles)
            xbmc.log('[MegaNexus] ratings preload: %d of %d titles' % (stored, len(titles)), xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log('[MegaNexus] ratings preload skipped: %s' % exc, xbmc.LOGINFO)
    thread = threading.Thread(target=work, name='MegaNexusRatingsPreload', daemon=True)
    thread.start()
    return thread


def _start_release_dates(proxy):
    """7.0.36: TMDB's release dates of the same cards (films: cinema / digital,
    series: next episode), fetched in the background and kept a day - Home's
    release badge then shows the moment a card is selected. Stops when
    MegaNexus closes (Kodi waits for a script's threads)."""
    if not proxy:
        return None
    from . import precache
    import threading
    titles = precache.titles()
    if not titles:
        return None
    home = xbmcgui.Window(10000)
    running = home.getProperty('meganexus.frontend.running')
    monitor = xbmc.Monitor()

    def stopped():
        return monitor.abortRequested() or home.getProperty('meganexus.frontend.running') != running

    def busy():
        """The user moves through MegaNexus (keys within 3 s), a video plays or a page loads."""
        try:
            touched = time.time() - float(home.getProperty('meganexus.interactive_busy') or 0) < 3
        except ValueError:
            touched = False
        return touched or browse_cache.playback_busy() or browse_cache.foreground_busy()

    def work():
        from resources.lib import release_info
        while not stopped():
            try:
                done = release_info.preload(titles, stopped, busy, monitor.waitForAbort)
                xbmc.log('[MegaNexus] release dates preload: %d of %d titles' % (done, len(titles)), xbmc.LOGINFO)
            except Exception as exc:
                xbmc.log('[MegaNexus] release dates preload skipped: %s' % exc, xbmc.LOGINFO)
            # 7.0.36: at midnight films in cinemas and series are fetched again
            # (released films stay kept), also while MegaNexus stays open.
            until = time.monotonic() + release_info.until_midnight() + 5
            while not stopped() and time.monotonic() < until:
                if monitor.waitForAbort(5):
                    return
    thread = threading.Thread(target=work, name='MegaNexusReleasePreload', daemon=True)
    thread.start()
    return thread


def switch_artwork():
    """9.0.0: a new Artwork choice (Settings) carried out at once and to the end, behind the
    opening screen and its ring: every title of Home and the collections gets its picture
    from the new choice (the catalog's where it has none - one picture a title), Kodi
    stores them, and the pictures the old choice used and the new one does not are removed
    from Kodi's cache. Back waits, as in the picture path switch.

    It used to be skipped: with Kodi keeping the pictures itself (8.1.0) the opening found
    them "ready" and asked for nothing, so every card showed the catalog's poster and then
    the new one as Home got to it - two pictures a title in Kodi's cache, the old ones kept.
    Returns False when there is nothing to switch."""
    from . import precache
    from resources.lib import art_switch
    import xbmcaddon
    if not precache.art_changed():
        return False
    proxy = precache.base() if precache.enabled() else ''
    if not proxy:
        return False
    ids = [folder['id'] for group in shown_groups() for folder in group.get('folders') or [] if folder.get('id')]
    landscape = xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape') == 'landscape'
    before = precache.memo_addresses(proxy)
    window = Loading('meganexus_loading.xml', ROOT, theme_folder(), '1080i', label='', full=True, hub=True)
    window.holding = True
    window.show()
    monitor = xbmc.Monitor()
    progress = Progress(window, ('artwork', 'posters'))
    started = time.monotonic()
    try:
        stopped = monitor.abortRequested
        precache.plan(ids, landscape, stopped)                 # the titles waiting for the new pictures
        names = _art_names()
        progress.begin('artwork', 'New artwork from %s · getting the pictures' % names)
        looked = precache.resolve_art(stopped, monitor.waitForAbort,
                                      lambda done, total: progress.update(done / float(total or 1), '%d / %d titles' % (done, total)))
        precache.plan(ids, landscape, stopped)                 # now with the new pictures
        progress.begin('posters', 'New artwork from %s · storing the pictures' % names)
        stored = precache.run(window, stopped, monitor.waitForAbort,
                              lambda done, total: progress.update(done / float(total or 1), '%d / %d pictures' % (done, total)),
                              goal=1.0)[0]
        removed = 0 if stopped() else art_switch.drop_pictures(before - precache.memo_addresses(proxy))
        xbmc.log('[MegaNexus] artwork switch: %d titles looked up, %d pictures stored, %d old ones removed in %.0f s'
                 % (looked, stored, removed, time.monotonic() - started), xbmc.LOGINFO)
        return True
    finally:
        progress.stopped.set()
        window.close()


def _art_names():
    try:
        from resources.lib import art_provider
        return art_provider.summary()
    except Exception:
        return 'TMDB / Fanart.tv'


def prepare(window=None, progress=None, requested=False):
    """Before Home: make sure every collection's first page is cached (Back
    skips). No poster screen (7.0.7): Kodi shows the posters it has shown
    before from its own disk cache, and Home's background preload loads the
    others at once - the first screen of every collection first - into the
    image RAM, so collections still open with their posters.
    7.0.45: ``window`` / ``progress`` - the opening screen and its one ring, kept
    open by open_home until Home's first rows are drawn (not closed here)."""
    all_jobs = jobs()
    cache = browse_cache.instance()
    # One SQLite read promotes warmed disk pages to the bounded in-process LRU.
    # Stale pages count as present: Home shows them at once and they are
    # revalidated one by one in the background instead of behind a loading screen.
    state = cache.lookup_many([job[0] for job in all_jobs])
    absent = [job for job in all_jobs if job[0] not in state]
    # 7.0.11: catalogs that failed or came back empty lately are not waited for
    # again; they retry in the background and appear once they load.
    misses = cache.lookup_many([browse_cache.miss_key(job[0]) for job in absent]) if absent else {}
    missing = [job for job in absent if browse_cache.miss_key(job[0]) not in misses]
    for key, provider, catalog, extra in absent:
        if browse_cache.miss_key(key) in misses:
            browse_cache.refresh(provider, catalog, extra)
    for key, provider, catalog, extra in all_jobs:
        if state.get(key) is False:
            browse_cache.refresh(provider, catalog, extra)
    report = {'cached': len(all_jobs) - len(missing), 'loaded': 0, 'failed': 0, 'deferred': len(missing), 'posters': 0}
    base = art_cold()
    if base:
        # Home's preload continues even when the proxy already holds many images.
        xbmcgui.Window(10000).setProperty('meganexus.art_warm.front', base)
    # 7.0.30: every time MegaNexus opens, Home and every collection's first page
    # are ready first: the opening screen stays until Kodi keeps 90 % of their
    # posters (cards without a picture link and links Kodi cannot load do not
    # count), and the titles' MDBList ratings are fetched in a few requests.
    # When Kodi already has them, Home opens at once without the screen.
    # (7.0.9-7.0.29: only once per device / after an update.) Back skips.
    from . import precache, perf
    import xbmcaddon
    if progress is not None:
        progress.begin('check')   # 7.0.45: Kodi's picture cache counted (2.6 s on the Cube) - the ring goes on
    proxy = precache.base() if precache.enabled() else ''
    ids = [folder['id'] for group in shown_groups() for folder in group.get('folders') or [] if folder.get('id')]
    landscape = xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape') == 'landscape'
    first = bool(proxy) and precache.first_time()
    # 8.1.5: the Artwork provider's pictures never hold the opening - only when they were
    # asked for: a new Artwork choice in Settings (``requested``: Home's 'prepare'). The
    # opening waited for them after every update (first_time is true then) and on every
    # start where they had never been fetched to the end - their mark (art_changed) is
    # written only then, and Back skips it every time: 4,524 of 4,574 posters were there
    # and the screen still said "One-time setup". Home fetches a row's own as it shows it.
    def art_block():
        return precache.art_waiting() if requested else 0
    ready = True
    done = total = 0
    if proxy and not missing:
        with perf.timed('Start check', collections=len(ids)) as step:
            # 8.1.2: ask the cheap question first. plan() walks Home's rows and all 82
            # collections to work out which pictures are wanted - 1.6 s and 1.3 s on a
            # CoreELEC box, every single time MegaNexus is opened, only to conclude that
            # the box already has them. needs_full() answers the same thing from what
            # Kodi keeps (0.3 s). Nothing is lost by skipping the plan here: the
            # screensaver draws one up itself and tops the pictures up there, which is
            # where that work belongs.
            if not precache.first_time() and not precache.needs_full(proxy):
                done = total = 0
                ready = not art_block()
                step.details.update(posters='kept', artwork=art_block())
            else:
                done, total = precache.plan(ids, landscape)
                ready = (not total or done >= total * precache.RING_DONE) and not art_block()
                step.details.update(posters='%d/%d' % (done, total), artwork=art_block())
    ratings = _start_ratings(proxy)
    _start_release_dates(proxy)
    xbmc.log('[MegaNexus] start: %d catalogs, %d to load, %d unavailable lately (retried in the background), posters ready: %s'
             % (len(all_jobs), len(missing), len(absent) - len(missing), 'yes' if ready else 'no'), xbmc.LOGINFO)
    later = saver_stores()
    if not missing and (ready or (later and not art_block() and not (total and done < total * FULL_SETUP_SHARE))):
        return report   # 7.0.47: the day's new posters come in the background
    own = window is None
    if own:
        window = Loading('meganexus_loading.xml', ROOT, theme_folder(),'1080i', label='', full=True, hub=True)
        window.show()
    monitor = xbmc.Monitor()
    if progress is None:
        progress = Progress(window)
    # the steps this opening needs; one that turns out not needed is passed over
    progress.plan(([] if not missing else ['catalogs'])
                  + (['artwork'] if proxy and (missing or art_block()) else [])
                  + (['posters'] if proxy and (missing or not ready) else []))
    try:
        if missing:
            progress.begin('catalogs')
            # a one-time setup (first preparation, or most catalogs new after a quick setup)
            setup = first or len(missing) * 2 > len(all_jobs)
            _warm_catalogs(window, monitor, all_jobs, missing, report, progress, retry=setup)
            if proxy and not window.cancelled and not monitor.abortRequested():
                done, total = precache.plan(ids, landscape, lambda: window.cancelled)
                ready = (not total or done >= total * precache.RING_DONE) and not art_block()
                if ratings is None:
                    ratings = _start_ratings(proxy)
        if proxy and art_block() and not window.cancelled and not monitor.abortRequested():
            # 7.0.32: the pictures of the provider chosen in Artwork (posters,
            # backgrounds, title logos) first, so collections open with them
            # instead of changing them one by one. Then the posters themselves.
            changed = requested and precache.art_changed()
            # 7.0.36: words only for a new Artwork choice; the day's new titles: the ring alone
            text = ('One-time setup: getting collection artwork from %s' % _art_names()) if changed else ''
            progress.begin('artwork', text)
            def art_label(done, total):
                progress.update(done / float(total or 1), ('%d / %d titles' % (done, total)) if text else '')
            started = time.monotonic()
            looked = precache.resolve_art(lambda: window.cancelled, monitor.waitForAbort, art_label,
                                          until=None if changed else started + MAX_ART_SECONDS)
            xbmc.log('[MegaNexus] artwork preload: %d titles in %.0f s%s'
                     % (looked, time.monotonic() - started, ' (skipped)' if window.cancelled else ''), xbmc.LOGINFO)
            if not window.cancelled and not monitor.abortRequested():
                done, total = precache.plan(ids, landscape, lambda: window.cancelled)
                ready = not total or done >= total * precache.RING_DONE
                first = first or changed
        # A first setup (install, a cleared cache, a new Artwork choice - Kodi keeps fewer
        # than half of the pictures) waits for the posters, until 90 %. 7.0.47: the day's new
        # ones are not waited for while our screensaver stores them (saver._store_posters) -
        # up to 30 s behind the ring on every opening, a slow box stores about 8 a second;
        # without our screensaver they still get MAX_POSTER_SECONDS here.
        full = bool(total) and done < total * FULL_SETUP_SHARE
        if proxy and not ready and not full and later:
            xbmc.log('[MegaNexus] poster preload: %d of %d kept by Kodi - the rest while the screensaver runs' % (done, total), xbmc.LOGINFO)
        if proxy and not ready and (full or not later) and not window.cancelled and not monitor.abortRequested():
            text = 'One-time setup: preparing collections · posters and artwork' if full else ''
            progress.begin('posters', text)
            def label(done, total):
                progress.update(done / float(total or 1), ('%d / %d pictures' % (done, total)) if text else '')
            started = time.monotonic()
            report['posters'] = precache.run(window, lambda: window.cancelled, monitor.waitForAbort, label,
                                             until=None if full else started + MAX_POSTER_SECONDS)[0]
            xbmc.log('[MegaNexus] poster preload: %d stored by Kodi of %d in %.0f s%s'
                     % (report['posters'], precache.progress()[1], time.monotonic() - started, ' (skipped)' if window.cancelled else ''), xbmc.LOGINFO)
        if ratings is not None:
            until = time.monotonic() + 10
            while ratings.is_alive() and time.monotonic() < until and not window.cancelled and not monitor.abortRequested():
                monitor.waitForAbort(.1)
        return report
    finally:
        if own:
            window.close()
