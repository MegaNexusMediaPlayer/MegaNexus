# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, MultiView's tiles ("kad se prebaci u multiview odvojene prozore kao plocice a u njima su kanali ...
dolje na dnu su i dalje kontrole samo ispod plocica blago oznaci koji kanali idu"): where each channel is drawn on the
1920 x 1080 picture - rounded tiles with room between them on a dark ground, each one's name under it, the bottom kept
for the player's controls. One place for the grid's ffmpeg (meganexus_ui/multiview.py) and the skin's tiles over it
(review/make_multiview_overlay.py); nothing of Kodi in it."""

WIDTH, HEIGHT = 1920, 1080
GROUND = '0x0d0f14'                   # the picture's ground between the tiles (the tiles' corners are this colour too)
GRID, FOCUS = 'grid', 'focus'
GAP = 36                              # between two tiles
NAME = 44                             # under a tile: its channel's name
TOP, BOTTOM = 40, 880                 # the tiles' part of the picture (under it: the grid's buttons - up from 900, 2026-11-21)
RADIUS = 18


def _fit(width, height):
    """16:9 inside ``width`` x ``height``."""
    w = min(width, height * 16 // 9)
    return w - w % 2, (w * 9 // 16) - (w * 9 // 16) % 2


def tiles(count, layout):
    """[(x, y, width, height)] of ``count`` channels' tiles (2 to 4; 1: the whole picture) - at even places, as the
    grid's encoder puts a picture (yuv420p: whole 2 x 2 blocks), so the skin's tile is where its picture is."""
    return [(x - x % 2, y - y % 2, w, h) for x, y, w, h in _places(count, layout)]


def _places(count, layout):
    if count <= 1:
        return [(0, 0, WIDTH, HEIGHT)]
    room = BOTTOM - TOP
    if layout == FOCUS:                # the first big, the others beside it - small tiles of one size (three fit)
        sw, sh = _fit(WIDTH, (room - 2 * GAP) // 3 - NAME)
        bw, bh = _fit(WIDTH - 3 * GAP - sw, room - NAME)
        left = (WIDTH - bw - GAP - sw) // 2
        big = (left, TOP + (room - bh - NAME) // 2, bw, bh)
        column = (count - 1) * (sh + NAME) + (count - 2) * GAP
        first = TOP + (room - column) // 2
        return [big] + [(left + bw + GAP, first + n * (sh + NAME + GAP), sw, sh) for n in range(count - 1)]
    if count == 2:
        w, h = _fit((WIDTH - 3 * GAP) // 2, room - NAME)
        left, top = (WIDTH - 2 * w - GAP) // 2, TOP + (room - h - NAME) // 2
        return [(left, top, w, h), (left + w + GAP, top, w, h)]
    w, h = _fit((WIDTH - 3 * GAP) // 2, (room - GAP) // 2 - NAME)
    left, top = (WIDTH - 2 * w - GAP) // 2, TOP + (room - 2 * (h + NAME) - GAP) // 2
    places = [(left + (n % 2) * (w + GAP), top + (n // 2) * (h + NAME + GAP), w, h) for n in range(count)]
    if count == 3:                     # the third one in the middle under the two
        places[2] = ((WIDTH - w) // 2,) + places[2][1:]
    return places


def shape(count, layout):
    """The name of a count and layout (the skin's tiles are drawn per shape)."""
    return '%s%d' % (layout, count)


SHAPES = [(layout, count) for layout in (GRID, FOCUS) for count in (2, 3, 4)]
