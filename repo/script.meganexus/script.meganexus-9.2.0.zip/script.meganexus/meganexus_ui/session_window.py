# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Retained native base window for a frontend session.

Dialogs may close while the native fullscreen player owns input. Kodi returns
first to this ordinary WindowXML, NOT to the launcher's HUB window. The caller
then restores its existing Details/Catalog/Home objects and selection. This
base has no routing/timers and never starts another frontend instance.
"""
import threading
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.theme import folder as theme_folder


_OPEN = [None]      # 9.1.4: this run's session window while it is open


class SessionWindow(xbmcgui.WindowXML):
    def __init__(self, *args):
        super().__init__(*args)
        self.ready = threading.Event()
        self.closed = False

    def onInit(self):
        self.ready.set()

    def onAction(self, action):
        # A Back received between dialogs must not pop the base back to HUB.
        pass

    def close(self):
        """Once only (9.1.4): Kodi's WindowXML.close() always asks for the previous window, whichever window is on
        top - a second close would take Kodi back from the screen it was left for."""
        if self.closed:
            return
        self.left()
        super().close()

    def left(self):
        """Done with: closed, or replaced by a Kodi window (leave_for) - then nothing more is asked of Kodi. A window of
        ours that is no longer shown is only taken out of Kodi's window history when Python frees it."""
        self.closed = True
        if _OPEN[0] is self:
            _OPEN[0] = None


def _opens_window(command):
    """A Kodi window other than its Home: ActivateWindow(Videos,videodb://movies/titles/,return) and the like."""
    text = str(command or '').strip()
    if not text.lower().startswith('activatewindow('):
        return False
    target = text[len('activatewindow('):].split(',')[0].strip(' )"\'').lower()
    return target not in ('', 'home', '10000')


def leave_for(command, run):
    """Home's way out to a Kodi window (9.1.4, GitHub #46: All local movies showed Kodi's library for a moment, then
    it was gone, back on the HUB). The window was opened over this session's base window, and closing that base at
    the end of the run asks Kodi for the previous window - which took it back from the library at once.

    So the library REPLACES the base (Kodi's ReplaceWindow: in its place in the window history too, Back leads to the
    HUB) and the base is not closed after it. Nothing of ours may be up over it while it opens: Kodi refuses to open
    a window under any modal dialog ("Activate of window refused"), our ring included. Should Kodi not open it, the
    base closes as before. Anything else runs as before."""
    session = _OPEN[0]
    if session is None or not _opens_window(command):
        run(command)
        return
    monitor = xbmc.Monitor()
    before = xbmcgui.getCurrentWindowId()
    run('ReplaceWindow(' + command.strip()[len('activatewindow('):])
    for _ in range(60):                           # up to 3 s for Kodi to open it
        if xbmcgui.getCurrentWindowId() != before:
            session.left()
            return
        if monitor.waitForAbort(.05):
            break
    session.close()


def scene(art='', title=''):
    window=xbmcgui.Window(10000)
    window.setProperty('meganexus.scene.art', str(art or ''))
    window.setProperty('meganexus.scene.title', str(title or ''))


def has_video_layer(os_release='/etc/os-release'):
    """Boxes that show hardware video on a plane under Kodi's interface
    (CoreELEC/LibreELEC/OSMC and similar, Android). PCs draw video in the GUI."""
    if xbmc.getCondVisibility('System.Platform.Android'):
        return True
    try:
        with open(os_release, encoding='utf-8', errors='replace') as stream:
            text = stream.read().lower()
    except OSError:
        return False
    return any(name in text for name in ('coreelec', 'libreelec', 'osmc', 'alexelec'))


ENTERING='meganexus.entering'   # 9.1.1: Window(Home) - MegaNexus is being entered from the HUB
ENTER_HOLD=.15                  # s the HUB's brighter picture stays before it fades (review/make_entry_fade.py)


def open_session(entering=False):
    """``entering`` (9.1.1): from the HUB - with a wallpaper of your own the HUB shows it brighter than the
    MegaNexus screens, and opening this window halved its light at once ("na ulazu ... bljesak"): it opens with
    the HUB's picture, which fades to the screens' darkening once the window is up."""
    home=xbmcgui.Window(10000)
    # Skin XML adds a black frame over small videos only where Kodi's own
    # translucent shade over the video plane does not show.
    home.setProperty('meganexus.videolayer', '1' if has_video_layer() else '')
    scene()
    if entering:home.setProperty(ENTERING,'1')
    win=SessionWindow('meganexus_session.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), theme_folder(),'1080i')
    win.show()
    _OPEN[0]=win
    monitor=xbmc.Monitor()
    for _ in range(100):
        if win.ready.is_set() or monitor.waitForAbort(.01):
            break
    if entering:
        # drawn once with it first, then the mark goes and the picture darkens (the skin's Hidden fade)
        timer=threading.Timer(ENTER_HOLD,home.clearProperty,(ENTERING,))
        timer.daemon=True
        timer.start()
    return win
