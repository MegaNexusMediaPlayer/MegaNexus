# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, MultiView in a screen that plays (MegaIPTV's player, MegaSport): its grid (meganexus_ui/multiview.py),
its tiles' window over it (MultiViewWindow), what the window asks (_on_grid) - one IPTV channel at most, the other tiles
live streams of the sport add-ons (meganexus_ui/multiview_sources.py).

A screen with MultiView mixes in MultiViewHost and has: _playing_row(rows) (its IPTV channel that plays), _channel_rows
(group), _preview_of / _group (the IPTV picker's start) and _switch(row) (an IPTV channel full screen)."""
import time

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.theme import folder as theme_folder
from .home_window import BACK
from .iptv import _folder

ADDON_UI = xbmcaddon.Addon('script.meganexus')   # the windows' own add-on (the pickers' layouts)
MV = 'meganexus.mv.'                       # Window(Home): a MultiView grid's shape, its tiles' names, whose sound is heard


def _clock(value):
    from .iptv import epg_time
    when = epg_time(value)
    return when.strftime('%H:%M') if when else ''


class MultiViewHost:
    """MultiView's part of a screen that plays."""
    # the Window(Home) property the screen's player loop reads its asks from - the grid's window (MultiViewWindow) asks
    # there: MegaIPTV's and MegaSport's (iptv.OSD_COMMAND); the Sport screen's own (sports.OSD_COMMAND) for its grid
    _mv_command = 'meganexus.iptv.osd'

    def _multiview(self, rows, found):
        """MultiView's button on a channel (meganexus_ui/multiview.py: its sources as one picture, a camera recorder's
        grid): a live stream of the sport add-ons beside it - the grid's one IPTV channel is this one (an IPTV list serves
        one at a time; meganexus_ui/multiview_sources.py). True once the grid plays."""
        from .multiview import GRID
        from .multiview_sources import pick_tile
        first = self._playing_row(rows)
        chosen = pick_tile([first], self, rows, found, 'MultiView: beside it') if first else None
        if not chosen:
            return False
        return self._mv_show([first, chosen], GRID, 0)

    def _on_grid(self, command, rows, found):
        """What the grid's window asked (MultiViewWindow): mv:add, mv:layout, mv:out, mv:close, mv:alone:<n>. True once
        something new plays."""
        from .multiview import BEHIND, FOCUS, GRID, MAX
        state = getattr(self, '_mv', None)
        if not state or getattr(self, '_grid', None) is None:
            return False
        what = command.split(':')[1]
        if what == 'add' and self._grid.state().get('late', 0) > BEHIND:
            xbmcgui.Dialog().notification('MultiView', 'This box shows no more channels at once.', time=4000)
            return False
        if what == 'add' and len(state['rows']) < MAX:
            from .multiview_sources import is_stream, pick_tile
            chosen = pick_tile(state['rows'], self, rows, found)
            same = lambda a, b: (a.get('mv_source') or {}).get('address') == (b.get('mv_source') or {}).get('address') if is_stream(a) \
                else not is_stream(b) and a.get('channelid') == b.get('channelid')
            if not chosen or any(same(chosen, r) for r in state['rows']):
                return False
            return self._mv_show(state['rows'] + [chosen], state['layout'], len(state['rows']))
        if what == 'layout':
            return self._mv_show(state['rows'], FOCUS if state['layout'] == GRID else GRID, state['sound'])
        if what == 'out' and len(state['rows']) > 2:
            left = [r for n, r in enumerate(state['rows']) if n != state['sound']]
            return self._mv_show(left, state['layout'], 0)
        if what in ('alone', 'close'):
            from .multiview_sources import iptv_rows, is_stream
            live = state['rows'][int(command.split(':')[2]) if what == 'alone' else state['sound']]
            if what == 'close' and is_stream(live) and iptv_rows(state['rows']):
                live = iptv_rows(state['rows'])[0]       # closed on a stream: the grid's IPTV channel plays on
            self._mv_left = live                      # this screen's own now: stopped as it is left (_mv_stop_left)
            covered = self._mv_cover(True)            # the ground over the change - not the screen behind the player
            if is_stream(live):                       # a sport stream alone, full screen (Back: the screen's own again)
                self._play_alone(live)
                switched = True
                if covered:
                    _playing_again(lambda: xbmc.Player().isPlayingVideo() and not xbmc.getInfoLabel('Player.Filenameandpath').startswith('http://127.0.0.1'))
            else:
                switched = self._switch(live)
                if covered:
                    _playing_again(lambda: xbmc.getCondVisibility('Pvr.IsPlayingTV'))
            self._mv_end()
            return switched
        return False

    def _play_alone(self, row):
        """``row``'s sport stream alone in Kodi's player (MultiView's Close, OK on its tile). A screen whose small video
        shows its own playback only plays it as its own (the Sport screen, MegaSport's page): Back from the player shows
        it there (idea 2026-11-21 "kad izadjem jos jednom zvuk ide bez slike samo artwork kanala": played here, the screen
        knew nothing of it and showed its event's picture over the sound)."""
        item = xbmcgui.ListItem(row.get('label') or 'Sport', path=row['mv_source']['address'])
        xbmc.Player().play(row['mv_source']['address'], item)

    def _mv_stop_left(self):
        """Leaving the screen that opened MultiView: what its Close left playing (the heard stream or channel) stops with
        it, as the screen's own playback does (idea 2026-11-20: "izasao sam na hub nakon multiviewa zvuk i dalje ide" -
        a new item of the grid's, no screen owned it). Not something else played since."""
        left, self._mv_left = getattr(self, '_mv_left', None), None
        if not left or not xbmc.Player().isPlayingVideo():
            return False
        if left.get('mv_source'):
            playing = xbmc.getInfoLabel('Player.Filenameandpath').split('|')[0]
            if playing != left['mv_source']['address'].split('|')[0]:
                return False
        elif not xbmc.getCondVisibility('Pvr.IsPlayingTV'):
            return False
        xbmc.Player().stop()
        return True

    def heard(self, n):
        """The grid's tile ``n`` has the cursor: its channel's sound ("kad hodam po plocicama zvuk je na kojoj je fokus")."""
        state = getattr(self, '_mv', None)
        if not state or n == state['sound'] or n >= len(state['rows']):
            return
        state['sound'] = n
        grid = getattr(self, '_grid', None)
        if grid is not None:
            grid.hear(n)                     # the grid's one sound (Kodi's audio track never changes: Kodi seeks then)
        xbmcgui.Window(10000).setProperty(MV + 'sound', str(n))
        window = getattr(self, '_mv_window', None)
        if window is not None:
            window.programme(state['rows'][n])

    def _mv_pick(self, rows, found, title, only_client=None):
        """A channel from the stable IPTV's tiles (this group's, Up / Down the others), None when none was chosen;
        ``only_client``: of that IPTV list only (Kodi's PVR client - a list is one provider)."""
        from .iptv import PlayerPicker
        group = getattr(self, '_group', 'alltv')
        load = self._channel_rows if only_client is None else (
            lambda g: [r for r in self._channel_rows(g) if r.get('clientid') == only_client])
        rows = rows if only_client is None else [r for r in (rows or load('alltv')) if r.get('clientid') == only_client] or load('alltv')
        picker = PlayerPicker('meganexus_iptv_picker.xml', ADDON_UI.getAddonInfo('path'), theme_folder(), '1080i', mode='strip',
                              rows=rows, selected=self._preview_of, title=title, groups=found, group=group, load=load)
        try:
            picker.doModal()
            return picker.chosen
        finally:
            del picker

    def _mv_show(self, channels, layout, sound):
        """The grid of ``channels`` (their order its cells') full screen, ``sound``'s audio heard."""
        from . import multiview
        from .iptv import plain_label
        from .multiview_layout import shape
        window = getattr(self, '_mv_window', None)
        if window is None:                           # the channel plays on meanwhile; a grid already shown: covered
            xbmcgui.Dialog().notification('MultiView', 'Opening %d channels...' % len(channels), time=4000)
        else:
            self._mv_cover(True)
        grid = getattr(self, '_grid', None) or multiview.Grid()
        address = grid.start(channels, layout, _folder(), sound)
        if not address:
            self._mv_end()
            xbmcgui.Dialog().notification('MultiView', 'The channels did not start - the provider may have refused one.', time=5000)
            return False
        kept = [r for r in channels if r.get('label') in grid.names]
        self._grid = grid
        self._mv = {'rows': kept, 'layout': layout, 'sound': min(sound, len(kept) - 1)}
        home = xbmcgui.Window(10000)
        home.setProperty('meganexus.iptv.multiview', '1')
        home.setProperty(MV + 'shape', shape(len(kept), layout))          # the skin's tiles over the grid
        for n in range(multiview.MAX):
            home.setProperty(MV + '%d.name' % n, plain_label(kept[n].get('label')) if n < len(kept) else '')
        home.setProperty(MV + 'sound', str(self._mv['sound']))
        home.setProperty(MV + 'full', '1' if len(kept) >= multiview.MAX else '')
        home.setProperty(MV + 'many', '1' if len(kept) > 2 else '')
        if getattr(self, '_mv_window', None) is None:                  # its tiles over it: they take the remote
            self._mv_window = MultiViewWindow('meganexus_multiview.xml', ADDON_UI.getAddonInfo('path'), theme_folder(), '1080i', owner=self)
            self._mv_cover(True)
            self._mv_window.show()
        item = xbmcgui.ListItem(path=address)
        item.setMimeType('application/vnd.apple.mpegurl')            # live HLS, not a playlist of Kodi's own
        item.setContentLookup(False)
        xbmc.Player().play(address, item)
        _playing_again(lambda: xbmc.Player().isPlayingVideo() and xbmc.getInfoLabel('Player.Filenameandpath') == address)
        self._mv_window.focus_tile(len(kept), layout, self._mv['sound'])
        self._mv_window.programme(kept[self._mv['sound']])
        self._mv_cover(False)
        return True

    def _mv_tiles(self):
        """Which tiles show their channel yet (its line has filled) - the skin says "Loading..." in the others - and
        whether the box keeps up (else Add channel goes: "mora raditi i na coreelecu" - a small box shows fewer)."""
        from . import multiview
        state = self._grid.state() if getattr(self, '_grid', None) is not None else {}
        tiles = state.get('tiles') or []
        home = xbmcgui.Window(10000)
        for n in range(multiview.MAX):
            home.setProperty(MV + '%d.shown' % n, '1' if n < len(tiles) and tiles[n].get('shown') else '')
        behind = state.get('late', 0) > multiview.BEHIND                 # the box does not keep up: no Add channel
        home.setProperty(MV + 'full', '1' if behind or len(getattr(self, '_mv', {}).get('rows') or ()) >= multiview.MAX else '')

    def _mv_cover(self, on):
        """The grid's window all ground ("Opening...") while the player changes; True when there is a window to cover."""
        xbmcgui.Window(10000).setProperty(MV + 'loading', '1' if on else '')
        return getattr(self, '_mv_window', None) is not None

    def _mv_end(self):
        grid, self._grid = getattr(self, '_grid', None), None
        if grid is not None:
            grid.stop()
        window, self._mv_window = getattr(self, '_mv_window', None), None
        if window is not None:
            window.close()
        home = xbmcgui.Window(10000)
        for name in ['meganexus.iptv.multiview'] + [MV + n for n in ('shape', 'sound', 'full', 'many', 'loading')] + [MV + '%d.%s' % (n, what) for n in range(4) for what in ('name', 'shown')]:
            home.clearProperty(name)


class MultiViewWindow(xbmcgui.WindowXMLDialog):
    """MultiView's tiles over its grid (review/make_multiview_window.py): the remote goes from tile to tile and the
    sound with it, OK on a tile: that channel alone; the buttons under them - Add channel, Layout, Take out, Close; Back:
    the grid closes, the heard channel stays. It asks its owner's player loop (owner._mv_command) as the player's buttons do."""
    TILES, BUTTONS, PROGRAMME = 600, 700, 800
    ADD, LAYOUT, OUT, CLOSE = 701, 702, 703, 704

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.owner = kwargs['owner']
        self._shape = None

    def _tile(self, control_id):
        """(shape index, n) of a tile's control, None for anything else."""
        if not self.TILES <= control_id < self.BUTTONS:
            return None
        return divmod(control_id - self.TILES, 10)

    def focus_tile(self, count, layout, n):
        from .multiview_layout import SHAPES
        self._shape = SHAPES.index((layout, count))
        try:
            self.setFocusId(self.TILES + 10 * self._shape + n)
        except RuntimeError:
            pass

    def programme(self, row):
        """What ``row``'s channel shows now, its times and how far (PVR's broadcast now), at the right under the tiles."""
        from .iptv import plain_label, rpc
        if row.get('mv_source'):                     # a sport add-on's stream: the event and the stream's name
            item = xbmcgui.ListItem(plain_label(row.get('label')))
            item.setLabel2(row['mv_source'].get('name') or 'Sport stream')
            item.setProperty('progress', '0')
            try:
                control = self.getControl(self.PROGRAMME)
                control.reset()
                control.addItem(item)
            except RuntimeError:
                pass
            return
        now = ((rpc('PVR.GetChannelDetails', {'channelid': row['channelid'], 'properties': ['broadcastnow']}) or {})
               .get('channeldetails') or {}).get('broadcastnow') or {}
        item = xbmcgui.ListItem(plain_label(now.get('title')) or plain_label(row.get('label')))
        item.setLabel2('  ·  '.join(x for x in (plain_label(row.get('label')), '%s - %s' % (_clock(now.get('starttime')), _clock(now.get('endtime')))
                                                if now.get('starttime') else '') if x))
        item.setProperty('progress', str(int(now.get('progresspercentage') or 0)))
        try:
            control = self.getControl(self.PROGRAMME)
            control.reset()
            control.addItem(item)
        except RuntimeError:
            pass

    def _ask(self, command):
        # idea 2026-11-20 "na multiview ne rade add channel izmjena izgleda i close kad radi vise kanala": its owner's
        # screen reads them - the Sport screen's player loop read its own property, never MegaIPTV's
        xbmcgui.Window(10000).setProperty(self.owner._mv_command, command)

    def onFocus(self, control_id):
        tile = self._tile(control_id)
        if tile is not None and tile[0] == self._shape:
            self.owner.heard(tile[1])

    def onClick(self, control_id):
        tile = self._tile(control_id)
        if tile is not None:
            return self._ask('mv:alone:%d' % tile[1])
        what = {self.ADD: 'add', self.LAYOUT: 'layout', self.OUT: 'out', self.CLOSE: 'close'}.get(control_id)
        if what:
            self._ask('mv:' + what)

    def onAction(self, action):
        if action.getId() in BACK:
            return self._ask('mv:close')
        if action.getId() == 3 and self.BUTTONS <= self.getFocusId() < self.BUTTONS + 10:   # Up from the buttons: the heard tile
            state = getattr(self.owner, '_mv', None) or {}
            if self._shape is not None:
                self.setFocusId(self.TILES + 10 * self._shape + state.get('sound', 0))


def _playing_again(ready, seconds=10.0):
    """Wait (a few seconds at most) until the player's change is done - ``ready`` says when."""
    monitor, until = xbmc.Monitor(), time.monotonic() + seconds
    while not ready() and time.monotonic() < until and not monitor.waitForAbort(.2):
        pass
