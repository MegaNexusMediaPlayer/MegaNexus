# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, MultiView: up to four live channels at once - "zar se nemoze u jednom playeru napraviti kao kamere
grid i da idu svi kanali u svoj grid", "odvojene prozore kao plocice a u njima su kanali".

Kodi has one video player, so the channels become one picture, as a camera recorder's grid, made by a process of its own
(multiview_grid.py - a process: served from Kodi's Python, Kodi froze, "smrzlo je"): each channel a line of its own -
its connection, its buffer, its decoder - and one clock that takes a picture from every line 25 times a second, so a
channel that comes late holds only its own tile (through one ffmpeg for all, one late channel stood the whole grid:
"zasteka svako nekoliko sekundi"). Kodi plays its short live HLS from 127.0.0.1 (as a file Kodi takes an .m3u8 for a
playlist of its own); the skin draws the tiles' corners, names and the heard one's ring over it
(review/make_multiview_window.py).

The channels' addresses are read from the lists MegaNexus wrote for Kodi (iptv_lists.live_file) when a grid starts and
given to the grid's process on its stdin - never in a command line, never logged. MultiView is there where an ffmpeg that
encodes and python3 are - the PC's Kodi, LibreELEC / CoreELEC with the ffmpeg-tools add-on ("mora raditi i na coreelecu
libreelecu"): tools() finds them and the box's profile."""
import glob
import json
import os
import platform
import re
import select
import shutil
import signal
import subprocess
import time

import xbmc
import xbmcvfs

from .multiview_layout import FOCUS, GRID  # noqa: F401  (megaiptv takes FOCUS from here)

MAX = 4
FOLDER = 'special://temp/meganexus_multiview/'
SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'multiview_grid.py')
READY = 3                 # pieces (a second each) written before Kodi is given the grid: it starts a moment behind them
START_WAIT = 15.0         # seconds its first pieces may take (it starts at once; the tiles fill as their lines do)
PORT_WAIT = 5.0           # seconds the grid's process may take to say its port
ERRORS = 'grid.txt'
TOOLS = 'meganexus.mv.tools'      # Window(Home): what this box makes a grid with, asked once a session
STATE = 'status.json'
BEHIND = .15              # of its last beats the box was behind: it shows no channel more
ADDRESS = re.compile(r'[a-z][a-z0-9+.-]*://\S+', re.I)


def _ffmpeg():
    """ffmpeg: the system's, else the ffmpeg-tools add-on's (LibreELEC / CoreELEC have it there, not as a program)."""
    found = shutil.which('ffmpeg')
    if found:
        return found
    for folder in (xbmcvfs.translatePath('special://home/addons/tools.ffmpeg-tools/bin'), '/storage/.kodi/addons/tools.ffmpeg-tools/bin'):
        path = os.path.join(folder, 'ffmpeg')
        if os.access(path, os.X_OK):
            return path
    return ''


def _encodes(binary, encoder, device=''):
    """A real second of encoding with ``encoder`` - a listed encoder may still not work on this box."""
    from .multiview_grid import video_codec
    cmd = [binary, '-hide_banner', '-nostdin', '-loglevel', 'error']
    cmd += ['-vaapi_device', device] if encoder == 'h264_vaapi' else []
    cmd += ['-f', 'lavfi', '-i', 'color=c=black:s=640x360:r=25:d=1']
    cmd += ['-vf', 'format=nv12,hwupload'] if encoder == 'h264_vaapi' else []
    try:
        return subprocess.run(cmd + video_codec(encoder) + ['-f', 'null', '-'], capture_output=True, timeout=20).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _small_box():
    """ARM, under 4 cores or under 3.5 GB: the light profile (a Fire TV Cube, a Raspberry Pi)."""
    try:
        with open('/proc/meminfo') as text:
            memory = int(next(line for line in text if line.startswith('MemTotal:')).split()[1]) / 1024.0 / 1024.0
    except (OSError, StopIteration, ValueError):
        memory = 0.0
    return platform.machine().lower().startswith(('arm', 'aarch')) or (os.cpu_count() or 1) < 4 or 0 < memory < 3.5


def tools():
    """What this box makes a grid with - {'ffmpeg', 'python3', 'profile'} - or None. Its encoder is the first that
    really encodes here: a hardware one (VAAPI on an Intel / AMD LibreELEC, V4L2), libx264, else MPEG-2 (in every
    ffmpeg; Kodi plays it). Asked once a Kodi session (it encodes a little to know)."""
    import xbmcgui
    home = xbmcgui.Window(10000)
    known = home.getProperty(TOOLS)
    if known:
        found = json.loads(known)
        return found or None
    binary, python = _ffmpeg(), shutil.which('python3') or ''
    found = {}
    if binary and python:
        try:
            listed = subprocess.run([binary, '-hide_banner', '-encoders'], capture_output=True, text=True, timeout=10).stdout
        except (OSError, subprocess.SubprocessError):
            listed = ''
        devices = sorted(glob.glob('/dev/dri/renderD*'))
        tries = [('h264_vaapi', d) for d in devices if ' h264_vaapi ' in listed] + \
                [(e, '') for e in ('h264_v4l2m2m', 'libx264', 'mpeg2video') if ' %s ' % e in listed]
        chosen = next(((e, d) for e, d in tries if _encodes(binary, e, d)), None)
        if chosen is not None:
            from .multiview_grid import FULL, LIGHT
            profile = dict(LIGHT if _small_box() else FULL, encoder=chosen[0], device=chosen[1])
            found = {'ffmpeg': binary, 'python3': python, 'profile': profile}
    xbmc.log('[MegaNexus] MultiView: %s' % ('%s, %s profile' % (found['profile']['encoder'], 'light' if found['profile']['light'] else 'full')
                                            if found else 'not on this box (no ffmpeg or python3 that can make a grid)'), xbmc.LOGINFO)
    home.setProperty(TOOLS, json.dumps(found))
    return found or None


def available():
    """MultiView on this box: an ffmpeg that encodes and python3 for the grid's process (tools())."""
    return tools() is not None


TOOLS_ADDON = 'tools.ffmpeg-tools'   # LibreELEC / CoreELEC: ffmpeg is this add-on of their own repository


def offer_tools():
    """True when MultiView can run here. On LibreELEC / CoreELEC without ffmpeg their repository's ffmpeg-tools add-on
    is offered first - Kodi's own question and progress ("multiview izbaci da nema ffmpeg addona pa ga ponudi da se
    instalira", 2026-11-19); what tools() kept for the session is asked again once it is in."""
    if available():
        return True
    import xbmcgui
    from resources.lib.kodi_restart import platform_kind
    if not _ffmpeg() and platform_kind() == 'elec':
        from .system_setup import ensure_addon
        if ensure_addon(TOOLS_ADDON):
            xbmcgui.Window(10000).clearProperty(TOOLS)
            if available():
                return True
    xbmcgui.Dialog().notification('MultiView', 'This box has no ffmpeg that can make a grid.', time=4000)
    return False


def channel_urls(folder, names):
    """{name: address} of the channels named, from the lists MegaNexus wrote for Kodi (#EXTINF ..., name / address)."""
    from resources.lib import iptv_lists
    wanted, found = set(names), {}
    for row in iptv_lists.load(folder):
        try:
            with open(iptv_lists.live_file(folder, row), encoding='utf-8', errors='replace') as text:
                name = None
                for line in text:
                    line = line.strip()
                    if line.startswith('#EXTINF'):
                        name = line.rsplit(',', 1)[-1].strip()
                    elif line and not line.startswith('#') and name:
                        if name in wanted and name not in found:
                            found[name] = line
                        name = None
        except OSError:
            continue
    return found


class Grid:
    """One grid's process at a time: ``start`` gives it the channels named (a channel already in it keeps its line),
    ``stop`` ends it, its lines and its pieces."""

    def __init__(self):
        self.process, self.port, self.gen = None, 0, 0
        self.names, self.layout = [], GRID
        self.folder = xbmcvfs.translatePath(FOLDER)

    @property
    def playlist(self):
        return os.path.join(self.folder, 'grid%d.m3u8' % self.gen)

    def _running(self):
        """The grid's process - started once, its port read from its first words."""
        if self.process is not None and self.process.poll() is None:
            return self.process
        self.process = None
        shutil.rmtree(self.folder, ignore_errors=True)
        os.makedirs(self.folder, exist_ok=True)
        found = tools()
        if found is None:
            return None
        # idea 2026-11-21 "na cube je instaliran ffmpeg tools ali ne radi multiview": python3 put the grid's folder
        # (meganexus_ui) first on its path, and the Calendar screen's calendar.py took the place of Python's own -
        # urllib's email imports it: "No module named 'xbmcaddon'" (the Cube's Python 3.11). -I: isolated, none of that
        with open(os.path.join(self.folder, ERRORS), 'w') as errors:
            process = subprocess.Popen([found['python3'], '-I', SCRIPT, self.folder, found['ffmpeg'], json.dumps(found['profile'])], stdin=subprocess.PIPE,
                                       stdout=subprocess.PIPE, stderr=errors, start_new_session=True)
        said = select.select([process.stdout], [], [], PORT_WAIT)[0]
        try:
            self.port = int(json.loads(process.stdout.readline() if said else b'')['port'])
        except (ValueError, KeyError, TypeError, OSError):
            xbmc.log('[MegaNexus] MultiView: the grid\'s process did not start%s' % self._why(), xbmc.LOGWARNING)
            _end(process)
            return None
        self.process = process
        return process

    def start(self, rows, layout, list_folder, heard=0):
        """The grid of ``rows`` (2 to MAX: an IPTV channel's row - its label - or a sport add-on's stream, its
        'mv_source' {'address'}) in ``layout``, the sound of the ``heard`` one of those that start; returns its address
        once Kodi can play it, '' if not."""
        rows = list(rows)[:MAX]
        urls = channel_urls(list_folder, [r.get('label') for r in rows if not r.get('mv_source')])
        sources, names = [], []
        for row in rows:
            stream = row.get('mv_source')
            if stream and stream.get('address'):
                sources.append([stream['address'], 'url'])          # its decoder reads it (HLS, the add-on's headers)
            elif row.get('label') in urls:
                sources.append(urls[row['label']])
            else:
                continue
            names.append(row.get('label'))
        if len(sources) < 2:
            xbmc.log('[MegaNexus] MultiView: the sources\' addresses were not found', xbmc.LOGWARNING)
            return ''
        process = self._running()
        if process is None:
            return ''
        self.gen += 1
        self.names, self.layout = names, layout
        try:
            process.stdin.write((json.dumps({'gen': self.gen, 'layout': layout, 'channels': sources,
                                             'heard': min(heard, len(sources) - 1)}) + '\n').encode())
            process.stdin.flush()
        except OSError:
            pass
        xbmc.log('[MegaNexus] MultiView: %d sources (%d streams of sport add-ons), %s'
                 % (len(sources), sum(1 for s in sources if not isinstance(s, str)), layout), xbmc.LOGINFO)
        monitor, until = xbmc.Monitor(), time.monotonic() + START_WAIT
        while time.monotonic() < until and not monitor.waitForAbort(.2):
            if process.poll() is not None:
                break
            if self._pieces() >= READY:
                return 'http://127.0.0.1:%d/grid%d.m3u8' % (self.port, self.gen)
        xbmc.log('[MegaNexus] MultiView: the grid did not start (%s)%s' % ('its process ended' if process.poll() is not None else 'too slow',
                                                                            self._why()), xbmc.LOGWARNING)
        self.stop()
        return ''

    def hear(self, n):
        """The grid's sound: its channel ``n``'s (Kodi's player plays on - its audio track is not changed)."""
        if self.running:
            try:
                self.process.stdin.write((json.dumps({'heard': n}) + '\n').encode())
                self.process.stdin.flush()
            except OSError:
                pass

    def state(self):
        """The grid's own words on its tiles - {'tiles': [{'shown', 'mark', 'held', 'dry', 'why'}, ...]} - {} before."""
        try:
            with open(os.path.join(self.folder, STATE), encoding='utf-8') as text:
                return json.load(text)
        except (OSError, ValueError):
            return {}

    def _why(self):
        """Why it ended: its process's last words and its lines', every address in them hidden."""
        lines = []
        try:
            with open(os.path.join(self.folder, ERRORS), encoding='utf-8', errors='replace') as text:
                lines = [line.strip() for line in text if line.strip()][-2:]
        except OSError:
            pass
        lines += [t.get('why') for t in self.state().get('tiles') or [] if t.get('why')]
        lines = [ADDRESS.sub('<address>', line) for line in lines]
        return (': ' + ' | '.join(lines)[:400]) if lines else ''

    def _pieces(self):
        try:
            with open(self.playlist, encoding='utf-8') as text:
                return sum(1 for line in text if line.strip().endswith('.ts'))
        except OSError:
            return 0

    @property
    def running(self):
        return self.process is not None and self.process.poll() is None

    def stop(self):
        """The grid ends: its process and everything of it (its group), its pieces."""
        process, self.process = self.process, None
        _end(process)
        shutil.rmtree(self.folder, ignore_errors=True)


def _end(process):
    """A process of the grid's ends (its group: nothing of it is left)."""
    if process is not None and process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=5)
        except (OSError, subprocess.SubprocessError):
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except OSError:
                pass
