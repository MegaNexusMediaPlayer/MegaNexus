# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The screen after a film or an episode (9.1.4).

"kad film zavrsi ili epizoda da se prikaze screen ... odgledao si film/epizodu ... ako nije npr 20% ostalo jos 1h ...
poster ... ocijeni odmah sa zvjezdicama 1 do 10 ... gumb exit koji na kojem stoji fokus ... plocicu za next episode ...
iza filma ... slicni filmovi ... pazi da se Home ne iscrta prije ovog ekrana ... i da nema bljeskova".

It opens the moment the film is left (trailers.wait_for_playback), before any MegaNexus screen is opened again behind
it, and the stop curtain fades onto it. The screens behind it then come back as they always did - and Home draws its
rows again there, out of sight (on the Cube 4 s after a film: Continue Watching built again, every row filled anew),
while the collections on its first screen are read into memory (HomeWindow.warm_after_film: the first collection after
a film read the disk for 1.9 s). Exit is then only this screen going: what is behind it is already drawn.

Kodi gives the keys to the MegaNexus screen opened last and draws by zorder (GUIWindowManager.cpp HandleAction /
RegisterDialog / RenderOrderSortFunction), so when a screen behind it has been opened again an identical one is opened
over it and the first goes (keep_on_top). Everything on it comes from Window(Home) properties - the new one draws the
same picture from its first frame, its opening animations do not run again (meganexus.postplay.shown).
"""
import json
import threading
import time

import xbmc
import xbmcgui

XML = 'meganexus_postplay.xml'
P = 'meganexus.postplay.'
SHOWING = 'meganexus.postplay'    # Window(Home): the screen is up (Home's trailers stand still - home_trailers)
MIN_SECONDS = 120                 # a film left sooner (the wrong source, a look) goes straight back
SIMILAR = 4
EXIT, REVIEW, NEXT = 10, 20, 50
STARS = tuple(range(31, 41))
SIMILAR_IDS = tuple(range(60, 60 + SIMILAR))
BACK = (9, 10, 92, 216, 247, 257, 275, 61448, 61467)
# what this screen writes (the places, meganexus.postplay.done.*, are the service's: resources/lib/postplay_told.py)
KEYS = ('chip', 'title', 'logo', 'background', 'line', 'headline', 'detail', 'steps', 'saved', 'rate.heading', 'rating',
        'rated', 'next.label', 'next.title', 'next.thumb', 'shown', 'leaving', 'away', 'done.meganexus') + \
    tuple('similar.%d.%s' % (index, part) for index in range(SIMILAR) for part in ('poster', 'title'))


class _State(object):
    window = None      # the screen with the keys
    owner = None       # the MegaNexus screen behind it (Home, a collection, a title page)
    data = None        # what it shows: see _data
    away = False       # the phone page is open over it
    warmed = False


_STATE = _State()


def showing():
    return _STATE.window is not None


def _home():
    return xbmcgui.Window(10000)


def _say(key, value):
    _home().setProperty(P + key, str(value) if value not in (None, False) else '')


def playing_now():
    """What plays, as the player's buttons know it (play_jobs.remember_playing) - read as the film starts: the service
    forgets it at the stop."""
    from .play_jobs import PLAYING
    return _home().getProperty(PLAYING)


# --- what it shows ---------------------------------------------------------------------------------------------

def _length(seconds):
    seconds = int(max(0, seconds))
    hours, minutes = seconds // 3600, (seconds % 3600) // 60
    if hours:
        return '%d h %d min' % (hours, minutes) if minutes else '%d h' % hours
    return '%d min' % minutes if minutes else '%d s' % seconds


def _saved(meta, context):
    """This title's place as the stop left it (continue_local - written before the screen opens): the row or None."""
    from resources.lib import continue_local
    try:
        rows = continue_local.recent()
    except Exception:
        return None
    video = str(context.get('video_id') or '')
    for row in rows:
        if row.get('canonical_id') != meta.get('id'):
            continue
        if video and row.get('video_id') not in (None, '') and str(row.get('video_id')) != video:
            continue
        return row
    return None


def texts(kind, position, duration, finished):
    """(headline, detail, lit bars of 20)."""
    what = 'film' if kind == 'movie' else 'episode'
    if finished:
        return ('You finished the %s' % what, 'Watched to the end' + (' · %s' % _length(duration) if duration else ''), 20)
    if not duration:
        return ('You stopped at %s' % _length(position), '', 0)
    left = max(0, duration - position)
    share = int(round(left * 100.0 / duration))
    return ('You stopped at %s' % _length(position), '%d%% left · %s to go' % (share, _length(left)),
            int(round((100 - share) / 5.0)))


def _episodes(meta):
    from resources.lib import title_details
    rows = title_details.episodes(meta)
    number = title_details.number
    return sorted(rows, key=lambda v: (number(v.get('season'), 1) == 0, number(v.get('season'), 1), number(v.get('episode'))))


def next_episode(meta, video_id, today=None):
    """The episode after this one that is already out (specials only after a special), or None."""
    from resources.lib import title_details
    number = title_details.number
    rows = _episodes(meta)
    at = next((index for index, row in enumerate(rows) if str(row.get('id')) == str(video_id)), None)
    if at is None:
        return None
    special = number(rows[at].get('season'), 1) == 0
    today = today or time.strftime('%Y-%m-%d')
    for row in rows[at + 1:]:
        if number(row.get('season'), 1) == 0 and not special:
            continue
        released = str(row.get('released') or row.get('firstAired') or '')[:10]
        if released and released > today:
            return None
        return row
    return None


def _credits(meta, context):
    """Where this video's end credits begin (s) as the service knew them (skip_service.note_credits), else 0."""
    try:
        known = json.loads(_home().getProperty('meganexus.playing.credits') or '{}')
    except ValueError:
        return 0.0
    if not isinstance(known, dict) or known.get('id') != str(context.get('video_id') or meta.get('id') or ''):
        return 0.0
    try:
        return float(known.get('at') or 0)
    except (TypeError, ValueError):
        return 0.0


def _data(snapshot, left_at=0.0):
    """What the screen shows for the film that was playing - None when it is not for this screen. ``left_at``: where
    the player was left (s), when it was."""
    try:
        playing = json.loads(snapshot or '{}')
    except ValueError:
        return None
    meta, context = playing.get('meta') or {}, playing.get('context') or {}
    kind = meta.get('type') or 'movie'
    if not meta.get('id') or kind not in ('movie', 'series'):
        return None
    row = _saved(meta, context)
    if row is None:
        return None
    position, duration = max(float(row.get('position') or 0), float(left_at or 0)), float(row.get('duration') or 0)
    # Back takes the film away before the service has saved the stop (3 s later on the Cube): where it was left, and
    # "watched" as the service will have it - its share, or the end credits begun (playback_watch.in_credits)
    from resources.lib.meganexus.paths import watched_percent
    credits = _credits(meta, context)
    finished = (row.get('event_type') == 'watched' or bool(duration and position * 100.0 / duration >= watched_percent())
                or bool(credits and position >= credits))
    if not finished and position < MIN_SECONDS:
        return None
    headline, detail, steps = texts(kind, position, duration, finished)
    name = str(meta.get('name') or meta.get('title') or '')
    episode = None
    if kind == 'series':
        episode = next((v for v in _episodes(meta) if str(v.get('id')) == str(context.get('video_id'))), None)
        season, number = context.get('season') or (episode or {}).get('season'), context.get('episode') or (episode or {}).get('episode')
        line = ' · '.join(part for part in (name, 'S%s E%s' % (season, number) if number not in (None, '') else '',
                                            str((episode or {}).get('name') or (episode or {}).get('title') or '')) if part)
    else:
        line = ' · '.join(str(part) for part in (meta.get('year') or meta.get('releaseInfo'),
                                                  ', '.join(map(str, (meta.get('genres') or [])[:3]))) if part)
    return {'meta': meta, 'context': context, 'kind': kind, 'finished': finished, 'name': name, 'line': line,
            'headline': headline, 'detail': detail, 'steps': steps, 'episode': episode}


def _publish(data):
    from resources.lib import art_cache
    meta = data['meta']
    picture = lambda url: art_cache.url(url) if url else ''
    for key in KEYS:
        _say(key, '')
    _say('chip', 'JUST WATCHED' if data['finished'] else 'CONTINUE LATER')
    _say('title', data['name'])
    _say('logo', picture(meta.get('logo') or meta.get('clearlogo') or ''))
    _say('background', picture(meta.get('background') or meta.get('fanart') or meta.get('poster') or ''))
    _say('line', data['line'])
    _say('headline', data['headline'])
    _say('detail', data['detail'])
    _say('steps', data['steps'])
    _say('saved', 'SAVED TO')
    _say('done.meganexus', '1')           # this box's Continue Watching / watched mark: written before the screen opened
    _say('rate.heading', 'RATE THIS %s' % ('EPISODE' if data['episode'] else 'SHOW' if data['kind'] == 'series' else 'FILM'))
    if data['kind'] == 'series':
        upcoming = next_episode(meta, data['context'].get('video_id'))
        if upcoming:
            _say('next.label', 'NEXT · S%s E%s' % (upcoming.get('season'), upcoming.get('episode')))
            _say('next.title', upcoming.get('name') or upcoming.get('title') or data['name'])
            _say('next.thumb', picture(upcoming.get('thumbnail') or meta.get('background') or meta.get('poster') or ''))
            data['next'] = upcoming


def _similar(data):
    """More like this (a film): the title's recommendations, fetched behind the screen."""
    from resources.lib import art_cache, title_details
    try:
        rows = title_details.related(data['meta'], limit=12)
    except Exception:
        rows = []
    rows = [row for row in rows if row.get('poster') and row.get('id')][:SIMILAR]
    if _STATE.data is not data:
        return
    data['similar'] = rows
    for index, row in enumerate(rows):
        _say('similar.%d.title' % index, row.get('name') or row.get('title') or '')
        _say('similar.%d.poster' % index, art_cache.url(row['poster']))


# --- the windows ----------------------------------------------------------------------------------------------

class PostPlay(xbmcgui.WindowXMLDialog):
    """Back / Exit leave it; the rest is in _clicked. Its methods hold no window in a closure."""
    focus_to = EXIT

    def onInit(self):
        if self.focus_to and self.focus_to != EXIT:
            try:
                self.setFocusId(self.focus_to)
            except Exception:
                pass

    def onClick(self, control_id):
        _clicked(control_id)

    def onAction(self, action):
        if action.getId() in BACK and self is _STATE.window:
            leave()


def _open(focus=EXIT):
    from .play_jobs import ROOT
    from resources.lib.theme import folder
    window = PostPlay(XML, ROOT, folder(), '1080i')
    window.focus_to = focus
    window.show()
    return window


def after_film(snapshot, left_at=0.0):
    """The film was left (wait_for_playback; ``left_at``: where, s): this screen at once, before the screens behind it
    come back. True when it opened."""
    if xbmc.Monitor().abortRequested() or xbmc.Player().isPlaying() or _home().getProperty('meganexus.next_episode'):
        return False
    data = _data(snapshot, left_at)
    if data is None:
        return False
    close()
    _STATE.data, _STATE.owner, _STATE.warmed, _STATE.away = data, None, False, False
    _publish(data)
    try:
        _STATE.window = _open()
    except Exception as exc:
        xbmc.log('[MegaNexus] After the film: the screen could not open (%r)' % exc, xbmc.LOGWARNING)
        _STATE.window = _STATE.data = None
        return False
    _say('shown', '1')                    # an identical one opened over it does not play the opening again
    _home().setProperty(SHOWING, '1')
    from .trailers import lift_curtain
    lift_curtain()
    if data['kind'] == 'movie':
        threading.Thread(target=_similar, args=(data,), name='MegaNexusAfterFilm', daemon=True).start()
    xbmc.log('[MegaNexus] After the film: %s (%s)' % (data['headline'], data['kind']), xbmc.LOGINFO)
    return True


def keep_on_top(window):
    """A MegaNexus screen opened again behind this one (Dialog's onInit): it would take the keys - an identical one
    goes over it and the old one goes. Home behind it reads its collections into memory meanwhile."""
    old = _STATE.window
    if old is None or _STATE.away or isinstance(window, PostPlay):
        return
    _STATE.owner = window
    try:
        focus = old.getFocusId()
    except Exception:
        focus = EXIT
    try:
        _STATE.window = _open(focus)
    except Exception as exc:
        xbmc.log('[MegaNexus] After the film: could not stay on top (%r)' % exc, xbmc.LOGWARNING)
        _STATE.window = old
        return
    try:
        old.close()
    except Exception:
        pass
    warm = getattr(window, 'warm_after_film', None)
    if warm is not None and not _STATE.warmed:
        _STATE.warmed = True
        try:
            warm()
        except Exception as exc:
            xbmc.log('[MegaNexus] After the film: no collections read ahead (%r)' % exc, xbmc.LOGWARNING)


def leave():
    """Exit / Back: the screen fades away over what is already drawn behind it."""
    window = _STATE.window
    if window is None:
        return
    _say('leaving', '1')
    _STATE.window = None
    _home().clearProperty(SHOWING)
    try:
        window.close()
    except Exception:
        pass


def close():
    """At once, no fade (MegaNexus closing, another film)."""
    window, _STATE.window = _STATE.window, None
    _STATE.owner = None
    _home().clearProperty(SHOWING)
    if window is not None:
        try:
            window.close()
        except Exception:
            pass


def _clicked(control_id):
    if control_id == EXIT:
        leave()
    elif control_id in STARS:
        rate(STARS.index(control_id) + 1)
    elif control_id == REVIEW:
        review()
    elif control_id == NEXT:
        upcoming = (_STATE.data or {}).get('next')
        if upcoming:
            meta = _STATE.data['meta']
            go({'canonical_id': meta['id'], 'media_type': 'series', 'video_id': upcoming['id'],
                'season': upcoming.get('season'), 'episode': upcoming.get('episode'), 'title': _STATE.data['name']}, True)
    elif control_id in SIMILAR_IDS:
        rows = (_STATE.data or {}).get('similar') or []
        index = SIMILAR_IDS.index(control_id)
        if index < len(rows):
            row = rows[index]
            go({'canonical_id': row['id'], 'media_type': row.get('type') or 'movie',
                'title': row.get('name') or row.get('title') or ''}, False)


def go(context, play):
    """Up next plays the episode, More like this opens the title's page - from the screen behind (as its own click
    would), once this one has gone."""
    owner = _STATE.owner
    leave()
    if owner is None or getattr(owner, '_dialog_closed', False):
        return
    custom = getattr(owner, 'open_after_film', None)

    def start():
        if custom is not None:
            return custom(context)
        from .details import open_context
        return (owner.in_place if play else owner.child)(open_context, context)
    owner.defer(start)


def _target():
    from resources.lib import rate_title
    data = _STATE.data or {}
    return rate_title.target(data.get('meta') or {}, data.get('episode'))


def rate(stars):
    """A star: the rating goes to Trakt and / or TMDB (the ones signed in), behind the screen."""
    from resources.lib import rate_title
    _say('rating', stars)
    where = [name for name, signed_in in rate_title.services() if signed_in]
    if not where:
        _say('rated', 'Sign in to Trakt or TMDB to rate')
        return
    target = _target()
    if not (target.get('imdb') or target.get('tmdb')):
        _say('rated', 'This title has no id to rate it by')
        return
    _say('rated', 'Sending %d/10…' % stars)
    data = _STATE.data

    def send():
        try:
            said = rate_title.send_to(target, stars, to_trakt='trakt' in where, to_tmdb='tmdb' in where).get('done') or 'Sent'
        except ValueError as exc:
            said = str(exc)
        except Exception as exc:
            said = 'Not sent (%s)' % type(exc).__name__
        if _STATE.data is data and str(_home().getProperty(P + 'rating')) == str(stars):
            _say('rated', said)
    threading.Thread(target=send, name='MegaNexusRate', daemon=True).start()


def review():
    """Write a review: the phone page we have (phone_setup, its QR) over this screen, which fades meanwhile."""
    from resources.lib import rate_title
    if not any(signed_in for _, signed_in in rate_title.services()):
        _say('rated', 'Sign in to Trakt or TMDB to rate')
        return
    target = _target()
    if not (target.get('imdb') or target.get('tmdb')):
        _say('rated', 'This title has no id to rate it by')
        return
    from .phone_setup import run
    _STATE.away = True
    _say('away', '1')
    try:
        sent = run(rating=target)
    finally:
        _STATE.away = False
        _say('away', '')
    if sent:
        _say('rated', sent.get('done') or 'Sent')
