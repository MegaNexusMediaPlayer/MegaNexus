# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from resources.lib import art_cache, library
from resources.lib.plain_text import without_emoji
from .dialog import Dialog
import xbmcaddon
import xbmcgui
from resources.lib import catalog_pages
from resources.lib import simkl_watched
from .play_jobs import _CATALOG
from resources.lib.theme import folder as theme_folder
from . import browse_meta
from . import listitems
from . import perf
import time
DETAILS_DWELL=.6   # seconds on a title before its details load quietly (6.0.32)


def _key(row):
    """A title once: by its id - 9.1.4: a local one (All local movies / series) by Kodi's library id."""
    local=row.get('local')
    if local:return ('local',local.get('type'),local.get('id'))
    return (row['target']['media_type'],row['target']['canonical_id'])


def _watched(row,watched):
    if row.get('local'):return row.get('watched')=='1'   # 9.1.4: Kodi's own mark of a local title
    target=row['target']
    return simkl_watched.watched_mark(watched,target['media_type'],target['canonical_id'],(target.get('imdb_id'),))

STATUS='meganexus.catalog.status'   # idea 2026-11-17: what there is to say, under the cards (review/make_big_home.py)
AHEAD=14                            # cards from the end at which the next page is asked for (two rows)


class Catalog(Dialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self.params=kwargs['params'];self.rows=[];self.jobs=[];self.outcome='';self._initialized=False;self._selected=0;self._page_job=None;self._alive=True;self._hover=(None,0.0)
    def onInit(self):
        self.setProperty('meganexus.title',without_emoji(self.params.get('label')) or 'Browse all')
        if self._initialized:
            rows=self.rows;self.rows=[];self.getControl(500).reset();self._append(rows)
            if self.rows:self.getControl(500).selectItem(min(self._selected,len(self.rows)-1))
            self.restore_focus();return
        self._initialized=True
        if 'rows' in self.params:
            self._append(self.params['rows']);self.focus(500);return
        try:self.jobs=catalog_pages.jobs_for(self.params)
        except ValueError as exc:xbmcgui.Dialog().ok('Collections',str(exc));self.close();return
        if self.params.get('initial_rows'):
            self._append(self.params['initial_rows']);self.focus(500)
        self._more()
    def _more(self):
        if self._page_job is not None:return
        if self.jobs and all(j['done'] for j in self.jobs):return
        self.setProperty(STATUS,'')   # 7.0.42: no loading words
        self._page_job=_CATALOG.submit(lambda:catalog_pages.fetch_page(self.jobs,stopped=lambda:not self._alive))

    def tick(self):
        if not self._alive:return
        self._hover_prefetch()
        self._near_the_end()
        if self._page_job is None or not self._page_job.done():return
        future,self._page_job=self._page_job,None
        try:result=future.result()
        except Exception:
            self.setProperty(STATUS,'Could not load titles · tried again at the end of the list');return
        if result is None:return
        rows,self.jobs=result
        shown=len(self.rows)
        self._append(rows)
        if self.rows:
            self.setFocusId(500)
            # 7.0.29: Load more keeps the cursor on the last title it showed (it went back to the top)
            if shown:self.getControl(500).selectItem(min(shown-1,len(self.rows)-1))
        jobs=[dict(j) for j in self.jobs]
        if not all(j['done'] for j in jobs):_CATALOG.submit(lambda:catalog_pages.prefetch_next(jobs))

    def _near_the_end(self):
        """idea 2026-11-17: the next page comes as the cursor nears the end - no Load more pill."""
        try:
            if 'rows' in self.params or not self.rows or self.getFocusId()!=500:return
            if self.getControl(500).getSelectedPosition()>=len(self.rows)-AHEAD:self._more()
        except Exception:return

    def _hover_prefetch(self):
        """Details of the title the cursor rests on load before Select (6.0.32)."""
        try:
            if not self.rows or self.getFocusId()!=500:return
            pos=self.getControl(500).getSelectedPosition()
        except Exception:return
        now=time.monotonic()
        if self._hover[0]!=pos:
            self._hover=(pos,now);return
        if now-self._hover[1]>=DETAILS_DWELL and 0<=pos<len(self.rows):
            row=self.rows[pos]
            if row.get('target') and not row.get('person'):browse_meta.prefetch(row['target'])

    def close(self):
        self._alive=False
        if self._page_job:self._page_job.cancel()
        super().close()

    def _append(self,rows):
        with perf.timed('Grid cards',added=len(rows)):self._append_rows(rows)

    def _append_rows(self,rows):
        seen={_key(r) for r in self.rows}
        items=[]
        watched=simkl_watched.snapshot()
        wide=xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape')=='landscape'
        for row in rows:
            key=_key(row)
            if key in seen:continue
            seen.add(key);self.rows.append(row)
            art=(row.get('landscape') or row.get('fanart') or row.get('poster')) if wide else row.get('poster')
            item=listitems.item(label=without_emoji(row['title']));item.setArt({'poster':art_cache.card(art)})
            item.setProperty('watched','1' if _watched(row,watched) else '')
            # 8.1.2: where the title lives, the same small round marks the Library draws
            # - Browse all opens with the Library's own cards and showed none of them.
            marks=[library.service_icon(name) for name in (row.get('services') or [])]
            marks=[mark for mark in marks if mark]
            for n in range(SERVICE_MARKS):
                item.setProperty('service.%d'%n,marks[n] if n<len(marks) else '')
            items.append(item)
        self.getControl(500).addItems(items)
        self.setProperty(STATUS,'' if self.rows else 'No titles found')
    def onClick(self,cid):
        if cid==500 and self.rows:
            from .details import open_context,open_person,plays_directly
            self._selected=self.getControl(500).getSelectedPosition()
            row=self.rows[self._selected]
            if row.get('local'):
                # 9.1.4: a title of this device (All local movies / series) plays as from Home's Local row
                from .local_storage import open_item
                self.outcome=self.child(open_item,row['local'])
                if self.outcome=='playing' or isinstance(self.outcome,dict):self.close()
                return
            # 7.0.44: a title opens like on Home - its top, the buttons where the rows are
            self.outcome=self.child(open_person,row['person']) if row.get('person') else \
                (self.in_place if plays_directly(row['target'],row) else self.child)(open_context,row['target'],row=row,
                                                                                      hero=not plays_directly(row['target'],row))
            if self.outcome=='playing' or isinstance(self.outcome,dict):self.close()
            else:
                watched=simkl_watched.snapshot()
                for i,row in enumerate(self.rows):
                    self.getControl(500).getListItem(i).setProperty('watched','1' if _watched(row,watched) else '')
    def onAction(self,action):
        if action.getId() in (9,10,92,216):self.close()
        elif action.getId() in (117,101,1009,11) and self.getFocusId()==500 and self.rows:
            from .details import context_choice,quick_choice,run_choice,open_person,plays_directly
            self._selected=self.getControl(500).getSelectedPosition()
            row=self.rows[self._selected]
            if row.get('local'):return   # 9.1.4: a title of this device has no title options
            if row.get('person'):self.outcome=self.child(open_person,row['person'])
            else:
                choice='details' if action.getId()==11 else context_choice(row['target'],row)
                if not choice or quick_choice(choice,row['target'],row):return
                self.outcome=(self.in_place if plays_directly(row['target'],row,choice) else self.child)(run_choice,row['target'],choice,row,
                                                                                         hero=choice in ('details','info'))
            if self.outcome=='playing' or isinstance(self.outcome,dict):self.close()

SERVICE_MARKS = 6          # this box, Nuvio, Trakt, Simkl, MDBList, WeTrakr


def open_catalog(params):
    wide=xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape')=='landscape'
    win=Catalog('meganexus_catalog_landscape.xml' if wide else 'meganexus_catalog.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',params=params)
    try:win.doModal();return win.outcome
    except ValueError as exc:xbmcgui.Dialog().ok('Collections',str(exc));return ''
    finally:win.close()
