# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, MegaSport: "mora biti potpuni redizajn da prihvaca strimove i addone sportske tablice prave izgleda
kao na kladionicama ... da bude brutalan"; "lige favoriti live eventi sa rezultatima iptv kanali koji nude stream ...
sve dinamicno"; "i sport mora imati multiview".

A live-score page (review/make_megasport_screen.py): the sports as tabs, the sections and leagues on the left, the
matches in the middle (a league's head, then a row a match: its minute, both sides, the score, the TV mark, how many
add-on events have it) - or a league's table - and on the right what plays, the match's details and its sources.

* The matches are ESPN's (resources/lib/sport_scores.py: the followed leagues' week - results, live ones with their
  minute, the ones to come; the tables); the sport add-ons' events are the Sport screen's (resources/lib/sports.py: their
  catalogs) - an event of them naming both sides is that match's (its streams are the match's), the others are Add-on
  events; the IPTV channel that shows a match is found in the person's own guide (resources/lib/sport_channels.py,
  sport_names.py: a national side in the box's language); On your channels: the guide's own sport, now and next.
* OK on a match plays its first source in the box (its IPTV channel, else its first stream); OK on a source plays that
  one; OK on what plays: full screen (Kodi's player - MultiView's button there; Back comes down to this page).
* MultiView (meganexus_ui/multiview_host.py): what plays and the sport add-ons' live streams - one IPTV channel at most.
* The live leagues are asked again every LIVE_EVERY seconds - the rows change in place (the cursor stays).
* Options: the leagues of any of ESPN's sports, the teams (Favourites), then MegaIPTV's own Options."""
import collections
import datetime
import json
import os
import queue
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import screen_guard, sport_channels, sport_names, sport_scores
from resources.lib.script_exit import drop
from resources.lib.theme import folder as theme_folder
from . import megaiptv
from .home_window import ADDON, BACK
from .megaiptv import _iptv_settings, _setting_json
from .multiview_host import MultiViewHost
from .play_jobs import plain_label

XML, TABLES_XML = 'meganexus_megasport.xml', 'meganexus_megasport_tables.xml'
TABS, SECTIONS, ROWS, SOURCES, LEGEND = 300, 400, 500, 600, 700
SEARCH, RESULTS, STREAMS, TABLES, FAVOURITES, MULTIVIEW, OPTIONS, HUB = 105, 101, 102, 103, 104, 106, 107, 108   # the top bar's icons
NOW = 113          # after HUB while a video plays (Sport's stream goes on under these screens): back to the big player
BAR = (SEARCH, RESULTS, STREAMS, TABLES, FAVOURITES, MULTIVIEW, OPTIONS, HUB, NOW)
P = 'megasport.'
FOLLOW = 'meganexus_sport_follow'      # {'chosen', 'leagues': [[sport, league, name]], 'teams': [[sport, league, id, name, logo]]}
KEPT = 'meganexus.megasport.kept'      # Window(Home): the last matches, for the next opening at once (Kodi's memory, not disk)
KEPT_FOR = 6 * 3600                    # seconds old they may be to be shown at once (fresh ones replace them in seconds)
MV_MOST = 4                            # MultiView's tiles picked on the page (multiview.MAX), your channels one of them at most
PREFETCH_TABLES = 6                    # tables asked for the Tables screen as MegaSport opens (_prefetch_tables)
EXTRAS_EVERY = 300                     # seconds between asking the add-ons' events and the guide again
BOARD_EVERY = 600                      # seconds between asking every sport again (the live ones: LIVE_EVERY)
NEXT_DAYS = 7                          # Coming up: the matches of the next days (a season that starts in March is not)
LIVE_EVERY = 60                        # seconds between asking the live leagues again
REST = .35                             # seconds the cursor rests on a row before its details and sources come
TAB_REST = .6                          # seconds the cursor rests on a sport's pill before the page is that sport's
NEAR = datetime.timedelta(hours=3)     # a match this near (or on) has its channel looked for
SAME_EVENT = 3                         # an add-on event naming both sides is the match's
ALL = 'all'
ICON = 'special://home/addons/script.meganexus/resources/media/bar/icon_%s.png'
SECTION_ICONS = {'live': 'livetv', 'today': 'calendar', 'next': 'next', 'tv': 'guide', 'addons': 'streams', 'teams': 'bookmark'}
OSD_SPORT = 'meganexus.sport.open'     # Window(Home): MegaSport's playback is in Kodi's player (its MultiView button)


BACKGROUND = 'special://home/addons/script.meganexus/resources/media/sport_bg/%s.jpg'


def sport_background(slug):
    """A sport's own picture behind the page (review/make_sport_backgrounds.py); a sport with none, and All: a stadium."""
    own = BACKGROUND % slug
    return own if slug != ALL and os.path.exists(xbmcvfs.translatePath(own)) else BACKGROUND % 'all'


def sport_icon(slug):
    """A sport's round pill's icon (review/make_bar_icons.py: Material Symbols for ESPN's sports, a cup for All); a
    sport ESPN adds that has none: a whistle."""
    own = ICON % ('sport_%s' % slug)
    return own if os.path.exists(xbmcvfs.translatePath(own)) else ICON % 'sport_any'


# ---- what the person follows -----------------------------------------------------------------------------------------
def followed():
    """([(sport, league, name)], [{'sport', 'league', 'id', 'name', 'logo'}]) - what the person follows; nothing chosen
    yet: ESPN's first leagues that play this week."""
    data = _setting_json(FOLLOW) or {}
    leagues = [tuple(l[:3]) for l in data.get('leagues') or [] if isinstance(l, list) and len(l) >= 3]
    teams = [dict(zip(('sport', 'league', 'id', 'name', 'logo'), t)) for t in data.get('teams') or [] if isinstance(t, list) and len(t) >= 4]
    return leagues, teams


def kept_matches():
    """The matches of the last opening (Window(Home), KEPT_FOR seconds) - shown at once while fresh ones come."""
    try:
        kept = json.loads(xbmcgui.Window(10000).getProperty(KEPT) or '{}')
    except ValueError:
        return []
    if time.time() - kept.get('at', 0) > KEPT_FOR:
        return []
    out = []
    for match in kept.get('matches') or []:
        try:
            match['start'] = datetime.datetime.fromisoformat(match['start']) if match.get('start') else None
        except ValueError:
            match['start'] = None
        out.append(match)
    return out


def keep_matches(matches):
    plain = [dict({k: v for k, v in m.items() if k not in ('events', 'tv')}, start=m['start'].isoformat() if m.get('start') else '')
             for m in matches]
    xbmcgui.Window(10000).setProperty(KEPT, json.dumps({'at': time.time(), 'matches': plain}))


def keep(leagues, teams):
    _iptv_settings().setSetting(FOLLOW, json.dumps({'chosen': True, 'leagues': [list(l) for l in leagues],
                                                    'teams': [[t['sport'], t['league'], t['id'], t['name'], t.get('logo', '')] for t in teams]}))


# ---- words -----------------------------------------------------------------------------------------------------------
def when_said(match, now=None):
    """A row's time: "67'" (live), 'FT', '20:45' today, 'Tmrw 20:45', 'Sat 15:00', '22 Nov'."""
    if match['state'] == sport_scores.LIVE:
        clock = match.get('clock') or ''
        return clock if clock and clock not in ('0:00', "0'") else (match.get('detail') or 'LIVE')
    if match['state'] == sport_scores.OVER:
        return match.get('detail') or 'FT'
    start = match['start'].astimezone() if match.get('start') else None
    if start is None:
        return match.get('detail') or ''
    today = (now or datetime.datetime.now().astimezone()).date()
    if start.date() == today:
        return start.strftime('%H:%M')
    if start.date() == today + datetime.timedelta(days=1):
        return 'Tmrw %s' % start.strftime('%H:%M')
    if 0 < (start.date() - today).days < 7:
        return start.strftime('%a %H:%M')
    return start.strftime('%d %b')


def score_said(match):
    sides = match.get('sides') or []
    if not match.get('pair') or len(sides) != 2 or match['state'] == sport_scores.BEFORE or sides[0]['score'] == '':
        return '–' if match.get('pair') else ''
    return '%s : %s' % (sides[0]['score'], sides[1]['score'])


def side_name(side):
    return side.get('short') or side.get('name') or ''


# ---- the guide's sport, the add-ons' events ----------------------------------------------------------------------------
SPORT_GENRE = ('sport', 'deport')        # a guide's genre for sport, as XMLTV guides write it (Sport, Sports, Šport, Deportes)


def is_sport(programme, channel=None):
    """Sport: the guide says so (its genre), or its channel is a sport channel (its name - "Arena Sport 1", "Sport Klub",
    "Eurosport": many guides give no genre, every programme "Other / Unknown")."""
    genre = programme.get('genre') or ''
    said = ' '.join(genre) if isinstance(genre, list) else str(genre)
    name = ' '.join(sport_channels.words((channel or {}).get('label')))
    return any(word in ' '.join(sport_channels.words(said)) or word in name for word in SPORT_GENRE)


def _channels():
    from .iptv import rpc
    reply = rpc('PVR.GetChannels', {'channelgroupid': 'alltv', 'properties': ['icon', 'channelnumber', 'uniqueid', 'clientid',
                                                                             'broadcastnow', 'broadcastnext']}) or {}
    return sorted(reply.get('channels') or [], key=lambda r: int(r.get('channelnumber') or 0))


def programmes(channels):
    """[(channel, programme)] - what is on now and next on every channel, its times as datetimes."""
    from .iptv import epg_time
    out = []
    for channel in channels:
        for which in ('broadcastnow', 'broadcastnext'):
            programme = channel.get(which) or {}
            if programme.get('title'):
                out.append((channel, dict(programme, start=epg_time(programme.get('starttime')), end=epg_time(programme.get('endtime')),
                                          now=which == 'broadcastnow')))
    return out


def guide_sport(found):
    """On your channels: the guide's own sport (its genre) on now and next, a programme once (a channel's HD and FHD
    copies are one), on now first."""
    seen, out = set(), []
    for now in (True, False):
        for channel, programme in found:
            key = (programme.get('title'), programme.get('starttime'))
            if programme['now'] == now and is_sport(programme, channel) and key not in seen:
                seen.add(key)
                out.append((channel, programme))
    return out


def addon_events():
    """The sport add-ons' events (their catalogs - kept ones first, else asked), each once, live first."""
    from resources.lib import sports
    out, seen = [], set()
    for provider, catalog in sports.catalogs():
        metas, fresh = sports.cached_page(provider, catalog)
        if metas is None or not fresh:
            try:
                metas = sports.load_page(provider, catalog, timeout=8)
            except Exception:
                metas = metas or []
        for meta in metas or []:
            card = sports.card(provider, catalog, meta)
            if card['id'] not in seen:
                seen.add(card['id'])
                out.append(dict(card, addon=provider.get('name') or ''))
    return sorted(out, key=lambda e: not e['live'])


def link(matches, events, found, folder=''):
    """Each match's add-on events (their title names both sides) and its IPTV channel (the guide, now or next at its
    time); the events left over are the add-ons' own."""
    now = datetime.datetime.now(datetime.timezone.utc)
    taken = set()
    for match in matches:
        near = match['state'] == sport_scores.LIVE or (match.get('start') and abs(match['start'] - now) <= NEAR)
        match['tv'] = None
        if near:
            sport_names.add_local_names(match, folder)
            hits = sport_channels.channels_for(match, found)
            match['tv'] = hits[0][1] if hits else None
        match['events'] = [e for e in events if sport_channels.likeness(match, e['title']) >= SAME_EVENT]
        taken |= {e['id'] for e in match['events']}
    return [e for e in events if e['id'] not in taken]


# ---- the page's lines ----------------------------------------------------------------------------------------------
def source_keys(match):
    keys = ['iptv:%s' % match['tv']['channelid']] if match.get('tv') else []
    return keys + ['event:%s' % e['id'] for e in match.get('events') or []]


def match_line(match, playing_key=''):
    sides = match.get('sides') or []
    pair = match.get('pair') and len(sides) == 2
    return {'kind': 'match', 'key': 'match:%s' % match['id'], 'label': match.get('name') or '', 'pair': '1' if pair else '',
            'status': when_said(match), 'live': '1' if match['state'] == sport_scores.LIVE else '',
            'home': side_name(sides[0]) if pair else (match.get('name') or ''), 'away': side_name(sides[1]) if pair else '',
            'home_logo': sides[0]['logo'] if pair else match.get('league_logo') or '', 'away_logo': sides[1]['logo'] if pair else '',
            'score': score_said(match), 'long': '1' if len(score_said(match)) > 7 else '', 'tv': '1' if match.get('tv') else '',
            'streams': str(len(match['events'])) if match.get('events') else '',
            'playing': '1' if playing_key and any(playing_key.startswith(k) for k in source_keys(match)) else '', 'match': match}


def event_line(event, playing_key=''):
    from resources.lib.sport_time import kickoff
    try:
        when = kickoff(event.get('info'), live=bool(event.get('live')))
    except Exception:
        when = event.get('info') or ''
    key = 'event:%s' % event['id']
    return {'kind': 'event', 'key': key, 'label': plain_label(event['title']), 'label2': event.get('addon') or '',
            'status': 'LIVE' if event.get('live') else (when or ''), 'live': '1' if event.get('live') else '', 'thumb': event.get('art') or '',
            'playing': '1' if playing_key.startswith(key) else '', 'event': event}


def guide_line(channel, programme, playing_key=''):
    from .multiview_host import _clock
    return {'kind': 'event', 'key': 'guide:%s:%s' % (channel['channelid'], programme.get('starttime')), 'label': plain_label(programme.get('title')),
            'label2': plain_label(channel.get('label')), 'status': 'LIVE' if programme['now'] else _clock(programme.get('starttime')),
            'live': '1' if programme['now'] else '', 'thumb': channel.get('icon') or '',
            'playing': '1' if playing_key == 'iptv:%s' % channel['channelid'] else '', 'channel': channel, 'programme': programme}


def head_line(name, logo):
    return {'kind': 'head', 'key': 'head:%s' % name, 'label': name, 'icon': logo}


def grouped(matches, playing_key=''):
    """The matches by league - its head, then its matches (the live ones first, then in time order)."""
    far = datetime.datetime.max.replace(tzinfo=datetime.timezone.utc)
    out, by = [], {}
    for match in matches:
        by.setdefault((match['sport'], match['league']), []).append(match)
    for group in by.values():
        group.sort(key=lambda m: (m['state'] != sport_scores.LIVE, m.get('start') or far))
        out.append(head_line(group[0].get('league_name') or group[0]['league'], group[0].get('league_logo') or ''))
        out += [match_line(m, playing_key) for m in group]
    return out


def zones(groups):
    """The zones of a table (ESPN's notes: Champions League, relegation ...) and their colours, each once."""
    return list(dict.fromkeys((row['zone'], row['zone_colour']) for group in groups for row in group['rows']
                              if row.get('zone') and row.get('zone_colour')))


def table_lines(groups, mine=()):
    """A league's table: its columns' heads, then a team a line (the followed ones and the chosen match's marked)."""
    out = []
    for group in groups:
        if len(groups) > 1 and group.get('name'):
            out.append(head_line(group['name'], ''))
        out.append({'kind': 'tablehead', 'key': 'tablehead:%s' % group.get('name')})
        for row in group['rows']:
            out.append({'kind': 'team', 'key': 'team:%s:%s' % (group.get('name'), row['id']), 'rank': row['rank'], 'team': row['team'],
                        'icon': row['logo'], 'p': row['played'], 'w': row['won'], 'd': row['drawn'], 'l': row['lost'],
                        'gf': row.get('for', ''), 'ga': row.get('against', ''), 'gd': row['diff'], 'pts': row['points'],
                        'zone_colour': row.get('zone_colour') or '', 'mine': '1' if row['id'] in mine else ''})
    return out


def coming(match, today):
    """A match of the next NEXT_DAYS days (not today's)."""
    if match['state'] != sport_scores.BEFORE or not match.get('start'):
        return False
    return 0 < (match['start'].astimezone().date() - today).days <= NEXT_DAYS


def in_tab(match, tab):
    return tab == ALL or match['sport'] == tab


def section_lines(tab, matches, guide, events, leagues, teams, current):
    """The left: the sections, then the tab's leagues - each with how many."""
    today = datetime.datetime.now().astimezone().date()
    mine = [m for m in matches if in_tab(m, tab)]
    count = {'live': sum(m['state'] == sport_scores.LIVE for m in mine),
             'today': sum(bool(m.get('start')) and m['start'].astimezone().date() == today for m in mine),
             'next': sum(coming(m, today) for m in mine),
             'tv': len(guide), 'addons': len(events)}
    names = (('live', 'Live now'), ('today', 'Today'), ('next', 'Coming up'), ('tv', 'On your channels'), ('addons', 'Add-on events'))
    out = [{'key': 'section:' + key, 'label': word, 'label2': str(count[key]) if count[key] else '', 'icon': ICON % SECTION_ICONS[key],
            'section': (key,)} for key, word in names]
    if teams:
        out.append({'key': 'section:teams', 'label': 'Favourites', 'label2': '', 'icon': ICON % SECTION_ICONS['teams'], 'section': ('teams',)})
    out[-1]['after'] = 'line'
    logos = {(m['sport'], m['league']): m.get('league_logo') or '' for m in matches}
    for sport, slug, name in leagues:
        if tab == ALL or sport == tab:
            n = sum(1 for m in matches if (m['sport'], m['league']) == (sport, slug))
            out.append({'key': 'league:%s/%s' % (sport, slug), 'label': name, 'label2': str(n) if n else '', 'icon': logos.get((sport, slug), ''),
                        'section': ('league', sport, slug, name)})
    for line in out:
        line['current'] = '1' if line['section'] == tuple(current) else ''
    return out


def lines_for(section, tab, matches, guide, events, teams, playing_key=''):
    """The middle's lines for a section (the matches by league, or the guide's / the add-ons' events)."""
    today = datetime.datetime.now().astimezone().date()
    mine = [m for m in matches if in_tab(m, tab)]
    kind = section[0]
    if kind == 'tv':
        return [guide_line(c, p, playing_key) for c, p in guide]
    if kind == 'addons':
        return [event_line(e, playing_key) for e in events]
    if kind == 'live':
        picked = [m for m in mine if m['state'] == sport_scores.LIVE]
    elif kind == 'today':
        picked = [m for m in mine if m.get('start') and m['start'].astimezone().date() == today]
    elif kind == 'next':
        picked = [m for m in mine if coming(m, today)]
    elif kind == 'teams':
        ids = {(t['sport'], t['id']) for t in teams}            # ESPN's team id is the team's in every competition
        picked = [m for m in matches if any((m['sport'], s['id']) in ids for s in m['sides'])]
    else:
        picked = [m for m in matches if (m['sport'], m['league']) == (section[1], section[2])]
    return grouped(picked, playing_key)


PROPS = ('status', 'live', 'home', 'away', 'score', 'tv', 'streams', 'playing', 'kind', 'rank', 'team', 'p', 'w', 'd', 'l', 'gd', 'pts',
         'mine', 'current', 'after', 'pair', 'long', 'gf', 'ga', 'zone_colour', 'picked')


def fill(control, before, lines):
    """``control``'s items for ``lines``: the same lines as ``before`` (a refresh) change where they are - no reset, the
    cursor stays and nothing blinks; other lines: the list anew."""
    if [l.get('key') for l in lines] == [l.get('key') for l in before]:
        for n, line in enumerate(lines):
            item = control.getListItem(n)
            item.setLabel(line.get('label') or '')
            item.setArt({'home_logo': line.get('home_logo') or '', 'away_logo': line.get('away_logo') or '',
                         'icon': line.get('icon') or '', 'thumb': line.get('thumb') or ''})
            _set(item, line)
        return False
    control.reset()
    control.addItems([list_item(line) for line in lines])
    return True


def _set(item, line):
    for key in PROPS:
        item.setProperty(key, str(line.get(key) or ''))
    if 'label2' in line:
        item.setLabel2(line.get('label2') or '')


def list_item(line):
    item = xbmcgui.ListItem(line.get('label') or '')
    item.setArt({'home_logo': line.get('home_logo') or '', 'away_logo': line.get('away_logo') or '',
                 'icon': line.get('icon') or '', 'thumb': line.get('thumb') or ''})
    _set(item, line)
    return item


# ---- MultiView (meganexus_ui/multiview_host.py) ----------------------------------------------------------------------
class SportGrid(MultiViewHost):
    """MultiView of what a sport screen plays (the Sport screen's stream, the page's channel or stream) with the sport
    add-ons' live streams beside it - one IPTV channel at most."""
    _preview_of, _group, _first = None, 'alltv', None

    def begin(self, row):
        """MultiView over ``row`` (a tile's row) - a live sport stream picked beside it; True once the grid plays."""
        self._first = row
        return self._multiview([], [])

    def _playing_row(self, rows):
        return self._first

    def _channel_rows(self, group):
        from .iptv import channels
        return channels(group) or []

    def _switch(self, row):
        from .iptv import item_for, rpc
        self._preview_of = row['channelid']
        rpc('Player.Open', {'item': item_for(row['channelid'])})
        return True

    def _multiview(self, rows, found):
        from .multiview import GRID
        from .multiview_sources import pick_tile
        first = self._playing_row(rows)
        chosen = pick_tile([first], self, self._channel_rows('alltv'), [], 'MultiView: beside it') if first else None
        return bool(chosen) and self._mv_show([first, chosen], GRID, 0)


# ---- the page ------------------------------------------------------------------------------------------------------------
class _SportPage(object):
    def _now_playing(self):
        """Now playing: Kodi's player for what plays (the Sport screen's stream goes on under these screens) - back here
        when it is left."""
        if not xbmc.getCondVisibility('Player.HasVideo'):
            return
        from .dialog import close_into_player
        monitor = xbmc.Monitor()
        close_into_player(self)
        seen, start = False, time.monotonic()
        while not monitor.waitForAbort(.1):
            full = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
            seen = seen or full
            if (seen and not full) or not xbmc.Player().isPlayingVideo() or (not seen and time.monotonic() - start > 5):
                break
        if not monitor.abortRequested():
            self.show()
            self.setFocusId(NOW if xbmc.getCondVisibility('Player.HasVideo') else HUB)

    """What the scores page and the Tables screen share: the sports' strip, the heads the cursor goes past."""

    def _paint_tabs(self):
        """Every sport ESPN has (the followed ones first), after All."""
        followed_sports = list(dict.fromkeys(s for s, _, _ in self.leagues))
        others = [s for s, _ in self.sports if s not in followed_sports]
        self.tabs = [(ALL, 'All sports')] + [(s, sport_scores._name(s)) for s in followed_sports + others]
        lines = [{'key': key, 'label': word, 'icon': sport_icon(key), 'current': '1' if key == self.tab else ''} for key, word in self.tabs]
        fill(self.getControl(TABS), getattr(self, '_tab_lines', []), lines)
        self._tab_lines = lines
        self.setProperty(P + 'bg', sport_background(self.tab))     # the sport's picture, melting into the next one's

    def _strip_on_shown(self):
        """The cursor left the sports before one was chosen: the strip's selected pill - drawn with its name - is the
        sport shown again."""
        at = next((n for n, (key, _) in enumerate(self.tabs) if key == self.tab), 0)
        control = self.getControl(TABS)
        if control.getSelectedPosition() != at:
            control.selectItem(at)

    def _past_heads(self):
        """A league's head or a table's column heads take no cursor: it goes on past them the way it came (Kodi gives a
        dialog no Up / Down of its own to see)."""
        control = self.getControl(ROWS)
        at = control.getSelectedPosition()
        before, self._row_at = getattr(self, '_row_at', at), at
        if not 0 <= at < len(self.lines) or self.lines[at]['kind'] not in ('head', 'tablehead'):
            return
        way = -1 if at < before else 1
        step = at + way
        while 0 <= step < len(self.lines) and self.lines[step]['kind'] in ('head', 'tablehead'):
            step += way
        if not 0 <= step < len(self.lines):                 # the first line is a head
            step = at + 1
            while step < len(self.lines) and self.lines[step]['kind'] in ('head', 'tablehead'):
                step += 1
            if way < 0 and 0 <= step < len(self.lines):     # Up onto it: up out of the list, as from its first line
                control.selectItem(step)                     # ("sa lijevog dijela na sredisnji ... nemogu gore")
                self._row_at = step
                return self.setFocusId(TABS)
        if 0 <= step < len(self.lines):
            control.selectItem(step)
            self._row_at = step
            self.moved_at = time.monotonic()

    def _native_close(self):
        try:
            xbmcgui.WindowXMLDialog.close(self)
        except Exception:
            pass

    def _settle_focus(self):
        try:
            self.setFocusId(ROWS if self.lines else SECTIONS)
        except RuntimeError:
            pass


class MegaSportScreen(_SportPage, SportGrid, xbmcgui.WindowXMLDialog):
    after_ready = None                       # the line whose first source plays once its streams come (OK before they did)

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.intent = kwargs.get('intent') or 'scores'      # what the page was opened for: scores, tables, teams
        self.from_sport = bool(kwargs.get('from_sport'))     # opened by the Sport screen: Back / Streams go back to it
        self.tab, self.section, self.mode = ALL, ('live',), 'matches'
        self.matches, self.events, self.guide, self.leagues, self.teams = [], [], [], [], []
        self.sports, self.by_key, self.found = [], {}, []   # ESPN's sports; every match by its key; the guide's now and next
        self.events_all = []                 # every add-on event (self.events: the ones no match has)
        self.extras_at, self.board_at, self.kept_at = 0.0, 0.0, 0.0
        # how the first loading went, one [perf] line once every board is in: what to make faster, read on the box
        # ("loading the matches je prespor svaki put traje vjecnost", idea 2026-11-19)
        self.opened_at, self.timing, self.timed = time.monotonic(), collections.Counter(), False
        self.asked_before = collections.Counter(sport_scores.asked)
        self.extras_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='MegaSportExtras')
        self.tabs, self.sections, self.lines, self.sources = [], [], [], []
        self.loading_tabs = set()            # the sports whose leagues are being got
        self.behind = kwargs.get('behind')   # the Sport screen under this page: hidden while the page is up
        self.ready = False
        self.results = queue.Queue()
        self.pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix='MegaSport')
        self.closed, self.pending, self.loaded = False, '', False
        self.playing = None                   # the source that plays: {'key', 'kind', 'label', ...}
        self.chosen = None                    # the line whose details show
        self.moved_at, self.asked_for = time.monotonic(), None
        self.section_chosen = False           # the person chose a section (a click): it is never changed for them
        self.live_at = time.monotonic()
        self.stream_cache = {}                # an add-on event's streams (while MegaSport is open)
        self._preview_of, self._group, self._windowed = None, 'alltv', False
        self.token = ''

    # Kodi's window ------------------------------------------------------------------------------------------------------
    def onInit(self):
        self.ready = True
        if not self.tabs:
            self.setProperty(P + 'note', 'Loading the matches...')
            self.setProperty(P + 'mode', 'matches')
            self.leagues, self.teams = followed()
            self._paint_tabs()
            kept = kept_matches()                       # the last opening's, at once
            if kept:
                self._took(('board', None, kept))
            self.pool.submit(self._prefetch_tables)     # first: the minute's first ESPN requests are theirs
            self.pool.submit(self._load_all)
            if self.intent == 'multiview':              # MultiView's button on the Tables or Favourites
                return self._multiview_button()
        self.setFocusId(ROWS if self.lines else SECTIONS)

    def onFocus(self, control_id):
        self.moved_at = time.monotonic()

    def onAction(self, action):
        self.moved_at = time.monotonic()
        aid = action.getId()
        if aid in BACK:
            if self.mode in ('search', 'multiview'):
                return self._show_matches()
            if self.getFocusId() in BAR:                 # on the top bar: the Sport screen again (opened from it), else stay
                return self._close() if self.from_sport else None
            return self.setFocusId(RESULTS)
        if aid in (117, 101) and self.getFocusId() == ROWS:            # the context menu: its match's choices
            return self._menu()

    def _section(self, section):
        self.section, self.mode, self.section_chosen = section, 'matches', True
        self.setProperty(P + 'mode', 'matches')
        self._paint_sections()
        self._paint_lines()
        self.setFocusId(ROWS if self.lines else SECTIONS)

    def onClick(self, control_id):
        if control_id == HUB:
            self.pending = 'hub'                        # the HUB itself, from over the Sport screen too
            return self._close()
        if control_id == NOW:
            return self._full_screen() if xbmc.getCondVisibility('Player.HasVideo') else None
        if control_id == OPTIONS:
            options_page()
            self.leagues, self.teams = followed()
            self._paint_tabs()
            self._paint_sections()
            return
        if control_id == SEARCH:
            return self._search()
        if control_id == RESULTS:                       # Live now: MegaSport's main screen
            return self._section(('live',))
        if control_id == STREAMS:                       # the sport add-ons' screen, where the page was opened from
            if self.from_sport:
                self.pending = ''
                return self._close()
            return self._section(('addons',))
        if control_id == TABLES:
            return self._to_tables()
        if control_id == FAVOURITES:                    # a screen of its own ("favoriti ... treba biti zaseban ekran")
            self.pending = 'favourites'
            return self._close()
        if control_id == MULTIVIEW:
            return self._multiview_button()
        if control_id == TABS:
            self._choose_tab(self.getControl(TABS).getSelectedPosition())
            return
        if control_id == SECTIONS:
            at = self.getControl(SECTIONS).getSelectedPosition()
            if 0 <= at < len(self.sections):
                self._section(self.sections[at]['section'])
            return
        if control_id == ROWS:
            line = self._line()
            if self.mode == 'multiview':
                return self._mv_ok(line)
            if line and line['kind'] in ('match', 'event'):
                self._ok_on_line(line)
            return
        if control_id == SOURCES:
            at = self.getControl(SOURCES).getSelectedPosition()
            if 0 <= at < len(self.sources):
                if self.mode == 'multiview':
                    source = self.sources[at]
                    return self._mv_pick(source['key'], 'iptv', source['channel'])
                self._ok_on_source(self.sources[at])
            return

    def _choose_tab(self, at):
        """The page as that sport's (All: every followed league's): its leagues - got the first time (the ones that play
        this week, for a sport none of whose is followed) - and the section that has matches now."""
        if not 0 <= at < len(self.tabs) or self.tabs[at][0] == self.tab:
            return
        self.tab, self.section_chosen = self.tabs[at][0], False
        self._paint_tabs()
        if not self.playing:                             # another sport: the last one's match leaves the right
            self._forget_details()
        self.section = self._best_section()
        self.mode = 'matches'
        self.setProperty(P + 'mode', 'matches')
        self._paint_sections()
        self._paint_lines()

    def _best_section(self):
        """Live now, else Today, else Coming up, else the tab's first league - the first that has matches."""
        counts = {s['section'][0]: s.get('label2') for s in section_lines(self.tab, self.matches, self.guide, self.events,
                                                                          self._tab_leagues(), self.teams, self.section)}
        found = next(((k,) for k in ('live', 'today', 'next') if counts.get(k)), None)
        if found:
            return found
        leagues = self._tab_leagues()
        return ('league',) + tuple(leagues[0]) if leagues and self.tab != ALL else ('live',)

    def _search(self):
        """A team, a league or an event among what the page has: its matches and the add-ons' events, as one list."""
        said = xbmcgui.Dialog().input('MegaSport: a team, a league, an event')
        found = sport_channels.words(said)
        if not found:
            return
        def has(words):
            return all(w in ' '.join(words) for w in found)
        matches = [m for m in self.matches if has(sport_channels.words(' '.join([m['name'], m.get('league_name') or ''] + [s['name'] for s in m['sides']])))]
        events = [e for e in self.events if has(sport_channels.words(e['title']))]
        self.mode = 'search'
        self.setProperty(P + 'mode', 'matches')
        self.lines = grouped(matches, (self.playing or {}).get('key', '')) + [event_line(e) for e in events]
        control = self.getControl(ROWS)
        control.reset()
        control.addItems([list_item(l) for l in self.lines])
        self.setProperty(P + 'heading', 'Found: %s' % said)
        self.setProperty(P + 'note', '' if self.lines else 'Nothing found for %s.' % said)
        self.setFocusId(ROWS if self.lines else SEARCH)

    # loading ------------------------------------------------------------------------------------------------------------
    def _load_all(self, live=frozenset()):
        """Every sport's matches (sport_scores.board: the followed sports first), each given to the page as it comes;
        the followed leagues a board leaves out (their week); the add-ons' events and the guide, linked to them.
        ``live``: only these sports again (a match of them is on or starts soon)."""
        try:
            kinds = sport_scores.sports()
        except Exception:
            kinds = []
        self.results.put(('sports', kinds))
        leagues, teams = followed()
        if not live:
            self.board_at = time.monotonic()
        extras = None
        if not self.extras_at or time.monotonic() - self.extras_at >= EXTRAS_EVERY:
            self.extras_at = time.monotonic()
            extras = self.extras_pool.submit(self._extras)
        order = list(dict.fromkeys(['soccer'] + [s for s, _, _ in leagues] + [t['sport'] for t in teams] + [s for s, _ in kinds]))
        sports = [s for s in order if s in live] if live else order
        if not live:
            self.results.put(('loading', sports))
        if 'soccer' in sports:                         # football's days first, side by side (every league of them)
            for offset in sport_scores.SOCCER_DAYS if not live else (0,):
                self.pool.submit(self._load_day, offset)
        for sport in sports:
            if sport != 'soccer':
                self.pool.submit(self._load_board, sport, sport in live, extras)
        for sport, slug in dict.fromkeys([(s, l) for s, l, _ in leagues] + [(t['sport'], t['league']) for t in teams]):
            if sport != 'soccer' and not live:          # football's board has every league; another's, its first ones
                self.pool.submit(self._load_week, sport, slug, extras)

    def _extras(self):
        """The guide's now and next first - your IPTV channels are linked to the matches as soon as it is read (on this
        box: a moment) - then the add-ons' events (their catalogs, over the network), linked again (idea 2026-11-20
        "sportske strimove kad sa resulta trazi za utakmice preko iptv su prespori": the channels waited for every
        add-on's catalog, one after another)."""
        started = time.monotonic()
        try:
            found = programmes(_channels())
        except Exception:
            found = []
        guide = time.monotonic() - started
        self.timing['guide'] += guide
        self.results.put(('extras', list(self.events_all), found))
        started = time.monotonic()
        try:
            events = addon_events()
        except Exception:
            events = []
        took = time.monotonic() - started
        self.timing['events'] += took
        self.results.put(('extras', events, found))
        xbmc.log('[MegaNexus][perf] MegaSport links: the guide %d ms (%d programmes) - your channels linked then; '
                 'the add-ons\' events %d ms (%d)' % (guide * 1000, len(found), took * 1000, len(events)), xbmc.LOGINFO)
        return events, found

    def _linked(self, matches, extras=None):
        """``matches`` linked to the add-ons' events and the guide that are here (never waited for: they are linked
        again when those come - _relink)."""
        if self.closed:
            return matches                   # the page has gone: nothing shows the links (they take the CPU)
        if extras is not None and extras.done():
            events, found = extras.result()
        else:
            events, found = self.events_all, self.found
        if events or found:
            started = time.monotonic()
            link(matches, events, found, megaiptv._folder())
            self.timing['link'] += time.monotonic() - started
        return matches

    def _prefetch_tables(self):
        """The Tables screen's first tables while the matches load (idea 2026-11-20 "kad pokrenem mega sport u pozadini
        ucitavaj odmah result i table"): the followed leagues' and football's first league with a table - kept until
        MegaSport is left (sport_scores.forget), so the Tables screen shows them at once."""
        leagues, _ = followed()
        wanted = [(sport, slug) for sport, slug, _ in leagues]
        try:
            wanted += [('soccer', slug) for slug, _, _ in sport_scores.leagues_with_tables('soccer')[:1]]
        except Exception:
            pass
        for sport, slug in list(dict.fromkeys(wanted))[:PREFETCH_TABLES]:
            if self.closed:
                return
            try:
                sport_scores.table(sport, slug, urgent=False)
            except Exception:
                continue

    def _log_timing(self):
        self.timed = True
        asked = collections.Counter(sport_scores.asked)
        asked.subtract(self.asked_before)
        xbmc.log('[MegaNexus][perf] MegaSport loaded: first matches %d ms, every board %d ms, %d matches; ESPN %d requests, '
                 '%.1f s waited for the minute\'s limit; links %d ms; add-on events %d ms; guide %d ms'
                 % (self.timing['first'] * 1000, (time.monotonic() - self.opened_at) * 1000, len(self.matches), asked['requests'],
                    asked['waited'], self.timing['link'] * 1000, self.timing['events'] * 1000, self.timing['guide'] * 1000),
                 xbmc.LOGINFO)

    def _relink(self, matches, events, found):
        if self.closed:
            return
        started = time.monotonic()
        link(matches, events, found, megaiptv._folder())
        self.timing['link'] += time.monotonic() - started
        self.results.put(('relinked',))

    def _load_day(self, offset):
        try:
            matches = self._linked(sport_scores.soccer_day(offset))
        except Exception:
            xbmc.log('[MegaNexus] MegaSport: football (day %+d) did not load: %s' % (offset, traceback.format_exc(limit=1).strip().splitlines()[-1]),
                     xbmc.LOGWARNING)
            matches = []
        self.results.put(('board', 'soccer' if offset == sport_scores.SOCCER_DAYS[-1] else None, matches))

    def _load_board(self, sport, live, extras):
        try:
            matches = self._linked(sport_scores.board(sport, live=live), extras)
        except Exception:
            xbmc.log('[MegaNexus] MegaSport: %s did not load: %s' % (sport, traceback.format_exc(limit=1).strip().splitlines()[-1]),
                     xbmc.LOGWARNING)
            matches = []
        self.results.put(('board', sport, matches))

    def _load_week(self, sport, slug, extras):
        try:
            self.results.put(('board', None, self._linked(sport_scores.week(sport, slug)[0], extras)))
        except Exception:
            pass

    def tick(self):
        """The page's loop: what the workers found, the cursor's details, what plays, the live leagues again."""
        while True:
            try:
                got = self.results.get_nowait()
            except queue.Empty:
                break
            self._took(got)
        if self.getFocusId() == ROWS:
            self._past_heads()
        focus = self.getFocusId()
        if self.loaded and focus == TABS and time.monotonic() - self.moved_at >= TAB_REST:
            self._choose_tab(self.getControl(TABS).getSelectedPosition())
        elif focus != TABS and self.tabs:
            self._strip_on_shown()
        if self.loaded and self.mode in ('matches', 'search') and focus == ROWS and time.monotonic() - self.moved_at >= REST:
            line = self._line()
            if line and line.get('key') != self.asked_for:
                self.asked_for = line.get('key')
                if line['kind'] in ('match', 'event'):
                    self._details(line)
        playing = bool(self.playing) and xbmc.getCondVisibility('Player.HasVideo')
        self.setProperty(P + 'video', '1' if playing else '')
        if playing:
            self.setProperty(P + 'video_status', '')
        if self.loaded and time.monotonic() - self.board_at >= BOARD_EVERY:
            self.live_at = time.monotonic()
            self.pool.submit(self._load_all)
        elif self.loaded and time.monotonic() - self.live_at >= LIVE_EVERY:
            self.live_at = time.monotonic()
            live = frozenset(m['sport'] for m in self.matches if m['state'] == sport_scores.LIVE or sport_scores.soon(m))
            if live:
                self.pool.submit(self._load_all, live)

    def _took(self, got):
        kind = got[0]
        if kind == 'note':
            self.setProperty(P + 'note', got[1])
        elif kind == 'sports':
            self.sports = got[1] or self.sports
            self._paint_tabs()
        elif kind == 'loading':
            self.loading_tabs = set(got[1])
        elif kind == 'extras':
            _, self.events_all, self.found = got
            self.guide = guide_sport(self.found)
            self.pool.submit(self._relink, list(self.matches), self.events_all, self.found)
            self._repaint()
        elif kind == 'relinked':
            self._repaint()
        elif kind == 'board':
            _, sport, matches = got
            self.loading_tabs.discard(sport)
            for match in matches:
                self.by_key[(match['sport'], match['league'], match['id'])] = match
            self.matches = list(self.by_key.values())
            first = not self.loaded and bool(self.matches)
            if first:
                self.timing['first'] = time.monotonic() - self.opened_at
            anew = first
            if first or not self.section_chosen:          # the section that has matches, as they come
                self.loaded = self.loaded or bool(self.matches)
                before, self.section = self.section, self._best_section()   # nothing live: Today; nothing today: Coming up
                if self.intent == 'teams' and self.teams:
                    self.section = ('teams',)
                elif self.intent in ('live', 'today', 'addons'):
                    self.section = (self.intent,)
                anew = first or before != self.section
            self._repaint(anew)
            if first:                                     # the cursor is put once - never taken from where the person is
                self.setFocusId(ROWS if self.lines else SECTIONS)
            if sport is not None and time.monotonic() - self.kept_at >= 5:
                self.kept_at = time.monotonic()
                keep_matches(self.matches)
            if not self.loading_tabs and not self.matches:
                self.setProperty(P + 'note', 'ESPN did not answer - open MegaSport again.')
            if not self.loading_tabs and not self.timed:
                self._log_timing()
        elif kind == 'streams':
            _, line_key, rows = got
            if self.chosen and self.chosen.get('key') == line_key:
                self.sources += rows
                self._paint_sources()
                if self.after_ready == line_key:
                    self.after_ready = None
                    if self._playable():
                        self._play_source(self._playable()[0])
                    elif not self.playing:
                        self.setProperty(P + 'video_status', 'No stream found for it')
        elif kind == 'probe':
            _, token, source, answered = got
            if token == self.token:
                if answered:
                    self._start_stream(source)
                else:
                    self.setProperty(P + 'video_status', 'This stream does not answer - choose another one')
                    self.playing = None
                    self._paint_sources()

    # painting -----------------------------------------------------------------------------------------------------------
    def _repaint(self, anew=False):
        """What came changes the page where it is: the add-on events no match has, the sections' counts, the lines (in
        place when they are the same - the cursor stays)."""
        taken = {e['id'] for m in self.matches for e in m.get('events') or []}
        self.events = [e for e in self.events_all if e['id'] not in taken]
        if self.mode == 'multiview':
            return self._paint_mv()                   # what plays live came: its lists grow where they are
        if self.mode == 'matches':
            if not self.loaded:
                return
            self._paint_sections()
            self._paint_lines(in_place=not anew)

    def _tab_leagues(self):
        """The tab's leagues: the followed ones first, then every league its matches are of (the most matches first)."""
        count = collections.Counter((m['sport'], m['league']) for m in self.matches if in_tab(m, self.tab))
        names = {(m['sport'], m['league']): m.get('league_name') or m['league'] for m in self.matches}
        mine = [l for l in self.leagues if self.tab in (ALL, l[0])]
        seen = {(s, l) for s, l, _ in mine}
        rest = sorted((k for k in count if k not in seen), key=lambda k: (-count[k], names[k]))
        return mine + [(s, l, names[(s, l)]) for s, l in rest]

    def _paint_sections(self):
        before, self.sections = self.sections, section_lines(self.tab, self.matches, self.guide, self.events, self._tab_leagues(),
                                                             self.teams, self.section)
        control = self.getControl(SECTIONS)
        at = control.getSelectedPosition()
        if fill(control, before, self.sections) and 0 <= at < len(self.sections):
            control.selectItem(at)

    def _heading(self):
        names = {'live': 'Live now', 'today': 'Today', 'next': 'Coming up', 'tv': 'On your channels', 'addons': 'Add-on events',
                 'teams': 'Favourites'}
        return names.get(self.section[0]) or (self.section[3] if len(self.section) > 3 else '')

    def _paint_lines(self, in_place=False):
        """The middle's lines; ``in_place``: the same lines as before (a live refresh) - their words change where they
        are, the cursor stays."""
        playing_key = (self.playing or {}).get('key', '')
        lines = lines_for(self.section, self.tab, self.matches, self.guide, self.events, self.teams, playing_key)
        self.setProperty(P + 'heading', self._heading())
        control = self.getControl(ROWS)
        if lines:
            self.setProperty(P + 'note', '')
        elif self.tab in self.loading_tabs:
            self.setProperty(P + 'note', 'Loading %s...' % dict(self.tabs).get(self.tab, ''))
        elif self.loaded:
            self.setProperty(P + 'note', 'Nothing here now.')
        if in_place and [l['key'] for l in lines] == [l['key'] for l in self.lines]:
            fill(control, self.lines, lines)
            self.lines = lines
            return
        key = (self._line() or {}).get('key')
        self.lines = lines
        control.reset()
        control.addItems([list_item(line) for line in lines])
        first = next((n for n, l in enumerate(lines) if l['key'] == key), next((n for n, l in enumerate(lines) if l['kind'] != 'head'), 0))
        if lines:
            control.selectItem(first)
        self.asked_for = None

    def _line(self):
        try:
            at = self.getControl(ROWS).getSelectedPosition()
        except RuntimeError:
            return None
        return self.lines[at] if 0 <= at < len(self.lines) else None

    def _details(self, line):
        """The right: the line's scoreboard and words, its sources (its channel at once, the add-ons' streams as they come)."""
        self.chosen, self.sources = line, []
        if self.after_ready and self.after_ready != line.get('key'):
            self.after_ready = None
            if not self.playing:
                self.setProperty(P + 'video_status', '')
        for key in ('home', 'away', 'home_logo', 'away_logo', 'score', 'status', 'league', 'title', 'about', 'tv', 'art', 'long'):
            self.setProperty(P + key, '')
        events = []
        if line['kind'] == 'match':
            match = line['match']
            sides = match.get('sides') or []
            if match.get('pair') and len(sides) == 2:
                for key, value in (('home', sides[0]['name']), ('away', sides[1]['name']), ('home_logo', sides[0]['logo']),
                                   ('away_logo', sides[1]['logo']), ('score', score_said(match))):
                    self.setProperty(P + key, value)
            else:
                self.setProperty(P + 'art', match.get('league_logo') or '')
            live = match['state'] == sport_scores.LIVE and not line['status'].lower().startswith('live')
            self.setProperty(P + 'status', 'LIVE %s' % line['status'] if live else line['status'])
            self.setProperty(P + 'long', '1' if len(score_said(match)) > 7 else '')   # a cricket innings' score: smaller
            self.setProperty(P + 'league', match.get('league_name') or '')
            self.setProperty(P + 'title', match.get('name') or '')
            start = match['start'].astimezone().strftime('%a %d %b %H:%M') if match.get('start') else ''
            self.setProperty(P + 'about', '  ·  '.join(x for x in (match.get('league_name'), match.get('venue'), start) if x))
            if match.get('tv'):
                self.setProperty(P + 'tv', 'On TV: %s' % plain_label(match['tv'].get('label')))
                self.sources.append(self._iptv_source(match['tv']))
            events = match.get('events') or []
        elif 'channel' in line:
            self.setProperty(P + 'art', line['channel'].get('icon') or '')
            self.setProperty(P + 'title', line['label'])
            self.setProperty(P + 'about', '%s  ·  %s' % (line['label2'], line['status']))
            self.sources.append(self._iptv_source(line['channel']))
        else:
            event = line['event']
            self.setProperty(P + 'art', event.get('art') or '')
            self.setProperty(P + 'title', line['label'])
            self.setProperty(P + 'about', '  ·  '.join(x for x in (event.get('addon'), line['status'], event.get('description')) if x))
            events = [event]
        self._paint_sources()
        for event in events:
            self._ask_streams(line['key'], event)

    def _remind_source(self, match):
        """A match to come: Remind me (or the reminder set) - the last of its sources ("remind me dolje stavi ga negdje
        drugo")."""
        from resources.lib import sport_reminders
        on = sport_reminders.has({'id': 'megasport:%s' % match['id']})
        return {'key': 'remind:%s' % match['id'], 'kind': 'remind', 'label': 'Reminder set · OK takes it off' if on else 'Remind me',
                'label2': match['start'].astimezone().strftime('%a %H:%M'), 'icon': ICON % 'calendar'}

    def _playable(self):
        return [s for s in self.sources if s['kind'] in ('iptv', 'stream')]

    def _forget_details(self):
        self.chosen, self.sources, self.asked_for, self.after_ready = None, [], None, None
        for key in ('home', 'away', 'home_logo', 'away_logo', 'score', 'status', 'league', 'title', 'about', 'tv', 'art',
                    'video_status', 'sources_status'):
            self.setProperty(P + key, '')
        self.getControl(SOURCES).reset()

    def _iptv_source(self, channel):
        return {'key': 'iptv:%s' % channel['channelid'], 'kind': 'iptv', 'label': plain_label(channel.get('label')), 'label2': 'IPTV',
                'channel': channel, 'icon': ICON % 'livetv'}

    def _ask_streams(self, line_key, event):
        if event['id'] in self.stream_cache:
            self.results.put(('streams', line_key, self.stream_cache[event['id']]))
            return
        self.setProperty(P + 'sources_status', 'Finding streams...')

        def work():
            from resources.lib import sports
            try:
                found = sports.streams(event)
            except Exception:
                found = []
            rows = [{'key': 'event:%s:%d' % (event['id'], n), 'kind': 'stream', 'label': s['label'],
                     'label2': s.get('detail') or event.get('addon') or '', 'url': s['url'], 'event': event, 'icon': ICON % 'streams'}
                    for n, s in enumerate(found)]
            self.stream_cache[event['id']] = rows
            self.results.put(('streams', line_key, rows))
        self.pool.submit(work)

    def _paint_sources(self):
        if self.mode == 'multiview':
            return                                   # MultiView's own on the right (_paint_mv)
        control = self.getControl(SOURCES)
        control.reset()
        playing = (self.playing or {}).get('key')
        match = (self.chosen or {}).get('match') if (self.chosen or {}).get('kind') == 'match' else None
        self.sources = self._playable()
        if match and match['state'] == sport_scores.BEFORE and match.get('start'):
            self.sources.append(self._remind_source(match))
        for source in self.sources:
            item = xbmcgui.ListItem(source['label'], source.get('label2') or '')
            item.setArt({'icon': source['icon']})
            item.setProperty('playing', '1' if source['key'] == playing else '')
            control.addItem(item)
        waiting = self.chosen and self.chosen['kind'] == 'match' and self.chosen['match'].get('events') and \
            not any(s['kind'] == 'stream' for s in self.sources)
        self.setProperty(P + 'sources_status', 'Finding streams...' if waiting else '' if self._playable() else
                         'No channel or stream found for it' if self.chosen else '')

    # playing ------------------------------------------------------------------------------------------------------------
    def _ok_on_line(self, line):
        """OK on a row: its first source plays in the box (asked for first: it plays once its streams come); OK on the
        row that plays: full screen."""
        if self.chosen is None or self.chosen.get('key') != line.get('key'):
            self.asked_for = line.get('key')
            self._details(line)
        playable = self._playable()
        if self.playing and any(s['key'] == self.playing['key'] for s in playable) and xbmc.getCondVisibility('Player.HasVideo'):
            return self._full_screen()
        if playable:
            return self._play_source(playable[0])
        self.after_ready = line.get('key')
        self.setProperty(P + 'video_status', 'Finding streams...')

    def _ok_on_source(self, source):
        if source['kind'] == 'remind':
            return self._remind()
        if self.playing and self.playing['key'] == source['key'] and xbmc.getCondVisibility('Player.HasVideo'):
            return self._full_screen()
        self._play_source(source)

    def _play_source(self, source):
        from .iptv import keep_windowed, open_preview
        self.playing = source
        self.setProperty(P + 'video_status', 'Connecting...')
        self._paint_sources()
        if self.mode == 'matches':
            self._paint_lines(in_place=True)
        if source['kind'] == 'iptv':
            if not self._windowed:
                keep_windowed()
                self._windowed = True
            self._preview_of = source['channel']['channelid']
            try:
                open_preview(self._preview_of)
            except Exception as error:
                self.setProperty(P + 'video_status', 'The channel did not start')
                xbmc.log('[MegaNexus] MegaSport: the channel did not start: %s' % str(error)[:120], xbmc.LOGWARNING)
            return
        from .sports import probe
        token = self.token = uuid.uuid4().hex
        self.pool.submit(lambda: self.results.put(('probe', token, source, probe(source['url']))))

    def _start_stream(self, source, windowed=True):
        from .sports import _hls_item
        from resources.lib import refresh_guard
        item = xbmcgui.ListItem(plain_label(source['event'].get('title')) or 'MegaSport')
        item.setProperty('IsPlayable', 'true')
        url = _hls_item(item, source['url'])
        refresh_guard.suspend('sports')                       # no TV mode switch for a preview (issue #4)
        xbmc.Player().play(url, item, windowed=windowed)

    def _play_alone(self, row):
        """MultiView left ``row``'s stream alone: the page's own playback (its small video shows it once the player is
        left - MultiViewHost._play_alone), the event's source line when the page found its streams."""
        address = row['mv_source']['address']
        known = next((s for rows in self.stream_cache.values() for s in rows if s['url'] == address), None)
        self.playing = known or {'key': 'mv:%s' % row.get('sport_event'), 'kind': 'stream', 'label': row['mv_source'].get('name') or '',
                                 'label2': '', 'url': address, 'event': {'id': row.get('sport_event'), 'title': row.get('label') or ''},
                                 'icon': ICON % 'streams'}
        self._start_stream(self.playing, windowed=False)

    def _switch(self, row):
        """MultiView left ``row``'s channel alone: the page's own playback too."""
        self.playing = self._iptv_source(row)
        return SportGrid._switch(self, row)

    def _stop(self):
        if self.playing and xbmc.Player().isPlaying():
            xbmc.Player().stop()
        self.playing = None
        if self._windowed:
            from .iptv import release_windowed
            release_windowed()
            self._windowed = False

    def _full_screen(self):
        """Kodi's player for what plays - the same playback; MultiView's button there (Window(Home) OSD_SPORT); this page
        steps aside (Kodi opens no window over a dialog) and comes back when the player is left."""
        from .home_trailers import view_mode
        from .multiview import available
        view_mode('normal')                               # the whole picture in Kodi's own player
        home = xbmcgui.Window(10000)
        home.setProperty(OSD_SPORT, '1')
        can = available()
        home.setProperty('meganexus.iptv.can_multiview', '1' if can else '')
        if can:                                           # MultiView's picker ready before its button is pressed
            from .multiview_sources import warm
            warm()
        from .dialog import close_into_player
        close_into_player(self)
        try:
            self._in_player()
        finally:
            self._back_here()

    def _back_here(self):
        xbmcgui.Window(10000).clearProperty(OSD_SPORT)
        if getattr(self, '_grid', None) is not None:
            self._mv_end()
        self.show()
        self.setFocusId(ROWS)

    def _in_player(self, grace=0.0):
        """While Kodi's player is up: its MultiView button and the grid's window's asks; leaves when the player is left."""
        from .iptv import OSD_COMMAND
        home, monitor = xbmcgui.Window(10000), xbmc.Monitor()
        home.clearProperty(OSD_COMMAND)
        seen, start = False, time.monotonic()
        grace = time.monotonic() + grace if grace else 0.0
        while not monitor.waitForAbort(.1):
            command = home.getProperty(OSD_COMMAND)
            if command:
                home.clearProperty(OSD_COMMAND)
                if command == 'multiview' and self._multiview([], []):
                    grace = time.monotonic() + 6
                elif command.startswith('mv:') and self._on_grid(command, [], []):
                    grace = time.monotonic() + 6
            if getattr(self, '_grid', None) is not None:
                self._mv_tiles()
            full = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
            if time.monotonic() < grace:
                if not full and xbmc.Player().isPlayingVideo():
                    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                continue
            seen = seen or full
            if (seen and not full) or not xbmc.Player().isPlayingVideo() or (not seen and time.monotonic() - start > 5):
                break

    # MultiView (SportGrid) -------------------------------------------------------------------------------------------------
    @staticmethod
    def _as_row(source):
        """A source as a MultiView tile's row."""
        if source['kind'] == 'iptv':
            return {'channelid': source['channel']['channelid'], 'label': source['label'], 'clientid': source['channel'].get('clientid')}
        return {'label': plain_label(source['event'].get('title')), 'mv_source': {'address': source['url'], 'name': source['label']}}

    def _playing_row(self, rows):
        """What plays - else the chosen row's first source (its channel, else its first stream) - as a tile's row."""
        source = self.playing or next(iter(self._playable()), None)
        return self._as_row(source) if source else None

    def _multiview_button(self):
        """The page's MultiView (idea 2026-11-20: "multiview na vrhu otvara pogresno polje umjesto da prikaze na ekranu
        nase addone sta ide uzivo i pored iptv"): on the page, what plays live on your add-ons in the middle and your
        channels with sport on now beside it - OK picks or leaves one (MV_MOST, your channels one at most: the
        provider's one connection), Start on top; Back: the matches again."""
        from .multiview import offer_tools
        if not offer_tools():
            return
        self.mode, self.mv_picks = 'multiview', []
        self._paint_mv()
        self.setFocusId(ROWS)

    def _mv_found(self):
        """(the add-ons' live events, [(channel, programme)] your channels' sport on now)."""
        return ([e for e in self.events_all if e.get('live')],
                [(channel, programme) for channel, programme in self.guide if programme.get('now')])

    def _paint_mv(self):
        live, on_now = self._mv_found()
        picked = {key for key, _, _ in self.mv_picks}
        count = len(self.mv_picks)
        start = {'kind': 'event', 'key': 'mv:start', 'status': 'START' if count >= 2 else '', 'live': '1' if count >= 2 else '',
                 'label': 'Start MultiView · %d picked' % count if count >= 2 else
                          'Pick 2 to %d · on your channels one at most' % MV_MOST, 'label2': ''}
        lines = [start] + [dict(event_line(e), key='mv:event:%s' % e['id'], picked='1' if 'mv:event:%s' % e['id'] in picked else '')
                           for e in live]
        self.setProperty(P + 'heading', 'MultiView · live on your add-ons')
        self.setProperty(P + 'note', '' if live or on_now else 'Finding what plays live...')
        if fill(self.getControl(ROWS), self.lines, lines) and self.lines and self.lines[0].get('key') != 'mv:start':
            self.getControl(ROWS).selectItem(0)
        self.lines = lines
        sources = [{'key': 'mv:iptv:%s' % channel['channelid'], 'kind': 'mv_iptv', 'label': plain_label(channel.get('label')),
                    'label2': plain_label(programme.get('title')), 'channel': channel, 'icon': ICON % 'livetv',
                    'picked': '1' if 'mv:iptv:%s' % channel['channelid'] in picked else ''} for channel, programme in on_now]
        self.setProperty(P + 'sources_status', 'Your channels · sport on now' if sources else '')
        fill(self.getControl(SOURCES), self.sources, sources)
        self.sources = sources

    def _mv_pick(self, key, kind, thing):
        """``thing`` picked, or left when it was."""
        if any(k == key for k, _, _ in self.mv_picks):
            self.mv_picks = [p for p in self.mv_picks if p[0] != key]
        elif len(self.mv_picks) >= MV_MOST:
            xbmcgui.Dialog().notification('MultiView', 'At most %d.' % MV_MOST, time=2500)
        elif kind == 'iptv' and any(k == 'iptv' for _, k, _ in self.mv_picks):
            xbmcgui.Dialog().notification('MultiView', 'One of your channels at most (your provider\'s one connection).', time=3500)
        else:
            self.mv_picks.append((key, kind, thing))
        self._paint_mv()

    def _mv_ok(self, line):
        if not line:
            return
        if line['key'] == 'mv:start':
            return self._mv_start() if len(self.mv_picks) >= 2 else None
        self._mv_pick(line['key'], 'event', line['event'])

    def _mv_start(self):
        """The picked ones in the grid - an add-on event: one of its streams (pick_stream); a channel: its tile."""
        from .home_trailers import view_mode
        from .iptv import channels
        from .multiview import GRID
        from .multiview_sources import pick_stream
        rows = []
        for _, kind, thing in self.mv_picks:
            if kind == 'event':
                row = pick_stream(thing)
            else:
                row = next((r for r in channels('alltv') or [] if r.get('channelid') == thing['channelid']), None)
            if row:
                rows.append(row)
        if len(rows) < 2:
            xbmcgui.Dialog().notification('MultiView', 'Two of them must play - pick another.', time=3500)
            return
        self._stop()                                  # the page's own preview: no second connection beside the grid
        view_mode('normal')
        xbmcgui.Window(10000).setProperty(OSD_SPORT, '1')
        xbmcgui.WindowXMLDialog.close(self)
        try:
            if self._mv_show(rows, GRID, 0):
                self._in_player(grace=6)
        finally:
            self._back_here()

    # tables, reminders, the menu ------------------------------------------------------------------------------------------
    def _to_tables(self):
        """The Tables screen ("tabele treba biti ekran za tabele ne za scores") - at the league shown, else the chosen
        match's."""
        line = self.chosen or self._line()
        league = None
        if self.section[0] == 'league':
            league = self.section[1:3]
        elif line and line.get('kind') == 'match':
            league = (line['match']['sport'], line['match']['league'])
        self.pending = 'tables:%s/%s' % league if league else 'tables'
        self._close()

    def _show_matches(self):
        self.mode = 'matches'
        self.setProperty(P + 'mode', 'matches')
        self._paint_lines()
        self._paint_sources()                         # the chosen line's again (after MultiView's own)
        self.setFocusId(ROWS if self.lines else SECTIONS)

    def _remind(self):
        from resources.lib import sport_reminders
        line = self.chosen
        if not line or line.get('kind') != 'match' or not line['match'].get('start'):
            return
        match = line['match']
        reminder = {'id': 'megasport:%s' % match['id']}
        if sport_reminders.has(reminder):
            sport_reminders.remove(reminder['id'])
            xbmcgui.Dialog().notification('MegaSport', 'Reminder removed', time=2500)
        else:
            sport_reminders.add(dict(reminder, title=match.get('name') or '', art=line.get('home_logo') or '',
                                     start=int(match['start'].timestamp()), app='megasport'))
            xbmcgui.Dialog().notification('MegaSport', 'You will be told when it starts', time=3000)
        self._paint_sources()
        if self.getFocusId() == SOURCES:                # the cursor stays on it (the last line)
            self.getControl(SOURCES).selectItem(len(self.sources) - 1)

    def _menu(self):
        """A match's choices: follow one of its sides, its table, a reminder at its start."""
        from .details import context_choice
        line = self._line()
        if not line or line.get('kind') != 'match':
            return
        match = line['match']
        options = []
        if match.get('pair'):
            for side in match['sides']:
                on = any((t['sport'], t['id']) == (match['sport'], side['id']) for t in self.teams)
                options.append(('follow:%s' % side['id'], '%s %s' % ('Unfollow' if on else 'Follow', side['name'])))
        options.append(('table', 'Table: %s' % (match.get('league_name') or match['league'])))
        if match['state'] == sport_scores.BEFORE and match.get('start'):
            options.append(('remind', 'Reminder at its start'))
        pick = context_choice(options=options, heading=match.get('name') or 'MegaSport')
        if not pick:
            return
        if pick.startswith('follow:'):
            side = next(s for s in match['sides'] if s['id'] == pick.split(':', 1)[1])
            leagues, teams = followed()
            if any((t['sport'], t['id']) == (match['sport'], side['id']) for t in teams):
                teams = [t for t in teams if (t['sport'], t['id']) != (match['sport'], side['id'])]
            else:
                teams.append({'sport': match['sport'], 'league': match['league'], 'id': side['id'], 'name': side['name'], 'logo': side.get('logo', '')})
            keep(leagues, teams)
            self.teams = teams
            self._paint_sections()
        else:
            self.chosen = line
            self._to_tables() if pick == 'table' else self._remind()

    def _close(self):
        self.closed = True                    # _run closes the window (after the next screen is up, going to it)

    def _finish(self):
        self._stop()
        if getattr(self, '_grid', None) is not None:
            self._mv_end()
        self._mv_stop_left()                  # what MultiView's Close left playing goes with the page
        drop(self.pool)                       # what was queued for the page does not run on after it
        drop(self.extras_pool)
        if self.matches:
            keep_matches(self.matches)


# ---- Options ---------------------------------------------------------------------------------------------------------
def _leagues_page(sport, sport_name):
    """``sport``'s leagues (ESPN's list): followed or not, OK turns it."""
    from . import settings_page as page

    def build():
        on = {(s, l) for s, l, _ in followed()[0]}
        try:
            listed = sport_scores.leagues(sport)
        except Exception:
            listed = []
        return [(slug, page.item(name, enabled=(sport, slug) in on)) for slug, name in listed]

    def act(slug):
        leagues, teams = followed()
        names = dict(sport_scores.leagues(sport))
        if any(s == sport and l == slug for s, l, _ in leagues):
            leagues = [x for x in leagues if not (x[0] == sport and x[1] == slug)]
        else:
            leagues.append((sport, slug, names.get(slug, slug)))
        keep(leagues, teams)
        return None
    return page.keyed('%s leagues' % sport_name, build, act)


def _sports_page():
    from . import settings_page as page

    def build():
        on = {}
        for s, _, _ in followed()[0]:
            on[s] = on.get(s, 0) + 1
        try:
            listed = sport_scores.sports()
        except Exception:
            listed = []
        return [(slug, page.item(name, '%d followed' % on[slug] if on.get(slug) else '')) for slug, name in listed]

    def act(slug):
        return _leagues_page(slug, dict(sport_scores.sports()).get(slug, slug))
    return page.keyed('Leagues', build, act)


def _teams_page(sport, league, name):
    from . import settings_page as page

    def build():
        on = {t['id'] for t in followed()[1] if (t['sport'], t['league']) == (sport, league)}
        try:
            listed = sport_scores.teams(sport, league)
        except Exception:
            listed = []
        return [(t['id'], page.item(t['name'], enabled=t['id'] in on)) for t in listed]

    def act(team_id):
        leagues, teams = followed()
        found = next((t for t in sport_scores.teams(sport, league) if t['id'] == team_id), None)
        if found is None:
            return None
        if any((t['sport'], t['league'], t['id']) == (sport, league, team_id) for t in teams):
            teams = [t for t in teams if (t['sport'], t['league'], t['id']) != (sport, league, team_id)]
        else:
            teams.append({'sport': sport, 'league': league, 'id': team_id, 'name': found['name'], 'logo': found['logo']})
        keep(leagues, teams)
        return None
    return page.keyed('%s teams' % name, build, act)


def _team_leagues_page(sport, sport_name):
    """``sport``'s leagues (ESPN's list): OK - its teams, each followed or not."""
    from . import settings_page as page

    def build():
        teams = followed()[1]
        try:
            listed = sport_scores.leagues(sport)
        except Exception:
            listed = []
        return [(slug, page.item(name, '%d followed' % n if n else ''))
                for slug, name in listed for n in [sum(1 for t in teams if (t['sport'], t['league']) == (sport, slug))]]

    def act(slug):
        return _teams_page(sport, slug, dict(sport_scores.leagues(sport)).get(slug, slug))
    return page.keyed('%s teams' % sport_name, build, act)


def _team_sports_page():
    """The teams to follow, any sport ("nema nikakvih drugih timova ni sportova za pratiti osim nogometa"): its sport,
    its league, the team."""
    from . import settings_page as page

    def build():
        teams = followed()[1]
        try:
            listed = sport_scores.sports()
        except Exception:
            listed = []
        return [(slug, page.item(name, '%d followed' % n if n else ''))
                for slug, name in listed for n in [sum(1 for t in teams if t['sport'] == slug)]]

    def act(slug):
        return _team_leagues_page(slug, dict(sport_scores.sports()).get(slug, slug))
    return page.keyed('Teams', build, act)


def options_page():
    """MegaSport's Options: the leagues (by sport), the teams, then MegaIPTV's own (its channels, its guide)."""
    from . import settings_page as page
    from .iptv import configure

    def build():
        leagues, teams = followed()
        return [('leagues', page.item('Leagues', '%d followed · shown first' % len(leagues))),
                ('teams', page.item('Teams', '%d followed · Favourites' % len(teams))),
                ('iptv', page.item('IPTV', 'The channels the matches play on'))]

    def act(key):
        if key == 'leagues':
            return _sports_page()
        if key == 'teams':
            return _team_sports_page()
        if key == 'iptv':
            return configure(megaiptv.options())
        return None
    return page.keyed('MegaSport', build, act)


class MegaSportTables(_SportPage, xbmcgui.WindowXMLDialog):
    """MegaSport's Tables (review/make_megasport_screen.py tables_window): the sports' strip, the leagues that have a table
    (ESPN's list; All: the followed ones and football's), the chosen league's table - its groups, P W D L GF GA GD Pts,
    each place's zone in ESPN's colour and the zones' words under it, the followed teams marked."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.intent = kwargs.get('intent') or 'tables'
        self.from_sport = bool(kwargs.get('from_sport'))
        self.behind = kwargs.get('behind')
        wanted = self.intent.split(':', 1)[1] if ':' in self.intent else ''
        self.wanted = tuple(wanted.split('/', 1)) if '/' in wanted else None
        self.tab = self.wanted[0] if self.wanted else ALL
        self.tabs, self.sports, self.sections, self.lines = [], [], [], []
        self.leagues, self.teams = followed()
        self.found = {}                         # a tab's leagues with a table: [(sport, slug, name, logo)]
        self.shown = self.asking = None         # (sport, slug): its table shows / is asked for
        self.results = queue.Queue()
        self.pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix='MegaSportTables')
        self.closed, self.pending, self.ready = False, '', False
        self.moved_at = time.monotonic()

    def onInit(self):
        self.ready = True
        if not self.tabs:
            self.setProperty(P + 'note', 'Loading the tables...')
            self._paint_tabs()
            self.pool.submit(self._load_sports)
            self.pool.submit(self._load_leagues, self.tab)
        self.setFocusId(SECTIONS)

    def onFocus(self, control_id):
        self.moved_at = time.monotonic()

    def onAction(self, action):
        self.moved_at = time.monotonic()
        if action.getId() in BACK:
            focus = self.getFocusId()
            if focus in BAR:
                return self._close('' if self.from_sport else 'hub')
            return self.setFocusId(SECTIONS if focus == ROWS else TABLES)

    def onClick(self, control_id):
        go = {RESULTS: 'live', FAVOURITES: 'favourites', MULTIVIEW: 'multiview'}
        if control_id in go:
            return self._close(go[control_id])
        if control_id == STREAMS:
            return self._close('' if self.from_sport else 'addons')
        if control_id == HUB:
            return self._close('hub')
        if control_id == NOW:
            return self._now_playing()
        if control_id == OPTIONS:
            options_page()
            self.leagues, self.teams = followed()
            self.found.pop(ALL, None)
            return self.pool.submit(self._load_leagues, self.tab)
        if control_id == SEARCH:
            return self._search()
        if control_id == TABS:
            return self._choose_tab(self.getControl(TABS).getSelectedPosition())
        if control_id == SECTIONS:
            self._ask(self.getControl(SECTIONS).getSelectedPosition())
            return self.setFocusId(ROWS) if self.lines else None

    def _close(self, pending):
        self.pending, self.closed = pending, True

    def _finish(self):
        drop(self.pool)

    def _search(self):
        """A league among the tab's (by its name's words)."""
        said = xbmcgui.Dialog().input('MegaSport: a league')
        words = sport_channels.words(said)
        if not words:
            return
        at = next((n for n, (_, _, name, _) in enumerate(self.found.get(self.tab) or [])
                   if all(w in ' '.join(sport_channels.words(name)) for w in words)), -1)
        if at < 0:
            return xbmcgui.Dialog().notification('MegaSport', 'No table of %s here.' % said, time=2500)
        self.getControl(SECTIONS).selectItem(at)
        self.setFocusId(SECTIONS)
        self._ask(at)

    # loading ------------------------------------------------------------------------------------------------------------
    def _load_sports(self):
        try:
            self.results.put(('sports', sport_scores.sports()))
        except Exception:
            pass

    def _load_leagues(self, tab):
        found = []
        try:
            if tab == ALL:
                found = [(s, l, n, '') for s, l, n in self.leagues]
                found += [('soccer', slug, name, logo) for slug, name, logo in sport_scores.leagues_with_tables('soccer')]
            else:
                found = [(tab, slug, name, logo) for slug, name, logo in sport_scores.leagues_with_tables(tab)]
        except Exception:
            xbmc.log('[MegaNexus] MegaSport tables: %s leagues did not load: %s' % (tab, traceback.format_exc(limit=1).strip().splitlines()[-1]),
                     xbmc.LOGWARNING)
        unique = list({item[:2]: item for item in reversed(found)}.values())[::-1]
        self.results.put(('leagues', tab, unique))

    def _load_table(self, sport, slug, name):
        try:
            groups = sport_scores.table(sport, slug)
        except Exception:
            groups = []
        self.results.put(('table', (sport, slug), name, groups))

    def tick(self):
        while True:
            try:
                got = self.results.get_nowait()
            except queue.Empty:
                break
            self._took(got)
        focus = self.getFocusId()
        if focus == ROWS:
            self._past_heads()
        rested = time.monotonic() - self.moved_at
        if focus == TABS and rested >= TAB_REST:
            self._choose_tab(self.getControl(TABS).getSelectedPosition())
        elif focus != TABS and self.tabs:
            self._strip_on_shown()
        if focus == SECTIONS and rested >= REST:
            self._ask(self.getControl(SECTIONS).getSelectedPosition())

    def _took(self, got):
        kind = got[0]
        if kind == 'sports':
            self.sports = got[1] or self.sports
            self._paint_tabs()
        elif kind == 'leagues':
            _, tab, leagues = got
            self.found[tab] = leagues
            if tab != self.tab:
                return
            self._paint_sections()
            if not leagues:
                self.setProperty(P + 'note', 'ESPN has no table of %s now.' % sport_scores._name(tab))
                return
            at = next((n for n, l in enumerate(leagues) if self.wanted and l[:2] == self.wanted), 0)
            self.wanted = None
            self.getControl(SECTIONS).selectItem(at)
            self._ask(at)
        elif kind == 'table':
            _, key, name, groups = got
            if key != self.asking:
                return
            self.shown = key
            self.setProperty(P + 'note', '' if groups else 'No table of %s now.' % name)
            mine = {t['id'] for t in self.teams if (t['sport'], t['league']) == key}
            before, self.lines = self.lines, table_lines(groups, mine)
            fill(self.getControl(ROWS), before, self.lines)
            first = next((n for n, l in enumerate(self.lines) if l['kind'] == 'team'), 0)
            self.getControl(ROWS).selectItem(first)
            self._row_at = first
            legend = self.getControl(LEGEND)
            legend.reset()
            for zone, colour in zones(groups):
                item = xbmcgui.ListItem(zone)
                item.setProperty('zone_colour', colour)
                legend.addItem(item)
            self._paint_sections()

    def _paint_sections(self):
        lines = [{'key': 'league:%s/%s' % (s, l), 'label': n, 'label2': '', 'icon': logo, 'section': ('league', s, l, n),
                  'current': '1' if (s, l) == self.shown else ''} for s, l, n, logo in self.found.get(self.tab) or []]
        before, self.sections = self.sections, lines
        fill(self.getControl(SECTIONS), before, lines)

    def _ask(self, at):
        leagues = self.found.get(self.tab) or []
        if not 0 <= at < len(leagues) or leagues[at][:2] == self.asking:
            return
        sport, slug, name, _ = leagues[at]
        self.asking = (sport, slug)
        self.setProperty(P + 'heading', '%s · Table' % name)
        self.setProperty(P + 'note', 'Loading the table...')
        self.pool.submit(self._load_table, sport, slug, name)

    def _choose_tab(self, at):
        if not 0 <= at < len(self.tabs) or self.tabs[at][0] == self.tab:
            return
        self.tab = self.tabs[at][0]
        self._paint_tabs()
        if self.tab in self.found:
            self._took(('leagues', self.tab, self.found[self.tab]))
        else:
            self.sections = []
            self.getControl(SECTIONS).reset()
            self.setProperty(P + 'note', 'Loading %s...' % sport_scores._name(self.tab))
            self.pool.submit(self._load_leagues, self.tab)


class MegaSportFavourites(_SportPage, xbmcgui.WindowXMLDialog):
    """MegaSport's Favourites (the scores page's look): the followed teams on the left (and Add a team), the chosen
    team's next matches and last results in the middle, the team on the right with its table and Unfollow."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.intent = kwargs.get('intent') or 'favourites'
        self.from_sport = bool(kwargs.get('from_sport'))
        self.behind = kwargs.get('behind')
        self.tab, self.tabs, self.sports, self.sections, self.lines, self.sources = ALL, [], [], [], [], []
        self.leagues, self.teams = followed()
        self.shown = self.asking = None          # (sport, league, id) of the team shown / asked for
        self.results = queue.Queue()
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='MegaSportFavourites')
        self.closed, self.pending, self.ready = False, '', False
        self.moved_at = time.monotonic()

    def onInit(self):
        self.ready = True
        if not self.tabs:
            self.setProperty(P + 'mode', 'matches')
            self.setProperty(P + 'heading', 'Favourites')
            self._paint_tabs()
            self.pool.submit(self._load_sports)
            self._paint_sections()
        self.setFocusId(SECTIONS)

    def _settle_focus(self):
        self.setFocusId(SECTIONS)

    def onFocus(self, control_id):
        self.moved_at = time.monotonic()

    def onAction(self, action):
        self.moved_at = time.monotonic()
        if action.getId() in BACK:
            focus = self.getFocusId()
            if focus in BAR:
                return self._close('' if self.from_sport else 'hub')
            return self.setFocusId(SECTIONS if focus in (ROWS, SOURCES) else FAVOURITES)

    def onClick(self, control_id):
        go = {RESULTS: 'live', TABLES: 'tables', MULTIVIEW: 'multiview'}
        if control_id in go:
            return self._close(go[control_id])
        if control_id == STREAMS:
            return self._close('' if self.from_sport else 'addons')
        if control_id == HUB:
            return self._close('hub')
        if control_id == NOW:
            return self._now_playing()
        if control_id in (OPTIONS, SEARCH):
            _team_sports_page()                    # the teams to follow, any sport
            return self._followed_again()
        if control_id == TABS:
            return self._choose_tab(self.getControl(TABS).getSelectedPosition())
        if control_id == SECTIONS:
            line = self._section_line()
            if line and line['key'] == 'add':
                _team_sports_page()
                return self._followed_again()
            self._ask(line)
            return self.setFocusId(ROWS) if self.lines else None
        if control_id == ROWS:                     # a match: the Results page's Favourites (its sources, its channel)
            return self._close('teams')
        if control_id == SOURCES:
            at = self.getControl(SOURCES).getSelectedPosition()
            if 0 <= at < len(self.sources):
                self._act(self.sources[at])

    def _close(self, pending):
        self.pending, self.closed = pending, True

    def _finish(self):
        drop(self.pool)

    def _load_sports(self):
        try:
            self.results.put(('sports', sport_scores.sports()))
        except Exception:
            pass

    def _followed_again(self):
        self.leagues, self.teams = followed()
        self._paint_sections()

    def _mine(self):
        return [t for t in self.teams if self.tab in (ALL, t['sport'])]

    def _paint_sections(self):
        lines = [{'key': 'team:%s/%s/%s' % (t['sport'], t['league'], t['id']), 'label': t['name'], 'label2': '', 'icon': t.get('logo') or '',
                  'team': t, 'section': ('team', t['sport'], t['league'], t['id']),
                  'current': '1' if (t['sport'], t['league'], t['id']) == self.shown else ''} for t in self._mine()]
        lines.append({'key': 'add', 'label': 'Add a team', 'label2': '', 'icon': ICON % 'add', 'section': ('add',), 'current': ''})
        before, self.sections = self.sections, lines
        fill(self.getControl(SECTIONS), before, lines)
        if not self._mine():
            self.setProperty(P + 'note', 'Follow your teams - Add a team, any sport.')

    def _section_line(self):
        at = self.getControl(SECTIONS).getSelectedPosition()
        return self.sections[at] if 0 <= at < len(self.sections) else None

    def _choose_tab(self, at):
        if not 0 <= at < len(self.tabs) or self.tabs[at][0] == self.tab:
            return
        self.tab = self.tabs[at][0]
        self._paint_tabs()
        self._paint_sections()

    def _ask(self, line):
        if not line or 'team' not in line:
            return
        team = line['team']
        key = (team['sport'], team['league'], team['id'])
        if key == self.asking:
            return
        self.asking = key
        self.setProperty(P + 'heading', team['name'])
        self.setProperty(P + 'note', 'Loading %s...' % team['name'])
        self.pool.submit(self._load_team, team)

    def _load_team(self, team):
        try:
            coming, done = sport_scores.team_schedule(team['sport'], team['league'], team['id'])
        except Exception:
            coming, done = [], []
        self.results.put(('team', team, coming, done))

    def tick(self):
        while True:
            try:
                got = self.results.get_nowait()
            except queue.Empty:
                break
            if got[0] == 'sports':
                self.sports = got[1] or self.sports
                self._paint_tabs()
            elif got[0] == 'team':
                self._show_team(*got[1:])
        focus = self.getFocusId()
        if focus == ROWS:
            self._past_heads()
        rested = time.monotonic() - self.moved_at
        if focus == TABS and rested >= TAB_REST:
            self._choose_tab(self.getControl(TABS).getSelectedPosition())
        elif focus != TABS and self.tabs:
            self._strip_on_shown()
        if focus == SECTIONS and rested >= REST:
            self._ask(self._section_line())

    def _show_team(self, team, coming, done):
        key = (team['sport'], team['league'], team['id'])
        if key != self.asking:
            return
        self.shown = key
        lines = ([head_line('Next', '')] + [match_line(m) for m in coming] if coming else []) + \
                ([head_line('Results', '')] + [match_line(m) for m in done] if done else [])
        before, self.lines = self.lines, lines
        fill(self.getControl(ROWS), before, lines)
        first = next((n for n, l in enumerate(lines) if l['kind'] != 'head'), 0)
        if lines:
            self.getControl(ROWS).selectItem(first)
        self._row_at = first
        self.setProperty(P + 'note', '' if lines else 'ESPN has no match of %s now.' % team['name'])
        league = next((m.get('league_name') for m in coming + done if m.get('league_name')), '') or team['league']
        for name, value in (('art', team.get('logo') or ''), ('title', team['name']), ('about', league), ('home', ''), ('tv', ''),
                            ('video_status', ''), ('sources_status', '')):
            self.setProperty(P + name, value)
        self.sources = [{'key': 'table', 'kind': 'table', 'label': 'Table', 'label2': league, 'icon': ICON % 'tables'},
                        {'key': 'unfollow', 'kind': 'unfollow', 'label': 'Unfollow', 'label2': team['name'], 'icon': ICON % 'bookmark'}]
        control = self.getControl(SOURCES)
        control.reset()
        for source in self.sources:
            item = xbmcgui.ListItem(source['label'], source['label2'])
            item.setArt({'icon': source['icon']})
            control.addItem(item)
        self._paint_sections()

    def _act(self, action):
        if not self.shown:
            return
        sport, league, team_id = self.shown
        if action['kind'] == 'table':
            return self._close('tables:%s/%s' % (sport, league))
        leagues, teams = followed()
        keep(leagues, [t for t in teams if (t['sport'], t['league'], t['id']) != self.shown])
        self.shown = self.asking = None
        self.lines, self.sources = [], []
        self.getControl(ROWS).reset()
        self.getControl(SOURCES).reset()
        for name in ('art', 'title', 'about'):
            self.setProperty(P + name, '')
        self._followed_again()
        self.setFocusId(SECTIONS)


SWITCHES = ('scores', 'live', 'today', 'teams', 'addons', 'tables', 'favourites', 'multiview')


def _switches(pending):
    return bool(pending) and pending.split(':', 1)[0] in SWITCHES


def _run(screen, previous=None):
    """A MegaSport screen until it closes (its loop: what its workers found, the cursor, what plays). The screen it
    came from goes once this one is drawn (no blink between the scores page and the Tables); the Sport screen it was
    opened over steps aside then - a dialog left under it stays over Kodi's player when the page goes full screen
    ("vrati me u live, ide zvuk, slike nema") - and comes back before the last MegaSport screen goes."""
    monitor = xbmc.Monitor()
    switching = False
    try:
        screen.show()
        for _ in range(50):
            if screen.ready or monitor.waitForAbort(.02):
                break
        if previous is not None:
            previous._native_close()
        elif screen.behind is not None:
            xbmcgui.WindowXMLDialog.close(screen.behind)
        screen._settle_focus()                       # down into what it shows - never left on the icon that opened it
        while not screen.closed and not monitor.abortRequested():
            screen.tick()
            monitor.waitForAbort(.1)
        switching = _switches(screen.pending) and not monitor.abortRequested()
    finally:
        screen.closed = True
        screen._finish()
        if not switching:
            # the Sport screen under it again - not on the way to the HUB, which it leaves for as well (no blink of it)
            if screen.behind is not None and screen.pending != 'hub' and not monitor.abortRequested():
                screen.behind.show_ready()
            screen._native_close()
    return screen.pending


def _screens(intent, behind=None, from_sport=False):
    """The scores page and the Tables screen, one after the other as they ask, until one is left for good."""
    path, theme = ADDON.getAddonInfo('path'), theme_folder()
    previous = None
    try:
        while True:
            kind, xml = ((MegaSportTables, TABLES_XML) if intent.startswith('tables') else
                         (MegaSportFavourites, XML) if intent == 'favourites' else (MegaSportScreen, XML))
            screen = kind(xml, path, theme, '1080i', intent=intent, from_sport=from_sport, behind=behind)
            intent = _run(screen, previous)
            if not _switches(intent):
                return intent
            previous = screen
    finally:
        sport_scores.forget()


def run_page(intent='scores', behind=None):
    """The live-score page (or the Tables) over the Sport screen (``behind``) - its top bar's Scores, Tables,
    Favourites - until its Back (the Sport screen again) or HUB ('hub': the Sport screen leaves for the HUB too -
    "u sportu Hub iz gornjeg reda ne izbacuje nas na glavni hub di su aplikacije ... kad smo u rezultatima")."""
    return _screens(intent, behind, from_sport=True)


def open_megasport():
    """The live-score page on its own (RunScript(script.meganexus,megasport_scores)) - its HUB button the way out."""
    screen_guard.hold()
    try:
        _screens('scores')
    finally:
        screen_guard.release()
        xbmc.executebuiltin('ActivateWindow(Home)')
