# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The player's Picture size button (9.1.4): Kodi's own view modes - the one in use marked - to take black bars
away or fill the screen. Kodi applies the choice to the video playing, as its own view mode setting does; the
names and their order are Kodi's."""
import xbmcgui

from .audio_streams import _rpc, _video_player

# Kodi's view modes (JSON-RPC Player.ViewMode), in Kodi's own order
MODES = (('normal', 'Normal · the picture as it is'),
         ('zoom', 'Zoom · fills the screen, the edges cut off'),
         ('stretch4x3', 'Stretch 4:3'),
         ('widezoom', 'Wide zoom · a little zoom and a little stretch'),
         ('stretch16x9', 'Stretch 16:9 · stretched to fill the screen'),
         ('original', 'Original size'),
         ('stretch16x9nonlin', 'Stretch 16:9 · nonlinear, the middle kept'),
         ('zoom120width', 'Zoom 120% width'),
         ('zoom110width', 'Zoom 110% width'))


def run():
    if _video_player() is None:
        return
    current = (_rpc('Player.GetViewMode') or {}).get('viewmode')
    rows = [('▶  ' if key == current else '     ') + name for key, name in MODES]
    position = next((i for i, (key, _name) in enumerate(MODES) if key == current), 0)
    choice = xbmcgui.Dialog().select('Picture size', rows, preselect=position)
    if choice >= 0 and MODES[choice][0] != current:
        _rpc('Player.SetViewMode', {'viewmode': MODES[choice][0]})
