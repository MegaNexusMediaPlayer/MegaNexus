# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Account and extras are optional; Home separately requires validated catalog setup."""
import xbmcgui
from resources.lib import backend_api, settings_snapshot
from resources.lib.meganexus import cloud_sync as sync
from . import settings

ADDON=settings.ADDON


def _steps():
    """Step by step with the remote, in the order of HUB Settings (7.0)."""
    from . import simkl_account, system_setup, iptv, keys_backup
    return [
        ('Accounts', [('Manage connected Nuvio account',settings.accounts) if sync.NuvioCloud.is_linked() else ('Connect Nuvio account',settings.sign_in_nuvio),
                      ('Stremio account',keys_backup.stremio)]),
        ('Add-ons (Home layout is kept)', [('Import my Nuvio add-ons and progress',settings.sync_nuvio),
                                   ('Add a configured provider manifest',lambda:settings.add_manifest(xbmcgui.Dialog())),
                                   ('Enable metadata add-ons',lambda:settings.select_provider('metadata')),
                                   ('Enable stream add-ons',lambda:settings.select_provider('streams'))]),
        ('API keys (optional)', [('TMDb, MDBList, Fanart.tv, TheIntroDB',keys_backup.keys)]),
        ('Collections', [('Import and validate Nuvio collections',settings.import_nuvio_collections),
                         ('Collections & Home rows',settings.collections)]),
        ('Tracking services', [('Connect Trakt',_trakt),('Connect Simkl with a PIN',simkl_account.link)]),
        ('Playback and extras', [('Autoplay and intro / credits',settings.playback),('Set up IPTV / EPG',iptv.configure),
                                 ('Weather location',system_setup.weather),('Home & library',settings.home_library),
                                 ('Themes, colours & screensaver',settings.themes_screensaver)]),
    ]


def _trakt():
    from .trakt_account import run
    return run()


WELCOME=[
    ('nuvio','I use Nuvio','Sign in: add-ons, collections and Continue Watching are imported.'),
    ('stremio','I use Stremio','Sign in: add-ons and Continue Watching are imported.'),
    ('backup','Restore a MegaNexus backup','Everything exactly as on your other device.'),
    ('phone','Set up on your phone','Scan a QR code: accounts, add-ons, API keys and collections on the phone.'),
    ('simple','Start simple','The MegaNexus Catalog and ready-made collections. Change anything later in HUB Settings.'),
    ('remote','Step by step with the remote','Accounts, add-ons, playback and extras, one step at a time.'),
]


def welcome(dialog):
    """First start: 'done' when set up, 'remote' for the step-by-step, a
    command for the caller, or '' when skipped."""
    items=[]
    for _,label,detail in WELCOME:
        item=xbmcgui.ListItem(label,detail)
        items.append(item)
    pick=dialog.select('Welcome to MegaNexus · how do you want to start?',items,useDetails=True)
    if pick<0:return ''
    way=WELCOME[pick][0]
    try:
        if way=='nuvio':
            if settings.sign_in_nuvio():_finish();return 'done'
            return ''
        if way=='stremio':
            from .keys_backup import stremio
            from resources.lib import stremio_account
            stremio()
            if stremio_account.linked():_finish();return 'done'
            return ''
        if way=='backup':
            from .keys_backup import restore
            result=restore()
            if result:_finish()
            return result or ''
        if way=='phone':
            from .phone_setup import run as phone
            if phone():_finish();return 'done'
            return ''
        if way=='simple':
            _finish()
            dialog.notification('MegaNexus','Ready. Add accounts and add-ons any time in HUB Settings.',time=4000)
            return 'done'
    except Exception as exc:
        dialog.ok('MegaNexus setup',str(exc) if isinstance(exc,ValueError) else 'This step could not finish. Check your account or connection and retry.')
        return ''
    return way


def _summary():
    from resources.lib import simkl_api
    meta,streams=backend_api.provider('metadata'),backend_api.provider('streams')
    name=lambda p:(p.get('name') or p.get('id')) if p else 'Not connected'
    return '\n'.join(['Nuvio account: '+('Connected' if sync.NuvioCloud.is_linked() else 'Skipped'),
                      'Metadata: '+name(meta),'Streams: '+name(streams),
                      'Simkl: '+('Connected' if simkl_api.authorized() else 'Skipped'),
                      '', 'You can change every choice in HUB Settings.'])


def _finish():
    ADDON.setSetting('meganexus_setup_v110_done','true')
    ADDON.setSetting('meganexus_setup_v110_step','0')
    ADDON.setSetting('meganexus_wizard_applied','true')
    settings_snapshot.invalidate()


def _offered():
    ADDON.setSetting('meganexus_setup_offered','true')
    settings_snapshot.invalidate()


def _already_started():
    """Recognize partially configured profiles created before the offered flag."""
    if any(ADDON.getSetting(key)=='true' for key in ('meganexus_setup_offered','meganexus_setup_v110_done','meganexus_wizard_applied')):return True
    try:
        if int(ADDON.getSetting('meganexus_setup_v110_step') or 0)>0:return True
    except ValueError:pass
    if any(ADDON.getSetting('meganexus_'+role+'_provider') for role in ('metadata','streams')):return True
    if sync.NuvioCloud.is_linked():return True
    from resources.lib import simkl_api
    return simkl_api.authorized()


def run(force=False):
    if not force and _already_started():
        if ADDON.getSetting('meganexus_setup_offered')!='true':_offered()
        return
    # Offer once, including when Back/Cancel dismisses the very first step.
    # Completion is separate: every optional step remains available manually.
    # 7.0.51: never over Kodi's "Keep this skin?" - and not at all without the skin kept
    from resources.lib import skin_activation
    if not skin_activation.settled():return None
    _offered()
    dialog=xbmcgui.Dialog()
    if not force:
        # 7.0: one clear choice first. People found add-ons, metadata and
        # collections hard to set up; an account or a backup brings them all.
        way=welcome(dialog)
        if way!='remote':return None   # set up, restored (Home loads it) or skipped
    steps=_steps()
    try:index=0 if force else min(len(steps)-1,max(0,int(ADDON.getSetting('meganexus_setup_v110_step') or 0)))
    except ValueError:index=0
    while index<len(steps):
        title,actions=steps[index]
        labels=[name for name,_ in actions]+['Next','Skip this step','Finish optional steps and check collection setup']
        if index:labels.append('Previous step')
        status=(' - '+settings.nuvio_status()) if index<2 else ''
        pick=dialog.select('Welcome to MegaNexus - %d/%d: %s%s'%(index+1,len(steps),title,status),labels)
        if pick<0:return  # Open MegaNexus goes to Home; setup stays available in Settings.
        if pick<len(actions):
            try:
                result=actions[pick][1]()
                if result=='meganexus:activate_skin':return 'meganexus:activate_skin:wizard'
                if isinstance(result,str) and result.startswith('ActivateWindow('):return result
                if result is True and index<2:
                    index+=1
                    ADDON.setSetting('meganexus_setup_v110_step',str(index))
            except Exception:
                dialog.ok('MegaNexus setup','This step could not finish. Check your account or connection, retry, or skip it for now.')
            finally:settings_snapshot.invalidate()
            continue
        choice=pick-len(actions)
        if choice==2:_finish();return
        index=index-1 if choice==3 else index+1
        ADDON.setSetting('meganexus_setup_v110_step',str(index))
    dialog.ok('MegaNexus setup',_summary())
    _finish()
