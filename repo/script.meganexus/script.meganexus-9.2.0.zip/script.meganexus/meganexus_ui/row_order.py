# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A screen's rows as the person puts them (idea): which are shown and in what order - MegaIPTV's channel, film and
series groups (megaiptv.py: "treba organizaciju rowsa u opcijama za kanale serije i filmove") and the rows the sport
add-ons offer in Sport (sports.py: "da se mogu pomjerati i od addona redove koje nudi prikazati i sakriti").

What is kept: {'hidden': [key, ...], 'order': [key, ...]}. A row given a place in ``order`` comes first in that order,
every other one after them as its source lists them; a hidden one is left out. A row the source no longer has is
simply not there (its key stays until the person orders again)."""
import xbmcgui


def arranged(rows, kept):
    """``rows`` [(key, ...)] as ``kept`` puts them."""
    kept = kept or {}
    hidden = set(kept.get('hidden') or [])
    order = list(kept.get('order') or [])
    rank = {key: n for n, key in enumerate(order)}
    return sorted((r for r in rows if str(r[0]) not in hidden), key=lambda r: rank.get(str(r[0]), len(order)))


def page(title, rows, load, save):
    """Every row of ``rows()`` [(key, name)] in its order, shown or hidden; OK on one: hide / show it, up, down, to
    the top. ``load()`` -> what is kept, ``save(kept)``."""
    from . import settings_page

    def ordered():
        rank = {key: n for n, key in enumerate((load() or {}).get('order') or [])}
        return sorted(rows(), key=lambda r: rank.get(r[0], len(rank)))

    def build():
        hidden = set((load() or {}).get('hidden') or [])
        return [(key, settings_page.item(name, enabled=key not in hidden)) for key, name in ordered()]

    def act(key):
        listed = ordered()
        keys = [k for k, _ in listed]
        if key not in keys:
            return None
        hidden = set((load() or {}).get('hidden') or [])
        pick = xbmcgui.Dialog().select(dict(listed)[key], ['Show' if key in hidden else 'Hide', 'Move up', 'Move down', 'Move to the top'])
        at = keys.index(key)
        if pick == 0:
            hidden ^= {key}
        elif pick in (1, 2, 3):
            keys.pop(at)
            keys.insert({1: max(0, at - 1), 2: min(len(keys), at + 1), 3: 0}[pick], key)
        else:
            return None
        save({'hidden': sorted(hidden), 'order': keys})
        return None
    return settings_page.keyed(title, build, act)
