# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, MultiView's grid as a process of its own (python3 multiview_grid.py FOLDER; nothing of Kodi in it):
"moras lokalno za svaki kanal imati posebnu liniju da bi ovo radilo bez stekanja".

Measured on two real channels through one ffmpeg for all: when one channel came late the whole grid stood - its pieces
3.9 s and 3.0 s apart instead of 2 - and every tile and Kodi waited for it ("zasteka svako nekoliko sekundi"). Here each
channel has a line of its own (Line): its own connection, the stream as it came held in its buffer - seconds of it, the
mark doubled each time the line ran dry ("dinamicki po kanalu da se meduspremnik dinamicki rijesava") - and its own
decoder, which makes its pictures one size in their real shape (a 720x576 16:9 channel was drawn narrow: "jednu sliku si
suzio") and its sound. One clock takes from every line a picture and the sound that goes with it 25 times a second - a
line that ran dry gives its last picture and silence, the others go on - and gives them to the encoder, which puts each in
its tile (multiview_layout) and writes the short live HLS Kodi plays, served from here on 127.0.0.1. The grid shows at
once; a tile shows its channel when its line has filled.

Kodi (multiview.py Grid) writes one line of JSON on stdin per grid - {"gen": n, "layout": ..., "channels": [address,
...], "heard": n} - a channel already in the grid keeps its line (no new connection) - and {"heard": n} when the cursor
goes to another tile: the grid has one sound, the heard channel's, changed here (idea 2026-11-21 "kad prebacujem izmedu
multiview strimova umjesto da samo aktivira zvuk drugog kanala on buferuje sve": Kodi seeks whenever its audio track
changes - VideoPlayer, PLAYER_SET_AUDIOSTREAM - and a live HLS filled its buffer again each time). On stdout once: {"port": p}. In FOLDER:
status.json (each tile's state, and how late the box is). It ends when stdin closes or Kodi is gone; its addresses are
never written anywhere.

"mora raditi i na coreelecu libreelecu": what the box can do comes as its profile (multiview.py tools(): python3
multiview_grid.py FOLDER FFMPEG PROFILE) - the encoder it has (a hardware one, libx264, else MPEG-2, which every ffmpeg
has and Kodi plays), and on a small box (ARM, little memory) smaller lines, a smaller grid and a shorter buffer."""
import array
import collections
import functools
import http.server
import json
import os
import queue
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.request

try:                                    # in Kodi: a module of meganexus_ui (tools() takes its encoders' words)
    from . import multiview_layout as layout
except ImportError:                     # run as the grid's process: its folder's (nothing of Kodi in it)
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import multiview_layout as layout  # noqa: E402

FPS = 25
FULL = {'line': [960, 540], 'out': [1920, 1080], 'most': 8.0, 'light': False, 'encoder': 'libx264', 'device': ''}
LIGHT = {'line': [640, 360], 'out': [1280, 720], 'most': 4.0, 'light': True, 'encoder': 'libx264', 'device': ''}
RATE = 48000
SOUND = RATE // FPS * 2 * 2             # 16-bit stereo sound of one picture
SILENCE = bytes(SOUND)
FIRST = 1.5                             # seconds a line holds before its tile shows it
FIRST_STREAM = 6.0                      # ... a sport add-on's stream (HLS comes a piece of seconds at a time: with 4 it ran dry once)
AHEAD = 3.0                             # seconds over its mark before it plays a little faster to come back
SEGMENT, PIECES = 1, 12                 # seconds in a piece of the grid's HLS, pieces in its playlist
QUEUE = 8                               # beats the encoder may be behind (each picture and the sound alike)
READ = 65536
STALL = 8                               # seconds without a byte before a line connects again
AGENT = 'MegaNexus/9'
ADDRESS = re.compile(r'[a-z][a-z0-9+.-]*://\S+', re.I)
NO_SOUND = ('matches no streams', 'does not contain any stream')


def hidden(text):
    """``text`` with every address in it hidden (a channel's address has the login in it)."""
    return ADDRESS.sub('<address>', text or '')


def ground_yuv():
    """The ground's colour (multiview_layout.GROUND) as limited-range BT.601 Y, Cb, Cr - ffmpeg's own for yuv420p."""
    r, g, b = (int(layout.GROUND[i:i + 2], 16) for i in (2, 4, 6))
    return (round(16 + (65.738 * r + 129.057 * g + 25.064 * b) / 256), round(128 + (-37.945 * r - 74.494 * g + 112.439 * b) / 256),
            round(128 + (112.439 * r - 94.154 * g - 18.285 * b) / 256))


def picture_bytes(profile):
    w, h = profile['line']
    return w * h * 3 // 2                                  # yuv420p


def blank_picture(profile=FULL):
    y, u, v = ground_yuv()
    w, h = profile['line']
    quarter = w * h // 4
    return bytes([y]) * (w * h) + bytes([u]) * quarter + bytes([v]) * quarter


def split_address(address):
    """A Kodi stream address - 'url|User-Agent=...&Referer=...' (a sport add-on's, with the headers it wants) - as
    (url, {header: value})."""
    from urllib.parse import parse_qsl
    url, _, said = (address or '').partition('|')
    return url, dict(parse_qsl(said, keep_blank_values=True)) if said else {}


def network_input(address):
    """ffmpeg's own reading of a stream (a sport add-on's HLS or TS): its headers, connecting again when it stops."""
    url, headers = split_address(address)
    words = ['-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5', '-rw_timeout', str(STALL * 1000000)]
    agent = next((v for k, v in headers.items() if k.lower() == 'user-agent'), '')
    words += ['-user_agent', agent or AGENT]
    others = ''.join('%s: %s\r\n' % (k, v) for k, v in headers.items() if k.lower() != 'user-agent')
    return words + (['-headers', others] if others else []) + ['-i', url]


def decoder_command(binary, video_fd, sound_fd, sound=True, profile=FULL, address=None):
    """A line's decoder: the stream from stdin (an IPTV channel MegaNexus reads itself) - or, ``address`` given, read by
    ffmpeg itself (a sport add-on's stream: HLS, its headers); its pictures in their real shape (each pixel as wide as
    the stream says), in the profile's line size on the ground, 25 a second from 0 (the ones that go, of a stream of 50
    or 60, go before they are scaled: on the Cube a 1080p50 line took a fifth less), its sound 48 kHz stereo from 0 -
    picture n and sound n are one moment. On a small box it decodes the lighter way (no loop filter, one thread)."""
    ground = '0x' + layout.GROUND[2:]
    w, h = profile['line']
    light = ['-skip_loop_filter', 'all', '-threads', '1'] if profile.get('light') else ['-threads', '2']   # a thread a core: ~150 MB
    source = network_input(address) if address else ['-f', 'mpegts', '-i', 'pipe:0']
    cmd = [binary, '-hide_banner', '-nostdin', '-loglevel', 'error'] + light + ['-filter_threads', '1',
           '-fflags', '+genpts+discardcorrupt'] + source + ['-map', '0:v:0',
           '-vf', "fps=%d:start_time=0,scale='trunc(iw*sar/2)*2':ih,setsar=1,scale=%d:%d:force_original_aspect_ratio=decrease:"
                  "flags=fast_bilinear,pad=%d:%d:(ow-iw)/2:(oh-ih)/2:color=%s,setsar=1,format=yuv420p" % (FPS, w, h, w, h, ground),
           '-f', 'rawvideo', 'pipe:%d' % video_fd]
    if sound:
        cmd += ['-map', '0:a:0', '-af', 'aresample=%d:async=1000:first_pts=0' % RATE, '-ac', '2', '-f', 's16le', 'pipe:%d' % sound_fd]
    return cmd


def video_codec(encoder):
    """The grid's video encoder's words: a hardware one, libx264, else MPEG-2 (in every ffmpeg; Kodi plays it)."""
    group = str(FPS * SEGMENT)                             # a key picture at every piece
    if encoder == 'h264_vaapi':
        return ['-c:v', 'h264_vaapi', '-b:v', '8M', '-maxrate', '8M', '-g', group]
    if encoder == 'h264_v4l2m2m':
        return ['-c:v', 'h264_v4l2m2m', '-b:v', '8M', '-g', group, '-pix_fmt', 'yuv420p']
    if encoder == 'libx264':
        return ['-c:v', 'libx264', '-preset', 'ultrafast', '-tune', 'zerolatency', '-b:v', '8M', '-maxrate', '8M', '-bufsize', '8M',
                '-g', group, '-pix_fmt', 'yuv420p']
    return ['-c:v', 'mpeg2video', '-b:v', '12M', '-maxrate', '12M', '-bufsize', '4M', '-g', group, '-pix_fmt', 'yuv420p']


def _even(value):
    return int(round(value / 2.0)) * 2


def encoder_command(binary, count, kind, folder, gen, picture_fds, sound_fd, profile=FULL):
    """The encoder: ``count`` lines' pictures (raw, from the clock) each in its tile on the ground - the tiles where the
    skin draws them, in the profile's grid size - and the heard one's sound (the clock's), as a live HLS (grid<gen>.m3u8)
    in ``folder``. ``picture_fds``: a line's pictures each; ``sound_fd``: the sound."""
    lw, lh = profile['line']
    ow, oh = profile['out']
    at = float(ow) / layout.WIDTH
    cmd = [binary, '-hide_banner', '-nostdin', '-loglevel', 'error']
    if profile.get('encoder') == 'h264_vaapi':
        cmd += ['-vaapi_device', profile.get('device') or '/dev/dri/renderD128']
    # what each input is it is told: ffmpeg looks into none of them (it opens its inputs one by one, and looking it read
    # up to 5 MB of the first while the grid gives every input a beat at a time - Encoder.give)
    told = ['-probesize', '32', '-analyzeduration', '0']
    for picture_fd in picture_fds:
        cmd += told + ['-f', 'rawvideo', '-pix_fmt', 'yuv420p', '-s', '%dx%d' % (lw, lh), '-framerate', str(FPS),
                       '-thread_queue_size', '64', '-i', 'pipe:%d' % picture_fd]
    cmd += told + ['-f', 's16le', '-ar', str(RATE), '-ac', '2', '-thread_queue_size', '512', '-i', 'pipe:%d' % sound_fd]
    parts = ['color=c=%s:s=%dx%d:r=%d[bg0]' % (layout.GROUND, ow, oh, FPS)]
    for n, (x, y, w, h) in enumerate(layout.tiles(count, kind)):
        parts.append('[%d:v]scale=%d:%d:flags=fast_bilinear,setsar=1[v%d]' % (n, _even(w * at), _even(h * at), n))
        parts.append('[bg%d][v%d]overlay=x=%d:y=%d:shortest=1[bg%d]' % (n, n, _even(x * at), _even(y * at), n + 1))
    out = '[bg%d]' % count
    if profile.get('encoder') == 'h264_vaapi':
        parts.append('%sformat=nv12,hwupload[up]' % out)
        out = '[up]'
    cmd += ['-filter_complex', ';'.join(parts), '-map', out] + video_codec(profile.get('encoder'))
    cmd += ['-map', '%d:a' % count, '-c:a', 'aac', '-b:a', '128k', '-f', 'hls', '-hls_time', str(SEGMENT), '-hls_list_size', str(PIECES),
            '-hls_flags', 'delete_segments+omit_endlist', '-hls_segment_filename', os.path.join(folder, 'g%d_%%d.ts' % gen),
            os.path.join(folder, 'grid%d.m3u8' % gen)]
    return cmd


def crossfade(old, new):
    """One beat's sound going from ``old`` to ``new`` (16-bit stereo, the boxes' own byte order: little-endian) - no
    click where the heard channel changes."""
    if len(old) != len(new):
        return new
    a, b = array.array('h', old), array.array('h', new)
    frames = len(b) // 2
    for i in range(len(b)):
        t = (i // 2) / frames
        b[i] = int(a[i] * (1 - t) + b[i] * t)
    return b.tobytes()


def _read_exactly(fd, size):
    data = bytearray()
    while len(data) < size:
        part = os.read(fd, size - len(data))
        if not part:
            return None
        data += part
    return bytes(data)


def _write_all(fd, data):
    view = memoryview(data)
    while view:
        view = view[os.write(fd, view):]


class Line:
    """One channel's own line: its connection, its decoder, and its buffer - the decoded pictures and their sound,
    numbered (picture n and sound n are one moment, so the sound never runs from its picture). The clock calls
    ``take`` 25 times a second; the rest runs in its threads."""

    PIPE, URL = 'pipe', 'url'               # an IPTV channel read here into its decoder / a stream its decoder reads

    def __init__(self, address, binary='ffmpeg', profile=FULL, kind=PIPE):
        self.address, self.binary, self.profile, self.kind = address, binary, profile, kind
        first = FIRST if kind == self.PIPE else FIRST_STREAM
        self.most, self.keep = profile['most'], (profile['most'] + AHEAD + 2) * FPS     # pictures it keeps at most
        self.lock = threading.Lock()
        self.blank = self.last = blank_picture(profile)
        self.pictures, self.sounds = collections.deque(), collections.deque()   # (n, data) of this decoder's
        self.taken = 0                                  # the number of the next picture the clock takes
        self.mark, self.filling = first, True          # seconds held before it plays (on); filling: holding
        self.sound, self.shown, self.dry, self.why = True, False, 0, ''
        self.alive, self.decoder, self._beat, self._response = True, None, 0, None

    # --- the clock's side (never waits) ---
    def take(self):
        """This beat's picture and its sound: the line's next - or, holding (filling to its mark) or dry, its last
        picture and silence. Run dry, it fills to a mark twice as long before it plays on."""
        with self.lock:
            pictures, sounds = self.pictures, self.sounds
            if self.filling:
                if len(pictures) < self.mark * FPS:
                    return self.last, SILENCE
                self.filling = False
                while not self.shown and len(pictures) > self.mark * FPS:
                    pictures.popleft()                  # its start: only its mark held (no picture of it was shown yet)
            if not pictures:
                self.filling, self.dry, self.mark = True, self.dry + 1, min(self.most, self.mark * 2)
                return self.last, SILENCE
            self._beat += 1
            if len(pictures) > (self.mark + AHEAD) * FPS and self._beat % 5 == 0 and len(pictures) > 1:
                pictures.popleft()                      # far ahead (it came faster than our clock): a picture less
            n, self.last = pictures.popleft()
            self.shown = True
            while sounds and sounds[0][0] < n:          # sound of pictures that went
                sounds.popleft()
            if sounds and sounds[0][0] == n:
                return self.last, sounds.popleft()[1]
            return self.last, SILENCE

    def state(self):
        with self.lock:
            return {'shown': self.shown, 'mark': self.mark, 'held': round(len(self.pictures) / FPS, 1), 'dry': self.dry,
                    'why': self.why}

    # --- its threads ---
    def start(self):
        threading.Thread(target=self._receive if self.kind == self.PIPE else self._read_itself, daemon=True).start()
        return self

    def _read_itself(self):
        """A sport add-on's stream: its decoder reads it itself; when it ends, it is started again (later each time)."""
        wait = 1.0
        while self.alive:
            decoder = self._start_decoder()
            began = time.monotonic()
            decoder.wait()
            if not self.alive:
                return
            wait = 1.0 if time.monotonic() - began > 30 else min(wait * 2, 10.0)
            time.sleep(wait)

    def stop(self):
        self.alive = False
        response, self._response = self._response, None
        if response is not None:
            try:
                response.close()
            except Exception:
                pass
        self._end_decoder()

    def _receive(self):
        """Its connection: the stream straight into its decoder; when the provider stops sending, it connects again
        (a new stream: a new decoder, the line fills again)."""
        wait = 1.0
        while self.alive:
            try:
                request = urllib.request.Request(self.address, headers={'User-Agent': AGENT})
                self._response = urllib.request.urlopen(request, timeout=STALL)
                with self.lock:
                    self.why = ''
                read = getattr(self._response, 'read1', self._response.read)      # what came, not a full READ
                while self.alive:
                    data = read(READ)
                    if not data:
                        raise OSError('the provider ended the stream')
                    wait = 1.0
                    decoder = self.decoder if self.decoder is not None and self.decoder.poll() is None else self._start_decoder()
                    try:
                        decoder.stdin.write(data)
                    except (OSError, ValueError):
                        self._end_decoder()
            except Exception as error:
                if not self.alive:
                    return
                with self.lock:
                    self.why = hidden(str(error))[:200]
                self._end_decoder()
                time.sleep(wait)
                wait = min(wait * 2, 10.0)

    def _start_decoder(self):
        picture_read, picture_write = os.pipe()
        sound_read, sound_write = os.pipe()
        decoder = subprocess.Popen(decoder_command(self.binary, picture_write, sound_write, self.sound, self.profile,
                                                   self.address if self.kind == self.URL else None),
                                   stdin=subprocess.PIPE if self.kind == self.PIPE else subprocess.DEVNULL,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, pass_fds=(picture_write, sound_write), bufsize=0)
        os.close(picture_write)
        os.close(sound_write)
        pictures, sounds = collections.deque(), collections.deque()
        with self.lock:
            self.decoder, self.pictures, self.sounds, self.filling = decoder, pictures, sounds, True
        threading.Thread(target=self._read, args=(picture_read, picture_bytes(self.profile), pictures), daemon=True).start()
        threading.Thread(target=self._read, args=(sound_read, SOUND, sounds), daemon=True).start()
        threading.Thread(target=self._decoder_words, args=(decoder,), daemon=True).start()
        return decoder

    def _read(self, fd, size, into):
        """The decoder's pictures (or sound) into the line's buffer, numbered from 0; past what it keeps the oldest go."""
        n = 0
        try:
            while True:
                part = _read_exactly(fd, size)
                if part is None:
                    return
                with self.lock:
                    into.append((n, part))
                    while len(into) > self.keep:
                        into.popleft()
                n += 1
        finally:
            os.close(fd)

    def _decoder_words(self, decoder):
        """Why its decoder ended (its addresses hidden); a stream with no sound: the decoder again, pictures only."""
        for raw in decoder.stderr:                       # line by line: a damaged stream says much, only the last is kept
            text = hidden(raw.decode('utf-8', 'replace').strip())
            if any(w in text for w in NO_SOUND):
                self.sound = False
            if text:
                with self.lock:
                    self.why = text[:200]

    def _end_decoder(self):
        decoder, self.decoder = self.decoder, None
        if decoder is not None:
            try:
                if decoder.stdin is not None:          # (a stream its decoder reads itself has none)
                    decoder.stdin.close()
            except OSError:
                pass
            if decoder.poll() is None:
                try:
                    decoder.kill()
                    decoder.wait(3)
                except (OSError, subprocess.SubprocessError):
                    pass


class Encoder:
    """The encoder of one grid (its generation): each line's picture and the sound written to it by a thread of its own,
    so the clock never waits on it."""

    def __init__(self, binary, count, kind, folder, gen, profile=FULL):
        pictures, sound = [os.pipe() for _ in range(count)], os.pipe()
        theirs = [p[0] for p in pictures] + [sound[0]]
        self.process = subprocess.Popen(encoder_command(binary, count, kind, folder, gen, theirs[:-1], theirs[-1], profile),
                                        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                        pass_fds=theirs)
        for fd in theirs:
            os.close(fd)
        self.queues = [queue.Queue(QUEUE) for _ in range(count + 1)]              # the lines' pictures, then the sound
        for (_, fd), into in zip(pictures + [sound], self.queues):
            threading.Thread(target=self._write, args=(fd, into), daemon=True).start()
        self.why, self.closed = '', False
        threading.Thread(target=self._words, daemon=True).start()

    def give(self, pictures, sound):
        """This beat's pictures (a line's each) and its sound - all of it, or none when the encoder is behind (a queue of
        it full; only the clock puts): a beat it misses goes whole. Its pictures and sound are counted into its HLS (25
        a second, 48 kHz): a picture that went while its sound did not left every picture after it early - the sound
        late for good (idea 2026-11-21 "u multiview zvuk kasni malo": ~0.77 s on the Cube, the encoder's second to
        start while the sound's queue held 2 s and the pictures' 0.3). False when it was behind: the box does not keep
        up."""
        if any(into.full() for into in self.queues):
            return False
        for into, data in zip(self.queues, list(pictures)[:len(self.queues) - 1] + [sound]):
            into.put_nowait(data)
        return True

    def _write(self, fd, into):
        try:
            while True:
                try:
                    data = into.get(timeout=.5)
                except queue.Empty:
                    if self.closed:
                        return
                    continue
                _write_all(fd, data)
        except OSError:
            pass
        finally:
            os.close(fd)                                  # its end: the encoder ends its pieces

    def _words(self):
        for raw in self.process.stderr:
            self.why = hidden(raw.decode('utf-8', 'replace').strip())[:300]

    def close(self):
        self.closed = True
        try:
            self.process.wait(5)
        except subprocess.SubprocessError:
            self.process.kill()


class Grid:
    """The lines, the clock and the encoder of the grid that plays."""

    def __init__(self, folder, binary='ffmpeg', profile=FULL):
        self.folder, self.binary, self.profile = folder, binary, profile
        self.lines, self.encoder, self.gen = [], None, 0
        self.heard, self.fading = 0, None                # the line whose sound is the grid's; the one before, this beat
        self.late = collections.deque(maxlen=FPS * 5)     # of the last beats: was the box behind (True) or not
        self.lock = threading.Lock()
        self.alive = True

    def arrange(self, gen, kind, sources, heard=0):
        """The grid ``gen``: these sources in this layout - an IPTV channel's address (read here), or [address, 'url']
        (a sport add-on's stream, read by its decoder), ``heard`` the one whose sound it has; one already in it keeps its
        line."""
        old = list(self.lines)
        lines = []
        for source in sources:
            address, how = (source, Line.PIPE) if isinstance(source, str) else (source[0], source[1])
            line = next((l for l in old if l.address == address), None)
            if line is not None:
                old.remove(line)
            lines.append(line or Line(address, self.binary, self.profile, how).start())
        encoder = Encoder(self.binary, len(lines), kind, self.folder, gen, self.profile)
        with self.lock:
            self.lines, previous, self.encoder, self.gen = lines, self.encoder, encoder, gen
            self.heard, self.fading = min(max(heard, 0), len(lines) - 1), None
        for line in old:
            line.stop()
        if previous is not None:
            threading.Thread(target=previous.close, daemon=True).start()
        self._forget(gen)

    def _forget(self, gen):
        """The pieces of grids before the one Kodi is given (it played the one before up to now)."""
        for name in os.listdir(self.folder):
            m = re.match(r'(?:grid(\d+)\.m3u8|g(\d+)_\d+\.ts)$', name)
            if m and int(m.group(1) or m.group(2)) < gen - 1:
                try:
                    os.remove(os.path.join(self.folder, name))
                except OSError:
                    pass

    def hear(self, n):
        """Line ``n``'s sound from the next beat on (that beat goes over to it from the one heard before)."""
        with self.lock:
            if 0 <= n < len(self.lines) and n != self.heard:
                self.fading, self.heard = self.heard, n

    def beat(self):
        """One beat of the clock: every line's picture and the heard one's sound to the encoder - a dry line holds none of
        the others."""
        with self.lock:
            lines, encoder, heard, fading, self.fading = list(self.lines), self.encoder, self.heard, self.fading, None
        taken = [line.take() for line in lines]
        if encoder is None or not taken:
            return True
        sound = taken[heard][1]
        if fading is not None and fading < len(taken):
            sound = crossfade(taken[fading][1], sound)
        return encoder.give([picture for picture, _ in taken], sound)

    def clock(self):
        at, beats = time.monotonic(), 0
        while self.alive:
            kept = self.beat()
            beats += 1
            if beats % FPS == 0:
                self.write_state()
            at += 1.0 / FPS
            delay = at - time.monotonic()
            self.late.append(not kept or delay < -.5 / FPS)  # the encoder or the beat behind: the box does not keep up
            if delay > 0:
                time.sleep(delay)
            elif delay < -1:                              # far behind (the machine was busy): the beat starts again
                at = time.monotonic()

    def write_state(self):
        with self.lock:
            lines, encoder, gen = list(self.lines), self.encoder, self.gen
        late = round(sum(self.late) / float(len(self.late)), 2) if self.late else 0.0
        state = {'gen': gen, 'tiles': [line.state() for line in lines], 'why': encoder.why if encoder else '', 'late': late}
        path = os.path.join(self.folder, 'status.json')
        with open(path + '.new', 'w') as out:
            json.dump(state, out)
        os.replace(path + '.new', path)

    def end(self):
        self.alive = False
        with self.lock:
            lines, encoder, self.lines, self.encoder = self.lines, self.encoder, [], None
        for line in lines:
            line.stop()
        if encoder is not None:
            encoder.close()


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def serve(folder):
    """The grid's address for Kodi: 127.0.0.1 only, a free port; .m3u8 as live HLS."""
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(_Quiet, directory=folder))
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def main(folder, binary='ffmpeg', profile=FULL):
    os.makedirs(folder, exist_ok=True)
    server = serve(folder)
    grid = Grid(folder, binary, profile)
    kodi = os.getppid()

    def end(*_):
        grid.end()
        server.shutdown()
        os._exit(0)

    def watch():                                          # Kodi gone (killed, restarted): the grid ends with it
        while os.getppid() == kodi:
            time.sleep(1)
        end()
    signal.signal(signal.SIGTERM, end)
    threading.Thread(target=watch, daemon=True).start()
    threading.Thread(target=grid.clock, daemon=True).start()
    sys.stdout.write(json.dumps({'port': server.server_address[1]}) + '\n')
    sys.stdout.flush()
    for text in sys.stdin:
        try:
            asked = json.loads(text)
            if 'gen' in asked:
                grid.arrange(int(asked['gen']), asked['layout'], list(asked['channels']), int(asked.get('heard') or 0))
            else:
                grid.hear(int(asked['heard']))
        except Exception as error:                        # a wrong line: said in its state, the grid goes on
            sys.stderr.write(hidden(repr(error))[:300] + '\n')
            sys.stderr.flush()
    end()


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else 'ffmpeg', dict(FULL, **json.loads(sys.argv[3])) if len(sys.argv) > 3 else FULL)
