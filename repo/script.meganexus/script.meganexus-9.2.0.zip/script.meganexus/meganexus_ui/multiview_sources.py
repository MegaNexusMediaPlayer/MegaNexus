# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, MultiView's tiles from the sport add-ons: "u multichannel da mozemo ubaciti isto iptv kao jedan
strim ... ili u iptv kad hocu multi channel iz sport addona strimove da mogu ubaciti".

A grid holds one channel of each IPTV list at most (a list is a provider, and a provider serves its connections only:
"bitno je da se drzimo ... 1 konekcija ako provajder tako trazi da ne zaobilazimo") - with several lists, a channel of
each; its other tiles are streams of the sport add-ons - each its own server, its own connection: a live event of their
catalogs (resources/lib/sports.py, as the Sport screen lists them), then one of its streams. A tile's row: {'label',
'mv_source': {'address', 'name'}} - the address as the add-on gives it (its headers after '|'), never logged.

"multiview se presporo otvara ... nekako brze da fetcha addone": the live events are got behind the screen as soon as
the player is up (warm()), from the add-ons' kept catalog pages (even old ones - refreshed behind) - the picker opens at
once; only a catalog with nothing kept is asked then, all of them side by side."""
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import xbmcgui

from .play_jobs import plain_label

FRESH = 120                     # seconds the live events got behind the screen count as now
ASK_TIMEOUT = 6                 # seconds a catalog with nothing kept may take
_EVENTS = {'at': 0.0, 'events': [], 'busy': False}


def is_stream(row):
    return bool((row or {}).get('mv_source'))


def iptv_rows(rows):
    return [r for r in rows if not is_stream(r)]


def lists_in(rows):
    """The IPTV lists (Kodi's PVR clients) the grid's IPTV channels are of."""
    return {r.get('clientid') for r in iptv_rows(rows) if r.get('clientid') is not None}


def live_events(ask=True):
    """The sport add-ons' live events, each once: their kept catalog pages (old ones too); a catalog with nothing kept
    asked - all such side by side (``ask``) - the others refreshed for the next time."""
    from resources.lib import sports
    pairs = sports.catalogs()
    pages, missing, stale = {}, [], []
    for n, (provider, catalog) in enumerate(pairs):
        metas, fresh = sports.cached_page(provider, catalog)
        if metas is None:
            missing.append(n)
        else:
            pages[n] = metas
            if not fresh:
                stale.append(n)
    todo = missing if ask else []
    if todo or stale:
        pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix='MegaNexusMultiViewEvents')
        futures = {pool.submit(sports.load_page, pairs[n][0], pairs[n][1], ASK_TIMEOUT): n for n in todo + stale}
        for future, n in futures.items():
            if n in todo:                            # waited for (nothing kept); the old ones refresh on their own
                try:
                    pages[n] = future.result(timeout=ASK_TIMEOUT + 2)
                except Exception:
                    pages[n] = []
        pool.shutdown(wait=False)
    out, seen = [], set()
    for n in sorted(pages):
        provider, catalog = pairs[n]
        for meta in pages[n] or []:
            card = sports.card(provider, catalog, meta)
            if card['live'] and card['id'] not in seen:
                seen.add(card['id'])
                out.append(card)
    return out


def warm():
    """The live events got behind the screen (the player is up: MultiView's picker will open at once)."""
    if _EVENTS['busy'] or time.monotonic() - _EVENTS['at'] < FRESH:
        return
    _EVENTS['busy'] = True

    def work():
        try:
            _EVENTS['events'], _EVENTS['at'] = live_events(), time.monotonic()
        except Exception:
            pass
        finally:
            _EVENTS['busy'] = False
    threading.Thread(target=work, daemon=True, name='MegaNexusMultiViewWarm').start()


def events_now():
    """The live events - the ones got behind the screen when they are recent, else got now (said on the screen)."""
    if time.monotonic() - _EVENTS['at'] < FRESH and _EVENTS['events']:
        return _EVENTS['events']
    xbmcgui.Dialog().notification('MultiView', 'Looking for live sport streams...', time=3000)
    _EVENTS['events'], _EVENTS['at'] = live_events(), time.monotonic()
    return _EVENTS['events']


def stream_row(event, stream, streams=()):
    """A MultiView tile's row for ``stream`` of ``event`` - ``streams``: all of the event's (a screen that plays the
    stream alone as its own has its others to choose from)."""
    return {'label': plain_label(event.get('title')) or 'Stream',
            'mv_source': {'address': stream['url'], 'name': plain_label(stream.get('label')) or ''}, 'sport_event': event.get('id'),
            'sport_streams': list(streams)}


def iptv_choices(rows):
    """[(client id, list name)] - the IPTV lists with no channel in the grid yet (Kodi's PVR clients that have channels)."""
    from .iptv import channels, rpc
    used = lists_in(rows)
    clients = {}
    for channel in channels('alltv') or []:
        client = channel.get('clientid')
        if client is not None and client not in used and client not in clients:
            clients[client] = ''
    if len(clients) > 1 or clients:
        for client in (rpc('PVR.GetClients', {}) or {}).get('clients') or []:
            if client.get('clientid') in clients:
                clients[client['clientid']] = plain_label(client.get('friendlyname') or client.get('addonname') or '')
    return [(client, name or 'IPTV') for client, name in clients.items()]


def pick_tile(rows, host, channel_rows, found, heading='MultiView: one more'):
    """One more tile for a grid of ``rows``: a channel of an IPTV list that has none in it yet, or a live sport stream
    - one list of both, opened at once (the live events got behind the screen) - its row, or None."""
    lists = iptv_choices(rows)
    events = events_now()
    items = [xbmcgui.ListItem('IPTV channel · %s' % name, 'A channel of this list (one per list)') for _, name in lists]
    items += [xbmcgui.ListItem(plain_label(e['title']), e.get('info') or e.get('addon') or 'Live') for e in events]
    if not items:
        xbmcgui.Dialog().notification('MultiView', 'No live sport stream and no other IPTV list now.', time=4000)
        return None
    chosen = xbmcgui.Dialog().select(heading, items, useDetails=True)
    if chosen < 0:
        return None
    if chosen < len(lists):
        client = lists[chosen][0]
        return host._mv_pick(channel_rows, found, 'MultiView: a channel of %s' % lists[chosen][1], only_client=client)
    return pick_stream(events[chosen - len(lists)])


def pick_stream(event):
    """One of ``event``'s streams (the only one at once) - its tile's row, or None."""
    from resources.lib import sports
    busy = xbmcgui.DialogProgressBG()
    busy.create('MultiView', 'Streams of %s...' % plain_label(event['title']))
    try:
        found = sports.streams(event)
    except Exception:
        found = []
    finally:
        busy.close()
    if not found:
        xbmcgui.Dialog().notification('MultiView', 'No stream of it answered.', time=4000)
        return None
    pick = 0 if len(found) == 1 else xbmcgui.Dialog().select(plain_label(event['title']),
                                                             [xbmcgui.ListItem(s['label'], s.get('detail') or '') for s in found], useDetails=True)
    return stream_row(event, found[pick], found) if pick >= 0 else None
