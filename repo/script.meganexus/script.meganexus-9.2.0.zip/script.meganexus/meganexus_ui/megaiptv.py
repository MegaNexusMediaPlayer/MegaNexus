# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaIPTV (idea, 2026-11-17): the HUB's IPTV app - MegaNexus' Home with an IPTV list's films and series in it.

"cilj je stvoriti iskustvo slicno ka IPTV DECK ... MegaIPTV"; "slazes kako ih iptv daje po grupama ... redove i pazi
da ne pomjesas filmove i serije ... nemoj kesirati to na disk ... samo svoj jedan izvor ... nema tu odaberi source".

"kad se ude u iptv prvo sto mora da ide su kanali i mini player preuzimamo iz Home da je puno veci ... da zadrzimo neki
nas stil sa ovim redom na vrhu ... plocicama".

The same screen as Home and the Plex app (meganexus_ui/server_app.py): its rows go round, the card under the cursor at
the top. Live TV is its home: a row each of the list's channel groups (Kodi's PVR, as meganexus_ui/iptv.py reads it),
each channel's card its logo, what is on and how far (review/make_channel_cards.py); the channel the cursor rests on
plays in the big video at the top (Home's), OK makes it full screen and Back comes back here. Movies and Series are each
their server's groups, a row a group, in the server's order (resources/lib/iptv_vod.py: asked when a row is, kept in
memory while the app is open); a series opens as its seasons, a row each. A film or an episode plays from the list
alone (the plugin's iptv_vod_play) - no source list. The top bar: Search · Live TV · Movies · Series · Settings · HUB.
"""
import json
import re
import time
import traceback
from urllib.parse import parse_qsl, quote, urlencode, urlsplit

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import home_data, iptv_vod, screen_guard
from resources.lib.theme import folder as theme_folder
from .home_window import ADDON, BACK, HUB_SETTLE_PLAIN, ROW_BASE, HomeWindow, to_player, wait_for_film
from .iptv import _folder
from .multiview_host import MV, MultiViewHost, MultiViewWindow, _playing_again  # noqa: F401  (MegaIPTV's MultiView)

ADDON_UI = xbmcaddon.Addon('script.meganexus')   # the windows' own add-on (the pickers' layouts)

KIND = 'megaiptv'
LIVE, MOVIES, SERIES, SHOW, SEARCH = 'app', 'app:movies', 'app:series', 'app:show:', 'app:search'
XML = 'meganexus_home.xml'
LIVE_BUTTON, MOVIES_BUTTON, SERIES_BUTTON, OPTIONS_BUTTON, HUB_BUTTON = 101, 106, 115, 107, 108   # Options: Home's Settings
GUIDE_BUTTON = 114                         # Watch Party's button on Home: the Guide here (review/make_icon_bar.py)
GUIDE_OPEN = 'meganexus.iptv.guide'        # Window(Home): Kodi's guide is MegaIPTV's (its Back keeps the picture full screen)
ENTRY_WAIT = 3.0                           # seconds the way in waits for the last channel's card before asking Kodi's PVR
LAST = 'meganexus_iptv_last_unique'   # the channel watched last (meganexus_ui/iptv.py keeps it the same way, in its add-on)
RECENT = 'meganexus_iptv_recent'      # the channels played last, newest first (Live TV's first row: Last played)
RECENT_ROW = 12
ROWS = 'meganexus_iptv_rows'          # the rows' order and the hidden ones, per kind (Options > Channel / Movie / Series rows)


def _iptv_settings():
    from .iptv import ADDON as iptv_addon
    return iptv_addon
CHANNEL = 'channel'          # a Live TV row's cards (review/make_channel_cards.py)
PLAY = 'plugin://plugin.video.meganexus/?'


def _shelf(title, job):
    return {'title': title, 'rows': [home_data.placeholder(' ', '')], 'megaiptv_job': job}


def _note(title, plot):
    return {'title': 'MegaIPTV', 'rows': [home_data.placeholder(title, plot)]}


def _setting_json(key):
    try:
        value = json.loads(_iptv_settings().getSetting(key) or 'null')
    except ValueError:
        value = None
    return value


def played(unique):
    """``unique`` (client:unique id) played: the channel watched last, first of Last played."""
    if not unique:
        return
    settings = _iptv_settings()
    settings.setSetting(LAST, unique)
    before = _setting_json(RECENT)
    before = [u for u in (before if isinstance(before, list) else []) if isinstance(u, str) and u != unique]
    settings.setSetting(RECENT, json.dumps(([unique] + before)[:RECENT_ROW]))


def arranged(scope, rows):
    """``rows`` [(id, ...)] as the person put them (Options > ... rows): the hidden left out, the ones given an order in it
    first, every other one after them in the server's order (row_order.py)."""
    from . import row_order
    return row_order.arranged(rows, (_setting_json(ROWS) or {}).get(scope))


def live_shelves():
    """Live TV: Last played, then a row each of the channel groups (Kodi's own 'All channels' only when there is no
    other) as Options > Channel rows put them ("u channels moramo imati na vrhu red last played")."""
    from .iptv import groups, plain_label, pvr_ready
    if not pvr_ready():
        return [_note('Live TV is still loading', 'The channels come in a moment - Back, and open MegaIPTV again.')]
    found = [g for g in groups() if g.get('channelgroupid') != 'alltv'] or groups()
    found = [g for _, g in arranged('live', [(str(g['channelgroupid']), g) for g in found])]
    recent = _setting_json(RECENT)
    last = [dict(_shelf('Last played', ('recent',)), shape=CHANNEL)] if isinstance(recent, list) and recent else []
    return last + [dict(_shelf(plain_label(g.get('label')) or 'Channels', ('channels', g['channelgroupid'])), shape=CHANNEL) for g in found]


def shelves(view, query=''):
    """Every row of one view, none asked for yet (the window's workers load them)."""
    if view == LIVE:
        return live_shelves()
    lists = iptv_vod.lists(_folder())
    if not lists:
        return [_note('No IPTV list with films and series', 'Settings > IPTV: an Xtream list shows its films and series here.')]
    several = len(lists) > 1
    named = lambda row, title: ('%s · %s' % (row.get('name') or 'IPTV', title)) if several else title
    if view == SEARCH:
        return [_shelf(named(row, title), ('find', row['id'], kind, query))
                for row in lists for kind, title in ((iptv_vod.MOVIE, 'Movies'), (iptv_vod.SERIES, 'Series'))]
    if view.startswith(SHOW):
        list_id, series_id, name = json.loads(view[len(SHOW):])[:3]
        found = {row['id']: row for row in lists}
        try:
            numbers = list(iptv_vod.seasons(found[list_id], series_id)) if list_id in found else []
        except Exception:
            xbmc.log('[MegaNexus] MegaIPTV: the seasons did not load: %s' % traceback.format_exc(limit=1).strip().splitlines()[-1],
                     xbmc.LOGWARNING)
            return [_note('The server did not answer', 'Back, and open the series again.')]
        # Home's landscape episodes ("landscape velicina epizoda mora biti velika kao na Home")
        return ([dict(_shelf('%s · Season %d' % (name, n), ('season', list_id, series_id, n)), shape='landscape') for n in numbers]
                or [_note('No episodes', 'The server lists no episodes of %s.' % name)])
    kind = iptv_vod.SERIES if view == SERIES else iptv_vod.MOVIE
    going = continue_cards(kind)
    out = [{'title': 'Continue Watching', 'rows': going}] if going else []
    for row in lists:
        try:
            out += [_shelf(named(row, title), ('titles', row['id'], kind, group))
                    for group, title in arranged('%s:%s' % (kind, row['id']), iptv_vod.groups(row, kind))]
        except Exception:
            xbmc.log('[MegaNexus] MegaIPTV: the %s groups of list %s did not load: %s'
                     % (kind, row.get('id'), traceback.format_exc(limit=1).strip().splitlines()[-1]), xbmc.LOGWARNING)
            out.append(_note('%s did not answer' % (row.get('name') or 'The IPTV server'), 'Back, and open MegaIPTV again.'))
    return out or [_note('Nothing here', 'The IPTV server lists no %s.' % ('series' if kind == iptv_vod.SERIES else 'films'))]


def _act(fn):
    """A settings page row's action that shows nothing after (the page stays)."""
    def act(key):
        fn(key)
    return act


def options():
    """MegaIPTV's Options (Home's Settings place): its groups, the guide's settings, its rows - which and in what order
    ("treba organizaciju rowsa u opcijama za kanale serije i filmove") - then the whole IPTV setup (iptv.configure)."""
    from . import settings_page as page
    from .iptv import _lists, epg_page, regroup
    first = []
    if any(r.get('live') for r in _lists()):
        first += [('groups', page.item('Groups', 'Countries, sport, films...'), _act(lambda key: regroup())),
                  ('epg', page.item('EPG options', 'OK, days back and ahead'), lambda key: epg_page()),
                  ('rows:live', page.item('Channel rows', 'Which, in what order'), lambda key: rows_page('live', 'Channel rows'))]
    lists = iptv_vod.lists(_folder())
    for row in lists:
        name = (' · %s' % (row.get('name') or 'IPTV')) if len(lists) > 1 else ''
        for kind, word in ((iptv_vod.MOVIE, 'Movie rows'), (iptv_vod.SERIES, 'Series rows')):
            scope = '%s:%s' % (kind, row['id'])
            first.append(('rows:' + scope, page.item(word + name, 'Which, in what order'),
                          lambda key, scope=scope, title=word + name: rows_page(scope, title)))
    return first


def _scope_rows(scope):
    """[(id, name)] of the rows of ``scope`` ('live' or '<kind>:<list id>') as Kodi / the server has them."""
    if scope == 'live':
        from .iptv import groups, plain_label
        return [(str(g['channelgroupid']), plain_label(g.get('label')) or 'Channels') for g in groups() if g.get('channelgroupid') != 'alltv']
    kind, list_id = scope.split(':', 1)
    row = {r['id']: r for r in iptv_vod.lists(_folder())}.get(list_id)
    return [(str(gid), title) for gid, title in iptv_vod.groups(row, kind)] if row else []


def rows_page(scope, title):
    """Every row of ``scope`` in its order, shown or hidden; a row: hide / show it, up, down, to the top (row_order.py)."""
    from . import row_order

    def load():
        return dict(((_setting_json(ROWS) or {}).get(scope) or {}))

    def save(kept):
        every = _setting_json(ROWS) or {}
        every[scope] = kept
        _iptv_settings().setSetting(ROWS, json.dumps(every))
    return row_order.page(title, lambda: _scope_rows(scope), load, save)


def continue_cards(kind):
    """MegaIPTV's own Continue Watching (resources/lib/app_continue.py: what it played stays out of MegaNexus' - "filmovi
    serije i kanali nesmiju ici u meganexus continue watching nego samo u IPTV"): its films, or its series (each its newest
    episode), not finished, the newest first; OK plays on from where it was left."""
    from resources.lib import app_continue
    from resources.lib.meganexus.paths import watched_percent
    cards, seen = [], set()
    for row in app_continue.recent(KIND):
        if (row.get('media_type') == 'movie') != (kind == iptv_vod.MOVIE) or row.get('event_type') == 'watched' \
                or float(row.get('percent') or 0) >= watched_percent() or not row.get(app_continue.PLAY):
            continue
        show = row.get('show_title') if kind == iptv_vod.SERIES else ''
        if (show or row.get('canonical_id')) in seen:
            continue
        seen.add(show or row.get('canonical_id'))
        asked = dict(parse_qsl(urlsplit(row[app_continue.PLAY]).query))
        percent = int(float(row.get('percent') or 0))
        left = max(0, int(float(row.get('duration') or 0) - float(row.get('position') or 0))) // 60
        title = ('%s · S%s E%s' % (show, row.get('season'), row.get('episode'))) if show else (row.get('title') or 'MegaIPTV')
        card = {'title': title, 'subtitle': '', 'plot': '', 'poster': row.get('poster') or '', 'fanart': row.get('background') or '',
                'landscape': '', 'clearlogo': '', 'path': '', 'is_folder': False, 'percent_value': percent,
                'meta_line': '%d%% watched%s' % (percent, ('  |  %d min left' % left) if left else ''),
                'server_play': row[app_continue.PLAY] + '&' + urlencode({'resume': int(float(row.get('position') or 0))})}
        if kind == iptv_vod.MOVIE:       # MegaNexus' details on it, as on its group's card (_details_tick)
            card['megaiptv_title'] = [asked.get('list_id'), iptv_vod.MOVIE, asked.get('item_id'), row.get('title') or '', asked.get('year') or '']
        cards.append(card)
    return cards


def _meta(title):
    return '  |  '.join(x for x in (title.get('year'), title.get('genre'), ('★ %.1f' % title['rating']) if title.get('rating') else '') if x)


def card(list_row, title):
    """A film's card plays it; a series' opens its seasons (app_open)."""
    base = {'title': title['name'], 'subtitle': title.get('year') or '', 'plot': title.get('plot') or '', 'poster': title.get('poster') or '',
            'fanart': title.get('backdrop') or '', 'landscape': '', 'clearlogo': '', 'meta_line': _meta(title), 'path': '', 'is_folder': False,
            'megaiptv_title': [list_row['id'], title['kind'], title['id'], title['name'], title.get('year') or '']}
    if title['kind'] == iptv_vod.SERIES:
        base['app_open'] = [list_row['id'], title['id'], title['name'], title.get('poster') or '', title.get('backdrop') or '']
        return base
    base['server_play'] = PLAY + urlencode({'action': 'iptv_vod_play', 'list_id': list_row['id'], 'kind': iptv_vod.MOVIE,
                                            'item_id': title['id'], 'ext': title.get('ext') or '', 'title': title['name'],
                                            'poster': title.get('poster') or '', 'year': title.get('year') or ''})
    return base


# ---- MegaNexus' own details for an IPTV title ("nema logo za filmove nema ocjena kao na Home ... artwork neradi
# autotraileri nerade kod iptv"): asked when the cursor comes to it (and for the next few), kept while the app is open
AHEAD = 3                    # the titles after the one the cursor is on, asked too


def _year_near(meta, year):
    found = str((meta or {}).get('releaseInfo') or (meta or {}).get('year') or '')[:4]
    return not year or not found.isdigit() or abs(int(found) - int(year)) <= 1


def _searched(kind, name, year):
    """A series (or a film the server gave no id for) in the metadata add-ons' search: the one of that name and year."""
    from resources.lib import backend_api, home_data, search_catalogs
    from resources.lib.iptv_lists import norm
    from resources.lib.meganexus.addon_wire import fetch_catalog
    from resources.lib.metadata_providers import catalog_sources
    want = norm(name)
    if not want:
        return None
    for source in catalog_sources():
        for catalog in search_catalogs.entries(source):
            if home_data.search_kind(catalog) != kind:
                continue
            try:
                found = (fetch_catalog(source, catalog['type'], catalog['id'], extra={'search': want}, timeout_override=5, retry=False) or {}).get('metas') or []
            except Exception:
                continue
            for meta in found[:10]:
                if isinstance(meta, dict) and meta.get('id') and norm(meta.get('name')) == want and _year_near(meta, year):
                    try:
                        return backend_api.metadata(kind, str(meta['id']), timeout=6, title=meta.get('name')) or meta
                    except Exception:
                        return meta
    return None


def title_meta(list_row, title):
    """MegaNexus' details of an IPTV film or series (pictures, logo, ratings, trailer) - a film by the TMDB id its server
    gives, else by its name and year - or None."""
    from resources.lib import backend_api
    if title['kind'] == iptv_vod.MOVIE:
        tmdb = iptv_vod.movie_info(list_row, title['id']).get('tmdb')
        if tmdb:
            try:
                return backend_api.metadata('movie', 'tmdb:%s' % tmdb, timeout=6, title=title['name'])
            except Exception:
                pass
    return _searched(title['kind'], title['name'], title.get('year'))


def with_details(card_row, meta):
    """The IPTV card as Home's card of ``meta`` - still played (or opened) from the list alone."""
    from resources.lib import home_data
    found = home_data.media_card(meta, media_type='series' if card_row.get('app_open') else 'movie')
    for key in ('server_play', 'app_open', 'megaiptv_title'):
        if key in card_row:
            found[key] = card_row[key]
    found['poster'] = found.get('poster') or card_row.get('poster') or ''
    found['is_folder'] = False
    return found


def episode_name(raw, show, number):
    """An episode's own name: servers often give "<series> - S01E01 - <name>" (or only the first two); the series' name
    and the S01E01 / 1x01 mark go, and an episode left without a name is "Episode N"."""
    text = str(raw or '')
    names = {str(show or '').strip(), re.sub(r'\[[^\]]*\]|\([^)]*\)|\|[^|]*\|', ' ', str(show or '')).strip()}
    for name in sorted((n for n in names if n), key=len, reverse=True):
        text = re.sub(re.escape(name), ' ', text, flags=re.I)
    text = re.sub(r'\bS\d{1,2}\s*E\d{1,4}\b|\b\d{1,2}x\d{1,4}\b', ' ', text, flags=re.I)
    text = ' '.join(text.split()).strip(' -–—|:.·')
    return text or 'Episode %d' % number


def episode_card(list_row, show, episode):
    name = episode_name(episode.get('name'), show[2], episode['episode'])
    wide = episode.get('poster') or show[4] or show[3]          # its still, else the series' wide picture, else its poster
    return {'title': name, 'subtitle': 'S%d E%d' % (episode['season'], episode['episode']), 'plot': episode.get('plot') or '',
            'poster': wide, 'fanart': show[4] or episode.get('poster') or '', 'landscape': wide,
            'clearlogo': '', 'meta_line': '%s  |  Season %d' % (show[2], episode['season']), 'path': '', 'is_folder': False,
            'server_play': PLAY + urlencode({'action': 'iptv_vod_play', 'list_id': list_row['id'], 'kind': iptv_vod.SERIES,
                                             'item_id': episode['id'], 'ext': episode.get('ext') or '', 'title': name,
                                             'poster': episode.get('poster') or show[3], 'season': episode['season'],
                                             'episode': episode['episode'], 'show': show[2]})}


def _clock(value):
    from .iptv import epg_time
    when = epg_time(value)
    return when.strftime('%H:%M') if when else ''


def channel_card(channel):
    """A channel's card: its logo, what is on now (its picture faint behind) and how far, what comes next."""
    from .iptv import plain_label
    now, after = channel.get('broadcastnow') or {}, channel.get('broadcastnext') or {}
    name = plain_label(channel.get('label')) or 'Channel'
    on_now = ('%s  %s' % (_clock(now.get('starttime')), now.get('title'))).strip() if now.get('title') else ''
    line = '  |  '.join(x for x in ('LIVE', ('%s - %s  %s' % (_clock(now.get('starttime')), _clock(now.get('endtime')), now['title'])) if now.get('title') else '',
                                    ('Next %s  %s' % (_clock(after.get('starttime')), after['title'])) if after.get('title') else '') if x)
    return {'title': name, 'subtitle': '', 'plot': now.get('plot') or '', 'poster': channel.get('icon') or '',
            'fanart': now.get('thumbnail') or '', 'landscape': '', 'clearlogo': '', 'meta_line': line, 'now': on_now,
            'percent_value': int(now.get('progresspercentage') or 0), 'path': '', 'is_folder': False,
            'channel': str(channel['channelid']), 'unique': '%s:%s' % (channel.get('clientid', ''), channel.get('uniqueid', channel['channelid'])),
            'app_open': ['live', channel['channelid'], name]}


_PICTURE_HOSTS = {}          # a guide's picture host -> it answers with pictures (asked once while the app is open)


def _pictures_work(url):
    """A guide's programme pictures come from a host that gives them - one asked once (some lists' guides point
    at pictures their host refuses: the card then shows the channel's own picture and its logo whole)."""
    from urllib.parse import urlsplit
    from urllib.request import Request, urlopen
    host = urlsplit(url).netloc
    if not host:
        return False
    if host not in _PICTURE_HOSTS:
        try:
            with urlopen(Request(url, headers={'User-Agent': 'Kodi', 'Range': 'bytes=0-255'}), timeout=6) as reply:
                _PICTURE_HOSTS[host] = reply.status in (200, 206) and (reply.headers.get('Content-Type') or '').startswith('image/')
        except Exception:
            _PICTURE_HOSTS[host] = False
    return _PICTURE_HOSTS[host]


CHANNEL_PROPERTIES = ['icon', 'channelnumber', 'subchannelnumber', 'uniqueid', 'clientid', 'broadcastnow', 'broadcastnext']


def channels_of(group):
    from .iptv import rpc
    reply = rpc('PVR.GetChannels', {'channelgroupid': group, 'properties': CHANNEL_PROPERTIES}) or {}
    rows = sorted(reply.get('channels') or [], key=lambda r: (int(r.get('channelnumber') or 0), int(r.get('subchannelnumber') or 0)))
    return [dict(channel_card(r), group=group) for r in _polished(rows)]


def recent_cards(recent):
    """Last played - only those channels: every channel's number without its programmes (a light list), then each
    played one's own details. Not every channel's programmes (the Cube: the top row waited for 708 of them)."""
    from .iptv import channel_key, rpc
    light = (rpc('PVR.GetChannels', {'channelgroupid': 'alltv', 'properties': ['uniqueid', 'clientid']}) or {}).get('channels') or []
    ids = {channel_key(r): r['channelid'] for r in light}
    rows = []
    for unique in recent:
        if unique in ids:
            found = (rpc('PVR.GetChannelDetails', {'channelid': ids[unique], 'properties': CHANNEL_PROPERTIES}) or {}).get('channeldetails')
            if found:
                rows.append(found)
    return [dict(channel_card(r), group='alltv') for r in _polished(rows)]


def _polished(rows):
    """A programme's picture that does not load goes; a channel without a logo gets the free tv-logos project's."""
    for r in rows:
        now = r.get('broadcastnow') or {}
        if now.get('thumbnail') and not _pictures_work(now['thumbnail']):
            now['thumbnail'] = ''
    if any(not r.get('icon') for r in rows):
        # a channel without a logo: the free tv-logos project's, by its name (resources/lib/channel_logos.py)
        from resources.lib import channel_logos
        from .iptv import groups, plain_label
        hints = [plain_label(g.get('label')) for g in groups()]
        for r in rows:
            if not r.get('icon'):
                r['icon'] = channel_logos.find(plain_label(r.get('label')), hints)
    return rows


def rows_of(job, show=None):
    """The cards of one row (Exception: the server did not answer); ``show``: the series a season row is of."""
    if job[0] == 'channels':
        return channels_of(job[1])
    if job[0] == 'recent':                       # Last played: in the order played
        return recent_cards(_setting_json(RECENT) or [])
    found = {row['id']: row for row in iptv_vod.lists(_folder())}
    list_row = found.get(job[1])
    if list_row is None:
        return []
    if job[0] == 'titles':
        return [card(list_row, t) for t in iptv_vod.titles(list_row, job[2], job[3])]
    if job[0] == 'find':
        return [card(list_row, t) for t in iptv_vod.find(list_row, job[2], job[3])]
    return [episode_card(list_row, show, e) for e in iptv_vod.seasons(list_row, job[2]).get(job[3], [])]   # 'season'


def _channel_card(unique):
    """A card for the channel of ``unique`` (client:unique id, as the last one is kept) from all of Kodi's channels, or None."""
    from .iptv import channel_key, channels, plain_label
    try:
        row = next((r for r in channels('alltv') if channel_key(r) == unique), None)
    except Exception:
        row = None
    if row is None:
        return None
    return {'app_open': ['live', row['channelid'], plain_label(row.get('label'))], 'unique': unique, 'group': 'alltv'}


class MegaIPTVWindow(MultiViewHost, HomeWindow):
    """Home, with an IPTV list's films and series in it."""

    @staticmethod
    def _identity(row):
        """An IPTV title is the same card before and after MegaNexus' details come (its list, kind and id on the server):
        with Home's identity - the TMDB / IMDb id it gets - the card under the cursor changed identity and Home kept the
        change back until the cursor left the row (no poster, logo or ratings while one stood on it)."""
        title = row.get('megaiptv_title')
        if title:
            return json.dumps(['megaiptv'] + [str(x) for x in title[:3]], ensure_ascii=False)
        return HomeWindow._identity(row)

    def onInit(self):
        self.setProperty('meganexus.app', KIND)             # its logo and top (review/make_app_home.py)
        super().onInit()
        try:
            self.getControl(LIVE_BUTTON).setLabel('Live TV')
            self.getControl(MOVIES_BUTTON).setLabel('Movies')
            self.getControl(SERIES_BUTTON).setLabel('Series')
        except Exception:
            pass

    def drain_updates(self):
        super().drain_updates()
        if not self._closed:
            self.setProperty('meganexus.app.home_top', '' if self._bucket == LIVE else '1')   # films and series: Home's top
            self._hero_tick()
            self._preview_tick()
            self._video_shown()
            self._details_tick()

    def _details_tick(self):
        """The card under the cursor and the next few: MegaNexus' own details, once each, behind the screen."""
        control_id, pos, _ = self._selection()
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves) or self._bucket == LIVE or self._pool is None:
            return
        rows = self._shelves[index].get('rows') or []
        asked = getattr(self, '_megaiptv_asked', None)
        if asked is None:                         # (a Kodi window's __dict__ is not a plain dict: setdefault gave None)
            asked = self._megaiptv_asked = set()
        for at in range(max(0, pos), min(len(rows), pos + 1 + AHEAD)):
            which = rows[at].get('megaiptv_title')
            if not which or rows[at].get('target') or tuple(which[:3]) in asked:
                continue
            asked.add(tuple(which[:3]))
            self._pool.submit(self._details, index, tuple(which[:3]), self._generation)

    def _details(self, index, which, generation):
        found = {row['id']: row for row in iptv_vod.lists(_folder())}
        list_id, kind, title_id = which
        shelf = self._shelves[index] if 0 <= index < len(self._shelves) else {}
        rows = list(shelf.get('rows') or [])
        at = next((i for i, c in enumerate(rows) if tuple((c.get('megaiptv_title') or [])[:3]) == which), None)
        if at is None or list_id not in found:
            return
        name, year = rows[at]['megaiptv_title'][3:5]
        try:
            meta = title_meta(found[list_id], {'kind': kind, 'id': title_id, 'name': name, 'year': year})
        except Exception:
            meta = None
        if not meta or self._closed or generation != self._generation:
            return
        rows = list(self._shelves[index].get('rows') or [])
        if at < len(rows) and tuple((rows[at].get('megaiptv_title') or [])[:3]) == which:
            rows[at] = with_details(rows[at], meta)
            self._updates.put((generation, index, rows, None, self._shelves[index].get('_ring_g')))

    # ---- the channel at the top ---------------------------------------------------------------
    def _cards(self):
        for shelf in self._shelves:
            for card_row in shelf.get('rows') or []:
                yield card_row

    def _preview_tick(self):
        """On the way in, the channel watched last plays at the top by itself (once its row is there) - after that only
        the one OK is pressed on ("nesmi stalno sam kad dojem na poster da krene kanal osim na ulazu zadnji")."""
        if getattr(self, '_entry_done', False) or self._bucket != LIVE:
            return
        last = _iptv_settings().getSetting(LAST)
        found = next((c for c in self._cards() if last and c.get('unique') == last), None)
        waited = time.monotonic() - getattr(self, '_opened_at', 0) >= ENTRY_WAIT
        if found is None and not waited and not all(shelf.get('_loaded') for shelf in self._shelves):
            return                            # its card may come with its row (going round, some rows never load here)
        self._entry_done = True
        from .iptv import _free_for_channel, current_id
        if found is None and last:
            found = _channel_card(last)       # a group whose row is not drawn (further down, going round): Kodi's PVR has it
        if found is None:
            return
        self._cursor_to_channel(found['app_open'][1])   # as the stable IPTV selected the last channel
        if xbmc.getCondVisibility('Pvr.IsPlayingTV') and current_id() == found['app_open'][1]:
            self._preview_of = found['app_open'][1]          # it plays already (back from full screen, the app opened again): kept, not restarted
            self.setProperty('meganexus.app.playing', str(self._preview_of))
        elif _free_for_channel():
            self._play_channel(found)

    def _cursor_to_channel(self, channel):
        """The cursor on ``channel``'s card, its row where the rows stand (the top bar keeps the cursor: Live TV chosen there)."""
        spot = next(((i, at) for i, shelf in enumerate(self._shelves) for at, c in enumerate(shelf.get('rows') or [])
                     if (c.get('app_open') or [None, None])[:2] == ['live', channel]), None)
        if spot is None:
            return
        try:
            self.getControl(ROW_BASE + spot[0]).selectItem(spot[1])
            if self.getFocusId() >= ROW_BASE:
                self.setFocusId(ROW_BASE + spot[0])
        except Exception:
            pass

    def _play_channel(self, card_row):
        """The channel of ``card_row`` in the big video at the top (Kodi's player, windowed)."""
        from .iptv import keep_windowed, open_preview
        if not getattr(self, '_windowed', False):
            keep_windowed()
            self._windowed = True
        channel = card_row['app_open'][1]
        before = getattr(self, '_preview_of', None)
        if before and before != channel:          # the player's Last channels, newest first
            self._recent = [before] + [c for c in getattr(self, '_recent', []) if c not in (before, channel)][:4]
        self._group = card_row.get('group', getattr(self, '_group', 'alltv'))
        self._preview_of = channel
        self.setProperty('meganexus.app.video', '')
        self.setProperty('meganexus.app.playing', str(channel))       # its card's play mark, OK · Full screen
        try:
            open_preview(channel)
        except Exception as exc:
            self._preview_of = None
            self.setProperty('meganexus.app.playing', '')
            xbmc.log('[MegaNexus] MegaIPTV: the channel did not start: %s' % str(exc)[:120], xbmc.LOGWARNING)
            return
        played(card_row.get('unique') or '')

    def _video_shown(self):
        if getattr(self, '_preview_of', None) and xbmc.getCondVisibility('Player.HasVideo'):
            self.setProperty('meganexus.app.video', '1')

    def _channel_ok(self, card_row):
        """OK on a channel: it plays at the top; OK again on the one that plays makes it full screen."""
        if card_row['app_open'][1] != getattr(self, '_preview_of', None) or not xbmc.getCondVisibility('Player.HasVideo'):
            return self._play_channel(card_row)
        self._full_screen()

    def _full_screen(self):
        """Kodi's player for the channel at the top - the same playback, no new start. This screen steps aside (Kodi
        opens no window over a dialog) and comes back when the player is left (_player)."""
        from .home_trailers import view_mode
        view_mode('normal')
        monitor = xbmc.Monitor()
        self._child_active = True
        self._restore_focus = self.getFocusId()
        started = self._preview_of
        try:
            self.close_into_player()
            self._player(monitor)
        finally:
            if not self._dialog_closed and not monitor.abortRequested():
                self.show_ready()                  # back as the YouTube app's screen comes back (the cursor where it was)
                self._back_to_live()
                if self._preview_of != started:    # another channel chosen in the player: the cursor on the one that plays
                    self._cursor_to_channel(self._preview_of)
            self._child_active = False

    def _player(self, monitor):
        """Kodi's player as the stable IPTV's ("izgled glavnog playera mora biti kao stari sa svim funkcijama") - its
        buttons (review/make_iptv_osd.py, Window(Home) meganexus.iptv.osd): Channels first - the channels as small
        tiles, a group at a time, over the picture - Previous / Next channel, Last channels, Catch-up, From start.
        Returns once the player is left (or nothing plays). A programme Kodi's PVR plays from the archive (the guide's,
        Kodi's own buttons') becomes its file from the Xtream server the moment it starts (_guides_archive: it seeks) -
        the guide goes full screen a moment BEFORE it starts the programme ("kod catchup kad se otvori nema opet progres
        bara": looked for only on the way in, the live channel still played)."""
        from .iptv import OSD_COMMAND, SWITCH_GRACE, SWITCH_SETTLED, _moving
        from .player_osd import player_buttons, switched
        home = xbmcgui.Window(10000)
        home.clearProperty(OSD_COMMAND)
        home.setProperty('meganexus.iptv.open', '1')
        try:
            self._osd_state()
            if getattr(self, '_mv_ok', False):                # MultiView's picker ready before its button is pressed
                from .multiview_sources import warm
                warm()
            seen, start, osd, switching, before, tried = False, time.monotonic(), None, 0.0, '', set()
            tiles_at = 0.0
            while not monitor.waitForAbort(.05):
                osd = player_buttons(osd)
                if getattr(self, '_grid', None) is not None and time.monotonic() >= tiles_at:
                    tiles_at = time.monotonic() + .5
                    self._mv_tiles()
                path = xbmc.getInfoLabel('Player.Filenameandpath')
                if path.startswith('pvr://guide/') and path not in tried:
                    tried.add(path)
                    if self._guides_archive():          # the picture stops for the change, as after Channels
                        switching, before = time.monotonic() + SWITCH_GRACE, path
                command = home.getProperty(OSD_COMMAND)
                if command:
                    home.clearProperty(OSD_COMMAND)
                    before = xbmc.getInfoLabel('Player.FilenameAndPath')
                    if self._in_player(command):
                        switching = time.monotonic() + SWITCH_GRACE
                full = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                if time.monotonic() < switching and switched(before) and _moving(SWITCH_SETTLED):
                    switching = 0.0
                if time.monotonic() < switching:
                    if not full and xbmc.Player().isPlayingVideo():
                        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                    continue
                if full:
                    seen = True
                if (seen and not full) or not xbmc.Player().isPlayingVideo() or (not seen and time.monotonic() - start > 5):
                    break
        finally:
            home.clearProperty('meganexus.iptv.open')
            home.clearProperty(OSD_COMMAND)

    def _channel_rows(self, group):
        from .iptv import channels
        return channels(group) or []

    def _playing_row(self, rows):
        """The PVR row of the channel that plays: in ``rows`` (its group's), else among all of Kodi's channels - the guide
        may have switched to one of another group (its name and archive were then missed: catch-up through Kodi's PVR,
        which does not seek)."""
        found = next((r for r in rows if r['channelid'] == self._preview_of), None)
        return found or next((r for r in self._channel_rows('alltv') if r['channelid'] == self._preview_of), None)

    def _follow(self, channel):
        """``channel`` plays (the guide switched to it): its group - the row its card is in - is the player's group."""
        self._preview_of = channel
        card = next((c for c in self._cards() if (c.get('app_open') or [None, None])[:2] == ['live', channel]
                     and c.get('group') not in (None, 'alltv')), None)
        if card is not None:
            self._group = card['group']

    def _osd_state(self):
        """What the player's IPTV buttons can do for the channel that plays."""
        from .iptv import broadcasts
        home = xbmcgui.Window(10000)
        row = self._playing_row(self._channel_rows(getattr(self, '_group', 'alltv'))) or {}
        now = None
        try:
            now = next((b for b in broadcasts(self._preview_of) if b.get('isactive')), None) if row.get('hasarchive') else None
        except Exception:
            pass
        self._now_programme = now
        home.setProperty('meganexus.iptv.has_recent', '1' if getattr(self, '_recent', []) else '')
        if getattr(self, '_mv_ok', None) is None:
            from .multiview import available
            self._mv_ok = available()
        home.setProperty('meganexus.iptv.can_multiview', '1' if self._mv_ok else '')
        home.setProperty('meganexus.iptv.has_archive', '1' if row.get('hasarchive') else '')
        home.setProperty('meganexus.iptv.has_restart', '1' if now and now.get('broadcastid') else '')

    def _switch(self, row):
        """Another channel in Kodi's player (it stays full screen)."""
        from .iptv import item_for, rpc
        before = self._preview_of
        if before and before != row['channelid']:
            self._recent = [before] + [c for c in getattr(self, '_recent', []) if c not in (before, row['channelid'])][:4]
        self._preview_of, self._archive = row['channelid'], False
        self.setProperty('meganexus.app.playing', str(row['channelid']))
        played('%s:%s' % (row.get('clientid', ''), row.get('uniqueid', row['channelid'])))
        rpc('Player.Open', {'item': item_for(row['channelid'])})
        self._osd_state()
        return True

    def _in_player(self, command):
        """One of the player's IPTV buttons; True once something new plays."""
        from .iptv import PlayerPicker, archive, groups, item_for, plain_label, rpc
        group = getattr(self, '_group', 'alltv')
        rows = self._channel_rows(group)
        if command in ('previous', 'next'):
            if not rows:
                return False
            index = next((i for i, r in enumerate(rows) if r['channelid'] == self._preview_of), -1)
            return self._switch(rows[(index + (-1 if command == 'previous' else 1)) % len(rows)])
        if command == 'restart':
            now = getattr(self, '_now_programme', None)
            return bool(now) and self._from_archive(now, rows)
        found = groups()
        if command == 'multiview':
            return self._multiview(rows, found)
        if command.startswith('mv:'):
            return self._on_grid(command, rows, found)
        if command == 'catchup':
            try:
                kwargs = dict(mode='box', rows=self._schedule(archive(self._preview_of)),
                              channel=plain_label((self._playing_row(rows) or {}).get('label')))
            except Exception:
                return False
        elif command == 'last':
            known = {r['channelid']: r for r in self._channel_rows('alltv')}
            recent = [known[c] for c in getattr(self, '_recent', []) if c in known and c != self._preview_of]
            if not recent:
                return False
            kwargs = dict(mode='strip', rows=recent, selected=recent[0]['channelid'], title='Last channels')
        else:                                     # Channels: the stable IPTV's tiles, a group at a time
            label = next((plain_label(g.get('label')) for g in found if g['channelgroupid'] == group), 'Channels')
            kwargs = dict(mode='strip', rows=rows, selected=self._preview_of, title=label, groups=found, group=group,
                          load=self._channel_rows)
        picker = PlayerPicker('meganexus_iptv_picker.xml', ADDON_UI.getAddonInfo('path'), theme_folder(), '1080i', **kwargs)
        try:
            picker.doModal()
            chosen = picker.chosen
            if picker.mode == 'strip' and getattr(picker, 'group', None) not in (None, group) and chosen:
                self._group = picker.group
        finally:
            del picker
        if not chosen:
            return False
        if command == 'catchup':
            if chosen.get('mark') == 'watching' or chosen.get('mark') == 'live' and not getattr(self, '_archive', False):
                return False                      # what already plays
            if chosen.get('mark') == 'live':      # from the archive back to the channel live
                live = self._playing_row(rows)
                return bool(live) and self._switch(live)
            return self._from_archive(chosen, rows)
        if chosen['channelid'] == self._preview_of:
            return False
        return self._switch(chosen)

    def _schedule(self, past):
        """The Catch-up box as the channel's schedule ("nije oznaceno sta trenutno ide"): its archive oldest first, the
        programme on air last (LIVE), the one from the archive that plays marked Watching - the cursor starts there."""
        watching = getattr(self, '_watching', None) if getattr(self, '_archive', False) else None
        rows = [dict(b, mark='watching') if watching and b.get('starttime') == watching else dict(b) for b in reversed(past)]
        now = getattr(self, '_now_programme', None)
        return rows + ([dict(now, mark='live')] if now else [])

    def _from_archive(self, programme, rows):
        """A programme of the channel that plays from its archive: a file from its Xtream server when the list is one -
        Kodi's player seeks it like a film, its progress bar and forward ("iptv nema progres bar jer kad koristim catchup
        moram moci ubrzati"; iptv.archive_file) - else through Kodi's PVR (IPTV Simple)."""
        from .iptv import _play_file, archive_file, item_for, plain_label, rpc
        name = (self._playing_row(rows) or {}).get('label') or ''
        url = archive_file(name, programme)
        self._watching = programme.get('starttime')
        if url:
            _play_file(url, plain_label(programme.get('title') or 'Programme'))
            self._archive = True
            return True
        xbmc.log('[MegaNexus] MegaIPTV: catch-up of %s through Kodi\'s PVR (no file from its server)' % (plain_label(name) or self._preview_of),
                 xbmc.LOGINFO)
        self._archive = rpc('Player.Open', {'item': item_for(('broadcast', programme['broadcastid']))}) == 'OK'
        return self._archive

    def _back_to_live(self):
        """Out of the player after a programme from the archive or a MultiView grid (it ends): the channel - the grid's
        whose sound was heard - plays live at the top again (the archive and the grid stay Kodi's player's alone)."""
        grid = getattr(self, '_grid', None)
        if grid is not None:
            from .multiview_sources import iptv_rows
            heard = self._mv['rows'][self._mv['sound']]
            channel = next(iter(iptv_rows([heard] + self._mv['rows'])), None)   # a sport stream heard: the grid's channel
            self._mv_end()
            if channel is not None:
                self._preview_of, self._archive = channel['channelid'], True   # it plays at the top again, as after the archive
                self.setProperty('meganexus.app.playing', str(channel['channelid']))
        if getattr(self, '_archive', False) and self._preview_of and not self._dialog_closed:
            from .iptv import open_preview
            self._archive = False
            try:
                open_preview(self._preview_of)
            except Exception as exc:
                xbmc.log('[MegaNexus] MegaIPTV: the channel did not start again: %s' % str(exc)[:120], xbmc.LOGWARNING)

    def _guides_archive(self):
        """A programme the guide plays from the archive (Kodi's PVR: pvr://guide/<id>/<its start, UTC>.epg - it does not
        seek): the same programme as a file from its Xtream server instead, when the list is one. Returns what played
        before, '' when nothing changed."""
        from .iptv import _play_file, archive_file, broadcasts, channels, plain_label
        path = xbmc.getInfoLabel('Player.Filenameandpath')
        if not path.startswith('pvr://guide/'):
            return ''
        name = xbmc.getInfoLabel('VideoPlayer.ChannelName')
        start = path.rsplit('/', 1)[-1][:-len('.epg')].replace(' ', 'T')
        row = next((r for r in channels('alltv') if plain_label(r.get('label')) == plain_label(name)), None)
        programme = next((b for b in broadcasts(row['channelid']) if (b.get('starttime') or '').replace(' ', 'T') == start), None) if row else None
        url = archive_file(row.get('label'), programme) if programme else ''
        if not url:
            xbmc.log('[MegaNexus] MegaIPTV: the guide\'s catch-up of %s stays Kodi\'s PVR (%s)'
                     % (plain_label(name), 'no file from its server' if programme else 'its programme not found'), xbmc.LOGINFO)
            return ''
        self._preview_of, self._archive, self._watching = row['channelid'], True, programme.get('starttime')
        _play_file(url, plain_label(programme.get('title') or 'Programme'))
        return path

    def stop_channel(self):
        """Leaving MegaIPTV: its channel (or grid) stops, Kodi's own player setting as it was - and a sport stream
        MultiView left alone (it is no channel: Pvr.IsPlayingTV never said it plays)."""
        self._mv_end()
        self._mv_stop_left()
        if getattr(self, '_preview_of', None):
            if xbmc.getCondVisibility('Pvr.IsPlayingTV'):        # its channel - never a film started from here
                from .iptv import _stop_channel
                _stop_channel()
            self._preview_of = None
            self.setProperty('meganexus.app.playing', '')
        if getattr(self, '_windowed', False):
            from .iptv import release_windowed
            release_windowed()
            self._windowed = False

    def _hero_tick(self):
        """The app's top: the card under the cursor - its title, line, words and picture (as it is: nothing kept)."""
        control_id, pos, _ = self._selection()
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves):
            return
        rows = self._shelves[index].get('rows') or []
        card_row = rows[pos] if 0 <= pos < len(rows) else {}
        key = (self._identity(card_row), card_row.get('title'), card_row.get('fanart')) if card_row else None   # its details too
        if key == getattr(self, '_hero_key', None):
            return
        self._hero_key = key
        for name, value in (('title', card_row.get('title')), ('meta', card_row.get('meta_line')), ('plot', card_row.get('plot')),
                            ('fanart', card_row.get('fanart'))):
            self.setProperty('meganexus.app.' + name, str(value or '').strip())

    def _load(self, index, shelf, generation):
        job = shelf.get('megaiptv_job')
        if not job:
            return super()._load(index, shelf, generation)
        if self._closed or generation != self._generation:
            return
        show = json.loads(self._bucket[len(SHOW):]) if self._bucket.startswith(SHOW) else None
        try:
            rows = rows_of(job, show) or [home_data.placeholder('Nothing here', 'The server has nothing in this group.')]
        except Exception:
            xbmc.log('[MegaNexus] MegaIPTV row did not load: %s' % traceback.format_exc(limit=1).strip().splitlines()[-1], xbmc.LOGWARNING)
            rows = [dict(home_data.placeholder('The server did not answer', 'Select to ask again.'), megaiptv_retry=True)]
        self._put(index, shelf, rows, generation)

    def _put(self, index, shelf, rows, generation):
        if not self._closed and generation == self._generation:
            g = shelf.get('_ring_g')
            if g is not None and 0 <= g < len(self._pages) and self._pages[g].get('megaiptv_job') == shelf.get('megaiptv_job'):
                self._pages[g].update(rows=rows, _loaded=True)
            self._updates.put((generation, index, rows, None, g))

    def _paint(self, shelves, keep_pages=False):
        """Home's paint - and the card the cursor left (a film started from it, "mora vratiti na mjesto odaklen je
        pokrenut") is picked again once its row's cards come: here they come from the server after the paint, when
        Home has already put the cursor on a row with none of them."""
        first = not getattr(self, '_painted', False)
        super()._paint(shelves, keep_pages)
        if not first:                     # only the window's first paint (onInit's): Home's own first focus writes [row, 0]
            return                        # over the card while the row still has its one blank card
        self._painted = True
        spot = self._focus_memory.get(self._bucket or 'home')
        try:
            spot = [int(x) for x in spot[:3]] if spot else None
        except (TypeError, ValueError):
            spot = None
        if spot and getattr(self, '_ring_g', None) is not None:
            spot[0] = self._ring_at % home_data.MAX_ROWS          # going round: the remembered row stands where the ring put it
        self._return_spot = spot if spot and spot[1] > 0 else None

    def _set_rows(self, index, rows, watched=None, background=False):
        super()._set_rows(index, rows, watched, background)
        spot = getattr(self, '_return_spot', None)
        if not spot or spot[0] != index or not 0 < spot[1] < len(rows or ()):
            return
        self._return_spot = None
        try:
            control = self.getControl(ROW_BASE + index)
            if control.getSelectedPosition() <= 0:           # the cursor did not move meanwhile
                self._select(control, spot[1], len(rows), spot[2] if len(spot) > 2 else None)
        except Exception:
            pass

    def _go(self, view, query=None):
        """Another of the app's views, drawn in this screen. Films and series: the channel stops (Home's own top, its
        pictures and trailers, have the screen) - back on Live TV the last channel plays again."""
        if view != LIVE and getattr(self, '_preview_of', None):
            self.stop_channel()
        self._return_spot = None                  # another view: its first card
        self._entry_done = view != LIVE and getattr(self, '_entry_done', False)
        if query is not None:
            self._app_query = query
        self._bucket = view
        self._focus_memory.pop(view, None)
        self._paint(shelves(view, getattr(self, '_app_query', '')))

    def _card(self, control_id):
        if not ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            return None, -1
        index = control_id - ROW_BASE
        rows = self._shelves[index].get('rows') or []
        pos = self.getControl(control_id).getSelectedPosition()
        return (rows[pos] if 0 <= pos < len(rows) else None), index

    def onClick(self, control_id):
        self._touch()
        for button, view in ((LIVE_BUTTON, LIVE), (MOVIES_BUTTON, MOVIES), (SERIES_BUTTON, SERIES)):
            if control_id == button:
                return self._go(view) if self._bucket != view else None
        if control_id in (105, 111):
            return self._search()
        if control_id == GUIDE_BUTTON:
            return self._guide()
        if control_id == 113:      # Home's round Now playing, after HUB while the channel plays: the big player
            return self._full_screen() if getattr(self, '_preview_of', None) and xbmc.getCondVisibility('Player.HasVideo') else None
        if control_id == OPTIONS_BUTTON:
            self._suspended = True
            try:
                from .iptv import configure
                self.over(configure, options())
            finally:
                self._suspended = False
            iptv_vod.forget()
            return self._go(self._bucket if not self._bucket.startswith(SHOW) else LIVE)
        row, index = self._card(control_id)
        if row is not None and row.get('megaiptv_retry'):
            self._shelves[index]['_loaded'] = False
            self._scheduled.discard(index)
            return
        if row is not None and (row.get('app_open') or [None])[0] == 'live':
            return self._channel_ok(row)
        if row is not None and row.get('app_open'):
            self._back_to = self._bucket
            opened = list(row['app_open'])
            opened[3] = opened[3] or row.get('poster') or ''          # the server without pictures: MegaNexus' details' ones
            opened[4] = opened[4] or row.get('fanart') or ''
            return self._go(SHOW + json.dumps(opened))
        super().onClick(control_id)           # a film or an episode plays (its server_play), the HUB

    def onAction(self, action):
        if action.getId() in BACK:
            self._touch()
            if self._bucket.startswith(SHOW):
                return self._go(getattr(self, '_back_to', SERIES))
            if self._bucket == SEARCH:
                return self._go(LIVE)
            top = {MOVIES: MOVIES_BUTTON, SERIES: SERIES_BUTTON}.get(self._bucket)
            # films and series: up to their button on the top bar ("back ... vraca stalno na channels umjesto da vrati na
            # vrh"), from there Options; on the bar (and on Live TV): its HUB button, as the other apps
            self.setFocusId(top if top and self.getFocusId() >= ROW_BASE else HUB_BUTTON)
            return
        super().onAction(action)

    def _guide(self):
        """Kodi's own TV guide (skin.meganexus MyPVRGuide.xml: the channels' programmes as wide as their time, the time
        line, the line of now, the groups, over the channel that plays full screen) on the group the channel that plays
        is in ("kad se ude u guide fokus mora biti na drzavi di kanal ide"). OK on a programme does it at once ("switch i
        play stavi u jednu funkciju"): Kodi's Smart select while it is open - on air: its channel, over: from the
        archive, ahead: its information. Kodi opens no window over a dialog: this screen steps aside and comes back when
        the guide is left - a channel chosen there playing at its top. What the guide starts full screen plays in this
        app's player (_player)."""
        from .iptv import current_id, give_back_select, smart_select
        monitor, focus, started = xbmc.Monitor(), self.getFocusId(), getattr(self, '_preview_of', None)
        self._child_active = True
        select = smart_select()                         # OK: on air - the channel, over - from the archive, at once
        home = xbmcgui.Window(10000)
        home.setProperty(GUIDE_OPEN, '1')               # the guide's Back: the picture full screen (MyPVRGuide.xml)
        try:
            xbmcgui.WindowXMLDialog.close(self)
            path = self._guide_group()
            xbmc.executebuiltin('ActivateWindow(TVGuide,%s)' % path if path else 'ActivateWindow(TVGuide)')
            for _ in range(100):                        # it opens (ten seconds at most)
                if xbmc.getCondVisibility('Window.IsActive(tvguide)') or monitor.waitForAbort(.1):
                    break
            while not monitor.waitForAbort(.2):
                if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                    if xbmc.getCondVisibility('Pvr.IsPlayingTV') and current_id():
                        self._follow(current_id())
                    self._player(monitor)               # back to the guide afterwards (Kodi's player was opened from it)
                    self._back_to_live()
                    continue
                if not xbmc.getCondVisibility('Window.IsActive(tvguide) | System.HasModalDialog'):
                    break                               # Back from the guide (its programme dialogs go back to it)
        finally:
            home.clearProperty(GUIDE_OPEN)
            give_back_select(select)
            if not self._dialog_closed and not monitor.abortRequested():
                # what the guide switched to: playing at the top and the cursor on its card BEFORE the screen shows
                # ("fokusiraj se na taj kanal unaprijed da nema cekanja ili naglih tranzita glavnog playera")
                focus = self._took_guides_channel(started) or focus
                self.show_ready()
                self.setFocusId(focus)
            self._child_active = False

    def _took_guides_channel(self, started):
        """The channel the guide left playing, when another than ``started``: this screen's (its LAST, the play mark,
        its card under the cursor - and in the cursor's memory, so the screen comes back on it, no move after). Returns
        its row's control, None when nothing changed or it has no card here."""
        from .iptv import current_id
        channel = current_id() if xbmc.getCondVisibility('Pvr.IsPlayingTV') else None
        if not channel or channel == started:
            return None
        self._preview_of = channel
        self.setProperty('meganexus.app.playing', str(channel))
        card = next((c for c in self._cards() if (c.get('app_open') or [None, None])[:2] == ['live', channel]), None)
        if card is None:
            return None
        self._follow(channel)
        played(card.get('unique') or '')
        index, pos = next((i, at) for i, shelf in enumerate(self._shelves) for at, c in enumerate(shelf.get('rows') or []) if c is card)
        self._focus_memory[self._bucket or 'home'] = [self._view_row(index), pos]
        xbmcgui.Window(10000).setProperty('meganexus.home.focus', json.dumps(self._focus_memory))
        try:
            self.getControl(ROW_BASE + index).selectItem(pos)
        except Exception:
            pass
        return ROW_BASE + index

    def _guide_group(self):
        """Kodi's path of the group the channel that plays is in (its first row here, a country...), '' for Kodi's own:
        pvr://channels/tv/<name>@<the PVR client's id>/ (Kodi's PVR/channels/PVRChannelsPath.cpp, the name encoded as
        its CURL::Encode does)."""
        from .iptv import groups
        playing = getattr(self, '_preview_of', None)
        card = next((c for c in self._cards() if (c.get('app_open') or [None, None])[:2] == ['live', playing]
                     and c.get('group') not in (None, 'alltv')), None) if playing else None
        if card is None:
            return ''
        label = next((g.get('label') for g in groups() if g.get('channelgroupid') == card['group']), '')
        client = str(card.get('unique') or '').split(':', 1)[0]
        if not label or not client:
            return ''
        return 'pvr://channels/tv/%s@%s/' % (quote(label, safe="-_.!()"), client)

    def _search(self):
        self._suspended = True
        try:
            query = xbmcgui.Dialog().input('Search MegaIPTV', getattr(self, '_app_query', '')).strip()
        finally:
            self._suspended = False
        if query:
            self._go(SEARCH, query)


def _wait_for_live():
    """The PVR's channels loaded (after Kodi starts), our ring meanwhile - as meganexus_ui/iptv.py waits."""
    from .iptv import pvr_ready
    if pvr_ready():
        return
    def wait():
        monitor = xbmc.Monitor()
        for _ in range(240):
            if pvr_ready() or monitor.waitForAbort(.25):
                return True
        return False
    from .play_jobs import ring_job
    ring_job(wait)


def open_megaiptv():
    """MegaIPTV, Live TV first; without IPTV set up, the channels' own first steps (meganexus_ui/iptv.py)."""
    from .iptv import configured, open_iptv, refresh_hold
    if not configured():
        open_iptv()
        return
    _wait_for_live()
    monitor = xbmc.Monitor()
    view, query, pending = LIVE, '', ''
    steady_screen = refresh_hold()         # its channels keep the TV's mode, small and full screen (unless its AFR is on)
    steady_screen.__enter__()
    try:
        while not monitor.abortRequested():
            window = MegaIPTVWindow(XML, ADDON.getAddonInfo('path'), theme_folder(), '1080i', shelves=shelves(view, query), bucket=view)
            window._app_query = query
            window.setProperty('meganexus.app', KIND)        # before it shows: never MegaNexus' wordmark first
            cover = None
            try:
                screen_guard.hold()
                window.show_ready()
                from .trailers import lift_curtain
                lift_curtain()
                while not window._closed and not window._leaving and not monitor.abortRequested():
                    window.drain_updates()
                    monitor.waitForAbort(.05)
                pending, view, query = window._pending, window._bucket or LIVE, getattr(window, '_app_query', '')
            finally:
                if getattr(window, '_pending', None) not in ('playing', 'player', 'reload'):
                    window.stop_channel()                 # leaving MegaIPTV: its channel stops
                if getattr(window, '_pending', None) == 'hub':
                    try:
                        from .play_jobs import wait_overlay
                        cover = wait_overlay('', {})
                    except Exception:
                        cover = None
                    xbmc.executebuiltin('ActivateWindow(Home)')
                    for _ in range(20):
                        if xbmc.getCondVisibility('Window.IsActive(Home)') or monitor.waitForAbort(.025):
                            break
                    monitor.waitForAbort(HUB_SETTLE_PLAIN)
                window._finish()
                window._release()
                screen_guard.release()
                if cover is not None:
                    cover.close()
            if pending == 'player':
                to_player()
                pending = 'playing'
            if pending == 'playing':
                wait_for_film()
                continue
            if pending == 'reload':
                continue
            if pending and pending != 'hub':
                from .system_setup import execute_command
                from .session_window import leave_for
                leave_for(pending, execute_command)
            break
    finally:
        steady_screen.__exit__(None, None, None)
        iptv_vod.forget()
        from resources.lib import channel_logos
        channel_logos.forget()
        _PICTURE_HOSTS.clear()
        if not pending:
            xbmc.executebuiltin('ActivateWindow(Home)')
