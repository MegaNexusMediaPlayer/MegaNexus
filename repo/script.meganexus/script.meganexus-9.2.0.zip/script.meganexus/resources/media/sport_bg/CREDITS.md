# MegaSport backgrounds

Photographs from Wikimedia Commons, cut to 16:9 and made smaller (review/make_sport_backgrounds.py).

* all.jpg - "Olympic Stadium (7724386874).jpg" by The Department for Culture, Media and Sport, CC BY 2.0 (https://creativecommons.org/licenses/by/2.0) - https://commons.wikimedia.org/wiki/File:Olympic_Stadium_(7724386874).jpg
* australian-football.jpg - "Melbourne (AU), View from Eureka Tower, Melbourne Cricket Ground -- 2019 -- 1450.jpg" by Dietmar Rabich, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0) - https://commons.wikimedia.org/wiki/File:Melbourne_(AU),_View_from_Eureka_Tower,_Melbourne_Cricket_Ground_--_2019_--_1450.jpg
* baseball.jpg - "McLane Baseball Stadium 004 during EMU at MSU baseball game on May 10, 2023 (8506749).jpg" by Joel Dinda from Mulliken, Michigan, CC BY 2.0 (https://creativecommons.org/licenses/by/2.0) - https://commons.wikimedia.org/wiki/File:McLane_Baseball_Stadium_004_during_EMU_at_MSU_baseball_game_on_May_10,_2023_(8506749).jpg
* basketball.jpg - "Capital One Arena interior 2017-04-19.jpg" by Daniel Lobo, CC0 (http://creativecommons.org/publicdomain/zero/1.0/deed.en) - https://commons.wikimedia.org/wiki/File:Capital_One_Arena_interior_2017-04-19.jpg
* field-hockey.jpg - "Field hockey pitch on TTK Sachsenwald premises 002.jpg" by Jeuwre, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0) - https://commons.wikimedia.org/wiki/File:Field_hockey_pitch_on_TTK_Sachsenwald_premises_002.jpg
* football.jpg - "Sun Devil Stadium - Pac12 Championship.jpg" by Clintus McGintus, CC BY-SA 2.0 (https://creativecommons.org/licenses/by-sa/2.0) - https://commons.wikimedia.org/wiki/File:Sun_Devil_Stadium_-_Pac12_Championship.jpg
* golf.jpg - "Putting green at the Royal Canberra Golf Club 4.JPG" by Neuroxic, CC BY 4.0 (https://creativecommons.org/licenses/by/4.0) - https://commons.wikimedia.org/wiki/File:Putting_green_at_the_Royal_Canberra_Golf_Club_4.JPG
* hockey.jpg - "The Rink in the American Dream Meadowlands during ice hockey practicing.jpg" by ArielR20130725, CC0 (http://creativecommons.org/publicdomain/zero/1.0/deed.en) - https://commons.wikimedia.org/wiki/File:The_Rink_in_the_American_Dream_Meadowlands_during_ice_hockey_practicing.jpg
* lacrosse.jpg - "Lacrosse-Faceoff.jpg" by Mcmaerti, Public domain (public domain) - https://commons.wikimedia.org/wiki/File:Lacrosse-Faceoff.jpg
* mma.jpg - "PLMMA Cage-Octagon MMA.JPG" by Tyka17, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0) - https://commons.wikimedia.org/wiki/File:PLMMA_Cage-Octagon_MMA.JPG
* racing.jpg - "Aerial view of Motorsport race track Circuit Zandvoort Formula one (40889997713).jpg" by dronepicr, CC BY 2.0 (https://creativecommons.org/licenses/by/2.0) - https://commons.wikimedia.org/wiki/File:Aerial_view_of_Motorsport_race_track_Circuit_Zandvoort_Formula_one_(40889997713).jpg
* rugby.jpg - "Higashi Osaka Hanazono Rugby Stadium ground.jpg" by Kst01, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0) - https://commons.wikimedia.org/wiki/File:Higashi_Osaka_Hanazono_Rugby_Stadium_ground.jpg
* soccer.jpg - "Drone aerial view of the soccer stadium (Unsplash).jpg" by Liane Metzler liane, CC0 (http://creativecommons.org/publicdomain/zero/1.0/deed.en) - https://commons.wikimedia.org/wiki/File:Drone_aerial_view_of_the_soccer_stadium_(Unsplash).jpg
* tennis.jpg - "Pörtschach Johannes-Brahms-Promenade Werzer-Tennis-Arena 27052017 8932.jpg" by Johann Jaritz, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0) - https://commons.wikimedia.org/wiki/File:P%C3%B6rtschach_Johannes-Brahms-Promenade_Werzer-Tennis-Arena_27052017_8932.jpg
* volleyball.jpg - "Volleyball court, Chorzow (DBR45884).jpg" by Matti Blume, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/deed.en) - https://commons.wikimedia.org/wiki/File:Volleyball_court,_Chorzow_(DBR45884).jpg
* water-polo.jpg - "Lazdynai swimming pool water polo competition.jpg" by Illustr, CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0) - https://commons.wikimedia.org/wiki/File:Lazdynai_swimming_pool_water_polo_competition.jpg
* rugby-league.jpg - the same picture as rugby.jpg
* cricket.jpg - the same picture as australian-football.jpg
