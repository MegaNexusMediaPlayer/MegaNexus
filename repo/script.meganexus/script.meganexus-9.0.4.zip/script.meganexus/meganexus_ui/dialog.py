# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Keep Kodi callbacks short and remove parent modals while a child owns input."""
import queue
import time
import threading
import traceback
import xbmc
import xbmcgui

from resources.lib import screen_guard


def _ignore(*_args, **_kwargs):
    """The callback a closed window keeps: a plain function, so it holds no window.

    Dialog._release puts this in place of the per-instance callbacks. Anything Kodi
    still delivers to a window it has not freed yet lands here and is dropped.
    """

BACK = (9, 10, 92, 216, 13, 247, 257, 275, 61448, 61467)
ACTIONS = (117, 101, 1009, 11)
FRONTEND = False   # 7.0.55: set by the interface's own run (default.py launch) - its pages make way for a party film
# Touch gestures (IDs 501-599) are left entirely to Kodi, as before 6.0.37.
# 6.0.37/6.0.39 turned vertical drags into Up/Down steps; it fought Kodi's own
# panning (too fast on a small move, focus changes repainted Home) and was
# removed in 6.0.40. Never reuse window attribute names for Dialog state:
# 6.0.37 stored it as self._touch and replaced HomeWindow._touch().


class KodiStopping(Exception):
    """8.1.4: Kodi is closing (it was told to stop, or the box goes to sleep).

    A window opened from a click (Settings, a title) returns when Kodi closes, and the
    click went on as if nothing had happened: Home was drawn again (paint/seed) after
    Kodi had already taken the skin down - Kodi crashed in getSelectedPosition, or hung
    there until the system killed it after 30 s, which is what every night's suspend
    of the Cube ran into. Raised where such a window returns; the click stops there."""


def _unless_stopping(result):
    if xbmc.Monitor().abortRequested():
        raise KodiStopping()
    return result


class Action:
    def __init__(self, aid): self.aid = aid
    def getId(self): return self.aid

class Dialog(xbmcgui.WindowXMLDialog):
    """Callbacks are wrapped per window instance (6.0.37). Kodi 22's SWIG 4.5
    bindings make the window classes' attributes read-only after creation
    ("cannot modify read-only attribute ...onInit"), so the earlier
    class-level wrapping in __init_subclass__ stopped every MegaNexus window."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self._events = queue.Queue(maxsize=1)
        self._dispatching = False
        self._dialog_closed = False
        self._child_active = False
        self._restore_focus = None
        self._meganexus_play_hidden = False
        self._wanted_focus = 0
        self._focus_until = 0.0
        self._last_input = 0.0
        self._focus_at = 0.0
        self._xml_ready=threading.Event()
        self._install_callbacks()

    def _install_callbacks(self):
        cls = type(self)
        for name in ('onInit', 'onClick', 'onAction'):
            owner = next((k for k in cls.__mro__ if name in k.__dict__), None)
            if owner is None or owner is Dialog or not issubclass(owner, Dialog):
                continue
            original = owner.__dict__[name]
            if name == 'onInit':
                def ready(_fn=original):
                    try:return _fn(self)
                    finally:self._xml_ready.set()
                self.onInit = ready
                continue
            def callback(value, _fn=original, _name=name):
                if self._child_active or self._dialog_closed: return
                if _name == 'onAction':
                    aid = value.getId()
                    # 8.1.2: noted before anything is filtered out. Kodi owns navigation,
                    # so those keys are not forwarded - but they are still a person
                    # pressing a button, and _take_focus has to know.
                    self._last_input = time.monotonic()
                    if aid not in BACK + ACTIONS: return  # Kodi owns navigation/seek/touch.
                    value = Action(aid)
                    if aid in BACK: return _fn(self, value)
                # A busy operation already owns this click; do not replay held
                # Select after it returns. Irrelevant navigation never queues.
                if not self._dispatching:
                    self.defer(lambda: _fn(self, value))
            setattr(self, name, callback)

    def _release(self):
        """Let Kodi free this window when it is done with.

        Each instance wires its own callbacks (6.0.37, because Kodi 22's SWIG bindings
        make the class attributes read-only), and those functions close over the window
        while being stored ON the window: the window points at a function that points
        back at the window. A reference cycle around a C++ object.

        Kodi says so at every script exit - "has left several classes in memory that we
        couldn't clean up ... SwigDirector_WindowXMLDialog", six of them in one session
        here - and until they go it keeps each window registered with its controls. The
        window ids climb for the same screen reopened (13018, 13019, 13020, 13021,
        13022 for Settings), memory climbed to 1000 MB in five minutes, and a window
        Kodi still has but Python has forgotten is a control it will draw after the
        controls were freed.

        The cyclic collector would get these eventually, but it does not run before Kodi
        tears the interpreter down - which is when the warning is printed. So the cycle
        is broken by hand, here, the moment the window is finished with.
        """
        try:
            while True:
                self._events.get_nowait()
        except queue.Empty:
            pass
        except Exception:
            pass
        for name in ('onInit', 'onClick', 'onAction'):
            try:
                setattr(self, name, _ignore)       # a plain function: no window in its closure
            except Exception:
                pass
        self._restore_focus = None
        self._wanted_focus = 0

    def show_ready(self):
        """Restored XML controls are valid only after Kodi delivers onInit."""
        self._xml_ready.clear()
        self.show()
        monitor=xbmc.Monitor()
        for _ in range(100):
            if self._xml_ready.is_set() or self._dialog_closed or monitor.waitForAbort(.01):break

    def defer(self, fn):
        try: self._events.put_nowait(fn)
        except queue.Full: pass

    def child(self, fn, *args, **kwargs):
        """Hide the parent natively; retain its Python state for Back/Stop."""
        try: focus = self.getFocusId()
        except Exception: focus = None
        self._child_active = True
        try:
            xbmcgui.WindowXMLDialog.close(self)
            return _unless_stopping(fn(*args, **kwargs))
        finally:
            self._restore_focus = focus
            if not self._dialog_closed and not xbmc.Monitor().abortRequested():
                self.show_ready()
            self._child_active = False

    def in_place(self, fn, *args, **kwargs):
        """7.0.29: start a title over this screen - it stays while the sources are
        searched and chosen (no other screen, wallpaper or black blinks between) and
        hides only when the video starts (playback._hide_parents); back afterwards."""
        from . import play_jobs
        try: focus = self.getFocusId()
        except Exception: focus = None
        self._child_active = True
        self._meganexus_play_hidden = False
        play_jobs.PARENTS.append(self)
        try:
            return _unless_stopping(fn(*args, **kwargs))
        finally:
            try: play_jobs.PARENTS.remove(self)
            except ValueError: pass
            if self._meganexus_play_hidden:
                self._meganexus_play_hidden = False
                self._restore_focus = focus
                if not self._dialog_closed and not xbmc.Monitor().abortRequested():
                    self.show_ready()
            self._child_active = False

    def over(self, fn, *args, **kwargs):
        """Run a window on top of this one while it stays visible (translucent
        HUB Settings, 6.0.35). Its own input is paused meanwhile."""
        self._child_active = True
        try:
            return _unless_stopping(fn(*args, **kwargs))
        finally:
            self._child_active = False

    def restore_focus(self):
        """Where the cursor was when this screen stepped aside - and only if it is
        still free. 8.1.2: this used to set it outright, which on a slow return landed
        on top of keys the person had pressed in the meantime ("i nesmije vracati fokus
        naknadno"). focus() asks only while nothing holds the cursor and gives up at the
        first key."""
        focus, self._restore_focus = self._restore_focus, None
        if focus:
            self.focus(focus)

    def drain_events(self):
        if self._dialog_closed or self._dispatching or self._child_active: return
        try: fn = self._events.get_nowait()
        except queue.Empty: return
        self._dispatching = True
        try: fn()
        except KodiStopping:
            pass                 # 8.1.4: Kodi is closing - the rest of this click must not draw
        except Exception:
            # 6.0.39: one failing click or key never closes MegaNexus ("Could
            # not open the interface"); the window stays and the log has why.
            xbmc.log('[MegaNexus] Action failed: ' + traceback.format_exc(), xbmc.LOGERROR)
            try: xbmcgui.Dialog().notification('MegaNexus', 'That did not work. Please try again.', time=3000)
            except Exception: pass
        finally: self._dispatching = False

    FOCUS_PATIENCE = 2.0      # s a control has to accept focus before we stop asking
    FOCUS_RETRY = 0.25        # s between asks, so a slow one costs a few log lines, not forty

    def focus(self, control_id):
        """Put the cursor on a control, and keep asking until Kodi gives it.

        In onInit a control often cannot take focus yet: the list has no items, Kodi
        has not finished the layout, the window is not the active one. setFocusId is
        then a no-op, the screen opens with the cursor nowhere, and the first key press
        goes wherever Kodi chooses - which from the sofa looks like a control skipping,
        or like a collection that did not open until the second press.

        The ask is repeated from the loop that drives the window (doModal, or
        drain_updates for Home and the collection screen) - never slept on here, which
        runs inside a GUI callback. Whether it worked is read back from getFocusId;
        asking is not the same as being given.

        It does NOT first test Control.IsVisible: that condition is evaluated against
        the active window, which this one is not yet during onInit, so it answers no
        for a control that is perfectly ready and the cursor would never be placed.
        """
        self._wanted_focus = int(control_id or 0)
        self._focus_at = self._focus_until = time.monotonic()
        self._focus_until += self.FOCUS_PATIENCE
        self._focus_asked = 0.0
        self._take_focus()

    def _take_focus(self):
        """Place the cursor - but only while nothing at all holds it.

        8.1.2, and this is the whole rule now. Earlier versions tried to be clever:
        they kept asking for up to two seconds, compared the control the cursor was on
        with the one it had been on, and gave up if the difference looked like a person.
        It read well and behaved badly - leaving Settings and pressing a key dragged the
        cursor back onto Settings, and a click on Search landed on Settings because an
        older screen still had a return of its own pending.

        A control cannot always take focus the moment a screen opens (no items yet, the
        window not active), which is why asking is repeated at all. But the only state
        worth asking in is "nobody has it": if any control holds the cursor it is either
        where we put it or where the person moved it, and both are left alone.
        """
        wanted = getattr(self, '_wanted_focus', 0)
        # getattr throughout: Kodi can re-init a window, and a window may be built
        # without __init__ having run, so none of this state is guaranteed to exist.
        if not wanted or getattr(self, '_dialog_closed', False):
            return
        now = time.monotonic()
        if now - getattr(self, '_focus_asked', 0.0) < self.FOCUS_RETRY and self._focus_asked:
            return
        self._focus_asked = now
        try:
            held = self.getFocusId()
            if held or getattr(self, '_last_input', 0.0) > getattr(self, '_focus_at', 0.0):
                self._wanted_focus = 0      # where it is, or where the person moved it
                return
            self.setFocusId(wanted)
        except Exception:
            self._wanted_focus = 0
            return
        if now >= getattr(self, '_focus_until', 0.0):
            self._wanted_focus = 0

    def doModal(self):
        self._dialog_closed = False
        # 8.1.2: while this is on screen the skin must not be loaded again. A reload frees
        # every control of every window; a Python window that is still running then uses
        # freed controls, which crashed Kodi on a profile rename. The component installer
        # and anything else that would reload waits for the mark instead - and not
        # reloading costs nothing, Kodi keeps the skin it has until its next start.
        screen_guard.hold()
        try:
            self.show_ready()
            monitor = xbmc.Monitor()
            checked = 0.0
            while not self._dialog_closed and not monitor.abortRequested():
                self.drain_events()
                self._take_focus()
                tick = getattr(self, 'tick', None)
                # 8.1.4: never once Kodi is closing - its windows are taken down under us
                if tick and not self._dialog_closed and not monitor.abortRequested(): tick()
                now = time.monotonic()
                if FRONTEND and now - checked >= .5:
                    checked = now
                    # 7.0.55: the Watch Party host's film is waiting for Home - this page makes way
                    # (as Back does); Home starts the film like a click (party.take_handover)
                    if not self._child_active and xbmcgui.Window(10000).getProperty('meganexus.party.start'):
                        self.close()
                        break
                monitor.waitForAbort(.05)
        finally:
            screen_guard.release()
            self._release()
            if xbmc.Monitor().abortRequested() and not getattr(Dialog, '_said_stopping', False):
                # 8.1.5: which of our threads still run as Kodi closes - Kodi kills the
                # script after 5 s and its own list (finish_jobs) never got written
                Dialog._said_stopping = True
                import threading
                busy = sorted(t.name for t in threading.enumerate() if t is not threading.current_thread() and t.is_alive())
                xbmc.log('[MegaNexus] Kodi is closing - still running: %s' % (', '.join(busy) or 'nothing'), xbmc.LOGINFO)

    def close(self):
        self._dialog_closed = True
        super().close()
