# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The HUB's YouTube app (9.0.6): MegaNexus' own Home, with YouTube in it.

The same screen as Home - its rows going round, the top bar that slides away - with YouTube's
videos as landscape cards. Its top: the card under the cursor (its title, then one line: channel ·
when it came out · LIVE · views - no description) and, beside it, the small video. As IPTV and Sport do: OK on a video
starts it small, OK on it again opens Kodi's player, Back there comes down to the small video -
it plays on while you browse and search. In Kodi's player its buttons have Up next (what YouTube puts
beside the video, as posters over the player - as IPTV's Channels), Previous / Next video and Autoplay:
on, a video that ends is followed by the next one, small or big; off (as it starts), it stops. The
round play by HUB (the film-waiting one) brings the playing video back big.

Home has YouTube's categories only; a channel is opened from Channels (or a card's options) and
has All videos, Popular and Live. Back on a channel or a search comes to the app's Home, Back
there stops the small video; only HUB leaves.

Nothing of YouTube is kept: its answers live in memory while the app is open
(resources.lib.youtube), and the pictures Kodi stored for it are removed when it closes
(forget_pictures) - "da ne usporava ostatak MegaNexusa". Your channels are kept: yours.
Videos play through Kodi's YouTube add-on - installed, and its first-start questions answered,
before the app opens (ready_player).
"""
import json
import time
import traceback
import uuid

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import home_data
from resources.lib import screen_guard
from resources.lib import youtube
from resources.lib.plain_text import without_emoji
from resources.lib.theme import folder as theme_folder
from .home_trailers import PreviewPlayer
from .home_window import ADDON, BACK, HUB_SETTLE_PLAIN, ROW_BASE, HomeWindow, to_player

HOME = 'youtube'
SEARCH = 'youtube:search'
CHANNEL = 'youtube:channel:'
XML = 'meganexus_home.xml'      # the app always has its top: the small video lives there
ADDON_ID = 'plugin.video.youtube'
# the YouTube add-on's own settings: its first-start wizard still to come, and when it last ran
WIZARD, WIZARD_RUN = 'kodion.setup_wizard', 'kodion.setup_wizard.forced_runs'
WIZARD_QUIET = 10.0   # s without any of its questions on screen: the wizard did not come
START_WAIT = 30.0     # s Kodi's YouTube add-on may take to start a video (not counting its questions)
STREAM_KIND = 'application/dash+xml'   # what Kodi's YouTube add-on hands Kodi (MPEG-DASH; steady playback: MP4)
AWAY_GRACE = .8       # s Kodi's player may be gone at a video's end before the next one is there
# Kodi's boxes the YouTube add-on asks its questions in (its first-start wizard, a choice)
ASKING = ' | '.join('Window.IsVisible(%s)' % name for name in
                    ('yesnodialog', 'selectdialog', 'okdialog', 'progressdialog', 'virtualkeyboard', 'numericinput', 'addonsettings'))
CONTEXT = (117, 101, 1009)   # the context menu key, its remote twins
OPEN = 'meganexus.youtube.open'           # the app's video in Kodi's player: its buttons (review/make_app_osd.py)
OSD_COMMAND = 'meganexus.youtube.osd'     # ... and the one pressed: related / previous / next / autoplay
AUTOPLAY = 'meganexus.youtube.autoplay'   # ... and the Autoplay switch's state
HERO = ('title', 'meta', 'fanart')   # no description at the top (9.0.6)


def _shelf(title, job, shape='landscape'):
    return {'title': title, 'rows': [home_data.placeholder(' ', '')], 'youtube_job': job, 'shape': shape}


def shelves(view, query=''):
    """Every row of one of the app's views - none of them asked for yet (the window loads them)."""
    if view == SEARCH:
        return [_shelf('Results', ('search', query, '')), _shelf('Channels', ('channels', query), 'square'),
                        _shelf('This month', ('search', query, youtube.THIS_MONTH)), _shelf('Most viewed', ('search', query, youtube.MOST_VIEWED))]
    if view.startswith(CHANNEL):
        channel_id = view[len(CHANNEL):]
        return [_shelf('All videos', ('channel', channel_id)), _shelf('Popular', ('popular', channel_id)),
                        _shelf('Live', ('live', channel_id))]
    rows = [_shelf('Live now', ('page', youtube.LIVE_PAGE, 'first'))]
    rows.extend(_shelf(title, ('topic', query)) for title, query in youtube.TOPICS[:2])
    rows.append(_shelf('Sports', ('page', youtube.SPORTS_PAGE, 'all')))
    rows.extend(_shelf(title, ('topic', query)) for title, query in youtube.TOPICS[2:])
    if youtube.my_channels():
        rows.append(_shelf('Your channels', ('mine',), 'square'))     # round, as the Music app's artists: OK opens one
    return rows


def cards(job):
    """The cards of one row (asked for in the window's workers)."""
    kind = job[0]
    if kind == 'channels':
        return [youtube.channel_card(c) for c in youtube.find_channels(job[1])]
    if kind == 'mine':
        return [youtube.channel_card(c) for c in youtube.my_channels()]
    if kind == 'search':
        found = youtube.search(job[1], job[2])
    elif kind == 'topic':
        found = youtube.topic(job[1])
    elif kind == 'channel':
        found = youtube.channel_videos(job[1])
    elif kind == 'popular':
        found = youtube.channel_popular(job[1])
    elif kind == 'live':
        found = youtube.channel_live(job[1])
    elif kind == 'page':
        page = youtube.page(job[1])
        found = (page[0][1] if page else []) if job[2] == 'first' else [v for _, items in page for v in items]
    else:
        found = []
    return [youtube.video_card(v) for v in found]


def _nothing(job):
    if job[0] in ('popular', 'live'):
        return 'Nothing here', 'This channel has none of these.'
    return 'Nothing found', 'YouTube had nothing for this.'


class YouTubePlayer(PreviewPlayer):
    """The app's video. Ours is the first video Kodi starts after we asked for it (the YouTube add-on
    hands Kodi a stream of its own making), and it stays ours by its item's token or that stream.
    ``finished``: it played to its end - the next one follows; ``stopped``: it was stopped."""
    def __init__(self):
        super().__init__()
        self.finished = self.stopped = False

    def owns(self):
        try:
            if not self.token or not self.isPlayingVideo():
                return False
            if self.getPlayingItem().getProperty('meganexus.preview') == self.token:
                return True
            return bool(self.started_own and self.av_path and self.getPlayingFile() == self.av_path)
        except Exception:
            return False

    def onAVStarted(self):
        if not self.token or self.cancelled:
            return
        try:
            mine = self.getPlayingItem().getProperty('meganexus.preview') == self.token
        except Exception:
            mine = False
        if mine or (self.requested and not self.started_own):
            try:
                self.av_path = self.getPlayingFile()
            except Exception:
                self.av_path = ''
            self.started_own, self.requested, self.ready = True, False, True

    def onPlayBackEnded(self):
        if self.started_own and not self.cancelled:
            self.finished = True
        self._ended()

    def onPlayBackStopped(self):
        # the video before, stopped by Kodi for the next one we asked for: ours plays on - nothing ends
        if self.owns():
            return
        if self.started_own:
            self.stopped = True
        self._ended()


class YouTubeWindow(HomeWindow):
    """Home, with YouTube's rows, its top and its small video."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._player = YouTubePlayer()
        self._video = None          # the card of the video in the small player
        self._played = []           # the videos played this time (the next one is a new one)
        self._next = []             # its Up next
        self._hero = None
        self._asked_at = 0.0
        self._loading = False       # asked for, its picture not there yet
        self._big_wanted = False    # OK pressed on it again meanwhile: big once its picture is there

    def onInit(self):
        self.setProperty('meganexus.app', 'youtube')   # the app's logo and top (review/make_app_home.py)
        super().onInit()
        try:
            self.getControl(106).setLabel('Channels')
            # HUB in Watch Party's place (that one is MegaNexus' own): the row keeps its even gaps
            self.getControl(108).setPosition(*self.getControl(114).getPosition())
        except Exception:
            pass

    def _paint_rows(self, shelves):
        super()._paint_rows(shelves)
        # the search's words in their pill under the bar, as on Home
        self.setProperty('meganexus.search.query', getattr(self, '_yt_query', '') if self._bucket == SEARCH else '')

    def _load(self, index, shelf, generation):
        job = shelf.get('youtube_job')
        if not job:
            return super()._load(index, shelf, generation)
        if self._closed or generation != self._generation:
            return
        try:
            rows = cards(job) or [dict(home_data.placeholder(*_nothing(job)), youtube={'empty': True})]
        except Exception:
            xbmc.log('[MegaNexus] YouTube row did not load: ' + traceback.format_exc(limit=2), xbmc.LOGWARNING)
            rows = [dict(home_data.placeholder('YouTube did not answer', 'Select to ask again.'), youtube={'retry': True})]
        if not self._closed and generation == self._generation:
            # kept with the view's row: going round, it comes back drawn, not emptied and asked again
            g = shelf.get('_ring_g')
            if g is not None and 0 <= g < len(self._pages) and self._pages[g].get('youtube_job') == job:
                self._pages[g].update(rows=rows, _loaded=True)
            self._updates.put((generation, index, rows, None, g))

    def drain_updates(self):
        super().drain_updates()
        if not self._closed:
            self._hero_tick()
            self._video_tick()

    # ---- the top: the card under the cursor -----------------------------------------------------
    def _hero_tick(self):
        """Its title and its line - set only when the card changes."""
        control_id, pos, _ = self._selection()
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves):
            return                                     # on the top bar: the last card stays
        rows = self._shelves[index].get('rows') or []
        card = rows[pos] if 0 <= pos < len(rows) else {}
        key = (self._identity(card) if card else None, self._playing_id())
        if key == self._hero:
            return
        self._hero = key
        # the card under the cursor is the one that plays: OK makes it big (review/make_app_home.py hints)
        self.setProperty('meganexus.app.here', '1' if card and (card.get('youtube') or {}).get('video') == key[1] else '')
        values = {'title': card.get('title') or '', 'meta': card.get('meta_line') or '', 'fanart': card.get('fanart') or ''}
        font = card.get('font') or ''
        # in Kodi's own font the emoji it lacks would be boxes; MegaNexus' own draws them (youtube.video_card)
        self.setProperty('meganexus.app.font', font)
        for name in HERO:
            value = values[name] if name == 'fanart' or font else without_emoji(values[name])
            self.setProperty('meganexus.app.' + name, value.strip())

    # ---- the small video ----------------------------------------------------------------------
    def _card(self, control_id):
        if not ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            return None, -1
        index = control_id - ROW_BASE
        rows = self._shelves[index].get('rows') or []
        pos = self.getControl(control_id).getSelectedPosition()
        if not 0 <= pos < len(rows):
            return None, index
        try:
            shown = int(xbmc.getInfoLabel('Container(%d).Position' % control_id) or 0)
        except ValueError:
            shown = 0
        self._focus_memory[self._bucket or HOME] = [self._view_row(index), pos, shown]
        # and where Kodi's re-initialised screen reads it (onInit, back from the big video): the cursor
        # comes back to this card, the row scrolled as it was - never to an older place
        xbmcgui.Window(10000).setProperty('meganexus.home.focus', json.dumps(self._focus_memory))
        return rows[pos], index

    def _playing_id(self):
        return ((self._video or {}).get('youtube') or {}).get('video') or ''

    def _start(self, card, windowed=True):
        """``card``'s video in Kodi's player - small (``windowed``) or big."""
        video_id = (card.get('youtube') or {}).get('video') or ''
        path = youtube.play_path(video_id)
        if not path:
            return False
        player = self._player
        player.token, player.requested = uuid.uuid4().hex, True
        player.started_own = player.ready = player.finished = player.stopped = player.cancelled = False
        player.stop_requested, player.av_path = False, ''
        home = xbmcgui.Window(10000)
        # a preview to MegaNexus' playback service: no Continue Watching, no tracking, no busy spinner
        home.setProperty('meganexus.preview.active', player.token)
        home.setProperty('meganexus.preview.silent', player.token)
        item = xbmcgui.ListItem(label=card.get('title') or 'YouTube', path=path)
        item.setArt({'thumb': card.get('poster') or '', 'fanart': card.get('fanart') or ''})
        item.setProperty('meganexus.preview', player.token)
        item.setProperty('IsPlayable', 'true')
        # its kind told: Kodi otherwise asks the add-on's stream server on the thread that draws the
        # screen (CCurlFile::Stat), and when that server hung everything stood still for 20 s
        item.setMimeType('video/mp4' if youtube.steady() else STREAM_KIND)
        item.setContentLookup(False)
        self._video, self._next = card, []
        if video_id not in self._played:
            self._played.append(video_id)
            self._history = getattr(self, '_history', []) + [card]
        self._asked_at, self._loading, self._big_wanted = time.monotonic(), True, False
        self.setProperty('meganexus.app.video', '')
        self.setProperty('meganexus.app.loading', '1')
        self.setProperty('meganexus.app.playing', video_id)   # its card's play mark (review/make_app_home.py)
        player.play(path, item, windowed=windowed)
        self._load_next(video_id)
        self._describe()
        return True

    def _load_next(self, video_id):
        """Its Up next, asked for behind the screen - the player's Up next button and the video
        after this one come from it."""
        def work():
            try:
                found = [youtube.video_card(v) for v in youtube.related(video_id)]
            except Exception:
                return
            if self._playing_id() == video_id:
                self._next = found
        if self._pool is not None:
            self._pool.submit(work)

    def _describe(self):
        """What plays, for the player's corner (review/make_app_osd.py)."""
        home, card = xbmcgui.Window(10000), self._video or {}
        home.setProperty('meganexus.youtube.now.title', card.get('title') or '')
        home.setProperty('meganexus.youtube.now.info', card.get('meta_line') or '')

    def _previous(self):
        """The video played before this one, this time."""
        history = getattr(self, '_history', [])
        return history[-2] if len(history) > 1 else None

    def _after(self):
        """A video ended: the next one only with Autoplay on (the player's switch) - off, it stops."""
        return self._following() if _autoplay() else None

    def _following(self):
        """The next video: the first of Up next not played this time."""
        if not self._next and self._playing_id():
            try:
                self._next = [youtube.video_card(v) for v in youtube.related(self._playing_id())]
            except Exception:
                self._next = []
        return next((c for c in self._next if c['youtube']['video'] not in self._played), None)

    def _video_tick(self):
        if not self._video:
            return
        player = self._player
        if player.finished:
            player.finished = False
            following = self._after()
            if following is None or not self._start(following):
                self._stop_video()
            return
        if player.stopped:
            self._stop_video(stop=False)
            return
        if self._loading:
            if player.ready and player.owns():
                self._picture_shown()
                if self._big_wanted:
                    self._big()
            elif xbmc.getCondVisibility(ASKING):
                self._asked_at = time.monotonic()      # the add-on asks something: no hurry
            elif time.monotonic() - self._asked_at > START_WAIT:
                self._stop_video()
                xbmcgui.Dialog().notification('YouTube', 'This video did not start.', time=3000)

    def _picture_shown(self):
        """Its picture is there: the small video shows it."""
        self._loading = False
        self.setProperty('meganexus.app.video', '1')
        self.setProperty('meganexus.app.loading', '')

    def _stop_video(self, stop=True):
        player = self._player
        if stop:
            player.cancel()
            player.stop_owned()
        player._ended()
        player.token, player.requested = '', False
        self._video, self._loading = None, False
        for name in ('video', 'loading', 'playing'):
            self.setProperty('meganexus.app.' + name, '')

    def _big(self):
        """Kodi's player for the video in the small one - the same playback, no new start. This
        screen steps aside (Kodi opens no window over it) and comes back when the player is left.
        There the player's buttons act (Up next, Previous / Next video - review/make_app_osd.py)
        and a video that ends is followed by the next one, there."""
        from .home_trailers import view_mode
        view_mode('normal')
        monitor, home = xbmc.Monitor(), xbmcgui.Window(10000)
        self._child_active = True
        self._restore_focus = self.getFocusId()
        try:
            xbmcgui.WindowXMLDialog.close(self)
            home.clearProperty(OSD_COMMAND)
            home.setProperty(OPEN, '1')
            home.setProperty(AUTOPLAY, '1' if _autoplay() else '')
            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            seen, start, away, switching = False, time.monotonic(), None, 0.0
            while not monitor.abortRequested():
                player = self._player
                command = home.getProperty(OSD_COMMAND)
                if command == 'autoplay':
                    home.clearProperty(OSD_COMMAND)
                    home.setProperty(AUTOPLAY, '1' if _autoplay(toggle=True) else '')   # the switch shows it at once
                elif command:
                    home.clearProperty(OSD_COMMAND)
                    chosen = self._in_player(command)
                    if chosen is not None and self._start(chosen, windowed=False):
                        switching = time.monotonic() + START_WAIT
                if player.finished:
                    player.finished = False
                    following = self._after()
                    if following is None or not self._start(following, windowed=False):
                        self._stop_video()
                        break
                    switching = time.monotonic() + START_WAIT
                full = xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                if switching:
                    # another video starts: Kodi may drop its full screen for a moment
                    if player.ready and player.owns():
                        if full:
                            switching = 0.0
                            self._picture_shown()
                        else:
                            xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
                    elif time.monotonic() > switching and not xbmc.getCondVisibility(ASKING):
                        self._stop_video()
                        break
                    if monitor.waitForAbort(.1):
                        break
                    continue
                if full:
                    seen, away = True, None
                elif seen:
                    away = away or time.monotonic()
                    # Back: the video plays on (small); its end: a moment for the next one to be asked for
                    if player.isPlayingVideo() or time.monotonic() - away >= AWAY_GRACE:
                        break
                elif time.monotonic() - start > 5:
                    break
                if monitor.waitForAbort(.1):
                    break
        finally:
            for name in (OPEN, OSD_COMMAND, AUTOPLAY):
                home.clearProperty(name)
            if not self._dialog_closed and not monitor.abortRequested():
                self.show_ready()
            self._child_active = False

    def _in_player(self, command):
        """The player's buttons: the card to play there, or None."""
        if command == 'next':
            return self._following()
        if command == 'previous':
            return self._previous()
        if command != 'related':
            return None
        self._following()                     # Up next asked for now if it has not come yet
        cards = [c for c in self._next if c['youtube']['video'] != self._playing_id()]
        if not cards:
            xbmcgui.Dialog().notification('YouTube', 'Nothing up next right now.', time=2500)
            return None
        from .sports import SportPicker
        events = [(i, {'id': c['youtube']['video'], 'title': c['title'], 'art': c['poster'], 'live': ''})
                  for i, c in enumerate(cards)]
        picker = SportPicker('meganexus_sports_picker.xml', ADDON.getAddonInfo('path'), theme_folder(), '1080i',
                             mode='strip', groups=[('Up next', events)], picture=lambda url: url or '')
        picker.doModal()
        chosen = picker.chosen
        del picker
        return cards[chosen] if chosen is not None else None

    # ---- keys ----------------------------------------------------------------------------------
    def _go(self, view, query=None):
        """Another of the app's views, drawn in this screen - the small video plays on."""
        if query is not None:
            self._yt_query = query
        self._bucket = view
        self._focus_memory.pop(view, None)
        self._paint(shelves(view, getattr(self, '_yt_query', '')))

    def onClick(self, control_id):
        self._touch()
        if control_id == 101:
            if self._bucket != HOME:
                self._go(HOME)
            return
        if control_id in (105, 111):
            return self._search()
        if control_id == 106:
            return self._channels()
        if control_id == 107:
            return self._open_settings()
        if control_id == 113 and self._video:
            return self._play(self._video)        # the round play by HUB: back to the video that plays
        row, index = self._card(control_id)
        if row is None:
            if index < 0:
                super().onClick(control_id)     # the HUB, the film waiting
            return
        found = row.get('youtube') or {}
        if found.get('retry'):
            self._shelves[index]['_loaded'] = False
            self._scheduled.discard(index)
            return
        if found.get('video'):
            self._play(row)
        elif found.get('channel_id'):
            self._go(CHANNEL + found['channel_id'])

    def _play(self, card):
        """OK on a video: small; OK on the one playing small: big - and OK on it while it is still
        starting: big as soon as its picture is there (it is never started again: stopping a
        YouTube stream as it starts held Kodi up to 20 s)."""
        if card['youtube']['video'] != self._playing_id():
            self._start(card)
        elif self._loading:
            self._big_wanted = True
        else:
            self._big()

    def onAction(self, action):
        if action.getId() in CONTEXT:
            row, _ = self._card(self.getFocusId())
            if row is not None and (row.get('youtube') or {}).get('channel_id'):
                return self._options(row)
            return
        if action.getId() in BACK:
            self._touch()
            if self._bucket != HOME:
                self._returning = True
                try:
                    self._go(HOME)
                finally:
                    self._returning = False
            elif self._video:
                self._stop_video()
            return
        super().onAction(action)

    def _finish(self):
        if self._video:
            self._stop_video()
        super()._finish()

    def _open_settings(self):
        """MegaNexus' Settings over the app (YouTube's page among them); a new theme opens it again."""
        from .settings import run
        self._suspended = True
        try:
            command = self.over(run)
        finally:
            self._suspended = False
        if command == 'meganexus:reload':
            self._pending, self._theme_changed = 'reload', True
            self._finish()
        elif command:
            self._pending = command
            self._finish()

    # ---- the app's boxes --------------------------------------------------------------------
    def _search(self):
        self._suspended = True
        try:
            query = xbmcgui.Dialog().input('Search YouTube', getattr(self, '_yt_query', '')).strip()
        finally:
            self._suspended = False
        if query:
            self._go(SEARCH, query)

    def _channels(self):
        """Yours, to open or remove, and Add channel first."""
        mine = youtube.my_channels()
        pick = xbmcgui.Dialog().select('Channels', ['Add channel'] + [c.get('name') or c['id'] for c in mine])
        if pick == 0:
            return self._add_channel()
        if pick > 0:
            channel = mine[pick - 1]
            what = xbmcgui.Dialog().select(channel.get('name') or 'Channel', ['Open', 'Remove from your channels'])
            if what == 0:
                self._go(CHANNEL + channel['id'])
            elif what == 1:
                youtube.remove_channel(channel['id'])

    def _add_channel(self):
        query = xbmcgui.Dialog().input('Add channel - its name').strip()
        if not query:
            return
        from .play_jobs import ring_job
        try:
            found = ring_job(lambda: youtube.find_channels(query)) or []
        except Exception:
            found = None
        if not found:
            xbmcgui.Dialog().notification('YouTube', 'No channel found.' if found is not None else 'YouTube did not answer.', time=3000)
            return
        labels = ['%s%s' % (c['name'], '  ·  ' + c['subscribers'] if c.get('subscribers') else '') for c in found]
        pick = xbmcgui.Dialog().select('Add channel', labels)
        if pick >= 0:
            self._add(found[pick])
            self._go(CHANNEL + found[pick]['id'])

    def _options(self, row):
        """A card's options: play it, the channel it is from - open it, add it or remove it."""
        found = row['youtube']
        channel_id, name = found['channel_id'], found.get('channel') or 'the channel'
        mine = youtube.has_channel(channel_id)
        choices = (['Play'] if found.get('video') else []) + ['Open %s' % name] + \
                  ['Remove %s from your channels' % name if mine else 'Add %s to your channels' % name]
        pick = xbmcgui.Dialog().select(name, choices)
        if pick < 0:
            return
        choice = choices[pick]
        if choice == 'Play':
            self._play(row)
        elif choice.startswith('Open '):
            self._go(CHANNEL + channel_id)
        elif mine:
            youtube.remove_channel(channel_id)
        else:
            self._add({'id': channel_id, 'name': found.get('channel') or '', 'avatar': found.get('avatar') or ''})

    def _add(self, channel):
        if not channel.get('name'):
            from .play_jobs import ring_job
            try:
                page = ring_job(lambda: youtube.channel(channel['id'])) or {}
            except Exception:
                page = {}
            channel = dict(channel, name=page.get('name') or channel['id'], avatar=channel.get('avatar') or page.get('avatar') or '')
        youtube.add_channel(channel)
        xbmcgui.Dialog().notification('YouTube', '%s is in your channels.' % channel['name'], time=2500)


# ---- the app ------------------------------------------------------------------------------------
def _autoplay(toggle=False):
    """Autoplay: the next video by itself - off unless turned on (the player's switch, Settings › YouTube)."""
    from resources.lib import settings_snapshot
    addon = settings_snapshot.cached_addon()
    on = addon.getSetting(youtube.AUTONEXT) == 'true'
    if toggle:
        on = not on
        addon.setSetting(youtube.AUTONEXT, 'true' if on else 'false')
        settings_snapshot.invalidate()
    return on


def _wizard_done():
    """The YouTube add-on's first-start questions are behind it (its own settings say so)."""
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        return not addon.getSettingBool(WIZARD) and addon.getSettingInt(WIZARD_RUN) > 0
    except Exception:
        return True       # settings it does not have: nothing to wait for


def ready_player():
    """Kodi's YouTube add-on installed (Kodi asks) and its first-start wizard finished before the
    app opens - the first video never runs into its questions. False: not installed."""
    from .system_setup import ensure_addon
    if not ensure_addon(ADDON_ID):
        return False
    if _wizard_done():
        return True
    xbmc.executebuiltin('RunPlugin(plugin://%s/config/setup_wizard/)' % ADDON_ID)
    monitor, quiet_since = xbmc.Monitor(), time.monotonic()
    while not monitor.waitForAbort(.25):
        if _wizard_done():
            break
        if xbmc.getCondVisibility(ASKING):
            quiet_since = time.monotonic()
        elif time.monotonic() - quiet_since > WIZARD_QUIET:
            break
    return True


def forget_pictures():
    """The pictures Kodi stored for the app go once it has closed - the MegaNexus service removes
    them (youtube.forget_pictures), so the HUB never waits for it."""
    xbmc.executebuiltin('NotifyAll(meganexus,%s)' % youtube.CLOSED)


def _forget_places():
    """Where the cursor was in the app is not kept for the next time."""
    window = xbmcgui.Window(10000)
    try:
        saved = json.loads(window.getProperty('meganexus.home.focus') or '{}')
    except ValueError:
        return
    if isinstance(saved, dict):
        window.setProperty('meganexus.home.focus', json.dumps({k: v for k, v in saved.items() if not str(k).startswith(HOME)}))


def open_youtube():
    if not ready_player():
        xbmc.executebuiltin('ActivateWindow(Home)')
        return
    monitor = xbmc.Monitor()
    view, query, pending = HOME, '', ''
    try:
        while not monitor.abortRequested():
            window = YouTubeWindow(XML, ADDON.getAddonInfo('path'), theme_folder(), '1080i', shelves=shelves(view, query), bucket=view)
            window._yt_query = query
            window.setProperty('meganexus.app', 'youtube')   # before it shows: never MegaNexus' wordmark first
            cover = None
            try:
                screen_guard.hold()
                window.show_ready()
                from .trailers import lift_curtain
                lift_curtain()
                while not window._closed and not window._leaving and not monitor.abortRequested():
                    window.drain_updates()
                    monitor.waitForAbort(.05)
                pending, view, query = window._pending, window._bucket or HOME, getattr(window, '_yt_query', '')
            finally:
                if getattr(window, '_pending', None) == 'hub':
                    # the HUB first, under the app - nothing flashes between them
                    try:
                        from .play_jobs import wait_overlay
                        cover = wait_overlay('', {})
                    except Exception:
                        cover = None
                    xbmc.executebuiltin('ActivateWindow(Home)')
                    for _ in range(20):
                        if xbmc.getCondVisibility('Window.IsActive(Home)') or monitor.waitForAbort(.025):
                            break
                    monitor.waitForAbort(HUB_SETTLE_PLAIN)
                window._finish()
                window._release()
                screen_guard.release()
                if cover is not None:
                    cover.close()
            if pending == 'player':
                # Now playing: MegaNexus' film waiting behind the app
                to_player()
                from .trailers import wait_for_playback
                wait_for_playback()
                continue
            if pending == 'reload':
                if getattr(window, '_theme_changed', False):
                    from resources.lib import theme
                    theme.sync()                  # Kodi loads its skin again now, with no page open
                    monitor.waitForAbort(.5)
                continue
            if pending and pending != 'hub':
                from .system_setup import execute_command
                execute_command(pending)          # a command from Settings
            break                                 # the HUB, or the screen closed from outside
    finally:
        youtube.forget()
        _forget_places()
        forget_pictures()
        if not pending:
            xbmc.executebuiltin('ActivateWindow(Home)')
