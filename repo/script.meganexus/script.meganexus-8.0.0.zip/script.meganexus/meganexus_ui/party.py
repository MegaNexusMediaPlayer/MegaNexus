# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Watch Party on the TV (7.0.52): the screen behind the Watch Party button, and a guest's
film start.

The party itself runs in the service (party_service); this screen talks to it on
127.0.0.1 with the key in this profile. Typing (messages, names) is done on the phone:
the phone page opens from the QR code here and stays usable while the party lasts.
"""
import json
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

from . import settings_page as page

TITLE = 'Watch Party'
# 7.0.60: what the host is told before the TorBox link is shared (also on the phone)
SHARE_WARNING = ('Guests without the film play it from your TorBox link - the same link it plays from here.[CR][CR]'
                 'That link has your TorBox key in it: a guest could find it in their Kodi log. MegaNexus never '
                 'keeps it in their settings or history. Share only in parties with people you trust.')


def _api(path, body=None):
    from resources.lib.party_service import api
    found = api()
    if not found:
        raise ValueError('Watch Party starts a few seconds after Kodi. Try again in a moment.')
    port, key, _ = found
    data = json.dumps(body or {}).encode('utf-8') if body is not None or path != '/api/party/state' else None
    request = Request('http://127.0.0.1:%d%s' % (port, path), data=data, method='POST' if data is not None else 'GET',
                      headers={'X-Party-Key': key, 'Content-Type': 'application/json'})
    try:
        with urlopen(request, timeout=20) as reply:
            answer = json.loads(reply.read().decode('utf-8'))
    except ValueError:
        raise
    except Exception:
        raise ValueError('Watch Party is not running. Check HUB Settings > Watch Party.')
    if not answer.get('ok'):
        raise ValueError(answer.get('error') or 'That did not work.')
    return answer


def _plugin():
    return xbmcaddon.Addon('plugin.video.meganexus')


def _turned_on():
    """Watch Party is off on this TV: offer to turn it on (the service starts at once)."""
    if _plugin().getSetting('watch_party') != 'false':
        return True
    if not xbmcgui.Dialog().yesno(TITLE, 'Watch Party is off on this TV.[CR][CR]Turn it on?'):
        return False
    _plugin().setSetting('watch_party', 'true')
    monitor = xbmc.Monitor()
    for _ in range(30):                              # the service answers in a moment
        try:
            _api('/api/party/state')
            return True
        except ValueError:
            if monitor.waitForAbort(0.5):
                return False
    return True


def _say(text):
    xbmcgui.Dialog().notification(TITLE, text, 'special://home/addons/plugin.video.meganexus/resources/media/meganexus_icon.png', 4000)


def _phone():
    """The QR code of the party page (the same QR window as the phone setup)."""
    from resources.lib.party_service import api
    from resources.lib.plex_qr import qr_png
    from resources.lib.theme import folder as theme_folder
    from .phone_setup import PhoneWindow
    found = api()
    if not found or not found[2]:
        raise ValueError('Watch Party is not running yet.')
    url = found[2]
    window = PhoneWindow('meganexus_phone_setup.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),
                         theme_folder(), '1080i', qr=qr_png(url, box_size=10, border=2) or '', url=url,
                         title='Watch Party on your phone',
                         steps='Scan the code with the phone camera.[CR]Write messages, pause, seek and see who is in.'
                               '[CR]The page keeps working for the whole party - this screen can close.')
    window.doModal()
    del window


class _QRCorner(xbmcgui.WindowXMLDialog):
    """The QR code in a corner over the film; Back / OK closes it, so does QR_CORNER_FOR."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.qr, self.url = kwargs['qr'], kwargs['url']

    def onInit(self):
        self.setProperty('meganexus.party.qr', self.qr)
        self.setProperty('meganexus.party.qrurl', self.url)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61448, 61467, 7, 100):
            self.close()


QR_CORNER_FOR = 120.0                   # s the corner QR stays over the film


def qr_corner():
    """7.0.60: the player's Watch Party button - the phone page's QR code in a corner over the
    film, which plays on: joining from the phone without leaving the film."""
    import threading
    from resources.lib.party_service import api
    from resources.lib.plex_qr import qr_png
    from resources.lib.theme import folder as theme_folder
    found = api()
    if not found or not found[2]:
        _say('Watch Party is not running on this TV')
        return
    window = _QRCorner('meganexus_party_qr.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),
                       theme_folder(), '1080i', qr=qr_png(found[2], box_size=8, border=2) or '', url=found[2])
    timer = threading.Timer(QR_CORNER_FOR, window.close)
    timer.daemon = True
    timer.start()
    try:
        window.doModal()
    finally:
        timer.cancel()
        del window


def _find_friend():
    text = xbmcgui.Dialog().input('Friend code (8 characters) or their exact profile name')
    text = (text or '').strip()
    if not text:
        return
    from resources.lib.party_identity import clean_code
    code = clean_code(text)
    found = _api('/api/party/find', {'code': code} if code else {'name': text}).get('found') or []
    if not found:
        xbmcgui.Dialog().ok(TITLE, 'Nobody found. Names count only when that person chose "Others can find me by my name" - '
                                   'the friend code always works.')
        return
    pick = 0 if len(found) == 1 else xbmcgui.Dialog().select('Who is it?', ['%s · %s' % (f['name'], f['code']) for f in found])
    if pick < 0:
        return
    person = found[pick]
    pair = _api('/api/party/friend/add', {'public': person['public'], 'name': person['name']}).get('pair')
    xbmcgui.Dialog().ok(TITLE, 'Asked %s to be friends.[CR][CR]Your TVs both show [B]%s[/B] - check it is the same on theirs '
                               '(a call or a message) before you watch together.' % (person['name'], pair))


def _invite(state):
    friends = [f for f in state['friends'] if f['state'] == 'friend']
    if not friends:
        xbmcgui.Dialog().ok(TITLE, 'Add friends first (Friends > Add a friend) - or give people a join code.')
        return
    pick = xbmcgui.Dialog().select('Invite a friend', [f['name'] for f in friends])
    if pick >= 0:
        _api('/api/party/invite', {'public': friends[pick]['public']})
        _say('Invited %s' % friends[pick]['name'])


def open_party():
    def build():
        # 7.0.55: only what a party needs, in the order it is used; the settings made once are in
        # HUB Settings > Watch Party (settings_page below)
        state = _api('/api/party/state')
        party, rows = state['party'], []
        friends = [f for f in state['friends'] if f['state'] == 'friend']
        online = sum(1 for f in friends if f.get('online'))
        news = sum(int(f.get('unread') or 0) for f in friends) + sum(1 for f in state['friends'] if f['state'] == 'asking')
        if party:
            media = party.get('media') or {}
            if media.get('title'):
                rows.append(('media', page.item('Watching', media['title'] if party['hosting'] else '%s · select to play it' % media['title'])))
            names = ', '.join(m['name'] + (' (away)' if m.get('status') == 'away' else '') for m in party['members'])
            rows.append(('members', page.item('People · %d' % len(party['members']), names)))
            for person in party['waiting']:
                rows.append(('w:' + person['public'], page.item('%s wants to join' % person['name'], 'Select to let in')))
            if party['hosting']:
                rows.append(('invite', page.item('Invite a friend', '%d online' % online if friends else 'Add friends first')))
                rows.append(('code', page.item('Join code', party['code'] or 'For people who are not your friends')))
            rows.append(('phone', page.item('Phone remote', 'Messages, pause and seek')))
            rows.append(('leave', page.item('End the party' if party['hosting'] else 'Leave the party')))
        else:
            for invite in state['invites']:
                rows.append(('i:' + invite['party'], page.item('%s invites you' % invite['name'],
                                                               (invite.get('media') or {}).get('title') or 'Select to join')))
            rows.append(('create', page.item('Start a party', 'Then play a film - your friends get it')))
            rows.append(('join', page.item('Join with a code')))
            rows.append(('phone', page.item('Phone remote', 'Messages, pause and seek')))
        rows.append(('friends', page.item('Friends', ('%d new · ' % news if news else '') + '%d of %d online' % (online, len(friends)))))
        rows.append(('settings', page.item('Watch Party settings')))
        return rows

    def act(key):
        try:
            state = _api('/api/party/state')
            if key == 'phone':
                _phone()
            elif key == 'create':
                _api('/api/party/create', {})
                _say('Party started - play a film, or invite friends')
            elif key == 'join':
                code = xbmcgui.Dialog().input('Join code')
                if code:
                    found = _api('/api/party/join', {'code': code})
                    xbmcgui.Dialog().ok(TITLE, 'Asked %s to let you in. You are in as soon as they say yes.' % found.get('name', ''))
            elif key.startswith('i:'):
                _api('/api/party/accept', {'party': key[2:]})
                _say('You are in the party')
            elif key.startswith('w:'):
                person = next((p for p in state['party']['waiting'] if p['public'] == key[2:]), None)
                if person:
                    if xbmcgui.Dialog().yesno(TITLE, 'Let %s into the party?' % person['name']):
                        _api('/api/party/approve', {'public': person['public']})
                    else:
                        _api('/api/party/deny', {'public': person['public']})
            elif key == 'invite':
                _invite(state)
            elif key == 'code':
                code = _api('/api/party/code', {}).get('code')
                xbmcgui.Dialog().ok(TITLE, 'Join code: [B]%s[/B][CR][CR]It works for 10 minutes. You let in everyone who uses it.' % code)
            elif key == 'leave':
                if xbmcgui.Dialog().yesno(TITLE, 'End the party for everyone?' if state['party']['hosting'] else 'Leave the party?'):
                    _api('/api/party/leave', {})
            elif key == 'friends':
                from .party_chat import open_friends      # 7.0.55: like a messaging app
                open_friends(_api)
            elif key == 'settings':
                settings_page()
            elif key == 'media' and state['party'] and not state['party']['hosting']:
                _api('/api/party/play', {})                   # the host's film, on this TV
                return page.DONE
            elif key == 'members' and state['party'] and state['party']['hosting']:
                others = [m for m in state['party']['members'] if m['public'] != state['me']['public']]
                pick = xbmcgui.Dialog().select('Remove someone?', [m['name'] for m in others]) if others else -1
                if pick >= 0 and xbmcgui.Dialog().yesno(TITLE, 'Remove %s from the party?' % others[pick]['name']):
                    _api('/api/party/remove', {'public': others[pick]['public']})
        except ValueError as exc:
            xbmcgui.Dialog().ok(TITLE, str(exc))
        return None

    if not _turned_on():
        return None
    try:
        _api('/api/party/state')
    except ValueError as exc:
        xbmcgui.Dialog().ok(TITLE, str(exc))
        return None
    import threading
    done = threading.Event()
    threading.Thread(target=_close_for_film, args=(done,), name='MegaNexusPartyScreen', daemon=True).start()
    try:
        return page.keyed(TITLE, build, act)
    finally:
        done.set()


def _close_for_film(done):
    """7.0.54: the host's film starts while this screen is open (the interface starts it): the
    screen goes, it never stays over the player."""
    monitor = xbmc.Monitor()
    had = xbmc.getCondVisibility('Player.HasVideo')
    while not done.is_set() and not monitor.waitForAbort(.5):
        now = xbmc.getCondVisibility('Player.HasVideo')
        if now and not had:
            for window in list(page._STACK):
                try:
                    window.close()
                except Exception:
                    pass
            return
        had = now


HANDOVER = 'meganexus.party.start'     # Window(Home): the open interface starts the host's film
HANDOVER_WAIT = 8.0                      # an open page closes first (Dialog.doModal), then Home takes it


def play_party():
    """``RunScript(script.meganexus,party_play)`` from the service. The MegaNexus interface,
    when open, starts the film itself (7.0.53): started beside it, its Home stayed over the
    player and the film guard paused it ("started behind the HUB")."""
    import time
    home = xbmcgui.Window(10000)
    if home.getProperty('meganexus.frontend.running'):
        token = str(time.time())
        home.setProperty(HANDOVER, token)
        monitor = xbmc.Monitor()
        until = time.monotonic() + HANDOVER_WAIT
        while time.monotonic() < until:
            if home.getProperty(HANDOVER) != token:
                return True                                  # the interface took it
            if monitor.waitForAbort(.1):
                return False
        home.clearProperty(HANDOVER)                         # a page that cannot take it: here
    return play_here()


def take_handover(window):
    """The interface's Home loop: a waiting party film starts from here, like a click."""
    home = xbmcgui.Window(10000)
    if not home.getProperty(HANDOVER):
        return False
    home.clearProperty(HANDOVER)

    def start():
        started = play_here()
        if started:
            window._dialog_closed = True       # stays hidden - shown again it covered the film
        return started
    return window.child(start) is True


STARTING = 'meganexus.party.starting'   # Window(Home): a start is under way (one at a time)
START_GUARD = 60.0


def play_here():
    """A guest: the host's film, here - one start at a time (7.0.55: several in a row flickered
    the screen between the player and Home)."""
    import time
    home = xbmcgui.Window(10000)
    try:
        if time.time() - float(home.getProperty(STARTING) or 0) < START_GUARD:
            return False
    except ValueError:
        pass
    home.setProperty(STARTING, str(time.time()))
    try:
        return _play_here()
    finally:
        home.clearProperty(STARTING)


def _play_here():
    """The same release from this box's sources, else the host's shared stream, else the
    source list. True once it plays."""
    from resources.lib import backend_api, party_bridge
    from . import playback
    home = xbmcgui.Window(10000)
    try:
        data = json.loads(home.getProperty('meganexus.party.play') or '{}')
    except ValueError:
        return False
    media, share = data.get('media') or {}, data.get('share')
    if not media.get('id') or party_bridge.playing_now(media):
        return False
    if xbmc.Player().isPlayingVideo() and not data.get('asked'):
        return False        # the guest watches something else: never cut off (the service's pill says so)
    meta = {'id': media['id'], 'type': media.get('type') or 'movie', 'name': media.get('title') or '',
            'poster': media.get('poster') or '', 'background': media.get('background') or '',
            'logo': media.get('logo') or '', 'year': media.get('year') or ''}
    context = {k: media.get(k) for k in ('season', 'episode', 'video_id') if media.get(k)}
    video_id = media.get('video_id') or media['id']

    def sources():
        try:
            return backend_api.streams(meta['type'], video_id, complete=True)
        except Exception:                              # e.g. no stream add-on on this TV
            return None, []
    result = playback.job(sources, meta, True, label='Joining the party…')
    if not result:
        return False                                   # Back
    source, rows = tuple(result)[:2]
    blank = {'id': '', 'name': '', 'base_url': ''}
    row = party_bridge.match(rows or [], media.get('release'))
    if row is None and share and share.get('url'):
        row, source = {'url': share['url'], 'name': 'Shared by the host', 'title': meta['name']}, None
        party_bridge.mark_guest_link(share['url'])     # 7.0.60: played, never kept here (the host's key)
    if row is None and rows:
        xbmcgui.Dialog().notification(TITLE, 'Pick a source - the host\'s release is not in yours',
                                      'special://home/addons/plugin.video.meganexus/resources/media/meganexus_icon.png', 5000)
        return playback.play(meta, context) in (True, 'playing')
    if row is None:
        xbmcgui.Dialog().ok(TITLE, '[B]%s[/B] needs a stream add-on on this TV - the host does not share '
                                   'their stream (Share my stream, with TorBox).[CR][CR]'
                                   'Add one in HUB Settings > Add-ons, or with the quick setup on the phone (your own TorBox, '
                                   'Premiumize, Offcloud or Easynews key), then select "Watching" in Watch Party.'
                            % (meta['name'] or 'The film'))
        return False
    playback.remember_playing(meta, context, row)
    ctx = backend_api.playback_context(meta, row, source or blank, context.get('season', ''), context.get('episode', ''),
                                       video_id, 0)
    return playback._start(meta, ctx, None) is True


def settings_page():
    """HUB Settings > Watch Party (7.0.55): what is set once."""
    def on(name, default):
        # 7.0.58: read fresh each time - three of these are saved by the Watch Party service, and an
        # Addon kept from the page's start showed the old value until the page was opened again
        value = _plugin().getSetting(name)
        return default if value == '' else value == 'true'

    from resources.lib import party_bridge

    def build():
        rows = [('on', page.item('Watch Party on this TV', enabled=on('watch_party', True)))]
        torbox = party_bridge.torbox_on()
        if on('watch_party', True):
            try:
                me = _api('/api/party/state')['me']
            except ValueError:
                me = None
            rows.append(('findable', page.item('Friends can find me by name', enabled=on('watch_party_findable', False))))
            rows.append(('messages', page.item('Messages in the player', enabled=on('watch_party_messages', True))))
            rows.append(('share', page.item('Share my stream', 'Your TorBox link to the film, for guests without it'
                                            if torbox else 'Needs TorBox on this TV', enabled=on('watch_party_share', False))))
            if me:
                rows.append(('me', dict(page.item('Your friend code', me['code']), kind='info')))
                rows.append(('newkey', page.item('New phone link', 'The old link stops working')))
        return rows

    def act(key):
        try:
            if key == 'on':
                turn = not on('watch_party', True)
                if not turn and not xbmcgui.Dialog().yesno(TITLE, 'Turn Watch Party off on this TV?'):
                    return None
                _plugin().setSetting('watch_party', 'true' if turn else 'false')
            elif key in ('findable', 'messages', 'share'):
                name = {'findable': 'watch_party_findable', 'messages': 'watch_party_messages', 'share': 'watch_party_share'}[key]
                turn = not on(name, key == 'messages')
                if key == 'share' and turn and not party_bridge.torbox_on():
                    xbmcgui.Dialog().ok(TITLE, 'Share my stream needs TorBox on this TV - add your TorBox key with the '
                                               'quick setup on the phone or in HUB Settings, then turn it on.')
                    return None
                if key == 'share' and turn and not xbmcgui.Dialog().yesno(TITLE, SHARE_WARNING):
                    return None
                try:
                    _api('/api/party/setting', {'name': key, 'on': turn})     # the running party hears it at once
                except ValueError:
                    _plugin().setSetting(name, 'true' if turn else 'false')
            elif key == 'newkey':
                if xbmcgui.Dialog().yesno(TITLE, 'Make a new phone link? Phones with the old one need the new QR code.'):
                    _api('/api/party/newkey', {})
                    _phone()
        except ValueError as exc:
            xbmcgui.Dialog().ok(TITLE, str(exc))
        return None
    return page.keyed('Watch Party', build, act)
