# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import xbmc
import xbmcgui
from resources.lib import cache_store,meganexus_subtitles
from .system_setup import rpc
from .playback import job,plain_label

def pick(rows,playerid,context,request_id,enabled=False):
    groups=meganexus_subtitles.group_rows(rows)
    langs=sorted(groups,key=lambda x:(x!='hr',meganexus_subtitles.NAMES.get(x,x)))
    if not langs and not enabled:
        # 7.0.50: a TV channel has only what it sends (subtitle tracks, teletext) - nothing to search
        live=xbmc.getCondVisibility('VideoPlayer.Content(LiveTV)') or xbmc.getCondVisibility('PVR.IsPlayingTV')
        xbmc.log('[MegaNexus] Subtitles: none in this %s'%('channel' if live else 'video'),xbmc.LOGINFO)
        xbmcgui.Dialog().ok('Subtitles','This channel sends no subtitles right now.' if live else
                            'No subtitle files were returned. Try searching your subtitle add-ons.');return
    dialog=xbmcgui.Dialog()
    off=['Subtitles off'] if enabled else []
    index=dialog.select('Subtitle language',off+[meganexus_subtitles.NAMES.get(l,l)+' · '+str(len(groups[l]))+' versions' for l in langs])
    if index<0:return
    if off:
        if index==0:
            xbmc.Player().showSubtitles(False);return
        index-=1
    candidates=groups[langs[index]];labels=[]
    title=meganexus_subtitles.NAMES.get(langs[index],langs[index])
    for i,row in enumerate(candidates):
        release=plain_label(row.get('displayName') or row.get('name') or row.get('release') or row.get('filename')) or 'Version '+str(i+1)
        source=plain_label(row.get('sourceName') or ('Embedded track' if row.get('embedded') else 'Subtitle provider'))
        labels.append('%d. %s — %s'%(i+1,release,source))
    player=xbmc.Player()
    while True:
        index=dialog.select(title,labels)
        if index<0:return
        row=candidates[index]
        if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
        if row.get('embedded'):
            rpc('Player.SetSubtitle',{'playerid':playerid,'subtitle':row['index'],'enable':True})
            meganexus_subtitles.remember_active('')   # the video's own track: nothing to sync
            return
        try:path=job(lambda:meganexus_subtitles.prepare_selected(row,context.get('video_id') or context.get('canonical_id') or 'selected'),label='Loading the subtitle…',quiet=True)
        except ValueError:
            # 7.0.29: its server did not deliver it - the list comes back for another version
            xbmcgui.Dialog().notification('Subtitles','This version could not be downloaded - choose another.',time=3500)
            labels[index]='✕ '+labels[index].lstrip('✕ ')
            continue
        if not path:return
        break
    # Downloads can finish after a channel/title switch. Never apply to another video.
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    player.setSubtitles(path);player.showSubtitles(True)
    meganexus_subtitles.remember_active(path,row)

def run():
    try:
        active=next((p for p in rpc('Player.GetActivePlayers') or [] if p['type']=='video'),None)
        if not active:return
        playerid=active['playerid'];player=xbmc.Player();request_id=player.getPlayingItem().getProperty('meganexus.request')
        xbmcgui.Window(10000).setProperty('meganexus.subtitle.manual',request_id)
        key=xbmcgui.Window(10000).getProperty('meganexus.subtitle.context')
        context=cache_store.get('meganexus_play',key) or {}
        if context.get('meganexus_request_id')!=request_id:context={}
        props=rpc('Player.GetProperties',{'playerid':playerid,'properties':['subtitles','subtitleenabled']}) or {}
        embedded=[dict(s,embedded=True,sourceName='Embedded track',lang=s.get('language')) for s in props.get('subtitles') or []]
        # 7.0.24: the player's subtitle button searches every subtitle add-on at
        # once and lists all versions (the timing has its own button).
        if context:
            rows=job(lambda:meganexus_subtitles.external_rows(context,search=True),label='Searching subtitles…',quiet=True)
            if rows is None:return
            rows=embedded+rows
        else:rows=embedded   # not started through MegaNexus: the video's own tracks
        pick(rows,playerid,context,request_id,enabled=props.get('subtitleenabled'))
    except Exception as exc:
        xbmcgui.Dialog().ok('Subtitles',str(exc) if isinstance(exc,ValueError) else 'Subtitle selection could not finish. Try another file or provider.')


SYNC_TRIES='meganexus.subtitle.sync_tries'   # Window(Home): {request, attempt, tried} of this playback
SYNC_LABELS={1:'Syncing subtitles…',2:'Syncing subtitles · a closer look…',3:'Syncing subtitles · another subtitle…'}


def autosync():
    """7.0.29: the player's Autosync subtitle button - retime the subtitle on screen."""
    player=xbmc.Player()
    if not player.isPlayingVideo():return
    request_id=player.getPlayingItem().getProperty('meganexus.request')
    key=xbmcgui.Window(10000).getProperty('meganexus.subtitle.context')
    context=cache_store.get('meganexus_play',key) or {}
    if context.get('meganexus_request_id')!=request_id:context={}
    if not context:
        xbmcgui.Dialog().notification('Autosync subtitle','Works on titles started in MegaNexus.',time=4000);return
    try:duration=float(player.getTotalTime() or 0)   # 7.0.45: the film's length tells its version and a subtitle that fits
    except Exception:duration=0
    import json
    home=xbmcgui.Window(10000)
    # 7.0.50: each press on this film goes further (more subtitles, piece by piece, then another
    # subtitle in your language) - the count and the subtitles tried belong to this playback
    try:tries=json.loads(home.getProperty(SYNC_TRIES) or '{}')
    except ValueError:tries={}
    if tries.get('request')!=request_id:tries={'request':request_id,'attempt':0,'tried':[]}
    tries['attempt']=attempt=int(tries.get('attempt') or 0)+1
    label=SYNC_LABELS.get(attempt,SYNC_LABELS[3])
    home.setProperty('meganexus.subtitle.syncing',label)   # 7.0.45: the player's pill
    try:
        try:result=job(lambda:meganexus_subtitles.autosync(context,context.get('video_id') or context.get('canonical_id') or 'sync',
                                                           duration=duration,attempt=attempt,tried=tries['tried']),label=label,quiet=True)
        except ValueError as exc:   # 7.0.45: told in passing, the film plays on - no dialog to close
            home.setProperty(SYNC_TRIES,json.dumps(tries))
            xbmc.log('[MegaNexus] Autosync subtitle (press %d): %s'%(attempt,exc),xbmc.LOGINFO)   # 7.0.50: why, in the log
            xbmcgui.Dialog().notification('Autosync subtitle',str(exc),time=8000);return
    finally:
        home.clearProperty('meganexus.subtitle.syncing')
    if result and len(result)>2 and isinstance(result[2],dict) and result[2].get('url'):
        tries['tried'].append(str(result[2]['url']))
    home.setProperty(SYNC_TRIES,json.dumps(tries))
    if not result:return
    path,what=result[:2]
    xbmc.log('[MegaNexus] Autosync subtitle (press %d): %s'%(attempt,what),xbmc.LOGINFO)
    if len(result)>2:   # 7.0.45: another subtitle in your language, one that belongs to this film
        home.setProperty('meganexus.subtitle.row',json.dumps(result[2]))
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    if not what.startswith('Already in sync'):
        player.setSubtitles(path);player.showSubtitles(True)
        home.setProperty('meganexus.subtitle.path',path)
    xbmcgui.Dialog().notification('Autosync subtitle',what,time=5000)
    # 7.0.45: kept with the film while it is in Continue Watching - not synced again next time
    try:row=result[2] if len(result)>2 else json.loads(home.getProperty('meganexus.subtitle.row') or '{}')
    except ValueError:row={}
    try:meganexus_subtitles.keep_synced(context,path,row)
    except Exception as exc:xbmc.log('[MegaNexus] kept subtitle not saved: %s'%exc,xbmc.LOGINFO)
