# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Local storage (6.0.37): HUB Settings > Local storage and playback of the
"Local Movies" / "Local Series" Home rows (Kodi's own video library)."""
import xbmcgui
from resources.lib import local_media, settings_cache
from . import settings_page as page

ADDON = settings_cache.cached_addon()
HELP = ('Kodi opens Videos > Files.\n\n'
        '1. Choose [B]Add videos...[/B] and browse to the folder (USB disk, NAS, SMB/NFS share).\n'
        '2. Confirm. MegaNexus reads the folder itself - the titles appear in the '
        '[B]Local Movies[/B] and [B]Local Series[/B] rows on Home and in the Library.\n'
        '3. Optional: [B]This directory contains[/B] Movies / TV shows lets Kodi add plots and ratings.\n\n'
        'Movies work best as "Title (Year)" folders, series as "Show/Season 1/S01E01".')


def _clock(seconds):
    seconds = int(seconds or 0)
    hours, rest = divmod(seconds, 3600)
    return '%d:%02d:%02d' % (hours, rest // 60, rest % 60) if hours else '%d:%02d' % (rest // 60, rest % 60)


def _covered(start, title=''):
    """7.0.52: a local film starts like every other - the loading screen stays over the
    screen it came from until the film is on screen (HUB showed for a moment in between).
    ``start()``: True when Kodi took the file. Returns whether the video plays."""
    import time
    import xbmc
    from resources.lib.theme import folder as theme_folder
    from .playback import Loading, ROOT, _hide_parents
    win = Loading('meganexus_loading.xml', ROOT, theme_folder(), '1080i', meta={'name': title}, full=True,
                  label='Starting playback')
    win.show()
    _hide_parents()                       # Home under the loading screen; back by itself on failure
    try:
        if not start():
            return False
        monitor, player = xbmc.Monitor(), xbmc.Player()
        until = time.monotonic() + 10
        while not player.isPlayingVideo():
            if time.monotonic() > until or monitor.waitForAbort(.1):
                return False
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
        until = time.monotonic() + 3
        while not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') and time.monotonic() < until:
            if monitor.waitForAbort(.05):
                break
        return True
    finally:
        try:
            win.close()
        except Exception:
            pass


def _play(kind, item_id):
    """Ask Resume / From the beginning like Kodi does; '' when cancelled."""
    position = local_media.resume_seconds(kind, item_id)
    resume = False
    if position > 0:
        pick = xbmcgui.Dialog().contextmenu(['Resume from %s' % _clock(position), 'Play from the beginning'])
        if pick < 0:
            return ''
        resume = pick == 0
    if not _covered(lambda: local_media.play(kind, item_id, resume)):
        xbmcgui.Dialog().notification('Local storage', 'This file could not be opened. Is the drive connected?', time=4000)
        return ''
    return 'playing'


def _episode_item(episode):
    label = '%dx%02d  %s' % (int(episode.get('season') or 0), int(episode.get('episode') or 0), episode.get('title') or episode.get('label') or '')
    resume = episode.get('resume') or {}
    position, total = float(resume.get('position') or 0), float(resume.get('total') or 0)
    if position > 0 and total > 0:
        state = '%d%% watched' % int(position * 100 / total)
    else:
        state = 'Watched' if episode.get('playcount') else ''
    li = xbmcgui.ListItem(label, '  ·  '.join(x for x in (state, str(episode.get('firstaired') or '')[:4]) if x))
    art = episode.get('art') or {}
    li.setArt({'thumb': art.get('thumb') or art.get('season.poster') or art.get('tvshow.poster') or ''})
    return li


def _series(show):
    seasons = local_media.seasons(show['id'])
    season = None
    if len(seasons) > 1:
        labels = []
        for row in seasons:
            left = int(row.get('episode') or 0) - int(row.get('watchedepisodes') or 0)
            labels.append(xbmcgui.ListItem(row.get('label') or 'Season %s' % row.get('season'),
                                           '%d episodes%s' % (row.get('episode') or 0, ' · %d new' % left if left and row.get('watchedepisodes') else '')))
        first = next((i for i, row in enumerate(seasons) if int(row.get('watchedepisodes') or 0) < int(row.get('episode') or 0)), 0)
        pick = xbmcgui.Dialog().select(show.get('title') or 'Seasons', labels, preselect=first, useDetails=True)
        if pick < 0:
            return ''
        season = seasons[pick].get('season')
    elif seasons:
        season = seasons[0].get('season')
    episodes = local_media.episodes(show['id'], season)
    if not episodes:
        xbmcgui.Dialog().notification('Local storage', 'No episodes found for this series.', time=3000)
        return ''
    pick = xbmcgui.Dialog().select(show.get('title') or 'Episodes', [_episode_item(e) for e in episodes],
                                   preselect=local_media.next_episode(episodes), useDetails=True)
    if pick < 0:
        return _series(show) if len(seasons) > 1 else ''
    return _play('episode', episodes[pick]['episodeid'])


def _play_file(path, title):
    """7.0.29: a video file MegaNexus found in the folders (Kodi keeps its resume point)."""
    import xbmc
    from resources.lib.wallpaper_video import foreground
    foreground()
    item = xbmcgui.ListItem(title, path=path)
    try:item.getVideoInfoTag().setTitle(title)
    except Exception:pass
    if _covered(lambda: xbmc.Player().play(path, item) or True, title):
        return 'playing'
    xbmcgui.Dialog().notification('Local storage', 'This file could not be opened. Is the drive connected?', time=4000)
    return ''


def _file_series(local):
    episodes = local.get('episodes') or []
    if not episodes:
        return ''
    labels = [xbmcgui.ListItem('S%02d E%02d' % (int(e['season']), int(e['episode'])), e['path'].rsplit('/', 1)[-1])
              for e in episodes]
    pick = xbmcgui.Dialog().select(local.get('title') or 'Episodes', labels, useDetails=True)
    if pick < 0:
        return ''
    chosen = episodes[pick]
    return _play_file(chosen['path'], '%s · S%02d E%02d' % (local.get('title') or '', int(chosen['season']), int(chosen['episode'])))


def open_item(local):
    """A click on a Local row card: 'playing', a Kodi window command or ''."""
    kind = local.get('type')
    if kind == 'file':
        return _play_file(local['path'], local.get('title') or '')
    if kind == 'file_series':
        return _file_series(local)
    if kind == 'all':
        return local_media.library_window(local.get('kind'))
    if kind == 'movie':
        return _play('movie', local['id'])
    if kind == 'series':
        return _series(local)
    return ''


def _home_rows(value=None):
    on = local_media.enabled(ADDON) if value is None else value
    ADDON.setSetting(local_media.HOME_SETTING, 'true' if on else 'false')
    settings_cache.invalidate()


def run():
    def rows():
        have = local_media.counts()
        folders = len(local_media.sources())
        from resources.lib import local_files
        found = local_files.cached() or {}
        if not have['movie'] and found.get('movies'):have['movie'] = len(found['movies'])
        if not have['series'] and found.get('shows'):have['series'] = len(found['shows'])
        return [page.item('Show on Home · Local Movies and Local Series', enabled=local_media.enabled(ADDON)),
                page.item('On this device', '%d movies · %d series' % (have['movie'], have['series'])),
                page.item('Add a folder · Kodi video sources', '%d folder%s' % (folders, '' if folders == 1 else 's')),
                page.item('Scan folders for new files'),
                page.item('Remove missing files from the list'),
                page.item('Back')]

    def choose(pick):
        if pick == 0:
            _home_rows(not local_media.enabled(ADDON))
        elif pick == 1:
            local_media.forget_counts()
        elif pick == 2:
            if not xbmcgui.Dialog().yesno('Add a folder', HELP, nolabel='Cancel', yeslabel='Open Kodi'):
                return None
            _home_rows(True)   # whoever adds a folder wants to see it on Home
            local_media.forget_counts()
            return local_media.SOURCES_WINDOW
        elif pick == 3:
            local_media.scan()
            xbmcgui.Dialog().notification('Local storage', 'Scanning your folders. New titles appear on Home.', time=3000)
        elif pick == 4:
            local_media.clean()
            xbmcgui.Dialog().notification('Local storage', 'Removing files that are no longer there.', time=3000)
        elif pick == 5:
            return page.DONE
        return None
    return page.show('Local storage (beta)', rows, choose)
