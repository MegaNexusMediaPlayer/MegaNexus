# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus interface entry point."""
import os
import sys
import threading
import time
import uuid
import xbmc
import xbmcaddon
import xbmcgui

backend = xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('path')
for path in (backend, os.path.join(backend, 'resources', 'lib')):
    if path not in sys.path: sys.path.insert(0, path)

try:  # 7.0.52: player questions never stop all Python while a Usenet film closes
    from resources.lib.player_state import install as _safe_player
    _safe_player()
except Exception:
    pass

home = xbmcgui.Window(10000)
try:
    # 7.0.21: opened before the service carried out a requested reset.
    from resources.lib import factory_reset
    factory_reset.apply()
except Exception as exc:
    xbmc.log('[MegaNexus] factory reset check failed: %s' % exc, xbmc.LOGERROR)
try:
    # 7.0: opened before the service moved the previous installation.
    from resources.lib import rename_migration
    rename_migration.run()
except Exception as exc:
    xbmc.log('[MegaNexus] move from previous IDs failed: %s' % exc, xbmc.LOGERROR)
# 9.1.3: set once this run is over - the close report (below) ends with it. Kodi frees a script only after its last
# thread ended: the report waiting for Kodi to close kept every run (each Home, game, quiz) in memory until then
_RUN_OVER=threading.Event()

def finish_jobs():
    _RUN_OVER.set()
    module=sys.modules.get('meganexus_ui.play_jobs')
    if module:
        # JobPool.shutdown takes nothing: it cancels what is queued and closes its
        # executor without waiting. One pool refusing must not take the others, or
        # the rest of this (script_exit, the busy-thread report) never runs.
        for pool in (module._JOBS, module._BACKGROUND, module._CATALOG):
            try:
                pool.shutdown()
            except Exception as exc:
                xbmc.log('[MegaNexus] pool did not close: %s' % exc, xbmc.LOGWARNING)
    try:
        from resources.lib import script_exit
        script_exit.stop()   # 7.0.5: idle workers kept Kodi from closing
    except Exception:
        pass
    try:
        # 8.1.2: a backstop for the windows doModal did not drive (closed another way, or
        # built and dropped). Kodi prints what Python still holds at this point - six
        # WindowXMLDialogs in one session here - and keeps every one of them registered,
        # controls and all. Dialog._release breaks the cycle where it can; this collects
        # whatever is left while the interpreter is still ours.
        import gc
        gc.collect()
    except Exception:
        pass
    if xbmc.Monitor().abortRequested():
        # 7.0.29: what is still busy while Kodi closes (it hung waiting on it).
        import threading
        busy=[t.name for t in threading.enumerate() if t is not threading.current_thread() and t.is_alive()]
        if busy:xbmc.log('[MegaNexus] Interface still running at exit: %s'%', '.join(sorted(busy)),xbmc.LOGINFO)

def _report_at_close():
    """8.1.5: where every thread of the interface stands once Kodi closes (1.5 s on).
    Kodi waits 5 s for this script and then kills it; this says what it waited for. 9.1.3: only while this run lasts -
    a run that ended without Kodi closing has nothing to report, and its watch must not hold it."""
    def watch():
        monitor=xbmc.Monitor()
        while not _RUN_OVER.is_set():
            if monitor.waitForAbort(.5):break
        if not monitor.abortRequested():return
        time.sleep(1.5)
        import traceback
        frames=sys._current_frames()
        for thread in threading.enumerate():
            if thread is threading.current_thread() or not thread.is_alive():continue
            stack=traceback.extract_stack(frames.get(thread.ident)) if thread.ident in frames else []
            where=' < '.join('%s:%d %s'%(f.filename.rsplit('/',1)[-1],f.lineno,f.name) for f in reversed(stack[-4:]))
            xbmc.log('[MegaNexus] Kodi is closing - %s%s at %s'%(thread.name,'' if thread.daemon else ' (waited for)',where or '?'),xbmc.LOGINFO)
    threading.Thread(target=watch,name='MegaNexusCloseReport',daemon=True).start()


def launch():
    _report_at_close()
    token=uuid.uuid4().hex
    home.setProperty('meganexus.frontend.running', token)
    import meganexus_ui.dialog as _dialog
    _dialog.FRONTEND=True   # 7.0.55: this run's pages make way for a Watch Party film (party.take_handover)
    session=None
    try:
        from resources.lib.saver_state import wake_for_entry
        wake_for_entry()
        # 7.0.16: the HUB picture first - on Android the rest of the start takes a
        # moment and Kodi showed its own busy spinner meanwhile.
        from resources.lib import interface_colors
        interface_colors.publish()
        if mode not in ('settings','skinsettings','themes','badges','iptv','sports'):
            # 7.0.42: Sport and IPTV open right over the HUB (its hidden video control
            # serves their previews): no base picture flashing in or out
            from meganexus_ui.session_window import open_session
            session=open_session(entering=True)   # 9.1.1: the HUB's picture darkens to ours instead of at once
        from resources.lib import settings_snapshot
        from meganexus_ui.system_setup import execute_command
        settings_snapshot.invalidate()
        from resources.lib.presentation_settings import sync as sync_appearance
        sync_appearance()
        try:
            from resources.lib import theme
            # MegaNexus skin follows the chosen theme (6.0.28); 7.0.45: once Kodi has loaded
            # its skin again for it - that closed the first-start setup opening meanwhile
            theme.sync_and_settle()
        except Exception:xbmc.log('[MegaNexus] Theme sync skipped.',xbmc.LOGWARNING)
        try:
            from resources.lib.seek_profile import apply
            apply()
        except Exception:xbmc.log("[MegaNexus] Could not restore original Kodi seek controls.",xbmc.LOGWARNING)
        if mode == 'iptv':
            from meganexus_ui.iptv import open_iptv
            open_iptv()
        elif mode == 'sports':
            # 6.0.35: sports add-ons have their own screen (GitHub issue #8).
            from meganexus_ui.sports import open_sports
            open_sports()
        elif mode == 'youtube':
            # 9.0.6: the HUB's YouTube app - MegaNexus' Home with YouTube in it
            from meganexus_ui.youtube import open_youtube
            open_youtube()
        elif mode == 'poker':
            # Poker (games branch): Texas Hold'em round the TV's table, each player's cards on their phone
            from meganexus_ui.poker import open_poker
            open_poker()
        elif mode == 'quiz':
            # Guess It (games branch): MegaNexus' own party quiz - its screen and the phones' page while it is open
            from meganexus_ui.quiz import open_quiz
            open_quiz()
        elif mode == 'games':
            # the HUB's Games app (games branch) - MegaNexus' Home with games in it; nothing of it runs once closed
            from meganexus_ui.games import open_games
            open_games()
        elif mode == 'music':
            # 9.0.6: the HUB's Music app - MegaNexus' Home with the music in it; it plays on when the app closes
            from meganexus_ui.music import open_music
            open_music()
        elif mode == 'wizard':
            from meganexus_ui.onboarding import run as setup
            command=setup(force=True)
            if command:execute_command(command)
            from meganexus_ui.home_window import open_home
            if not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):open_home()
        elif mode == 'phone':
            # HUB / backend entry: after Save on the phone MegaNexus starts.
            from meganexus_ui.phone_setup import run as phone
            if phone():
                from meganexus_ui.onboarding import _finish
                _finish()
                from meganexus_ui.home_window import open_home
                open_home()
            else:xbmc.executebuiltin('ActivateWindow(Home)')
        elif mode == 'badges':
            from meganexus_ui.settings import badge_settings
            command=badge_settings()
            if command:execute_command(command)
        elif mode == 'themes':
            from meganexus_ui.settings import themes_screensaver
            command=themes_screensaver()
            if command:execute_command(command)
        elif mode == 'skinsettings':
            from meganexus_ui.settings import run
            command=run(back_command='ActivateWindow(Home)')
            if command:execute_command(command)
        elif mode == 'settings':
            from meganexus_ui.settings import run
            command=run()
            if command:execute_command(command)
            else:xbmc.executebuiltin('ActivateWindow(Home)')
        elif mode == 'open' and len(sys.argv) > 2:
            from resources.lib.meganexus import keyed_cache
            from meganexus_ui.details import open_context
            command = open_context(keyed_cache.get('meganexus_open', sys.argv[2]) or {})
            if isinstance(command,dict) and 'trailer' in command:
                from meganexus_ui.trailers import play_trailer,wait_for_playback
                if play_trailer(command['trailer']):wait_for_playback()
                command=''
            if command=='playing':
                xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
            elif command: xbmc.executebuiltin(command)
        else:
            # 7.0: MegaNexus Skin is required. Nothing else starts (system check,
            # first-start setup) until it is active, so Kodi's "Keep this skin?"
            # question is never covered.
            from resources.lib import skin_activation
            if xbmc.getSkinDir()!=skin_activation.SKIN:
                # "No" in Kodi's question is respected this session (no second ask).
                status=skin_activation.switch() if skin_activation.wanted() else 'declined'
                if status!='ok':
                    if status=='failed':skin_activation.report_failure()
                    elif status!='busy':skin_activation.tell_needed()   # busy: the other entry asks
                    return
            # 7.0.51: Kodi may still be asking "Keep this skin?" (the skin already loaded, or
            # another MegaNexus entry switched it) - nothing opens over that question, and
            # without the skin kept the setup does not start at all
            if not skin_activation.settled():
                if xbmc.getSkinDir()!=skin_activation.SKIN:skin_activation.tell_needed()
                return
            try:
                # 6.0.37: add-ons that overload Kodi - clean install, turn off or Skip.
                from meganexus_ui.system_check import run as system_check
                system_check()
            except Exception:xbmc.log('[MegaNexus] System check skipped.',xbmc.LOGWARNING)
            from meganexus_ui.onboarding import run as setup
            command=setup()
            if command:execute_command(command)
            try:
                # 9.0.0: once - pictures through vfs.meganexus where the update kept the proxy
                from meganexus_ui.settings import offer_native_pictures
                offer_native_pictures()
            except Exception:xbmc.log('[MegaNexus] Picture path offer skipped.',xbmc.LOGWARNING)
            from meganexus_ui.home_window import open_home
            if not xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):open_home()
    except Exception:
        import traceback
        # The cause belongs in kodi.log (6.0.37): the message alone hid it.
        xbmc.log('[MegaNexus] Interface failed: ' + traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('MegaNexus', 'Could not open the interface. Open MegaNexus settings to repair the bundled components or check your provider configuration.')
    finally:
        if session:session.close()
        finish_jobs()
        if home.getProperty('meganexus.frontend.running')==token:
            home.clearProperty('meganexus.frontend.running')


mode = sys.argv[1] if len(sys.argv) > 1 else 'home'
if mode=='subtitles':
    from meganexus_ui.subtitle_dialogs import run
    try:run()
    finally:finish_jobs()
elif mode=='keyboard_pick':
    # 7.0.45: a suggestion pill on the keyboard searches at once (as Enter), not only fills the line.
    import json
    text=sys.argv[2].strip() if len(sys.argv)>2 else ''
    if text:xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Input.SendText','params':{'text':text,'done':True}}))
elif mode=='reboot_recovery':
    # 7.0.45: Power menu on CoreELEC dual boot - restart into recovery (TWRP).
    from meganexus_ui.power import reboot_recovery
    try:reboot_recovery()
    finally:finish_jobs()
elif mode=='party':
    # 7.0.52: the Watch Party button
    from meganexus_ui.party import open_party
    try:open_party()
    finally:finish_jobs()
elif mode=='party_qr':
    # 7.0.60: the player's Watch Party button - the QR code in a corner over the film
    from meganexus_ui.party import qr_corner
    try:qr_corner()
    finally:finish_jobs()
elif mode=='party_play':
    # 7.0.52: Watch Party - the host's film, here
    from meganexus_ui.party import play_party
    try:play_party()
    finally:finish_jobs()
elif mode=='ai_translate':
    # 8.1.3: the player's AI button - translates in this run, in the background of the film
    from meganexus_ui.subtitle_dialogs import ai_translate
    try:ai_translate()
    except Exception:xbmc.log('[MegaNexus] AI subtitles: '+__import__('traceback').format_exc(),xbmc.LOGWARNING)
    finally:finish_jobs()
elif mode=='autosync':
    # 7.0.29: the player's Autosync subtitle button.
    from meganexus_ui.subtitle_dialogs import autosync
    try:autosync()
    finally:finish_jobs()
elif mode=='audio':
    # 7.0.24: the player's audio button.
    from meganexus_ui.audio_streams import run
    try:run()
    finally:finish_jobs()
elif mode=='switch_source':
    # 7.0.29: the player's Sources button - pause, choose another source, carry on.
    from meganexus_ui.play_jobs import switch_source
    try:switch_source()
    finally:finish_jobs()
elif mode=='music_mini':
    # 9.0.6: the small player by the music in the corner of every screen - over whatever is open
    from meganexus_ui.music import open_mini
    try:open_mini(auto=sys.argv[2:3]==['auto'])   # 'auto': opened by a song starting - it goes by itself
    finally:finish_jobs()
elif mode=='downloads':
    # 7.0.29: the corner's download ring - the progress box (or the list).
    from meganexus_ui.downloads import progress
    try:progress()
    finally:finish_jobs()
elif mode=='phonetype':
    # 7.0.29: the keyboard's "Write with phone" (also while MegaNexus is open).
    from meganexus_ui.phone_setup import write_with_phone
    try:write_with_phone()
    finally:finish_jobs()
elif mode=='profiles':
    # 7.0.45: who is watching - Kodi's first screen, over the HUB while it gets ready
    try:
        from meganexus_ui.profiles import at_start
        at_start()
    except Exception:
        import traceback
        xbmc.log('[MegaNexus] Profiles failed: '+traceback.format_exc(),xbmc.LOGERROR)
    finally:
        finish_jobs()
elif mode=='player_home':
    # 7.0.29: the player's Home button - the film pauses, "Now playing" brings it back.
    from resources.lib.foreground_guard import park
    park()
elif mode=='tracking-check':
    import json,time
    from resources.lib.tracking_connections import check_connections
    try:
        result=check_connections();result['checked_at']=time.time()
        home.setProperty('meganexus.tracking.check',json.dumps(result))
    finally:finish_jobs()
elif mode=='saverpreview':
    # 7.0.25: "Show on TV" of the phone page - the screensaver over the QR
    # screen until a key is pressed.
    from meganexus_ui.saver import preview
    try:preview()
    finally:finish_jobs()
elif home.getProperty('meganexus.frontend.running'):
    # One modal interface at a time, including on skin reload/activation.
    pass
else:
    restarting=False
    try:
        # An installed update waiting for a Kodi restart: ask before the
        # interface opens ("Later" asks again at the next entry).
        from resources.lib import updater
        restarting=updater.prompt_at_entry()
    except Exception:
        xbmc.log('[MegaNexus] Restart reminder skipped.',xbmc.LOGDEBUG)
    if not restarting:
        launch()
