# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Poker (HUB's Games row): the table on the TV, each player's cards and moves on their phone.

"Texas Holdem za vise osoba na uzor guess it ... 3d stol playeri oko stola tj imena kad se preimenuju na mobitelu a
na mobitelu vidimo karte i kontrole i koliko para stavljamo". The lobby is Guess It's: how many chips, which blinds,
how long a move may take - and the phones' code; Start seats every phone in (2 to 8). Then hand after hand
(resources.lib.poker plays them) until one player has every chip; the blinds double every RISE hands. The TV shows
the table (meganexus_poker.xml, review/make_poker_window.py) - nobody's cards until they are shown; each phone gets
its own two cards and, on its turn, what it may do. A move not made in time (or a phone gone) checks when it can,
else folds. Back twice ends the game (the lobby); Back in the lobby leaves Poker. Nothing of it runs once closed.
"""
import os
import queue
import time

import xbmc
import xbmcgui

from resources.lib import games, poker, screen_guard
from resources.lib.play_server import PlayServer
from resources.lib.theme import folder as theme_folder
from .home_window import ADDON
from .quiz import LEAVE_AGAIN, QuizWindow

XML = 'meganexus_poker.xml'
MEDIA = 'special://home/addons/skin.meganexus/media/meganexus/poker/'
CHIPS = (1000, 2000, 5000, 10000)
BLINDS = ((5, 10), (10, 20), (25, 50), (50, 100))
CLOCKS = ((30, '30 seconds'), (60, 'A minute'), (0, 'No limit'))
RISE = 10                        # hands between the blinds doubling
GONE_WAIT = 10.0                 # s a player whose phone is gone has before the table moves for them
SHOW_HAND = 6.0                  # s the hand's end stays (OK goes on)
TICK = .1
CHOICE = {801: 'chips', 802: 'blinds', 803: 'clock'}
SIZES = {'chips': len(CHIPS), 'blinds': len(BLINDS), 'clock': len(CLOCKS)}
# where each player sits for 2 ... 8 players: places of the eight round the table (0 at the front), spread out
PLACES = {2: (0, 4), 3: (0, 3, 5), 4: (0, 2, 4, 6), 5: (0, 2, 3, 5, 6), 6: (0, 1, 3, 4, 5, 7), 7: (0, 1, 2, 3, 5, 6, 7),
          8: tuple(range(8))}
STREETS = {'preflop': 'PRE-FLOP', 'flop': 'FLOP', 'turn': 'TURN', 'river': 'RIVER', 'showdown': 'SHOWDOWN', 'won': ''}
SEAT_KEYS = ('name', 'initial', 'chips', 'said', 'turn', 'folded', 'out', 'card1', 'card2', 'bet', 'dealer', 'blind',
             'hand', 'win', 'timer')
# a seat's colour is read from Home's window: a colour looked up on this one would come from any box over it
TINT = 'meganexus.poker.seat.%d.colour'


def money(amount):
    return '{:,}'.format(amount)


def card(code):
    return MEDIA + 'cards/%s.png' % code


def tint(colours=('',) * 8):
    home = xbmcgui.Window(10000)
    for place, colour in enumerate(colours):
        home.setProperty(TINT % place, colour)


class Game(object):
    def __init__(self, window, server):
        self.window, self.server = window, server
        self.choice = {'chips': 1, 'blinds': 1, 'clock': 0}
        self.moves = queue.Queue()
        self.monitor = xbmc.Monitor()
        self.closing = False
        self.leave_until = 0.0
        self.places = {}

    # ---- the screen -------------------------------------------------------------------------------------------
    def show(self, **values):
        for name, value in values.items():
            self.window.setProperty('poker.' + name, '' if value is None else str(value))

    def pressed(self, wait):
        """What was pressed, waiting in Kodi's own wait (the only one that lets the window's keys through)."""
        if self.window.pressed.empty():
            self.monitor.waitForAbort(wait)
        if self.leave_until and time.monotonic() > self.leave_until:
            self.leave_until = 0.0
            self.show(hint='')
        try:
            return self.window.pressed.get_nowait()
        except queue.Empty:
            return None

    def leaving(self):
        """Back in a game: the first one says so, a second one within LEAVE_AGAIN seconds ends it (the lobby)."""
        if self.leave_until:
            self.leave_until = 0.0
            self.show(hint='')
            return True
        self.leave_until = time.monotonic() + LEAVE_AGAIN
        self.show(hint='Press Back again to end this game')
        return False

    def roster(self):
        return sorted(self.server.roster(), key=lambda p: p['slot']) if self.server else []

    # ---- the lobby -------------------------------------------------------------------------------------------
    def lobby_words(self):
        small, big = BLINDS[self.choice['blinds']]
        self.show(chips=money(CHIPS[self.choice['chips']]), blinds='%d / %d' % (small, big),
                  clock=CLOCKS[self.choice['clock']][1])
        roster = self.roster()
        self.show(players='[CR]'.join('[COLOR FF%s]●[/COLOR]  %s' % (p['colour'].lstrip('#').upper(), p['name']) for p in roster)
                  or 'No phone yet - scan the code.')

    def lobby(self):
        """The game's choices, then Start ('start' - two phones at least) or 'close'."""
        self.show(phase='lobby', strip='', status='The blinds double every %d hands.' % RISE)
        if self.server:
            self.server.set_table({'phase': 'lobby'})
        self.window.setFocusId(804)
        while not self.monitor.abortRequested():
            self.lobby_words()
            key = self.pressed(.25)
            if key in CHOICE:
                name = CHOICE[key]
                self.choice[name] = (self.choice[name] + 1) % SIZES[name]
            elif key == 804:
                if len(self.roster()) >= 2:
                    return 'start'
                self.show(status='Two players at least: each scans the code with a phone.')
            elif key in (805, 'back'):
                return 'close'
        return 'close'

    # ---- the table on the screen and on the phones -----------------------------------------------------------
    def refresh(self, table, left=None):
        """The TV's table and every phone's: the public table to all, each one's cards and moves to them."""
        roster = {p['slot']: p for p in self.roster()}
        for seat in table.seats:                          # a name changed on its phone shows at once
            if seat['slot'] in roster:
                seat['name'] = roster[seat['slot']]['name']
        public = table.public()
        result = public['result'] or {}
        # every place's values worked out first and each property set once: emptied and filled again, a frame Kodi
        # draws in between would blink the table every second
        places = {place: dict.fromkeys(SEAT_KEYS, '') for place in range(8)}
        tints = [''] * 8
        for seat in public['seats']:
            place = self.places.get(seat['slot'])
            if place is None:
                continue
            person = roster.get(seat['slot'])
            shown = isinstance(seat['cards'], list)
            cards = seat['cards'] if shown else (['back', 'back'] if seat['cards'] and not seat['folded'] else [])
            won = (result.get('won') or {}).get(seat['slot'])
            tints[place] = 'FF' + (person['colour'] if person else '#FFFFFF').lstrip('#').upper()
            places[place] = {'name': seat['name'], 'initial': seat['name'][:1].upper(), 'chips': money(seat['chips']), 'said': seat['said'],
                      'turn': '1' if public['turn'] == seat['slot'] else '',
                      'folded': 'FOLD' if seat['folded'] and not seat['out'] else '', 'out': 'OUT' if seat['out'] else '',
                      'card1': card(cards[0]) if cards else '', 'card2': card(cards[1]) if len(cards) > 1 else '',
                      'bet': money(seat['bet']) if seat['bet'] else '',
                      'dealer': '1' if public['button'] == seat['slot'] else '', 'blind': seat['blind'],
                      'hand': (result.get('hands') or {}).get(seat['slot'], ''), 'win': '+' + money(won) if won else '',
                      'timer': ('%d' % left) if left is not None and public['turn'] == seat['slot'] else ''}
        self.show(**{'seat.%d.%s' % (place, key): value for place, values in places.items() for key, value in values.items()})
        tint(tints)
        for i in range(5):
            self.show(**{'board.%d' % i: card(public['board'][i]) if i < len(public['board']) else ''})
        self.show(pot='POT %s' % money(public['pot']) if public['pot'] else '', street=STREETS.get(public['street'], ''),
                  result=self.result_words(table) if result else '',
                  strip='Hand %d  ·  Blinds %s / %s' % (public['hand'], money(table.small), money(table.big)))
        if self.server:
            self.server.set_table(dict(public, phase='table', left=left, clock=CLOCKS[self.choice['clock']][0]))
            for seat in table.seats:
                self.server.tell(seat['slot'], dict(table.private(seat['slot']), t='hand', pot=public['pot'], left=left))

    @staticmethod
    def result_words(table):
        names = {s['slot']: s['name'] for s in table.seats}
        parts = []
        for pot in table.result['pots']:
            who = ' and '.join(names[slot] for slot in pot['winners'])
            parts.append('%s %s %s%s' % (who, 'win' if len(pot['winners']) > 1 else 'wins', money(pot['amount']),
                                         ('  ·  ' + pot['hand']) if pot['hand'] else ''))
        return '   |   '.join(parts[:2])

    # ---- a hand ------------------------------------------------------------------------------------------------
    def wait_for_move(self, table):
        """The player on turn's move from their phone - in its time, else checked or folded for them. 'lobby' when
        Back twice ended the game."""
        slot = table.public()['turn']
        clock = CLOCKS[self.choice['clock']][0]
        start = time.monotonic()
        shown = None
        while not self.monitor.abortRequested():
            here = any(p['slot'] == slot and p.get('here', True) for p in self.roster())
            limit = clock if here else min(clock or GONE_WAIT, GONE_WAIT)
            left = max(0, int(limit - (time.monotonic() - start) + .999)) if limit else None
            if left != shown:
                shown = left
                self.refresh(table, left)
            if limit and time.monotonic() - start >= limit:
                table.act(slot, 'check' if table.options(slot)['check'] else 'fold')
                return None
            key = self.pressed(TICK)
            if key == 'back' and self.leaving():
                return 'lobby'
            while True:
                try:
                    who, move, to = self.moves.get_nowait()
                except queue.Empty:
                    break
                if who != slot:
                    continue
                try:
                    table.act(slot, move, to)
                    return None
                except poker.Refused as exc:
                    if self.server:
                        self.server.tell(slot, {'t': 'refused', 'text': str(exc)})
        return 'lobby'

    def hand(self, table):
        table.start_hand()
        while table.result is None and not self.monitor.abortRequested():
            if self.wait_for_move(table) == 'lobby':
                return 'lobby'
        self.refresh(table)
        end = time.monotonic() + SHOW_HAND
        while time.monotonic() < end and not self.monitor.abortRequested():
            key = self.pressed(TICK)
            if key == 'back' and self.leaving():
                return 'lobby'
            if key is not None and key != 'back':
                break
        return None

    def game(self):
        """One game to its winner: 'lobby' (Play again, or Back twice) or 'close'."""
        roster = self.roster()[:poker.MOST]
        small, big = BLINDS[self.choice['blinds']]
        table = poker.Table([(p['slot'], p['name']) for p in roster], CHIPS[self.choice['chips']], small, big)
        self.places = dict(zip([p['slot'] for p in roster], PLACES[len(roster)]))
        self.show(phase='table', hint='', result='')
        while table.over() is None and not self.monitor.abortRequested():
            if table.hand and table.hand % RISE == 0:
                table.small, table.big = table.small * 2, table.big * 2
            if self.hand(table) == 'lobby':
                return 'lobby'
        winner = table.seats[table.over()]
        self.show(phase='final', winner='%s wins!' % winner['name'],
                  winner_line='All %s chips after %d hands' % (money(winner['chips']), table.hand))
        if self.server:
            self.server.set_table({'phase': 'final', 'winner': winner['slot'], 'name': winner['name']})
        self.window.setFocusId(806)
        while not self.monitor.abortRequested():
            key = self.pressed(.25)
            if key in (806, 'back'):
                return 'lobby'
            if key == 807:
                return 'close'
        return 'close'

    def play(self):
        while not self.monitor.abortRequested():
            if self.lobby() != 'start':
                return
            if self.game() == 'close':
                return


def open_poker():
    """Poker: its screen and the phones' page, for as long as it is open."""
    from resources.lib.plex_link_window import qr_png
    window = QuizWindow(XML, ADDON.getAddonInfo('path'), theme_folder(), '1080i')
    game = Game(window, None)
    server, qr = None, ''
    try:
        server = PlayServer(lambda: [], None, mode='poker', key=games.phone_key(),
                            on_move=lambda slot, move, to: game.moves.put((slot, move, to)))
        server.start()
        game.server = server
        qr = qr_png(server.url(), box_size=10, border=2) or ''
    except OSError as exc:
        xbmc.log('[MegaNexus] Poker: no page for the phones (%s)' % exc.__class__.__name__, xbmc.LOGWARNING)
    screen_guard.hold()
    try:
        window.setProperty('poker.qr', qr)
        window.setProperty('poker.url', server.url() if server else 'Phones are not available here.')
        window.setProperty('poker.phase', 'lobby')
        window.show()
        if server is None:
            window.setProperty('poker.status', 'Poker is played with phones: they could not be reached here.')
        game.play()
    finally:
        game.closing = True
        if server is not None:
            server.stop()
        window.close()
        tint()
        screen_guard.release()
        if qr:
            try:
                os.remove(qr)                # the code carries this session's key
            except OSError:
                pass
        del window
