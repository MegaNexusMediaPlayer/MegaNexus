# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The HUB's Games app (games branch): MegaNexus' own Home, with games in it.

The same screen as the YouTube and Music apps - Home's rows going round, its top bar - with the free games
(resources.lib.games' catalogue) and your own (the folders you add in Options) as posters. The top shows the game
under the cursor: its name, its console · year · kind · players, and what it is about.

OK on a game: its emulator (one of Kodi's game add-ons) is found or offered for installing, a free game is
downloaded the first time (its author's release, checked against the catalogue), then the app steps aside and Kodi
plays it. When the game ends the app comes back where it was.

The top bar: Players - the phones' QR code and who plays (each phone the next player; play_server), Options (your
folders, Kodi's controller settings, titles, downloads), Settings and HUB. The phones' page runs while the app is open
and nothing of the app runs once it is closed ("pali se kad kliknemo na games i kad izajemo gasi se").
"""
import os
import queue
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcgui

from resources.lib import game_pad, games, home_data, screen_guard
from resources.lib.play_server import MOST, PlayServer
from resources.lib.theme import folder as theme_folder
from .dialog import BACK
from .home_window import ADDON, HUB_SETTLE_PLAIN, ROW_BASE, HomeWindow, app_bar

HOME = 'games'
SEARCH = 'games:search'
XML = 'meganexus_home.xml'
APP = 'games'
PLAYERS_BUTTON = 106             # Home's Library: the app's Players
OPTIONS_BUTTON = 115             # the Calendar's place: the app's Options (as YouTube's)
CONTEXT = (117, 101, 1009)
WORKERS = 2                      # Continue playing and your folders (a network folder can be slow)
START_WAIT = 20.0                # s Kodi may take to show the game
INSTALL_WAIT = 180.0             # s for Kodi's own installing of a game add-on (its questions included)
GAME_COVER = 'meganexus.game.cover'   # Window(Home): the window under the app is black (meganexus_session.xml)
TITLES, ROW_TITLES = 'meganexus_games_titles', 'meganexus_games_rowtitles'
APP_TITLES = 'meganexus.app.titles'
# "treba malo objasnjenje ... pored qr da je multiplayer i podrzava ... mobitela": what the code is for, and how many
PLAYERS_STEPS = ('[B]Multiplayer on this TV: up to %d phones at once.[/B][CR]'
                 'Everyone on this TV\'s Wi-Fi scans this same code - each phone is the next player (Player 1, 2 ...).[CR]'
                 'Each phone gets the game\'s own controller, starts games and opens their menu. A Bluetooth controller '
                 'plays along.' % MOST)
NO_PADS = ('[CR][COLOR FF8FA6CC]This device has no phone controller for MegaNexus: here the phones start games and open '
           'their menu; play with a Bluetooth controller.[/COLOR]')
ASKING = ' | '.join('Window.IsVisible(%s)' % name for name in
                    ('yesnodialog', 'selectdialog', 'okdialog', 'progressdialog', 'extendedprogressdialog',
                     'addoninformation', 'addonsettings'))


def _shelf(title, job=None, rows=None):
    shelf = {'title': title, 'rows': rows or [home_data.placeholder(' ', '')], 'shape': 'poster'}
    if job:
        shelf['games_job'] = job
    return shelf


def _size(count):
    return ('%.1f MB' % (count / 1048576.0)) if count >= 104858 else '%d KB' % max(1, count // 1024)


def card(item):
    """A free game's poster card."""
    systems = games.catalog()['systems']
    players = item['players']
    parts = [systems.get(item['system'], {}).get('name') or '', str(item.get('year') or ''), item['genre'],
             ('%s players' % players) if players != '1' else '1 player']
    if item.get('file') and not games.ready(item):
        parts.append('%s download' % _size(item['file']['size']))
    return {'title': item['title'], 'poster': item['poster'], 'fanart': item['fanart'], 'plot': item['description'],
            'meta_line': '  ·  '.join(p for p in parts if p), 'shape': 'poster', 'game': {'id': item['id']}}


def file_card(found):
    """One of your games (games.dressed): its console, its folder; libretro's box shown whole ('fit'), else the
    console's poster - "skinuo sam neku igru ali nema njene slike ... i nije prikazan za koji je uredaj"."""
    folder = found.get('folder') or os.path.dirname(found['path'])
    console = games.CONSOLES.get(found.get('console') or '', ('',))[0]
    parts = (console, 'Your games', os.path.basename(folder.rstrip('/')))
    return {'title': found['title'], 'poster': found.get('poster') or '', 'fanart': found.get('fanart') or '',
            'plot': found['path'], 'meta_line': '  ·  '.join(p for p in parts if p), 'shape': 'poster',
            'fit': bool(found.get('boxed')), 'game': {'id': found['id'], 'path': found['path'], 'title': found['title']}}


def shelves(view, query=''):
    """Every row of one of the app's views: the catalogue's at once, Continue playing and your folders loaded."""
    data = games.catalog()
    if view == SEARCH:
        words = query.lower()
        found = [card(g) for g in data['games'] if words in g['title'].lower() or words in g['genre'].lower()]
        return [_shelf('Games', rows=found or [home_data.placeholder('Nothing found', 'No game has this name.')]),
                _shelf('Your games', ('search', query))]
    rows = [_shelf('Continue playing', ('recent',))]
    for row in data['rows']:
        found = [card(g) for g in data['games'] if row['id'] in g['rows']]
        if found:
            rows.append(_shelf(row['title'], rows=found))
    if games.folders():
        rows.append(_shelf('Your games', ('yours',)))
    return rows


def cards(job):
    """A loaded row's cards (the app's workers)."""
    installed = games.cores()
    if job[0] == 'recent':
        played = [games.free_game(entry['id']) or entry for entry in games.recent()]
        played = [item for item in played if item.get('system') or item.get('path')]
        yours = iter(games.dressed([item for item in played if item.get('path')], installed))
        return [file_card(next(yours)) if item.get('path') else card(item) for item in played]
    yours = games.your_games(installed)
    if job[0] == 'search':
        yours = [f for f in yours if job[1].lower() in f['title'].lower()]
    return [file_card(f) for f in games.dressed(yours, installed)]


def _switch(key):
    from resources.lib import settings_snapshot
    return settings_snapshot.cached_addon().getSetting(key) != 'false'


def _titles(on=None):
    """The app's titles under the cards (Window(Home), as Kodi reads a card's words there): '' gives Home's back."""
    if on is not None and on != '':
        from resources.lib import settings_snapshot
        settings_snapshot.cached_addon().setSetting(TITLES, 'true' if on else 'false')
        settings_snapshot.invalidate()
    value = '' if on == '' else ('on' if _switch(TITLES) else 'off')
    xbmcgui.Window(10000).setProperty(APP_TITLES, value)
    return value


class GamesWindow(HomeWindow):
    """Home, with games in it."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._hero = None
        self._games_pool = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='MegaNexusGamesRows')
        self._server = kwargs.get('server')
        self._asked = kwargs.get('asked') or queue.Queue()     # the games the phones asked for

    def onInit(self):
        self.setProperty('meganexus.app', APP)
        super().onInit()
        try:
            self.getControl(PLAYERS_BUTTON).setLabel('Players')
            self.getControl(OPTIONS_BUTTON).setLabel('Options')
            app_bar(self, options=True)
        except Exception:
            pass

    def _row_titles(self):
        return _switch(ROW_TITLES)

    def _paint_rows(self, rows):
        super()._paint_rows(rows)
        self.setProperty('meganexus.search.query', getattr(self, '_games_query', '') if self._bucket == SEARCH else '')

    def _load(self, index, shelf, generation):
        if not shelf.get('games_job'):
            return super()._load(index, shelf, generation)
        if not self._closed and generation == self._generation:
            self._games_pool.submit(self._load_games, index, shelf, generation)

    def _load_games(self, index, shelf, generation):
        job = shelf['games_job']
        if self._closed or generation != self._generation:
            return
        try:
            rows = cards(job)
        except Exception:
            xbmc.log('[MegaNexus] Games row did not load: ' + traceback.format_exc(limit=2), xbmc.LOGWARNING)
            rows = []
        if not rows:
            empty = {'recent': ('Nothing played yet', 'The games you play show here.'),
                     'yours': ('No games found', 'Options > Your game folders: the folders with your games.'),
                     'search': ('Nothing found', 'None of your games has this name.')}[job[0]]
            rows = [dict(home_data.placeholder(*empty), shape='poster', game={'empty': True})]
        if not self._closed and generation == self._generation:
            g = shelf.get('_ring_g')
            if g is not None and 0 <= g < len(self._pages) and self._pages[g].get('games_job') == job:
                self._pages[g].update(rows=rows, _loaded=True)
            self._updates.put((generation, index, rows, None, g))

    def drain_updates(self):
        super().drain_updates()
        if not self._closed:
            self._hero_tick()
            self._phone_asked()

    def _phone_asked(self):
        """A game a phone asked for: started as OK on its card would (its emulator, its download, then it plays)."""
        if self._suspended or self._child_active:
            return
        try:
            ident = self._asked.get_nowait()
        except queue.Empty:
            return
        item = games.free_game(ident) or next((dict(r, path=r['path']) for r in games.recent()
                                               if r['id'] == ident and r.get('path')), None)
        if item:
            self._start(item)

    def _hero_tick(self):
        """The game under the cursor at the top: its name, its line and what it is about - set when it changes."""
        control_id, pos, _ = self._selection()
        index = control_id - ROW_BASE
        if not 0 <= index < len(self._shelves):
            return
        rows = self._shelves[index].get('rows') or []
        row = rows[pos] if 0 <= pos < len(rows) else {}
        if row is self._hero:
            return
        self._hero = row
        self.setProperty('meganexus.app.font', '')
        for name, key in (('title', 'title'), ('meta', 'meta_line'), ('plot', 'plot'), ('fanart', 'fanart')):
            self.setProperty('meganexus.app.' + name, str(row.get(key) or '').strip())

    # ---- keys ----------------------------------------------------------------------------------------------
    def _go(self, view, query=None):
        if query is not None:
            self._games_query = query
        self._bucket = view
        self._focus_memory.pop(view, None)
        self._paint(shelves(view, getattr(self, '_games_query', '')))

    def onClick(self, control_id):
        self._touch()
        if control_id == 101:
            return self._go(HOME) if self._bucket != HOME else None
        if control_id in (105, 111):
            return self._search()
        if control_id == PLAYERS_BUTTON:
            return self._players()
        if control_id == OPTIONS_BUTTON:
            return self._options()
        if control_id == 107:
            return self._settings()
        row, index = self._card(control_id)
        if row is None:
            if index < 0:
                super().onClick(control_id)     # the HUB
            return
        game = row.get('game') or {}
        if game.get('empty'):
            if self._shelves[index].get('games_job', ('',))[0] == 'yours':
                self._folders()
            return
        item = games.free_game(game['id']) if not game.get('path') else dict(game, path=game['path'])
        if item:
            self._start(item)

    def _card(self, control_id):
        if not ROW_BASE <= control_id < ROW_BASE + len(self._shelves):
            return None, -1
        index = control_id - ROW_BASE
        rows = self._shelves[index].get('rows') or []
        pos = self.getControl(control_id).getSelectedPosition()
        return (rows[pos] if 0 <= pos < len(rows) else None), index

    def onAction(self, action):
        if action.getId() in CONTEXT:
            row, index = self._card(self.getFocusId())
            if row is not None and (row.get('game') or {}).get('id'):
                self._card_options(row, index)
            return
        if action.getId() in BACK:
            self._touch()
            if self._bucket != HOME:
                return self._go(HOME)
            return self.setFocusId(108)
        super().onAction(action)

    def _search(self):
        self._suspended = True
        try:
            query = xbmcgui.Dialog().input('Search games', getattr(self, '_games_query', '')).strip()
        finally:
            self._suspended = False
        if query:
            self._go(SEARCH, query)

    # ---- playing ---------------------------------------------------------------------------------------
    def _start(self, item):
        """The game's emulator, its file, then Kodi plays it - the app steps aside meanwhile."""
        self._suspended = True
        try:
            core = self._emulator(item)
            if not core or (item.get('file') and not games.ready(item) and not self._download(item)):
                return
        finally:
            self._suspended = False
        games.note_played(item)
        # "kad ulazim u igru i izlazim blejsne mi pozadina sa tmdb": the app steps aside before Kodi shows the game
        # and comes back after it - the window under it (the HUB's picture) stays black until the app is drawn again
        home = xbmcgui.Window(10000)
        home.setProperty(GAME_COVER, '1')
        try:
            self.child(play, item, core, self._server)
        finally:
            home.clearProperty(GAME_COVER)
        self._games_refresh_recent()

    def _emulator(self, item):
        installed = games.cores()
        core = games.core_for(item, installed)
        if core:
            return core
        wanted = games.core_wanted(item)
        system = games.catalog()['systems'].get(item.get('system'), {}).get('name') or 'this game'
        if not wanted or not xbmcgui.Dialog().yesno(
                'Retro', 'Kodi has no emulator for %s yet.[CR]Install it now from Kodi\'s add-ons?' % system):
            if not wanted:
                xbmcgui.Dialog().ok('Retro', 'None of Kodi\'s game add-ons plays this file.[CR]'
                                             'Add-ons > Install from repository > Game add-ons.')
            return ''
        xbmc.executebuiltin('InstallAddon(%s)' % wanted)
        monitor = xbmc.Monitor()
        waited = 0.0
        while waited < INSTALL_WAIT and not monitor.abortRequested():
            if xbmc.getCondVisibility('System.HasAddon(%s)' % wanted) and not xbmc.getCondVisibility(ASKING):
                break
            if waited > 3 and not xbmc.getCondVisibility(ASKING + ' | System.HasActiveModalDialog'):
                break          # its questions answered (or refused) and nothing installing any more
            monitor.waitForAbort(.25)
            waited += .25
        core = games.core_for(item, games.cores())
        if not core:
            xbmcgui.Dialog().ok('Retro', 'The emulator is not there.[CR]On this device it may come from the '
                                         'system\'s own add-ons: Add-ons > Install from repository > Game add-ons.')
        return core

    def _download(self, item):
        """The free game's own release, downloaded once (checked against the catalogue)."""
        progress = xbmcgui.DialogProgress()
        progress.create(item['title'], 'Downloading the game from its author\'s release…')
        box = {}

        def work():
            try:
                box['path'] = games.download(item, lambda done, total: progress.update(
                    int(done * 100 / total) if total else 0, 'Downloading… %s of %s' % (_size(done), _size(total or done))),
                    progress.iscanceled)
            except Exception as exc:
                box['error'] = exc
        worker = threading.Thread(target=work, name='MegaNexusGameDownload', daemon=True)
        worker.start()
        monitor = xbmc.Monitor()
        while worker.is_alive() and not monitor.abortRequested():
            monitor.waitForAbort(.1)
        progress.close()
        error = box.get('error')
        if error and not isinstance(error, InterruptedError):
            xbmc.log('[MegaNexus] Games: %s did not download: %s' % (item['id'], error), xbmc.LOGWARNING)
            reason = str(error) if isinstance(error, games.Refused) else 'The download did not finish. Try again later.'
            xbmcgui.Dialog().ok(item['title'], reason)
        if box.get('path'):
            self._games_refresh_cards()
        return bool(box.get('path'))

    def _games_refresh_recent(self):
        for index, shelf in enumerate(self._shelves):
            if shelf.get('games_job', ('',))[0] == 'recent':
                shelf['_loaded'] = False
                self._scheduled.discard(index)

    def _games_refresh_cards(self):
        """A download done: its cards lose their size."""
        for index, shelf in enumerate(self._shelves):
            if shelf.get('games_job'):
                continue
            rows = [card(games.free_game(r['game']['id'])) if (r.get('game') or {}).get('id') and
                    games.free_game(r['game']['id']) else r for r in shelf.get('rows') or []]
            self._updates.put((self._generation, index, rows, None, shelf.get('_ring_g')))

    # ---- the bar ---------------------------------------------------------------------------------------
    def _players(self):
        """Who plays: the phones' code (one for everyone) and the players there are, as they come and go."""
        if self._server is None:
            return
        self._suspended = True
        try:
            self.over(players_screen, self._server)
        finally:
            self._suspended = False

    def _options(self):
        state = lambda on: 'On' if on else 'Off'
        used = games.downloaded_size()
        choices = [('folders', 'Your game folders · %d' % len(games.folders())),
                   ('controllers', 'Controllers'),
                   ('titles', 'Titles under the cards · %s' % state(_switch(TITLES))),
                   ('rowtitles', 'Row titles · %s' % state(_switch(ROW_TITLES))),
                   ('downloads', 'Downloaded games · %s' % (_size(used) if used else 'none')),
                   ('newcode', 'Phones · a new code (the phones need to scan again)'),
                   ('about', 'About the free games')]
        self._suspended = True
        try:
            pick = xbmcgui.Dialog().select('Options', [label for _key, label in choices])
            if pick < 0:
                return
            key = choices[pick][0]
            if key == 'folders':
                self._folders()
            elif key == 'controllers':
                xbmc.executebuiltin('ActivateWindow(gamecontrollers)')
            elif key == 'titles':
                _titles(not _switch(TITLES))
            elif key == 'rowtitles':
                from resources.lib import settings_snapshot
                settings_snapshot.cached_addon().setSetting(ROW_TITLES, 'false' if _switch(ROW_TITLES) else 'true')
                settings_snapshot.invalidate()
                self._go(self._bucket or HOME)
            elif key == 'downloads' and used and xbmcgui.Dialog().yesno(
                    'Downloaded games', 'Delete every downloaded game (%s)?[CR]They download again when played.' % _size(used)):
                for item in games.catalog()['games']:
                    if item.get('file'):
                        games.remove_download(item)
                self._go(self._bucket or HOME)
            elif key == 'newcode':
                games.phone_key(new=True)
                xbmcgui.Dialog().notification('Retro', 'New code - it is used the next time Retro opens', time=4000)
            elif key == 'about':
                xbmcgui.Dialog().textviewer('About the free games', about())
        finally:
            self._suspended = False

    def _folders(self):
        """Your game folders: add one (Kodi's own browser - local, network, USB) or take one off."""
        while True:
            now = games.folders()
            labels = ['Add a folder…'] + ['Remove  %s' % f for f in now]
            pick = xbmcgui.Dialog().select('Your game folders', labels)
            if pick < 0:
                break
            if pick == 0:
                chosen = xbmcgui.Dialog().browse(0, 'A folder with your games', 'files')
                if chosen:
                    games.set_folders(now + [chosen])
            else:
                games.set_folders([f for f in now if f != now[pick - 1]])
        self._go(self._bucket or HOME)

    def _card_options(self, row, index):
        game = row['game']
        item = games.free_game(game['id'])
        choices = []
        if self._shelves[index].get('games_job', ('',))[0] == 'recent':
            choices.append(('forget', 'Remove from Continue playing'))
        if item and item.get('file') and games.ready(item):
            choices.append(('delete', 'Delete the download (%s)' % _size(item['file']['size'])))
        if item:
            choices.append(('about', 'About %s' % item['title']))
        if not choices:
            return
        self._suspended = True
        try:
            pick = xbmcgui.Dialog().contextmenu([label for _key, label in choices])
            if pick < 0:
                return
            key = choices[pick][0]
            if key == 'forget':
                games.forget_played(game['id'])
                self._drop_card(index, self.getControl(ROW_BASE + index).getSelectedPosition(),
                                ('Nothing played yet', 'The games you play show here.'))
            elif key == 'delete':
                games.remove_download(item)
                self._games_refresh_cards()
            elif key == 'about':
                xbmcgui.Dialog().textviewer(item['title'], about_one(item))
        finally:
            self._suspended = False

    def _settings(self):
        from .settings import run
        self._suspended = True
        try:
            command = self.over(run)
        finally:
            self._suspended = False
        if command == 'meganexus:reload':
            self._pending, self._theme_changed = 'reload', True
            self._finish()
        elif command:
            self._pending = command
            self._finish()

    def _finish(self):
        try:
            self._games_pool.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            self._games_pool.shutdown(wait=False)     # Kodi 21 on Windows embeds Python 3.8
        super()._finish()


def about_one(item):
    return ('%s[CR][CR]Controls: %s[CR][CR]By %s  ·  %s  ·  %s[CR]%s'
            % (item['description'], item['controls'], item['author'], item['year'], item['license'], item['homepage']))


def about():
    lines = ['Every free game here is shared by its author for free. MegaNexus does not ship them: the first time '
             'one is played, its author\'s own release is downloaded and kept only if it is exactly the file '
             'MegaNexus knows (SHA-256). Mr.Boom, 2048 and Cave Story are Kodi\'s own game add-ons.', '']
    for item in games.catalog()['games']:
        lines.append('[B]%s[/B]  ·  %s  ·  %s  ·  %s' % (item['title'], item['author'], item['license'],
                                                                         item['homepage']))
    return '[CR]'.join(lines)


def pad_of(item, core):
    """What the phones are told of the game that starts: its controller and what that has (game_pad) - the phone
    draws that pad. Our pads' button map gets this controller if it is new (Kodi reads it again by itself), and our
    pads' add-on shows its picture."""
    controller = game_pad.controller_of(core)
    found = game_pad.layout(controller) if controller else []
    if found and game_pad.kind():
        known = installed_controllers()
        game_pad.write_maps(known + [(controller, found)] if controller not in dict(known) else known, controller)
    system = item.get('system') or ''
    logo = system if os.path.isfile(os.path.join(os.path.dirname(item.get('poster') or ''), '..', 'logos', system + '.svg')) else ''
    return {'id': item['id'], 'title': item['title'], 'controller': controller, 'features': found, 'logo': logo}


def installed_controllers():
    """Every one of Kodi's controller add-ons installed, with its features (a keyboard or a mouse is no pad)."""
    found = []
    for ident in sorted(games.controller_ids()):
        if not any(word in ident for word in game_pad.NOT_PADS):
            features = game_pad.layout(ident)
            if features:
                found.append((ident, features))
    return found


def phone_games():
    """The games the phones browse: the catalogue's and your games played lately (posters and big pictures by their
    names; ``played``: when, for the phone's Continue playing - "ubaciti zadnje igrane igre")."""
    systems = games.catalog()['systems']
    played = {r['id']: r.get('at') or 0 for r in games.recent()}
    found = [{'id': g['id'], 'title': g['title'], 'system': g['system'], 'short': systems.get(g['system'], {}).get('short', ''),
              'poster': os.path.basename(g['poster']), 'fanart': os.path.basename(g['fanart']), 'description': g['description'],
              'played': played.get(g['id'], 0),
              'meta': '  \u00b7  '.join(p for p in (systems.get(g['system'], {}).get('name'), str(g.get('year') or ''),
                                                     g['genre'], g['players'] + (' players' if g['players'] != '1' else ' player')) if p)}
             for g in games.catalog()['games']]
    # your games: by their console (its chip), libretro's box whole on its own blurred copy ('boxed', a whole address)
    # or the console's poster (the app's own pictures)
    for r in games.dressed([r for r in games.recent() if r.get('path')], games.cores()):
        console = games.CONSOLES.get(r['console'])
        found.append({'id': r['id'], 'title': r['title'], 'system': r['console'] or 'yours', 'short': console[1] if console else 'Yours',
                      'poster': r['poster'] if r['boxed'] else os.path.basename(r['poster']), 'fanart': r['fanart'],
                      'boxed': r['boxed'], 'description': r['path'], 'played': r.get('at') or 0,
                      'meta': '  \u00b7  '.join(p for p in (console[0] if console else '', 'Your games') if p)})
    return found


def ask(asked, ident):
    """A phone asked for a game: the one that plays stops for it (the app comes back and starts the new one)."""
    if games.playing():
        xbmc.executebuiltin('PlayerControl(Stop)')
    asked.put(ident)


def players_screen(server):
    """The Players screen: the code to scan, the players there are (each in their colour), refreshed as they change."""
    from resources.lib.plex_link_window import qr_png
    from .phone_setup import PhoneWindow
    url = server.url()
    qr = qr_png(url, box_size=10, border=2) or ''
    window = PhoneWindow('meganexus_phone_setup.xml', ADDON.getAddonInfo('path'), theme_folder(), '1080i', qr=qr, url=url,
                         title='Players', steps=PLAYERS_STEPS + ('' if server.pads else NO_PADS))
    monitor = xbmc.Monitor()
    try:
        window.show()
        while not window.cancelled and not monitor.abortRequested():
            text = '   '.join('[COLOR FF%s]\u25cf[/COLOR] %d  %s%s' % (p['colour'][1:], p['slot'], p['name'],
                                                                       '' if p['here'] else ' (away)')
                             for p in server.roster()) or 'No phone yet - scan the code.'
            if window.getProperty('meganexus.phone.status') != text:     # (its own first words set as it opened)
                window.setProperty('meganexus.phone.status', text)
            # Kodi's own wait: only in it does Kodi hand the window its keys (Back closes it)
            monitor.waitForAbort(.25)
    finally:
        window.close()
        del window
        if qr:
            try:
                os.remove(qr)        # the code carries this session's key
            except OSError:
                pass


def play(item, core, server=None):
    """The game in Kodi's player (RetroPlayer) while the app has stepped aside; back when it ends. The phones get
    its pad while it plays."""
    from .play_jobs import wait_overlay
    monitor = xbmc.Monitor()
    if server is not None:
        server.set_game(pad_of(item, core))
    cover = wait_overlay('', {})
    try:
        xbmc.executebuiltin(games.play_command(item, core))
        waited = 0.0
        while not games.playing() and waited < START_WAIT and not monitor.abortRequested():
            if xbmc.getCondVisibility(ASKING):
                waited = 0.0          # Kodi asks something first (a game add-on's own question)
            monitor.waitForAbort(.1)
            waited += .1
    finally:
        cover.close()
    # a console's first game: Kodi installs its controller (a dependency of the game add-on) only as it starts it -
    # the pad sent before had nothing to draw ("gameboy advance nema kontroler"); now that it plays, asked again
    if server is not None and games.playing() and not (server.game or {}).get('features'):
        server.set_game(pad_of(item, core))
    try:
        while games.playing() and not monitor.abortRequested():
            monitor.waitForAbort(.25)
    finally:
        if server is not None:
            server.set_game(None)


def open_games():
    monitor = xbmc.Monitor()
    view, query, pending = HOME, '', ''
    _titles()
    asked = queue.Queue()
    server = None
    try:
        game_pad.begin(installed_controllers())                     # before any phone's pad is there
        server = PlayServer(phone_games, lambda ident: ask(asked, ident), key=games.phone_key()).start()
    except OSError as exc:
        xbmc.log('[MegaNexus] Games: no page for the phones (%s)' % exc.__class__.__name__, xbmc.LOGWARNING)
    try:
        while not monitor.abortRequested():
            window = GamesWindow(XML, ADDON.getAddonInfo('path'), theme_folder(), '1080i', shelves=shelves(view, query),
                                 bucket=view, server=server, asked=asked)
            window._games_query = query
            window.setProperty('meganexus.app', APP)
            cover = None
            try:
                screen_guard.hold()
                window.show_ready()
                from .trailers import lift_curtain
                lift_curtain()
                while not window._closed and not window._leaving and not monitor.abortRequested():
                    window.drain_updates()
                    monitor.waitForAbort(.05)
                pending, view, query = window._pending, window._bucket or HOME, getattr(window, '_games_query', '')
            finally:
                if getattr(window, '_pending', None) == 'hub':
                    try:
                        from .play_jobs import wait_overlay
                        cover = wait_overlay('', {})
                    except Exception:
                        cover = None
                    xbmc.executebuiltin('ActivateWindow(Home)')
                    for _ in range(20):
                        if xbmc.getCondVisibility('Window.IsActive(Home)') or monitor.waitForAbort(.025):
                            break
                    monitor.waitForAbort(HUB_SETTLE_PLAIN)
                window._finish()
                window._release()
                screen_guard.release()
                if cover is not None:
                    cover.close()
            if pending == 'reload':
                if getattr(window, '_theme_changed', False):
                    from resources.lib import theme
                    theme.sync()
                    monitor.waitForAbort(.5)
                continue
            if pending and pending != 'hub':
                from .system_setup import execute_command
                execute_command(pending)
            break
    finally:
        if server is not None:
            server.stop()                 # every phone and its pad go with the app
        game_pad.end()                    # our pads' add-on off: nothing of it runs once the app is closed
        _titles('')
        games.forget()
        if not pending:
            xbmc.executebuiltin('ActivateWindow(Home)')
