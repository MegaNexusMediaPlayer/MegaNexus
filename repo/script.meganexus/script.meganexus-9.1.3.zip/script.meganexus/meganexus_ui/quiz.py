# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Guess It on the TV (games branch): MegaNexus' own party quiz - "pogodi film seriju glumca ... brutalno, na eng".

The lobby: what to guess (everything, movies, series, actors), how hard, how many questions - and the phones' code:
everyone scans the same one and is a player (play_server, as in Games). Then the questions, made fresh from TMDB
(resources.lib.quiz): 20 seconds each, the picture losing its tiles as the clock runs, the phones' four buttons
in the TV's colours. The answer comes lit with how many chose each, everyone's points (faster is more, a streak
more still), the scores every fifth question and the podium at the end. No phone? The remote answers for the TV.

Nothing of it stays: the code, the players and the questions go when the screen closes.
"""
import os
import queue
import random
import threading
import time

import xbmc
import xbmcgui

from resources.lib import games, quiz, screen_guard
from resources.lib.play_server import PlayServer
from resources.lib.theme import folder as theme_folder
from .home_window import ADDON

XML = 'meganexus_quiz.xml'
LIMIT = 20.0                    # s to answer
UNCOVERED = .75                 # the picture is whole after three quarters of the time
SHOW_ANSWER = 6.0               # s the answer stays (OK goes on at once)
SHOW_SCORES = 7.0
SCORES_EVERY = 5
LEAVE_AGAIN = 3.0               # s a second Back has to leave (the first one says so on the screen)
TICK = .1
TV = 0                          # the TV's own player (its remote)
TV_COLOUR = '#FFFFFF'
BACK = (9, 10, 92, 216, 247, 257, 275, 61448, 61467)
OPTIONS = (401, 402, 403, 404)
CHOICE = {801: 'kind', 802: 'level', 803: 'length'}
MESSAGES = {'nokey': 'Guess It asks TMDB for its questions: add your TMDB key in Settings > API keys first.',
            'empty': 'TMDB gave nothing to ask - try again in a moment.'}



def blanks(text):
    """A question's words with each name left out drawn as a blank in the theme's colour (a skin colour name)."""
    return text.replace(quiz.HIDDEN, '[COLOR button_focus]%s[/COLOR]' % quiz.HIDDEN)


class QuizWindow(xbmcgui.WindowXMLDialog):
    """Its callbacks only queue what was pressed; open_quiz's loop does the rest."""

    def __init__(self, *args):
        super().__init__(*args)
        self.pressed = queue.Queue()

    def onInit(self):
        self.setFocusId(804)

    def onClick(self, control_id):
        self.pressed.put(control_id)

    def onAction(self, action):
        if action.getId() in BACK:
            self.pressed.put('back')


class Scores(object):
    """Everyone's points: {slot: {'name', 'colour', 'score', 'streak', 'gain'}}."""

    def __init__(self):
        self.people = {}

    def player(self, slot, roster):
        if slot not in self.people:
            known = next((p for p in roster if p['slot'] == slot), None)
            self.people[slot] = {'name': known['name'] if known else 'TV', 'colour': known['colour'] if known else TV_COLOUR,
                                 'score': 0, 'streak': 0, 'gain': 0}
        return self.people[slot]

    def mark(self, answers, right, roster):
        """The question's answers ({slot: (option, seconds left)}): each one's points and streak."""
        for person in self.people.values():
            person['gain'] = 0
        for slot, (option, left) in answers.items():
            person = self.player(slot, roster)
            correct = option == right
            person['streak'] = person['streak'] + 1 if correct else 0
            person['gain'] = quiz.points(correct, left, LIMIT, person['streak'])
            person['score'] += person['gain']
        for slot, person in self.people.items():
            if slot not in answers:
                person['streak'] = 0

    def board(self):
        """[(rank, slot, person)] best first (equal points, equal place)."""
        ordered = sorted(self.people.items(), key=lambda item: -item[1]['score'])
        board, rank, last = [], 0, None
        for number, (slot, person) in enumerate(ordered, 1):
            if person['score'] != last:
                rank, last = number, person['score']
            board.append((rank, slot, person))
        return board


def _colour(hex_colour):
    return 'FF' + hex_colour.lstrip('#').upper()


class Game(object):
    def __init__(self, window, server):
        self.window, self.server = window, server
        self.choice = {'kind': 0, 'level': 0, 'length': 0}
        self.answers = queue.Queue()
        self.monitor = xbmc.Monitor()
        self.closing = False
        self.tv_plays = False           # the remote answered once in this game: the TV is a player
        self.leave_until = 0.0

    # ---- the screen -------------------------------------------------------------------------------------
    def show(self, **values):
        for name, value in values.items():
            self.window.setProperty('quiz.' + name, '' if value is None else str(value))

    def pressed(self, wait):
        """What was pressed, waiting ``wait`` seconds for it. The wait is Kodi's own: Kodi hands a script's window its
        keys (onClick, onAction) only while the script waits in Monitor.waitForAbort or xbmc.sleep - a wait of
        Python's own (a queue's) let none through: nothing on the screen answered, not even Back."""
        if self.window.pressed.empty():
            self.monitor.waitForAbort(wait)
        if self.leave_until and time.monotonic() > self.leave_until:
            self.leave_until = 0.0
            self.show(hint='')
        try:
            return self.window.pressed.get_nowait()
        except queue.Empty:
            return None

    def leaving(self):
        """Back in a game: the first one says so, a second one within LEAVE_AGAIN seconds ends the game - back to
        Guess It's own first page, where Back leaves it ("da ne izade skroz iz igre nego na pocetnu stranicu od igre";
        a Yes / No box before took Back as No: "kad krene kviz nemogu izaci")."""
        if self.leave_until:
            self.leave_until = 0.0
            self.show(hint='')
            return True
        self.leave_until = time.monotonic() + LEAVE_AGAIN
        self.show(hint='Press Back again to end this game')
        return False

    def wait(self, seconds, skip=True):
        """``seconds`` on the screen as it is; OK (or Back) earlier goes on."""
        end = time.monotonic() + seconds
        while time.monotonic() < end and not self.monitor.abortRequested():
            key = self.pressed(TICK)
            if key == 'back':
                return 'back'
            if key is not None and skip:
                return key

    def lobby_words(self):
        kinds, levels = quiz.KINDS, quiz.LEVELS
        self.show(kind=kinds[self.choice['kind']][1], level=levels[self.choice['level']][1],
                  length=quiz.LENGTHS[self.choice['length']])
        roster = self.server.roster() if self.server else []
        self.show(players='[CR]'.join('[COLOR %s]●[/COLOR]  %s' % (_colour(p['colour']), p['name']) for p in roster)
                  or 'No phone yet - scan the code, or play with the remote.')

    # ---- the lobby ---------------------------------------------------------------------------------------
    def lobby(self):
        """What to guess, then Start ('start') - or 'close'."""
        self.show(phase='lobby', status='', background='')
        if self.server:
            self.server.set_quiz({'phase': 'lobby'})
        self.window.setFocusId(804)
        while not self.monitor.abortRequested():
            self.lobby_words()
            key = self.pressed(.25)
            if key in CHOICE:
                name = CHOICE[key]
                size = {'kind': len(quiz.KINDS), 'level': len(quiz.LEVELS), 'length': len(quiz.LENGTHS)}[name]
                self.choice[name] = (self.choice[name] + 1) % size
            elif key == 804:
                return 'start'
            elif key in (805, 'back'):
                return 'close'
        return 'close'

    def questions(self):
        """The round from TMDB, made on a worker while the lobby says so - Back stops it there (the lobby stays)."""
        self.show(status='Getting the questions…')
        box, stop = {}, threading.Event()

        def work():
            try:
                box['round'] = quiz.round_of(quiz.KINDS[self.choice['kind']][0], quiz.LEVELS[self.choice['level']][0],
                                             quiz.LENGTHS[self.choice['length']],
                                             cancelled=lambda: self.closing or stop.is_set())
            except quiz.NoKey:
                box['error'] = 'nokey'
            except Exception as exc:
                xbmc.log('[MegaNexus] Guess It: no round (%s)' % exc.__class__.__name__, xbmc.LOGWARNING)
                box['error'] = 'empty'
        worker = threading.Thread(target=work, name='MegaNexusQuizRound', daemon=True)
        worker.start()
        while worker.is_alive() and not self.monitor.abortRequested():
            if self.pressed(.1) == 'back':
                stop.set()
                self.show(status='')
                return []
        found = box.get('round') or []
        if not found:
            self.show(status=MESSAGES[box.get('error') or 'empty'])
        return found

    # ---- one question -------------------------------------------------------------------------------------
    def ask(self, number, question, total, scores):
        """Show the question, take the answers until the time is up (or everyone answered); returns them."""
        tiles = list(range(16)) if question.get('reveal') else []
        random.shuffle(tiles)
        # the tiles first, the picture under them after: the other way round a frame Kodi drew in between showed it whole
        for index in range(16):
            self.show(**{'tile.%d' % index: '1' if index in tiles else ''})
        # nothing behind a question: the picture across the screen showed what its tiles hide, and a question in words
        # had its answer's poster there ("prelako pogodi") - the background is the reveal's
        self.show(phase='question', counter='QUESTION %d / %d  ·  %s' % (number, total, question['category'].upper()),
                  prompt=question['prompt'], picture=question.get('picture') or '', text=blanks(question.get('text') or ''),
                  tall='1' if question.get('tall') else '', background='', correct='', after='', results='', answered='')
        for index, option in enumerate(question['options'], 1):
            self.show(**{'option.%d' % index: option, 'count.%d' % index: ''})
        self.strip(scores)
        if self.server:
            self.server.set_quiz({'phase': 'question', 'n': number, 'total': total, 'prompt': question['prompt'],
                                  'category': question['category'], 'options': question['options']})
        self.window.setFocusId(OPTIONS[0])
        while not self.answers.empty():
            self.answers.get_nowait()                    # an answer to the question before, too late
        answers, start, hidden = {}, time.monotonic(), 0
        try:
            bar = self.window.getControl(500)
        except RuntimeError:
            bar = None
        while not self.monitor.abortRequested():
            elapsed = time.monotonic() - start
            left = LIMIT - elapsed
            if left <= 0:
                break
            while not self.answers.empty():
                slot, asked, option = self.answers.get_nowait()
                if asked == number and slot not in answers and 0 <= option < 4:
                    answers[slot] = (option, left)
            key = self.pressed(TICK)
            if key == 'back' and self.leaving():
                return None
            if key in OPTIONS and TV not in answers:
                answers[TV] = (OPTIONS.index(key), left)
                self.tv_plays = True
            if bar is not None:
                bar.setPercent(100.0 * left / LIMIT)
            if tiles:
                due = min(len(tiles), int(len(tiles) * elapsed / (LIMIT * UNCOVERED)) + 1)
                while hidden < due:
                    self.show(**{'tile.%d' % tiles[hidden]: ''})
                    hidden += 1
            here = [p['slot'] for p in self.server.roster() if p['here']] if self.server else []
            self.show(answered='%d of %d answered' % (len([s for s in answers if s != TV]), len(here)) if here else '')
            # everyone answered: on at once (the TV too once its remote plays; with no phone, the remote alone)
            if all(slot in answers for slot in here) and (TV in answers or (here and not self.tv_plays)):
                break
        return answers

    def reveal(self, number, question, answers, scores):
        right = question['answer']
        roster = self.server.roster() if self.server else []
        scores.mark(answers, right, roster)
        counts = [sum(1 for option, _left in answers.values() if option == index) for index in range(4)]
        for index in range(16):
            self.show(**{'tile.%d' % index: ''})
        self.show(phase='reveal', correct=right + 1, after=question.get('after') or question['options'][right],
                  background=question.get('after_picture') or question.get('picture') or '',
                  results='   '.join('[COLOR %s]●[/COLOR] %s %s' % (_colour(p['colour']), p['name'],
                                                                       ('+%d' % p['gain']) if p['gain'] else '0')
                                     for _rank, slot, p in scores.board() if slot in answers) or 'Nobody answered')
        for index in range(4):
            self.show(**{'count.%d' % (index + 1): counts[index] or ''})
        self.strip(scores)
        board = {slot: rank for rank, slot, _p in scores.board()}
        if self.server:
            self.server.set_quiz({'phase': 'reveal', 'n': number, 'answer': right, 'text': question['options'][right]})
            for slot, person in scores.people.items():
                if slot != TV:
                    self.server.tell(slot, {'t': 'result', 'n': number, 'answered': slot in answers,
                                            'correct': slot in answers and answers[slot][0] == right, 'gain': person['gain'],
                                            'score': person['score'], 'rank': board[slot], 'of': len(board),
                                            'text': question['options'][right]})

    def strip(self, scores):
        self.show(strip='     '.join('[COLOR %s]●[/COLOR] %s  [B]%d[/B]' % (_colour(p['colour']), p['name'], p['score'])
                                    for _rank, _slot, p in scores.board()[:6]))

    def board(self, scores, final, total):
        control = self.window.getControl(700)
        control.reset()
        for rank, _slot, person in scores.board():
            item = xbmcgui.ListItem(person['name'], str(person['score']))
            item.setProperty('rank', str(rank))
            item.setProperty('colour', _colour(person['colour']))
            item.setProperty('gain', ('+%d' % person['gain']) if person['gain'] and not final else '')
            control.addItem(item)
        winner = scores.board()[0][2]['name'] if scores.people else ''
        self.show(phase='final' if final else 'scores',
                  scores_title=('%s wins!' % winner if winner else 'Final scores') if final else 'Scores after %d' % total)
        if self.server:
            ranks = {slot: rank for rank, slot, _p in scores.board()}
            self.server.set_quiz({'phase': 'final' if final else 'scores'})
            for slot, person in scores.people.items():
                if slot != TV:
                    self.server.tell(slot, {'t': 'place', 'final': final, 'rank': ranks[slot], 'of': len(ranks),
                                            'score': person['score']})
        if final:
            self.window.setFocusId(806)

    # ---- a whole game ---------------------------------------------------------------------------------------
    def play(self):
        while not self.monitor.abortRequested():
            if self.lobby() != 'start':
                return
            round_ = self.questions()
            if not round_:
                continue
            if self.round(round_) == 'close':
                return

    def round(self, round_):
        """One game to its end (or Back twice: to the first page); Close on its podium leaves Guess It."""
        scores = Scores()
        self.tv_plays = False
        for number, question in enumerate(round_, 1):
            answers = self.ask(number, question, len(round_), scores)
            if answers is None:
                return 'lobby'
            self.reveal(number, question, answers, scores)
            if self.wait(SHOW_ANSWER) == 'back' and self.leaving():
                return 'lobby'
            if number % SCORES_EVERY == 0 and number < len(round_) and scores.people:
                self.board(scores, False, number)
                if self.wait(SHOW_SCORES) == 'back' and self.leaving():
                    return 'lobby'
        self.board(scores, True, len(round_))
        while not self.monitor.abortRequested():
            key = self.pressed(.25)
            if key in (806, 'back'):
                return 'lobby'                   # Play again, and Back: the first page
            if key == 807:
                return 'close'
        return 'close'


def open_quiz():
    """Guess It: its screen and the phones' page, for as long as it is open."""
    from resources.lib.plex_link_window import qr_png
    window = QuizWindow(XML, ADDON.getAddonInfo('path'), theme_folder(), '1080i')
    game = Game(window, None)
    server, qr = None, ''
    try:
        server = PlayServer(lambda: [], None, on_answer=lambda slot, number, option: game.answers.put((slot, number, option)),
                            mode='quiz', key=games.phone_key()).start()
        game.server = server
        qr = qr_png(server.url(), box_size=10, border=2) or ''
    except OSError as exc:
        xbmc.log('[MegaNexus] Guess It: no page for the phones (%s)' % exc.__class__.__name__, xbmc.LOGWARNING)
    screen_guard.hold()
    try:
        window.setProperty('quiz.qr', qr)
        window.setProperty('quiz.url', server.url() if server else 'Phones are not available - play with the remote.')
        window.setProperty('quiz.phase', 'lobby')
        window.show()
        if not quiz.ready():
            window.setProperty('quiz.status', MESSAGES['nokey'])
        game.play()
    finally:
        game.closing = True
        if server is not None:
            server.stop()
        window.close()
        screen_guard.release()
        if qr:
            try:
                os.remove(qr)                # the code carries this session's key
            except OSError:
                pass
        del window
