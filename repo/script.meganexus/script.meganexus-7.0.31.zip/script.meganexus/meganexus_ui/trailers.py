import xbmc
import xbmcgui
from resources.lib.trailer_support import trailer_url
import time
import threading

_PLAYER=None


def wait_for_playback():
    """Close all dialogs before calling; don't reopen Home during AV/window startup."""
    monitor=xbmc.Monitor();seen=False;start=time.monotonic()
    home=xbmcgui.Window(10000);request=home.getProperty('meganexus.playback.started')
    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    while not monitor.waitForAbort(.05):
        playing=xbmc.Player().isPlayingVideo()
        full=xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
        if full:seen=True
        if seen and not full:
            # Leaving the player is Stop, so the service commits resume before
            # the same title page returns. Closing an OSD keeps fullscreen active.
            # 7.0.29: the player's Home button leaves the film playing behind Home,
            # "Now playing" brings it back.
            if playing and not home.getProperty('meganexus.background_film'):xbmc.Player().stop()
            break
        if not playing and time.monotonic()-start>2:break
        if not seen and time.monotonic()-start>10:break
    if not xbmc.Player().isPlaying():
        home.clearProperty('meganexus.preview.active')
        # Let the service commit Stop before the details screen reads resume.
        # A missing service must not leave the UI waiting indefinitely.
        # The service saves progress and flags it within milliseconds; do not
        # keep the user staring at an empty screen longer than 0.8 s.
        for _ in range(40):
            if not request or home.getProperty('meganexus.playback.finished')==request:break
            if monitor.waitForAbort(.02):break

def _full_screen_trailer(url,meta,parent=None):
    """Kodi's own full-screen player, like a film: the screen behind it is hidden
    (a MegaNexus screen in front keeps Kodi's player from opening), Back or the
    end of the trailer brings it back."""
    import uuid
    from .home_trailers import PreviewPlayer
    from resources.lib.wallpaper_video import suspend
    from resources.lib import refresh_guard
    player=PreviewPlayer();player.token=uuid.uuid4().hex
    monitor=xbmc.Monitor();home=xbmcgui.Window(10000)
    item=xbmcgui.ListItem(label='Trailer: '+str(meta.get('name') or meta.get('title') or ''))
    item.setProperty('meganexus.preview',player.token);item.setProperty('IsPlayable','true')
    home.setProperty('meganexus.preview.active',player.token)
    suspend()
    started=False;hidden=False
    try:
        refresh_guard.suspend('trailer')
        if parent is not None:
            xbmcgui.WindowXMLDialog.close(parent);hidden=True
        player.path=url;player.play(url,item);begin=time.monotonic();full_since=None
        while not monitor.abortRequested():
            if player.owns() and (player.ready or player.getTime()>.15):started=True
            full=xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
            if full and full_since is None:full_since=time.monotonic()
            if player.failed or (started and not player.isPlayingVideo()):break
            if full_since is not None and not full and time.monotonic()-full_since>1:break   # Back
            if not started and time.monotonic()-begin>8:break
            monitor.waitForAbort(.1)
    finally:
        player.cancel();player.stop_owned();player._ended()
        home.clearProperty('meganexus.preview.active')
        refresh_guard.restore('trailer')
        if hidden:
            try:parent.show_ready()
            except Exception:pass
    return started


def play_trailer(meta):
    return show_trailer(meta)


def show_trailer(meta,parent=None):
    """Resolve/cache first, then play it in Kodi's own full-screen player
    (7.0.31, every device: the user prefers it, and boxes whose video is a
    hardware layer under the interface showed the trailer window black on
    Kodi 22). ``parent`` - the screen it was started from - is hidden meanwhile."""
    from .playback import job
    from resources.lib.trailer_cache import prepare
    if xbmc.Player().isPlayingVideo():
        xbmcgui.Dialog().ok('Trailer','Stop the current video before opening a trailer.');return False
    cancelled=threading.Event()
    def resolve():
        # Trailer source order from Settings > Trailers (YouTube and/or IMDb).
        from resources.lib.trailer_support import trailer_candidates,playable
        for candidate in trailer_candidates(trailer_url(meta),(meta,)):
            path=playable(candidate,prepare,cancelled)
            if path or cancelled.is_set():return path
        return ''
    try: url=job(resolve,meta,label='Preparing trailer')
    finally: cancelled.set()
    if not url:
        # A resolution failure never reaches Kodi's playback queue.
        return False
    return _full_screen_trailer(url,meta,parent)
