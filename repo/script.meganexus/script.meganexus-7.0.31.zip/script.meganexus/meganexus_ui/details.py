from resources.lib import art_cache
from .dialog import Dialog
from . import browse_meta
"""Title details and a plain AIOStreams selection screen."""
import xbmc
import queue
import threading
import time
import xbmcaddon
import xbmcgui
from . import listitems
from resources.lib import backend_api, simkl
from resources.lib import simkl_watched, title_details
from resources.lib.theme import folder as theme_folder



def _chosen_art(meta):
    """The title's pictures from the provider chosen in Artwork (cached only: no wait)."""
    try:
        from resources.lib import art_provider
        return art_provider.meta(meta,cached_only=True)
    except Exception:
        return meta

class Details(Dialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args)
        self.meta=_chosen_art(kwargs['meta'])
        self.action=''
        self.closed=False
        self._metadata_pending=kwargs.get('metadata_pending',False);self._metadata_job=None;self._metadata_error=False;self._after_metadata=None
        self._extra_jobs=[];self._extras_started=False
        self.context=kwargs.get('context') or {}
        self.seasons=[];self.episodes=[];self.related=list(kwargs.get('related') or []);self._related_loaded=bool(kwargs.get('related'));self._season=None;self._recommendations=queue.Queue();self._descriptions=queue.Queue();self._description_jobs=set()
        self.landscape=xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape')=='landscape'

    def _ratings(self):
        """7.0.29: MDBList's ratings row (logos + scores) when MDBList is on, else
        the title's IMDb score as IMDb's logo + the number - never as text."""
        from resources.lib import ratings_row
        from resources.lib.home_data import rating_label,rating_icon
        label=rating_label(self.meta)
        own=(rating_icon(label),label.split(' ',1)[-1]) if label else None
        def fetch(load):
            def work():
                try:ratings=load()
                except Exception:return
                if ratings and not self.closed:ratings_row.publish(self,ratings)
            threading.Thread(target=work,name='MegaNexusRatings',daemon=True).start()
        ratings_row.publish_for(self,self.meta,own,fetch)

    def _fetch_art(self):
        """7.0.29: the Artwork provider's pictures not cached yet - fetched off the UI thread."""
        def work():
            try:
                from resources.lib import art_provider
                fresh=art_provider.meta(self.meta)
            except Exception:return
            if self.closed or fresh is self.meta:return
            self.meta=fresh
            self.setProperty('meganexus.fanart',art_cache.url(fresh.get('background') or ''))
            self.setProperty('meganexus.poster',art_cache.url(fresh.get('poster') or ''))
        threading.Thread(target=work,name='MegaNexusArtwork',daemon=True).start()

    def onInit(self):
        m=self.meta
        self._fetch_art()
        from .session import scene
        scene(art_cache.url(m.get('background') or m.get('poster') or ''), m.get('name') or m.get('title') or '')
        self._season=None
        self.setProperty('meganexus.title',m.get('name') or m.get('title') or m['id'])
        self._shown_plot=None
        self.setProperty('meganexus.plot',m.get('description') or m.get('overview') or '')
        self.setProperty('meganexus.fanart',art_cache.url(m.get('background') or ''))
        self.setProperty('meganexus.poster',art_cache.url(m.get('poster') or ''))
        self.setProperty('meganexus.year',str(m.get('releaseInfo') or m.get('year') or ''))
        series=m.get('type')=='series'
        self.setProperty('meganexus.series','1' if series else '')
        self.getControl(100).setLabel('Play episode' if series else 'Play')
        for cid in (101,103,104,106):self.getControl(cid).setEnabled(not self._metadata_pending and not self._metadata_error)
        self.setProperty('meganexus.meta_line','  |  '.join(str(v) for v in (
            m.get('releaseInfo') or m.get('year'), m.get('runtime'),
            ' / '.join(str(g.get('name') or '') if isinstance(g,dict) else str(g) for g in m.get('genres') or []) if isinstance(m.get('genres'),list) else m.get('genres')) if v))
        self._people()
        self._ratings()
        if series:
            self.seasons=title_details.seasons(m)
            self.getControl(501).reset()
            self.getControl(501).addItems([listitems.item(label=title_details.season_label(n)) for n in self.seasons])
            if self.seasons:
                self.setProperty('meganexus.empty','')
                requested=title_details.number(self.context.get('season'),1)
                first=self.seasons.index(requested) if requested in self.seasons else 0
                self.getControl(501).selectItem(first);self._episodes(first);self.setFocusId(501)
            else:
                # No loading banner over the episode row: rows appear when they arrive.
                self.setProperty('meganexus.empty','' if self._metadata_pending else 'No episodes supplied for this series.')
        else:
            self.setProperty('meganexus.empty','')
        if self._metadata_pending:
            self.setProperty('meganexus.related_status','Loading details…')
            if self._metadata_job is None:self._metadata_job=browse_meta.request(self.context)
        else:self._start_extras()
        self._favorite_label()
        self._watch_badges()
        self.restore_focus()

    def _start_extras(self):
        if self._related_loaded:self._recommendations.put(self.related);return
        if self._extras_started:return
        self._extras_started=True
        self.setProperty('meganexus.related_status','Loading recommendations…')
        def load_related():
            if self.closed:return
            try:rows=title_details.related(self.meta,limit=100)
            except Exception:rows=[]
            if not self.closed:self._recommendations.put(rows)
        from .playback import _BACKGROUND
        self._extra_jobs.append(_BACKGROUND.submit(load_related))

    def _people(self):
        items=[]
        for person in self.meta.get('meganexus_people',title_details.people(self.meta)):
            li=listitems.item(label=person['name'],label2=person['role'])
            li.setArt(art_cache.art({'thumb':person.get('photo') or 'special://home/addons/script.meganexus/resources/media/person.png'}))
            items.append(li)
        self.getControl(503).reset();self.getControl(503).addItems(items)
        self.setProperty('meganexus.has_people','1' if items else '')

    def _episodes(self,index):
        if not self.seasons:return
        index=max(0,min(index,len(self.seasons)-1))
        season=self.seasons[index]
        if season==self._season:return
        self._season=season
        self.episodes=title_details.episodes(self.meta,season)
        items=[]
        for e in self.episodes:
            from resources.lib.display_text import clean, episode_line
            # 7.0.29: the card says "Episode N"; its title and description go to the top of the page.
            li=listitems.item(label='Episode %s'%e['episode'])
            li.setProperty('name',clean(e.get('title') or e.get('name') or ''))
            li.setProperty('episode_meta', episode_line(e, season))
            # 7.0.12: the episode's own still in both layouts (the series poster was shown before).
            art=e.get('thumbnail') or e.get('background') or self.meta.get('background') or e.get('poster') or self.meta.get('poster')
            li.setArt({'thumb':art_cache.card(art)})
            li.setProperty('plot',title_details.episode_plot(e,self.meta))
            li.setProperty('episode_title',(self.meta.get('name') or self.meta.get('title') or '')+' - S%s E%s - %s'%(season,e['episode'],e.get('title') or e.get('name') or 'Episode'))
            items.append(li)
        self.getControl(502).reset();self.getControl(502).addItems(items)
        selected=next((i for i,e in enumerate(self.episodes) if e['id']==self.context.get('video_id')),0)
        if items:self.getControl(502).selectItem(selected)
        self.setProperty('meganexus.season',title_details.season_label(season))
        try:
            control=self.getControl(501)
            for i in range(control.size()):control.getListItem(i).setProperty('current','1' if i==index else '')
        except Exception:pass
        self._watch_badges()
        missing=any(not title_details.episode_description(e) for e in self.episodes)
        if missing and season not in self._description_jobs:
            self._description_jobs.add(season)
            def load():
                try:data=title_details.season_descriptions(self.meta,season)
                except Exception:data={}
                if not self.closed:self._descriptions.put((season,data))
            from .playback import _BACKGROUND
            self._extra_jobs.append(_BACKGROUND.submit(load))

    def onFocus(self,cid):
        if cid==502 and self.seasons:
            self._episodes(self.getControl(501).getSelectedPosition())

    def _top_plot(self):
        """7.0.29: on an episode the top of the page describes it; elsewhere the series."""
        text=self.meta.get('description') or self.meta.get('overview') or ''
        if self.getFocusId()==502 and self.episodes:
            pos=self.getControl(502).getSelectedPosition()
            if 0<=pos<len(self.episodes):
                item=self.getControl(502).getListItem(pos)
                name=item.getProperty('name');plot=item.getProperty('plot')
                if name.lower().startswith('episode'):name=''   # no real title: "Episode 1" once
                episode=self.episodes[pos]
                head='Season %s  ·  Episode %s'%(episode.get('season') or self._season or 1,episode.get('episode'))
                text='[B]%s%s[/B][CR]%s'%(head,('  ·  '+name) if name else '',plot)
        if text!=getattr(self,'_shown_plot',None):
            self._shown_plot=text;self.setProperty('meganexus.plot',text)

    def tick(self):
        if self.closed:return
        if self.meta.get('type')=='series':self._top_plot()
        # Kodi moves horizontal list selection without another onFocus callback.
        if self.seasons and self.getFocusId()==501:
            self._episodes(self.getControl(501).getSelectedPosition())
        if self._metadata_job is not None and self._metadata_job.done():
            future,self._metadata_job=self._metadata_job,None
            try:
                meta=future.result()
                if not meta:raise ValueError('No details returned')
            except Exception:
                self._metadata_pending=False;self._metadata_error=True;self._after_metadata=None
                self.setProperty('meganexus.related_status','Details unavailable. Select Play to retry, or press Back.')
                self.getControl(100).setLabel('Retry details')
            else:
                self._metadata_pending=False;self._metadata_error=False
                try:self._restore_focus=self.getFocusId()
                except Exception:pass
                combined=dict(self.meta,**meta)
                for key in ('name','poster','background','description'):
                    if not combined.get(key):combined[key]=self.meta.get(key) or ''
                self.meta=_chosen_art(combined);self.onInit()
                # First season becomes navigable as soon as its episodes arrive.
                if self.meta.get('type')=='series' and self.seasons and self.getFocusId()==100:self.setFocusId(501)
                if self._after_metadata is not None:
                    manual=self._after_metadata;self._after_metadata=None
                    self.defer(lambda:self._play(manual))
        while not self._descriptions.empty():
            season,data=self._descriptions.get_nowait()
            if data.get('season'):
                self.meta.setdefault('meganexus_season_overviews',{})[str(season)]=data['season']
            for e in title_details.episodes(self.meta,season):
                summary=data.get(title_details.number(e.get('episode')))
                if not title_details.episode_description(e) and summary:
                    e['description']=summary
            if season==self._season:
                for i,e in enumerate(self.episodes):self.getControl(502).getListItem(i).setProperty('plot',title_details.episode_plot(e,self.meta))
        try:rows=self._recommendations.get_nowait()
        except queue.Empty:return
        self.related=rows;self._related_loaded=True
        self.setProperty('meganexus.related_status','' if rows else 'No recommendations available for this title.')
        items=[];watched=simkl_watched.snapshot()
        for row in rows[:16]:
            li=listitems.item(label=row['title'])
            li.setArt({'thumb':art_cache.card((row.get('fanart') or row.get('poster')) if self.landscape else row.get('poster'))})
            li.setProperty('plot',row.get('plot') or '')
            target=row['target'];li.setProperty('watched','1' if simkl_watched.state(watched,target['media_type'],target['canonical_id']).get('watched') else '')
            items.append(li)
        self.getControl(504).reset();self.getControl(504).addItems(items)

    def child(self,fn,*args,**kwargs):
        if self.seasons:
            self.context['season']=self._season
            if self.episodes:
                pos=max(0,min(self.getControl(502).getSelectedPosition(),len(self.episodes)-1))
                self.context['video_id']=self.episodes[pos]['id']
        return super().child(fn,*args,**kwargs)

    def _more_like(self):
        from .catalog import open_catalog
        if not self._related_loaded:
            from .playback import job
            rows=job(lambda:title_details.related(self.meta,limit=100),label='Finding similar titles')
            if not rows:
                xbmcgui.Dialog().notification('More like this','No similar titles were found.',time=3000);return
            self.related=list(rows);self._related_loaded=True
        self.child(open_catalog,{'label':'More like this · '+str(self.meta.get('name') or self.meta.get('title') or ''),'rows':self.related})

    def _person(self):
        from .playback import job
        from .catalog import open_catalog
        persons=self.meta.get('meganexus_people',title_details.people(self.meta))
        pos=self.getControl(503).getSelectedPosition()
        if not 0<=pos<len(persons):return
        person=persons[pos]
        self.child(open_person,person)

    def _info(self,episode=False):
        if self._metadata_pending or self._metadata_error:return
        entry=None
        if episode and self.episodes:
            entry=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
        show_info(self.meta,entry)

    def _watch_badges(self):
        m=self.meta;mid=m.get('id') or self.context.get('canonical_id')
        entry=simkl_watched.state(simkl_watched.snapshot(),m.get('type') or 'movie',mid)
        self.setProperty('meganexus.watched','1' if entry.get('watched') else '')
        # 7.0.29: the same button takes a mark away again
        try:self.getControl(104).setLabel('Unmark watched' if entry.get('watched') else 'Mark watched')
        except Exception:pass
        for i,season in enumerate(self.seasons):
            eps=title_details.episodes(m,season)
            watched=entry.get('watched') or str(season) in entry.get('seasons',[]) or (bool(eps) and all(simkl_watched.is_episode_watched(entry,season,e['episode']) for e in eps))
            self.getControl(501).getListItem(i).setProperty('watched','1' if watched else '')
        for i,e in enumerate(self.episodes):
            self.getControl(502).getListItem(i).setProperty('watched','1' if simkl_watched.is_episode_watched(entry,e.get('season',1),e['episode']) else '')
        self._watch_next(entry)

    def _watch_next(self,entry):
        """7.0.29: "Next · S5 E3" before the seasons - the episode after the last one
        watched (the latest season and episode watched, whatever is left behind)."""
        self._watch_next_target=None
        if (self.meta.get('type') or '')!='series' or not self.seasons:
            self.setProperty('meganexus.next.label','');return
        order=[(s,e) for s in self.seasons if str(s)!='0' for e in title_details.episodes(self.meta,s)]
        last=max((i for i,(s,e) in enumerate(order) if simkl_watched.is_episode_watched(entry,e.get('season',s),e['episode'])),default=None)
        if last is not None and last+1<len(order):
            season,e=order[last+1]
            self._watch_next_target=(season,e["id"])
            self.setProperty('meganexus.next.label','Next · S%s E%s'%(e.get('season',season),e['episode']))
        else:self.setProperty('meganexus.next.label','')

    def _go_next(self):
        """Select the next episode (its season pill, then the episode) - OK plays it."""
        if not getattr(self,"_watch_next_target",None):return
        season,video_id=self._watch_next_target
        if season not in self.seasons:return
        index=self.seasons.index(season)
        try:self.getControl(501).selectItem(index)
        except Exception:pass
        self._episodes(index)
        pos=next((i for i,e in enumerate(self.episodes) if e['id']==video_id),0)
        self.getControl(502).selectItem(pos);self.setFocusId(502)

    def _mark_watched(self,only=None,unmark=False):
        from .playback import job
        from resources.lib import trakt
        # 6.0.39: Simkl and/or Trakt, whichever is connected (Trakt-only users too).
        from resources.lib import mdblist_tracking
        # 7.0.29: MDBList too, when its tracking is on - every connected service.
        services=[name for name,on in (('Simkl',simkl.authorized()),('Trakt',trakt.authorized()),('MDBList',mdblist_tracking.enabled())) if on]
        if not services:
            from .simkl_account import link
            if not link():return
            services=['Simkl']
        m=self.meta;scope='title';season=episode=None
        if m.get('type')=='series' and only=='episode' and self.episodes:
            # 7.0.29: long OK on an episode - that episode, no question
            e=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
            scope='episode';season=e.get('season',1);episode=e['episode']
        elif m.get('type')=='series':
            if self.seasons:self._episodes(self.getControl(501).getSelectedPosition())
            choices=['Entire series (all aired episodes)']
            if self.seasons:
                season=self.seasons[max(0,self.getControl(501).getSelectedPosition())]
                choices.append(title_details.season_label(season))
            if self.episodes:
                e=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
                choices.append('Episode S%s E%s - %s'%(e.get('season',1),e['episode'],e.get('title') or e.get('name') or 'Episode'))
            pick=xbmcgui.Dialog().select(('Unmark watched on ' if unmark else 'Mark watched on ')+' and '.join(services),choices)
            if pick<0:return
            scope=('title','season','episode')[pick]
            if scope=='episode':season=e.get('season',1);episode=e['episode']
        from resources.lib.plugin import extract_ids
        ctx=dict(extract_ids(m),media_type=m.get('type') or 'movie',canonical_id=m.get('id') or '',title=m.get('name') or m.get('title') or '')
        from resources.lib import trakt_watched
        marks={'Simkl':simkl_watched.mark,'Trakt':trakt_watched.mark,'MDBList':mdblist_tracking.mark}
        if unmark:marks={'Simkl':simkl_watched.unmark,'Trakt':trakt_watched.unmark,'MDBList':mdblist_tracking.unmark}
        failed=[]
        for name in services:
            try:job(lambda fn=marks[name]:fn(ctx,scope,season,episode),label='Saving watched status to '+name)
            except Exception as exc:failed.append('%s: %s'%(name,str(exc) if isinstance(exc,ValueError) else 'could not save. Please retry.'))
        self._watch_badges()
        if failed:xbmcgui.Dialog().ok('Unmark watched' if unmark else 'Mark watched','[CR]'.join(failed))

    def _play(self,manual=False):
        if self._metadata_pending or self._metadata_error:
            self._after_metadata=manual;self.getControl(100).setLabel('Preparing video…')
            if self._metadata_error:
                self._metadata_error=False;self._metadata_pending=True;self._metadata_job=browse_meta.request(self.context)
            return
        context=dict(self.context)
        if manual:context['force_manual']=True
        if self.meta.get('type')=='series':
            if self.seasons:self._episodes(self.getControl(501).getSelectedPosition())
            if not self.episodes:
                xbmcgui.Dialog().ok('Episodes','The selected metadata provider has no episodes for this series.');return
            pos=max(0,self.getControl(502).getSelectedPosition())
            e=self.episodes[min(pos,len(self.episodes)-1)]
            if context.get('video_id')!=e['id']:
                context.pop('resume_seconds',None);context.pop('resume_percent',None)
            context.update(video_id=e['id'],season=e.get('season',1),episode=e['episode'])
        if context.pop('meganexus_refresh_local_resume',False):
            # Stop may be delivered after this window began opening. Read the
            # committed final position again at the actual playback click.
            from resources.lib import continue_local
            saved=next((r for r in continue_local.recent() if r.get('canonical_id')==self.meta['id'] and r.get('video_id')==(context.get('video_id') or self.meta['id'])),None)
            context.pop('resume_seconds',None);context.pop('resume_percent',None)
            if saved and saved.get('event_type')!='watched':
                context.update(resume_seconds=saved.get('position') or 0,resume_percent=saved.get('percent') or 0)
        self.context=context
        # 7.0.29: this page hides once the video starts (Kodi refuses its full-screen
        # video while a page like this is open - the page showed before the film).
        from . import playback
        self._meganexus_play_hidden=False;playback.PARENTS.append(self)
        try:started=choose_stream(self.meta,context)
        finally:
            try:playback.PARENTS.remove(self)
            except ValueError:pass
        if started:self.action='playing';self.close()
        elif self._meganexus_play_hidden:
            self._meganexus_play_hidden=False;self.show_ready()   # it did not start: the page again

    def _favorite_label(self):
        try:
            from resources.lib import library
            inside=library.contains(self.meta.get('type') or 'movie',self.meta.get('id') or '')
        except Exception:inside=False
        self.getControl(101).setLabel('In Library' if inside else 'Add to Library')

    def _add_to_library(self):
        # 6.0.35: the MegaNexus Library (local, synced with the Nuvio account)
        # plus Trakt / Simkl when connected - no Simkl sign-in required.
        from .playback import job
        from resources.lib import library
        mt=self.meta.get('type') or 'movie';mid=self.meta.get('id') or ''
        try:
            if library.contains(mt,mid):
                library.remove(mt,mid);xbmcgui.Dialog().notification('Library','Removed from Library',time=3000)
            else:
                item=dict(self.meta,media_type=mt,canonical_id=mid,title=self.meta.get('name') or self.meta.get('title') or '')
                reached=job(lambda:library.add(item),label='Saving to Library')
                extra=(' and '+' + '.join(reached)) if reached else ''
                xbmcgui.Dialog().notification('Library','Saved to Library'+extra,time=3000)
        except Exception as exc:
            xbmcgui.Dialog().ok('Library',str(exc) if isinstance(exc,ValueError) else 'The Library could not be updated.')
        self._favorite_label()

    def onClick(self,control_id):
        if control_id==100:
            self._play()
        elif control_id==501:
            self._episodes(self.getControl(501).getSelectedPosition());self.setFocusId(502)
        elif control_id==507:self._go_next()   # 7.0.29: Watch next
        elif control_id==502:self._play()
        elif control_id==103:
            from .trailers import show_trailer
            if not show_trailer(self.meta,parent=self):self.setProperty('meganexus.trailer_status','Trailer unavailable. Try another title, or change the trailer source in Settings > Trailers.')
        elif control_id==101:
            self._add_to_library()
        elif control_id==104:self._mark_watched(unmark=self.getProperty('meganexus.watched')=='1')
        elif control_id==105:self._more_like()
        elif control_id==106:self._more_like()   # 7.0.29: More like this took Info's place
        elif control_id==503:
            self._person()
        elif control_id==504 and self.related:
            row=self.related[self.getControl(504).getSelectedPosition()]
            outcome=self.child(open_context,row['target'],row=row)
            if outcome=='playing' or isinstance(outcome,dict):self.action=outcome;self.close()
        elif control_id==102:self.close()

    def close(self):
        if self._metadata_job:self._metadata_job.cancel()
        for future in self._extra_jobs:future.cancel()
        self.closed=True
        super().close()

    def onAction(self,action):
        aid=action.getId()
        if aid in (9,10,92,216):
            self.close()
        elif aid in (117,101,1009,11):
            focus=self.getFocusId()
            if focus==504 and self.related:
                row=self.related[self.getControl(504).getSelectedPosition()]
                choice='info' if aid==11 else context_choice(row['target'],row)
                if not choice or quick_choice(choice,row['target'],row):return
                outcome=(self.in_place if plays_directly(row['target'],row,choice) else self.child)(run_choice,row['target'],choice,row)
                if outcome=='playing' or isinstance(outcome,dict):self.action=outcome;self.close()
                return
            if focus==502 and aid!=11 and self.episodes:
                # 7.0.29: an episode's own options
                e=self.episodes[max(0,self.getControl(502).getSelectedPosition())]
                pos=max(0,self.getControl(502).getSelectedPosition())
                seen=self.getControl(502).getListItem(pos).getProperty('watched')=='1'
                label=('Unmark watched · S%s E%s' if seen else 'Mark watched · S%s E%s')%(e.get('season',1),e['episode'])
                choice=context_choice(options=[('episode_watched',label),('manual','Choose stream manually'),('info','Info')])
                if choice=='episode_watched':self._mark_watched(only='episode',unmark=seen);return
            else:choice='info' if aid==11 else context_choice()
            if choice=='manual':
                if focus==501:self._episodes(self.getControl(501).getSelectedPosition())
                self._play(manual=True)
            elif choice=='related':self._more_like()
            elif choice=='info':self._info(episode=focus==502)


class Info(Dialog):
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self.meta=kwargs['meta'];self.episode=kwargs.get('episode')
    def onInit(self):
        m=self.meta;e=self.episode
        title=m.get('name') or m.get('title') or ''
        if e:title+=' - S%s E%s - %s'%(e.get('season',1),e.get('episode'),e.get('title') or e.get('name') or 'Episode')
        self.setProperty('meganexus.title',title)
        self.setProperty('meganexus.poster',art_cache.url(m.get('poster') or ''))
        plot=title_details.episode_plot(e,m) if e else (m.get('overview') or m.get('description') or 'No description supplied.')
        self.setProperty('meganexus.plot',plot)
        self.getControl(510).setText(plot)
        self.getControl(503).reset()
        items=[]
        for person in m.get('meganexus_people',title_details.people(m)):
            li=listitems.item(label=person['name'],label2=person['role'])
            li.setArt(art_cache.art({'thumb':person.get('photo') or 'special://home/addons/script.meganexus/resources/media/person.png'}));items.append(li)
        self.getControl(503).addItems(items)
        self.setProperty('meganexus.has_people','1' if items else '')
    def onClick(self,cid):
        if cid==102:self.close()
        elif cid==503:Details._person(self)
    def onAction(self,action):
        if action.getId() in (9,10,92,216):self.close()


def show_info(meta,episode=None):
    win=Info('meganexus_info.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',meta=meta,episode=episode)
    try:win.doModal()
    finally:win.close()


class ContextMenu(Dialog):
    """Title options (6.0.35): the options depend on the card (see title_options)."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args);self.choice='';self.options=list(kwargs.get('options') or DEFAULT_OPTIONS)[:7]
        self.heading=kwargs.get('heading') or 'Title options'
        self._focus_ready=False
    def onInit(self):
        self.setProperty('meganexus.opt.title',self.heading)
        for i in range(7):self.setProperty('meganexus.opt.%d'%i,self.options[i][1] if i<len(self.options) else '')
        self.setProperty('meganexus.opt.count',str(len(self.options)))
        self.setFocusId(100)
    def tick(self):
        if not self._focus_ready:
            self.setFocusId(100);self._focus_ready=True
    def onClick(self,cid):
        if 100<=cid<100+len(self.options):
            self.choice=self.options[cid-100][0]
            self.close()
    def onAction(self,action):
        if action.getId() in (9,10,92,216):self.close()


DEFAULT_OPTIONS=(('manual','Choose stream manually'),('related','More like this'),('info','Info'))
# Choices that open another screen (the caller hides its window for them).
SCREEN_CHOICES=('manual','start','related','info')


def title_options(context,row=None):
    """Options for one card. Continue Watching cards add Play from the
    beginning / Remove (GitHub issue #5); every title can be added to or
    removed from the Library."""
    row=row or {};options=[]
    kind=row.get('continue_card')
    if kind=='resume' and float((row.get('target') or context).get('resume_seconds') or 0)>0:
        options.append(('start','Play from the beginning'))
    options.append(('manual','Choose stream manually'))
    if kind in ('resume','next'):options.append(('remove','Remove from Continue Watching'))
    try:
        from resources.lib import library
        inside=library.contains(context.get('media_type') or 'movie',context.get('canonical_id') or '')
    except Exception:inside=False
    options.append(('unlibrary','Remove from Library') if inside else ('library','Add to Library'))
    options+=[('related','More like this'),('info','Info')]
    return options


def context_choice(context=None,row=None,options=None):
    options=options or (title_options(context,row) if context else DEFAULT_OPTIONS)
    win=ContextMenu('meganexus_context.xml',xbmcaddon.Addon('script.meganexus').getAddonInfo('path'),theme_folder(),'1080i',options=options)
    try:win.doModal();return win.choice
    finally:win.close()


def quick_choice(choice,context,row=None):
    """Choices that need no screen. Returns True when handled."""
    row=row or {}
    mt=context.get('media_type') or 'movie';mid=context.get('canonical_id') or ''
    if choice=='remove':
        # Hidden until played again; progress and watched state stay as they are.
        from resources.lib import continue_rules
        continue_rules.hide(mt,mid)
        import time
        xbmcgui.Window(10000).setProperty('meganexus.progress.revision','removed-%s'%time.time())
        xbmcgui.Dialog().notification('Continue Watching','Removed. It returns when you play it again.',time=3000)
        return True
    if choice in ('library','unlibrary'):
        from resources.lib import library
        from .playback import job
        title=row.get('title') or context.get('title') or ''
        try:
            if choice=='library':
                item=dict(row,media_type=mt,canonical_id=mid,title=title)
                reached=job(lambda:library.add(item),label='Saving to Library')
                extra=(' and '+' + '.join(reached)) if reached else ''
                xbmcgui.Dialog().notification('Library','Saved to Library'+extra,time=3000)
            else:
                library.remove(mt,mid)
                xbmcgui.Dialog().notification('Library','Removed from Library',time=3000)
        except Exception as exc:
            xbmcgui.Dialog().ok('Library',str(exc) if isinstance(exc,ValueError) else 'The Library could not be updated.')
        return True
    return False


def run_choice(context,choice,row=None):
    """Screens opened from Title options."""
    if choice=='related':return more_like_this(context,row)
    ctx=dict(context,details_view=choice)
    if choice=='manual':ctx['force_manual']=True
    if choice=='start':
        ctx.pop('details_view',None)
        ctx.update(resume_seconds=0,resume_percent=0,play_from_start=True)
    return open_context(ctx,row=row)


def more_like_this(context,row=None):
    """More like this opens straight as a grid (6.0.35)."""
    from .playback import job
    from .catalog import open_catalog
    mt=context.get('media_type') or 'movie';mid=context.get('canonical_id') or ''
    def load():
        meta=browse_meta.cached(dict(context,media_type=mt,canonical_id=mid)) or backend_api.metadata(mt,mid)
        return meta,title_details.related(meta,limit=100)
    try:result=job(load,label='Loading recommendations')
    except Exception:result=None
    if not result:
        xbmcgui.Dialog().ok('More like this','No recommendations are available for this title.');return ''
    meta,rows=result
    if not rows:
        xbmcgui.Dialog().ok('More like this','No recommendations are available for this title.');return ''
    return open_catalog({'label':'More like this · '+str(meta.get('name') or meta.get('title') or (row or {}).get('title') or ''),'rows':rows})


def context_menu(context,info=False,row=None):
    """Title options and the chosen action in one call (callers that are
    already hidden). Home and catalog screens show the options first, over
    themselves, then hide only for screen choices."""
    choice='info' if info else context_choice(context,row)
    if not choice or quick_choice(choice,context,row):return ''
    return run_choice(context,choice,row)


def choose_stream(meta,context):
    from .playback import play
    try:return play(meta,context)
    except Exception as exc:
        xbmcgui.Dialog().ok('Playback',str(exc) if isinstance(exc,ValueError) else 'Could not load this source. Check your provider configuration and connection.')
        return False


def _autoplay(context):
    return xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_autoplay')=='true' and not context.get('force_manual')


def plays_directly(context,row=None,choice=None):
    """7.0.29: does this start the video (or its source list) without the title page?
    Then the screen it comes from stays (Dialog.in_place) instead of closing first."""
    context=context or {}
    mt=context.get('media_type') or context.get('type') or 'movie'
    if choice is not None:
        if choice=='start':return True
        return choice=='manual' and (mt=='movie' or bool(context.get('video_id')))
    if context.get('details_view'):return False
    return bool(context.get('resume_seconds') or context.get('video_id') or context.get('play_from_start'))


def open_context(context,row=None):
    mid=context.get('canonical_id') or context.get('id') or ''
    if not mid:return ''
    mt=context.get('media_type') or context.get('type') or 'movie'
    if mt in ('tv','show','tvshow','episode','anime'):mt='series'
    context=dict(context,canonical_id=mid,media_type=mt)
    if (row or {}).get('continue_card') in ('resume','next'):context['meganexus_continue']=True
    meta=browse_meta.cached(context)
    metadata_pending=meta is None
    if meta is None:meta=browse_meta.seed(context,row)
    view=context.get('details_view')
    direct=(view=='manual' and (mt=='movie' or context.get('video_id'))) or (not view and (context.get('resume_seconds') or context.get('video_id') or context.get('play_from_start')))
    starting=None
    if metadata_pending and (direct or view=='info'):
        from .playback import job,Loading,ROOT
        if direct and not _autoplay(context):
            # 7.0.29: the sources are chosen over the screen it was started from.
            from .playback import wait_overlay
            starting=wait_overlay('Loading sources…',meta)
        elif direct:
            # 7.0.29: a resume starts on the title's own picture, in ONE loading
            # screen up to the video (two in a row showed the wallpaper between).
            starting=Loading('meganexus_loading.xml',ROOT,theme_folder(),'1080i',meta=meta,full=True,label='Loading video…')
            starting.show()
        try:meta=job(lambda:backend_api.metadata(mt,mid),meta,label=('Loading video…' if _autoplay(context) else 'Loading sources…') if starting else 'Loading details',window=starting)
        except Exception:meta=None
        if starting is not None and meta:
            try:starting.apply(meta)   # the full details' picture and logo
            except Exception:pass
        if not meta:
            if starting:starting.close()
            return ''
        metadata_pending=False
    if view=='info':
        episode=next((e for e in title_details.episodes(meta) if e['id']==context.get('video_id')),None) if mt=='series' else None
        show_info(meta,episode);return ''
    if starting is not None:
        from .playback import handoff
        handoff(starting)
    try:playing=bool(direct and choose_stream(meta,context))
    finally:
        if starting is not None:
            from .playback import _take_handoff
            _take_handoff()           # not taken (another path): never left open
            try:starting.close()
            except Exception:pass
    addon=xbmcaddon.Addon('script.meganexus')
    filename='meganexus_details_landscape.xml' if xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_card_shape')=='landscape' else 'meganexus_details.xml'
    related=None
    while True:
        if playing:
            from .trailers import wait_for_playback
            wait_for_playback()
            import json
            home=xbmcgui.Window(10000);raw=home.getProperty('meganexus.next_episode')
            home.clearProperty('meganexus.next_episode')
            if raw:
                try:next_context=json.loads(raw)
                except ValueError:next_context={}
                if next_context.get('canonical_id')==mid:
                    context=next_context
                    playing=choose_stream(meta,context)
                    if playing:continue
            from resources.lib import continue_local
            saved=next((r for r in continue_local.recent() if r.get('canonical_id')==mid and r.get('video_id')==context.get('video_id')),None)
            context.pop('resume_seconds',None);context.pop('resume_percent',None)
            if saved and saved.get('event_type')!='watched':
                context.update(resume_seconds=saved.get('position') or 0,resume_percent=saved.get('percent') or 0)
            context['meganexus_refresh_local_resume']=True
            playing=False
        window=Details(filename,addon.getAddonInfo('path'),theme_folder(),'1080i',meta=meta,context=context,metadata_pending=metadata_pending,related=related)
        try:
            window.doModal();action=window.action;context=dict(window.context)
            meta=window.meta;metadata_pending=window._metadata_pending
            # Returning from the player reuses loaded recommendations.
            related=window.related if getattr(window,'_related_loaded',False) else None
        finally:window.close()
        if action=='playing':playing=True;continue
        return action


def open_person(person):
    from .playback import job
    from .person import open_page
    try:
        page = job(lambda: title_details.person_page(person), label='Loading actor · Movies and Series')
    except Exception as exc:
        xbmcgui.Dialog().ok('Actor filmography', str(exc) if isinstance(exc, ValueError) else 'Filmography could not load. Check the metadata add-ons and retry.')
        return ''
    if page is None:
        return ''
    return open_page(page)
