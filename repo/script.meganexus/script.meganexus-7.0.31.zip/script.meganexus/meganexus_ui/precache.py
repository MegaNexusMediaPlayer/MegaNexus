"""Kodi stores collection posters in advance - the One-time setup (7.0.8, 7.0.18).

Kodi makes its own copy of a poster (decode, resize, write to its texture cache
on disk) the first time it shows it, so a collection opened for the first time
showed its posters one by one (very visible on Android / CoreELEC boxes).
Kodi does the same work for an invisible image: behind the "One-time setup"
screen on opening MegaNexus (meganexus_loading.xml, Window.Property(
meganexus.precache.N)) it stores the first screen of every collection - after
the first install, after every update and when Kodi lacks more than 10 % of
them (``needs_full`` / ``plan``). Home opens at 90 %. Nothing runs in the
background afterwards (7.0.18: it competed with Kodi's own work on CoreELEC);
Kodi's normal cache takes over. About 30 KB per poster on the device.
HUB Settings > Performance turns it off (meganexus_poster_precache).
"""
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen

import xbmcaddon
import xbmcgui

from . import kodi_textures

SLOTS = 30            # a collection's first screen at once, as when it opens
SLOTS_ARM = 10        # 7.0.17: CoreELEC / Android boxes decode far fewer at once
PER_SHELF = 16        # 7.0.30: a row's whole first page (was 12: the first screen)
WAIT = 8              # seconds Kodi gets for one picture (7.0.30: each on its own)
STALL = 2             # ... or fewer when it stores nothing more (a broken image link)
FULL_SHARE = .8       # Kodi keeps fewer than this share of the last full preload: preload again
TOTAL_SETTING = 'meganexus_precache_total'
VERSION_SETTING = 'meganexus_precache_version'   # 7.0.16: the preload runs again after every update
AHEAD_WORKERS = 6     # the next batch downloads into the image RAM while Kodi stores this one
RING_STEPS = 20
RING_DONE = .9        # the ring next to HUB shows the tick from 90 % (the rest needs no watching)

# This interface session: posters Kodi keeps (done), those still to store
# (todo, Home order) and every poster MegaNexus wants stored (wanted, the ring).
_STATE = {'lock': threading.Lock(), 'base': '', 'done': set(), 'todo': {}, 'wanted': set(), 'skipped': set(),
          'titles': [], 'shown_done': False}


def slots():
    """Invisible images in use at once: fewer on ARM boxes (CoreELEC, Android)."""
    import platform
    machine = (platform.machine() or '').lower()
    return SLOTS_ARM if machine.startswith(('arm', 'aarch')) else SLOTS


def enabled():
    try:
        return xbmcaddon.Addon('plugin.video.meganexus').getSetting('meganexus_poster_precache') != 'false'
    except Exception:
        return False


def base():
    value = xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
    return value if value.startswith('http://127.0.0.1:') else ''


def _reset(proxy):
    if _STATE['base'] != proxy:
        _STATE.update(base=proxy, done=set(), todo={}, wanted=set(), skipped=set(), titles=[], shown_done=False)


def card_art(row, landscape=False):
    if landscape:
        return str(row.get('landscape') or row.get('fanart') or row.get('poster') or '')
    return str(row.get('poster') or '')


def targets(proxy, rows, landscape=False, titles=None, raw=None):
    """Proxy URLs of the first page of one row (cards without a picture link are
    not counted). ``titles`` collects (media type, imdb id, tmdb id) for ratings,
    ``raw`` the picture links themselves."""
    result = []
    for row in [r for r in rows or [] if r.get('target') or r.get('collection_id')][:PER_SHELF]:
        url = card_art(row, landscape and bool(row.get('target')))
        if url.startswith(('https://', 'http://')) and '|' not in url:
            result.append(kodi_textures.proxy_url(proxy, url))
            if raw is not None:
                raw.append(url)
        target = row.get('target') or {}
        if titles is not None and target:
            canonical = str(target.get('canonical_id') or '')
            imdb = str(target.get('imdb_id') or (canonical if canonical.startswith('tt') else '')).split(':')[0]
            tmdb = str(target.get('tmdb_id') or (canonical.split(':', 1)[1] if canonical.startswith('tmdb:') else ''))
            if imdb or tmdb:
                titles.append((target.get('media_type') or 'movie', imdb, tmdb))
    return result


def home_targets(proxy, landscape=False, titles=None):
    """7.0.30: Home's own rows - Continue Watching, collection tiles, catalog rows."""
    from resources.lib import home_data
    found = []
    for shelf in home_data.initial_shelves()[:home_data.MAX_ROWS]:
        rows = shelf.get('rows') or []
        if shelf.get('job') or shelf.get('collection_job'):
            try:
                rows = home_data.load_catalog(shelf, cached_only=True) or rows
            except Exception:
                pass
        found.extend(targets(proxy, rows, landscape, titles))
    return found


# 7.0.31: what the opening check learnt from each row - its picture links and
# titles - kept with the version of the catalog pages it came from. Reading every
# page again took 41 s for 600 collections on a CoreELEC box (about 130 MB of
# JSON); now only pages that changed are read.
ROWS_FILE = 'precache-rows.json'
_ROWS = {}


def _rows_path():
    import os
    from resources.lib.meganexus.common import profile_path
    return os.path.join(profile_path(), ROWS_FILE)


def _load_rows():
    import json
    if not _ROWS:
        try:
            with open(_rows_path(), encoding='utf-8') as handle:
                data = json.load(handle)
            _ROWS.update(data if isinstance(data, dict) else {})
        except (OSError, ValueError):
            pass
        _ROWS.setdefault('', {})
    return _ROWS


def _save_rows(used):
    import json, os
    keep = {key: value for key, value in _ROWS.items() if key in used}
    _ROWS.clear()
    _ROWS.update(keep)
    _ROWS.setdefault('', {})
    path = _rows_path()
    try:
        with open(path + '.part', 'w', encoding='utf-8') as handle:
            json.dump(keep, handle, separators=(',', ':'))
        os.replace(path + '.part', path)
    except OSError:
        pass


def _shelf_identities(shelf):
    from resources.lib import browse_cache
    if shelf.get('collection_job'):
        jobs = shelf['collection_job']
    elif shelf.get('job'):
        provider, catalog = shelf['job']
        jobs = [(provider, catalog, shelf.get('extra') or {})]
    else:
        return []
    return [browse_cache.catalog_key(provider, catalog, extra or {}) for provider, catalog, extra in jobs]


def _art_signature():
    try:
        from resources.lib import art_provider
        from resources.lib.settings_cache import cached_addon
        return str(art_provider.summary(cached_addon()))
    except Exception:
        return ''


def shelves_targets(proxy, shelves, landscape=False, titles=None, remembered=None):
    """Picture links (and titles) of these rows' first pages: from what an
    earlier check learnt when the catalog pages have not changed, else read
    from the cached pages (cached_only - no network)."""
    from resources.lib import browse_cache, home_data
    rows_memo = _load_rows()
    identities = [_shelf_identities(shelf) for shelf in shelves]
    stamps = browse_cache.instance().stamps([key for keys in identities for key in keys])
    art = _art_signature()
    found, used = [], set()
    for shelf, keys in zip(shelves, identities):
        saved_rows = remembered(shelf) if remembered else None
        signature = None
        if keys and saved_rows is None and all(key in stamps for key in keys):
            signature = [stamps[key] for key in keys] + [bool(landscape), art, PER_SHELF]
            memo_key = '|'.join(keys)
            hit = rows_memo.get(memo_key)
            if hit and hit.get('sig') == signature:
                used.add(memo_key)
                found.extend(kodi_textures.proxy_url(proxy, url) for url in hit.get('urls') or [])
                if titles is not None:
                    titles.extend(tuple(t) for t in hit.get('titles') or [])
                continue
        rows = saved_rows
        if rows is None:
            try:
                rows = home_data.load_catalog(shelf, cached_only=True)
            except Exception:
                rows = None
        own, raw = [], []
        found.extend(targets(proxy, rows, landscape, own, raw))
        if titles is not None:
            titles.extend(own)
        if signature is not None and rows is not None:
            memo_key = '|'.join(keys)
            used.add(memo_key)
            rows_memo[memo_key] = {'sig': signature, 'titles': own, 'urls': raw}
    _USED_ROWS.update(used)
    return found


_USED_ROWS = set()


def collection_targets(proxy, collection_id, landscape=False, remembered=None, titles=None):
    """First screens of every row of a collection (cached catalog pages only)."""
    from resources.lib import home_data
    from resources.lib.collections_home import collection_shelves
    return shelves_targets(proxy, collection_shelves(collection_id), landscape, titles, remembered)


def mark(proxy, kept):
    with _STATE['lock']:
        _reset(proxy)
        _STATE['done'].update(kept)
        for url in kept:
            _STATE['todo'].pop(url, None)


def add(proxy, urls, front=False):
    """Queue posters for the idle work (front: the cursor's neighbours)."""
    if not proxy or not urls:
        return
    with _STATE['lock']:
        _reset(proxy)
        urls = list(dict.fromkeys(urls))
        _STATE['wanted'].update(urls)
        new = {url: True for url in urls if url not in _STATE['done']}
        if front:
            new.update((url, True) for url in _STATE['todo'] if url not in new)
            _STATE['todo'] = new
        else:
            for url in new:
                _STATE['todo'].setdefault(url, True)
    publish()


def peek(count, skip=()):
    with _STATE['lock']:
        result = []
        for url in _STATE['todo']:
            if len(result) >= count:
                break
            if url not in _STATE['done'] and url not in skip:
                result.append(url)
        return result


def _head(url):
    """Download it into the image memory; False when the picture is not there."""
    try:
        with urlopen(Request(url, method='HEAD'), timeout=6) as response:
            response.read(0)
            return 200 <= getattr(response, 'status', 200) < 300
    except Exception:
        return False


# 7.0.30: pictures that could not be fetched are skipped at once and for a day -
# they held the opening screen (8 s each, on every start). Kodi still loads them
# when a card shows one, if they exist by then.
BROKEN_FILE = 'precache-unavailable.json'
BROKEN_DAYS = 1
_BROKEN = {}


def _broken_path():
    import os
    from resources.lib.meganexus.common import profile_path
    return os.path.join(profile_path(), BROKEN_FILE)


def unavailable():
    """Picture links that could not be fetched within the last day."""
    import json
    if not _BROKEN:
        try:
            with open(_broken_path(), encoding='utf-8') as handle:
                data = json.load(handle)
            _BROKEN.update(data if isinstance(data, dict) else {})
        except (OSError, ValueError):
            pass
        _BROKEN.setdefault('', 0)
    now = time.time()
    return {url for url, at in _BROKEN.items() if url and now - at < BROKEN_DAYS * 86400}


def _remember_unavailable(urls):
    import json, os
    unavailable()
    now = time.time()
    for url in urls:
        _BROKEN[url] = now
    keep = {url: at for url, at in _BROKEN.items() if url and now - at < BROKEN_DAYS * 86400}
    path = _broken_path()
    try:
        with open(path + '.part', 'w', encoding='utf-8') as handle:
            json.dump(keep, handle)
        os.replace(path + '.part', path)
    except OSError:
        pass


def take_url(url):
    with _STATE['lock']:
        _STATE['todo'].pop(url, None)


def pending():
    with _STATE['lock']:
        return bool(_STATE['todo'])


def take(count):
    with _STATE['lock']:
        batch = []
        while _STATE['todo'] and len(batch) < count:
            url = next(iter(_STATE['todo']))
            del _STATE['todo'][url]
            if url not in _STATE['done']:
                batch.append(url)
        return batch


def store(window, batch, stopped, wait=time.sleep):
    """Hand a batch to Kodi through the window's invisible images and wait
    until its texture cache has them (or WAIT). Returns how many were stored."""
    kept = kodi_textures.kept(batch)
    left = [url for url in batch if url not in kept][:slots()]
    stored = 0
    with _STATE['lock']:
        _STATE['done'].update(kept)
    if left:
        for slot, url in enumerate(left):
            window.setProperty('meganexus.precache.%d' % slot, kodi_textures.texture(url))
        waiting = set(left)
        deadline = time.monotonic() + WAIT
        moved = time.monotonic()
        try:
            while waiting and not stopped() and time.monotonic() < deadline and time.monotonic() - moved < STALL:
                if wait(.1):
                    break
                got = kodi_textures.kept(waiting)
                if got:
                    moved = time.monotonic()
                    waiting -= got
                    stored += len(got)
                    with _STATE['lock']:
                        _STATE['done'].update(got)
                    publish()
        finally:
            for slot in range(len(left)):
                window.setProperty('meganexus.precache.%d' % slot, '')
            if waiting and not stopped():
                with _STATE['lock']:
                    _STATE['skipped'].update(waiting)   # 7.0.30: not stored in time - not counted
    publish()
    return stored


def progress():
    """(stored, wanted) - pictures Kodi could not get in time (a broken or
    unknown link) no longer count (7.0.30)."""
    with _STATE['lock']:
        wanted = _STATE['wanted'] - _STATE['skipped']
        return len(wanted & _STATE['done']), len(wanted)


def titles():
    """(media type, imdb id, tmdb id) of every card the last plan() counted."""
    with _STATE['lock']:
        return list(_STATE['titles'])


def publish():
    """7.0.18: no ring next to HUB any more (the invisible posters only run behind
    the One-time setup screen, which shows its own ring); clears an old one."""
    try:
        xbmcgui.Window(10000).clearProperty('meganexus.precache.ring')
    except Exception:
        pass


def _version():
    try:
        return xbmcaddon.Addon('script.meganexus').getAddonInfo('version') or ''
    except Exception:
        return ''


def first_time():
    """Never prepared on this device, or prepared by an earlier version."""
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    return not addon.getSetting(TOTAL_SETTING) or addon.getSetting(VERSION_SETTING) != _version()


def needs_full(proxy):
    """The preload check: never done on this device, done for an earlier
    version (7.0.16: after every update), or Kodi keeps far fewer posters than
    after the last one (one query). plan() then counts what is really missing."""
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    try:
        expected = int(addon.getSetting(TOTAL_SETTING) or 0)
    except (ValueError, Exception):
        expected = 0
    if not expected or addon.getSetting(VERSION_SETTING) != _version():
        return True
    return len(kodi_textures.cached(proxy)) < expected * FULL_SHARE


def plan(collection_ids, landscape, stopped=lambda: False):
    """Home's rows and every collection's first page: queued, Kodi's copies
    marked, the total and this version remembered. Returns (stored by Kodi, total)."""
    proxy = base()
    if not proxy or not enabled():
        return 0, 0
    from . import perf
    found = []
    with perf.timed('Start check: Home rows'):
        try:
            wanted = home_targets(proxy, landscape, found)
        except Exception:
            wanted = []
    _USED_ROWS.clear()
    with perf.timed('Start check: collections', collections=len(collection_ids)):
        from resources.lib.collections_home import collection_shelves
        shelves = []
        for collection_id in collection_ids:
            if stopped():
                return 0, 0
            try:
                shelves.extend(collection_shelves(collection_id))
            except Exception:
                continue
        try:
            wanted += shelves_targets(proxy, shelves, landscape, found)
        except Exception:
            pass
        _save_rows(_USED_ROWS)
    try:
        from resources.lib import ratings_row
        if ratings_row.any_enabled():   # 7.0.30: the services' logos of the ratings row
            wanted += [url for url in ratings_row.LOGOS.values() if url.startswith(('https://', 'http://'))]
    except Exception:
        pass
    wanted = list(dict.fromkeys(wanted))
    with perf.timed('Start check: Kodi cache', pictures=len(wanted)):
        mark(proxy, kodi_textures.cached(proxy))
    add(proxy, wanted)
    gone = unavailable()
    with _STATE['lock']:
        _STATE['skipped'].update(url for url in wanted if url in gone and url not in _STATE['done'])
        for url in gone:
            _STATE['todo'].pop(url, None)
    with _STATE['lock']:
        _STATE['titles'] = list(dict.fromkeys(found))
    try:
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        addon.setSetting(TOTAL_SETTING, str(len(wanted)))
        addon.setSetting(VERSION_SETTING, _version())
    except Exception:
        pass
    return progress()


def prepare_all(window, collection_ids, landscape, stopped, wait, label):
    """Behind the "One-time setup" screen: the first screen of every
    collection, SLOTS at once. label(done, total) shows the progress.
    Returns (stored, total)."""
    if not base() or not enabled():
        return 0, 0
    plan(collection_ids, landscape, stopped)
    return run(window, stopped, wait, label)


def run(window, stopped, wait, label, until=None):
    """Store the queued posters until RING_DONE of them are in Kodi's cache
    (or until ``until``, a time.monotonic() deadline).

    7.0.30: every picture is first fetched into the image memory (a few at a
    time ahead); one that cannot be fetched is skipped at once and for a day
    and not counted. The others go to Kodi slot by slot - each invisible image
    takes the next picture as soon as Kodi has stored its own; one Kodi has not
    stored after WAIT seconds is given up as well."""
    stored = 0
    count = slots()
    ahead = ThreadPoolExecutor(max_workers=AHEAD_WORKERS, thread_name_prefix='MegaNexusPreloadNet')
    fetching, ready, gone = {}, [], []
    active, free = {}, list(range(count))
    shown = None
    def release(slot):
        window.setProperty('meganexus.precache.%d' % slot, '')
        del active[slot]
        free.append(slot)
    try:
        while not stopped() and (until is None or time.monotonic() < until):
            done, total = progress()
            if (done, total) != shown:
                shown = (done, total)
                label(done, total)
            if done >= total * RING_DONE:
                break                    # 7.0.11: Home opens at 90 %; the rest finishes there in the background
            # Fetch ahead: the next pictures into the image memory.
            if len(fetching) + len(ready) < count + AHEAD_WORKERS:
                for url in peek(count + AHEAD_WORKERS - len(fetching) - len(ready), skip=set(fetching) | set(ready)):
                    fetching[url] = ahead.submit(_head, url)
            for url, future in list(fetching.items()):
                if future.done():
                    del fetching[url]
                    take_url(url)
                    try:
                        good = future.result()
                    except Exception:
                        good = False
                    if good:
                        ready.append(url)
                    else:
                        gone.append(url)
                        with _STATE['lock']:
                            _STATE['skipped'].add(url)
            if gone:
                _remember_unavailable(gone)
                gone = []
            # Hand fetched pictures to Kodi.
            if free and ready:
                batch, ready = ready[:len(free)], ready[len(free):]
                kept = kodi_textures.kept(batch)
                with _STATE['lock']:
                    _STATE['done'].update(kept)
                for url in batch:
                    if url in kept:
                        continue
                    slot = free.pop()
                    active[slot] = (url, time.monotonic())
                    window.setProperty('meganexus.precache.%d' % slot, kodi_textures.texture(url))
            if not active and not fetching and not ready and not pending():
                break
            if wait(.1):
                break
            if not active:
                continue
            got = kodi_textures.kept([url for url, _ in active.values()])
            now = time.monotonic()
            for slot, (url, started) in list(active.items()):
                if url in got:
                    stored += 1
                    with _STATE['lock']:
                        _STATE['done'].add(url)
                    release(slot)
                elif now - started > WAIT:
                    with _STATE['lock']:
                        _STATE['skipped'].add(url)   # Kodi could not use it: not counted
                    release(slot)
    finally:
        for slot in list(active):
            window.setProperty('meganexus.precache.%d' % slot, '')
        for future in fetching.values():
            future.cancel()
        ahead.shutdown(wait=False)       # Kodi on Windows still embeds Python 3.8
    done, total = progress()
    label(done, total)
    return stored, total
