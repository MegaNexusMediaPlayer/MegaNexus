import xbmc
import xbmcgui
from resources.lib import cache_store,meganexus_subtitles
from .system_setup import rpc
from .playback import job,plain_label

def pick(rows,playerid,context,request_id,enabled=False):
    groups=meganexus_subtitles.group_rows(rows)
    langs=sorted(groups,key=lambda x:(x!='hr',meganexus_subtitles.NAMES.get(x,x)))
    if not langs and not enabled:xbmcgui.Dialog().ok('Subtitles','No subtitle files were returned. Try searching your subtitle add-ons.');return
    dialog=xbmcgui.Dialog()
    off=['Subtitles off'] if enabled else []
    index=dialog.select('Subtitle language',off+[meganexus_subtitles.NAMES.get(l,l)+' · '+str(len(groups[l]))+' versions' for l in langs])
    if index<0:return
    if off:
        if index==0:
            xbmc.Player().showSubtitles(False);return
        index-=1
    candidates=groups[langs[index]];labels=[]
    for i,row in enumerate(candidates):
        release=plain_label(row.get('displayName') or row.get('name') or row.get('release') or row.get('filename')) or 'Version '+str(i+1)
        source=plain_label(row.get('sourceName') or ('Embedded track' if row.get('embedded') else 'Subtitle provider'))
        labels.append('%d. %s — %s'%(i+1,release,source))
    index=dialog.select(meganexus_subtitles.NAMES.get(langs[index],langs[index]),labels)
    if index<0:return
    row=candidates[index]
    player=xbmc.Player()
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    if row.get('embedded'):
        rpc('Player.SetSubtitle',{'playerid':playerid,'subtitle':row['index'],'enable':True});return
    path=job(lambda:meganexus_subtitles.prepare_selected(row,context.get('video_id') or context.get('canonical_id') or 'selected'),label='Loading selected subtitle')
    if not path:return
    # Downloads can finish after a channel/title switch. Never apply to another video.
    if not player.isPlayingVideo() or player.getPlayingItem().getProperty('meganexus.request')!=request_id:return
    player.setSubtitles(path);player.showSubtitles(True)

def run():
    try:
        active=next((p for p in rpc('Player.GetActivePlayers') or [] if p['type']=='video'),None)
        if not active:return
        playerid=active['playerid'];player=xbmc.Player();request_id=player.getPlayingItem().getProperty('meganexus.request')
        xbmcgui.Window(10000).setProperty('meganexus.subtitle.manual',request_id)
        key=xbmcgui.Window(10000).getProperty('meganexus.subtitle.context')
        context=cache_store.get('meganexus_play',key) or {}
        if context.get('meganexus_request_id')!=request_id:context={}
        props=rpc('Player.GetProperties',{'playerid':playerid,'properties':['subtitles','subtitleenabled']}) or {}
        embedded=[dict(s,embedded=True,sourceName='Embedded track',lang=s.get('language')) for s in props.get('subtitles') or []]
        # 7.0.24: the player's subtitle button searches every subtitle add-on at
        # once and lists all versions (the timing has its own button).
        if context:
            rows=job(lambda:meganexus_subtitles.external_rows(context,search=True),label='Searching subtitle add-ons')
            if rows is None:return
            rows=embedded+rows
        else:rows=embedded   # not started through MegaNexus: the video's own tracks
        pick(rows,playerid,context,request_id,enabled=props.get('subtitleenabled'))
    except Exception as exc:
        xbmcgui.Dialog().ok('Subtitles',str(exc) if isinstance(exc,ValueError) else 'Subtitle selection could not finish. Try another file or provider.')
