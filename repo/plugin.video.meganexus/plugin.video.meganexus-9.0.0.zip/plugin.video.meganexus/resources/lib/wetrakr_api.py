# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""WeTrakr, the fourth tracking service (8.1.2).

Written against their published API (api.wetrakr.com), not against their add-on: the
account is linked here, the lists are read here and what is watched here is written
there. Nothing else has to be installed.

What the service calls things, and what we call the same thing:

    favorites      the Library - "Add to Library" saves here as it does on Trakt/Simkl
    tracking       what has been watched, with a status per title (watched, watching,
                   planning, dropped, hold, waiting, playing)
    playing        a scrobble while a film runs

8.1.5, from their documentation (api.wetrakr.com, Authentication): every WeTrakr account
registers its own app (wetrakr.com > Settings > API) and gets its own client_id - so each
person here uses their own. The sign-in is the device flow, as on Trakt: a code on the
TV, entered at wetrakr.com/activate. Every call carries the version header, that
client_id in the wetrakr-api-key header (it was never sent, and the API refuses a call
without it) and the account's token. Paged lists give 100 at most per page.
"""
import json
import os
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

from .meganexus.paths import profile_path
from .texts import tr

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

API = 'https://api.wetrakr.com'
VERSION_HEADER = '1'
TOKEN_PATH = os.path.join(profile_path(), 'wetrakr_token.json')
ACTIVATE_FALLBACK = 'https://wetrakr.com/activate'
KEY_SETTING = 'wetrakr_client_id'      # the person's own WeTrakr app (Settings > API)
ENABLE_SETTING = 'enable_wetrakr'
# Their tracking lists. 'watched' is the one the Library and the watched marks use.
STATUSES = ('watching', 'waiting', 'watched', 'planning', 'dropped', 'hold', 'playing')
PAGE = 100          # 8.1.5: the API's most per page (it was 500)
_CACHE = {}
# 8.1.5, what WeTrakr asks of an app that every user shares: one request after another,
# the history and the Library pulled again only when /sync/last_activities says something
# changed - and that asked every few hours, not in a loop - and a 429 waited out (until
# midnight UTC for the day's quota). The pulled lists are kept on disk for restarts.
CHECK_EVERY = 3 * 3600
CACHE_PATH = os.path.join(profile_path(), 'wetrakr_cache.json')
_ONE_AT_A_TIME = threading.Lock()


def _setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


def enabled():
    return (_setting(ENABLE_SETTING, 'true') or 'true').lower() == 'true'


def client_id():
    return (_setting(KEY_SETTING, '') or '').strip()


def credentials_configured():
    return bool(client_id())


def _read_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return default


def _write_json(path, value):
    temporary = None
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(path), delete=False) as handle:
            temporary = handle.name
            json.dump(value, handle)
        try:
            os.chmod(temporary, 0o600)
        except OSError:
            pass
        os.replace(temporary, path)
        return True
    except Exception:
        return False
    finally:
        if temporary and os.path.exists(temporary):
            try:
                os.remove(temporary)
            except OSError:
                pass


def token_data():
    return _read_json(TOKEN_PATH, {})


def save_token(data):
    data = dict(data or {})
    if data.get('access_token'):
        data.setdefault('client_id', client_id())
        data.setdefault('created_at', int(time.time()))
    return _write_json(TOKEN_PATH, data)


def clear_token():
    try:
        if os.path.exists(TOKEN_PATH):
            os.remove(TOKEN_PATH)
    except Exception:
        pass


def authorized():
    return bool(enabled() and (token_data() or {}).get('access_token'))


def authorization_status():
    if authorized():
        return 'connected'
    return 'ready' if credentials_configured() else 'needs_api'


def _headers(auth=True):
    sent = {'Content-Type': 'application/json', 'wetrakr-api-version': VERSION_HEADER,
            'User-Agent': 'MegaNexus/%s (Kodi)' % (ADDON.getAddonInfo('version') or '8.1.2')}
    if client_id():
        sent['wetrakr-api-key'] = client_id()      # 8.1.5: the API refuses every call without it
    if auth:
        signed = token_data() or {}
        if not signed.get('access_token'):
            raise RuntimeError(tr('WeTrakr account is not linked'))
        sent['Authorization'] = 'Bearer %s' % signed['access_token']
    return sent


def _stored():
    return _read_json(CACHE_PATH, {}) or {}


def _store(**changes):
    data = _stored()
    data.update(changes)
    _write_json(CACHE_PATH, data)
    return data


def _midnight_utc():
    now = time.time()
    return now - now % 86400 + 86400


def _open(path, payload=None, method='GET', auth=True, timeout=20):
    paused = float(_stored().get('paused_until') or 0)
    if paused > time.time():
        raise RuntimeError(tr('WeTrakr: today\'s requests are used up - again after midnight UTC'))
    asked = urllib.request.Request(
        API + path, data=json.dumps(payload).encode('utf-8') if payload is not None else None,
        headers=_headers(auth=auth), method=method)
    with _ONE_AT_A_TIME:                     # one request after another, never side by side
        for attempt in (1, 2):
            try:
                with urllib.request.urlopen(asked, timeout=timeout) as answer:
                    body = answer.read().decode('utf-8', 'ignore')
                    headers = dict(answer.headers.items())
                return (json.loads(body) if body else {}), headers
            except urllib.error.HTTPError as exc:
                if exc.code != 429:
                    raise
                text = ''
                try:
                    text = exc.read().decode('utf-8', 'ignore')
                except Exception:
                    pass
                if 'CONCURRENCY' in text.upper() and attempt == 1:
                    try:
                        wait = float(exc.headers.get('Retry-After') or 2)
                    except (TypeError, ValueError):
                        wait = 2.0
                    time.sleep(min(30.0, max(1.0, wait)))     # as they say, then once more
                    continue
                if 'CONCURRENCY' not in text.upper():
                    _store(paused_until=_midnight_utc())       # the day's quota: until midnight UTC
                    xbmc.log('[MegaNexus] WeTrakr: the day\'s requests are used up - resting until midnight UTC',
                             xbmc.LOGWARNING)
                raise


def _request(path, payload=None, method='GET', auth=True, timeout=20, retry=True):
    """One call. An expired access token is refreshed once and the call repeated - their
    tokens are short-lived and a refresh token comes with every device login."""
    try:
        return _open(path, payload, method, auth, timeout)[0]
    except urllib.error.HTTPError as exc:
        if exc.code == 401 and auth and retry and refresh():
            return _request(path, payload, method, auth, timeout, retry=False)
        raise


def _paged(path, query=None, limit=PAGE, pages=100):
    """Every row of a compact list, walked with the cursor the API hands back."""
    rows, cursor = [], ''
    for _ in range(pages):
        asked = dict(query or {}, compact='true', limit=min(limit, PAGE))
        if cursor:
            asked['after'] = cursor
        body, headers = _open('%s?%s' % (path, urllib.parse.urlencode(asked)))
        batch = body.get('data') if isinstance(body, dict) else body
        if isinstance(batch, dict):
            batch = batch.get('items') or []
        rows.extend(batch or [])
        cursor = headers.get('X-Pagination-Next') or headers.get('x-pagination-next') or ''
        if not cursor or not batch:
            break
    return rows


def refresh():
    """A new access token from the refresh token. False when there is none to use."""
    signed = token_data() or {}
    token = signed.get('refresh_token')
    if not token:
        return False
    try:
        answer = _request('/oauth/token/refresh', {'refresh_token': token}, method='POST', auth=False, retry=False)
    except Exception as exc:
        xbmc.log('[MegaNexus] WeTrakr: the session could not be renewed: %s' % exc, xbmc.LOGWARNING)
        return False
    if not isinstance(answer, dict) or not answer.get('access_token'):
        return False
    signed.update(answer)
    save_token(signed)
    invalidate_cache()
    return True


def _pin_text(address, code, remaining=None):
    lines = [tr('Code: [B]%s[/B]') % code, '', tr('Open %s and enter it.') % address]
    if remaining is not None:
        lines.append(tr('%d seconds left') % remaining)
    return '\n'.join(lines)


def device_auth():
    """Link the account: a code is shown while WeTrakr is asked every few seconds
    whether it was entered. True once linked."""
    if not enabled():
        raise RuntimeError(tr('WeTrakr is switched off in settings'))
    if not credentials_configured():
        raise RuntimeError(tr('Enter your WeTrakr app\'s client ID first (wetrakr.com > Settings > API)'))
    start = _request('/oauth/device/code', {'client_id': client_id()}, method='POST', auth=False)
    code = str((start or {}).get('user_code') or '').strip()
    device = str((start or {}).get('device_code') or '').strip()
    if not (code and device):
        raise RuntimeError(tr('WeTrakr did not return a pairing code'))
    address = str(start.get('verification_url') or ACTIVATE_FALLBACK)
    every = max(5, int(start.get('interval') or 5))
    lasts = max(60, int(start.get('expires_in') or 600))
    title = tr('MegaNexus • Link WeTrakr')
    try:
        xbmcgui.Dialog().ok(title, _pin_text(address, code))
    except Exception as exc:
        xbmc.log('[MegaNexus] WeTrakr Dialog.ok fallback: %s' % exc, xbmc.LOGWARNING)
    waiting = xbmcgui.DialogProgress()
    waiting.create(title, _pin_text(address, code, remaining=lasts))
    began = time.time()
    try:
        while not waiting.iscanceled() and time.time() - began < lasts:
            spent = time.time() - began
            waiting.update(int(max(0, min(100, spent / float(lasts) * 100))),
                           _pin_text(address, code, remaining=int(lasts - spent)))
            answer = None
            try:
                answer = _request('/oauth/device/token', {'device_code': device}, method='POST',
                                  auth=False, retry=False)
            except urllib.error.HTTPError as exc:
                body = {}
                try:
                    body = json.loads(exc.read().decode('utf-8', 'ignore') or '{}')
                except Exception:
                    pass
                error = str(body.get('error') or '')
                if exc.code == 429 or error == 'slow_down':
                    every = min(60, max(every, 5) * 2)     # polling too fast: back off
                elif exc.code in (410, 418, 409) or error in ('expired_token', 'access_denied', 'already_used'):
                    break
            except Exception as exc:
                xbmc.log('[MegaNexus] WeTrakr poll: %s' % exc, xbmc.LOGWARNING)
            if isinstance(answer, dict) and answer.get('access_token'):
                save_token(answer)
                waiting.close()
                xbmcgui.Dialog().notification('MegaNexus', tr('WeTrakr linked successfully'),
                                              xbmcgui.NOTIFICATION_INFO, 3000)
                invalidate_cache()
                return True
            xbmc.sleep(every * 1000)
    finally:
        try:
            waiting.close()
        except Exception:
            pass
    return False


def logout():
    signed = token_data() or {}
    if signed.get('refresh_token'):
        try:
            _request('/oauth/logout', {'refresh_token': signed['refresh_token']}, method='POST', retry=False)
        except Exception:
            pass        # the token goes from this box either way
    clear_token()
    invalidate_cache()
    return True


def invalidate_cache(prefix=''):
    """Our own write (or Sync now): that list is pulled again at its next read.
    8.1.5: '/sync/favorites' -> 'favorites', '/sync/tracking' -> 'watched' - it was called
    with the paths and never matched a kept list."""
    kinds = [kind for kind, path in (('favorites', '/sync/favorites'), ('watched', '/sync/tracking'))
             if not prefix or path.startswith(prefix) or prefix.startswith(path)]
    data = _stored()
    for kind in kinds:
        _CACHE.pop(kind, None)
        data.pop(kind, None)
    _write_json(CACHE_PATH, data)


def _kept(kind, pull):
    """The list ``kind``: from memory or disk while /sync/last_activities - asked every
    CHECK_EVERY at most - says nothing changed; pulled again (``pull()``) when it did."""
    now = time.time()
    data = _stored()
    held = data.get(kind)
    if held is not None and now - float(data.get('checked') or 0) < CHECK_EVERY:
        return held
    if held is not None:
        try:
            activities = _request('/sync/last_activities') or {}
        except Exception:
            return held                               # unknown: what is kept stays
        if activities == data.get('activities'):
            _store(checked=now)
            return held
        data = _store(activities=activities, checked=now, favorites=None, watched=None)
    fresh = pull()
    if fresh is None:
        return held if held is not None else ([] if kind == 'favorites' else {})
    if 'activities' not in data:
        try:
            data['activities'] = _request('/sync/last_activities') or {}
        except Exception:
            pass
    _store(**{kind: fresh, 'checked': now, 'activities': data.get('activities')})
    return fresh


# ─── what a title looks like to them ────────────────────────────────────────

def _ids_from_ctx(ctx):
    """{imdb, tmdb, tvdb} as WeTrakr writes them - IMDb keeps its tt."""
    ctx = ctx or {}
    found = {}
    imdb = str(ctx.get('imdb_id') or '').strip()
    if not imdb:
        canonical = str(ctx.get('canonical_id') or '')
        if canonical.startswith('tt'):
            imdb = canonical.split(':')[0]
    if imdb:
        found['imdb'] = imdb if imdb.startswith('tt') else 'tt%s' % imdb
    for name, key in (('tmdb', 'tmdb_id'), ('tvdb', 'tvdb_id')):
        value = str(ctx.get(key) or '').strip()
        if value.isdigit():
            found[name] = int(value)
    return found


def _is_series(ctx):
    kind = str((ctx or {}).get('media_type') or (ctx or {}).get('type') or '').lower()
    return kind in ('series', 'show', 'tv', 'anime', 'episode')


def _item(ctx):
    """One entry of a body: its ids, with the title and year when we have them."""
    entry = {'ids': _ids_from_ctx(ctx)}
    title = str((ctx or {}).get('title') or (ctx or {}).get('name') or '').strip()
    if title:
        entry['title'] = title
    year = str((ctx or {}).get('year') or '')[:4]
    if year.isdigit():
        entry['year'] = int(year)
    return entry if entry['ids'] or entry.get('title') else None


def _body(ctx, season=None, episode=None):
    """movies / shows, in the shape /sync/tracking and /sync/favorites take."""
    entry = _item(ctx)
    if not entry:
        return {}
    if not _is_series(ctx):
        return {'movies': [entry]}
    if season is not None and episode is not None:
        show = dict(entry)
        show['seasons'] = [{'number': int(season), 'episodes': [{'number': int(episode)}]}]
        return {'shows': [show]}
    if season is not None:
        show = dict(entry)
        show['seasons'] = [{'number': int(season)}]
        return {'shows': [show]}
    return {'shows': [entry]}


# ─── the Library (their favorites) ──────────────────────────────────────────

def add_to_library(ctx):
    body = _body(ctx)
    if not body:
        return False
    _request('/sync/favorites', body, method='POST')
    invalidate_cache('/sync/favorites')
    return True


def remove_from_library(ctx):
    body = _body(ctx)
    if not body:
        return False
    _request('/sync/favorites/remove', body, method='POST')
    invalidate_cache('/sync/favorites')
    return True


def _canonical(ids):
    """The id MegaNexus keys a title by: IMDb when there is one, else tmdb:NNN."""
    imdb = str((ids or {}).get('imdb') or '').strip()
    if imdb:
        return imdb if imdb.startswith('tt') else 'tt%s' % imdb
    tmdb = str((ids or {}).get('tmdb') or '').strip()
    return 'tmdb:%s' % tmdb if tmdb else ''


def _row(entry, media_type):
    ids = entry.get('ids') or {}
    canonical = _canonical(ids)
    if not canonical:
        return None
    images = entry.get('images') or {}
    return {'media_type': media_type, 'canonical_id': canonical,
            'title': entry.get('title') or entry.get('name') or canonical,
            'poster': entry.get('poster') or images.get('poster') or '',
            'background': entry.get('backdrop') or images.get('backdrop') or '', 'clearlogo': '',
            'year': entry.get('year') or 0, 'plot': entry.get('overview') or entry.get('description') or '',
            'added_at': _epoch(entry.get('favorited_at') or entry.get('created_at') or entry.get('tracked_at'))}


def _epoch(value):
    from datetime import datetime
    try:
        return int(datetime.fromisoformat(str(value).replace('Z', '+00:00')).timestamp()) if value else 0
    except (ValueError, TypeError, OverflowError):
        return 0


def _kind_of(entry, fallback='movie'):
    kind = str(entry.get('type') or entry.get('media_type') or fallback).lower()
    return 'series' if kind in ('show', 'series', 'tv', 'anime') else 'movie'


def watchlist_copy_rows(limit=200):
    """The account's favorites as Library mirror rows (same shape as Trakt's and
    Simkl's, so library.py needs nothing special for them)."""
    if not authorized():
        return []

    def pull():
        rows = []
        try:
            for entry in _paged('/sync/favorites/all'):
                row = _row(entry, _kind_of(entry))
                if row:
                    rows.append(row)
        except Exception as exc:
            xbmc.log('[MegaNexus] WeTrakr favorites: %s' % exc, xbmc.LOGWARNING)
            return None
        return rows
    return (_kept('favorites', pull) or [])[:limit]


# ─── what has been watched ──────────────────────────────────────────────────

def mark(ctx, scope='title', season=None, episode=None):
    """Watched, on their side. ``scope`` is 'title', 'season' or 'episode'."""
    body = _body(ctx, season if scope in ('season', 'episode') else None,
                 episode if scope == 'episode' else None)
    if not body:
        return False
    body['status'] = 'watched'
    _request('/sync/tracking', body, method='POST')
    invalidate_cache('/sync/tracking')
    return True


def unmark(ctx, scope='title', season=None, episode=None):
    """Not watched after all: the play is taken off their list too."""
    body = _body(ctx, season if scope in ('season', 'episode') else None,
                 episode if scope == 'episode' else None)
    if not body:
        return False
    body['status'] = 'watched'
    _request('/sync/tracking/remove', body, method='POST')
    invalidate_cache('/sync/tracking')
    return True


def watched_items(limit=2000):
    """{'movie|tt123': {'watched': True, 'episodes': [...]}} - the shape the merged
    watched view is built from (simkl_watched)."""
    if not authorized():
        return {}
    return _kept('watched', _pull_watched) or {}


def _pull_watched():
    found = {}
    try:
        for target, media_type in (('movies', 'movie'), ('shows', 'series')):
            for entry in _paged('/sync/tracking/watched/%s' % target):
                canonical = _canonical(entry.get('ids') or {})
                if not canonical:
                    continue
                key = '%s|%s' % (media_type, canonical)
                item = found.setdefault(key, {'watched': False, 'seasons': [], 'episodes': []})
                if media_type == 'movie':
                    item['watched'] = True
                    continue
                for season in entry.get('seasons') or []:
                    number = season.get('number')
                    for shown in season.get('episodes') or []:
                        marker = '%s:%s' % (number, shown.get('number'))
                        if marker not in item['episodes']:
                            item['episodes'].append(marker)
                if not (entry.get('seasons') or []):
                    item['watched'] = bool(entry.get('completed') or entry.get('watched'))
    except Exception as exc:
        xbmc.log('[MegaNexus] WeTrakr watched: %s' % exc, xbmc.LOGWARNING)
        return None
    return found


def last_activities():
    """When anything last changed over there - a cheap way to know a sync is needed."""
    try:
        return _request('/sync/last_activities') or {}
    except Exception:
        return {}


def scrobble(ctx, progress, season=None, episode=None):
    """A film is running: progress from 0 to 100."""
    if not authorized():
        return False
    entry = _item(ctx)
    if not entry:
        return False
    body = {'progress': round(float(progress or 0), 1),
            'app_version': ADDON.getAddonInfo('version') or '8.1.2'}
    if _is_series(ctx) and season is not None and episode is not None:
        body['show'] = entry
        body['episode'] = {'season': int(season), 'number': int(episode)}
    else:
        body['movie'] = entry
    try:
        _request('/sync/tracking/playing/%s' % ('episodes' if 'episode' in body else 'movies'),
                 body, method='POST')
        return True
    except Exception as exc:
        xbmc.log('[MegaNexus] WeTrakr scrobble: %s' % exc, xbmc.LOGDEBUG)
        return False
