# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Trending now on TMDB (7.0.42): a large landscape picture on the HUB (and in
the screensaver, switched on in its studio) that changes every ROTATE seconds.

The service reads TMDB's trending films and series of the week (backdrop,
title logo, year) once every REFRESH seconds - needs the user's TMDB key - and
publishes the current one as Window(Home) properties meganexus.spotlight.art /
.logo / .title / .line. It turns only while the HUB or the screensaver shows
(nothing changes behind MegaNexus or a video). Setting meganexus_hub_spotlight
(default on).
"""
import time

SETTING = 'meganexus_hub_spotlight'
REFRESH = 6 * 3600
ROTATE = 10
MAX_ITEMS = 20
CACHE_KEY = 'hub_spotlight:v1'
PROPS = ('art', 'logo', 'title', 'line')


def _logo(tmdb_direct, kind, tmdb_id):
    try:
        data = tmdb_direct._request('/%s/%s/images' % (kind, tmdb_id), {'include_image_language': 'en,null'}) or {}
    except Exception:
        return ''
    logos = [row for row in data.get('logos') or [] if row.get('file_path')]
    logos.sort(key=lambda row: (row.get('iso_639_1') != 'en', -(row.get('vote_average') or 0)))
    return tmdb_direct._image_url(logos[0]['file_path'], 'logo') if logos else ''


def items(refresh=False):
    """[{'art', 'logo', 'title', 'line'}] of this week's trending titles (cached)."""
    from . import tmdb_direct
    if not tmdb_direct._api_key():
        return []
    cached = None if refresh else tmdb_direct._cache_get(CACHE_KEY)
    if cached is not None:
        return cached.get('items') or []
    try:
        reply = tmdb_direct._request('/trending/all/week', {'language': 'en-US'}) or {}
    except Exception:
        return []
    found = []
    for row in reply.get('results') or []:
        kind = row.get('media_type')
        if kind not in ('movie', 'tv') or not row.get('backdrop_path'):
            continue
        title = row.get('title') or row.get('name') or ''
        year = str(row.get('release_date') or row.get('first_air_date') or '')[:4]
        line = ' · '.join(part for part in ('Film' if kind == 'movie' else 'Series', year,
                                             ('TMDB %.1f' % row['vote_average']) if row.get('vote_average') else '') if part)
        found.append({'art': tmdb_direct._image_url(row['backdrop_path'], 'backdrop'),
                      'logo': _logo(tmdb_direct, kind, row.get('id')), 'title': title, 'line': line})
        if len(found) >= MAX_ITEMS:
            break
    if found:
        tmdb_direct._cache_set(CACHE_KEY, {'items': found}, REFRESH)
    return found


NOLOGO = 'meganexus.nologo'    # 7.0.42: Window(Home) - the MegaNexus logo stays off every screen


def logo_rule(window, on):
    """While Trending now on TMDB is on (and a TMDB key is set), the theme's pictures
    without the MegaNexus logo everywhere - the HUB, the opening screens, the
    screensaver - from the start, not only once a trending picture has loaded (the
    logo flashed on the way out and into the screensaver). Cheap when unchanged."""
    value = '1' if on else ''
    if window.getProperty(NOLOGO) != value:
        window.setProperty(NOLOGO, value)
    return on


def logo_off(addon=None):
    """The rule as the settings say it now (any interpreter)."""
    from . import tmdb_direct
    if addon is None:
        from .settings_cache import cached_addon
        addon = cached_addon()
    return addon.getSetting(SETTING) != 'false' and bool(tmdb_direct._api_key())


def publish(window, item):
    for key in PROPS:
        window.setProperty('meganexus.spotlight.' + key, (item or {}).get(key, ''))


def run(monitor, enabled, showing, window, log=None, step=2):
    """Service loop: rotate while the HUB / screensaver shows; clear when switched off."""
    found, loaded, index, shown, next_turn = [], 0., -1, False, 0.
    from . import tmdb_direct
    on = lambda: enabled() and bool(tmdb_direct._api_key())
    try:
        logo_rule(window, on())
    except Exception:
        pass
    while not monitor.waitForAbort(step):
        try:
            logo_rule(window, on())
        except Exception:
            pass          # the logo rule never stops the pictures
        try:
            if not enabled():
                if shown:
                    publish(window, None)
                    shown = False
                continue
            now = time.monotonic()
            if not found or now - loaded > REFRESH:
                found, loaded = items(), now
                if not found:
                    loaded = now - REFRESH + 600      # no key / no answer: again in 10 minutes
                    continue
            if not showing() or now < next_turn:
                continue
            index = (index + 1) % len(found)
            publish(window, found[index])
            shown, next_turn = True, now + ROTATE
        except Exception as exc:
            if log:
                log('[MegaNexus] Trending spotlight skipped: %s' % type(exc).__name__)
