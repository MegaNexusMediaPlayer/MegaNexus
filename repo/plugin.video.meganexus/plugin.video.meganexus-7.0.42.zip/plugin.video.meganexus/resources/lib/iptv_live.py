# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Live TV only in Kodi's channel list, films and series as IPTV VOD (7.0.37).

IPTV playlists often list their films and series as channels too: on a Fire
TV Cube 34,025 "channels", most of them films and series. Kodi made a channel
and a guide row of each - about 258 MiB more RSS before the TV screen opened
and almost three minutes of one CPU core in its image cleanup (RAM audit,
11.10.2026).

MegaNexus reads each playlist itself, line by line (never the whole list in
memory) and sorts every entry by what the playlist itself says - any
provider, not one known list:

* IPTV Simple's own media markers (media=, media-dir=, media-size=,
  #EXT-X-PLAYLIST-TYPE:VOD) or a tvg-type / type of movie, series or vod;
* a link to a file (.mkv, .mp4, .avi ... at the end of its path or after #,
  e.g. /play/<code>#.mkv) or a /movie/, /series/ or /vod/ path (Xtream);

everything else is a channel. Group names are never used. Channels go to a
local file IPTV Simple reads (every line and attribute as it was: tvg-id,
groups, numbers, logos, catch-up - channel identities, favourites and the
guide stay); films and series to a small index on disk that the source list
searches (iptv_lists.py, "IPTV VOD"). New files replace the old ones only when
complete; a failed download keeps the last good ones.
"""
import gzip
import os
import re
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

SETTING = 'meganexus_iptv_live_only'
RULES = 3                    # raise when the sorting rules change: lists are made again at once
TIMEOUT = 60
VIDEO_FILE = re.compile(r'\.(?:mkv|mp4|m4v|avi|mov|wmv|webm|mpg|mpeg|flv|divx|xvid|iso|vob|ogm|3gp)$', re.I)
VOD_PATH = re.compile(r'/(?:movie|movies|series|vod)/', re.I)
VOD_TYPE = re.compile(r'\b(?:tvg-type|type)\s*=\s*"(?:movie|movies|series|vod|film)"', re.I)
MEDIA = re.compile(r'\b(?:media|media-dir|media-size)\s*=', re.I)


def is_vod_link(url):
    """A link to a file or an Xtream film / series path."""
    url = str(url or '').strip()
    try:
        parts = urlsplit(url)
    except ValueError:
        return False
    if VOD_PATH.search(parts.path):
        return True
    return bool(VIDEO_FILE.search(parts.path) or VIDEO_FILE.search(parts.fragment.strip()))


def is_vod(block, url):
    """``block``: the # lines before the link (#EXTINF, #EXTGRP, ...)."""
    for line in block:
        upper = line.lstrip().upper()
        if upper.startswith('#EXT-X-PLAYLIST-TYPE:') and upper.split(':', 1)[1].strip() == 'VOD':
            return True
        if upper.startswith('#EXTINF') and (MEDIA.search(line) or VOD_TYPE.search(line)):
            return True
    return is_vod_link(url)


def entry_name(block):
    """The name of an entry: after the last comma of #EXTINF (tvg-name else)."""
    for line in block:
        if line.lstrip().upper().startswith('#EXTINF'):
            name = _attr(line, 'tvg-name')
            tail = line.rsplit('",', 1)[-1] if '",' in line else line.split(',', 1)[-1]
            return (tail.strip() or name).strip()
    return ''


def _attr(line, key):
    match = re.search(r'\b%s\s*=\s*"([^"]*)"' % re.escape(key), line, re.I)
    return match.group(1) if match else ''


def entry_groups(block):
    """The groups of an entry: group-title (several split by ;) and #EXTGRP."""
    found = []
    for line in block:
        upper = line.lstrip().upper()
        if upper.startswith('#EXTINF'):
            found += [g.strip() for g in _attr(line, 'group-title').split(';')]
        elif upper.startswith('#EXTGRP:'):
            found += [g.strip() for g in line.split(':', 1)[1].split(';')]
    return [g for g in found if g]


def split_lines(lines, live, vod, stopped=None, hidden=(), groups=None, keep_vod=False):
    """Sort an M3U playlist: channels to ``live(text)`` (as they were), films and
    series to ``vod(name, url)``. Channels whose groups are all ``hidden`` are
    left out (Kodi never loads them); ``groups`` counts every channel group
    (for the Groups picker). ``keep_vod``: films and series stay in ``live``
    too (Only live TV switched off). Returns (channels, films and series)."""
    kept = dropped = 0
    block = []
    hidden = set(hidden or ())
    for count, raw in enumerate(lines):
        if stopped is not None and count % 4000 == 0 and stopped():
            raise ValueError('stopped')
        line = raw.rstrip('\r\n')
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith('#EXTM3U') and not kept and not dropped and not block:
            live(line + '\n')
            continue
        if stripped.startswith('#'):
            block.append(line)       # #EXTINF, #EXTGRP, #KODIPROP ... belong to the next link
            continue
        entry = ''.join(row + '\n' for row in block) + line + '\n'
        if is_vod(block, stripped):
            dropped += 1
            vod(entry_name(block), stripped)
            if keep_vod:
                live(entry)
        else:
            names = entry_groups(block)
            if groups is not None:
                for name in names or ['']:
                    groups[name] = groups.get(name, 0) + 1
            if not (names and all(name in hidden for name in names)):
                live(entry)
                kept += 1
        block = []
    return kept, dropped


def _text_lines(response):
    stream = response
    if 'gzip' in (response.headers.get('Content-Encoding') or '').lower():
        stream = gzip.GzipFile(fileobj=response)
    for raw in stream:
        yield raw.decode('utf-8', 'replace')


def _open(url):
    return urlopen(Request(url, headers={'User-Agent': 'MegaNexus/7', 'Accept-Encoding': 'gzip'}), timeout=TIMEOUT)


def build(source, live_target, vod_target=None, vod_row=None, opener=None, stopped=None, hidden=(), groups=None, keep_vod=False):
    """Download ``source`` once: channels to ``live_target`` (None: not kept),
    films and series through ``vod_row(name, url)`` -> a text line, or None, to
    ``vod_target``. Atomic; the channel file only when it has channels.
    Returns (channels, films and series)."""
    temps = []
    targets = [Path(t) for t in (live_target, vod_target) if t]
    for target in targets:
        target.parent.mkdir(parents=True, exist_ok=True)
        temps.append(target.with_name('%s.%d.tmp' % (target.name, os.getpid())))   # never another process' file
    live_out = vod_out = None
    try:
        with (opener or _open)(source) as response:
            if live_target:
                live_out = open(temps[0], 'w', encoding='utf-8')
            if vod_target:
                vod_out = open(temps[-1], 'w', encoding='utf-8')

            def vod(name, url):
                if vod_out is not None and vod_row is not None:
                    row = vod_row(name, url)
                    if row:
                        vod_out.write(row)
            kept, dropped = split_lines(_text_lines(response), live_out.write if live_out else (lambda text: None), vod, stopped,
                                        hidden, groups, keep_vod)
        for handle in (live_out, vod_out):
            if handle is not None:
                handle.close()
        if live_target and kept <= 0:
            raise ValueError('the playlist has no live channels')
        for temp, target in zip(temps, targets):
            _private(temp)
            os.replace(temp, target)
    finally:
        for handle in (live_out, vod_out):
            try:
                if handle is not None:
                    handle.close()
            except OSError:
                pass
        for temp in temps:
            try:
                temp.unlink()
            except OSError:
                pass
    return kept, dropped


def _private(path):
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def describe(exc):
    """A failure without its link (the link holds the login)."""
    code = getattr(exc, 'code', None)
    if code:
        return 'HTTP %s' % code
    if isinstance(exc, ValueError):
        return str(exc)[:120]
    return type(exc).__name__
