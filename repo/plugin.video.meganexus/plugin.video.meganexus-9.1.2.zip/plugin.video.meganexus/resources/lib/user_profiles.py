# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus profiles (7.0.45): who is watching.

Each profile has its own tracking and watching - the Nuvio / Stremio / Trakt /
Simkl / MDBList sign-ins and their sync, Continue Watching, what is watched, the
Library, the subtitle language, the last links - and (9.0.6) its music: what it
heard, saved and follows, its Deezer. Everything else is one for all:
add-ons, debrid, Usenet, API keys, the look, the player, and what is prepared
once (posters, artwork, catalogs, the one-time setup) - a profile never loads it
again.

The active profile's files are where they always were (every part of MegaNexus
reads them there); a profile that is not active keeps them in profiles/<id>/
with its own values of the profile settings (settings.json). Switching moves the
active profile's away and the chosen one's in - nothing is copied, so a profile
never sees another's data. The first profile is the one this box had: an
existing setup is the primary profile as it is.

Switching runs in the service while no sync runs (request / serve); a switch cut
short is finished on the next start (journal).
"""
import hashlib
import json
import os
import re
import secrets
import shutil
import threading
import time
import uuid

FILES = ('nuvio_token.json', 'stremio_token.json', 'trakt_token.json', 'simkl_token.json', 'trakt_watched.json',
         'simkl_watched.json', 'mdblist_watched.json', 'account_sync_fp.json', 'nuvio_sync_state.json',
         'nuvio_library_state.json', 'library_origins.json', 'continue_hidden.json', 'kept_subtitles.json',
         'playback.db', 'favorites.db', 'tmdb_session.json',
         'party_identity.json', 'party_friends.json', 'party_active.json',
         'party_messages.json',   # 7.0.52: Watch Party, each profile its own
         'music_history.json', 'music_library.json', 'music_follow.json', 'music_playlists.json',   # 9.0.6: the Music app's own
         'youtube_channels.json',   # ... and the YouTube app's channels
         'home_tracking_rows.json',   # 9.0.8: Home's Watchlist / Next episodes as last answered
         'anilist_token.json', 'mal_token.json', 'anime_outbox.json',   # 9.1.1: each profile's anime lists
         'library_place.json')   # ... and the place its Library was left on (meganexus_ui/library.py)
SUFFIXES = ('', '.bak', '-wal', '-shm', '-journal')
FOLDERS = ('kept_subtitles',
           'library_sections')   # 9.1.1: the Library's sections, each profile its own (library_sections)
SETTINGS = ('enable_trakt', 'trakt_scrobble', 'trakt_sync_progress', 'trakt_sync_watchlist', 'trakt_service_sync_interval',
            'enable_simkl', 'simkl_mark_watched', 'simkl_service_sync', 'simkl_watched_threshold',
            'mdblist_tracking', 'watchlist_merge_mdblist', 'watchlist_merge_simkl',
            'nuvio_email', 'nuvio_password', 'nuvio_sync_enabled', 'nuvio_sync_direction', 'nuvio_sync_library',
            'nuvio_sync_progress', 'nuvio_sync_merge_only', 'nuvio_progress_interval', 'nuvio_sync_collections',
            'nuvio_sync_addons', 'stremio_email', 'stremio_password', 'stremio_sync_enabled', 'stremio_sync_direction',
            'stremio_sync_progress', 'stremio_sync_addons', 'cloud_sync_continuous', 'cloud_sync_direction',
            'cloud_sync_interval_min', 'last_account_sync_at', 'meganexus_subtitle_language', 'preferred_subtitle_langs',
            'meganexus_music_deezer_profile',
            'meganexus_watchlist_from', 'meganexus_next_episodes_from')   # 9.0.8: whose rows they are
# A new profile never changes what all share: its accounts do not bring add-ons or collections.
NEW_PROFILE = {'nuvio_sync_addons': 'false', 'nuvio_sync_collections': 'false', 'stremio_sync_addons': 'false'}
PRIMARY = 'main'
MAX_PROFILES = 8
PIN_DIGITS = (4, 8)
SERVICE_WAIT = 15   # seconds the interface waits for the service at Kodi's start
SHOWN = 'meganexus.profiles.done'   # the HUB shows its pills, spotlight and corner (after who is watching)
COVER_MAX = 25      # seconds after the service starts it shows them whatever happened
REQUEST, DONE, SERVING = 'meganexus.profile.request', 'meganexus.profile.done', 'meganexus.profile.service'
_LOCK = threading.RLock()


def _root():
    from .meganexus.paths import profile_path
    return profile_path()


def folder(pid=''):
    path = os.path.join(_root(), 'profiles', pid) if pid else os.path.join(_root(), 'profiles')
    os.makedirs(path, exist_ok=True)
    return path


def _store():
    return os.path.join(folder(), 'profiles.json')


def _journal():
    return os.path.join(folder(), 'switching.json')


def _write(path, value):
    from .meganexus.json_files import write_json
    write_json(path, value)


def _read(path, default):
    from .meganexus.json_files import read_json
    return read_json(path, default)


def _first_name():
    """The primary's name: its Nuvio profile's, else "Profile 1"."""
    try:
        from .meganexus.cloud_sync import NuvioCloud
        token = NuvioCloud.token() or {}
        name = str(token.get('profile_name') or '').strip()
        if name:
            return name[:24]
    except Exception:
        pass
    return 'Profile 1'


def picture_on_this_box(value):
    """The profile's picture where it actually is here, or '' when it is not.

    The stored value is an absolute path, which only holds on the box that wrote it. A
    profile carried over from another device or restored from a backup pointed at
    /storage/.kodi/... on a desktop - a file that is not there. The circle then drew
    nothing and, because the skin shows either the picture or the initials, hid the
    initials too: the picker was a row of empty rings (8.1.2, reported as "there were no
    names"). It is also why setting the picture from the phone appeared to be refused
    the second time - the profile still claimed to have one.

    Only the file name carries over; the folder belongs to this box.
    """
    value = str(value or '')
    # isfile, not exists: a stored value that happens to name a folder ('/' after a bad
    # write) is not a picture, and the skin would draw an empty ring for it forever
    if value and os.path.isfile(value):
        return value
    name = os.path.basename(value.replace('\\', '/').rstrip('/'))
    if not name:
        return ''
    here = os.path.join(folder('pictures'), name)
    return here if os.path.isfile(here) else ''


def load():
    with _LOCK:
        data = _read(_store(), {})
        rows = [row for row in data.get('profiles') or [] if isinstance(row, dict) and row.get('id')]
        for row in rows:
            # repaired here, once, for everything that reads a profile: the picker, the
            # corner circle (publish), the phone page and the settings screen
            row['picture'] = picture_on_this_box(row.get('picture'))
        if not any(row.get('id') == PRIMARY for row in rows):
            # this box's setup as it is - the first, primary profile
            rows.insert(0, {'id': PRIMARY, 'name': _first_name(), 'primary': True, 'picture': '', 'pin': '',
                            'created': time.time()})
            data = {'version': 1, 'active': data.get('active') or PRIMARY, 'profiles': rows}
            _write(_store(), data)
        data['profiles'] = rows
        if data.get('active') not in {row['id'] for row in rows}:
            data['active'] = PRIMARY
        return data


def profiles():
    return load()['profiles']


def active():
    return load()['active']


def get(pid):
    return next((row for row in profiles() if row['id'] == pid), None)


def _save(data):
    with _LOCK:
        _write(_store(), data)


def _clean_name(name):
    name = re.sub(r'\s+', ' ', str(name or '')).strip()[:24]
    if not name:
        raise ValueError('Give the profile a name.')
    return name


def add(name):
    with _LOCK:
        data = load()
        if len(data['profiles']) >= MAX_PROFILES:
            raise ValueError('There can be up to %d profiles.' % MAX_PROFILES)
        name = _clean_name(name)
        if any(row['name'].casefold() == name.casefold() for row in data['profiles']):
            raise ValueError('There is a profile with this name already.')
        pid = uuid.uuid4().hex[:10]
        data['profiles'].append({'id': pid, 'name': name, 'primary': False, 'picture': '', 'pin': '', 'created': time.time()})
        _write(os.path.join(folder(pid), 'settings.json'), dict(NEW_PROFILE))
        _save(data)
        return pid


def rename(pid, name):
    with _LOCK:
        data = load()
        name = _clean_name(name)
        if any(row['name'].casefold() == name.casefold() and row['id'] != pid for row in data['profiles']):
            raise ValueError('There is a profile with this name already.')
        for row in data['profiles']:
            if row['id'] == pid:
                row['name'] = name
        _save(data)
    publish()


def set_picture(pid, payload):
    """A JPEG / PNG from the phone (already checked and made square by the page)."""
    if not payload or len(payload) > 4 * 1024 * 1024 or not (payload[:3] == b'\xff\xd8\xff' or payload[:8] == b'\x89PNG\r\n\x1a\n'):
        raise ValueError('Choose a JPEG or PNG picture (up to 4 MB).')
    with _LOCK:
        data = load()
        if not any(row['id'] == pid for row in data['profiles']):
            raise ValueError('This profile is gone.')
        # a new name each time: Kodi keeps pictures by name
        for old in os.listdir(folder('pictures')):
            if old.startswith(pid + '-'):
                try:
                    os.remove(os.path.join(folder('pictures'), old))
                except OSError:
                    pass
        path = os.path.join(folder('pictures'), '%s-%d.%s' % (pid, int(time.time()), 'png' if payload[:4] == b'\x89PNG' else 'jpg'))
        with open(path, 'wb') as handle:
            handle.write(payload)
        for row in data['profiles']:
            if row['id'] == pid:
                row['picture'] = path
        _save(data)
    publish()
    return path


def _pin_hash(pin, salt):
    return hashlib.sha256(('%s|%s' % (salt, pin)).encode('utf-8')).hexdigest()


def set_pin(pid, pin):
    """A PIN of 4-8 digits; '' takes it away."""
    pin = str(pin or '').strip()
    if pin and (not pin.isdigit() or not PIN_DIGITS[0] <= len(pin) <= PIN_DIGITS[1]):
        raise ValueError('A PIN is 4 to 8 digits.')
    with _LOCK:
        data = load()
        for row in data['profiles']:
            if row['id'] == pid:
                if pin:
                    salt = secrets.token_hex(8)
                    row['pin'] = '%s$%s' % (salt, _pin_hash(pin, salt))
                else:
                    row['pin'] = ''
        _save(data)


def has_pin(pid):
    return bool((get(pid) or {}).get('pin'))


def pin_ok(pid, pin):
    stored = str((get(pid) or {}).get('pin') or '')
    if not stored:
        return True
    salt, _, digest = stored.partition('$')
    return secrets.compare_digest(digest, _pin_hash(str(pin or ''), salt))


def remove(pid):
    with _LOCK:
        data = load()
        if pid == PRIMARY:
            raise ValueError('The first profile cannot be removed.')
        if pid == data['active']:
            raise ValueError('Switch to another profile first.')
        data['profiles'] = [row for row in data['profiles'] if row['id'] != pid]
        _save(data)
        shutil.rmtree(os.path.join(folder(), pid), ignore_errors=True)
        for old in os.listdir(folder('pictures')):
            if old.startswith(pid + '-'):
                try:
                    os.remove(os.path.join(folder('pictures'), old))
                except OSError:
                    pass


# -- switching -----------------------------------------------------------------------------------

def _defaults():
    """The add-on's default value of each profile setting."""
    found = {key: '' for key in SETTINGS}
    try:
        import xml.etree.ElementTree as ET
        here = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'settings.xml')
        for item in ET.parse(here).iter('setting'):
            if item.get('id') in SETTINGS:
                found[item.get('id')] = item.get('default') or ''
    except Exception:
        pass
    return found


def _move(source_dir, target_dir):
    """Every profile file and folder from one place to the other (missing ones skipped)."""
    for name in FILES:
        for suffix in SUFFIXES:
            source = os.path.join(source_dir, name + suffix)
            if os.path.exists(source):
                os.replace(source, os.path.join(target_dir, name + suffix))
    for name in FOLDERS:
        source = os.path.join(source_dir, name)
        if os.path.isdir(source):
            target = os.path.join(target_dir, name)
            shutil.rmtree(target, ignore_errors=True)
            os.replace(source, target)


def _keep_settings(addon, pid):
    values = {key: addon.getSetting(key) for key in SETTINGS}
    _write(os.path.join(folder(pid), 'settings.json'), values)


def _apply_settings(addon, pid):
    values = dict(_defaults())
    values.update(_read(os.path.join(folder(pid), 'settings.json'), {}))
    for key in SETTINGS:
        if key in values and addon.getSetting(key) != str(values[key]):
            addon.setSetting(key, str(values[key]))


class _between_processes(object):
    """One switch at a time also between Kodi's processes (the service and the
    interface): a lock file; one left by a stopped Kodi is stale after STALE seconds."""
    STALE = 120

    def __enter__(self):
        path = os.path.join(folder(), 'switch.lock')
        until = time.monotonic() + 60
        while True:
            try:
                handle = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(handle, str(time.time()).encode())
                os.close(handle)
                self.path = path
                return self
            except FileExistsError:
                try:
                    if time.time() - os.path.getmtime(path) > self.STALE:
                        os.remove(path)
                        continue
                except OSError:
                    continue
                if time.monotonic() > until:
                    raise ValueError('Another profile switch is still running.')
                time.sleep(.1)

    def __exit__(self, *args):
        try:
            os.remove(self.path)
        except OSError:
            pass
        return False


def switch(target, addon=None):
    """Make ``target`` the active profile. The caller makes sure no sync runs."""
    with _LOCK, _between_processes():
        return _switch(target, addon)


def _switch(target, addon=None):
    import xbmcaddon
    data = load()
    if not any(row['id'] == target for row in data['profiles']):
        raise ValueError('This profile is gone.')
    current = data['active']
    if target == current and not os.path.exists(_journal()):
        return current
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    journal = _read(_journal(), {}) or {'from': current, 'to': target, 'stage': 'out'}
    _write(_journal(), journal)
    if journal['stage'] == 'out':
        _keep_settings(addon, journal['from'])
        _move(_root(), folder(journal['from']))
        journal['stage'] = 'in'
        _write(_journal(), journal)
    _move(folder(journal['to']), _root())
    _fresh_sign_in(folder(journal['from']), _root())
    _apply_settings(addon, journal['to'])
    data['active'] = journal['to']
    _save(data)
    for name in ('switching.json', 'switching.json.bak'):
        try:
            os.remove(os.path.join(folder(), name))
        except OSError:
            pass
    _after_switch()
    return journal['to']


OWN_KEYS = ('profile_index', 'profile_name', 'uses_primary_addons')


def _fresh_sign_in(old_dir, new_dir):
    """Two profiles on one Nuvio account (each its own Nuvio profile): only the active
    one renews the sign-in, so the one coming in takes the newest - else a renewed
    sign-in would leave the other's stale."""
    old = _read(os.path.join(old_dir, 'nuvio_token.json'), {})
    new = _read(os.path.join(new_dir, 'nuvio_token.json'), {})
    if not old.get('access_token') or not new.get('access_token'):
        return
    same = old.get('user_id') and old.get('user_id') == new.get('user_id') or \
        (old.get('email') and old.get('email') == new.get('email'))
    if same and old != new:
        fresh = {key: value for key, value in old.items() if key not in OWN_KEYS}
        fresh.update({key: new[key] for key in OWN_KEYS if key in new})
        _write(os.path.join(new_dir, 'nuvio_token.json'), fresh)


def nuvio_account_from_first():
    """The active profile has no Nuvio sign-in: the first profile's account (its own
    Nuvio profile is chosen next). False when the first profile has none either."""
    root_token = _read(os.path.join(_root(), 'nuvio_token.json'), {})
    if root_token.get('access_token'):
        return True
    if active() == PRIMARY:
        return False
    first = _read(os.path.join(folder(PRIMARY), 'nuvio_token.json'), {})
    if not first.get('access_token'):
        return False
    _write(os.path.join(_root(), 'nuvio_token.json'), {k: v for k, v in first.items() if k not in OWN_KEYS})
    settings = _read(os.path.join(folder(PRIMARY), 'settings.json'), {})
    from .settings_snapshot import cached_addon
    addon = cached_addon()
    for key in ('nuvio_email', 'nuvio_sync_direction', 'nuvio_progress_interval'):
        if settings.get(key):
            addon.setSetting(key, settings[key])
    for key, value in (('nuvio_sync_enabled', 'true'), ('nuvio_sync_progress', 'true'), ('nuvio_sync_library', 'true'),
                       ('nuvio_sync_addons', 'false'), ('nuvio_sync_collections', 'false')):
        addon.setSetting(key, value)
    return True


def finish_cut_short(addon=None):
    """A switch stopped half-way (Kodi closed during it) is finished first."""
    if os.path.exists(_journal()):
        journal = _read(_journal(), {})
        if journal.get('to'):
            switch(journal['to'], addon)


TONES = 8


def initials(name):
    words = [w for w in str(name or '').replace('-', ' ').split() if w[:1].isalnum()]
    return (''.join(w[0] for w in words[:2]) or str(name or '?')[:1]).upper()


def publish():
    """The profile in use for the corner's small circle (its picture, else its initials
    on its colour) - Window(Home) meganexus.profile.*."""
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        rows = profiles()
        now = active()
        index = next((i for i, row in enumerate(rows) if row['id'] == now), 0)
        row = rows[index] if rows else {}
        for key, value in (('active', now), ('name', row.get('name') or ''), ('initials', initials(row.get('name'))),
                           ('picture', row.get('picture') or ''), ('tone', str(index % TONES + 1))):
            home.setProperty('meganexus.profile.' + key, value)   # a window has no setProperties
    except Exception:
        pass


def _after_switch():
    try:
        from . import settings_snapshot
        settings_snapshot.invalidate()
    except Exception:
        pass
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        home.setProperty('meganexus.progress.revision', 'profile-%s' % time.time())
        home.setProperty('meganexus.library_dirty', '1')
    except Exception:
        pass
    publish()


def request(target, wait=45.0, monitor=None):
    """From the interface: the service switches (while no sync runs); itself when no
    service answers. True when ``target`` is active after it."""
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    if target == active():
        return True
    monitor = monitor or xbmc.Monitor()
    started = time.monotonic()
    while home.getProperty(SERVING) != '1' and time.monotonic() - started < SERVICE_WAIT:
        if monitor.waitForAbort(.2):   # at Kodi's start the service may come a moment later
            return False
    if home.getProperty(SERVING) != '1':
        switch(target)   # no service running: nothing syncs meanwhile
        return active() == target
    token = uuid.uuid4().hex
    home.setProperty(REQUEST, json.dumps({'id': target, 'token': token}))
    until = time.monotonic() + wait
    while time.monotonic() < until:
        answer = home.getProperty(DONE)
        if answer.startswith(token):
            return answer == token + '|ok' and active() == target
        if monitor.waitForAbort(.1):
            break
    return False


def serve(monitor, lock):
    """In the service: carries out switch requests holding the sync lock."""
    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    home.setProperty(SERVING, '1')
    publish()
    # what the HUB shows waits for who is watching - never more than COVER_MAX after the start
    started = time.monotonic()
    shown = bool(home.getProperty(SHOWN))
    try:
        while not monitor.abortRequested():
            if not shown and (home.getProperty(SHOWN) or time.monotonic() - started > COVER_MAX):
                home.setProperty(SHOWN, '1')
                shown = True
            raw = home.getProperty(REQUEST)
            if raw:
                home.clearProperty(REQUEST)
                try:
                    asked = json.loads(raw)
                except ValueError:
                    asked = {}
                result = 'error'
                if asked.get('id') and lock.acquire(timeout=40):
                    try:
                        switch(asked['id'])
                        result = 'ok'
                        xbmc.log('[MegaNexus] profiles: now %s' % (get(active()) or {}).get('name'), xbmc.LOGINFO)
                    except Exception as exc:
                        xbmc.log('[MegaNexus] profiles: switch failed: %s' % exc, xbmc.LOGERROR)
                    finally:
                        lock.release()
                home.setProperty(DONE, '%s|%s' % (asked.get('token') or '', result))
            if monitor.waitForAbort(.2):
                break
    finally:
        home.clearProperty(SERVING)
