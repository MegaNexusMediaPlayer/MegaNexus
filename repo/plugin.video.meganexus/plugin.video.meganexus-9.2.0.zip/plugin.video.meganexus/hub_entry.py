# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import os
import sys

addon_path = os.path.dirname(os.path.abspath(__file__))
lib_path = os.path.join(addon_path, 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:  # 7.0.52: player questions never stop all Python while a Usenet film closes
    from resources.lib.player_state import install as _safe_player
    _safe_player()
except Exception:
    pass

from resources.lib.kodi_entry import run

if __name__ == '__main__':
    try:
        run()
    finally:
        # 7.0.19: Kodi waits for every thread of this call; background workers
        # (subtitle search, catalog refresh...) end once their work is done, so
        # a playback no longer leaves the call - and its memory - behind.
        try:
            from resources.lib import script_exit
            script_exit.stop()
        except Exception:
            pass
