# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Where intros and credits are, from every source we have (7.0.29).

1. TheIntroDB (skip_service.lookup, API key in HUB Settings > API keys).
2. The media server the episode plays from: Plex markers (intro, credits),
   Jellyfin media segments (Intro, Outro, Recap, Preview), Emby chapter
   markers (IntroStart / IntroEnd / CreditsStart). They belong to that very
   file, so they win over TheIntroDB for their kind.
3. The file's own chapters named Intro / Opening / Credits / Ending (Kodi's
   Player.ChapterName), checked while it plays.
4. Up next: an episode with a next one and no known credits offers
   "Next episode" 1 min 30 s before its end (7.0.42; the watched percentage
   came far too early on long episodes). HUB Settings > Playback turns it off.

Segments are {'type': intro|recap|credits|preview|upnext, 'start', 'end'} in seconds.
"""
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
from urllib.request import Request, urlopen

UPNEXT = 'meganexus_upnext'            # 'watched' (default, on) or 'off'
LEAD = 90                               # 7.0.42: seconds before the end
WATCHED = 'simkl_watched_threshold'     # the one "counts as watched" percentage
WATCHED_CHOICES = ('75', '80', '85', '90', '95')
CHAPTERS = 'meganexus_skip_chapters'
OUTRO = 'meganexus_skip_outro'          # 7.0.50: Skip outro on its own (8.1.4: on - never beside Next episode)
INTRO_CHAPTER = re.compile(r'^\s*(?:intro(?:duction)?|opening(?: credits| titles)?|op|recap|previously(?: on)?.*|cold open)\s*$', re.I)
CREDITS_CHAPTER = re.compile(r'^\s*(?:(?:end(?:ing)?\s*)?credits|ending|outro|ed|end titles|closing credits)\s*$', re.I)
TICKS = 10000000.0


def outro_on(addon):
    """7.0.50: the Skip outro button at the credits (Next episode is offered there either way)."""
    return (addon.getSetting(OUTRO) or 'true') != 'false'


def upnext_on(addon):
    return (addon.getSetting(UPNEXT) or 'watched') != 'off'


def watched_percent(addon):
    try:
        return max(50.0, min(99.0, float(addon.getSetting(WATCHED) or 85)))
    except (TypeError, ValueError):
        return 85.0


def chapters_on(addon):
    return (addon.getSetting(CHAPTERS) or 'true') != 'false'


def _clean(rows, duration):
    out = []
    for row in rows:
        try:
            start, end = float(row['start']), float(row['end'])
        except (KeyError, TypeError, ValueError):
            continue
        end = min(end, duration - 0.75)
        if 0 <= start < end and start < duration - 1:
            out.append({'type': row['type'], 'start': start, 'end': end})
    return out


def plex(ctx, duration, timeout=4):
    base, key, token = ctx.get('server_url'), ctx.get('rating_key'), ctx.get('token')
    if not (base and key):
        return []
    url = '%s/library/metadata/%s?%s' % (str(base).rstrip('/'), key, urlencode({'includeMarkers': 1, 'X-Plex-Token': token or ''}))
    with urlopen(Request(url, headers={'Accept': 'application/xml'}), timeout=timeout) as response:
        root = ET.fromstring(response.read(2 * 1024 * 1024))
    rows = []
    for marker in root.iter('Marker'):
        kind = {'intro': 'intro', 'credits': 'credits'}.get(marker.get('type'))
        if kind:
            rows.append({'type': kind, 'start': int(marker.get('startTimeOffset') or 0) / 1000.0,
                         'end': int(marker.get('endTimeOffset') or 0) / 1000.0})
    return _clean(rows, duration)


def _emby_get(ctx, path, timeout=4):
    from . import mediabrowser
    flavor = ctx.get('server_flavor') or mediabrowser.JELLYFIN
    url = str(ctx.get('server_url') or '').rstrip('/') + path
    raw = mediabrowser.request(url, token=ctx.get('token') or '', timeout=timeout, flavor=flavor)
    return mediabrowser.json_of(raw) if raw else {}


def jellyfin(ctx, duration):
    item = ctx.get('item_id')
    if not (ctx.get('server_url') and item):
        return []
    data = _emby_get(ctx, '/MediaSegments/%s' % item)
    kinds = {'Intro': 'intro', 'Outro': 'credits', 'Recap': 'recap', 'Preview': 'preview'}
    rows = [{'type': kinds[s.get('Type')], 'start': (s.get('StartTicks') or 0) / TICKS, 'end': (s.get('EndTicks') or 0) / TICKS}
            for s in data.get('Items') or [] if s.get('Type') in kinds]
    return _clean(rows, duration)


def emby(ctx, duration):
    item = ctx.get('item_id')
    if not (ctx.get('server_url') and item):
        return []
    from . import mediabrowser
    account = mediabrowser.account_for_url(ctx.get('server_url')) or {}
    user = account.get('user_id') or account.get('UserId') or ''
    path = ('/emby/Users/%s/Items/%s?Fields=Chapters' % (user, item)) if user else ('/emby/Items/%s?Fields=Chapters' % item)
    data = _emby_get(ctx, path)
    marks = {}
    for chapter in data.get('Chapters') or []:
        kind = chapter.get('MarkerType')
        if kind in ('IntroStart', 'IntroEnd', 'CreditsStart'):
            marks[kind] = (chapter.get('StartPositionTicks') or 0) / TICKS
    rows = []
    if 'IntroStart' in marks and marks.get('IntroEnd', 0) > marks['IntroStart']:
        rows.append({'type': 'intro', 'start': marks['IntroStart'], 'end': marks['IntroEnd']})
    if 'CreditsStart' in marks:
        rows.append({'type': 'credits', 'start': marks['CreditsStart'], 'end': duration})
    return _clean(rows, duration)


def server(ctx, duration):
    """The playing server's own markers; [] for any other source or on error."""
    try:
        if ctx.get('server_type') == 'plex':
            return plex(ctx, duration)
        if ctx.get('server_type') == 'emby':
            if (ctx.get('server_flavor') or '') == 'emby':
                return emby(ctx, duration)
            return jellyfin(ctx, duration)
    except Exception:
        return []
    return []


def merge(introdb, from_server):
    """One segment per kind: the server's (same file) before TheIntroDB's."""
    kinds = {row['type'] for row in from_server}
    rows = list(from_server) + [row for row in introdb if row['type'] not in kinds]
    return sorted(rows, key=lambda row: row['start'])


def has_credits(segments):
    return any(row['type'] in ('credits', 'preview') for row in segments)


def upnext(segments, duration, on, next_available, lead=LEAD):
    """'Next episode' for the last ``lead`` seconds, only when no credits are known."""
    if not next_available or not on or has_credits(segments) or duration <= 2 * lead:
        return None
    return {'type': 'upnext', 'start': duration - lead, 'end': duration - 0.75}


CREDITS_WINDOW = 600.0    # 9.0.5: the end credits are in the last 10 minutes...
CREDITS_SHARE = .2        # ...or the last fifth of the video, never in its first half


def _number(value):
    try:
        return int(str(value or '').strip())
    except ValueError:
        return None


def chapter(name, position, duration, number=None, count=None):
    """A segment from the playing chapter's name (Intro / Credits), or None.

    9.0.5: a name alone is not where it is. Marianne's file had one chapter, "End Credits",
    for the whole episode - Kodi names the chapter at 0:00 so, and Next episode came at the
    very start ("to nesmije na pocetku nikad"). A file with a single chapter says nothing;
    the credits are never the first chapter (the episode comes before them) and only near
    the end; an intro or a recap only in the first half. ``number`` / ``count``: Kodi's
    Player.Chapter / Player.ChapterCount (unknown: not checked)."""
    name = str(name or '').strip()
    if not name:
        return None
    number, count = _number(number), _number(count)
    if count is not None and count < 2:
        return None
    try:
        duration = float(duration or 0)
    except (TypeError, ValueError):
        duration = 0.0
    if CREDITS_CHAPTER.match(name):
        near_end = duration > 0 and position >= max(duration / 2, duration - max(CREDITS_WINDOW, duration * CREDITS_SHARE))
        if not near_end or number == 1:
            return None
        return {'type': 'credits', 'start': position, 'end': duration - 0.75, 'chapter': True}
    if INTRO_CHAPTER.match(name):
        if duration > 0 and position > duration / 2:
            return None
        kind = 'recap' if re.match(r'\s*(recap|previously)', name, re.I) else 'intro'
        return {'type': kind, 'start': position, 'end': duration - 0.75, 'chapter': True, 'name': name}
    return None
