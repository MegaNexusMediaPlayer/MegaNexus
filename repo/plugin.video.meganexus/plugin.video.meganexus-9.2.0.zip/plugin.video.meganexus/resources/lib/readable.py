# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A title's words in letters the skin can draw (idea 2026-11-21).

"text je zbugan sa kockicama bit ce da nasi fontovi ne podrzavaju" - "tako je, zamijeniti engleskim koje nemamo font":
a K-drama with no Croatian on TMDB came from the metadata add-on in Korean, which no font set of the skin has (nor Kodi's
own), and its title and story drew as boxes. What the add-ons send (addon_wire: catalogs and details) is looked at here:
a name, a story or an episode's title in letters the font set in use lacks (resources/text_cover.json, made by
review/make_text_cover.py) becomes TMDB's English one - asked once, kept a month (tmdb_api's store), WAIT seconds at
most; one not come by then is left empty (never boxes) and comes in English the next time. Without a TMDB key: empty.
"""
import bisect
import json
import os
import threading
import time

LIFE = 30 * 86400          # s an English text is kept
NOT_FOUND = 86400          # ... and that TMDB had none
WAIT = 2.5                 # s a page waits for the English ones (the rest come behind, for the next time)
AT_ONCE = 4                # TMDB asked for that many titles at once
COVER = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'text_cover.json')
_COVER = {}
_SET = {'name': None, 'at': -1e9}


def _ranges(fontset):
    if not _COVER:
        try:
            with open(COVER, encoding='utf-8') as handle:
                for name, ranges in json.load(handle).items():
                    _COVER[name] = ([a for a, _ in ranges], [b for _, b in ranges])
        except (OSError, ValueError):
            _COVER['_all'] = None
    return _COVER.get(fontset) or _COVER.get('_all')


def _fontset():
    """The font set in use (Kodi's Skin.Font), asked once a minute."""
    now = time.monotonic()
    if now - _SET['at'] > 60:
        try:
            import xbmc
            _SET['name'] = xbmc.getInfoLabel('Skin.Font') or ''
        except Exception:
            _SET['name'] = ''
        _SET['at'] = now
    return _SET['name']


def drawable(text, fontset=None):
    """Every letter of ``text`` is in the font set's (spaces and Kodi's [B]-style marks are ASCII)."""
    text = str(text or '')
    if not text or all(ord(char) < 0x250 for char in text):
        return True
    found = _ranges(fontset or _fontset())
    if not found:
        return True
    starts, ends = found
    for char in text:
        code = ord(char)
        if code < 0x250 or char.isspace():
            continue
        at = bisect.bisect_right(starts, code) - 1
        if at < 0 or code > ends[at]:
            return False
    return True


def _ids(meta):
    mid = str(meta.get('id') or '')
    imdb = str(meta.get('imdb_id') or (mid if mid.startswith('tt') else ''))
    tmdb = str(meta.get('moviedb_id') or meta.get('tmdb_id') or (mid.split(':', 1)[1] if mid.startswith('tmdb:') else ''))
    return tmdb, imdb


def english(meta, media_type, seasons=()):
    """TMDB's English {'name', 'description', 'episodes': {'s:e': [title, story]}} of ``meta`` (its ``seasons``' episodes
    too), kept; {} when TMDB has it not, None without a TMDB key."""
    from . import tmdb_api
    if not tmdb_api.api_key():
        return None
    tmdb, imdb = _ids(meta)
    kind = tmdb_api.kind_of(media_type)
    if not (tmdb or imdb):
        return {}
    key = 'english:%s:%s' % (kind, tmdb or imdb)
    have = tmdb_api.kept(key)
    wanted = [str(s) for s in seasons]
    if have is not None and all(s in (have.get('seasons') or []) for s in wanted):
        return have
    found = dict(have or {})
    tid = tmdb_api.find_id(tmdb, imdb, media_type)
    if not tid:
        tmdb_api.keep(key, {}, NOT_FOUND)
        return {}
    if 'name' not in found:
        detail = tmdb_api.get('/%s/%s' % (kind, tid), {'language': 'en-US'}) or {}
        found.update(name=detail.get('title') or detail.get('name') or '', description=detail.get('overview') or '')
    episodes = dict(found.get('episodes') or {})
    for season in [s for s in wanted if s not in (found.get('seasons') or [])]:
        answer = tmdb_api.get('/tv/%s/season/%s' % (tid, season), {'language': 'en-US'}) or {}
        for row in answer.get('episodes') or []:
            episodes['%s:%s' % (season, row.get('episode_number'))] = [row.get('name') or '', row.get('overview') or '']
    found.update(episodes=episodes, seasons=sorted(set((found.get('seasons') or []) + wanted)))
    tmdb_api.keep(key, found, LIFE)
    return found


def _english(text, better):
    """``text`` as it is when it can be drawn, else the English one (or nothing - never boxes)."""
    if drawable(text):
        return text
    return better if better and drawable(better) else ''


def _fixed(meta, found):
    meta = dict(meta)
    for key in ('name', 'description'):
        if key in meta:
            meta[key] = _english(meta.get(key), (found or {}).get(key))
    videos = meta.get('videos')
    if isinstance(videos, list) and any(isinstance(v, dict) and not _words_drawable(v) for v in videos):
        episodes = (found or {}).get('episodes') or {}
        out = []
        for video in videos:
            if isinstance(video, dict) and not _words_drawable(video):
                english_one = episodes.get('%s:%s' % (video.get('season'), video.get('episode'))) or ['', '']
                video = dict(video)
                for key, at in (('title', 0), ('name', 0), ('overview', 1), ('description', 1)):
                    if key in video:
                        video[key] = _english(video.get(key), english_one[at])
            out.append(video)
        meta['videos'] = out
    return meta


def _words_drawable(meta):
    return all(drawable(meta.get(key)) for key in ('name', 'title', 'description', 'overview'))


def _within(jobs):
    """Run ``jobs`` (callables) AT_ONCE at a time; the answers come by WAIT (None for one still on its way - it goes
    on behind and keeps its answer for the next time)."""
    answers, threads = [None] * len(jobs), []
    pending = list(enumerate(jobs))
    lock = threading.Lock()

    def worker():
        while True:
            with lock:
                if not pending:
                    return
                at, job = pending.pop(0)
            try:
                answers[at] = job()
            except Exception:
                answers[at] = None
    for _ in range(min(AT_ONCE, len(jobs))):
        thread = threading.Thread(target=worker, name='MegaNexusEnglish', daemon=True)
        thread.start()
        threads.append(thread)
    until = time.monotonic() + WAIT
    for thread in threads:
        thread.join(max(0.0, until - time.monotonic()))
    return list(answers)


def fix_meta(answer, media_type):
    """An add-on's details answer ({'meta': ...}) with its words drawable - a new dict when one changed."""
    meta = (answer or {}).get('meta') if isinstance(answer, dict) else None
    if not isinstance(meta, dict):
        return answer
    videos = meta.get('videos') if isinstance(meta.get('videos'), list) else []
    bad = [v for v in videos if isinstance(v, dict) and not _words_drawable(v)]
    if not bad and _words_drawable(meta):
        return answer
    seasons = sorted({v.get('season') for v in bad if v.get('season') is not None}, key=str)
    found = _within([lambda: english(meta, media_type, seasons)])[0]
    return dict(answer, meta=_fixed(meta, found))


def fix_catalog(answer, media_type):
    """An add-on's catalog page ({'metas': [...]}) with every title's words drawable - a new dict when one changed."""
    metas = (answer or {}).get('metas') if isinstance(answer, dict) else None
    if not isinstance(metas, list):
        return answer
    bad = [n for n, meta in enumerate(metas) if isinstance(meta, dict) and not _words_drawable(meta)]
    if not bad:
        return answer
    found = _within([(lambda m=metas[n]: english(m, m.get('type') or media_type)) for n in bad])
    out = list(metas)
    for n, english_one in zip(bad, found):
        out[n] = _fixed(metas[n], english_one)
    return dict(answer, metas=out)
