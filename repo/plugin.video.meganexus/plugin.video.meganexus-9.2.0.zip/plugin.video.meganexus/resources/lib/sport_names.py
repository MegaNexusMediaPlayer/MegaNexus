# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, a national side's name as the person's own guide writes it: ESPN says "Poland - Sweden", the
guide of the person's IPTV list "Fudbal - Liga nacija: Poljska - Švedska".

The countries' names in the language of where this box is - its time zone's country (the system's zone table), that
country's language (Unicode's likely subtags: BA - Bosnian in Latin letters) - and in English, from Unicode's own CLDR
(its territory names; nothing of ours). A side is a country's when ESPN's badge for it is a country's flag; its English
name finds the country (all its words in CLDR's English name: "Bosnia-Herzegovina" - "Bosnia & Herzegovina").
CLDR's tables are Unicode's and change once a year: kept on disk (KEEP_DAYS) - nothing else is."""
import json
import os
import re
import time
import unicodedata
import urllib.request

TERRITORIES = 'https://raw.githubusercontent.com/unicode-org/cldr-json/main/cldr-json/cldr-localenames-full/main/%s/territories.json'
LIKELY = 'https://raw.githubusercontent.com/unicode-org/cldr-json/main/cldr-json/cldr-core/supplemental/likelySubtags.json'
ZONES = ('/usr/share/zoneinfo/zone1970.tab', '/usr/share/zoneinfo/zone.tab')
KEEP_DAYS = 30
AGENT = 'Mozilla/5.0 (X11; Linux x86_64) MegaNexus'
_tables = {}


def _plain(text):
    text = unicodedata.normalize('NFKD', text or '')
    return [w for w in re.split(r'[^a-z0-9]+', ''.join(c for c in text if not unicodedata.combining(c)).lower()) if w]


def _fetch(url, folder, name):
    """Unicode's table from ``url`` - from the disk while it is younger than KEEP_DAYS."""
    path = os.path.join(folder, name) if folder else ''
    if path and os.path.exists(path) and time.time() - os.path.getmtime(path) < KEEP_DAYS * 86400:
        with open(path, encoding='utf-8') as text:
            return json.load(text)
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': AGENT}), timeout=20) as reply:
        data = json.loads(reply.read().decode('utf-8'))
    if path:
        os.makedirs(folder, exist_ok=True)
        with open(path + '.new', 'w', encoding='utf-8') as out:
            json.dump(data, out)
        os.replace(path + '.new', path)
    return data


def zone_country():
    """The country of this box's time zone (Europe/Sarajevo - BA), '' when it is not known."""
    zone = os.environ.get('TZ', '').lstrip(':')
    if not zone:
        try:
            zone = os.path.realpath('/etc/localtime').split('zoneinfo/')[-1]
        except OSError:
            return ''
    for table in ZONES:
        try:
            with open(table, encoding='utf-8') as text:
                for line in text:
                    parts = line.rstrip('\n').split('\t')
                    if len(parts) >= 3 and not line.startswith('#') and parts[2] == zone:
                        return parts[0].split(',')[0]
        except OSError:
            continue
    return ''


def local_languages(folder=''):
    """CLDR's names of the language(s) of this box's country: ['bs'], ['hr'], ['de']; a language CLDR writes in
    other letters first gets its Latin writing too (['sr', 'sr-Latn'] - the guides there use both); [] unknown."""
    country = zone_country()
    if not country:
        return []
    likely = _fetch(LIKELY, folder, 'cldr_likely.json')['supplemental']['likelySubtags'].get('und-' + country, '')
    parts = likely.split('-')                           # 'bs-Latn-BA', 'sr-Cyrl-RS'
    if not parts or not parts[0]:
        return []
    return [parts[0]] + (['%s-Latn' % parts[0]] if len(parts) > 2 and parts[1] != 'Latn' else [])


def countries(language, folder=''):
    """{code: name} - CLDR's names of the countries in ``language``."""
    key = (language, folder)
    if key not in _tables:
        data = _fetch(TERRITORIES % language, folder, 'cldr_territories_%s.json' % language)
        _tables[key] = {code: name for code, name in data['main'][language]['localeDisplayNames']['territories'].items()
                        if len(code) == 2 and code.isalpha()}
    return _tables[key]


def is_country(side):
    return '/countries/' in (side.get('logo') or '')


def country_code(name, english):
    """The code of the country ``name`` (ESPN's English) is: all its words in CLDR's English name, the fewest others."""
    said = set(_plain(name)) - {'and'}
    found = [(len(set(_plain(other)) - said - {'and'}), code) for code, other in english.items() if said and said <= set(_plain(other)) | {'and'}]
    return min(found)[1] if found else ''


def add_local_names(match, folder=''):
    """``match``'s national sides get their names in the box's language (side['also']); a club is as it is. Nothing
    happens when the tables cannot be had."""
    sides = [s for s in match.get('sides') or [] if is_country(s) and 'also' not in s]
    if not sides:
        return match
    try:
        english = countries('en', folder)
        languages = [l for l in local_languages(folder) if l != 'en']
    except Exception:
        return match
    local = []
    for language in languages:
        try:
            local.append(countries(language, folder))
        except Exception:                               # (a writing CLDR does not have)
            pass
    for side in sides:
        code = country_code(side.get('name') or '', english)
        names = [table.get(code) for table in local] + [english.get(code)] if code else []
        side['also'] = [n for n in dict.fromkeys(names) if n and n != side.get('name')]
    return match
