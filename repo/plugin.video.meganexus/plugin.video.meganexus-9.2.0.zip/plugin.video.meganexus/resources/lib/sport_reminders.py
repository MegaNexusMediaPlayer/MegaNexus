# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Sport reminders (8.1.3): hold OK on an event that is not live yet, and MegaNexus says
when it is.

"Live" is what the Sport screen already goes by: the add-on's own listing marks the
event live (sports.card). Nothing here knows any add-on by name. The service looks the
event up again in the sport catalogs of the add-on it came from, because an event moves
from an "upcoming" catalog to a "live" one under whatever names that add-on uses.

Idea 2026-11-18: a MegaSport match (its card's menu) has its own start: it is said LEAD seconds before it, and Watch
opens MegaSport.
"""
import json
import os
import time

import xbmc

from .meganexus.paths import profile_path

EVERY = 60            # seconds between looks while a reminder is waiting
KEEP = 36 * 3600      # a reminder that never went live is dropped after this
LEAD = 120            # seconds before a MegaSport match's start it is said


def _path():
    return os.path.join(profile_path(), 'sport_reminders.json')


def _read():
    try:
        with open(_path(), encoding='utf-8') as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(value):
    from .meganexus.json_files import write_json
    write_json(_path(), value)


def has(event):
    return str(event.get('id') or '') in _read()


def add(event):
    saved = _read()
    saved[str(event['id'])] = {'id': event['id'], 'type': event.get('type') or '', 'title': event.get('title') or '',
                               'provider_id': event.get('provider_id') or '', 'art': event.get('art') or '',
                               'added': int(time.time()), 'start': event.get('start') or 0, 'app': event.get('app') or ''}
    _write(saved)


def remove(event_id):
    saved = _read()
    if saved.pop(str(event_id), None) is not None:
        _write(saved)


def waiting():
    return list(_read().values())


def _live_ids(provider_id):
    """Ids the add-on lists as live now, across its sport catalogs (its own names)."""
    from . import sports
    found = set()
    for provider, catalog in sports.catalogs():
        if provider.get('id') != provider_id:
            continue
        metas, fresh = sports.cached_page(provider, catalog)
        if metas is None or not fresh:
            try:
                metas = sports.load_page(provider, catalog, timeout=8)
            except Exception:
                metas = metas or []
        for meta in metas or []:
            if 'live' in str(meta.get('releaseInfo') or '').lower():
                found.add(str(meta.get('id')))
    return found


def check(notify=None):
    """One look: the reminders whose event is live now are said and dropped."""
    saved = _read()
    if not saved:
        return []
    now = time.time()
    said, live = [], {}
    for key, reminder in list(saved.items()):
        if reminder.get('start'):                     # a MegaSport match: by its own start
            if now >= float(reminder['start']) - LEAD:
                saved.pop(key, None)
                if now - float(reminder['start']) < 3 * 3600:      # (not one that ended while the box was off)
                    said.append(reminder)
            continue
        if now - float(reminder.get('added') or now) > KEEP:
            saved.pop(key, None)
            continue
        provider = reminder.get('provider_id') or ''
        if provider not in live:
            live[provider] = _live_ids(provider)
        if key in live[provider]:
            saved.pop(key, None)
            said.append(reminder)
    if said or len(saved) != len(_read()):
        _write(saved)
    for reminder in said:
        (notify or _notify)(reminder)
    return said


def _notify(reminder):
    import xbmcgui
    title = reminder.get('title') or 'Your event'
    app = 'megasport' if reminder.get('app') == 'megasport' else 'sports'
    said = '%s starts now' % title if app == 'megasport' else '%s is live now' % title
    playing = xbmc.Player().isPlayingVideo()
    if playing:
        xbmcgui.Dialog().notification('MegaSport' if app == 'megasport' else 'Sport', said, reminder.get('art') or xbmcgui.NOTIFICATION_INFO, 10000)
        return
    if xbmcgui.Dialog().yesno('MegaSport' if app == 'megasport' else 'Sport', said + '.', nolabel='Later', yeslabel='Watch'):
        xbmc.executebuiltin('RunScript(script.meganexus,%s)' % app)


def run(monitor):
    """The service: a look every EVERY seconds while something is waiting."""
    while not monitor.waitForAbort(EVERY):
        try:
            if waiting():
                check()
        except Exception as exc:
            xbmc.log('[MegaNexus] Sport reminders: %s' % exc, xbmc.LOGDEBUG)
