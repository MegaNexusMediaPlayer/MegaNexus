# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Subtitle auto-sync without AI (7.0.29, experimental - the player's Sync button).

A subtitle made for another release of the film starts early or late, or
drifts (25 fps vs 23.976 fps). MegaNexus lines it up against a reference
timeline that belongs to the playing file - subtitles the stream itself
supplies, or a release whose name matches the stream - in any language:
when people speak, the cues start, whatever the language.

How (MegaNexus' own method): every cue start of the subtitle votes for the
shift that puts it on a cue start of the reference; the strongest shift, at
each of the usual frame-rate ratios, wins when enough cues agree. The
median of the agreeing cues refines it. The result is written as a new SRT
and loaded at once; nothing changes when the match is not convincing.
"""
import html
import re

RATIOS = (1.0, 25 / 23.976, 23.976 / 25, 24 / 23.976, 23.976 / 24, 25 / 24, 24 / 25)
BIN = 0.1                 # seconds per vote bucket
SEARCH = 180.0            # the largest shift tried, seconds
MATCH = 0.45              # a cue agrees within this many seconds
MIN_SHARE = 0.30          # this share of the cues must agree...
MIN_MATCHES = 15          # ...and at least this many
# 9.1.2: ...and clearly more than chance does. Against a dense track (an SDH one: 762 lines in 50 minutes) a cue
# meets one of its lines within MATCH a quarter of the time whatever the timing: Lupin's Croatian subtitle "fitted"
# at 34 % moved by 116 s and slowed to 24 fps, where it already sat at 29 % - chance was 25 %
ABOVE_CHANCE = 0.20
SAMPLE = 600              # cues used for the votes (spread over the film)

TIME = re.compile(r'(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})')
ARROW = re.compile(r'(\d+:\d{1,2}:\d{1,2}[,.]\d{1,3})\s*-->\s*(\d+:\d{1,2}:\d{1,2}[,.]\d{1,3})')
ASS_TIME = re.compile(r'(\d+):(\d{2}):(\d{2})[.](\d{2})')
ASS_TAGS = re.compile(r'\{[^}]*\}')
TAGS = re.compile(r'<[^>]+>')


def _seconds(text):
    found = TIME.match(text.strip())
    if not found:
        return None
    h, m, s, ms = found.groups()
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms.ljust(3, '0')[:3]) / 1000.0


def _ass_seconds(text):
    found = ASS_TIME.match(text.strip())
    if not found:
        return None
    h, m, s, cs = found.groups()
    return int(h) * 3600 + int(m) * 60 + int(s) + int(cs) / 100.0


def parse(text):
    """[(start, end, text)] from SRT, WebVTT or ASS/SSA."""
    text = str(text or '').replace('\r\n', '\n').replace('\r', '\n').lstrip('﻿')
    cues = []
    if '[Events]' in text or re.search(r'(?m)^Dialogue:', text):
        fields = ['Layer', 'Start', 'End', 'Style', 'Name', 'MarginL', 'MarginR', 'MarginV', 'Effect', 'Text']
        for line in text.split('\n'):
            if line.startswith('Format:') and 'Start' in line:
                fields = [f.strip() for f in line[7:].split(',')]
            elif line.startswith('Dialogue:'):
                parts = line[9:].split(',', len(fields) - 1)
                if len(parts) < len(fields):
                    continue
                row = dict(zip(fields, parts))
                start, end = _ass_seconds(row.get('Start', '')), _ass_seconds(row.get('End', ''))
                body = ASS_TAGS.sub('', row.get('Text', '')).replace('\\N', '\n').replace('\\n', '\n').strip()
                if start is not None and end is not None and body:
                    cues.append((start, end, body))
        return sorted(cues)
    for block in re.split(r'\n\s*\n', text):
        lines = [l for l in block.split('\n') if l.strip()]
        for index, line in enumerate(lines):
            found = ARROW.search(line)
            if found:
                start, end = _seconds(found.group(1)), _seconds(found.group(2))
                body = '\n'.join(lines[index + 1:]).strip()
                if start is not None and end is not None and body:
                    cues.append((start, end, body))
                break
    return sorted(cues)


def _starts(cues):
    starts = sorted({round(c[0], 2) for c in cues})
    if len(starts) > SAMPLE:
        step = len(starts) / float(SAMPLE)
        starts = [starts[int(i * step)] for i in range(SAMPLE)]
    return starts


def _near(sorted_values, value):
    """Distance from value to the nearest of the sorted values."""
    import bisect
    at = bisect.bisect_left(sorted_values, value)
    best = float('inf')
    for i in (at - 1, at):
        if 0 <= i < len(sorted_values):
            best = min(best, abs(sorted_values[i] - value))
    return best


def align(target, reference):
    """(ratio, shift, share, matches) mapping target times t -> t * ratio + shift,
    or None when the reference does not fit the subtitle."""
    import bisect
    mine, theirs = _starts(target), sorted(c[0] for c in reference)
    if len(mine) < MIN_MATCHES or len(theirs) < MIN_MATCHES:
        return None
    best = None
    for ratio in RATIOS:
        votes = {}
        for t in mine:
            scaled = t * ratio
            low = bisect.bisect_left(theirs, scaled - SEARCH)
            high = bisect.bisect_right(theirs, scaled + SEARCH)
            for r in theirs[low:high]:
                bucket = int(round((r - scaled) / BIN))
                votes[bucket] = votes.get(bucket, 0) + 1
        if not votes:
            continue
        # The strongest bucket with its neighbours (a shift between two buckets).
        bucket = max(votes, key=lambda b: votes[b] + 0.5 * (votes.get(b - 1, 0) + votes.get(b + 1, 0)))
        shift = bucket * BIN
        diffs = []
        for t in mine:
            scaled = t * ratio + shift
            at = bisect.bisect_left(theirs, scaled)
            near = min((theirs[i] for i in (at - 1, at) if 0 <= i < len(theirs)), key=lambda r: abs(r - scaled))
            if abs(near - scaled) <= MATCH:
                diffs.append(near - scaled)
        if not diffs:
            continue
        diffs.sort()
        shift += diffs[len(diffs) // 2]                  # the median refines it
        matches = sum(1 for t in mine if _near(theirs, t * ratio + shift) <= MATCH)
        share = matches / float(len(mine))
        if best is None or (share, -abs(ratio - 1)) > (best[2], -abs(best[0] - 1)):
            best = (ratio, shift, share, matches)
    if best is None or best[2] < max(MIN_SHARE, chance(theirs) + ABOVE_CHANCE) or best[3] < MIN_MATCHES:
        return None
    return best


def chance(starts):
    """The share of cues that meet a line of a track with these ``starts`` within MATCH by chance alone."""
    starts = sorted(starts)
    span = (starts[-1] - starts[0]) if len(starts) > 1 else 0
    return min(1.0, len(starts) * 2 * MATCH / span) if span > 0 else 1.0


def share_at(target, reference, ratio=1.0, shift=0.0):
    """The share of ``target``'s cues that meet a line of ``reference`` timed t -> t * ratio + shift."""
    mine, theirs = _starts(target), sorted(c[0] for c in reference)
    if not mine or not theirs:
        return 0.0
    return sum(1 for t in mine if _near(theirs, t * ratio + shift) <= MATCH) / float(len(mine))


PIECE = 600.0             # 7.0.50: seconds of film per piece for piece-by-piece timing
PIECE_SEARCH = 25.0       # ... how far a piece may sit from the whole-film timing
PIECE_MIN = 8             # ... cues a piece needs to count


def _local_shift(starts, theirs, ratio, shift):
    """The extra shift that puts these cue starts on the reference's, near ``shift``: (extra, matches)."""
    import bisect
    votes = {}
    for t in starts:
        scaled = t * ratio + shift
        low = bisect.bisect_left(theirs, scaled - PIECE_SEARCH)
        high = bisect.bisect_right(theirs, scaled + PIECE_SEARCH)
        for r in theirs[low:high]:
            bucket = int(round((r - scaled) / BIN))
            votes[bucket] = votes.get(bucket, 0) + 1
    if not votes:
        return None
    bucket = max(votes, key=lambda b: votes[b] + 0.5 * (votes.get(b - 1, 0) + votes.get(b + 1, 0)))
    extra = bucket * BIN
    diffs = sorted(d for d in ((_nearest(theirs, t * ratio + shift + extra) - (t * ratio + shift + extra)) for t in starts)
                   if abs(d) <= MATCH)
    if len(diffs) < PIECE_MIN // 2:
        return None
    return extra + diffs[len(diffs) // 2], len(diffs)


def _nearest(sorted_values, value):
    import bisect
    at = bisect.bisect_left(sorted_values, value)
    found = [sorted_values[i] for i in (at - 1, at) if 0 <= i < len(sorted_values)]
    return min(found, key=lambda r: abs(r - value)) if found else float('inf')


def align_pieces(target, reference, ratio=1.0, shift=0.0):
    """7.0.50, Autosync's second try: the film piece by piece (PIECE seconds each) - a
    release with a scene added or cut runs early before it and late after it, which one
    timing for the whole film can not fix. Each piece gets its own shift near the
    whole-film one, neighbours smooth it, cues between pieces follow the line between
    them. Returns (retimed cues, share of cues that meet the reference) or None."""
    theirs = sorted(c[0] for c in reference)
    cues = sorted(target)
    if len(cues) < 2 * MIN_MATCHES or len(theirs) < MIN_MATCHES:
        return None
    pieces = {}
    for start, _, _ in cues:
        pieces.setdefault(int((start * ratio + shift) // PIECE), []).append(start)
    found = []
    for number in sorted(pieces):
        starts = pieces[number]
        if len(starts) < PIECE_MIN:
            continue
        local = _local_shift(starts, theirs, ratio, shift)
        if local:
            found.append((sum(starts) / len(starts), local[0]))
    if len(found) < 2:
        return None
    smooth = []
    for i, (at, extra) in enumerate(found):          # a piece unlike both neighbours takes their median
        near = sorted(e for _, e in found[max(0, i - 1):i + 2])
        smooth.append((at, near[len(near) // 2] if abs(extra - near[len(near) // 2]) > 2.0 else extra))

    def extra_at(t):
        if t <= smooth[0][0]:
            return smooth[0][1]
        for (a, ea), (b, eb) in zip(smooth, smooth[1:]):
            if t <= b:
                if abs(eb - ea) > 1.0:               # a cut or an added scene: a step, not a slope
                    return ea if t < (a + b) / 2 else eb
                return ea + (eb - ea) * (t - a) / (b - a)
        return smooth[-1][1]
    retimed = []
    for start, end, body in cues:
        extra = extra_at(start)
        new_start, new_end = start * ratio + shift + extra, end * ratio + shift + extra
        if new_end > 0:
            retimed.append((max(0.0, new_start), new_end, body))
    starts = _starts(retimed)
    share = sum(1 for t in starts if _near(theirs, t) <= MATCH) / float(len(starts) or 1)
    return retimed, share


def share_of(target, reference, ratio, shift):
    """Share of the target's cues that meet the reference with this timing."""
    theirs = sorted(c[0] for c in reference)
    starts = _starts(target)
    return sum(1 for t in starts if _near(theirs, t * ratio + shift) <= MATCH) / float(len(starts) or 1)


def retime(cues, ratio, shift):
    out = []
    for start, end, body in cues:
        start, end = start * ratio + shift, end * ratio + shift
        if end > 0:
            out.append((max(0.0, start), end, body))
    return out


def _stamp(value):
    ms = int(round(value * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return '%02d:%02d:%02d,%03d' % (h, m, s, ms)


def to_srt(cues):
    blocks = []
    for index, (start, end, body) in enumerate(cues, 1):
        clean = html.unescape(TAGS.sub(lambda m: m.group(0) if m.group(0).lower() in ('<i>', '</i>', '<b>', '</b>') else '', body))
        blocks.append('%d\n%s --> %s\n%s\n' % (index, _stamp(start), _stamp(end), clean))
    return '\n'.join(blocks)


def describe(ratio, shift):
    parts = ['%+.1f s' % shift]
    if abs(ratio - 1) > 1e-4:
        for a, b in ((25, 23.976), (23.976, 25), (24, 23.976), (23.976, 24), (25, 24), (24, 25)):
            if abs(ratio - a / b) < 1e-4:
                parts.append('%g→%g fps' % (a, b))
                break
    return ' · '.join(parts)


TOKENS = re.compile(r'[a-z0-9]+')
QUIET = {'mkv', 'mp4', 'avi', 'srt', 'sub', 'subs', 'eng', 'english', 'x264', 'x265', 'h264', 'h265', 'hevc',
         'aac', 'ac3', 'ddp5', 'dd5', 'the', 'and', 'www', 'com', 'org'}


def release_tokens(text):
    return {t for t in TOKENS.findall(str(text or '').lower()) if len(t) > 1 and t not in QUIET}


def similarity(a, b):
    a, b = release_tokens(a), release_tokens(b)
    return len(a & b) / float(len(a | b)) if a and b else 0.0
