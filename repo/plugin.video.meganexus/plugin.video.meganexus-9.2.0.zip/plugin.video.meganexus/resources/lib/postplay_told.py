# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Where the film just stopped was saved - for the screen after it (9.1.4, script.meganexus meganexus_ui/postplay.py).

"da se pojave animacije kao da se pojave plocice dodano u trakt pa trakt plocica simkl itd" - a place's picture comes
onto that screen when the place has said it took the stop: the service writes Window(Home) meganexus.postplay.done.<place>
and the screen's skin shows it (nothing asks or waits for it). Only a place that answered: a stop Trakt was not sent
(under 1 %), one waiting in an outbox or one that failed shows nothing.
"""
import threading
import time

import xbmcgui

DONE = 'meganexus.postplay.done.'
STOPPED = 'meganexus.postplay.stopped'    # when the last film stopped (time.time()) - a sync begun after it carried it
PLACES = ('nuvio', 'trakt', 'simkl', 'mdblist', 'wetrakr')
FRESH = 600.0                              # s after the stop a place's answer still belongs to it
_LOCK = threading.Lock()


def stopped(now=None):
    """A film stopped: the places it is saved to are told now - what they said of the last one goes."""
    home = xbmcgui.Window(10000)
    with _LOCK:
        for place in PLACES:
            home.clearProperty(DONE + place)
        home.setProperty(STOPPED, repr(now if now is not None else time.time()))


def since():
    """When the last film stopped (0.0: none, or too long ago to show)."""
    try:
        at = float(xbmcgui.Window(10000).getProperty(STOPPED) or 0)
    except ValueError:
        return 0.0
    return at if time.time() - at <= FRESH else 0.0


def took(place):
    """``place`` took the last stop."""
    if place in PLACES and since():
        with _LOCK:
            xbmcgui.Window(10000).setProperty(DONE + place, '1')


def answered(reporter, answer):
    """A tracker's answer to the stop (playback_watch._send_report): something sent back is a yes."""
    place = getattr(reporter, 'PLACE', '')
    if place and answer:
        took(place)


def synced(started, report):
    """The account sync (cloud_sync): Nuvio's progress went across in a sync begun after the stop."""
    at = since()
    if not at or started < at:
        return
    for row in report or []:
        if row.get('service') == 'nuvio' and ((row.get('sections') or {}).get('progress') or {}).get('ok'):
            took('nuvio')
