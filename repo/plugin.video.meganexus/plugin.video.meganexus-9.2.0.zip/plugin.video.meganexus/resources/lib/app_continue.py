# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18: what a HUB app plays continues in that app alone - "filmovi serije i kanali nesmiju ici u meganexus
continue watching nego samo u IPTV tako i plex i emby i jellyfin moraju imati samo svoj continue watching dok se sa
tracking servisima svi povezuju".

A playback's ``meganexus_app`` (MegaIPTV's films and episodes: hub.iptv_vod_start; a Plex / Jellyfin / Emby server's own
title: hub.plex_start, hub.mediabrowser_play) keeps its place here - per app, its newest LIMIT - and never in MegaNexus'
Continue Watching (continue_local and progress_db: Home's row and what Nuvio syncs; playback_watch). The tracking
services still get it (playback_watch's reporters, Simkl's outbox), and a title last played in an app stays out of
Home's row while what they bring back of it is not newer than a play in MegaNexus (home_data.continue_shelf). MegaIPTV
shows its own (meganexus_ui/megaiptv.py); a server app's is its server's own Continue Watching (its progress is
reported there).
"""
import json

from . import continue_local

LIMIT = 50
PLAY = 'meganexus_app_play'     # the plugin path that plays the title again in its app (MegaIPTV's)
IPTV_IDS = 'iptv:'              # MegaIPTV's own titles' ids (hub.iptv_vod_start) - never MegaNexus' titles


def _connect():
    conn = continue_local.connect()
    conn.execute('CREATE TABLE IF NOT EXISTS meganexus_app_continue (app TEXT NOT NULL, identity TEXT NOT NULL, '
                 'updated REAL NOT NULL, payload TEXT NOT NULL, PRIMARY KEY (app, identity))')
    return conn


def identity(ctx):
    """One entry for each film and each episode (an IPTV episode is a title of its own on its server)."""
    return '%s|%s|%s' % (continue_local.identity(ctx), ctx.get('season') or 0, ctx.get('episode') or 0)


def save(ctx, position, duration, finished=False):
    """``ctx``'s place in its app (seconds)."""
    app = ctx.get('meganexus_app')
    if not app or not ctx.get('canonical_id') or position < 1:
        return
    value = continue_local.entry(ctx, position, duration, finished)
    value.update(app=app, **{PLAY: ctx.get(PLAY) or ''})
    conn = _connect()
    try:
        conn.execute('INSERT OR REPLACE INTO meganexus_app_continue VALUES (?, ?, ?, ?)',
                     (app, identity(ctx), value['updated_at'], json.dumps(value)))
        conn.execute('DELETE FROM meganexus_app_continue WHERE app=? AND identity NOT IN '
                     '(SELECT identity FROM meganexus_app_continue WHERE app=? ORDER BY updated DESC LIMIT ?)', (app, app, LIMIT))
        conn.commit()
    finally:
        conn.close()


def recent(app=None):
    """The newest first - of ``app``, or of every app."""
    conn = _connect()
    try:
        if app:
            rows = conn.execute('SELECT payload FROM meganexus_app_continue WHERE app=? ORDER BY updated DESC', (app,))
        else:
            rows = conn.execute('SELECT payload FROM meganexus_app_continue ORDER BY updated DESC')
        return [json.loads(r[0]) for r in rows.fetchall()]
    finally:
        conn.close()


def in_apps(local):
    """For Home's Continue Watching (home_data.continue_shelf): a test ``(row, its title_keys) -> True`` for a title that
    is an app's - MegaIPTV's own id, or played last in an app (later than in MegaNexus: ``local``, continue_local's
    journal), whatever a tracking service brings back of it."""
    from .meganexus import progress_db
    from .progress_model import timestamp

    def latest(rows):
        out = {}
        for row in rows:
            for key in progress_db.title_keys(row):
                out[key] = max(out.get(key, 0), timestamp(row.get('updated_at')))
        return out
    apps, here = latest(recent()), latest(local)

    def test(row, keys):
        if str(row.get('canonical_id') or '').startswith(IPTV_IDS):
            return True
        return max([apps.get(k, 0) for k in keys] or [0]) > max([here.get(k, 0) for k in keys] or [0])
    return test
