# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Plain Kodi directory output for long add-on catalogs; the skin owns rendering."""
from . import backend_api


def render(params):
    from . import hub as p
    from .meganexus.addon_wire import fetch_catalog
    # 9.0.6: the add-on whose catalog it is (BingeCat's showed "Enable this catalog in AIOMetadata")
    from .meganexus import addon_registry
    from . import metadata_providers
    source=(addon_registry.get_provider(params['provider_id']) if params.get('provider_id') else None) \
        or metadata_providers.first() or backend_api.provider('metadata')
    if not source:
        p.add_item('Connect a metadata add-on in HUB Settings',p.build_url(action='first_run_wizard'),is_folder=False)
        return p.end_dir(content='files',cache=False)
    mt=params.get('media_type') or 'movie';cid=params.get('catalog_id') or ''
    catalog=next((c for c in (source.get('manifest') or {}).get('catalogs') or [] if c.get('id')==cid and c.get('type')==mt),None)
    if not catalog:
        p.add_item('Enable this catalog in %s'%(source.get('name') or 'its add-on'),p.build_url(action='first_run_wizard'),is_folder=False)
        return p.end_dir(content='files',cache=False)
    try:skip=max(0,int(params.get('page') or 0))
    except ValueError:skip=0
    extra={k:params[k] for k in ('genre','search','year') if params.get(k) and params[k]!='None'}
    if skip:extra['skip']=skip
    data=fetch_catalog(source,mt,cid,extra=extra,timeout_override=12)
    raw=(data or {}).get('metas') or []
    for meta in raw:
        if not isinstance(meta,dict) or not meta.get('id'):continue
        title=meta.get('name') or meta.get('title') or meta['id']
        p.add_item(title,p.build_url(action='play_item',media_type=mt,canonical_id=meta['id'],title=title),
                   is_folder=False,info=p._info_of(meta),art={'poster':meta.get('poster') or '',
                   'thumb':meta.get('poster') or '', 'fanart':meta.get('background') or ''},properties={'IsPlayable':'false'})
    supports_skip=any((e.get('name') if isinstance(e,dict) else e)=='skip' for e in catalog.get('extra') or [])
    if raw and supports_skip:
        query=dict(params,action='catalog_all',page=str(skip+len(raw)),provider_id=source['id'])
        p.add_item('Next page',p.build_url(**query))
    if not raw:p.add_item('No more titles','',is_folder=False)
    return p.end_dir(content='tvshows' if mt=='series' else 'movies',cache=False)
