# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The subtitles' font and size - MegaNexus' own fonts in them too (idea 2026-11-20: "mozes ove fontove sto smo mi
napravili i velicinu titlova").

Kodi draws subtitles itself (libass), with its own settings (Player > Language > Subtitles): subtitles.fontname - a
family of the fonts it finds when it starts in special://xbmc/media/Fonts and special://home/media/Fonts (the user's) -
and subtitles.fontsize (12-74, 42 its default). The skin's fonts are the skin's only: MegaNexus puts its families
(SIL Open Font License) into the user's fonts folder - the Medium for subtitles as they are, the Bold for Kodi's Bold
style - and sets Kodi's settings over JSON-RPC (kept on disk at once: kodi_keep). A family put in shows in Kodi's list
after Kodi starts again.
"""
import json
import os
import shutil

import xbmc
import xbmcvfs

DEFAULT = 'DEFAULT'                      # Kodi's own (DejaVu Sans)
FONTS = (('Barlow', 'Barlow'), ('Poppins', 'Poppins'), ('Fira Sans', 'FiraSans'))   # (Kodi's family name, the skin's folder)
WEIGHTS = ('Medium', 'Bold')
SIZES = (('Small', 34), ('Medium', 42), ('Large', 52), ('Extra large', 62))           # Kodi's 12-74; 42: its own
SKIN_FONTS = 'special://home/addons/skin.meganexus/fonts'
USER_FONTS = 'special://home/media/Fonts'
WANTED = 'meganexus_subtitle_font'      # a family chosen before Kodi listed it: set as Kodi starts again (apply_wanted)


def _rpc(method, params):
    answer = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in answer:
        raise RuntimeError(str(answer['error'].get('message') or answer['error']))
    return answer.get('result')


def files(folder):
    """The font files of a family: (the skin's, the user's fonts folder's) paths."""
    source, target = xbmcvfs.translatePath(SKIN_FONTS), xbmcvfs.translatePath(USER_FONTS)
    return [(os.path.join(source, folder, '%s-%s.ttf' % (folder, weight)), os.path.join(target, '%s-%s.ttf' % (folder, weight)))
            for weight in WEIGHTS]


def install():
    """Every family's files in the user's fonts folder (the ones missing or changed) - the names copied."""
    copied = []
    for _, folder in FONTS:
        for source, target in files(folder):
            try:
                if not os.path.isfile(source):
                    continue
                if os.path.isfile(target) and os.path.getsize(target) == os.path.getsize(source):
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                shutil.copyfile(source, target + '.tmp')
                os.replace(target + '.tmp', target)
                copied.append(os.path.basename(target))
            except OSError as exc:
                xbmc.log('[MegaNexus] Subtitle font not put in: %s' % exc, xbmc.LOGWARNING)
    return copied


def offered():
    """The families Kodi's subtitles offer now (found when it started)."""
    try:
        settings = _rpc('Settings.GetSettings', {'level': 'expert', 'filter': {'section': 'player', 'category': 'subtitles'}})
        found = next((s for s in settings.get('settings') or [] if s.get('id') == 'subtitles.fontname'), {})
        return [o.get('value') for o in found.get('options') or []]
    except Exception:
        return [DEFAULT]


def font_now():
    try:
        return _rpc('Settings.GetSettingValue', {'setting': 'subtitles.fontname'}).get('value') or DEFAULT
    except Exception:
        return DEFAULT


def size_now():
    try:
        return int(_rpc('Settings.GetSettingValue', {'setting': 'subtitles.fontsize'}).get('value') or 42)
    except Exception:
        return 42


def font_name(value):
    return 'Kodi\'s own' if value in ('', DEFAULT) else value


def size_name(value):
    return next((name for name, size in SIZES if size == value), str(value))


def set_font(family):
    """Kodi's subtitles in ``family`` (DEFAULT: Kodi's own) - 'set', or 'after restart' (put in and remembered: Kodi lists
    it once it starts again, and apply_wanted sets it then)."""
    from .kodi_keep import keep
    from .meganexus.paths import writer
    if family != DEFAULT:
        install()
        if family not in offered():
            writer().setSetting(WANTED, family)
            return 'after restart'
    writer().setSetting(WANTED, '')
    _rpc('Settings.SetSettingValue', {'setting': 'subtitles.fontname', 'value': family})
    keep()
    return 'set'


def apply_wanted():
    """At the service's start: the families in the user's fonts folder, and a family chosen before Kodi listed it set
    now that it does. True when it was set."""
    from .meganexus.paths import addon
    install()
    wanted = addon().getSetting(WANTED)
    if not wanted or wanted not in offered():
        return False
    return set_font(wanted) == 'set'


def set_size(size):
    from .kodi_keep import keep
    _rpc('Settings.SetSettingValue', {'setting': 'subtitles.fontsize', 'value': int(size)})
    keep()
