# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, which of the person's IPTV channels shows a match ("iptv kanali koji nude stream ... sve dinamicno",
"kombinacije tih kanala kad imamo iptv provajdera").

Read from the guide of the person's own lists each time - what is on now and next on every channel, as Kodi's PVR has
it - never a list of channels of ours. A programme is a match's when it is on at the match's time and its title names
both sides (a side: its name, its short name, or the word that is most its own - "Arsenal", "Brighton"), or one side and
the league; an event of many (a race, a fight night): its name or its league's. A channel whose name carries one of the
match's own broadcasters (ESPN lists them) counts a little more. Nothing of Kodi in it (sport_scores' matches; the
channels as Kodi's PVR.GetChannels gives them, their programmes' times as datetimes)."""
import functools
import re
import unicodedata

FILLER = {'fc', 'cf', 'sc', 'ac', 'afc', 'fk', 'nk', 'sk', 'cd', 'club', 'de', 'the', 'and', 'vs', 'v', 'at', 'live',
          'uzivo', 'direct', 'directo', 'diretta', 'en', 'vivo'}
COMMON = {'city', 'united', 'real', 'sporting', 'athletic', 'atletico', 'union', 'town', 'rovers', 'county', 'national',
          'team', 'women', 'woman', 'football', 'basketball', 'hockey', 'stars'}   # in many sides' names: no side by them alone
BEFORE_MIN, AFTER_MIN = 30, 15     # a programme starting up to this long before / after the match is its
LONGEST = 3 * 3600                 # a match is not on longer than this (its programme must still be on at its start)
GOOD = 2                           # the least a programme's likeness must be to be the match's


def words(text):
    """``text`` as plain lowercase words (no accents: "Šibenik" is "sibenik") - a new list each time (callers compare
    slices of it with lists)."""
    return list(_words(text or ''))


@functools.lru_cache(maxsize=8192)
def _words(text):
    # kept by the text: MegaSport's links ask the same names and titles hundreds of thousands of times (442,053 for 358
    # matches) - the Cube's Python spent seconds on it at every board ("loading the matches ... traje vjecnost")
    text = unicodedata.normalize('NFKD', text)
    text = ''.join(c for c in text if not unicodedata.combining(c)).lower()
    return tuple(w for w in re.split(r'[^a-z0-9]+', text) if w)


def _own(side):
    """A side's names as word runs - its whole name, its short one and the other names it has (another language's: the
    caller's ``also``), without the fillers - and its own words (its city, its name: "detroit", "pistons")."""
    runs, own = _side_words(side.get('name'), side.get('short'), tuple(side.get('also') or ()))
    return [list(run) for run in runs], set(own)


@functools.lru_cache(maxsize=4096)
def _side_words(name, short, also):
    runs = []
    for one in (name, short) + also:
        run = tuple(w for w in _words(one or '') if w not in FILLER)
        if run and run not in runs:
            runs.append(run)
    return tuple(runs), frozenset(w for run in runs for w in run if len(w) >= 4 and not w.isdigit() and w not in COMMON)


def _has_run(text_words, run):
    n = len(run)
    return any(text_words[i:i + n] == run for i in range(len(text_words) - n + 1))


def side_named(side, text_words):
    runs, own = _own(side)
    return any(_has_run(text_words, run) for run in runs) or any(w in text_words for w in own)


def likeness(match, title, channel_name=''):
    """How much ``title`` (a programme's) is ``match``'s: 0 none, 2 one side and its league, 3 both sides; +1 when the
    channel carries one of the match's broadcasters."""
    said = words(title)
    if not said:
        return 0
    league = [w for w in words(match.get('league_name')) if w not in FILLER]
    league_named = bool(league) and (_has_run(said, league) or (len(league) > 1 and sum(w in said for w in league if len(w) >= 4) >= 2))
    if match.get('pair'):
        named = sum(side_named(side, said) for side in match.get('sides') or [])
        score = 3 if named >= 2 else (GOOD if named == 1 and league_named else 0)
    else:
        own = [w for w in words(match.get('name')) if w not in FILLER and len(w) >= 4]
        score = 3 if own and sum(w in said for w in own) >= min(2, len(own)) else (GOOD if league_named else 0)
    if score:
        channel = words(channel_name)
        if any(_has_run(channel, words(b)) for b in match.get('channels') or [] if words(b)):
            score += 1
    return score


def at_its_time(match, start, end):
    """The programme (``start`` - ``end``, datetimes) is on when the match is."""
    begins = match.get('start')
    if begins is None or start is None or end is None:
        return False
    return (start - begins).total_seconds() <= AFTER_MIN * 60 and (begins - start).total_seconds() <= LONGEST + BEFORE_MIN * 60 \
        and end > begins


def channels_for(match, programmes):
    """The channels showing ``match``, the likest first: [(likeness, channel, programme)] of ``programmes`` -
    [(channel, programme)], a programme {'title', 'start', 'end'}."""
    found = {}
    for channel, programme in programmes:
        if not at_its_time(match, programme.get('start'), programme.get('end')):
            continue
        score = likeness(match, programme.get('title') or '', channel.get('label') or '')
        key = channel.get('channelid')
        if score >= GOOD and score > found.get(key, (0,))[0]:
            found[key] = (score, channel, programme)
    return sorted(found.values(), key=lambda f: (-f[0], str(f[1].get('label') or '')))
