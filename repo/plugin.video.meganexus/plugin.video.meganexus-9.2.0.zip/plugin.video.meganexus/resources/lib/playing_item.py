# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A property of the item Kodi plays, read from Kodi once per playback (9.1.4).

xbmc.Player().getPlayingItem() copies the whole playing item (Kodi 21, interfaces/legacy/Player.cpp:
``new ListItem(std::make_shared<CFileItem>(...))`` - its video tag, cast, art) and Kodi keeps that copy while the
Python that asked lives: 12.7 KB a call on the Cube with a MegaNexus film. The film guard asked twice a second -
94 MB an hour of a film, Kodi's memory grew from 663 to 981 MB in three hours of "Odiseja", Home and the
collections were slow after it (the disk cache pushed out) and the kernel killed Kodi twice. The trailer, YouTube
and Sport previews asked on every pass of their screen's loop.

A playback is told apart by what is played (getPlayingFile() keeps nothing, a string), by a moment with nothing
playing and by Kodi's own word that one started or stopped (Player.OnPlay / OnAVStart / OnStop): the same clip
played again as a new preview is asked for again."""
import threading

KEEP = 8                   # answers remembered (the film, a preview over it, the next one)
STARTS = ('Player.OnPlay', 'Player.OnAVStart', 'Player.OnStop')
_KEPT = {}
_LOCK = threading.Lock()
_STATE = {'plays': 0, 'monitor': None}


def _listen():
    """Kodi's announcements of a playback starting or ending, in this interpreter (once)."""
    if _STATE['monitor'] is not None:
        return
    import xbmc

    class Plays(xbmc.Monitor):
        def onNotification(self, sender, method, data):
            if method in STARTS:
                started()
    _STATE['monitor'] = Plays()


def started():
    """A playback started or ended: every answer is asked for again."""
    with _LOCK:
        _STATE['plays'] += 1
        _KEPT.clear()


def prop(player, name):
    """The playing item's property ``name`` ('' when nothing plays or Kodi does not say), asked once a playback."""
    _listen()
    try:
        path = player.getPlayingFile()
    except Exception:
        # nothing plays: the next playback is asked for again even when Kodi's word of it does not reach this
        # interpreter (callbacks come only on the thread that made the monitor, while it waits in Kodi)
        if _KEPT:
            started()
        return ''
    with _LOCK:
        key = (_STATE['plays'], path, name)
        if key in _KEPT:
            return _KEPT[key]
    try:
        value = player.getPlayingItem().getProperty(name)
    except Exception:
        return ''                  # asked again next time
    with _LOCK:
        if key[0] == _STATE['plays']:
            _KEPT[key] = value
            while len(_KEPT) > KEEP:
                _KEPT.pop(next(iter(_KEPT)))
    return value
