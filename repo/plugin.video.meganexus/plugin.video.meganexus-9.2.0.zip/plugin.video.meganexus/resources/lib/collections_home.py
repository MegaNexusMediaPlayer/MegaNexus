# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Local collection presets mapped to the user's installed Stremio providers."""
import json
import os
import re

import xbmcaddon


def groups(include_hidden=False):
    """Collection groups; rows hidden in Settings > Collections > Home rows are
    left out of Home unless ``include_hidden``. 7.0.11: collections made only of
    sport catalogs live in the Sports screen, not on Home."""
    from .collection_profile import load
    if include_hidden:
        return load()
    shown = []
    for group in load():
        if group.get('hidden'):
            continue
        folders = [f for f in group.get('folders') or [] if not _sports_only(f)]
        if folders:
            shown.append(dict(group, folders=folders))
    return shown


def _sports_only(folder):
    from .sports import is_sports_source
    sources = [s for s in (folder or {}).get('sources') or [] if s.get('enabled') is not False]
    return bool(sources) and all(is_sports_source(s) for s in sources)


def find_collection(collection_id):
    from .collection_profile import folder
    found = folder(collection_id)   # 7.0.31: one collection, not a copy of all of them
    if found is not None:
        return found
    for group in groups(include_hidden=True):
        for folder in group['folders']:
            if folder['id'] == collection_id:
                return folder
    return None


def _norm(value):
    return re.sub(r'[^a-z0-9]', '', str(value or '').lower())


def active_sources(folder):
    """Sources switched ON in the collection editor (all sources by default);
    sport catalogs are shown in the Sports screen instead (7.0.11)."""
    from .sports import is_sports_source
    return [s for s in (folder or {}).get('sources') or [] if s.get('enabled') is not False and not is_sports_source(s)]


SERIES_TYPES = {'series', 'tv', 'show', 'shows', 'tvshow', 'tvshows'}
MOVIE_TYPES = {'movie', 'movies', 'film', 'films'}
# Catalog IDs too general to move to another add-on by their ID alone.
GENERIC_CATALOGS = {'top', 'popular', 'trending', 'year', 'imdbrating', 'new', 'featured', 'latest', 'search'}


def kind(media_type):
    """'movie' / 'series' / the type itself - like Nuvio's catalogTypeKey."""
    value = str(media_type or '').strip().lower()
    if value in SERIES_TYPES:
        return 'series'
    if value in MOVIE_TYPES:
        return 'movie'
    return value


def _find_catalog(manifest, source):
    """Nuvio's findCollectionCatalog: same ID (also the part before a comma)
    and the same type, aliases allowed (tv = series)."""
    wanted_id = str(source.get('catalogId') or '')
    wanted_type = str(source.get('type') or '')
    catalogs = [c for c in manifest.get('catalogs') or [] if isinstance(c, dict)]
    for cid in (wanted_id, wanted_id.split(',', 1)[0]):
        found = [c for c in catalogs if c.get('id') == cid]
        exact = next((c for c in found if c.get('type') == wanted_type), None)
        if exact:
            return exact
        alike = [c for c in found if kind(c.get('type')) == kind(wanted_type)]
        if len(alike) == 1:
            return alike[0]
    return None


def _family(value):
    return {w for w in re.split(r'[^a-z0-9]+', str(value or '').lower()) if len(w) > 2}


def matching_catalog(source, providers, selected=None):
    """Resolve a collection source to one installed add-on catalog.

    The manifest ID must match (the same ID written with different separators,
    e.g. ``aio-metadata``/``aiometadata``, counts as the same ID) and that add-on
    must publish this catalog ID and type. When the same add-on is installed
    more than once, the exported ``providerId`` wins, then an enabled metadata
    add-on, then the first configured install.

    6.0.36: collections shared by other people name *their* instance of an
    add-on (another host or configuration = another manifest ID). When no
    installed add-on has that ID, the one installed add-on that publishes the
    same catalog is used (several: the most similar name/ID, then an enabled
    metadata add-on). General catalog IDs ("top", "popular"...) only move to an
    add-on with a similar name. ``selected`` is retained for older callers.
    """
    addon = source.get('addonId') or ''
    if not source.get('catalogId'):
        return None
    exact, similar = [], []
    for provider in providers:
        manifest = provider.get('manifest') or {}
        mid = manifest.get('id') or ''
        if addon and mid == addon:
            bucket = exact
        elif addon and _norm(mid) and _norm(mid) == _norm(addon):
            bucket = similar
        else:
            continue
        catalog = _find_catalog(manifest, source)
        if catalog:
            bucket.append((provider, catalog))
    matches = exact or similar
    try:
        from .metadata_providers import entries
        switches = {p['id']: on for p, on in entries(providers)}
    except Exception:
        switches = {}
    if not matches:
        wanted_family = _family(addon)
        generic = _norm(str(source.get('catalogId') or '').split(',', 1)[0]) in GENERIC_CATALOGS
        for provider in providers:
            manifest = provider.get('manifest') or {}
            catalog = _find_catalog(manifest, source)
            if not catalog:
                continue
            overlap = len(wanted_family & (_family(manifest.get('id')) | _family(manifest.get('name')) | _family(provider.get('name'))))
            if generic and not overlap:
                continue
            matches.append((overlap, provider, catalog))
        if not matches:
            return None
        matches.sort(key=lambda m: (-m[0], not switches.get(m[1].get('id'))))
        return matches[0][1], matches[0][2]
    if len(matches) == 1:
        return matches[0]
    wanted = source.get('providerId')
    for match in matches:
        if wanted and match[0].get('id') == wanted:
            return match
    return next((m for m in matches if switches.get(m[0].get('id'))), matches[0])


def folder_shelf(folder, providers, media_type=None, title=None):
    from . import home_data as hd
    p = hd._api()
    jobs = []
    from .metadata_providers import entries
    switches={p['id']:on for p,on in entries(providers)}
    providers=[p for p in providers if switches.get(p['id'],True)]
    from .settings_snapshot import setting
    selected=setting('meganexus_metadata_provider')
    from . import collection_sources
    needs_key = False
    for source in active_sources(folder):
        if media_type and kind(source['type']) != media_type:
            continue
        if collection_sources.is_virtual(source):
            if collection_sources.usable(source):
                jobs.append(collection_sources.job(source))
            else:
                needs_key = True
            continue
        match = matching_catalog(source, providers, selected)
        if match:
            provider, catalog = match
            genre = source.get('genre')
            # "None" in the Nuvio export means no filter, not the literal genre.
            extra = dict(source.get('extra') or {})
            if genre and genre != 'None':extra['genre']=genre
            jobs.append((provider, catalog, extra))
    # 7.0.21: "Browse all" of a Movies or Series row lists only that kind.
    path = (p.build_url(action='meganexus_collection', collection_id=folder['id'], media_type=media_type) if media_type
            else p.build_url(action='meganexus_collection', collection_id=folder['id']))
    if not jobs and needs_key:
        return {'title': title or folder['title'], 'rows': [hd.placeholder(
            'Add your TMDb API key', 'This collection reads TMDB. Enter your free TMDb API key in HUB Settings > Add-ons.',
            p.build_url(action='setup_center'), folder=False)]}
    if not jobs:
        return {'title': title or folder['title'], 'rows': [hd.placeholder(
            'Connect collection catalogs', 'Validate this collection against your configured add-ons in Settings > Collections.',
            p.build_url(action='first_run_wizard'), folder=False)]}
    return {'title': title or folder['title'], 'path': path, 'collection_job': jobs,
            'rows': [hd.placeholder(' ', '', path)]}   # 7.0.42: no loading words on a card


def tile_settings():
    """Read artwork settings once per Home build instead of per collection group."""
    from .settings_snapshot import cached_addon
    addon = cached_addon()
    animated = addon.getSetting('meganexus_animated_art') == 'true'
    try:
        overrides = json.loads(addon.getSetting('meganexus_animation_map') or '{}')
    except ValueError:
        overrides = {}
    # 7.0.18: animations come from the collections themselves (their own
    # 'animation' link, e.g. imported from Nuvio) and the user's choices - no
    # bundled table tied to one collection set.
    return {'animated': animated, 'overrides': overrides if isinstance(overrides, dict) else {}}


def tiles(group, settings=None):
    from .home_data import placeholder
    rows = []
    # 7.0.42: the shape the collection's source gives (Nuvio tileShape / imageAspect,
    # collection_profile.shape_of); a row shows one shape - the one most of its cards
    # have. Nothing given (the built-in add-on's own collections): landscape title cards.
    from collections import Counter
    given=Counter(f.get('shape') for f in group['folders'] if not f.get('hidden') and f.get('shape'))
    shape=given.most_common(1)[0][0] if given else 'landscape'
    base = 'special://home/addons/script.meganexus'
    try:
        local = xbmcaddon.Addon('script.meganexus').getAddonInfo('path')
    except Exception:
        local = ''
    def art(value):
        if value.startswith(('http://','https://','special://')) or os.path.isabs(value):return value
        # 7.0.18: a bundled picture that is no longer shipped (the old preset's
        # covers) is not asked for - the card shows its title instead.
        if value and local and not os.path.exists(os.path.join(local,value)):return ''
        return os.path.join(base,value).replace('\\','/') if value else ''
    settings = settings or tile_settings()
    animated, overrides = settings['animated'], settings.get('overrides') or {}
    for folder in group['folders']:
        if folder.get('hidden'):continue
        animation=folder.get('animation') or ''
        if not animation:
            # 7.0.18: a GIF cover is the collection's animation (focused card);
            # with animations off it stays still, as the other covers.
            cover=str(folder.get('cover') or folder.get('backdrop') or '')
            if cover.lower().split('?',1)[0].endswith('.gif'):animation=cover
        row = placeholder(folder['title'], 'Browse movies and series in the %s collection.' % folder['title'])
        row.update(collection_id=folder['id'], shape=shape,
                   hide_title='1' if folder.get('hideTitle') else '',
                   poster=art(folder.get('cover') or ''),
                   fanart=art(folder.get('backdrop') or folder.get('cover') or ''),
                   clearlogo=art(folder.get('logo') or ''),   # 7.0.44: its name logo, else the name
                   animation=art(overrides.get(folder['id']) or animation or '') if animated else '')
        rows.append(row)
    # 7.0.18: the collection's own name, no renaming by id; 7.0.24: hidden on request.
    return {'title': '' if group.get('hideTitle') else group['title'],
            'shape': shape, 'rows': rows}


POSTER_GROUPS = 'meganexus_home_poster_groups'   # 9.0.9: the rows shown as poster rows, by group id


def poster_groups(addon=None):
    """9.0.9: the ids of the Home rows (groups of your collections) shown as poster rows ("Show as ·
    Poster rows"); the others are cards, as before."""
    try:
        if addon is None:
            from .settings_snapshot import cached_addon
            addon = cached_addon()
        value = addon.getSetting(POSTER_GROUPS)
    except Exception:
        value = ''
    return set(part for part in str(value or '').split(',') if part)


def show_as_posters(group_id, on, addon=None):
    """A Home row (group) as poster rows (``on``) or as cards."""
    if addon is None:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.meganexus')
    ids = poster_groups(addon)
    ids = (ids | {str(group_id)}) if on else (ids - {str(group_id)})
    addon.setSetting(POSTER_GROUPS, ','.join(sorted(ids)))


def home_rows():
    """Home's rows of your collections: each group a row of cards - 9.0.9: or, set so ("Show as · Poster
    rows", poster_groups), a poster row for each of its collections, as the "MegaNexus rows" layout
    shows every group (one user: "private collections on the homepage only show up as different
    buttons to click and at the bottom, not as a row"). With none set so, Home is what it was."""
    settings=tile_settings()
    posters=poster_groups()
    from .home_data import MAX_ROWS
    from .meganexus import addon_registry
    providers=None
    out=[]
    for group in groups():
        if group['id'] not in posters:
            # 9.0.8: each row knows its group - Home's Watchlist / Next episodes stand after a number of them
            row=dict(tiles(group,settings),home_group=group['id'])
            if row['rows']:out.append(row)
            continue
        if providers is None:providers=addon_registry.list_providers()
        for folder,mt,title in _poster_rows(group):
            # as catalog_rows: the first MAX_ROWS made whole, the later ones when their page is drawn
            out.append(dict(folder_shelf(folder,providers,mt,title),catalog_row=True,home_group=group['id'])
                       if len(out)<MAX_ROWS else
                       {'title':title,'lazy':(folder['id'],mt),'catalog_row':True,'rows':[],'home_group':group['id']})
    return out


LAYOUT_SETTING = 'meganexus_home_layout'
LAYOUTS = ('collections', 'rows', 'posters')
LAYOUT_LABELS = {'collections': 'MegaNexus collections · cards that open catalogs',
                 'rows': 'MegaNexus rows · posters right on Home',
                 'posters': 'MegaNexus posters · every film and series of your collections, once'}   # 7.0.48


def layout(addon=None):
    """Home layout (6.0.35, GitHub issue #9). MegaNexus collections stay the default."""
    try:
        if addon is None:
            from .settings_snapshot import cached_addon
            addon = cached_addon()
        value = addon.getSetting(LAYOUT_SETTING)
    except Exception:
        value = ''
    return value if value in LAYOUTS else 'collections'


def _poster_rows(group):
    """[(collection, media_type, row title)] of a group's poster rows: one row per collection shown on
    Home - its Movies and its Series as two when it has both. 7.0.24: "Show title" off for a collection
    hides its row title here too."""
    wanted = []
    for folder in group['folders']:
        if folder.get('hidden'):
            continue
        types = [mt for mt in ('movie', 'series') if any(kind(s.get('type')) == mt for s in active_sources(folder))]
        if len(types) == 2:
            wanted += [(folder, 'movie', folder['title'] + ' · Movies'), (folder, 'series', folder['title'] + ' · Series')]
        else:
            wanted.append((folder, types[0] if types else None, folder['title']))
    return [(f, mt, '' if f.get('hideTitle') else title) for f, mt, title in wanted]


def catalog_rows(full=False):
    """Nuvio-style Home: every visible catalog is a poster row - Movies and
    Series as two rows, one under the other. 7.0.48: all of them - Home draws a
    page at a time and the next one at the bottom (no "More catalogs" row). Only
    a first page is made whole; the later rows are their title and folder until
    their page is drawn (resolve) - Home opens as fast as with one page.
    ``full``: every row whole (the posters wall)."""
    from .meganexus import addon_registry
    providers = addon_registry.list_providers()
    wanted = [(f, mt, title, group['id']) for group in groups() for f, mt, title in _poster_rows(group)]
    from .home_data import MAX_ROWS
    # 9.0.8: home_group - Home's Watchlist / Next episodes rows stand after a number of the groups
    return [dict(folder_shelf(f, providers, mt, title), catalog_row=True, home_group=gid) if full or i < MAX_ROWS
            else {'title': title, 'lazy': (f['id'], mt), 'catalog_row': True, 'rows': [], 'home_group': gid}
            for i, (f, mt, title, gid) in enumerate(wanted)]


def resolve(shelf):
    """7.0.48: a row of a later Home page made whole when its page is drawn."""
    if not shelf.get('lazy'):
        return shelf
    from .meganexus import addon_registry
    folder_id, media_type = shelf['lazy']
    folder = find_collection(folder_id)
    if not folder:
        from .home_data import placeholder
        return {'title': shelf['title'], 'rows': [placeholder('Collection unavailable', 'Sync your collections again.')]}
    return dict(folder_shelf(folder, addon_registry.list_providers(), media_type, shelf['title']), catalog_row=True)


def collection_shelves(collection_id):
    from .meganexus import addon_registry
    from .home_data import placeholder, _api
    folder = find_collection(collection_id)
    if not folder:
        return [{'title': 'Collection unavailable', 'rows': [placeholder('Open Setup', 'Choose another collection.', _api().build_url(action='setup_center'))]}]
    providers = addon_registry.list_providers()
    types = [kind(s['type']) for s in active_sources(folder)]
    # One row per kind of catalog in the collection, whatever it is called:
    # Movies and Series first, then any other type an add-on uses (7.0.21:
    # e.g. 'anime' sources were left out before).
    kinds = [mt for mt in ('movie', 'series') if mt in types] + \
        [mt for mt in dict.fromkeys(types) if mt and mt not in ('movie', 'series')]
    labels = {'movie': 'Movies', 'series': 'Series'}
    return [folder_shelf(folder, providers, mt, folder['title'] + ' — ' + labels.get(mt, mt.replace('.', ' ').title()))
            for mt in kinds]


def render_native(collection_id, media_type=''):
    """Full catalog links preserve required genre filters and native pagination."""
    from .home_data import _api
    from .meganexus import addon_registry
    p = _api()
    folder = find_collection(collection_id)
    for source in active_sources(folder):
        if media_type and kind(source['type']) != media_type:
            continue
        match = matching_catalog(source, addon_registry.list_providers())
        if not match:
            continue
        provider, catalog = match
        label = '%s — %s' % (folder['title'], 'Movies' if source['type'] == 'movie' else 'Series')
        genre = source.get('genre') or ''
        p.add_item(label, p.build_url(action='catalog_all', provider_id=provider['id'], media_type=source['type'],
                   catalog_id=catalog['id'], genre='' if genre == 'None' else genre, label=label))
    p.end_dir()
