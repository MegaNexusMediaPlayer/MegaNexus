# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.4: the HUB's Plex, Jellyfin and Emby apps - each its own Home (script.meganexus meganexus_ui/server_app.py),
no longer rows in MegaNexus' Home ("od sad oni ne idu u meganexus nego svaka u svoj dio").

Their rows are the ones the server itself gives, in its order:

* Plex: its own home hubs (/hubs - Continue Watching, Recently Added Movies, ...), as Plex's apps show them;
* Jellyfin and Emby: Continue Watching (Resume), Next Up and each library's Latest, as their apps show them;

then every library as a row, newest first, that goes on as the cursor nears its end (``cards`` with ``start``).
The cards are MegaNexus' own (media_servers.plex_card / mediabrowser_card): the title page for a film or series its
ids tell, the server plays the rest. No network here but in ``offered`` and ``cards`` (the window's workers).
"""
import time

from . import media_servers

PAGE = 40
HUBS_LIFE = 60          # s a Plex /hubs answer serves the rows drawn from it
PLEX_SKIPPED = ('artist', 'album', 'track', 'photo', 'clip', 'playlist')
SHOWN = ('movie', 'show', 'episode')
_HUBS = {}              # Plex server id -> (when, [hub]) - each hub with its items


def _servers(kind):
    if kind == media_servers.PLEX:
        from . import plex
        return plex.servers() or []
    from . import mediabrowser
    return mediabrowser.servers(kind) or []


def server_of(kind, server_id):
    return next((s for s in _servers(kind) if str(s.get('id') or '') == str(server_id)), None)


def _libraries(kind, server):
    if kind == media_servers.PLEX:
        from . import plex
        found = plex.libraries(server)
    else:
        from . import mediabrowser
        found = mediabrowser.libraries(server)
    return [lib for lib in found if lib.get('type') in ('movie', 'show')]


def _plex_hubs(server, force=False):
    """[{'id', 'title', 'items'}] of a Plex server's home hubs (kept HUBS_LIFE)."""
    sid = str(server.get('id') or '')
    kept = _HUBS.get(sid)
    if not force and kept and time.monotonic() - kept[0] < HUBS_LIFE:
        return kept[1]
    from .plex import items, server_list
    root, base = server_list.ask(server, '/hubs', {'count': PAGE})
    hubs = []
    for node in root.findall('./Hub'):
        if str(node.attrib.get('type') or '').lower() in PLEX_SKIPPED:
            continue
        found = items.rows_of(node, server, base, SHOWN)
        if found:
            hubs.append({'id': str(node.attrib.get('hubIdentifier') or node.attrib.get('key') or len(hubs)),
                         'title': node.attrib.get('title') or 'Plex', 'items': found})
    _HUBS[sid] = (time.monotonic(), hubs)
    return hubs


def offered(kind):
    """Every row the app can show on its Home, in the server's order: [(row id, title, job)]. A server that does not
    answer adds none (the others still do)."""
    out = []
    every = _servers(kind)
    for server in every:
        sid = str(server.get('id') or '')
        prefix = (str(server.get('name') or '') + ' · ') if len(every) > 1 else ''
        try:
            if kind == media_servers.PLEX:
                out += [('hub:%s:%s' % (sid, hub['id']), prefix + hub['title'], ('hub', sid, hub['id']))
                        for hub in _plex_hubs(server, force=True)]
            libraries = _libraries(kind, server)
            if kind != media_servers.PLEX:
                out += [('continue:%s' % sid, prefix + 'Continue Watching', ('continue', sid)),
                        ('nextup:%s' % sid, prefix + 'Next Up', ('nextup', sid))]
                out += [('latest:%s:%s' % (sid, lib['key']), prefix + 'Latest · ' + lib['title'], ('latest', sid, lib['key']))
                        for lib in libraries]
            out += [('library:%s:%s' % (sid, lib['key']), prefix + lib['title'], ('library', sid, lib['key'], lib['type'], 'added'))
                    for lib in libraries]
        except Exception:
            continue
    return out


def libraries_of(kind):
    """[(server id, library key, type, title)] of every movie and series library (the app's Libraries)."""
    out = []
    every = _servers(kind)
    for server in every:
        prefix = (str(server.get('name') or '') + ' · ') if len(every) > 1 else ''
        try:
            out += [(str(server.get('id') or ''), lib['key'], lib['type'], prefix + lib['title']) for lib in _libraries(kind, server)]
        except Exception:
            continue
    return out


def library_rows(server_id, key, kind_of_library, title):
    """One library's own view: newest first, A to Z, not watched yet."""
    return [('%s · Recently added' % title, ('library', server_id, key, kind_of_library, 'added')),
            ('%s · A to Z' % title, ('library', server_id, key, kind_of_library, 'title')),
            ('%s · Not watched' % title, ('library', server_id, key, kind_of_library, 'unwatched'))]


def _card(kind, server, item):
    return media_servers.plex_card(item) if kind == media_servers.PLEX else media_servers.mediabrowser_card(kind, server, item)


def cards(kind, job, start=0, size=PAGE, unwatched=False):
    """(cards, how many the row has in all) of one row from ``start`` - ``unwatched`` (the app's filter) keeps a
    library row to what is not watched yet."""
    if job[0] == 'search':
        return search(kind, job[1]), 0
    server = server_of(kind, job[1])
    if server is None:
        return [], 0
    what = job[0]
    if kind == media_servers.PLEX:
        from . import plex
        if what == 'hub':
            hub = next((h for h in _plex_hubs(server) if h['id'] == job[2]), None)
            found = (hub or {}).get('items') or []
            return [_card(kind, server, item) for item in found[start:start + size]], len(found)
        if what == 'library':
            order = job[4]
            found, total = plex.children(server, '/library/sections/%s/all' % job[2], start, size,
                                         sort='titleSort' if order == 'title' else 'addedAt:desc',
                                         unwatched=unwatched or order == 'unwatched')
            return [_card(kind, server, item) for item in found], total
        return [], 0
    from . import mediabrowser
    if what == 'continue':
        found, total = mediabrowser.resume(server, start, size)
    elif what == 'nextup':
        found = mediabrowser.next_up(server, size) if not start else []
        total = len(found)
    elif what == 'latest':
        found = mediabrowser.latest(server, size, parent_id=job[2]) if not start else []
        total = len(found)
    elif what == 'library':
        order = job[4]
        found, total = mediabrowser.children(server, job[2], start, size,
                                             sort='SortName' if order == 'title' else 'DateCreated:desc',
                                             include_types='Series' if job[3] == 'show' else 'Movie', recursive=True,
                                             unplayed=unwatched or order == 'unwatched')
    else:
        return [], 0
    return [_card(kind, server, item) for item in found], total


def search(kind, query, limit=PAGE):
    """The app's search: films and series of every server of the kind, in the server list's order."""
    query = str(query or '').strip()
    if not query:
        return []
    if kind == media_servers.PLEX:
        from . import plex
        return [media_servers.plex_card(item) for item in plex.search_all(query, limit_per_server=limit)
                if item.get('media_type') in ('movie', 'show')]
    from . import mediabrowser
    out = []
    for server in _servers(kind):
        try:
            out += [_card(kind, server, item) for item in mediabrowser.server_find(server, query, limit=limit)
                    if item.get('media_type') in ('movie', 'show')]
        except Exception:
            continue
    return out


def forget():
    _HUBS.clear()
