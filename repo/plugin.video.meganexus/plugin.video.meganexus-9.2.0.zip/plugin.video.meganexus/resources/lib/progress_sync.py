# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Lightweight Continue Watching cadence, independent of idle-only library sync."""
import time


def retry_delay(error, failures):
    try:
        delay = float((getattr(error, 'headers', None) or {}).get('Retry-After') or 0)
    except (TypeError, ValueError):
        delay = 0
    return min(3600, max(delay, min(900, 30 * (2 ** min(failures, 5)))))


def playing_video():
    try:
        import xbmc
        return bool(xbmc.Player().isPlayingVideo())
    except Exception:
        return False


LIBRARY_DIRTY = 'meganexus.library_dirty'   # 7.0.44: set by favorites_store on every change
LIBRARY_EVERY = 300                         # seconds between pulls of Nuvio's Library


class Scheduler:
    def __init__(self, window, clock=time.monotonic, playing=playing_video, stopped=lambda: False):
        # 9.0.7: stopped - Kodi is closing or replacing MegaNexus: the round ends between its parts (one
        # round went on through Nuvio, the library and Trakt after "Stopping all", and Kodi killed the
        # service after 5 s while the interface froze - the Cube, 2026-11-03)
        self.window, self.clock, self.playing, self.stopped = window, clock, playing, stopped
        self.next_nuvio = self.next_simkl = self.next_flush = 0.0
        self.last_nuvio = None      # 9.1.4: when the last progress round went to Nuvio
        self.next_trakt = self.next_trakt_flush = 0.0
        self.nuvio_failures = self.simkl_failures = self.trakt_failures = 0
        self.dirty_since = None
        # 7.0.44: the Library (Nuvio's watchlist) - a change here goes out a few seconds
        # later, Nuvio's changes come every LIBRARY_EVERY (it waited for the idle-only
        # sync, 30 minutes, and its "changed" mark was cleared by the progress sync)
        self.next_library = 0.0
        self.library_failures = 0
        self.last_request = ''
        self.account = ''
        self.last_scope = None

    def step(self, sync, simkl, settings, cycle_lock):
        from . import nuvio_progress
        now = self.clock()
        try:
            interval = max(30, min(300, float(settings.getSetting('nuvio_progress_interval') or 60)))
        except (TypeError, ValueError):
            interval = 60
        account = nuvio_progress.scope()
        if account != self.account:
            self.account = account
            self.next_nuvio = 0
            self.nuvio_failures = 0
        request = self.window.getProperty('meganexus.progress.pull_requested')
        if request != self.last_request:
            self.last_request = request
            # Focus/return requests may advance the ordinary schedule, never backoff.
            if not self.nuvio_failures:
                self.next_nuvio = min(self.next_nuvio, now)
            if not self.simkl_failures:
                self.next_simkl = min(self.next_simkl, now)
        dirty = self.window.getProperty('meganexus.sync_dirty')
        if dirty and self.dirty_since is None:
            self.dirty_since = now
        elif not dirty:
            self.dirty_since = None
        dirty_due = bool(dirty and self.dirty_since is not None and now-self.dirty_since >= 5)
        # 9.1.4: a playing film saves its place every 15 s, and each save sent Nuvio a round 5 s later - about 6 %
        # of one of the Cube's cores while it played. While a film plays a change waits for the interval since the
        # last round; stopped or ended, it goes as before.
        if dirty_due and self.last_nuvio is not None and now - self.last_nuvio < interval and self.playing():
            dirty_due = False
        due_nuvio = now >= self.next_nuvio or (dirty_due and not self.nuvio_failures)
        if not cycle_lock.acquire(False):
            return
        try:
            if simkl.enabled() and simkl.authorized() and now >= self.next_flush:
                try:
                    simkl.flush_progress()
                except Exception:
                    pass  # Durable outbox is retained; its own backoff governs retries.
                self.next_flush = self.clock() + 10
            if self.stopped():
                return
            allowed = (account and 'nuvio' in sync.active_targets() and
                       sync._cloud_sections('nuvio').get('progress') and
                       settings.getSetting('cloud_sync_interval_min') != '0')
            if allowed and due_nuvio:
                try:
                    result = sync.sync_round(targets=['nuvio'], sections={
                        'progress': True, 'addons': False, 'collections': False, 'library': False})
                    if not result or not result.get('ok'):
                        raise RuntimeError('Progress sync not acknowledged')
                    self.nuvio_failures = 0
                    self.last_nuvio = now
                    self.next_nuvio = self.clock() + interval
                    if self.window.getProperty('meganexus.sync_dirty') == dirty:
                        self.window.clearProperty('meganexus.sync_dirty')
                        self.dirty_since = None
                    # Bounded batches continue without discarding the rest of the queue.
                    if nuvio_progress.pending(limit=1):
                        self.next_nuvio = min(self.next_nuvio, self.clock()+10)
                except Exception as error:
                    self.nuvio_failures += 1
                    self.next_nuvio = self.clock() + retry_delay(error, self.nuvio_failures-1)
            if self.stopped():
                return
            library_mark = self.window.getProperty(LIBRARY_DIRTY)
            library_on = account and 'nuvio' in sync.active_targets() and sync._cloud_sections('nuvio').get('library')
            library_due = now >= self.next_library or (library_mark and not self.library_failures)
            if library_on and library_due and not self.playing():
                try:
                    result = sync.sync_round(targets=['nuvio'], sections={
                        'progress': False, 'addons': False, 'collections': False, 'library': True})
                    if not result or not result.get('ok'):
                        raise RuntimeError('Library sync not acknowledged')
                    self.library_failures = 0
                    self.next_library = self.clock() + LIBRARY_EVERY
                    if self.window.getProperty(LIBRARY_DIRTY) == library_mark:
                        self.window.clearProperty(LIBRARY_DIRTY)
                except Exception as error:
                    self.library_failures += 1
                    self.next_library = self.clock() + retry_delay(error, self.library_failures-1)
            # 6.0.39: watched lists are not downloaded while a video plays
            # (small boxes stuttered); they catch up right after.
            if self.stopped():
                return
            busy = self.playing()
            if not busy and simkl.enabled() and simkl.authorized() and now >= self.next_simkl:
                try:
                    simkl.sync_playback_progress()
                    from . import simkl_watched
                    simkl_watched.refresh(max_age=max(120, interval))
                    self.simkl_failures = 0
                    self.next_simkl = self.clock() + interval
                except Exception as error:
                    self.simkl_failures += 1
                    self.next_simkl = self.clock() + retry_delay(error, self.simkl_failures-1)
            if self.stopped():
                return
            self._trakt(busy, interval)
            if self.stopped():
                return
            self._mdblist(busy, interval)
            if self.stopped():
                return
            self._wetrakr(busy, interval)
        finally:
            cycle_lock.release()

    def _wetrakr(self, busy, interval):
        """9.1.4: WeTrakr's watched list kept up to date here, not by the screens' paint (simkl_watched):
        watched_items() asks /sync/last_activities at most every 3 hours and pulls the list only when it moved."""
        from . import wetrakr_api
        if busy or self.clock() < getattr(self, 'next_wetrakr', 0.0) or not wetrakr_api.authorized():
            return
        self.next_wetrakr = self.clock() + max(300, interval)
        try:
            wetrakr_api.watched_items()
        except Exception:
            pass   # what is kept stays; asked again at the next turn

    def _mdblist(self, busy, interval):
        """MDBList watched marks come in (7.0.12); playback goes out as scrobbles."""
        from . import mdblist_tracking
        if busy or not mdblist_tracking.enabled() or self.clock() < getattr(self, 'next_mdblist', 0.0):
            return
        try:
            mdblist_tracking.refresh(max_age=max(300, interval))
            self.mdblist_failures = 0
            self.next_mdblist = self.clock() + max(300, interval)
        except Exception as error:
            self.mdblist_failures = getattr(self, 'mdblist_failures', 0) + 1
            self.next_mdblist = self.clock() + retry_delay(error, self.mdblist_failures - 1)


    def _trakt(self, busy, interval):
        """Trakt: queued watches go out, watched marks come in (6.0.39)."""
        from . import trakt_api
        if not trakt_api.authorized():
            return
        now = self.clock()
        if now >= self.next_trakt_flush:
            try:
                trakt_api.flush_outbox()
            except Exception:
                pass   # the outbox keeps them
            self.next_trakt_flush = self.clock() + 60
        if busy or now < self.next_trakt:
            return
        try:
            from . import trakt_watched
            trakt_watched.refresh(max_age=max(120, interval))
            self.trakt_failures = 0
            self.next_trakt = self.clock() + max(120, interval)
        except Exception as error:
            self.trakt_failures += 1
            self.next_trakt = self.clock() + retry_delay(error, self.trakt_failures-1)


def run(monitor, cycle_lock):
    import xbmcgui
    from .meganexus import cloud_sync as sync
    from . import simkl_api as simkl, settings_snapshot
    if monitor.waitForAbort(5):
        return
    scheduler = Scheduler(xbmcgui.Window(10000), stopped=monitor.abortRequested)
    while not monitor.abortRequested():
        try:
            scheduler.step(sync, simkl, settings_snapshot.cached_addon(), cycle_lock)
        except Exception:
            # Never emit tokenized endpoint URLs through an exception message.
            if monitor.waitForAbort(15):
                return
        if monitor.waitForAbort(2):
            return
