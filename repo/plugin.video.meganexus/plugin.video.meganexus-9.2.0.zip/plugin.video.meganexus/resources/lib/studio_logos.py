# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A title's studios' and networks' logos (idea, 2026-11-17).

"treba ubaciti originalne ikone i logotipe studija kod filmova i serija ko sto nuvio radi": TMDB's production companies
(a film) or networks (a series) that have a logo, in TMDB's order, at most MOST - as TMDB shows them. Kept with
TMDB's other answers (tmdb_api.keep): a month, six hours when there is none. Never from a Kodi GUI callback.
"""
from . import release_info, tmdb_api

MOST = 3


def logos(meta, cached_only=False):
    """[logo address] of the title in ``meta`` ([] without a TMDB key, when TMDB has none, or not fetched yet with
    ``cached_only``)."""
    if not tmdb_api.api_key():
        return []
    series = (meta.get('type') or '') == 'series'
    kind = 'tv' if series else 'movie'
    imdb, tmdb = release_info._ids(meta)
    key = 'studio_logos:%s:%s:%s' % (kind, tmdb, imdb)
    kept = tmdb_api.kept(key)
    if kept is not None:
        return kept.get('logos') or []
    if cached_only:
        return []
    try:
        tmdb = tmdb or tmdb_api.find_id(imdb_id=imdb, media_type='series' if series else 'movie')
        reply = (tmdb_api.get('/%s/%s' % (kind, tmdb)) or {}) if tmdb else {}
    except Exception:
        return []
    rows = reply.get('networks' if series else 'production_companies') or []
    found = [tmdb_api.picture(row['logo_path'], 'logo') for row in rows if isinstance(row, dict) and row.get('logo_path')][:MOST]
    tmdb_api.keep(key, {'logos': found}, tmdb_api.HIT_LIFE if found else tmdb_api.MISS_LIFE)
    return found
