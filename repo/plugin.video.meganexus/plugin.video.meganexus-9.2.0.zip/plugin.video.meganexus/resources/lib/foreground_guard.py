# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A MegaNexus film never plays behind Home (7.0.29).

Sometimes a film started but Kodi did not switch to its full-screen video:
it played on behind Home and could not be left. And Back from the player
left the film running under the HUB. The service watches a MegaNexus film
(Window(Home).Property(meganexus.playing.request_id)):

* not on screen 4 s after it started (Back / Esc pressed while it loaded) - it
  is paused and the HUB offers "Now playing" to carry on in full screen;
* the player left for Home or the HUB for 1 s - the film is stopped (its
  progress is saved as on any stop);
* the player's Home button (park) - the film plays on behind Home and "Now
  playing" brings it back to full screen.

Dialogs over the player (sources, subtitles, audio, info) keep Kodi's
full-screen window underneath, so they are never mistaken for leaving.

7.0.45: a video started outside MegaNexus (Kodi's Videos, a file) that was full
screen stops too when Back / Esc leaves its player - it no longer plays on behind
the HUB. Not live TV, nor while MegaNexus IPTV or Sport shows its preview, and only
with the option on (Playback: "Back stops a video", on at first).

9.0.7: the films this guard, the player's Back (trailers) and the no-picture check stop
go through stop_film(). xbmc.Player().stop() keeps Python's lock (the GIL, one for every
add-on) until Kodi's main thread has closed the film, and all Python stands still that
long. When the main thread is itself waiting on Python - Kodi stopping our service for an
add-on update holds the lock the main thread needs, and its kill of the service needs the
GIL (2026-11-03 22:08, gdb) - nothing moves again: the 9.0.x playnext freeze, the same way.
Kodi's JSON-RPC lets go of the GIL while it waits. And the film is named as being left
first (LEAVING): subtitle work (Autosync, AI subtitles, the start's own) keeps its hands
off that player from then on (being_left).
"""
import json
import time

import xbmc
import xbmcgui

BRING_UP = 4.0
# MegaNexus screens that, open over the video, mean it plays behind (Kodi still
# counts its full-screen video as active underneath them).
COVERS = ' | '.join('Window.IsVisible(%s)' % name for name in (
    'meganexus_home.xml', 'meganexus_home_compact.xml', 'meganexus_details.xml', 'meganexus_details_landscape.xml',
    'meganexus_catalog.xml', 'meganexus_catalog_landscape.xml', 'meganexus_library.xml', 'meganexus_person.xml'))


def on_screen():
    return xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') and not xbmc.getCondVisibility(COVERS)
WAITING = 'meganexus.background_film'
LEFT = 1.0
LEAVING = 'meganexus.film.leaving'   # 9.0.7: Window(Home) - the request of the film being stopped
VIDEO_PLAYER = 1                     # Kodi's JSON-RPC player of videos when no playlist says otherwise
STOP_WAIT = 3.0                      # 9.0.8: s at most stop_film() waits for Kodi to close the video


def being_left(request):
    """9.0.7: the film of this request is on its way out (stop_film named it): nothing may
    touch its player any more. Asked right before every subtitle call on the player."""
    try:
        return bool(request) and xbmcgui.Window(10000).getProperty(LEAVING) == str(request)
    except Exception:
        return False


def stop_film(request=''):
    """9.0.7: the film stops, MegaNexus' way. Named as being left first (``request``, the
    film's meganexus.request), a Usenet film's server told to stop waiting (player_state),
    then Kodi's JSON-RPC Player.Stop, which never holds Python while Kodi closes the film.
    Only a player of video is stopped - the id Kodi gives it, which is the current
    playlist's (a film after a song from the music queue plays as player 0: a fixed 1 was
    refused and the film went on).

    9.0.8: and it returns once the film is closed, as xbmc.Player().stop() did. Kodi's
    Player.Stop only posts the stop to its main thread and answers at once (Kodi 21 and 22,
    PlayerOperations.cpp: PostMsg(TMSG_MEDIA_STOP)) - Back from a film then found it still
    playing, skipped the wait for the service to save where it was stopped, and the title
    page read the resume point from before (trailers.wait_for_playback). The wait lets go of
    Python (waitForAbort) and ends with Kodi's stop of this script."""
    if request:
        xbmcgui.Window(10000).setProperty(LEAVING, str(request))
    try:
        from .player_state import leaving
        leaving()
    except Exception:
        pass
    player = _video_player()
    if player is not None and 'result' in _rpc('Player.Stop', {'playerid': player}):
        _wait_closed()


def _wait_closed(most=STOP_WAIT):
    """9.0.8: until Kodi shows no video any more (STOP_WAIT at most, never past Kodi's stop)."""
    monitor, until = xbmc.Monitor(), time.monotonic() + most
    while xbmc.getCondVisibility('Player.HasVideo') and time.monotonic() < until:
        if monitor.waitForAbort(.05):
            break


def pause_film(pause=True):
    """9.0.8: the video paused (``pause``) or going on again, through Kodi's JSON-RPC
    Player.PlayPause on the player showing it. The Player's own pause() keeps Python's lock
    while Kodi's main thread pauses the video (Player.cpp: SendMsg(TMSG_MEDIA_PAUSE), no
    DelayedCallGuard) - all Python stands still meanwhile, for good when the main thread is
    itself waiting on Python (foreground_guard.stop_film). True when Kodi did it."""
    player = _video_player()
    if player is None:
        return False
    return 'result' in _rpc('Player.PlayPause', {'playerid': player, 'play': not pause})


def _rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request)) or '{}')
    except (TypeError, ValueError):
        return {}


def _video_player():
    """The JSON-RPC id of the player showing a video; None when none does. Kodi not
    answering: the videos' usual id."""
    players = _rpc('Player.GetActivePlayers').get('result')
    if not isinstance(players, list):
        return VIDEO_PLAYER
    return next((p.get('playerid') for p in players if isinstance(p, dict) and p.get('type') == 'video'), None)


def _ours(player, home):
    if not home.getProperty('meganexus.playing.request_id'):
        return False
    if home.getProperty('meganexus.preview.active') or home.getProperty('meganexus.playback.choosing'):
        return False
    try:
        if not player.isPlayingVideo():
            return False
        wanted = home.getProperty('meganexus.playing.request_id')
        # 9.1.4: once per playback - getPlayingItem() twice a second kept 94 MB an hour of a film in Kodi
        from .playing_item import prop
        request = prop(player, 'meganexus.request')
        if request:
            return request == wanted
        # a resolver handoff can lose the item's properties: the service confirmed the start
        return home.getProperty('meganexus.playback.started') == wanted
    except Exception:
        return False


STOP_SETTING = 'meganexus_back_stops_video'
KEEP_PLAYING = ' | '.join(('VideoPlayer.Content(LiveTV)', 'Pvr.IsPlayingTv', 'Pvr.IsPlayingRadio',
                           'Window.IsVisible(meganexus_iptv.xml)', 'Window.IsVisible(meganexus_sports.xml)'))


def _song(home):
    """The Music app's song plays (a song from YouTube comes as a video - it is no film)."""
    return bool(home.getProperty('meganexus.music.playing')) and not xbmc.getCondVisibility('String.IsEmpty(MusicPlayer.Title)')


def _other_video(player, home):
    """A video of Kodi's own (not MegaNexus's, not a preview, the wallpaper or live TV - nor the Music app's
    song from YouTube, which comes as a video and plays on through every screen)."""
    if home.getProperty('meganexus.playing.request_id') or home.getProperty('meganexus.preview.active') \
            or home.getProperty('meganexus.saver.active'):
        return False
    if _song(home):
        return False
    try:
        if not player.isPlayingVideo():
            return False
    except Exception:
        return False
    try:
        from .settings_snapshot import cached_addon
        if cached_addon().getSetting(STOP_SETTING) == 'false':
            return False
    except Exception:
        pass
    return not xbmc.getCondVisibility(KEEP_PLAYING)


def run(monitor):
    player, home = xbmc.Player(), xbmcgui.Window(10000)
    started = away = None
    seen = parked_away = False
    other_seen, other_away = False, None
    failures = 0
    xbmc.log('[MegaNexus] Film guard on.', xbmc.LOGINFO)
    while not monitor.abortRequested():
        try:
            if _ours(player, home):
                now = time.monotonic()
                started = started or now
                if on_screen():
                    seen, away = True, None
                    if parked_away:            # back through "Now playing"
                        home.clearProperty(WAITING)
                        parked_away = False
                        xbmc.log('[MegaNexus] Film guard: the film is back on screen - no longer waiting.', xbmc.LOGINFO)
                elif home.getProperty(WAITING):
                    away, parked_away = None, True     # behind Home, "Now playing" shown
                elif seen:
                    away = away or now
                    if now - away >= LEFT:
                        xbmc.log('[MegaNexus] The player was left for Home - the film stops.', xbmc.LOGINFO)
                        stop_film(home.getProperty('meganexus.playing.request_id'))
                        seen, away, started = False, None, None
                elif now - started >= BRING_UP and not home.getProperty(WAITING):
                    # Back / Esc pressed while it started: it waits, paused, for the
                    # HUB's "Now playing" pill (review/make_hub_now_playing.py).
                    xbmc.log('[MegaNexus] The film started behind the HUB - paused, Now playing shown.', xbmc.LOGINFO)
                    if not xbmc.getCondVisibility('Player.Paused'):
                        xbmc.executebuiltin('PlayerControl(Play)')
                    home.setProperty(WAITING, '1')
            else:
                started = away = None
                seen = parked_away = False
                # 9.0.5: the film waiting behind Home keeps its mark while any video plays - a moment in
                # which Kodi does not say what plays (its windows changing as the player is left) is not
                # its end. The mark gone, the film was stopped as soon as the player was left
                # ("kliknuo sam na home i ugasio je playback").
                # 9.0.6: nor is a song the film: one from YouTube is a video too, and the HUB's "Now
                # playing" stood in Up's way to the music ("crticom prema gore nemogu pristupiti glazbi")
                if home.getProperty(WAITING) and (not player.isPlayingVideo() or _song(home)):
                    home.clearProperty(WAITING)
                    xbmc.log('[MegaNexus] Film guard: no film plays any more - no longer waiting.', xbmc.LOGINFO)
                if _other_video(player, home):
                    if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                        other_seen, other_away = True, None
                    elif other_seen:
                        other_away = other_away or time.monotonic()
                        if time.monotonic() - other_away >= LEFT:
                            xbmc.log('[MegaNexus] The player of a video was left - it stops.', xbmc.LOGINFO)
                            stop_film()
                            other_seen, other_away = False, None
                else:
                    other_seen, other_away = False, None
        except Exception:
            failures += 1
            if failures <= 3:
                import traceback
                xbmc.log('[MegaNexus] Film guard: ' + traceback.format_exc(), xbmc.LOGWARNING)
        if monitor.waitForAbort(0.5):
            break


FROM_PLAYER = 'meganexus.home.from_player'   # Home puts the cursor on its own pill


def park():
    """The player's Home button: the film plays on behind MegaNexus Home, whose
    "Now playing" brings it back to full screen."""
    home = xbmcgui.Window(10000)
    home.setProperty(WAITING, '1')
    # 8.1.2: Home was asked for by name, so Home is where the cursor belongs
    # (home_window._came_from_the_player). Nothing else may place it there.
    home.setProperty(FROM_PLAYER, '1')
    xbmc.log('[MegaNexus] Home from the player - the film plays on, Now playing shown.', xbmc.LOGINFO)
    # Back leads to the screen the film was started from. Kodi ignores it while the
    # player bar is still fading out, so it is sent once no dialog is closing.
    monitor = xbmc.Monitor()
    until = time.monotonic() + 4
    while time.monotonic() < until and not monitor.abortRequested():
        if not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            return
        if xbmc.getCondVisibility(COVERS):
            # 8.1.2: a MegaNexus screen is up over the film - the Back we sent arrived
            # and did its work. Kodi can take a moment to stop counting its full-screen
            # video as active, and a second Back sent in that moment went THROUGH to
            # that screen and closed it, which put the film back on the screen: the
            # player's Home button looked like it did nothing.
            return
        if not xbmc.getCondVisibility('System.HasActiveModalDialog | Window.IsVisible(videoosd)'):
            xbmc.executebuiltin('Action(Back)')
            monitor.waitForAbort(0.4)
        else:
            monitor.waitForAbort(0.1)
    if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') and not xbmc.getCondVisibility(COVERS):
        xbmc.executebuiltin('ActivateWindow(Home)')
