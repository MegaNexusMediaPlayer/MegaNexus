# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaIPTV's Movies and Series, as each IPTV list's Xtream server has them (idea, 2026-11-17).

"MegaNexus IPTV must retrieve Movies and Series from supported IPTV provider endpoints ... Movie categories ...
Series categories, seasons, episodes ... strict separation between Live TV, Movies and Series" (the user's master
task); "slazes kako ih iptv daje po grupama ... redove i pazi da ne pomjesas filmove i serije ... nemoj kesirati to
na disk ... oni koriste od tu samo svoj jedan izvor a ne sourcove od addona ... nema tu odaberi source".

* A row is one of the server's groups (player_api.php get_vod_categories / get_series_categories), in its order; its
  titles are asked when the row is (get_vod_streams / get_series with the group's id), a series' seasons and episodes
  when it is opened (get_series_info). Films and series never share a row.
* Nothing is written to disk: what was asked is kept in memory while MegaIPTV is open (forget() when it closes).
* One call to a server at a time, PAUSE after the one before - however many rows load at once.
* A film or an episode plays from its list alone: link() makes its address from the list's login when it plays; the
  login is never kept elsewhere nor written to the log.
"""
import json
import threading
import time
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

MOVIE, SERIES = 'movie', 'series'
PAUSE = 0.25                 # seconds between two calls to a server
TIMEOUT = 30
PAGE = 40
ACTIONS = {MOVIE: ('get_vod_categories', 'get_vod_streams'), SERIES: ('get_series_categories', 'get_series')}
_KEPT = {}                   # (list id, what...) -> the answer, while MegaIPTV is open
_CALL = threading.Lock()     # one call to a server at a time
_LAST = [0.0]


def _text(value, most=2000):
    return ' '.join(str(value or '').split())[:most]


def _number(value, kind=float):
    try:
        return kind(float(value))
    except (TypeError, ValueError):
        return kind(0)


def _year(*values):
    for value in values:
        text = str(value or '').strip()
        if len(text) >= 4 and text[:4].isdigit():
            return text[:4]
    return ''


def movie(row):
    """An Xtream get_vod_streams row as a title (None when it has no id or name)."""
    if not isinstance(row, dict) or row.get('stream_id') in (None, ''):
        return None
    name = _text(row.get('name') or row.get('title'), 200)
    if not name:
        return None
    return {'kind': MOVIE, 'id': str(row['stream_id']), 'name': name,
            'year': _year(row.get('year'), row.get('release_date'), row.get('releasedate')),
            'poster': _text(row.get('stream_icon'), 500), 'backdrop': '', 'plot': _text(row.get('plot')),
            'genre': _text(row.get('genre'), 200), 'cast': _text(row.get('cast'), 400), 'rating': _number(row.get('rating')),
            'added': _number(row.get('added'), int), 'ext': _text(row.get('container_extension'), 8) or 'mp4'}


def series(row):
    """An Xtream get_series row as a title."""
    if not isinstance(row, dict) or row.get('series_id') in (None, ''):
        return None
    name = _text(row.get('name') or row.get('title'), 200)
    if not name:
        return None
    backdrop = row.get('backdrop_path')
    if isinstance(backdrop, list):
        backdrop = backdrop[0] if backdrop else ''
    return {'kind': SERIES, 'id': str(row['series_id']), 'name': name,
            'year': _year(row.get('year'), row.get('releaseDate'), row.get('release_date')),
            'poster': _text(row.get('cover'), 500), 'backdrop': _text(backdrop, 500), 'plot': _text(row.get('plot')),
            'genre': _text(row.get('genre'), 200), 'cast': _text(row.get('cast'), 400), 'rating': _number(row.get('rating')),
            'added': _number(row.get('last_modified'), int), 'ext': ''}


def episodes(reply):
    """{season: [episode]} of an Xtream get_series_info answer, each season's in the episodes' order."""
    found = {}
    rows = reply.get('episodes') if isinstance(reply, dict) else None
    for season, items in (rows.items() if isinstance(rows, dict) else []):
        for row in items if isinstance(items, list) else []:
            if not isinstance(row, dict) or row.get('id') in (None, ''):
                continue
            info = row.get('info') if isinstance(row.get('info'), dict) else {}
            number = _number(row.get('season') or season, int)
            found.setdefault(number, []).append(
                {'id': str(row['id']), 'season': number, 'episode': _number(row.get('episode_num'), int),
                 'name': _text(row.get('title'), 200), 'poster': _text(info.get('movie_image') or info.get('cover_big'), 500),
                 'plot': _text(info.get('plot')), 'duration': _number(info.get('duration_secs'), int),
                 'ext': _text(row.get('container_extension'), 8) or 'mp4'})
    for items in found.values():
        items.sort(key=lambda e: e['episode'])
    return dict(sorted(found.items()))


class Xtream:
    """One Xtream server's player_api."""

    def __init__(self, account, opener=None, wait=None, clock=None):
        self.base, self.user, self.password = account
        self.opener = opener or (lambda request: urlopen(request, timeout=TIMEOUT))
        self.wait = wait or time.sleep
        self.clock = clock or time.monotonic

    def get(self, action, **extra):
        query = urlencode(dict({'username': self.user, 'password': self.password, 'action': action}, **extra))
        request = Request('%s/player_api.php?%s' % (self.base, query), headers={'User-Agent': 'MegaNexus/9'})
        with _CALL:
            gap = PAUSE - (self.clock() - _LAST[0])
            if gap > 0:
                self.wait(gap)
            try:
                with self.opener(request) as response:
                    return json.loads(response.read().decode('utf-8', 'replace'))
            finally:
                _LAST[0] = self.clock()

    def link(self, kind, item_id, ext):
        """The address a film or an episode plays from."""
        return '%s/%s/%s/%s/%s.%s' % (self.base, 'movie' if kind == MOVIE else 'series', quote(self.user, safe=''),
                                       quote(self.password, safe=''), quote(str(item_id), safe=''), ext or 'mp4')


def account(list_row):
    from .iptv_catchup import xtream_account
    return xtream_account((list_row or {}).get('m3u'))


def lists(folder):
    """The IPTV lists with films and series to show (an Xtream server's)."""
    from .iptv_lists import load
    return [row for row in load(folder) if account(row)]


def _kept(key, ask):
    if key not in _KEPT:
        _KEPT[key] = ask()
    return _KEPT[key]


def groups(list_row, kind, opener=None):
    """[(group id, name)] of the server's films or series, in its order."""
    def ask():
        reply = Xtream(account(list_row), opener).get(ACTIONS[kind][0])
        return [(str(g['category_id']), _text(g.get('category_name'), 120) or '-') for g in (reply if isinstance(reply, list) else [])
                if isinstance(g, dict) and g.get('category_id') not in (None, '')]
    return _kept((list_row['id'], kind, 'groups'), ask)


def titles(list_row, kind, group_id, opener=None):
    """Every title of one group, as the server orders it."""
    make = movie if kind == MOVIE else series
    def ask():
        reply = Xtream(account(list_row), opener).get(ACTIONS[kind][1], category_id=str(group_id))
        return [t for t in (make(row) for row in (reply if isinstance(reply, list) else [])) if t]
    return _kept((list_row['id'], kind, 'group', str(group_id)), ask)


def everything(list_row, kind, opener=None):
    """Every film or series of the server (one call, for the search)."""
    make = movie if kind == MOVIE else series
    def ask():
        reply = Xtream(account(list_row), opener).get(ACTIONS[kind][1])
        return [t for t in (make(row) for row in (reply if isinstance(reply, list) else [])) if t]
    return _kept((list_row['id'], kind, 'all'), ask)


def find(list_row, kind, text, limit=PAGE, opener=None):
    """Titles whose name has every word of ``text`` (newest first)."""
    words = ' '.join(str(text or '').casefold().split()).split()
    if not words:
        return []
    found = [t for t in everything(list_row, kind, opener) if all(w in t['name'].casefold() for w in words)]
    found.sort(key=lambda t: -t['added'])
    return found[:limit]


def seasons(list_row, series_id, opener=None):
    """{season: [episode]} of one series."""
    return _kept((list_row['id'], SERIES, 'seasons', str(series_id)),
                 lambda: episodes(Xtream(account(list_row), opener).get('get_series_info', series_id=str(series_id))))


def movie_info(list_row, movie_id, opener=None):
    """{'tmdb': id or '', 'backdrop': picture or ''} of one film (get_vod_info - the list has no ids)."""
    def ask():
        info = (Xtream(account(list_row), opener).get('get_vod_info', vod_id=str(movie_id)) or {}).get('info') or {}
        backdrop = info.get('backdrop_path')
        if isinstance(backdrop, list):
            backdrop = backdrop[0] if backdrop else ''
        tmdb = str(info.get('tmdb_id') or '').strip()
        return {'tmdb': tmdb if tmdb.isdigit() else '', 'backdrop': _text(backdrop, 500)}
    return _kept((list_row['id'], MOVIE, 'info', str(movie_id)), ask)


def link(list_row, kind, item_id, ext):
    """The address a film or an episode plays from, made from the list's login now."""
    login = account(list_row)
    if login is None:
        raise ValueError('This IPTV list has no login for its films and series.')
    return Xtream(login).link(kind, item_id, ext)


def forget():
    """MegaIPTV closed: nothing of the servers is kept."""
    _KEPT.clear()
