# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Trending now on TMDB (7.0.42): a large landscape picture on the HUB (and in
the screensaver, switched on in its studio) that changes every ROTATE seconds.

The service reads TMDB's trending films and series of the week (backdrop,
title logo, year) once every REFRESH seconds - needs the user's TMDB key - and
publishes the current one as Window(Home) properties meganexus.spotlight.art /
.logo / .title / .line / .plot (7.0.44: the line is genres · year · seasons or
running time · TMDB rating, like Google TV; plot is the story). It turns only while the HUB or the screensaver shows
(nothing changes behind MegaNexus or a video). Setting meganexus_hub_spotlight
(default on).
"""
import time

SETTING = 'meganexus_hub_spotlight'
REFRESH = 6 * 3600
ROTATE = 10
MAX_ITEMS = 20
CACHE_KEY = 'hub_spotlight:v3'   # v3 (7.0.48): the full-size backdrops
# 7.0.48: TMDB's full-size backdrop, not w1280: Kodi keeps a 16:9 picture up to 1080
# lines (fanartres) - w1280 (720 lines) was drawn enlarged on the 1674 px spotlight
BACKDROP = 'https://image.tmdb.org/t/p/original'
PROPS = ('art', 'logo', 'title', 'line', 'plot')


def _details(tmdb, kind, tmdb_id):
    """The title's details with its logos - one request (append_to_response)."""
    try:
        return tmdb.get('/%s/%s' % (kind, tmdb_id), {'language': 'en-US', 'append_to_response': 'images',
                                                           'include_image_language': 'en,null'}) or {}
    except Exception:
        return {}


def _logo(tmdb, details):
    logos = [row for row in (details.get('images') or {}).get('logos') or [] if row.get('file_path')]
    logos.sort(key=lambda row: (row.get('iso_639_1') != 'en', -(row.get('vote_average') or 0)))
    return tmdb.picture(logos[0]['file_path'], 'logo') if logos else ''


def meta_line(kind, row, details):
    """'Mystery, Drama, Crime · 2026 · 1 Season · TMDB 7.7' (films: running time)."""
    genres = ', '.join(g.get('name') for g in (details.get('genres') or [])[:3] if g.get('name'))
    year = str(row.get('release_date') or row.get('first_air_date') or '')[:4]
    if kind == 'tv':
        seasons = details.get('number_of_seasons') or 0
        length = '%d Season%s' % (seasons, '' if seasons == 1 else 's') if seasons else ''
    else:
        minutes = details.get('runtime') or 0
        length = ('%dh %dm' % divmod(minutes, 60) if minutes >= 60 else '%dm' % minutes) if minutes else ''
    rating = ('TMDB %.1f' % row['vote_average']) if row.get('vote_average') else ''
    return '  ·  '.join(part for part in (genres or ('Film' if kind == 'movie' else 'Series'), year, length, rating) if part)


def items(refresh=False):
    """[{'art', 'logo', 'title', 'line'}] of this week's trending titles (cached)."""
    from . import tmdb_api
    if not tmdb_api.api_key():
        return []
    cached = None if refresh else tmdb_api.kept(CACHE_KEY)
    if cached is not None:
        return cached.get('items') or []
    try:
        reply = tmdb_api.get('/trending/all/week', {'language': 'en-US'}) or {}
    except Exception:
        return []
    found = []
    for row in reply.get('results') or []:
        kind = row.get('media_type')
        if kind not in ('movie', 'tv') or not row.get('backdrop_path'):
            continue
        title = row.get('title') or row.get('name') or ''
        details = _details(tmdb_api, kind, row.get('id'))
        found.append({'art': BACKDROP + row['backdrop_path'],
                      'logo': _logo(tmdb_api, details), 'title': title, 'line': meta_line(kind, row, details),
                      'plot': str(details.get('overview') or row.get('overview') or '').strip()})
        if len(found) >= MAX_ITEMS:
            break
    if found:
        tmdb_api.keep(CACHE_KEY, {'items': found}, REFRESH)
    return found


NOLOGO = 'meganexus.nologo'    # 7.0.42: Window(Home) - the MegaNexus logo stays off every screen


def logo_rule(window, on):
    """While Trending now on TMDB is on (and a TMDB key is set), the theme's pictures
    without the MegaNexus logo everywhere - the HUB, the opening screens, the
    screensaver - from the start, not only once a trending picture has loaded (the
    logo flashed on the way out and into the screensaver). Cheap when unchanged."""
    value = '1' if on else ''
    if window.getProperty(NOLOGO) != value:
        window.setProperty(NOLOGO, value)
    return on


def logo_off(addon=None):
    """The rule as the settings say it now (any interpreter)."""
    from . import tmdb_api
    if addon is None:
        from .settings_snapshot import cached_addon
        addon = cached_addon()
    return addon.getSetting(SETTING) != 'false' and bool(tmdb_api.api_key())


def publish(window, item):
    for key in PROPS:
        window.setProperty('meganexus.spotlight.' + key, (item or {}).get(key, ''))


def run(monitor, enabled, showing, window, log=None, step=2):
    """Service loop: rotate while the HUB / screensaver shows; clear when switched off."""
    found, loaded, index, shown, next_turn = [], 0., -1, False, 0.
    from . import tmdb_api
    on = lambda: enabled() and bool(tmdb_api.api_key())
    try:
        logo_rule(window, on())
    except Exception:
        pass
    while not monitor.waitForAbort(step):
        try:
            logo_rule(window, on())
        except Exception:
            pass          # the logo rule never stops the pictures
        try:
            if not enabled():
                if shown:
                    publish(window, None)
                    shown = False
                continue
            now = time.monotonic()
            if not found or now - loaded > REFRESH:
                found, loaded = items(), now
                if not found:
                    loaded = now - REFRESH + 600      # no key / no answer: again in 10 minutes
                    continue
            if not showing() or now < next_turn:
                continue
            index = (index + 1) % len(found)
            publish(window, found[index])
            shown, next_turn = True, now + ROTATE
        except Exception as exc:
            if log:
                log('[MegaNexus] Trending spotlight skipped: %s' % type(exc).__name__)
