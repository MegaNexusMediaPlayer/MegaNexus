# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Local storage (6.0.37): movies and series from the device's own storage.

Kodi already scans folders (USB disk, NAS, SMB/NFS shares) into its video
library and keeps resume points and watched state for them. MegaNexus reads
that library through JSON-RPC and shows it on Home (Settings > Collections > Home rows, or HUB Settings > Local
storage). 9.1.4: one "Local media" row, films and series together ("jer su tu serije i filmovi"); and each folder
(a Kodi video source) may be a row of its own or a tile in that row, under the name the user gives it (its
folder's name first) - films, series, anime, home videos kept apart. Playback opens the library item itself, so Kodi's own resume and
watched marks keep working; MegaNexus' stream tracking stays out of it.
"""
import json
import time

import xbmc

HOME_SETTING = 'meganexus_home_local'
SOURCES_WINDOW = 'ActivateWindow(Videos,sources://video/,return)'
KINDS = ('movie', 'series')
TITLE = 'Local media'
FOLDERS_SETTING = 'meganexus_local_folders'   # 9.1.4: {folder: {'mode': 'row' | 'tile', 'name': ...}}
MODES = ('', 'row', 'tile')                   # in the Local media row, its own row, a tile in the Local media row
ROW_LIMIT = 40
_COUNTS = {'at': 0.0, 'value': None}
COUNT_SECONDS = 60


def rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        request['params'] = params
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except (TypeError, ValueError):
        return {}
    return (reply.get('result') or {}) if isinstance(reply, dict) else {}


def enabled(addon=None):
    try:
        if addon is None:
            from .settings_snapshot import cached_addon
            addon = cached_addon()
        return addon.getSetting(HOME_SETTING) == 'true'
    except Exception:
        return False


def counts(fresh=False):
    """{'movie': n, 'series': n} - cached for a minute, Home asks on every paint."""
    now = time.monotonic()
    if not fresh and _COUNTS['value'] is not None and now - _COUNTS['at'] < COUNT_SECONDS:
        return dict(_COUNTS['value'])
    value = {'movie': int((rpc('VideoLibrary.GetMovies', {'limits': {'start': 0, 'end': 1}}).get('limits') or {}).get('total') or 0),
             'series': int((rpc('VideoLibrary.GetTVShows', {'limits': {'start': 0, 'end': 1}}).get('limits') or {}).get('total') or 0)}
    _COUNTS.update(at=now, value=value)
    return dict(value)


def forget_counts():
    _COUNTS.update(at=0.0, value=None)


def folders(addon=None):
    """9.1.4: what each folder is on Home: {folder: {'mode': 'row' | 'tile', 'name': ...}} (in Local media: absent)."""
    try:
        if addon is None:
            from .settings_snapshot import cached_addon
            addon = cached_addon()
        found = json.loads(addon.getSetting(FOLDERS_SETTING) or '{}')
    except Exception:
        return {}
    return {path: way for path, way in found.items() if isinstance(way, dict) and way.get('mode') in MODES[1:]} \
        if isinstance(found, dict) else {}


def set_folder(path, mode, name='', addon=None):
    """A folder's place on Home: '' (in Local media), 'row' or 'tile', with its name."""
    if addon is None:
        from .settings_snapshot import cached_addon
        addon = cached_addon()
    chosen = folders(addon)
    if mode in MODES[1:]:
        chosen[path] = {'mode': mode, 'name': str(name or '').strip()}
    else:
        chosen.pop(path, None)
    addon.setSetting(FOLDERS_SETTING, json.dumps(chosen, sort_keys=True))


def folder_name(path, label='', addon=None):
    """The name a folder goes by on Home: the one the user gave it, else its folder's own."""
    return (folders(addon).get(path) or {}).get('name') or label or \
        str(path).rstrip('/\\').rsplit('/', 1)[-1].rsplit('\\', 1)[-1] or str(path)


def shelves(addon=None):
    """Home shelves for the local library: 9.1.4 the folders with a row of their own, then Local media - its tiles
    and the titles of every other folder; none when nothing is there."""
    if not enabled(addon):
        return []
    have = counts()
    from . import local_files
    if not (have.get('movie') or have.get('series')) and not any(local_files.has(kind) for kind in KINDS):
        # 7.0.29: folders Kodi has not scanned are read by MegaNexus itself - from the saved index (built by the
        # service): no rows for empty folders
        return []
    chosen = folders(addon)
    labels = {s['file']: s.get('label') or '' for s in sources()} if chosen else {}
    own = [{'title': folder_name(path, labels.get(path), addon), 'local_job': ('folder', path), 'rows': [loading_card()]}
           for path in labels if (chosen.get(path) or {}).get('mode') == 'row']
    left = [path for path in labels if path not in chosen]
    tiles = [path for path in labels if (chosen.get(path) or {}).get('mode') == 'tile']
    media = [] if chosen and not left and not tiles else \
        [{'title': TITLE, 'local_job': ('media',), 'rows': [loading_card()]}]
    return media + own


def loading_card(kind=''):
    return {'title': ' ', 'plot': '',   # 7.0.42: no loading words
            'path': '', 'is_folder': False, 'poster': '', 'fanart': '', 'subtitle': '', 'meta_line': ''}


def _art(art, *keys):
    for key in keys:
        value = (art or {}).get(key)
        if value:
            return value
    return ''


def _percent(resume):
    try:
        position, total = float((resume or {}).get('position') or 0), float((resume or {}).get('total') or 0)
    except (TypeError, ValueError):
        return 0
    return int(position * 100 / total) if position > 0 and total > 0 else 0


MOVIE_FIELDS = ['title', 'year', 'plot', 'art', 'rating', 'runtime', 'playcount', 'resume', 'genre', 'dateadded']
SHOW_FIELDS = ['title', 'year', 'plot', 'art', 'rating', 'playcount', 'episode', 'watchedepisodes', 'season', 'genre', 'dateadded']


def movie_card(movie):
    percent = _percent(movie.get('resume'))
    year = str(movie.get('year') or '')
    watched = bool(movie.get('playcount'))
    state = ('%d%% watched' % percent) if percent else ('Watched' if watched else '')
    rating = ('%.1f' % float(movie['rating'])) if movie.get('rating') else ''
    art = movie.get('art') or {}
    return {'title': movie.get('label') or movie.get('title') or 'Untitled',
            'subtitle': '  ·  '.join(x for x in (year, state) if x),
            'meta_line': '  |  '.join(x for x in (year, 'Movie', 'Local', rating) if x),
            'plot': movie.get('plot') or '', 'poster': _art(art, 'poster', 'thumb'),
            'fanart': _art(art, 'fanart'), 'landscape': _art(art, 'landscape', 'fanart'),
            'clearlogo': _art(art, 'clearlogo'), 'percent_value': percent, 'watched': '1' if watched and not percent else '',
            'local': {'type': 'movie', 'id': movie.get('movieid'), 'title': movie.get('label') or movie.get('title') or ''},
            'path': '', 'is_folder': False, '_added': movie.get('dateadded') or ''}


def show_card(show):
    total, seen = int(show.get('episode') or 0), int(show.get('watchedepisodes') or 0)
    left = max(0, total - seen)
    if total and not left:
        state = 'Watched'
    elif seen:
        state = '%d new episode%s' % (left, '' if left == 1 else 's')
    else:
        state = '%d episode%s' % (total, '' if total == 1 else 's') if total else ''
    year = str(show.get('year') or '')
    rating = ('%.1f' % float(show['rating'])) if show.get('rating') else ''
    art = show.get('art') or {}
    return {'title': show.get('label') or show.get('title') or 'Untitled',
            'subtitle': '  ·  '.join(x for x in (year, state) if x),
            'meta_line': '  |  '.join(x for x in (year, 'Series', 'Local', rating) if x),
            'plot': show.get('plot') or '', 'poster': _art(art, 'poster', 'thumb'),
            'fanart': _art(art, 'fanart'), 'landscape': _art(art, 'landscape', 'fanart'),
            'clearlogo': _art(art, 'clearlogo'), 'watched': '1' if total and not left else '',
            'local': {'type': 'series', 'id': show.get('tvshowid'), 'title': show.get('label') or show.get('title') or ''},
            'path': '', 'is_folder': False, '_added': show.get('dateadded') or ''}


def _library(kind, limit=None, paths=None):
    """Kodi's library titles of the kind as cards, newest first, and how many it holds in all; 9.1.4 ``paths``: only
    those in these folders (an empty list: none)."""
    if paths is not None and not paths:
        return [], 0
    params = {'sort': {'method': 'dateadded', 'order': 'descending'}}
    if limit:
        params['limits'] = {'start': 0, 'end': limit}
    if paths:
        rules = [{'field': 'path', 'operator': 'startswith', 'value': path} for path in paths]
        params['filter'] = rules[0] if len(rules) == 1 else {'or': rules}
    if kind == 'movie':
        found = rpc('VideoLibrary.GetMovies', dict(params, properties=MOVIE_FIELDS))
        cards = [movie_card(m) for m in found.get('movies') or [] if m.get('movieid')]
    else:
        found = rpc('VideoLibrary.GetTVShows', dict(params, properties=SHOW_FIELDS))
        cards = [show_card(s) for s in found.get('tvshows') or [] if s.get('tvshowid')]
    return cards, int((found.get('limits') or {}).get('total') or len(cards))


def _job(job):
    """('media',) / ('folder', path); a shelf kept from before 9.1.4 ('movie' / 'series') is Local media."""
    return tuple(job) if isinstance(job, (list, tuple)) and job else ('media',)


def _paths(job, addon=None):
    """The folders a row shows: one folder's own, or Local media's - every folder not given a row or a tile (None:
    no folder was given one - the whole library)."""
    job = _job(job)
    if job[0] == 'folder':
        return [job[1]]
    chosen = folders(addon)
    if not chosen:
        return None
    return [s['file'] for s in sources() if s['file'] not in chosen]


def _mixed(paths, limit=None):
    """Films and series together, newest first (Kodi's date added), and how many in all."""
    films, film_total = _library('movie', limit, paths)
    shows, show_total = _library('series', limit, paths)
    found = sorted(films + shows, key=lambda card: card.get('_added') or '', reverse=True)
    return (found[:limit] if limit else found), film_total + show_total


def all_cards(job):
    """9.1.4: every title of a row on MegaNexus' own page, as Browse all does - Local media's or one folder's."""
    return _mixed(_paths(job))[0]


def _tile(path, label, addon=None):
    name = folder_name(path, label, addon)
    return {'title': name, 'plot': 'Everything in this folder.', 'subtitle': 'Folder', 'poster': '', 'fanart': '',
            'meta_line': '', 'is_folder': False, 'path': '', 'local': {'type': 'folder', 'path': path, 'name': name}}


def rows(job=('media',), limit=ROW_LIMIT):
    """Newest first, like a streaming row of recently added titles: Local media (its folder tiles first) or one
    folder's row; the last card opens all of them."""
    job = _job(job)
    addon = None
    chosen = folders(addon)
    tiles = []
    if job[0] == 'media' and chosen:
        labels = {s['file']: s.get('label') or '' for s in sources()}
        tiles = [_tile(path, labels.get(path), addon) for path in labels if (chosen.get(path) or {}).get('mode') == 'tile']
    cards, total = _mixed(_paths(job, addon), limit)
    if not cards and job[0] == 'media' and not chosen:
        # 7.0.29: nothing scanned by Kodi - the titles MegaNexus finds in the folders.
        from . import local_files
        files = local_files.cards('movie', limit) + local_files.cards('series', limit)
        if files:
            return files[:limit]
    name = TITLE if job[0] == 'media' else folder_name(job[1])
    if total > len(cards):
        cards.append({'title': 'All · %s' % name, 'plot': '%d titles - all of them here.' % total, 'subtitle': 'Browse all',
                      'poster': '', 'fanart': '', 'meta_line': '', 'is_folder': False, 'path': '',
                      'local': {'type': 'all', 'job': list(job), 'name': name}})
    return tiles + cards or [{'title': 'Nothing here yet', 'plot': 'Add a folder in HUB Settings > Local storage.', 'subtitle': 'Settings',
                              'poster': '', 'fanart': '', 'meta_line': '', 'is_folder': True,
                              'path': 'plugin://plugin.video.meganexus/?action=setup_center'}]


def seasons(tvshow_id):
    found = rpc('VideoLibrary.GetSeasons', {'tvshowid': int(tvshow_id), 'properties': ['season', 'episode', 'watchedepisodes', 'art'],
                                           'sort': {'method': 'season'}})
    return [s for s in found.get('seasons') or [] if s.get('episode')]


def episodes(tvshow_id, season=None):
    params = {'tvshowid': int(tvshow_id), 'properties': ['title', 'season', 'episode', 'plot', 'art', 'playcount', 'resume', 'runtime', 'firstaired'],
              'sort': {'method': 'episode'}}
    if season is not None:
        params['season'] = int(season)
    return rpc('VideoLibrary.GetEpisodes', params).get('episodes') or []


def next_episode(items):
    """Index of the episode to preselect: one in progress, else the first unwatched."""
    for index, item in enumerate(items):
        if _percent(item.get('resume')):
            return index
    for index, item in enumerate(items):
        if not item.get('playcount'):
            return index
    return 0


def resume_seconds(kind, item_id):
    method, key, field = (('VideoLibrary.GetMovieDetails', 'movieid', 'moviedetails') if kind == 'movie'
                          else ('VideoLibrary.GetEpisodeDetails', 'episodeid', 'episodedetails'))
    details = rpc(method, {key: int(item_id), 'properties': ['resume']}).get(field) or {}
    try:
        return float((details.get('resume') or {}).get('position') or 0)
    except (TypeError, ValueError):
        return 0.0


def play(kind, item_id, resume=True):
    """Play a library movie / episode; Kodi keeps its own resume point and watched mark."""
    key = 'movieid' if kind == 'movie' else 'episodeid'
    from .refresh_guard import release_all
    release_all()   # the TV's refresh rate is chosen as playback opens
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.Open',
                                                       'params': {'item': {key: int(item_id)}, 'options': {'resume': bool(resume)}}})))
    return not reply.get('error')


def scan():
    forget_counts()
    from . import local_files
    local_files.forget()
    xbmc.executebuiltin('UpdateLibrary(video)')


def clean():
    forget_counts()
    xbmc.executebuiltin('CleanLibrary(video)')


def sources():
    return [s for s in rpc('Files.GetSources', {'media': 'video'}).get('sources') or [] if s.get('file')]
