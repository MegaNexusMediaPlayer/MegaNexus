# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Idea 2026-11-18, MegaSport's matches: "lige favoriti live eventi sa rezultatima ... sve dinamicno".

ESPN's public site API (no key; what its own pages ask): the sports (17 - football, basketball, hockey, MMA, racing with
F1, tennis, rugby ...), each sport's leagues (its own list, in its order), a league's matches of the week as ESPN shows
them (results, live with the minute, the ones to come), its table, its teams. Nothing here is a list of ours: what
there is comes from ESPN.

At most PER_MINUTE requests a minute (the person: no more than 20 a minute), SLOTS of them at once; every answer is kept
in memory for FRESH[kind] seconds (a live match's league for under a minute) and forgotten when MegaSport closes
(forget()) - nothing on disk; the lists that change once a day (the sports, a sport's leagues) are kept in Kodi's
memory (Window(Home)) for the next opening.

Every sport ("svi sportovi moraju biti populirani ... i to mora radit super brzo"): board(sport) - football: every
league's matches by day (one request a day, SOCCER_DAYS); a sport ESPN's header answers for: all its leagues that play
now in one request; the others: their first LEAGUES_PER_SPORT leagues' scoreboards."""
import collections
import datetime
import gzip
import json
import re
import threading
import time
import urllib.error
import urllib.request

SPORTS = 'https://sports.core.api.espn.com/v2/sports?limit=100'
LEAGUES = 'https://site.web.api.espn.com/apis/site/v2/leagues/dropdown?lang=en&region=%s&calendartype=whitelist&limit=300&sport=%s'
EDITIONS = {'Europe': 'gb', 'Africa': 'gb', 'Asia': 'in', 'Australia': 'au', 'Pacific': 'au'}   # ESPN's own editions, by the box's time zone
WEEK = 'https://site.api.espn.com/apis/site/v2/sports/%s/%s/scoreboard'
TABLE = 'https://site.api.espn.com/apis/v2/sports/%s/%s/standings'
TEAMS = 'https://site.api.espn.com/apis/site/v2/sports/%s/%s/teams'
SCHEDULE = 'https://site.api.espn.com/apis/site/v2/sports/%s/%s/teams/%s/schedule'   # football: its results; ?fixture=true its next
FEATURED = 'https://site.api.espn.com/apis/v2/scoreboard/header'
SPORT_HEADER = 'https://site.web.api.espn.com/apis/v2/scoreboard/header?sport=%s'
SOCCER_DAY = 'https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=%s'
SOCCER_DAYS = (0, 1, -1, 2, 3)          # today first, then tomorrow, yesterday's results, two more days to come
LEAGUES_PER_SPORT = 2                   # a sport ESPN's header does not answer for: its first leagues' scoreboards
PER_MINUTE = 20
FOR_YOU = 4                             # of them kept for what the person waits for (a table, a team's matches): the
                                        # loading behind the screen takes at most PER_MINUTE - FOR_YOU a minute
SLOTS = 4                               # requests at once
FRESH = {'sports': 86400, 'leagues': 86400, 'teams': 86400, 'table': 1800, 'week': 600, 'live': 45, 'featured': 600,
         'header': 300, 'day': 600}
DAILY = ('sports', 'leagues')           # kept in Kodi's memory between openings
AGENT = 'Mozilla/5.0 (X11; Linux x86_64) MegaNexus'
TIMEOUT = 15
LIVE, BEFORE, OVER = 'in', 'pre', 'post'

_lock = threading.Lock()              # the kept answers and the ones on their way
_turn = threading.Lock()              # the minute's count
_slots = threading.BoundedSemaphore(SLOTS)
_asked = collections.deque()          # when the last requests went (the minute's)
_kept = {}                            # address -> (when, answer)
asked = collections.Counter()         # requests sent; seconds waited for the minute's turn (MegaSport's [perf] line)
_coming = {}                          # address -> Event: asked already, its answer on its way


def forget():
    _kept.clear()


def _wait_turn(urgent=False):
    """Until a request may go: at most PER_MINUTE in any minute - the loading behind the screen at most PER_MINUTE -
    FOR_YOU of them, so what the person waits for (``urgent``) goes at once (idea 2026-11-20: "tabele su super spore
    pri ucitavanju": the matches' loading had taken the minute)."""
    limit = PER_MINUTE if urgent else PER_MINUTE - FOR_YOU
    while True:
        with _turn:
            now = time.monotonic()
            while _asked and now - _asked[0] >= 60:
                _asked.popleft()
            if len(_asked) < limit:
                _asked.append(now)
                asked['requests'] += 1
                return
            wait = 60 - (now - _asked[len(_asked) - limit]) + .05      # until one of them is a minute old
            asked['waited'] += wait
        time.sleep(wait)


def _daily(url, data=None):
    """A daily list kept in Kodi's memory (Window(Home)) for the next opening: read (``data`` None) or kept."""
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        key = 'meganexus.espn.%08x' % (hash(url) & 0xffffffff)
        if data is not None:
            home.setProperty(key, json.dumps({'day': datetime.date.today().isoformat(), 'url': url, 'data': data}))
            return data
        kept = json.loads(home.getProperty(key) or '{}')
        return kept['data'] if kept.get('url') == url and kept.get('day') == datetime.date.today().isoformat() else None
    except Exception:
        return None


def _get(url, kind, urgent=False):
    """ESPN's answer to ``url`` - kept FRESH[kind] seconds; SLOTS requests at once, PER_MINUTE a minute at most (``urgent``:
    the person waits for it - _wait_turn); the same address asked twice at once goes once."""
    while True:
        with _lock:
            hit = _kept.get(url)
            if hit and time.monotonic() - hit[0] < FRESH[kind]:
                return hit[1]
            if kind in DAILY:
                daily = _daily(url)
                if daily is not None:
                    _kept[url] = (time.monotonic(), daily)
                    return daily
            coming = _coming.get(url)
            mine = coming is None
            if mine:
                coming = _coming[url] = threading.Event()
        if mine:
            break
        coming.wait(TIMEOUT + 5)               # its answer is kept now - or it failed: asked again
    try:
        _wait_turn(urgent)                     # waited for without a slot: the minute's limit holds none of them
        with _slots:
            with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': AGENT, 'Accept-Encoding': 'identity'}),
                                        timeout=TIMEOUT) as reply:
                body = reply.read()
        if body[:2] == b'\x1f\x8b':
            body = gzip.decompress(body)
        data = json.loads(body.decode('utf-8', 'replace'))
        with _lock:
            _kept[url] = (time.monotonic(), data)
        if kind in DAILY:
            _daily(url, data)
        return data
    finally:
        with _lock:
            _coming.pop(url, None)
        coming.set()


def _name(slug):
    return ' '.join(w.capitalize() for w in slug.replace('-', ' ').split())


def sports():
    """[(slug, name)] - the sports ESPN has, in its order."""
    data = _get(SPORTS, 'sports')
    out = []
    for item in data.get('items') or []:
        slug = (item.get('$ref') or '').split('/sports/')[-1].split('?')[0].strip('/')
        if slug and '/' not in slug:
            out.append((slug, _name(slug)))
    return out


def edition():
    """ESPN's edition for where this box is (its time zone's part of the world: Europe/Zagreb - the UK edition, which
    lists Europe's competitions first); else its US one."""
    import os
    try:
        zone = os.path.realpath('/etc/localtime').split('zoneinfo/')[-1]
    except OSError:
        zone = ''
    zone = os.environ.get('TZ', '').lstrip(':') or zone
    return EDITIONS.get(zone.split('/')[0], 'us')


def leagues(sport):
    """[(slug, name)] - ``sport``'s leagues, as ESPN's edition for this box lists them (the big ones first)."""
    data = _get(LEAGUES % (edition(), sport), 'leagues')
    return [(l['slug'], l.get('name') or l.get('shortName') or l['slug']) for l in data.get('leagues') or [] if l.get('slug')]


def leagues_with_tables(sport):
    """[(slug, name, logo)] - ``sport``'s leagues that have a table now (ESPN's list's own word: one request a day)."""
    data = _get(LEAGUES % (edition(), sport), 'leagues', urgent=True)
    return [(l['slug'], l.get('name') or l.get('shortName') or l['slug'], ((l.get('logos') or [{}])[0]).get('href') or '')
            for l in data.get('leagues') or [] if l.get('slug') and ((l.get('season') or {}).get('type') or {}).get('hasStandings')]


def has_table(sport, league):
    """ESPN says ``league`` has a table now (its list's own word: no request of its own)."""
    data = _get(LEAGUES % (edition(), sport), 'leagues')
    found = next((l for l in data.get('leagues') or [] if l.get('slug') == league), {})
    return bool(((found.get('season') or {}).get('type') or {}).get('hasStandings'))


def featured():
    """[(sport, league, name)] - the leagues ESPN puts first now (what plays this week, across its sports)."""
    data = _get(FEATURED, 'featured')
    return [(sport.get('slug'), league.get('slug'), league.get('name') or league.get('abbreviation') or league.get('slug'))
            for sport in data.get('sports') or [] for league in sport.get('leagues') or [] if sport.get('slug') and league.get('slug')]


def playing(sport, count, days=(-2, 7)):
    """The first ``count`` of ``sport``'s leagues (ESPN's order) with a match from ``days[0]`` to ``days[1]`` days from now
    - the big ones that play now (a World Cup between its tournaments does not)."""
    now = datetime.datetime.now(datetime.timezone.utc)
    out = []
    for slug, name in leagues(sport)[:count * 3]:
        if len(out) >= count:
            break
        try:
            matches = week(sport, slug)[0]
        except Exception:
            continue
        if any(m['start'] and days[0] <= (m['start'] - now).total_seconds() / 86400 <= days[1] for m in matches):
            out.append((sport, slug, name))
    return out


_ISO = re.compile(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?(Z|[+-]\d{2}:?\d{2})?$')


def _when(text):
    """ESPN's '2026-11-24T20:00Z' (seconds, an offset maybe) as a time. Not strptime: in Kodi's second Python script
    and on it, strptime raises "'NoneType' object is not callable" (its _strptime module is the first script's, gone)
    - on the Cube every match failed and MegaSport stayed empty (18 Nov 2026)."""
    found = _ISO.match((text or '').strip())
    if not found:
        return None
    year, month, day, hour, minute, second, zone = found.groups()
    offset = datetime.timezone.utc
    if zone and zone != 'Z':
        sign = -1 if zone[0] == '-' else 1
        offset = datetime.timezone(sign * datetime.timedelta(hours=int(zone[1:3]), minutes=int(zone[-2:])))
    try:
        return datetime.datetime(int(year), int(month), int(day), int(hour), int(minute), int(second or 0), tzinfo=offset)
    except ValueError:
        return None


def _side(competitor):
    team = competitor.get('team') or competitor.get('athlete') or {}
    score = competitor.get('score')
    if isinstance(score, dict):
        score = score.get('displayValue') or score.get('value')
    logo = team.get('logo') or ((team.get('logos') or [{}])[0].get('href')) or (team.get('flag') or {}).get('href') or ''
    return {'id': str(team.get('id') or competitor.get('id') or ''), 'name': team.get('displayName') or team.get('fullName') or team.get('name') or '',
            'short': team.get('shortDisplayName') or team.get('shortName') or '', 'abbr': team.get('abbreviation') or '',
            'logo': logo, 'score': '' if score is None else str(score), 'home': competitor.get('homeAway') == 'home',
            'winner': bool(competitor.get('winner')), 'order': competitor.get('order') or 0}


def event(raw, sport, league, league_name='', league_logo=''):
    """One of ESPN's events as MegaSport's match: who, when, how it stands."""
    comp = (raw.get('competitions') or [{}])[0]
    status = raw.get('status') or comp.get('status') or {}
    kind = status.get('type') or {}
    sides = sorted((_side(c) for c in comp.get('competitors') or []), key=lambda s: s['order'])
    pair = len(sides) == 2
    if pair:
        sides.sort(key=lambda s: not s['home'])            # the home side first
    channels = []
    for b in comp.get('broadcasts') or []:
        channels += [n for n in b.get('names') or [] if n not in channels]
    for b in comp.get('geoBroadcasts') or []:
        name = ((b.get('media') or {}).get('shortName') or '').strip()
        if name and name not in channels:
            channels.append(name)
    venue = comp.get('venue') or {}
    return {'id': str(raw.get('id') or ''), 'sport': sport, 'league': league, 'league_name': league_name, 'league_logo': league_logo,
            'name': raw.get('name') or raw.get('shortName') or '', 'short': raw.get('shortName') or '',
            'start': _when(raw.get('date') or ''), 'state': kind.get('state') or BEFORE, 'detail': kind.get('shortDetail') or kind.get('detail') or '',
            'clock': status.get('displayClock') or '', 'period': status.get('period') or 0, 'completed': bool(kind.get('completed')),
            'sides': sides, 'pair': pair, 'channels': channels,
            'venue': ', '.join(x for x in (venue.get('fullName'), (venue.get('address') or {}).get('city')) if x)}


def _league_index(sport):
    """{ESPN's league id: (slug, name, logo)} - its list for this box's edition."""
    data = _get(LEAGUES % (edition(), sport), 'leagues')
    return {str(l.get('id')): (l['slug'], l.get('name') or l.get('shortName') or l['slug'], ((l.get('logos') or [{}])[0]).get('href') or '')
            for l in data.get('leagues') or [] if l.get('slug')}


def _season_name(slug):
    """'2026-27-english-premier-league' -> 'English Premier League' (a league ESPN's list for this edition lacks)."""
    words = [w for w in (slug or '').split('-') if not w.isdigit()]
    return ' '.join(w.capitalize() for w in words)


def soccer_day(offset):
    """Every football league's matches on the day ``offset`` days from today (ESPN's all-leagues scoreboard)."""
    day = (datetime.datetime.now().astimezone() + datetime.timedelta(days=offset)).strftime('%Y%m%d')
    data = _get(SOCCER_DAY % day, 'live' if offset == 0 else 'day')
    index = _league_index('soccer')
    out = []
    for raw in data.get('events') or []:
        league_id = next((part[2:] for part in str(raw.get('uid') or '').split('~') if part.startswith('l:')), '')
        season = (raw.get('season') or {}).get('slug') or ''
        slug, name, logo = index.get(league_id) or (season or league_id, _season_name(season), '')
        out.append(event(raw, 'soccer', slug, name, logo))
    return out


def header_event(raw, sport, league, league_name='', league_logo=''):
    """An event of ESPN's header (its sides at its top) as a scoreboard's - then event()."""
    sides = [{'team': {'id': c.get('id'), 'displayName': c.get('displayName') or c.get('name'), 'shortDisplayName': c.get('shortDisplayName'),
                       'abbreviation': c.get('abbreviation'), 'logo': c.get('logo') or ''},
              'score': c.get('score'), 'homeAway': c.get('homeAway'), 'winner': c.get('winner'), 'order': c.get('order') or 0}
             for c in raw.get('competitors') or []]
    competition = {'competitors': sides, 'venue': {'fullName': raw.get('location') or ''},
                   'broadcasts': [{'names': [raw['broadcast']]}] if raw.get('broadcast') else []}
    return event({'id': raw.get('id'), 'name': raw.get('name'), 'shortName': raw.get('shortName'), 'date': raw.get('date'),
                  'status': raw.get('fullStatus') or {}, 'competitions': [competition]}, sport, league, league_name, league_logo)


def board(sport, live=False):
    """``sport``'s matches now - its leagues that play, their results, the live ones, the ones to come."""
    if sport == 'soccer':
        out = []
        for offset in SOCCER_DAYS:
            try:
                out += soccer_day(offset)
            except Exception:
                continue
        return out
    marker = 'noheader:%s' % sport                   # ESPN's header does not answer for it (400): not asked again today
    data = {}
    if _daily(marker) is None:
        try:
            data = _get(SPORT_HEADER % sport, 'live' if live else 'header')
        except urllib.error.HTTPError:
            _daily(marker, {})
    found = [l for s in data.get('sports') or [] for l in s.get('leagues') or [] if l.get('events')]
    if not found:                                    # what ESPN puts first now, of it (the NBA, the NFL ...)
        try:
            top = _get(FEATURED, 'live' if live else 'featured')
        except Exception:
            top = {}
        found = [l for s in top.get('sports') or [] if s.get('slug') == sport for l in s.get('leagues') or [] if l.get('events')]
        shown = {l.get('slug') for l in found}
        out = _from_header(sport, found)
        more = [slug for slug, _ in leagues(sport) if slug not in shown][:LEAGUES_PER_SPORT]   # the next ones on ESPN's list
        for slug in more:
            try:
                out += week(sport, slug, live=live)[0]
            except Exception:
                continue
        return out
    return _from_header(sport, found)


def _from_header(sport, found):
    """Matches of a header's leagues (their names and logos from ESPN's list of the sport's leagues)."""
    if found:
        try:
            index = {slug: (name, logo) for slug, name, logo in _league_index(sport).values()}
        except Exception:
            index = {}
        out = []
        for l in found:
            slug = l.get('slug') or str(l.get('id') or '')
            name, logo = index.get(slug) or (l.get('name') or l.get('abbreviation') or slug, '')
            out += [header_event(raw, sport, slug, name, logo) for raw in l.get('events') or []]
        return out
    return []


def week(sport, league, live=False):
    """``league``'s matches as ESPN shows them now - the week's results, the live ones, the ones to come - and its
    name and logo; ``live``: asked again within a minute (a match of it is on)."""
    data = _get(WEEK % (sport, league), 'live' if live else 'week')
    about = (data.get('leagues') or [{}])[0]
    name = about.get('name') or about.get('abbreviation') or league
    logo = ((about.get('logos') or [{}])[0]).get('href') or ''
    return [event(raw, sport, league, name, logo) for raw in data.get('events') or []], name, logo


def table(sport, league, urgent=True):
    """``league``'s table(s): [{'name', 'rows': [{'rank', 'team', 'logo', 'played', 'won', 'drawn', 'lost', 'diff',
    'for', 'against', 'points', 'id', 'zone', 'zone_colour'}]}] - a group's own table each (a conference, a group of a
    cup); a zone is ESPN's note on the place (Champions League, relegation) and its colour. ``urgent``: asked as the
    person waits (MegaSport's prefetch of the Tables screen's first ones is not)."""
    data = _get(TABLE % (sport, league), 'table', urgent)
    groups = data.get('children') or ([data] if data.get('standings') else [])
    out = []
    for group in groups:
        entries = (group.get('standings') or {}).get('entries') or []
        rows = []
        for entry in entries:
            team = entry.get('team') or {}
            stats = {s.get('name'): s.get('displayValue') or str(s.get('value', '')) for s in entry.get('stats') or []}
            note = entry.get('note') or {}
            rows.append({'id': str(team.get('id') or ''), 'team': team.get('displayName') or team.get('name') or '',
                         'logo': ((team.get('logos') or [{}])[0]).get('href') or '', 'rank': stats.get('rank') or str(len(rows) + 1),
                         'played': stats.get('gamesPlayed', ''), 'won': stats.get('wins', ''), 'drawn': stats.get('ties', ''),
                         'lost': stats.get('losses', ''), 'diff': stats.get('pointDifferential') or stats.get('differential', ''),
                         'for': stats.get('pointsFor', ''), 'against': stats.get('pointsAgainst', ''),
                         'points': stats.get('points') or stats.get('winPercent', ''),
                         'zone': note.get('description') or '', 'zone_colour': (note.get('color') or '').lstrip('#')})
        try:
            rows.sort(key=lambda r: int(r['rank']))
        except ValueError:
            pass
        if rows:
            out.append({'name': group.get('name') or '', 'rows': rows})
    return out


def team_schedule(sport, league, team_id, count=5):
    """(the next ``count`` matches, the last ``count`` results - the newest first) of a team (ESPN's schedule: a football
    team's results and its fixtures are two answers, another sport's season is one)."""
    base = SCHEDULE % (sport, league, team_id)
    answers = [_get(base, 'week', True)] + ([_get(base + '?fixture=true', 'week', True)] if sport == 'soccer' else [])
    found = {}
    for data in answers:
        team = data.get('team') or {}
        name = (data.get('season') or {}).get('displayName') or ''
        for raw in data.get('events') or []:
            match = event(raw, sport, league, ((raw.get('league') or {}).get('name')) or name or team.get('displayName') or '')
            found[match['id']] = match
    far = datetime.datetime.max.replace(tzinfo=datetime.timezone.utc)
    near = datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)
    coming = sorted((m for m in found.values() if m['state'] != OVER), key=lambda m: m['start'] or far)[:count]
    done = sorted((m for m in found.values() if m['state'] == OVER), key=lambda m: m['start'] or near, reverse=True)[:count]
    return coming, done


def teams(sport, league):
    """[{'id', 'name', 'logo'}] - ``league``'s teams, by name."""
    data = _get(TEAMS % (sport, league), 'teams')
    found = []
    for block in (data.get('sports') or [{}])[0].get('leagues') or [{}]:
        for item in block.get('teams') or []:
            team = item.get('team') or {}
            found.append({'id': str(team.get('id') or ''), 'name': team.get('displayName') or team.get('name') or '',
                          'logo': ((team.get('logos') or [{}])[0]).get('href') or ''})
    return sorted((t for t in found if t['id']), key=lambda t: t['name'].lower())


def is_live(match):
    return match.get('state') == LIVE


def soon(match, minutes=15, now=None):
    """Starts within ``minutes`` (its league is then asked as a live one)."""
    start, now = match.get('start'), now or datetime.datetime.now(datetime.timezone.utc)
    return match.get('state') == BEFORE and start is not None and 0 <= (start - now).total_seconds() <= minutes * 60
