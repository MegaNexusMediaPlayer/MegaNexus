# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Kodi's YouTube add-on fixed in place for MPEG-DASH (idea 2026-11-20: "za youtube bi napravio skriptu koja mijenja addon
i popravi ovu gresku ... na svakom updateu addona ... se aktivira ponovo ... jer yt addon ne valja i ne radi dash i 4k a to
nam isto treba").

Its 7.4.4 takes DASH formats from its ANDROID_VR client too, and YouTube refuses their ranges past about 60 s (HTTP 403 -
the add-on's issues #1481 and #1483, open): a DASH video stalled, and on a Fire TV Cube the box froze on leaving it, so
MegaNexus held the add-on on Steady playback, and Steady's HLS has no picture with CoreELEC's inputstream.adaptive 21.
The fix the add-on's users found (#1483): that client gives no adaptive formats - '_use_adaptive': False, which the
add-on itself honours (player_client.py skips such a client's formats) - while it still serves the rest (history).

Written into the add-on's request_client.py as one marked line; once per its files - an update brings the file back as
it was, and ensure() writes it again; a file of another shape (the client gone, or the add-on's own setting there) is
left alone. Nothing else of the add-on is touched.
"""
import os
import re

ADDON_ID = 'plugin.video.youtube'
TARGET = ('resources', 'lib', 'youtube_plugin', 'youtube', 'client', 'request_client.py')
MARK = "'_use_adaptive': False,  # MegaNexus: no DASH from android_vr - YouTube refuses it past ~60 s (the add-on's #1483)"
CLIENT = re.compile(r"\n(?P<indent>[ \t]*)'android_vr': \{\n")
ANCHOR = re.compile(r"\n(?P<indent>[ \t]*)'_use_subtitles': False,\n")


def target(folder=None):
    """The add-on's request_client.py ('' when the add-on is not here)."""
    if folder is None:
        import xbmcvfs
        folder = xbmcvfs.translatePath('special://home/addons/%s' % ADDON_ID)
    path = os.path.join(folder, *TARGET)
    return path if os.path.isfile(path) else ''


def patched(text):
    """``text`` with the fix in the android_vr client, or None: there already, or a file of another shape."""
    if MARK in text:
        return None
    client = CLIENT.search(text)
    if not client:
        return None
    end = text.find('\n%s},' % client.group('indent'), client.end())       # the client's own closing brace
    if end < 0:
        return None
    block = text[client.end():end]
    if "'_use_adaptive'" in block:
        return None                     # the add-on decides it itself now
    anchor = ANCHOR.search('\n' + block)
    if not anchor:
        return None
    at = client.end() + anchor.end() - 1
    return text[:at] + anchor.group('indent') + MARK + '\n' + text[at:]


def ensure(folder=None, log=None):
    """The fix in the add-on: 'written' (just now - a new or updated add-on), 'kept' (already there), None (no add-on,
    or a file it does not fit)."""
    path = target(folder)
    if not path:
        return None
    try:
        with open(path, encoding='utf-8') as handle:
            text = handle.read()
    except OSError:
        return None
    if MARK in text:
        return 'kept'
    new = patched(text)
    if new is None:
        return None
    temp = '%s.%d.tmp' % (path, os.getpid())
    try:
        with open(temp, 'w', encoding='utf-8') as handle:
            handle.write(new)
        os.chmod(temp, os.stat(path).st_mode & 0o777)
        os.replace(temp, path)
    except OSError:
        try:
            os.remove(temp)
        except OSError:
            pass
        return None
    if log:
        log('[MegaNexus] YouTube add-on: MPEG-DASH fix written (no adaptive formats from its android_vr client)')
    return 'written'
