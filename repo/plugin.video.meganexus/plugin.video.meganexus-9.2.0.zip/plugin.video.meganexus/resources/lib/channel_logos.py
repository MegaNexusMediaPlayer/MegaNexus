# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A logo for an IPTV channel that has none (MegaIPTV, idea 2026-11-17).

"kanali koji nemaju logo moras pretraziti githube i viditi koje besplatne stranice daju imena kanala da se ucitaju i
loga sve mora dinamicki raditi": the tv-logo/tv-logos project (github.com/tv-logo/tv-logos, free to use) keeps channel
logos by country, a file each named after the channel and its country (countries/croatia/arena-sport-1-hr.png). The
countries a list speaks of are read from its channels' and groups' names (HR, RS, EX-YU ...); each country's names come
from its overview page (0_all_logos_mosaic.md, from GitHub's raw files - no API, no key), asked once while MegaIPTV
is open and kept in memory only. A channel's name without its country and picture-quality words is matched to them.
"""
import re
import threading
import unicodedata
from urllib.request import Request, urlopen

BASE = 'https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/'
TIMEOUT = 15
# country words in a list's names -> (folder, the files' suffix)
COUNTRIES = {
    'hr': ('croatia', 'hr'), 'cro': ('croatia', 'hr'), 'rs': ('serbia', 'rs'), 'srb': ('serbia', 'rs'), 'sr': ('serbia', 'rs'), 'si': ('slovenia', 'si'),
    'slo': ('slovenia', 'si'), 'de': ('germany', 'de'), 'ger': ('germany', 'de'), 'at': ('austria', 'at'), 'ch': ('switzerland', 'ch'),
    'uk': ('united-kingdom', 'uk'), 'gb': ('united-kingdom', 'uk'), 'us': ('united-states', 'us'), 'usa': ('united-states', 'us'),
    'it': ('italy', 'it'), 'fr': ('france', 'fr'), 'es': ('spain', 'es'), 'pt': ('portugal', 'pt'), 'nl': ('netherlands', 'nl'),
    'be': ('belgium', 'be'), 'pl': ('poland', 'pl'), 'cz': ('czech-republic', 'cz'), 'sk': ('slovakia', 'sk'), 'hu': ('hungary', 'hu'),
    'ro': ('romania', 'ro'), 'bg': ('bulgaria', 'bg'), 'gr': ('greece', 'gr'), 'tr': ('turkey', 'tr'), 'al': ('albania', 'al'),
    'ie': ('ireland', 'ie'), 'il': ('israel', 'il'), 'ru': ('russia', 'ru'), 'ua': ('ukraine', 'ua'), 'ca': ('canada', 'ca'),
    'au': ('australia', 'au'), 'br': ('brazil', 'br'), 'mx': ('mexico', 'mx'), 'ar': ('argentina', 'ar'), 'in': ('india', 'in'),
}
REGIONS = {'exyu': ('hr', 'rs', 'si'), 'balkan': ('hr', 'rs', 'si'), 'yu': ('hr', 'rs', 'si'), 'ba': ('hr', 'rs'), 'bih': ('hr', 'rs'),
           'mk': ('rs',), 'me': ('rs',), 'cg': ('rs',)}
ALWAYS = (('international', 'int'), ('world-europe', 'eu'))
QUALITY = {'hd', 'fhd', 'uhd', '4k', '8k', 'sd', 'hq', 'hevc', 'h265', 'h264', 'raw', 'backup', 'live', 'vip', 'multi', '50fps', '60fps'}
_NAMES = {}                  # folder -> {name}
_LOCK = threading.Lock()


def _fold(text):
    text = str(text or '').translate(str.maketrans({'đ': 'd', 'Đ': 'd', 'ß': 'ss', 'ø': 'o', 'ł': 'l'}))
    return ''.join(c for c in unicodedata.normalize('NFKD', text) if not unicodedata.combining(c)).lower()


def words(text):
    return [w for w in re.split(r'[^0-9a-z]+', _fold(text).replace('&', ' and ').replace('+', ' plus ')) if w]


def countries(texts):
    """[(folder, suffix)] the names speak of (their country words), the world's folders last."""
    found = []
    for text in texts:
        for word in words(text):
            for code in REGIONS.get(word, (word,)):
                place = COUNTRIES.get(code)
                if place and place not in found:
                    found.append(place)
    return found + [place for place in ALWAYS if place not in found]


def slug(name):
    """A channel's name as the logos' names are written: no country words, no picture-quality words."""
    skip = set(QUALITY) | set(COUNTRIES) | set(REGIONS)
    return '-'.join(w for w in words(name) if w not in skip)


def _names(folder, opener=None):
    with _LOCK:
        if folder in _NAMES:
            return _NAMES[folder]
    try:
        request = Request(BASE + folder + '/0_all_logos_mosaic.md', headers={'User-Agent': 'MegaNexus/9'})
        with (opener or (lambda r: urlopen(r, timeout=TIMEOUT)))(request) as response:
            page = response.read().decode('utf-8', 'replace')
        found = set(re.findall(r'!\[([a-z0-9-]+)\]', page)) - {'space'}
    except Exception:
        found = set()
    with _LOCK:
        _NAMES[folder] = found
    return found


def find(name, hints=(), opener=None):
    """The logo of channel ``name`` (``hints``: other names of the list - its groups - that tell its countries), or ''."""
    wanted = slug(name)
    if not wanted:
        return ''
    tries = [wanted, wanted + '-hd', wanted + '-tv', wanted[:-3] if wanted.endswith('-tv') else '']
    for folder, suffix in countries([name] + list(hints)):
        known = _names(folder, opener)
        for candidate in tries:
            if candidate and candidate in known:
                return '%s%s/%s-%s.png' % (BASE, folder, candidate, suffix)
    return ''


def forget():
    with _LOCK:
        _NAMES.clear()
