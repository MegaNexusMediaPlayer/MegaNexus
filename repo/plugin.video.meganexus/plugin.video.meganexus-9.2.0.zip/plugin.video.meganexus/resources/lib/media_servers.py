# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Plex, Jellyfin and Emby in MegaNexus (6.0.39, beta; Jellyfin and Emby separate since 7.0.29).

Everything is OFF until the user signs in and turns the server on (HUB
Settings > Accounts > Plex / Jellyfin): no request, no import of the server
clients, no row. When on:

* Sources: when a title is played, the user's own servers are searched by its
  IMDb / TMDb ID (episode by season and number) at the same time as the
  stream add-ons, and their copies come FIRST in the list ("Plex · <server>"),
  so autoplay prefers the own copy. Playback reports progress and watched
  back to the server (companion reporters).
* Home rows: "<Server> · Continue watching" and "<Server> · Recently added"
  (Home rows switch, off by default). Posters come from the server itself,
  resized there; MegaNexus metadata is used only to open the title page of a
  title that has an IMDb / TMDb ID, never to download a second poster.
"""
from collections import namedtuple
import time

PLEX, JELLYFIN, EMBY = 'plex', 'jellyfin', 'emby'
# 7.0.29: Jellyfin and Emby are separate connections (both may be on).
KINDS = (PLEX, JELLYFIN, EMBY)
ENABLED = {PLEX: 'meganexus_plex_enabled', JELLYFIN: 'meganexus_jellyfin_enabled', EMBY: 'meganexus_emby_enabled'}
SOURCES = {PLEX: 'plex_in_sources', JELLYFIN: 'emby_in_sources', EMBY: 'emby_server_in_sources'}
SOURCE_ID = {PLEX: '__plex__', JELLYFIN: '__emby__', EMBY: '__emby__'}   # one Emby-protocol source id (special-cased in the scan)
MAX_VERSIONS = 3


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_snapshot import cached_addon
    return cached_addon()


def _setting(addon, key, default=''):
    try:
        return addon.getSetting(key) or default
    except Exception:
        return default


def signed_in(kind):
    try:
        if kind == PLEX:
            from . import plex
            return plex.is_signed_in()
        from . import mediabrowser
        return mediabrowser.is_signed_in(kind)
    except Exception:
        return False


def enabled(kind, addon=None):
    """On only after sign-in AND the switch (default off)."""
    return _setting(_addon(addon), ENABLED[kind]) == 'true' and signed_in(kind)


def switch_on(kind, addon=None):
    """7.0.29: a server just connected is used in MegaNexus - connected but switched off looked like "nothing
    there". 9.1.4: its titles are in its own HUB app (media_apps), no longer rows on MegaNexus' Home."""
    addon = _addon(addon)
    addon.setSetting(ENABLED[kind], 'true')
    forget()


def label(kind):
    return {PLEX: 'Plex', JELLYFIN: 'Jellyfin', EMBY: 'Emby'}[kind]


def status(kind):
    """Short account line for Settings (no network)."""
    if not signed_in(kind):
        return 'Not connected'
    try:
        if kind == PLEX:
            from . import plex
            user = plex.account().get('username') or 'connected'
            return 'Connected · %s' % user
        from . import mediabrowser
        auth = mediabrowser.account(kind)
        return 'Connected · %s · %s' % (auth.get('server_name') or label(kind), auth.get('username') or '')
    except Exception:
        return 'Connected'


# ------------------------------------------------------------------ sources --

def parse_video_id(media_type, video_id):
    """'tt1:2:3' / 'tmdb:5:2:3' -> ({'imdb_id'|'tmdb_id': ...}, season, episode)."""
    parts = str(video_id or '').split(':')
    if parts and parts[0] == 'tmdb' and len(parts) > 1:
        ids, rest = {'tmdb_id': parts[1]}, parts[2:]
    elif parts and parts[0].startswith('tt'):
        ids, rest = {'imdb_id': parts[0]}, parts[1:]
    else:
        return None, None, None
    if media_type == 'series':
        try:
            return ids, int(rest[0]), int(rest[1])
        except (IndexError, TypeError, ValueError):
            return None, None, None   # a series without an episode is not playable
    return ids, None, None


_IMDB_KEYS = ('imdb_id', 'imdb', 'imdbId')
_TMDB_KEYS = ('tmdb_id', 'tmdb', 'tmdbId')
_TVDB_KEYS = ('tvdb_id', 'tvdb', 'tvdbId')
_SERIES_WORDS = ('series', 'show', 'tv', 'episode')


class LookupTarget(namedtuple('LookupTarget', 'media_type ids season episode')):
    """What one server is asked for. ``ids`` always holds all three keys, '' when unknown."""
    __slots__ = ()

    @property
    def is_episode(self):
        return self.media_type == 'series' and self.season is not None and self.episode is not None


def _one_spelling(ids, keys):
    for key in keys:
        value = str((ids or {}).get(key) or '').strip()
        if value:
            return value
    return ''


def _number(value):
    try:
        return int(value) if value not in (None, '') else None
    except (TypeError, ValueError):
        return None               # 'pilot' is not a season: no episode rather than a crash


def lookup_target(media_type, ids=None, season=None, episode=None):
    """The ids and kind a server lookup is built from, under one spelling each.

    An add-on may spell an id three ways ('imdb_id', 'imdb', 'imdbId') and may send the
    IMDb number without its 'tt'; the servers are asked with one spelling only.
    """
    imdb = _one_spelling(ids, _IMDB_KEYS).lower()
    return LookupTarget(
        'series' if str(media_type or '').strip().lower() in _SERIES_WORDS else 'movie',
        {'imdb_id': 'tt' + imdb if imdb.isdigit() else imdb,
         'tmdb_id': _one_spelling(ids, _TMDB_KEYS),
         'tvdb_id': _one_spelling(ids, _TVDB_KEYS)},
        _number(season), _number(episode))


def _plex_rows(ids, media_type, season, episode):
    from . import plex
    from . import server_health as health
    rows = []
    for server in plex.servers() or []:
        if not health.should_query('plex', server):
            continue
        try:
            found = plex.all_by_ids(server, ids, media_type=media_type, title='', limit=3)
            if season is not None:
                found = [e for e in (plex.episode_node_item(server, show, season, episode) for show in found[:1]) if e]
        except Exception:
            continue
        for item in found:
            # Since 2025/2026 Plex needs Plex Pass or Remote Watch Pass to stream
            # outside the home network; say so instead of a bare failure.
            away = not plex.is_local_connection(server, item.get('server_url'))
            for version in [v for v in (item.get('versions') or []) if v.get('part_key')][:MAX_VERSIONS]:
                name = 'Plex · %s' % (item.get('server_name') or 'Server')
                title = version.get('info_line') or version.get('version_label') or 'Direct play'
                rows.append({
                    'name': name, 'title': title + (' · away from home: needs Plex Pass or Remote Watch Pass' if away else ''),
                    'url': plex.playback_url(item, version['part_key']),
                    'subtitles': list(version.get('subtitles') or []),
                    '_meganexus_source': {'id': SOURCE_ID[PLEX], 'name': name, 'base_url': ''},
                    '_meganexus_server': {'server_type': 'plex', 'server_url': item.get('server_url') or '',
                                      'token': item.get('token') or '', 'rating_key': str(item.get('rating_key') or ''),
                                      'client_id': plex.client_identifier(), 'product': 'MegaNexus',
                                      'device_name': 'Kodi', 'duration_ms': int(item.get('duration_ms') or 0)},
                })
    return rows


def _jellyfin_rows(ids, media_type, season, episode, kind=JELLYFIN):
    from . import mediabrowser
    rows = []
    for server in mediabrowser.servers(kind) or []:
        try:
            found = mediabrowser.all_by_ids(server, ids, media_type=media_type, title='', limit=3)
            if season is not None:
                found = [e for e in (mediabrowser.episode_node_item(server, show, season, episode) for show in found[:1]) if e]
        except Exception:
            continue
        for item in found:
            for version in (item.get('versions') or [{}])[:MAX_VERSIONS]:
                try:
                    resolved = mediabrowser.playable_of(server, item['rating_key'], version.get('media_source_id') or '')
                except Exception:
                    continue
                version = resolved.get('version') or version
                name = '%s · %s' % (label(kind), server.get('name') or 'Server')
                rows.append({
                    'name': name, 'title': version.get('info_line') or version.get('version_label') or 'Direct play',
                    'url': resolved['url'], 'subtitles': list(version.get('subtitles') or []),
                    '_meganexus_source': {'id': SOURCE_ID[kind], 'name': name, 'base_url': ''},
                    '_meganexus_server': {'server_type': 'emby', 'server_url': server.get('url') or '',
                                      'server_flavor': mediabrowser.flavor_of(server), 'token': server.get('token') or '',
                                      'item_id': str(item['rating_key']), 'device_id': mediabrowser.device_id(),
                                      'session_id': resolved.get('play_session_id') or '',
                                      'play_session_id': resolved.get('play_session_id') or '',
                                      'media_source_id': resolved.get('media_source_id') or '',
                                      'duration_ms': int(item.get('duration_ms') or 0)},
                })
    return rows


def source_jobs(media_type, video_id, addon=None):
    """[(name, fn)] - one job per enabled server kind; [] costs nothing."""
    addon = _addon(addon)
    ids, season, episode = parse_video_id(media_type, video_id)
    if not ids:
        return []
    jobs = []
    for kind, fn in ((PLEX, _plex_rows), (JELLYFIN, _jellyfin_rows), (EMBY, _jellyfin_rows)):
        if _setting(addon, SOURCES[kind], 'true') != 'false' and enabled(kind, addon):
            if kind == PLEX:
                jobs.append((label(kind), lambda fn=fn: fn(ids, media_type, season, episode)))
            else:
                jobs.append((label(kind), lambda fn=fn, kind=kind: fn(ids, media_type, season, episode, kind)))
    return jobs


def playback_keys(row):
    """Server reporting keys for the playback context of a server row."""
    keys = dict(row.get('_meganexus_server') or {})
    if keys.get('server_type') == 'plex':
        try:
            from .settings_snapshot import cached_addon
            keys['product_version'] = cached_addon().getAddonInfo('version') or ''
        except Exception:
            pass
    return keys


# ------------------------------------------------------------------- cards --
# 9.1.4: the HUB's Plex, Jellyfin and Emby apps (media_apps) draw these; MegaNexus' Home has no server rows any more

def _target(ids, media_type, title, poster, fanart):
    imdb = str(ids.get('imdb_id') or '')
    canonical = imdb if imdb.startswith('tt') else ('tmdb:%s' % ids['tmdb_id'] if ids.get('tmdb_id') else '')
    if not canonical:
        return None
    return dict(media_type=media_type, canonical_id=canonical, title=title, source_provider_id='',
                season='', episode='', video_id='', tmdb_id=ids.get('tmdb_id') or '', imdb_id=imdb,
                tvdb_id=ids.get('tvdb_id') or '', ui_seed={'poster': poster, 'fanart': fanart, 'clearlogo': ''})


def _card(kind, item, poster, fanart, play_path, resume_ms=0):
    media = item.get('media_type')
    title = item.get('raw_title') or item.get('title') or 'Untitled'
    if media == 'episode':
        show = item.get('show_title') or ''
        title = '%s · S%s E%s' % (show, item.get('season') or 0, item.get('index') or 0) if show else title
    duration = int(item.get('duration_ms') or 0)
    percent = int(resume_ms * 100 / duration) if resume_ms and duration else 0
    year = str(item.get('year') or '') if item.get('year') else ''
    card = {'title': title, 'subtitle': ('%d%% watched' % percent) if percent else year,
            'plot': item.get('summary') or '', 'poster': poster, 'fanart': fanart, 'landscape': fanart,
            'clearlogo': '', 'percent_value': percent,
            'meta_line': '  |  '.join(x for x in (year, 'Series' if media in ('show', 'episode') else 'Movie', label(kind)) if x),
            'path': '', 'is_folder': False}
    target = _target(item.get('ids') or {}, 'series' if media == 'show' else 'movie', title, poster, fanart) \
        if media in ('movie', 'show') else None
    if target and not percent:
        card['target'] = target          # opens the MegaNexus title page (server copy is the first source)
    else:
        card['server_play'] = play_path  # episodes, resumes and unidentified titles play from the server
    return card


def plex_card(item):
    """A Plex item as a card (Home's rows, 9.1.4: the Plex app's): its poster, its backdrop, its place."""
    from . import plex
    thumb = item.get('parent_thumb') if item.get('media_type') == 'episode' and item.get('parent_thumb') else item.get('thumb')
    play = 'plugin://plugin.video.meganexus/?action=plex_play&server_id=%s&rating_key=%s' % (
        item.get('server_id'), item.get('rating_key'))
    return _card(PLEX, item, plex.poster_url(item, thumb), plex.poster_url(item, item.get('art'), 1280, 720),
                 play, item.get('view_offset_ms') or 0)


def mediabrowser_card(kind, server, item):
    """A Jellyfin / Emby item as a card (Home's rows, 9.1.4: the apps'): an episode shows its series' pictures."""
    from . import mediabrowser
    image = item.get('series_id') if item.get('media_type') == 'episode' and item.get('series_id') else item.get('rating_key')
    play = 'plugin://plugin.video.meganexus/?action=emby_play&item_id=%s&flavor=%s' % (item.get('rating_key'), kind)
    return _card(kind, item, mediabrowser.artwork_url(server, image),
                 mediabrowser.artwork_url(server, image, kind='Backdrop'), play, item.get('resume_ms') or 0)


def forget():
    """What the apps keep of the servers (a server switched on or off, signed in or out)."""
    from . import media_apps
    media_apps.forget()
