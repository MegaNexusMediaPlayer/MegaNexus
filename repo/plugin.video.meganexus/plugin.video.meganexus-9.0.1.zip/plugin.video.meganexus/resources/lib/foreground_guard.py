# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A MegaNexus film never plays behind Home (7.0.29).

Sometimes a film started but Kodi did not switch to its full-screen video:
it played on behind Home and could not be left. And Back from the player
left the film running under the HUB. The service watches a MegaNexus film
(Window(Home).Property(meganexus.playing.request_id)):

* not on screen 4 s after it started (Back / Esc pressed while it loaded) - it
  is paused and the HUB offers "Now playing" to carry on in full screen;
* the player left for Home or the HUB for 1 s - the film is stopped (its
  progress is saved as on any stop);
* the player's Home button (park) - the film plays on behind Home and "Now
  playing" brings it back to full screen.

Dialogs over the player (sources, subtitles, audio, info) keep Kodi's
full-screen window underneath, so they are never mistaken for leaving.

7.0.45: a video started outside MegaNexus (Kodi's Videos, a file) that was full
screen stops too when Back / Esc leaves its player - it no longer plays on behind
the HUB. Not live TV, nor while MegaNexus IPTV or Sport shows its preview, and only
with the option on (Playback: "Back stops a video", on at first).
"""
import time

import xbmc
import xbmcgui

BRING_UP = 4.0
# MegaNexus screens that, open over the video, mean it plays behind (Kodi still
# counts its full-screen video as active underneath them).
COVERS = ' | '.join('Window.IsVisible(%s)' % name for name in (
    'meganexus_home.xml', 'meganexus_home_compact.xml', 'meganexus_details.xml', 'meganexus_details_landscape.xml',
    'meganexus_catalog.xml', 'meganexus_catalog_landscape.xml', 'meganexus_library.xml', 'meganexus_person.xml'))


def on_screen():
    return xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') and not xbmc.getCondVisibility(COVERS)
WAITING = 'meganexus.background_film'
LEFT = 1.0


def _ours(player, home):
    if not home.getProperty('meganexus.playing.request_id'):
        return False
    if home.getProperty('meganexus.preview.active') or home.getProperty('meganexus.playback.choosing'):
        return False
    try:
        from .wallpaper_video import is_background
        if is_background(player):
            return False
    except Exception:
        pass
    try:
        if not player.isPlayingVideo():
            return False
        wanted = home.getProperty('meganexus.playing.request_id')
        request = player.getPlayingItem().getProperty('meganexus.request')
        if request:
            return request == wanted
        # a resolver handoff can lose the item's properties: the service confirmed the start
        return home.getProperty('meganexus.playback.started') == wanted
    except Exception:
        return False


STOP_SETTING = 'meganexus_back_stops_video'
KEEP_PLAYING = ' | '.join(('VideoPlayer.Content(LiveTV)', 'Pvr.IsPlayingTv', 'Pvr.IsPlayingRadio',
                           'Window.IsVisible(meganexus_iptv.xml)', 'Window.IsVisible(meganexus_sports.xml)'))


def _other_video(player, home):
    """A video of Kodi's own (not MegaNexus's, not a preview, the wallpaper or live TV)."""
    if home.getProperty('meganexus.playing.request_id') or home.getProperty('meganexus.preview.active') \
            or home.getProperty('meganexus.saver.active'):
        return False
    try:
        if not player.isPlayingVideo():
            return False
        from .wallpaper_video import is_background
        if is_background(player):
            return False
    except Exception:
        return False
    try:
        from .settings_snapshot import cached_addon
        if cached_addon().getSetting(STOP_SETTING) == 'false':
            return False
    except Exception:
        pass
    return not xbmc.getCondVisibility(KEEP_PLAYING)


def run(monitor):
    player, home = xbmc.Player(), xbmcgui.Window(10000)
    started = away = None
    seen = parked_away = False
    other_seen, other_away = False, None
    failures = 0
    xbmc.log('[MegaNexus] Film guard on.', xbmc.LOGINFO)
    while not monitor.abortRequested():
        try:
            if _ours(player, home):
                now = time.monotonic()
                started = started or now
                if on_screen():
                    seen, away = True, None
                    if parked_away:            # back through "Now playing"
                        home.clearProperty(WAITING)
                        parked_away = False
                elif home.getProperty(WAITING):
                    away, parked_away = None, True     # behind Home, "Now playing" shown
                elif seen:
                    away = away or now
                    if now - away >= LEFT:
                        xbmc.log('[MegaNexus] The player was left for Home - the film stops.', xbmc.LOGINFO)
                        player.stop()
                        seen, away, started = False, None, None
                elif now - started >= BRING_UP and not home.getProperty(WAITING):
                    # Back / Esc pressed while it started: it waits, paused, for the
                    # HUB's "Now playing" pill (review/make_hub_now_playing.py).
                    xbmc.log('[MegaNexus] The film started behind the HUB - paused, Now playing shown.', xbmc.LOGINFO)
                    if not xbmc.getCondVisibility('Player.Paused'):
                        xbmc.executebuiltin('PlayerControl(Play)')
                    home.setProperty(WAITING, '1')
            else:
                started = away = None
                seen = parked_away = False
                if home.getProperty(WAITING):
                    home.clearProperty(WAITING)
                if _other_video(player, home):
                    if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                        other_seen, other_away = True, None
                    elif other_seen:
                        other_away = other_away or time.monotonic()
                        if time.monotonic() - other_away >= LEFT:
                            xbmc.log('[MegaNexus] The player of a video was left - it stops.', xbmc.LOGINFO)
                            player.stop()
                            other_seen, other_away = False, None
                else:
                    other_seen, other_away = False, None
        except Exception:
            failures += 1
            if failures <= 3:
                import traceback
                xbmc.log('[MegaNexus] Film guard: ' + traceback.format_exc(), xbmc.LOGWARNING)
        if monitor.waitForAbort(0.5):
            break


FROM_PLAYER = 'meganexus.home.from_player'   # Home puts the cursor on its own pill


def park():
    """The player's Home button: the film plays on behind MegaNexus Home, whose
    "Now playing" brings it back to full screen."""
    home = xbmcgui.Window(10000)
    home.setProperty(WAITING, '1')
    # 8.1.2: Home was asked for by name, so Home is where the cursor belongs
    # (home_window._came_from_the_player). Nothing else may place it there.
    home.setProperty(FROM_PLAYER, '1')
    xbmc.log('[MegaNexus] Home from the player - the film plays on, Now playing shown.', xbmc.LOGINFO)
    # Back leads to the screen the film was started from. Kodi ignores it while the
    # player bar is still fading out, so it is sent once no dialog is closing.
    monitor = xbmc.Monitor()
    until = time.monotonic() + 4
    while time.monotonic() < until and not monitor.abortRequested():
        if not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            return
        if xbmc.getCondVisibility(COVERS):
            # 8.1.2: a MegaNexus screen is up over the film - the Back we sent arrived
            # and did its work. Kodi can take a moment to stop counting its full-screen
            # video as active, and a second Back sent in that moment went THROUGH to
            # that screen and closed it, which put the film back on the screen: the
            # player's Home button looked like it did nothing.
            return
        if not xbmc.getCondVisibility('System.HasActiveModalDialog | Window.IsVisible(videoosd)'):
            xbmc.executebuiltin('Action(Back)')
            monitor.waitForAbort(0.4)
        else:
            monitor.waitForAbort(0.1)
    if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') and not xbmc.getCondVisibility(COVERS):
        xbmc.executebuiltin('ActivateWindow(Home)')
