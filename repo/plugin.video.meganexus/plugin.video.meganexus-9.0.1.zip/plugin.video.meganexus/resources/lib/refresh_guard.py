# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""No display mode switch for small preview videos (6.0.35, GitHub issue #4).

With Kodi's "Adjust display refresh rate" on, starting a trailer or a Sports
preview switched the TV's mode. On some CoreELEC builds (Dolby Vision
avdvplus) a video in a small window then stays black - audio only - and the
GUI hangs. While a preview plays the setting is turned off and afterwards put
back. When the setting is already off nothing is touched, so devices that
work today keep working exactly the same way. The original value is also
kept in the add-on settings, so the service restores it after a crash.
"""
import json
import threading
import time

import xbmc

SETTING = 'videoplayer.adjustrefreshrate'
STORE = 'meganexus_refresh_restore'          # original value while suspended
PROPERTY = 'meganexus.refresh.suspended'     # Window(Home): previews holding it
# 7.0.50: each hold is a lease - {holder: last renewed}. A hold whose process died (a script
# Kodi killed, a crash) is no longer renewed; the service's sweep gives the setting back.
LEASE = 20            # seconds a hold lasts without being renewed
RENEW = 5             # a long hold (IPTV, Sport) renews this often


def _rpc(method, params):
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    except (TypeError, ValueError):
        return None
    return reply.get('result') if isinstance(reply, dict) else None


def _log(text):
    xbmc.log('[MegaNexus] ' + text, xbmc.LOGINFO)


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.meganexus')


def _home():
    import xbmcgui
    return xbmcgui.Window(10000)


def _leases(home):
    """{holder: last renewed}; holds written before 7.0.50 (a list) count as renewed now."""
    raw = home.getProperty(PROPERTY)
    if not raw:
        return {}
    try:
        value = json.loads(raw)
    except ValueError:
        value = ['preview']
    if raw == '1' or not isinstance(value, (list, dict)):
        value = ['preview']                      # a hold written before 7.0.29
    if isinstance(value, list):
        return dict.fromkeys((str(v) for v in value), time.time())
    out = {}
    for holder, stamp in value.items():
        try:
            out[str(holder)] = float(stamp)
        except (TypeError, ValueError):
            out[str(holder)] = time.time()
    return out


def _holders(home):
    return sorted(_leases(home))


def _store(home, holders, leases=None):
    leases = dict(leases if leases is not None else _leases(home))
    now = time.time()
    kept = {h: leases.get(h, now) for h in set(holders)}
    if kept:
        home.setProperty(PROPERTY, json.dumps(kept, sort_keys=True))
    else:
        home.clearProperty(PROPERTY)


def suspend(holder='preview'):
    """Before a small-window video starts. Returns True while the setting is held off.

    7.0.29: every holder is counted (video wallpaper, Home previews, trailers,
    Sport); the setting comes back only when the last one lets go - a trailer
    ending no longer switched it on under the running wallpaper, nor the
    wallpaper stopping under a starting trailer.
    """
    home = _home()
    holders = _holders(home)
    if holders:
        leases = _leases(home)
        leases[holder] = time.time()
        _store(home, holders + [holder], leases)
        return True
    if _addon().getSetting(STORE):
        # 7.0.42: a value kept with no holder left - a hold that was lost. Give the
        # user's setting back first, or it would be read as "off" and stay off.
        restore(force=True)
    result = _rpc('Settings.GetSettingValue', {'setting': SETTING}) or {}
    value = result.get('value')
    if not value:
        return False  # off (0) or unknown: nothing to do
    _store(home, [holder])           # 7.0.50: the hold first - a sweep never sees a value without it
    _addon().setSetting(STORE, str(value))
    if _rpc('Settings.SetSettingValue', {'setting': SETTING, 'value': 0}) is None:
        _addon().setSetting(STORE, '')
        _store(home, [])
        return False
    _persist(value)                  # 7.0.50: the file keeps the user's value, not the pause
    _log('Refresh-rate switching paused for %s' % holder)
    return True


def restore(holder='preview', force=False):
    """A holder lets go (cheap when nothing was held). The setting comes back
    when no holder is left. ``force`` releases every hold: service start (a
    crash left one behind) and right before real playback (release_all)."""
    home = _home()
    holders = _holders(home)
    if not force:
        if not holders:
            return False
        holders = [h for h in holders if h != holder]
        if holders:
            _store(home, holders)
            return False
    addon = _addon()
    stored = addon.getSetting(STORE)
    if not stored and not holders and not home.getProperty(PROPERTY):
        return False
    _store(home, [])
    if stored:
        try:
            value = int(stored)
        except ValueError:
            addon.setSetting(STORE, '')
            return False
        # 8.1.3: the user's value is let go only once Kodi has taken it back. It was
        # wiped first, so a Kodi that did not answer (on its way out, with Sport or a
        # trailer still holding the setting) left it off with nothing to give it back -
        # "AFR mi je na start/stop, a u Kodiju piše isključeno". Kept, the service's
        # sweep tries again a few seconds later, or the next start does.
        answer = _rpc('Settings.SetSettingValue', {'setting': SETTING, 'value': value})
        if answer is None:
            _persist(value)
            return False
        addon.setSetting(STORE, '')              # taken back - or refused, which no retry changes
        if answer:
            _persist(value)
            _log('Refresh-rate switching back (%s)' % ('all' if force else holder))
        return True
    addon.setSetting(STORE, '')
    return True


def _persist(value):
    """7.0.50: the user's value into guisettings.xml at once. Kodi wrote the pause (0) to
    the file and saved the value given back only later - a Kodi killed or a power cut in
    between left the setting off for good ("AFR switched itself off")."""
    try:
        from .skin_activation import persist
        persist(SETTING, str(int(value)))
    except Exception:
        pass


def renew(holder):
    """7.0.50: the holder is still there (cheap: Kodi is asked at most every RENEW seconds)."""
    home = _home()
    leases = _leases(home)
    if holder in leases and time.time() - leases[holder] >= RENEW:
        leases[holder] = time.time()
        _store(home, list(leases), leases)


class hold(object):
    """7.0.50: the setting off for as long as a screen is open - IPTV and Sport play
    no film, the TV never switches its mode there (with Kodi's switch a channel
    opening could freeze the picture on the Cube). Renewed in the background; the
    film's own start gives it back at once (release_all)."""

    def __init__(self, holder):
        self.holder = holder
        self.done = threading.Event()

    def __enter__(self):
        try:
            suspend(self.holder)
        except Exception:
            pass
        threading.Thread(target=self._renew, name='MegaNexusRefreshHold', daemon=True).start()
        return self

    def _renew(self):
        while not self.done.wait(RENEW):
            try:
                if self.holder in _leases(_home()):
                    renew(self.holder)
                elif not xbmc.Player().isPlayingVideo():
                    suspend(self.holder)          # a film in between gave it back: off again, never under a film
            except Exception:
                pass

    def __exit__(self, *exc):
        self.done.set()
        try:
            restore(self.holder)
        except Exception:
            pass
        return False


def sweep(playing_small=None):
    """7.0.50, the service every few seconds: holds that are no longer renewed are gone
    (their process died); with none left the user's setting comes back - it can not stay
    off by accident. A short video still playing in a window keeps an old-style hold."""
    home = _home()
    leases = _leases(home)
    stored = _addon().getSetting(STORE)
    if not leases and not stored:
        return False
    now = time.time()
    if leases and not home.getProperty(PROPERTY).startswith('{'):
        _store(home, list(leases), leases)        # an old-style hold: its lease starts now, then runs out
    fresh = {h: t for h, t in leases.items() if now - t < LEASE}
    if fresh:
        if len(fresh) != len(leases):
            _store(home, list(fresh), fresh)
        return False
    if playing_small is None:
        try:
            playing_small = xbmc.Player().isPlayingVideo() and not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
        except Exception:
            playing_small = False
    if playing_small and leases:
        return False
    _log('Refresh-rate switching: no hold left (%s) - back to your setting' % (', '.join(sorted(leases)) or 'none'))
    return restore(force=True)


def release_all():
    """7.0.29: right BEFORE a film, an episode or a channel starts. Kodi picks the
    TV's refresh rate when playback opens: restored after the start (as before),
    the film ran at the menu's rate - judder - and the setting looked "off"."""
    return restore(force=True)
