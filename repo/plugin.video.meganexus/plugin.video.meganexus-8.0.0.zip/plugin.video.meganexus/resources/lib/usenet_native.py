# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Usenet films read by Kodi itself, through the vfs.meganexus add-on (8.0).

Our Usenet player in Python read every article on one core (Kodi's Python lock),
~30 Mbit/s on a slow Android box. vfs.meganexus is a binary Kodi add-on (C++, built
for each system and Kodi version): Kodi opens mnxusenet://<token>/<name> through it
and it fetches and decodes the articles on all cores - Python is not in the way.

Python still does the clever part, when the film is chosen: it reads the NZB, finds
the film (also stored inside RAR volumes, or under obfuscated names), asks a few
articles through it, and writes a plan: the servers and, for each piece of the film,
its articles. Without the add-on (not built for this system, turned off, not
installed yet) the film plays as before, through usenet_stream.

The plan holds the server login, as the source's .json beside it does: only in
the profile, readable by this user only, never in a link or the log.
"""
import os
import re
import threading
import time

ADDON = 'vfs.meganexus'
SCHEME = 'mnxusenet'
SETTING = 'usenet_native'               # 'true' (default) / 'false'
LEAVING_FILE = 'leaving'                # MegaNexus' Stop: a read waiting for an article ends
WATCH_EVERY = 2.0                       # s the service looks whether a native film plays
LEAVING_EVERY = 0.25                    # ... and then for MegaNexus' Stop


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Usenet: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def wanted(addon=None):
    try:
        if addon is None:
            from .settings_cache import cached_addon
            addon = cached_addon()
        return (addon.getSetting(SETTING) or 'true') != 'false'
    except Exception:
        return True


def ready():
    """vfs.meganexus is installed and on (Kodi loaded it for this system)."""
    try:
        import xbmc
        return bool(xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % ADDON))
    except Exception:
        return False


def token_of(url):
    """The token of a usenet_stream link (http://127.0.0.1:<port>/usenet/<token>/<name>), or ''."""
    match = re.search(r'/usenet/([0-9a-f]{8,64})/', str(url or ''))
    return match.group(1) if match else ''


def safe_name(name):
    """The film's name as the link carries it: letters, digits, '.', '-' and '_' only."""
    base, ext = os.path.splitext(os.path.basename(str(name or '')))
    base = re.sub(r'[^A-Za-z0-9._-]+', '.', base).strip('.')[:120] or 'film'
    ext = re.sub(r'[^A-Za-z0-9]', '', ext)[:5].lower() or 'mkv'
    return '%s.%s' % (base, ext)


def plan_text(found, servers, name):
    """The "meganexus-plan 1" text vfs.meganexus reads (usenet.cpp ParsePlan)."""
    def hexed(value):
        return value.encode('utf-8').hex() if value else '-'
    lines = ['meganexus-plan 1', 'size %d' % found.size, 'name %s' % name.encode('utf-8').hex(),
             'keep %d' % found.keep, 'ahead %d' % found.ahead]
    for server in servers:
        lines.append('server %d %s %d %d %s %s' % (1 if server.get('ssl') else 0, server['host'], int(server['port']),
                                                   int(server['connections']), hexed(server.get('user') or ''),
                                                   hexed(server.get('password') or '')))
    for nzb_file, offset, length in found.extents:
        ids = [str(m).strip().strip('<>') for m in nzb_file.segments]
        if not ids or any(not i or any(c.isspace() for c in i) for i in ids):
            raise ValueError('an article id the plan can not carry')
        part = nzb_file.part_size or (nzb_file.size // len(ids)) or 768000
        lines.append('extent %d %d %d %d' % (offset, length, part, len(ids)))
        lines.extend(ids)
    return '\n'.join(lines) + '\n'


def prepare(url):
    """The film behind a usenet_stream link as a link for vfs.meganexus, or '' (then it plays as
    before). Raises when the release can not be played (incomplete, compressed...)."""
    token = token_of(url)
    if token:
        note_use()                                       # 8.0: Usenet is used here - the add-on comes
    if not token or not wanted() or not ready():
        return ''
    from . import usenet_stream
    started = time.time()
    path, saved, found, servers = usenet_stream.prepare(token)
    try:
        name = safe_name(found.name or saved.get('name') or 'film.mkv')
        text = plan_text(found, servers, name)
        plan = os.path.join(os.path.dirname(path), token + '.plan')
        temp = plan + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            handle.write(text)
        try:
            os.chmod(temp, 0o600)
        except Exception:
            pass
        os.replace(temp, plan)
    finally:
        found.fetcher.close()                    # its connections go: the add-on opens its own
    _log('played by %s (plan in %.1f s)' % (ADDON, time.time() - started))
    return '%s://%s/%s' % (SCHEME, token, name)


def leaving():
    """MegaNexus stops a native film: the add-on's waiting read ends at once."""
    try:
        from . import usenet_stream
        path = os.path.join(usenet_stream._folder(), LEAVING_FILE)
        with open(path, 'w') as handle:
            handle.write(str(time.time()))
        return True
    except Exception:
        return False


def watch(monitor):
    """The service: while a native film plays, the OSD Stop button (a Home property, set by the
    skin) becomes the leaving mark. Cheap: one label every WATCH_EVERY seconds otherwise."""
    import xbmc
    import xbmcgui
    from . import usenet_stream
    home = xbmcgui.Window(10000)
    while not monitor.waitForAbort(WATCH_EVERY):
        try:
            if not xbmc.getInfoLabel('Player.Filenameandpath').startswith(SCHEME + '://'):
                continue
            home.clearProperty(usenet_stream.LEAVING)    # a Stop of another film, before this one
            while xbmc.getInfoLabel('Player.Filenameandpath').startswith(SCHEME + '://'):
                if home.getProperty(usenet_stream.LEAVING) == '1':
                    home.clearProperty(usenet_stream.LEAVING)
                    leaving()
                if monitor.waitForAbort(LEAVING_EVERY):
                    return
        except Exception:
            continue


# --- the add-on itself: installed by MegaNexus for this system ----------------------------

MANIFEST = 'https://meganexusmediaplayer.github.io/MegaNexus/native/vfs.meganexus.json'
INSTALL_AFTER = 90                      # s after Kodi starts: never while Home loads
MAX_ZIP = 32 * 1024 * 1024


def platform_tag():
    """Kodi's platform name for this system (the add-on is built for each), or ''."""
    import platform
    import struct
    bits = struct.calcsize('P') * 8          # a 32-bit Kodi on a 64-bit CPU needs the 32-bit build
    machine = platform.machine().lower()
    try:
        import xbmc
        android = xbmc.getCondVisibility('System.Platform.Android')
        windows = xbmc.getCondVisibility('System.Platform.Windows')
        linux = xbmc.getCondVisibility('System.Platform.Linux')
    except Exception:
        return ''
    arm = machine.startswith(('arm', 'aarch64'))
    if android and arm:
        return 'android-aarch64' if bits == 64 else 'android-armv7'
    if windows and machine in ('amd64', 'x86_64') and bits == 64:
        return 'windows-x86_64'
    if linux and not android:
        if machine in ('x86_64', 'amd64') and bits == 64:
            return 'linux-x86_64'
        if arm:
            return 'linux-aarch64' if bits == 64 else 'linux-armv7'
    return ''


def kodi_major():
    try:
        import xbmc
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except Exception:
        return 0


def installed_version(addons_dir):
    try:
        import xml.etree.ElementTree as ET
        return ET.parse(os.path.join(addons_dir, ADDON, 'addon.xml')).getroot().get('version') or ''
    except Exception:
        return ''


def choose(manifest, major, tag):
    """(version, build) of the add-on for this Kodi and system from the published list, or None."""
    if not isinstance(manifest, dict) or not tag or not major:
        return None
    build = (manifest.get('builds') or {}).get('%d/%s' % (major, tag))
    if not isinstance(build, dict) or not re.match(r'^[0-9a-f]{64}$', str(build.get('sha256') or '')):
        return None
    if not re.match(r'^native/[A-Za-z0-9._+/-]+\.zip$', str(build.get('path') or '')) or '..' in build['path']:
        return None
    return str(manifest.get('version') or ''), build


def unpack(data, sha256, addons_dir, version):
    """The checked ZIP into addons/vfs.meganexus (staged, then moved in; the old one kept until
    the new one is in place)."""
    import hashlib
    import io
    import shutil
    import tempfile
    import zipfile
    if hashlib.sha256(data).hexdigest() != sha256:
        raise ValueError('checksum')
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        if not names or any(not n.startswith(ADDON + '/') or '..' in n or n.startswith('/') for n in names):
            raise ValueError('unexpected files')
        stage = tempfile.mkdtemp(prefix='.meganexus-native-', dir=addons_dir)
        try:
            archive.extractall(stage)
            import xml.etree.ElementTree as ET
            root = ET.parse(os.path.join(stage, ADDON, 'addon.xml')).getroot()
            if root.get('id') != ADDON or root.get('version') != version:
                raise ValueError('wrong add-on')
            target = os.path.join(addons_dir, ADDON)
            old = target + '.old'
            shutil.rmtree(old, ignore_errors=True)
            if os.path.isdir(target):
                os.replace(target, old)
            os.replace(os.path.join(stage, ADDON), target)
            shutil.rmtree(old, ignore_errors=True)
        finally:
            shutil.rmtree(stage, ignore_errors=True)


def _rpc(method, params):
    import json
    import xbmc
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    except ValueError:
        return {}


def ensure(monitor, fetch=None):
    """The service, once a start: the add-on for this Kodi and system installed and on. Quiet
    (no question, no notification); without it films play as before."""
    import json
    import xbmc
    import xbmcvfs
    if not wanted():
        return 'off'
    tag, major = platform_tag(), kodi_major()
    if not tag or not major:
        return 'no build for this system'
    if fetch is None:
        from urllib.request import Request, urlopen

        def fetch(url, limit):
            with urlopen(Request(url, headers={'User-Agent': 'MegaNexus'}), timeout=30) as reply:
                return reply.read(limit + 1)
    manifest = json.loads(fetch(MANIFEST, 1024 * 1024).decode('utf-8'))
    chosen = choose(manifest, major, tag)
    if not chosen:
        return 'no build for Kodi %d %s' % (major, tag)
    version, build = chosen
    addons_dir = xbmcvfs.translatePath('special://home/addons')
    if installed_version(addons_dir) != version:
        while xbmc.Player().isPlaying():                  # never under a film (the library is in use)
            if monitor.waitForAbort(30):
                return 'stopped'
        data = fetch(MANIFEST.rsplit('/native/', 1)[0] + '/' + build['path'], MAX_ZIP)
        if len(data) > MAX_ZIP:
            raise ValueError('too large')
        unpack(data, build['sha256'], addons_dir, version)
        xbmc.executebuiltin('UpdateLocalAddons')
        _log('%s %s installed for Kodi %d %s' % (ADDON, version, major, tag))
    for _ in range(60):                                   # slow boxes find a new add-on in ~30 s
        found = ((_rpc('Addons.GetAddonDetails', {'addonid': ADDON, 'properties': ['enabled', 'version']})
                  .get('result') or {}).get('addon') or {})
        if found.get('version') == version:
            if not found.get('enabled'):
                _rpc('Addons.SetAddonEnabled', {'addonid': ADDON, 'enabled': True})
            return 'ready'
        if monitor.waitForAbort(.5):
            return 'stopped'
    return 'installed - Kodi loads it at its next start'


RETRY_AFTER_FAILURE = 24 * 3600         # 7.0.59: the builds not reachable (not published yet, offline):
CHECK_FILE = 'usenet_native_check.json' #     asked again a day later, not at every start


def _profile():
    from .meganexus.common import profile_path
    return profile_path()


def _failed_lately():
    import json
    import os
    import time
    try:
        with open(os.path.join(_profile(), CHECK_FILE), encoding='utf-8') as handle:
            return time.time() - float(json.load(handle).get('failed') or 0) < RETRY_AFTER_FAILURE
    except (OSError, ValueError, TypeError):
        return False


def _remember_failure(failed):
    import json
    import os
    import time
    path = os.path.join(_profile(), CHECK_FILE)
    try:
        if failed:
            with open(path, 'w', encoding='utf-8') as handle:
                json.dump({'failed': time.time()}, handle)
        elif os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


USED_FILE = 'usenet_used'               # 8.0: a Usenet film has played on this profile


def in_use(addon=None):
    """8.0: the fast Usenet player is only for those who use Usenet - their own Usenet server is
    set, or a Usenet film (an add-on's NZB) has played here. Nobody else downloads it."""
    try:
        from . import usenet_stream
        if usenet_stream.own_servers(addon):
            return True
    except Exception:
        pass
    try:
        return os.path.exists(os.path.join(_profile(), USED_FILE))
    except Exception:
        return False


_installing = threading.Lock()


def install_now():
    """Usenet is used now (a server set, a Usenet film, the setting turned on): the add-on comes
    in the background - the film playing now plays as before."""
    if not wanted() or ready() or not _installing.acquire(False):
        return False

    def run():
        try:
            import xbmc
            _log('the fast Usenet player: %s' % ensure(xbmc.Monitor()))
            _remember_failure(False)
        except Exception as exc:
            _remember_failure(True)
            _log('the fast Usenet player not installed (%s) - Usenet plays as before' % type(exc).__name__)
        finally:
            _installing.release()
    threading.Thread(target=run, name='MegaNexusUsenetNativeInstall', daemon=True).start()
    return True


def note_use():
    """A Usenet film starts here: remembered (the next starts install the add-on too)."""
    try:
        path = os.path.join(_profile(), USED_FILE)
        if not os.path.exists(path):
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write('1')
    except OSError:
        pass
    if not _failed_lately():
        install_now()


def _install_later(monitor):
    if monitor.waitForAbort(INSTALL_AFTER):
        return
    if _failed_lately() or not in_use():
        return                                           # 8.0: no Usenet here - nothing downloaded
    if not _installing.acquire(False):
        return
    _installing.release()
    try:
        _log('the fast Usenet player: %s' % ensure(monitor))
        _remember_failure(False)
    except Exception as exc:
        _remember_failure(True)
        _log('the fast Usenet player not installed (%s) - Usenet plays as before; asked again in a day'
             % type(exc).__name__)


def start_watch():
    try:
        import xbmc
        threading.Thread(target=watch, args=(xbmc.Monitor(),), name='MegaNexusUsenetNative', daemon=True).start()
        threading.Thread(target=_install_later, args=(xbmc.Monitor(),), name='MegaNexusUsenetNativeInstall',
                         daemon=True).start()
    except Exception:
        pass
