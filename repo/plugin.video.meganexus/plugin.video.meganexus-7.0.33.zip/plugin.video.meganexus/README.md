# MegaNexus Hub (plugin.video.meganexus)

The engine of MegaNexus: accounts (Nuvio sync, Stremio, Trakt, Simkl, Plex,
Jellyfin / Emby), add-ons and catalogs, playback and Continue Watching, the
phone setup page, backup / restore and automatic updates. It installs and
keeps up to date the MegaNexus interface (`script.meganexus`), MegaNexus Skin
and MegaNexus Screensaver.

See the repository [README](../README.md), [install guide](../docs/INSTALL.md)
and [CHANGELOG](../CHANGELOG.md). MegaNexus License (see `LICENSE.txt`).
