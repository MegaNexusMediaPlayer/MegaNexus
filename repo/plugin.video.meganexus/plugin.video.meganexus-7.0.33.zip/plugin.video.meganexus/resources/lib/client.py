# -*- coding: utf-8 -*-
"""Backward-compat shim. Real implementation lives in meganexus.client."""
from meganexus.client import *  # noqa: F401,F403
