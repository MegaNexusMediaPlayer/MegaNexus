"""When a title came out, or comes out (7.0.32).

* The badge beside the ratings on a title's page: an episode's air day
  (Released / Today / Tomorrow / Friday / Coming soon), a film's release
  (Released / In cinemas / Coming). Films need a TMDB key for the cinema and
  digital dates; without one the metadata's release date still gives
  Released / Coming.
* The digital release filter (Settings > Playback): a film still only in
  cinemas, or an episode not yet aired, is not searched or played. The rules
  are AIOStreams' (Viren070/AIOStreams, filterer.ts): TMDB release dates of
  every country, types 4-6 (digital, physical, TV) count as a digital release;
  a film over a year old, or one TMDB has no dates for, always plays.
* Hide unreleased (Settings > Collections & Home rows): cards whose release
  date lies ahead are left out, as NuvioTV does (ReleaseInfoUtils.isUnreleased).
"""
import re
from datetime import date, datetime, timedelta, timezone

DIGITAL_TYPES = (4, 5, 6)          # TMDB: digital, physical, TV
CINEMA_TYPES = (2, 3)              # TMDB: theatrical (limited), theatrical
FILTER_SETTING = 'meganexus_digital_release_filter'
HIDE_SETTING = 'meganexus_hide_unreleased'
WEEKDAYS = ('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday')
_YEAR = re.compile(r'\b(19|20)\d{2}\b')


def parse_day(value):
    """A local calendar day from an ISO date / timestamp ('' or bad = None)."""
    value = str(value or '').strip()
    if not value:
        return None
    try:
        if len(value) == 10:
            return date.fromisoformat(value)
        stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
        return stamp.astimezone().date()
    except (ValueError, TypeError):
        return None


def episode_day(episode):
    episode = episode or {}
    return parse_day(episode.get('released') or episode.get('releaseDate') or episode.get('air_date')
                     or episode.get('firstAired'))


def short_date(day, today=None):
    today = today or date.today()
    text = '%d %s' % (day.day, day.strftime('%b'))
    return text if day.year == today.year else text + ' %d' % day.year


def day_badge(day, today=None):
    """(badge kind, date text) for a day: released, today, tomorrow, the weekday
    within a week, soon after that (pictures: media/release/<kind>.png)."""
    today = today or date.today()
    if day is None:
        return '', ''
    days = (day - today).days
    if days < 0:
        return 'released', short_date(day, today)
    if days == 0:
        return 'today', short_date(day, today)
    if days == 1:
        return 'tomorrow', short_date(day, today)
    if days < 7:
        return WEEKDAYS[day.weekday()], short_date(day, today)
    return 'soon', short_date(day, today)


def episode_badge(episode, today=None):
    kind, text = day_badge(episode_day(episode), today)
    if not kind:
        return '', ''
    label = 'S%s E%s' % (episode.get('season', 1), episode.get('episode'))
    return kind, label + '  ·  ' + text


def next_episode(episodes, today=None):
    """The first episode still to come (the series' badge when no episode is selected)."""
    today = today or date.today()
    upcoming = [(episode_day(e), e) for e in episodes or []]
    upcoming = [(d, e) for d, e in upcoming if d is not None and d >= today]
    return min(upcoming, key=lambda pair: pair[0])[1] if upcoming else None


def _dates(rows, types, today):
    days = []
    for row in rows or []:
        try:
            kind = int(row.get('type'))
        except (TypeError, ValueError):
            continue
        day = parse_day(row.get('release_date'))
        if kind in types and day is not None:
            days.append(day)
    return sorted(days)


def movie_status(meta, release_dates=None, today=None):
    """('released' | 'cinema' | 'coming' | '', the date shown).

    release_dates: TMDB's dates of every country ([{'type', 'release_date'}]);
    None = unknown (no TMDB key) - the metadata's release date decides."""
    today = today or date.today()
    released = parse_day((meta or {}).get('released'))
    if release_dates:
        digital = _dates(release_dates, DIGITAL_TYPES, today)
        cinema = _dates(release_dates, CINEMA_TYPES, today)
        past_digital = [d for d in digital if d <= today]
        if past_digital:
            return 'released', past_digital[0]
        past_cinema = [d for d in cinema if d <= today]
        if past_cinema:
            if (today - past_cinema[0]).days > 365:
                return 'released', past_cinema[0]
            return 'cinema', next((d for d in digital if d > today), past_cinema[0])
        upcoming = cinema or digital or ([released] if released else [])
        return ('coming', upcoming[0]) if upcoming else ('', None)
    if released is None:
        return '', None
    return ('released' if released <= today else 'coming'), released


def movie_badge(meta, release_dates=None, today=None):
    today = today or date.today()
    status, day = movie_status(meta, release_dates, today)
    if not status or day is None:
        return '', ''
    if status == 'released':
        return 'released', short_date(day, today)
    if status == 'cinema':
        return 'cinema', ('Digital ' + short_date(day, today)) if day > today else short_date(day, today)
    return day_badge(day, today)


def digital_verdict(meta, release_dates=None, episode=None, today=None):
    """(allowed, why) - AIOStreams' digital release rules, tolerance 0."""
    today = today or date.today()
    meta = meta or {}
    title = meta.get('name') or meta.get('title') or 'This title'
    if episode is not None:
        day = episode_day(episode)
        if day is not None and day > today:
            return False, '%s S%s E%s airs on %s.' % (title, episode.get('season', 1), episode.get('episode'), short_date(day, today))
        return True, ''
    released = parse_day(meta.get('released'))
    if released is not None and released > today:
        return False, '%s comes out on %s.' % (title, short_date(released, today))
    if released is not None and (today - released).days > 365:
        return True, ''
    if not release_dates:
        return True, ''                       # no TMDB dates: nothing to judge by
    digital = _dates(release_dates, DIGITAL_TYPES, today)
    if any(d <= today for d in digital):
        return True, ''
    if digital:
        return False, '%s is only in cinemas - digital release %s.' % (title, short_date(digital[0], today))
    return False, '%s is only in cinemas - no digital release announced yet.' % title


def unreleased(card, today=None):
    """NuvioTV's rule: a release date ahead, or only a future year."""
    today = today or date.today()
    target = (card or {}).get('target') or {}
    for value in (card.get('released'), target.get('released')):
        day = parse_day(value)
        if day is not None:
            return day > today
    info = str(card.get('releaseInfo') or target.get('releaseInfo') or card.get('year') or '')
    found = _YEAR.search(info)
    return bool(found) and int(found.group(0)) > today.year


def tmdb_dates(meta):
    """TMDB's release dates of a film (cached a day); None without a TMDB key
    or when the film is not on TMDB."""
    from . import tmdb_direct
    if not tmdb_direct._api_key():
        return None
    raw = str(meta.get('canonical_id') or meta.get('id') or '')
    imdb = str(meta.get('imdb_id') or (raw if raw.startswith('tt') else '')).split(':')[0]
    tmdb = str(meta.get('tmdb_id') or (raw.split(':')[1] if raw.startswith('tmdb:') else ''))
    key = 'release_dates:%s:%s' % (tmdb, imdb)
    cached = tmdb_direct._cache_get(key)
    if cached is not None:
        return cached.get('dates')
    try:
        tmdb = tmdb or tmdb_direct._resolve_tmdb_id(imdb_id=imdb, media_type='movie')
        if not tmdb:
            tmdb_direct._cache_set(key, {'dates': None}, tmdb_direct.NEGATIVE_TTL)
            return None
        reply = tmdb_direct._request('/movie/%s/release_dates' % tmdb) or {}
    except Exception:
        return None
    dates = [row for country in reply.get('results') or [] for row in country.get('release_dates') or []]
    dates = [{'type': row.get('type'), 'release_date': row.get('release_date')} for row in dates if isinstance(row, dict)]
    tmdb_direct._cache_set(key, {'dates': dates}, 24 * 60 * 60)
    return dates


def filter_on(addon=None):
    try:
        if addon is None:
            from .settings_cache import cached_addon
            addon = cached_addon()
        return addon.getSetting(FILTER_SETTING) == 'true'
    except Exception:
        return False


def hide_on(addon=None):
    try:
        if addon is None:
            from .settings_cache import cached_addon
            addon = cached_addon()
        return addon.getSetting(HIDE_SETTING) == 'true'
    except Exception:
        return False
