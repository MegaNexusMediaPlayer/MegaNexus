"""Titles without the emoji Kodi cannot draw (7.0.24).

Kodi draws text with one font, its own (DejaVu Sans with CJK and Hangul), and
has no emoji: "⚽🥊 Sport" showed boxes. Before a title is shown, the emoji
that font lacks are removed with their invisible helpers (variation
selectors, joiners, keycaps, tags); symbols it has (★ ✓ ♥ ❤ ⚡ ☀) stay. The
missing ranges were read from Kodi's media/Fonts/arial.ttf.
"""
import re

_MISSING = ('⌓-⌗⌚-⌛⌢-⌣〈-〉⌭-⍲⍶-⍹⍻-⍼'
            '⍾-⎆⎈-⎓⎕-⎚⎯-⏍⏐-⏢⏤⏦-⏧⏩-⏿'
            '⚝-⚟⚹-⚿⛄-✀✅✊-✋✨❌❎❓-❕❗'
            '❟-❠➕-➗➰➿⬛-⬞⬥-⭒⭕-⯿')
_EMOJI = re.compile('[\U0001F000-\U0001FAFF' + _MISSING + '︎️‍⃣\U000E0020-\U000E007F]')
_EDGES = ' \t·•|-–—:,'


def without_emoji(text):
    """The title as Kodi can draw it: emoji removed, spacing tidied."""
    value = str(text or '')
    clean = _EMOJI.sub('', value)
    if clean == value:
        return value
    return re.sub(r'\s{2,}', ' ', clean).strip(_EDGES)
