"""Enrich incomplete cloud progress without rewriting position or timestamps."""
from . import backend_api
import re


def metadata_identity(target):
    mt=str(target.get('media_type') or 'movie').lower()
    if mt in ('tv','tvshow','show','episode','anime'):mt='series'
    cid=str(target.get('imdb_id') or target.get('canonical_id') or target.get('video_id') or '').strip()
    if not cid and target.get('tmdb_id'):
        value=str(target['tmdb_id']);cid=value if value.startswith('tmdb:') else 'tmdb:'+value
    match=re.fullmatch(r'(tt\d+|tmdb:\d+)(?::\d+:\d+)?',cid)
    if match:cid=match.group(1)
    if cid.isdigit():cid='tmdb:'+cid
    return mt,cid


def _missing_title(value):
    return str(value or '').strip().lower() in ('unknown','untitled','','loading title…')

def _enrich_rows(rows):
    result=[]
    for original in rows:
        row=dict(original);target=dict(row.get('target') or {})
        mt,lookup=metadata_identity(target)
        if lookup:
            target.update(canonical_id=lookup,media_type=mt)
            row['target']=target
        if row.get('poster') and not _missing_title(row.get('title')):
            result.append(row);continue
        if lookup:
            try:
                meta=backend_api.metadata(mt,lookup)
                name=meta.get('name') or meta.get('title')
                if not _missing_title(name):row['title']=name
                row['poster']=meta.get('poster') or row.get('poster') or ''
                row['fanart']=meta.get('background') or row.get('fanart') or ''
                row['clearlogo']=meta.get('logo') or meta.get('clearlogo') or row.get('clearlogo') or ''
                row['plot']=meta.get('description') or meta.get('overview') or row.get('plot') or ''
                year=str(meta.get('year') or meta.get('releaseInfo') or '')[:4]
                row['meta_line']='  |  '.join(x for x in (year,'Series' if mt=='series' else 'Movie',row.get('subtitle')) if x)
                target.update(title=row.get('title') or '')
                row['target']=target
                key=row.get('progress_key')
                if isinstance(key,(list,tuple)) and len(key)==3:
                    from .meganexus.playback_store import update_metadata
                    update_metadata(*key,title='' if _missing_title(row.get('title')) else row['title'],
                                    poster=row['poster'],background=row['fanart'],clearlogo=row['clearlogo'])
            except Exception:
                pass
        if _missing_title(row.get('title')):
            row['title']='Saved '+('episode' if mt=='series' else 'movie')+(' · '+lookup if lookup else '')
        result.append(row)
    return result

def _keys(row,network=False):
    """Every id a card is known by: its own, its IMDb id, and the IMDb id of a
    TMDB id (cached; fetched when ``network``) - the same film saved by Nuvio
    as tmdb:12153 and by MegaNexus as tt0381707 is one title (7.0.29)."""
    target=row.get('target') or {}
    kind,cid=metadata_identity(target)
    keys=set()
    if cid:keys.add((kind,cid))
    imdb=str(target.get('imdb_id') or '')
    if imdb.startswith('tt'):keys.add((kind,imdb.split(':')[0]))
    # 7.0.29: the TMDB / TVDB ids the card carries
    for column,prefix in (('tmdb_id','tmdb:'),('tvdb_id','tvdb:')):
        value=str(target.get(column) or '').strip()
        if value and value not in ('0','None'):keys.add((kind,value if value.startswith(prefix) else prefix+value))
    if cid.startswith('tmdb:'):
        try:
            from . import tmdb_direct
            number=cid.split(':',1)[1]
            mt='movie' if kind=='movie' else 'tv'
            mapped=tmdb_direct.imdb_id_for(number,mt) if network else (tmdb_direct._cache_get('imdb_for:%s:%s'%(mt,number)) or '')
            if mapped:keys.add((kind,mapped))
        except Exception:pass
    return keys

def dedupe(rows,network=False):
    """7.0.24: one card per title. The same film or series can come twice
    (Nuvio and another app saving it under different IDs, or in another
    language); the newer card stays and takes the pictures the other one has."""
    result,seen=[],{}
    for row in rows:
        target=row.get('target') or {}
        title=str(row.get('title') or '').strip().casefold()
        if not target:
            result.append(row);continue
        kind='movie' if target.get('media_type')=='movie' else 'series'
        keys=_keys(row,network)
        if title and not _missing_title(title) and not title.startswith('saved '):keys.add((kind,'title:'+title))
        kept=next((seen[k] for k in keys if k in seen),None)
        if kept is None:
            result.append(row)
            for k in keys:seen[k]=row
            continue
        for art in ('poster','fanart','landscape','clearlogo'):
            if not kept.get(art) and row.get(art):kept[art]=row[art]
        for k in keys:seen.setdefault(k,kept)
    return result

def enrich(rows,on_update=None,should_stop=lambda:False):
    from concurrent.futures import ThreadPoolExecutor,as_completed
    result=[dict(r) for r in rows]
    pool=ThreadPoolExecutor(max_workers=2)
    tasks={pool.submit(_enrich_rows,[row]):i for i,row in enumerate(rows)}
    try:
        for task in as_completed(tasks):
            if should_stop():break
            result[tasks[task]]=task.result()[0]
            if on_update:on_update(dedupe([dict(r) for r in result]))
    finally:
        # Kodi 21 on Windows still embeds Python 3.8 (no cancel_futures kwarg).
        for task in tasks:task.cancel()
        pool.shutdown(wait=False)
    return dedupe(result)
