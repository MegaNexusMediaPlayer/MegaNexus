"""Subtitle auto-sync without AI (7.0.29, experimental - the player's Sync button).

A subtitle made for another release of the film starts early or late, or
drifts (25 fps vs 23.976 fps). MegaNexus lines it up against a reference
timeline that belongs to the playing file - subtitles the stream itself
supplies, or a release whose name matches the stream - in any language:
when people speak, the cues start, whatever the language.

How (MegaNexus' own method): every cue start of the subtitle votes for the
shift that puts it on a cue start of the reference; the strongest shift, at
each of the usual frame-rate ratios, wins when enough cues agree. The
median of the agreeing cues refines it. The result is written as a new SRT
and loaded at once; nothing changes when the match is not convincing.
"""
import html
import re

RATIOS = (1.0, 25 / 23.976, 23.976 / 25, 24 / 23.976, 23.976 / 24, 25 / 24, 24 / 25)
BIN = 0.1                 # seconds per vote bucket
SEARCH = 180.0            # the largest shift tried, seconds
MATCH = 0.45              # a cue agrees within this many seconds
MIN_SHARE = 0.30          # this share of the cues must agree...
MIN_MATCHES = 15          # ...and at least this many
SAMPLE = 600              # cues used for the votes (spread over the film)

TIME = re.compile(r'(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})')
ARROW = re.compile(r'(\d+:\d{1,2}:\d{1,2}[,.]\d{1,3})\s*-->\s*(\d+:\d{1,2}:\d{1,2}[,.]\d{1,3})')
ASS_TIME = re.compile(r'(\d+):(\d{2}):(\d{2})[.](\d{2})')
ASS_TAGS = re.compile(r'\{[^}]*\}')
TAGS = re.compile(r'<[^>]+>')


def _seconds(text):
    found = TIME.match(text.strip())
    if not found:
        return None
    h, m, s, ms = found.groups()
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms.ljust(3, '0')[:3]) / 1000.0


def _ass_seconds(text):
    found = ASS_TIME.match(text.strip())
    if not found:
        return None
    h, m, s, cs = found.groups()
    return int(h) * 3600 + int(m) * 60 + int(s) + int(cs) / 100.0


def parse(text):
    """[(start, end, text)] from SRT, WebVTT or ASS/SSA."""
    text = str(text or '').replace('\r\n', '\n').replace('\r', '\n').lstrip('﻿')
    cues = []
    if '[Events]' in text or re.search(r'(?m)^Dialogue:', text):
        fields = ['Layer', 'Start', 'End', 'Style', 'Name', 'MarginL', 'MarginR', 'MarginV', 'Effect', 'Text']
        for line in text.split('\n'):
            if line.startswith('Format:') and 'Start' in line:
                fields = [f.strip() for f in line[7:].split(',')]
            elif line.startswith('Dialogue:'):
                parts = line[9:].split(',', len(fields) - 1)
                if len(parts) < len(fields):
                    continue
                row = dict(zip(fields, parts))
                start, end = _ass_seconds(row.get('Start', '')), _ass_seconds(row.get('End', ''))
                body = ASS_TAGS.sub('', row.get('Text', '')).replace('\\N', '\n').replace('\\n', '\n').strip()
                if start is not None and end is not None and body:
                    cues.append((start, end, body))
        return sorted(cues)
    for block in re.split(r'\n\s*\n', text):
        lines = [l for l in block.split('\n') if l.strip()]
        for index, line in enumerate(lines):
            found = ARROW.search(line)
            if found:
                start, end = _seconds(found.group(1)), _seconds(found.group(2))
                body = '\n'.join(lines[index + 1:]).strip()
                if start is not None and end is not None and body:
                    cues.append((start, end, body))
                break
    return sorted(cues)


def _starts(cues):
    starts = sorted({round(c[0], 2) for c in cues})
    if len(starts) > SAMPLE:
        step = len(starts) / float(SAMPLE)
        starts = [starts[int(i * step)] for i in range(SAMPLE)]
    return starts


def _near(sorted_values, value):
    """Distance from value to the nearest of the sorted values."""
    import bisect
    at = bisect.bisect_left(sorted_values, value)
    best = float('inf')
    for i in (at - 1, at):
        if 0 <= i < len(sorted_values):
            best = min(best, abs(sorted_values[i] - value))
    return best


def align(target, reference):
    """(ratio, shift, share, matches) mapping target times t -> t * ratio + shift,
    or None when the reference does not fit the subtitle."""
    import bisect
    mine, theirs = _starts(target), sorted(c[0] for c in reference)
    if len(mine) < MIN_MATCHES or len(theirs) < MIN_MATCHES:
        return None
    best = None
    for ratio in RATIOS:
        votes = {}
        for t in mine:
            scaled = t * ratio
            low = bisect.bisect_left(theirs, scaled - SEARCH)
            high = bisect.bisect_right(theirs, scaled + SEARCH)
            for r in theirs[low:high]:
                bucket = int(round((r - scaled) / BIN))
                votes[bucket] = votes.get(bucket, 0) + 1
        if not votes:
            continue
        # The strongest bucket with its neighbours (a shift between two buckets).
        bucket = max(votes, key=lambda b: votes[b] + 0.5 * (votes.get(b - 1, 0) + votes.get(b + 1, 0)))
        shift = bucket * BIN
        diffs = []
        for t in mine:
            scaled = t * ratio + shift
            at = bisect.bisect_left(theirs, scaled)
            near = min((theirs[i] for i in (at - 1, at) if 0 <= i < len(theirs)), key=lambda r: abs(r - scaled))
            if abs(near - scaled) <= MATCH:
                diffs.append(near - scaled)
        if not diffs:
            continue
        diffs.sort()
        shift += diffs[len(diffs) // 2]                  # the median refines it
        matches = sum(1 for t in mine if _near(theirs, t * ratio + shift) <= MATCH)
        share = matches / float(len(mine))
        if best is None or (share, -abs(ratio - 1)) > (best[2], -abs(best[0] - 1)):
            best = (ratio, shift, share, matches)
    if best is None or best[2] < MIN_SHARE or best[3] < MIN_MATCHES:
        return None
    return best


def retime(cues, ratio, shift):
    out = []
    for start, end, body in cues:
        start, end = start * ratio + shift, end * ratio + shift
        if end > 0:
            out.append((max(0.0, start), end, body))
    return out


def _stamp(value):
    ms = int(round(value * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return '%02d:%02d:%02d,%03d' % (h, m, s, ms)


def to_srt(cues):
    blocks = []
    for index, (start, end, body) in enumerate(cues, 1):
        clean = html.unescape(TAGS.sub(lambda m: m.group(0) if m.group(0).lower() in ('<i>', '</i>', '<b>', '</b>') else '', body))
        blocks.append('%d\n%s --> %s\n%s\n' % (index, _stamp(start), _stamp(end), clean))
    return '\n'.join(blocks)


def describe(ratio, shift):
    parts = ['%+.1f s' % shift]
    if abs(ratio - 1) > 1e-4:
        for a, b in ((25, 23.976), (23.976, 25), (24, 23.976), (23.976, 24), (25, 24), (24, 25)):
            if abs(ratio - a / b) < 1e-4:
                parts.append('%g→%g fps' % (a, b))
                break
    return ' · '.join(parts)


TOKENS = re.compile(r'[a-z0-9]+')
QUIET = {'mkv', 'mp4', 'avi', 'srt', 'sub', 'subs', 'eng', 'english', 'x264', 'x265', 'h264', 'h265', 'hevc',
         'aac', 'ac3', 'ddp5', 'dd5', 'the', 'and', 'www', 'com', 'org'}


def release_tokens(text):
    return {t for t in TOKENS.findall(str(text or '').lower()) if len(t) > 1 and t not in QUIET}


def similarity(a, b):
    a, b = release_tokens(a), release_tokens(b)
    return len(a & b) / float(len(a | b)) if a and b else 0.0
