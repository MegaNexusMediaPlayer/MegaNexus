"""MegaNexus modular boundary package."""
