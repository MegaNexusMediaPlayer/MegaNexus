"""MegaNexus data/playback boundary. No skins, source races, sorting or quality filters."""
import re

ADDON_ID = 'plugin.video.meganexus'


def provider(role, providers=None):
    from .meganexus import store
    providers = list(providers if providers is not None else store.list_providers())
    from .settings_cache import setting
    chosen = setting('meganexus_' + role + '_provider')
    if chosen:
        return next((p for p in providers if p.get('id') == chosen), None)
    needle = 'aiometadata' if role == 'metadata' else 'aiostreams'
    candidates = [p for p in providers if needle in re.sub(r'[^a-z0-9]', '',
        (str((p.get('manifest') or {}).get('id','')) + str((p.get('manifest') or {}).get('name','')) + str(p.get('name',''))).lower())]
    if len(candidates)==1:return candidates[0]
    resource='meta' if role=='metadata' else 'stream'
    compatible=[p for p in providers if resource in {r.get('name') if isinstance(r,dict) else r for r in (p.get('manifest') or {}).get('resources') or []}]
    return compatible[0] if len(compatible)==1 else None


def metadata(media_type, canonical_id, timeout=8, preferred=''):
    """Resolve only through enabled, compatible add-ons; never relabel another title."""
    import time
    from .meganexus.client import fetch_meta
    from . import metadata_providers
    from .resource_support import same_identity
    sources = metadata_providers.enabled(media_type, canonical_id, preferred=preferred)
    deadline = time.monotonic() + max(1, timeout)
    reasons = [] if sources else ['no switched-on metadata add-on for this ID']
    for index, source in enumerate(sources):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            reasons.append('no time left')
            break
        try:
            data = fetch_meta(source, media_type, canonical_id,
                              timeout_override=max(.25, min(4, remaining / max(1, len(sources)-index))), retry=False, rate_wait=.1)
            meta = (data or {}).get('meta')
            if not same_identity(meta, media_type, canonical_id):
                reasons.append('%s: %s' % (source.get('name') or source.get('id'),
                                           'another title (%s %s)' % ((meta or {}).get('type'), str((meta or {}).get('id') or '')[:24])
                                           if meta else 'no details'))
                continue
            from .plugin import _normalize_meta_art_urls
            from .title_details import normalize_people_art
            meta = normalize_people_art(_normalize_meta_art_urls(source, meta), source)
            result = dict(meta, id=canonical_id, type=media_type,
                          _meganexus_metadata_provider=source['id'])
            if media_type == 'series':
                try:
                    from .watch_nextup import remember
                    remember(result, source['id'])
                except Exception:
                    pass
            return result
        except Exception as exc:
            # Configured URLs and keys must not escape into logs or UI errors.
            reasons.append('%s: %s' % (source.get('name') or source.get('id'), type(exc).__name__))
            continue
    fallback = _fallback_metadata(media_type, canonical_id, reasons)
    try:   # 7.0.31: why a title page says "Retry details" (or which stand-in answered)
        import xbmc
        xbmc.log('[MegaNexus] details %s for %s %s - %s' % ('from %s' % fallback['_meganexus_fallback'] if fallback else 'unavailable',
                 media_type, str(canonical_id)[:40], '; '.join(reasons) or 'no add-on'), xbmc.LOGINFO)
    except Exception:
        pass
    if fallback:
        return fallback
    if not sources:
        raise ValueError('Enable a metadata add-on supporting this title ID in Settings > Add-ons.')
    raise ValueError('No enabled metadata add-on returned matching details. Check the collection mapping and connection.')


def _fallback_metadata(media_type, canonical_id, reasons, timeout=5):
    """7.0.31: when the switched-on metadata add-ons give no details (an ID they
    do not know, another title, a timeout), Cinemeta - always installed, also
    when switched off - answers for the title's IMDb ID, found through TMDb for
    a tmdb: ID when a TMDb key is set; a film may also come from TMDb itself.
    The title is never guessed: Cinemeta must return the same IMDb ID, and a
    TMDb ID is only translated through TMDb's own external IDs."""
    from .meganexus.client import fetch_meta
    from .resource_support import same_identity
    cid = str(canonical_id or '')
    kind = 'series' if media_type in ('series', 'tv', 'show', 'tvshow', 'episode') else 'movie'
    imdb = cid.split(':')[0] if cid.startswith('tt') else ''
    tmdb = cid.split(':', 1)[1].split(':')[0] if cid.startswith('tmdb:') else ''
    try:
        from . import tmdb_direct
        keyed = bool(tmdb_direct._api_key())
    except Exception:
        tmdb_direct, keyed = None, False
    if not imdb and tmdb and keyed:
        imdb = tmdb_direct.imdb_id_for(tmdb, kind, timeout=4)
    if imdb:
        try:
            from . import default_setup
            from .meganexus import store
            cinemeta = default_setup.cinemeta_provider(store.list_providers()) or {
                'id': 'cinemeta', 'name': 'Cinemeta', 'manifest': default_setup.bundled_manifest(),
                'manifest_url': default_setup.CINEMETA_URL, 'base_url': default_setup.CINEMETA_URL.rsplit('/manifest.json', 1)[0]}
            meta = (fetch_meta(cinemeta, kind, imdb, timeout_override=timeout, retry=False, rate_wait=.1) or {}).get('meta')
            if same_identity(meta, kind, imdb):
                return dict(meta, id=canonical_id, type=media_type, imdb_id=imdb,
                            _meganexus_metadata_provider=cinemeta['id'], _meganexus_fallback='Cinemeta')
            reasons.append('Cinemeta: %s' % ('another title' if meta else 'no details'))
        except Exception as exc:
            reasons.append('Cinemeta: %s' % type(exc).__name__)
    if kind == 'movie' and keyed and (tmdb or imdb):
        # Series need their episodes, which only an add-on (or Cinemeta) lists.
        try:
            found = tmdb_direct.meta_for(tmdb_id=tmdb, imdb_id=imdb, media_type='movie')
        except Exception:
            found = {}
        if found.get('name') and (not tmdb or str(found.get('tmdb_id')) == tmdb):
            return {'id': canonical_id, 'type': media_type, 'name': found['name'], 'poster': found.get('poster') or '',
                    'background': found.get('fanart') or '', 'logo': found.get('clearlogo') or '',
                    'description': found.get('description') or '', 'releaseInfo': found.get('year') or '',
                    'year': found.get('year') or '', 'genres': found.get('genres') or [],
                    'runtime': ('%d min' % found['runtime']) if found.get('runtime') else '',
                    'imdbRating': found.get('imdbRating') or '', 'imdb_id': found.get('imdb_id') or imdb,
                    'tmdb_id': found.get('tmdb_id') or tmdb, 'director': [found['director']] if found.get('director') else [],
                    'cast': [c.get('name') for c in found.get('cast') or [] if c.get('name')],
                    '_meganexus_metadata_provider': 'tmdb', '_meganexus_fallback': 'TMDb'}
        reasons.append('TMDb: no details')
    return None


STREAM_TIMEOUT = 20
STREAM_GRACE = 2.5


def _assemble(results, servers, sources, media_type):
    """The rows found so far: own servers first, then the configured add-on order
    (not arrival order), each link once, best first."""
    rows = [row for source in servers + sources for row in results.get(source['id'], [])]
    # 7.0.29: the same link once (several configurations of one add-on gave every
    # source two or three times).
    seen, unique = set(), []
    for row in rows:
        key = row.get('url') or (row.get('infoHash') and '%s:%s' % (row.get('infoHash'), row.get('fileIdx'))) or ''
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        unique.append(row)
    rows = unique
    # 7.0.12: best first by the user's stream preferences (Playback > Automatic stream choice).
    try:
        from . import stream_choice
        rows = stream_choice.order(rows, media_type)
    except Exception as exc:
        import xbmc
        xbmc.log('[MegaNexus] stream preferences not applied: %s' % exc, xbmc.LOGWARNING)
    return rows


def imdb_video_id(media_type, video_id):
    """tmdb:123 -> tt..., tmdb:123:1:2 -> tt...:1:2 (TMDb's external IDs, cached);
    '' when there is no TMDb key or no IMDb ID."""
    value = str(video_id or '')
    if not value.startswith('tmdb:'):
        return ''
    parts = value.split(':')
    try:
        from . import tmdb_direct
        kind = 'series' if media_type in ('series', 'tv', 'show', 'tvshow', 'episode') else 'movie'
        imdb = tmdb_direct.imdb_id_for(parts[1], kind, timeout=4)
    except Exception:
        imdb = ''
    return ':'.join([imdb] + parts[2:]) if imdb else ''


def streams(media_type, video_id, complete=False, on_update=None):
    """Query enabled providers independently and retain each provider's ordering.
    ``complete`` (7.0.29, the source list): wait for every add-on (up to
    STREAM_TIMEOUT) - a choice must show them all, not only the fastest.
    ``on_update(rows)`` gets the rows found so far after every answer, so the
    source list can open with the first ones and grow."""
    from concurrent.futures import ThreadPoolExecutor
    from . import stream_providers
    from .meganexus.client import get_json, build_resource_url
    sources = stream_providers.enabled(media_type, video_id)
    addon_video_id = video_id
    if not sources:
        # 7.0.31: no switched-on stream add-on takes this ID (a tmdb: title from a
        # collection; Torrentio, Comet... take IMDb IDs). Only then it is asked by
        # its IMDb ID - from TMDb's external IDs, already cached by the details.
        alias = imdb_video_id(media_type, video_id)
        if alias:
            sources = stream_providers.enabled(media_type, alias)
            if sources:
                addon_video_id = alias
    # 6.0.39 (beta): the user's own Plex / Jellyfin servers, when switched on,
    # are searched at the same time and listed first.
    try:
        from . import media_servers
        server_jobs = media_servers.source_jobs(media_type, video_id)
    except Exception:
        server_jobs = []
    # 7.0.12: TorBox / Premiumize built in (no add-on), searched at the same time.
    try:
        from . import debrid
        server_jobs.extend(debrid.jobs(media_type, video_id))
    except Exception:
        pass
    if not sources and not server_jobs:
        raise ValueError('Enable a compatible stream add-on in Settings > Add-ons > Stream add-ons.')

    def fetch(source):
        data = get_json(build_resource_url(source, 'stream', media_type, addon_video_id),
                        ttl_seconds=0, timeout_override=20, retry=False, rate_wait=0.25)
        rows = (data or {}).get('streams')
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ValueError('Invalid stream response')
        # A provider cannot spoof provenance. Never alter its labels, hints,
        # duplicate streams, headers, or ranking; attach our own trusted origin.
        origin = {key: source.get(key) or '' for key in ('id', 'name', 'base_url')}
        origin['name'] = origin['name'] or (source.get('manifest') or {}).get('name') or source['id']
        return [dict(row, _meganexus_source=origin) for row in rows]

    # Every add-on starts at once. As soon as one returns streams, the others
    # get STREAM_GRACE more seconds; stragglers are skipped (they finish in the
    # background) instead of holding "Loading video" for up to 20 seconds.
    import time
    from concurrent.futures import wait, FIRST_COMPLETED
    results, errors, slow = {}, [], []
    pool = ThreadPoolExecutor(max_workers=min(8, len(sources) + len(server_jobs)), thread_name_prefix='MegaNexusStreams')
    futures = {pool.submit(fetch, source): source for source in sources}
    servers = [{'id': '__server_%d__' % i, 'name': name} for i, (name, _) in enumerate(server_jobs)]
    futures.update({pool.submit(job): server for server, (_, job) in zip(servers, server_jobs)})
    pending = set(futures)
    deadline = time.monotonic() + STREAM_TIMEOUT
    grace = None
    try:
        while pending:
            remaining = (grace or deadline) - time.monotonic()
            if remaining <= 0:
                break
            done, pending = wait(pending, timeout=remaining, return_when=FIRST_COMPLETED)
            for future in done:
                source = futures[future]
                try:
                    found = future.result()
                except Exception:
                    # Do not log configured URLs: they can contain account tokens.
                    errors.append(source.get('name') or source['id'])
                    continue
                results[source['id']] = found
                if found and on_update is not None:
                    try:
                        on_update(_assemble(results, servers, sources, media_type))
                    except Exception:
                        pass
                # 7.0.29: only a stream add-on starts the grace - the built-in TorBox /
                # Premiumize search answers in a moment and cut every add-on off.
                if found and grace is None and not complete and source in sources:
                    grace = min(deadline, time.monotonic() + STREAM_GRACE)
    finally:
        pool.shutdown(wait=False)
    slow = [s.get('name') or s['id'] for s in (futures[f] for f in pending)]
    rows = _assemble(results, servers, sources, media_type)
    if not rows and len(errors) + len(slow) == len(sources) + len(servers):
        raise ValueError('Stream add-ons could not respond. Check their configuration and connection.')
    first = sources[0] if sources else {'id': '__servers__', 'name': 'Your servers', 'base_url': ''}
    return dict(first, _meganexus_errors=errors, _meganexus_slow=slow), rows


def playback_context(meta, row, source, season='', episode='', video_id='', resume_seconds=0):
    from . import plugin as p, title_details
    source = row.get('_meganexus_source') or source
    url = p._stream_play_url_from_row(row)
    if not url:
        raise ValueError('This stream add-on result has no Kodi-playable URL. Check its provider/debrid configuration or choose another result.')
    ids = p.extract_ids(meta)
    info = p._meta_info(meta)
    try:resume_seconds=max(0.0,float(resume_seconds or 0))
    except (TypeError,ValueError):resume_seconds=0.0
    return {
        'media_type': meta.get('type') or 'movie', 'canonical_id': meta['id'],
        'video_id': video_id or meta['id'], 'season': season, 'episode': episode,
        'title': meta.get('name') or meta.get('title') or meta['id'],
        'show_title': meta.get('name') or meta.get('title') or '',
        'stream_url': url, 'provider_id': source['id'], 'provider_name': source.get('name') or source['id'],
        'provider_base_url': source.get('base_url') or '', 'poster': meta.get('poster') or '',
        'background': meta.get('background') or '', 'clearlogo': meta.get('logo') or '',
        'tmdb_id': ids.get('tmdb_id') or '', 'imdb_id': ids.get('imdb_id') or '', 'tvdb_id': ids.get('tvdb_id') or '',
        'external_ids': ids, 'kodi_info': info, 'plot': info.get('plot') or '',
        'year': info.get('year') or 0, 'resume_seconds': resume_seconds,
        'meganexus_resume_exact': resume_seconds>0,
        'next_episode': title_details.next_episode(meta,video_id) if meta.get('type')=='series' else None,
        'subtitles': row.get('subtitles') or [], 'behaviorHints': row.get('behaviorHints') or {},
        'request_headers': p._stream_row_request_headers(row),
        'stream_name': row.get('name') or '', 'stream_title': row.get('title') or '',
        # 6.0.39: a Plex / Jellyfin copy reports progress and watched to its server.
        **(_server_keys(row)),
    }


def _server_keys(row):
    if not row.get('_meganexus_server'):
        return {}
    from . import media_servers
    return media_servers.playback_keys(row)


def queue_playback(context):
    from . import cache_store
    from .context import build_url
    key = cache_store.put('meganexus_play', context)
    return build_url(action='meganexus_play', key=key)


def play_queued(key):
    from .wallpaper_video import suspend
    from .refresh_guard import release_all
    suspend()
    release_all()   # 7.0.29: the TV's refresh rate is chosen as playback opens
    from . import cache_store, plugin
    context = cache_store.get('meganexus_play', key)
    if not isinstance(context, dict) or not context.get('stream_url'):
        raise ValueError('Playback request expired. Choose the title again.')
    import xbmcgui
    from . import debrid
    if str(context['stream_url']).startswith(debrid.SCHEME):
        # 7.0.12: TorBox / Premiumize give the link only now (the row holds the torrent).
        import xbmc
        try:
            context['stream_url'] = debrid.resolve(context['stream_url'], monitor=xbmc.Monitor())
        except Exception as exc:
            xbmcgui.Dialog().notification('Debrid', str(exc)[:120], time=6000)
            xbmcgui.Window(10000).setProperty('meganexus.playback.error', context.get('meganexus_request_id') or '')
            raise
    xbmcgui.Window(10000).setProperty('meganexus.subtitle.context',key)
    return plugin._play_with_context(context, use_resolved_url=False)


def catalog_entries(bucket=''):
    from .metadata_providers import enabled
    desired = {'movies': 'movie', 'series': 'series'}.get(bucket)
    result = []
    for source in enabled():
        for catalog in (source.get('manifest') or {}).get('catalogs') or []:
            mt = catalog.get('type')
            if mt not in ('movie', 'series') or (desired and mt != desired):
                continue
            if bucket == 'anime' and 'anime' not in (str(catalog.get('id', '')) + str(catalog.get('name', ''))).lower():
                continue
            result.append((source, catalog, 'movies' if mt == 'movie' else 'series'))
    return result
