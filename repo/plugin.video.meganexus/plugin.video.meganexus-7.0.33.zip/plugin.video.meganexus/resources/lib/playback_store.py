# -*- coding: utf-8 -*-
"""Backward-compat shim. Real implementation lives in meganexus.playback_store."""
from meganexus.playback_store import *  # noqa: F401,F403
