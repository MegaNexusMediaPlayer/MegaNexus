"""Preserve every release within its language, loading one selected file at a time."""
from . import subtitle_broker as broker
import json
import xbmc
import xbmcaddon
import xbmcgui

NAMES={'hr':'Croatian','sr':'Serbian','bs':'Bosnian','sl':'Slovenian','en':'English','de':'German','it':'Italian','fr':'French','es':'Spanish','pt':'Portuguese','und':'Unknown language'}

def language(value):
    if isinstance(value,(list,tuple)):
        return next((language(v) for v in value if language(v)!='und'),'und')
    if isinstance(value,dict):
        value=next((value[k] for k in ('lang','language','languageCode','code','name') if value.get(k)),'und')
    raw=str(value or 'und').strip().lower()
    aliases={'cro':'hr','hrv':'hr','croatian':'hr','hrvatski':'hr','ser':'sr','srp':'sr','serbian':'sr','bos':'bs','bosnian':'bs','slv':'sl','slovenian':'sl'}
    if raw in aliases:return aliases[raw]
    # Kodi owns the language registry, including names outside our common labels.
    try:
        code=xbmc.convertLanguage(raw,xbmc.ISO_639_1)
        if code:return code.lower()
        code=xbmc.convertLanguage(raw,xbmc.ISO_639_2)
        if code:return code.lower()
    except Exception:pass
    return broker._normalize_lang(raw)

def languages():
    data=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,
        'method':'Settings.GetSettings','params':{'level':'expert'}})))
    setting=next((s for s in data.get('result',{}).get('settings',[])
                  if s.get('id')=='locale.subtitlelanguage'),{})
    excluded={'none','forced_only','original','default','mediadefault',''}
    rows=[{'label':r['label'],'value':r['value']} for r in setting.get('options',[])
          if r.get('value') not in excluded]
    if not rows:raise ValueError('Kodi could not return its subtitle languages. Reopen Settings and try again.')
    return rows

def preferred():
    addon=xbmcaddon.Addon('plugin.video.meganexus')
    return addon.getSetting('meganexus_subtitle_language') or (addon.getSetting('preferred_subtitle_langs') or 'en').split(',')[0]

def language_name(value):
    try:
        name=xbmc.convertLanguage(str(value),xbmc.ENGLISH_NAME)
        if name:return name
    except Exception:pass
    return NAMES.get(language(value),str(value))

def group_rows(rows):
    groups={}
    for row in rows:
        clean=dict(row);lang=language(row.get('lang') or row.get('language'))
        clean['lang']=lang;groups.setdefault(lang,[]).append(clean)
    return groups

def external_rows(context,search=False):
    # Searching with an empty seed avoids the old broker's early exit when the
    # stream already supplied a sidecar. Include both sets AFTER provider search.
    initial=[]
    for raw in context.get('subtitles') or []:
        row=broker._coerce_subtitle(raw)
        if row:
            row['sourceName']=row.get('sourceName') or context.get('provider_name') or 'Stream provider'
            initial.append(row)
    if search:
        found=broker.search_subtitles(context,initial_subtitles=[],max_results=1000)
        initial=broker._dedupe(initial+found)
    for row in initial:row['lang']=language(row.get('lang'))
    return initial

def prepare_selected(row,key):
    from .playback.subtitle_files import _prepare_subtitle_files
    result=_prepare_subtitle_files([row],key,prefer_local_copy=True,defer_download=False)
    if not result or str(result[0]['path']).startswith(('http://','https://')):
        raise ValueError('The selected subtitle could not be downloaded. Try another release.')
    return result[0]['path']

def auto_apply(context,player=None):
    """Search off the playback path; one matching file, never a different video."""
    from .session_store import load_session
    player=player or xbmc.Player()
    uid=context.get('playback_uid');request=context.get('meganexus_request_id')
    wanted=language(context.get('meganexus_subtitle_language') or preferred())
    home=xbmcgui.Window(10000)
    def current():
        try:
            return bool(uid and request and player.isPlayingVideo() and
                (load_session() or {}).get('playback_uid')==uid and
                home.getProperty('meganexus.playback.started')==request and
                home.getProperty('meganexus.subtitle.manual')!=request)
        except Exception:return False
    if not current():return False
    # Source-native releases already match this video. Search other installed
    # addons only if the source did not supply the selected language.
    rows=[r for r in external_rows(context,search=False) if language(r.get('lang'))==wanted]
    if not rows:
        rows=[r for r in external_rows(context,search=True) if language(r.get('lang'))==wanted]
    if not current():return False
    # Preserve the provider's order, including numbered Croatian releases. 7.0.29: a
    # release that cannot be downloaded (its server is off, or answers with an error
    # page) gives way to the next one instead of leaving the film without subtitles.
    key=context.get('video_id') or context.get('canonical_id') or uid
    for selected in rows[:AUTO_TRIES]:
        try:path=prepare_selected(selected,key)
        except ValueError:continue
        if not current():return False
        player.setSubtitles(path);player.showSubtitles(True)
        remember_active(path,selected)
        return True
    if rows:raise ValueError('The selected subtitle could not be downloaded. Try another release.')
    return False


AUTO_TRIES=8


AUTOSYNC='meganexus_autosync_subtitles'   # 7.0.29: Autosync subtitle offset - on for everyone


def remember_active(path,row=None):
    """7.0.29: the downloaded subtitle on screen - what the player's Sync button retimes."""
    import json
    home=xbmcgui.Window(10000)
    home.setProperty('meganexus.subtitle.path',str(path or ''))
    home.setProperty('meganexus.subtitle.row',json.dumps(row or {},default=str))
    from .settings_cache import cached_addon
    on=(cached_addon().getSetting(AUTOSYNC) or 'true')!='false'
    home.setProperty('meganexus.subtitle.syncable','1' if path and on else '')


def _read(path):
    import xbmcvfs
    handle=xbmcvfs.File(path)
    try:raw=bytes(handle.readBytes())
    finally:handle.close()
    for codec in ('utf-8-sig','cp1250','latin-1'):
        try:return raw.decode(codec)
        except UnicodeDecodeError:continue
    return raw.decode('utf-8','replace')


def references(context,current_row,limit=10):
    """Other subtitles of the playing title, any language, as (row, likeness):
    the stream's own first, then releases named most like the stream. Never the
    subtitle being synced."""
    from .subtitle_sync import similarity
    name=' '.join(str(context.get(k) or '') for k in ('stream_title','stream_name'))
    mine=str((current_row or {}).get('url') or '')
    own=[r for r in external_rows(context,search=False) if str(r.get('url') or '')!=mine]
    seen={str(r.get('url') or '') for r in own}|{mine}
    found=[r for r in external_rows(context,search=True) if str(r.get('url') or '') not in seen]
    def likeness(r):return similarity(name,r.get('displayName') or r.get('name') or r.get('release') or '')
    ranked=sorted(found,key=likeness,reverse=True)
    return [(r,1.0) for r in own][:limit]+[(r,likeness(r)) for r in ranked][:max(0,limit-len(own))]


def _fetch_all(rows,key,wait=14.0):
    """Download the references side by side; whatever arrived within ``wait``."""
    import threading,time
    out=[None]*len(rows)
    def one(i,row):
        try:out[i]=_read(prepare_selected(row,'%s-ref%d'%(key,i)))
        except Exception:pass
    threads=[threading.Thread(target=one,args=(i,r),name='MegaNexusSyncRef',daemon=True) for i,r in enumerate(rows)]
    for th in threads:th.start()
    until=time.monotonic()+wait
    for th in threads:th.join(max(0.0,until-time.monotonic()))
    return out


def consensus(results):
    """results: [(ratio, shift, share, matches, likeness)]. Subtitles of most releases
    are timed alike: the timing most references agree on (a release named like the
    stream counts more) is the video's. Returns (ratio, shift, share, agreeing) or None."""
    groups=[]
    for found in results:
        ratio,shift,share,_,like=found
        weight=share*(1+2*like)
        for group in groups:
            if abs(group['ratio']-ratio)<1e-3 and abs(group['shift']-shift)<.35:
                group['weight']+=weight;group['members'].append(found);break
        else:groups.append({'ratio':ratio,'shift':shift,'weight':weight,'members':[found]})
    if not groups:return None
    best=max(groups,key=lambda g:g['weight'])
    members=best['members']
    sure=len(members)>=2 or members[0][4]>=.35 or members[0][2]>=.6
    if not sure:return None
    lead=max(members,key=lambda m:(m[4],m[2]))
    return lead[0],lead[1],lead[2],len(members)


def autosync(context,key='sync'):
    """(new path, description) or raises ValueError with what is missing."""
    import hashlib,json,os
    import xbmcvfs
    from . import subtitle_sync as sync
    home=xbmcgui.Window(10000)
    path=home.getProperty('meganexus.subtitle.path')
    if not path:raise ValueError('Sync works on subtitles MegaNexus downloaded. Choose one with the Subtitles button first.')
    try:row=json.loads(home.getProperty('meganexus.subtitle.row') or '{}')
    except ValueError:row={}
    target=sync.parse(_read(path))
    if len(target)<sync.MIN_MATCHES:raise ValueError('This subtitle has too few lines to sync.')
    # 7.0.29: compared with the other subtitles of this title from the subtitle
    # add-ons (any language - cues start when people speak), the timing most of
    # them agree on wins; nothing changes when they do not agree.
    refs=references(context,row)
    if not refs:raise ValueError('The subtitle add-ons returned no other subtitle of this title to compare with.')
    texts=_fetch_all([r for r,_ in refs],key)
    results=[]
    for (ref,like),text in zip(refs,texts):
        if not text:continue
        found=sync.align(target,sync.parse(text))
        if found:results.append(found+(like,))
    if not any(texts):raise ValueError('The other subtitles of this title could not be downloaded. Try again in a moment.')
    best=consensus(results)
    if not best:
        raise ValueError('The other subtitles of this title do not agree on one timing - this version may be made for '
                         'a different cut. Try another subtitle version.')
    ratio,shift,share,agree=best
    if abs(ratio-1)<1e-4 and abs(shift)<.15:return path,'Already in sync (%d subtitles agree)'%agree
    folder=os.path.dirname(xbmcvfs.translatePath(path)) or xbmcvfs.translatePath('special://temp/')
    name='synced-%s.srt'%hashlib.sha1(('%s|%s|%s'%(path,ratio,shift)).encode('utf-8')).hexdigest()[:12]
    out=os.path.join(folder,name)
    with open(out,'w',encoding='utf-8') as handle:handle.write(sync.to_srt(sync.retime(target,ratio,shift)))
    return out,'%s · %d subtitles agree'%(sync.describe(ratio,shift),agree)

