"""Read-only local tracking audit, executed inside Kodi; no credentials output."""
import sqlite3
from pathlib import Path
import xbmcaddon
import xbmcvfs

addon=xbmcaddon.Addon('plugin.video.meganexus')
from . import trakt,simkl,mdblist_tracking,stremio_account
from .meganexus import nuvio_stremio_sync as sync


def flag(key,default=True):
    return (addon.getSetting(key) or ('true' if default else 'false'))=='true'


def check(linked,fn):
    if not linked:return 'not_connected'
    try:fn();return 'responds'
    except Exception as error:
        code=getattr(error,'code',None)
        return 'HTTP %s'%code if isinstance(code,int) else type(error).__name__


def check_connections():
    nuvio=sync.Nuvio.is_linked();stremio=stremio_account.linked()
    t=trakt.authorized();s=simkl.authorized();m=bool(mdblist_tracking.api_key())
    report={
        'Nuvio':{'connected':nuvio,'sync':flag('nuvio_sync_enabled'),'profile_selected':bool(sync.Nuvio.token().get('profile_index')),
                 'direction':sync._direction_for('nuvio'),'sections':sync._sections_for('nuvio'),
                 'connection':check(nuvio,lambda:sync.Nuvio.profiles())},
        'Stremio':{'connected':stremio,'sync':stremio_account.keep_in_sync(),
                   'connection':check(stremio,lambda:sync.Stremio._api('addonCollectionGet',{'authKey':sync.Stremio._auth_key(),'update':True}))},
        'Trakt':{'connected':t,'sync':trakt.enabled() and trakt.sync_enabled(),'scrobble':trakt.enabled() and trakt.scrobble_enabled(),
                 'connection':check(t,lambda:trakt._request('/sync/last_activities',auth=True,timeout=6))},
        'Simkl':{'connected':s,'sync':simkl.enabled() and flag('simkl_service_sync'),'scrobble':simkl.mark_watched_enabled(),
                 'connection':check(s,lambda:simkl._request('/sync/activities',method='POST',payload={},auth=True,timeout=6))},
        'MDBList':{'connected':m,'sync':mdblist_tracking.enabled(),'scrobble':mdblist_tracking.enabled(),
                   'connection':check(m,lambda:mdblist_tracking.request('GET','/sync/last_activities',timeout=6))}}
    folder=Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
    path=folder/'playback.db';counts={}
    if path.is_file():
        connection=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=2)
        try:
            names={r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for name in ('nuvio_progress_outbox','playback_progress'):
                if name in names:counts[name]=connection.execute('SELECT COUNT(*) FROM '+name).fetchone()[0]
        finally:connection.close()
    report['local']=counts
    return report

