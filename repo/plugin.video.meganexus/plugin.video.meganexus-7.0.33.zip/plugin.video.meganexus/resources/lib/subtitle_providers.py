"""Subtitle switches per add-on (7.0.17), like the stream and metadata ones.

An add-on that publishes a "subtitles" resource (OpenSubtitles, an all-in-one
add-on such as AIOStreams...) can be switched on or off as a subtitle source on
its own, whatever else it serves. Until the user changes one, every subtitle
add-on is on - as before 7.0.17 - and add-ons added later start on too.
"""
from . import addon_switches

SETTING = 'meganexus_subtitle_providers'


def candidates(providers=None):
    from .meganexus import store
    providers = store.list_providers() if providers is None else providers
    return [p for p in providers if p.get('id') and any(
        (r.get('name') if isinstance(r, dict) else r) == 'subtitles'
        for r in (p.get('manifest') or {}).get('resources') or [])]


def entries(providers=None):
    return addon_switches.entries(SETTING, candidates(providers))


def enabled_ids(providers=None):
    return {p['id'] for p, on in entries(providers) if on}


def set_enabled(provider_id, on):
    addon_switches.set_enabled(SETTING, entries(), provider_id, on, 'This add-on does not offer subtitles.')
