"""A MegaNexus film never plays behind Home (7.0.29).

Sometimes a film started but Kodi did not switch to its full-screen video:
it played on behind Home and could not be left. And Back from the player
left the film running under the HUB. The service watches a MegaNexus film
(Window(Home).Property(meganexus.playing.request_id)):

* not on screen 4 s after it started (Back / Esc pressed while it loaded) - it
  is paused and the HUB offers "Now playing" to carry on in full screen;
* the player left for Home or the HUB for 1 s - the film is stopped (its
  progress is saved as on any stop);
* the player's Home button (park) - the film plays on behind Home and "Now
  playing" brings it back to full screen.

Dialogs over the player (sources, subtitles, audio, info) keep Kodi's
full-screen window underneath, so they are never mistaken for leaving.
"""
import time

import xbmc
import xbmcgui

BRING_UP = 4.0
# MegaNexus screens that, open over the video, mean it plays behind (Kodi still
# counts its full-screen video as active underneath them).
COVERS = ' | '.join('Window.IsVisible(%s)' % name for name in (
    'meganexus_home.xml', 'meganexus_home_compact.xml', 'meganexus_details.xml', 'meganexus_details_landscape.xml',
    'meganexus_catalog.xml', 'meganexus_catalog_landscape.xml', 'meganexus_library.xml', 'meganexus_person.xml'))


def on_screen():
    return xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)') and not xbmc.getCondVisibility(COVERS)
WAITING = 'meganexus.background_film'
LEFT = 1.0


def _ours(player, home):
    if not home.getProperty('meganexus.playing.request_id'):
        return False
    if home.getProperty('meganexus.preview.active') or home.getProperty('meganexus.playback.choosing'):
        return False
    try:
        from .wallpaper_video import is_background
        if is_background(player):
            return False
    except Exception:
        pass
    try:
        if not player.isPlayingVideo():
            return False
        wanted = home.getProperty('meganexus.playing.request_id')
        request = player.getPlayingItem().getProperty('meganexus.request')
        if request:
            return request == wanted
        # a resolver handoff can lose the item's properties: the service confirmed the start
        return home.getProperty('meganexus.playback.started') == wanted
    except Exception:
        return False


def run(monitor):
    player, home = xbmc.Player(), xbmcgui.Window(10000)
    started = away = None
    seen = parked_away = False
    failures = 0
    xbmc.log('[MegaNexus] Film guard on.', xbmc.LOGINFO)
    while not monitor.abortRequested():
        try:
            if _ours(player, home):
                now = time.monotonic()
                started = started or now
                if on_screen():
                    seen, away = True, None
                    if parked_away:            # back through "Now playing"
                        home.clearProperty(WAITING)
                        parked_away = False
                elif home.getProperty(WAITING):
                    away, parked_away = None, True     # behind Home, "Now playing" shown
                elif seen:
                    away = away or now
                    if now - away >= LEFT:
                        xbmc.log('[MegaNexus] The player was left for Home - the film stops.', xbmc.LOGINFO)
                        player.stop()
                        seen, away, started = False, None, None
                elif now - started >= BRING_UP and not home.getProperty(WAITING):
                    # Back / Esc pressed while it started: it waits, paused, for the
                    # HUB's "Now playing" pill (review/make_hub_now_playing.py).
                    xbmc.log('[MegaNexus] The film started behind the HUB - paused, Now playing shown.', xbmc.LOGINFO)
                    if not xbmc.getCondVisibility('Player.Paused'):
                        xbmc.executebuiltin('PlayerControl(Play)')
                    home.setProperty(WAITING, '1')
            else:
                started = away = None
                seen = parked_away = False
                if home.getProperty(WAITING):
                    home.clearProperty(WAITING)
        except Exception:
            failures += 1
            if failures <= 3:
                import traceback
                xbmc.log('[MegaNexus] Film guard: ' + traceback.format_exc(), xbmc.LOGWARNING)
        if monitor.waitForAbort(0.5):
            break


def park():
    """The player's Home button: the film plays on behind MegaNexus Home, whose
    "Now playing" brings it back to full screen."""
    home = xbmcgui.Window(10000)
    home.setProperty(WAITING, '1')
    xbmc.log('[MegaNexus] Home from the player - the film plays on, Now playing shown.', xbmc.LOGINFO)
    # Back leads to the screen the film was started from. Kodi ignores it while the
    # player bar is still fading out, so it is sent once no dialog is closing.
    monitor = xbmc.Monitor()
    until = time.monotonic() + 4
    while time.monotonic() < until and not monitor.abortRequested():
        if not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
            return
        if not xbmc.getCondVisibility('System.HasActiveModalDialog | Window.IsVisible(videoosd)'):
            xbmc.executebuiltin('Action(Back)')
            monitor.waitForAbort(0.4)
        else:
            monitor.waitForAbort(0.1)
    if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
        xbmc.executebuiltin('ActivateWindow(Home)')
