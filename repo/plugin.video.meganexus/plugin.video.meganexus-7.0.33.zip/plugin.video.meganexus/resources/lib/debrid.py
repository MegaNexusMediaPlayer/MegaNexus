"""Debrid services built in (7.0.12): TorBox and Premiumize, no stream add-on.

TorBox closed its own search API (search-api.torbox.app has no DNS record any
more; api.torbox.app/openapi.json has no search). So MegaNexus finds the
torrents of a title by its IMDb id in a public index (Torrentio, which
TorBox's search also used), asks each service which of them it already has
(cached = plays at once) and lists those next to the stream add-ons:

* TorBox      POST /v1/api/torrents/checkcached?format=list {"hashes": [...]}
              play: createtorrent (magnet) -> mylist?id= -> requestdl -> CDN link
* Premiumize  GET  /api/cache/check?items[]=...
              play: POST /api/transfer/directdl (src=magnet) -> file link

"Cached only" (default on) lists only what a service already has. Off, the
others are listed as "Not cached"; choosing one starts the download on the
account and waits up to UNCACHED_WAIT seconds. The links that are played
never carry an API key, and keys are never logged.
"""
import base64
import json
import re
import time
import uuid
from urllib.parse import urlencode
from urllib.request import Request, urlopen

INDEX = 'https://torrentio.strem.fun'
TORBOX = 'https://api.torbox.app/v1/api'
PREMIUMIZE = 'https://www.premiumize.me/api'
SCHEME = 'meganexus-debrid://'
CACHED_SETTING = 'debrid_cached_only'
SERVICES = {
    'torbox': {'name': 'TorBox', 'key': 'torbox_api_key', 'on': 'torbox_enabled', 'short': 'TB'},
    'premiumize': {'name': 'Premiumize', 'key': 'premiumize_api_key', 'on': 'premiumize_enabled', 'short': 'PM'},
}
TIMEOUT = 12
UNCACHED_WAIT = 60
MAX_HASHES = 80
VIDEO = re.compile(r'\.(?:mkv|mp4|m4v|avi|ts|m2ts|mov|wmv|webm)$', re.I)
SAMPLE = re.compile(r'\b(?:sample|trailer|featurette|extras?)\b', re.I)
_SIZE = re.compile(r'💾\s*(\d+(?:[.,]\d+)?)\s*(TB|GB|MB)', re.I)
_SEEDERS = re.compile(r'👤\s*(\d+)')


def _addon():
    from .settings_cache import cached_addon
    return cached_addon()


def _setting(name, default=''):
    try:
        return (_addon().getSetting(name) or default).strip()
    except Exception:
        return default


def api_key(service):
    return _setting(SERVICES[service]['key'])


def enabled(service):
    return bool(api_key(service)) and _setting(SERVICES[service]['on'], 'true').lower() != 'false'


def active():
    return [s for s in SERVICES if enabled(s)]


def cached_only():
    return _setting(CACHED_SETTING, 'true').lower() != 'false'


def _http(url, method='GET', params=None, json_body=None, form=None, headers=None, timeout=TIMEOUT):
    if params:
        url = url + ('&' if '?' in url else '?') + urlencode(params, doseq=True)
    headers = dict({'Accept': 'application/json', 'User-Agent': 'MegaNexus/7'}, **(headers or {}))
    body = None
    if json_body is not None:
        body = json.dumps(json_body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    elif form is not None:
        boundary = uuid.uuid4().hex
        body = (''.join('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n' % (boundary, k, v)
                        for k, v in form.items()) + '--%s--\r\n' % boundary).encode('utf-8')
        headers['Content-Type'] = 'multipart/form-data; boundary=' + boundary
    try:
        with urlopen(Request(url, data=body, method=method, headers=headers), timeout=timeout) as response:
            return json.loads(response.read().decode('utf-8', 'replace') or '{}')
    except Exception as exc:
        code = getattr(exc, 'code', None)
        detail = ''
        try:
            payload = json.loads(exc.read().decode('utf-8', 'replace'))
            detail = payload.get('detail') or payload.get('message') or ''
        except Exception:
            pass
        if code in (401, 403):
            raise ValueError('The API key was not accepted.')
        raise ValueError(str(detail)[:100] if detail else 'HTTP %s' % (code or type(exc).__name__))


# ---- index ------------------------------------------------------------
def _video_ref(media_type, video_id):
    """('movie'|'series', 'tt123[:s:e]', season, episode) or None (IMDb ids only)."""
    parts = str(video_id or '').split(':')
    if not parts or not parts[0].startswith('tt'):
        return None
    if str(media_type or 'movie') == 'movie' or len(parts) < 3:
        return 'movie', parts[0], None, None
    try:
        return 'series', '%s:%d:%d' % (parts[0], int(parts[1]), int(parts[2])), int(parts[1]), int(parts[2])
    except ValueError:
        return None


def _size(title):
    match = _SIZE.search(str(title or ''))
    if not match:
        return 0
    return float(match.group(1).replace(',', '.')) * {'TB': 1e12, 'GB': 1e9, 'MB': 1e6}[match.group(2).upper()]


def index(media_type, video_id):
    """Torrents of the title: [{'hash', 'title', 'filename', 'size', 'seeders', 'file_idx'}]."""
    ref = _video_ref(media_type, video_id)
    if not ref:
        return []
    kind, stremio_id, _, _ = ref
    data = _http('%s/stream/%s/%s.json' % (INDEX, kind, stremio_id), timeout=15)
    found, seen = [], set()
    for row in (data or {}).get('streams') or []:
        digest = str(row.get('infoHash') or '').lower()
        if not re.fullmatch(r'[0-9a-f]{40}', digest) or digest in seen:
            continue
        seen.add(digest)
        title = str(row.get('title') or '')
        hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
        seeders = _SEEDERS.search(title)
        found.append({'hash': digest, 'title': title.split('\n')[0], 'filename': hints.get('filename') or title.split('\n')[0],
                      'size': _size(title), 'seeders': int(seeders.group(1)) if seeders else 0,
                      'file_idx': row.get('fileIdx'), 'label': str(row.get('name') or '').replace('Torrentio', '').strip()})
        if len(found) >= MAX_HASHES:
            break
    return found


# ---- cache checks -----------------------------------------------------
def _torbox_cached(hashes):
    data = _http(TORBOX + '/torrents/checkcached', method='POST', params={'format': 'list'},
                 json_body={'hashes': hashes}, headers={'Authorization': 'Bearer ' + api_key('torbox')})
    rows = (data or {}).get('data') or []
    if isinstance(rows, dict):
        rows = list(rows.values())
    return {str(r.get('hash') or '').lower() for r in rows if isinstance(r, dict)}


def _premiumize_cached(hashes):
    data = _http(PREMIUMIZE + '/cache/check', params={'apikey': api_key('premiumize'), 'items[]': hashes})
    if (data or {}).get('status') != 'success':
        raise ValueError(str((data or {}).get('message') or 'Premiumize did not answer')[:100])
    answers = data.get('response') or []
    return {h for h, ok in zip(hashes, answers) if ok}


CACHE_CHECK = {'torbox': _torbox_cached, 'premiumize': _premiumize_cached}


def _token(service, item, season, episode, cached):
    data = {'v': service, 'h': item['hash'], 's': season, 'e': episode, 'c': cached, 'i': item.get('file_idx')}
    return SCHEME + base64.urlsafe_b64encode(json.dumps(data).encode('utf-8')).decode('ascii')


def _size_label(size):
    return ('%.2f GB' % (size / 1e9)) if size >= 1e9 else (('%.0f MB' % (size / 1e6)) if size else '')


def stream_rows(service, media_type, video_id, found=None):
    """Stremio-shaped rows of one service for the source list."""
    ref = _video_ref(media_type, video_id)
    if not ref:
        return []
    _, _, season, episode = ref
    found = index(media_type, video_id) if found is None else found
    if not found:
        return []
    cached = CACHE_CHECK[service]([item['hash'] for item in found])
    only_cached = cached_only()
    name, short = SERVICES[service]['name'], SERVICES[service]['short']
    rows = []
    for item in found:
        hit = item['hash'] in cached
        if only_cached and not hit:
            continue
        detail = [item['title']]
        if item['size']:
            detail.append('💾 ' + _size_label(item['size']) + ('  👤 %d' % item['seeders'] if item['seeders'] else ''))
        if not hit:
            detail.append('Not cached - %s downloads it first' % name)
        rows.append({'name': '[%s%s] %s\n%s' % (short, '+' if hit else ' ⏳', name, item['label']),
                     'title': '\n'.join(detail), 'url': _token(service, item, season, episode, hit),
                     'behaviorHints': {'videoSize': int(item['size']) or None, 'filename': item['filename'],
                                       'bingeGroup': '%s-%s' % (service, item['label'] or 'any')},
                     'meganexus_cached': hit})
    return rows


def jobs(media_type, video_id):
    """[(name, fn)] one per active service; the index is asked once and shared."""
    services = active()
    if not services or not _video_ref(media_type, video_id):
        return []
    shared = {}

    def found():
        if 'rows' not in shared:
            shared['rows'] = index(media_type, video_id)
        return shared['rows']

    import threading
    lock = threading.Lock()

    def job(service):
        with lock:
            rows = found()
        origin = {'id': service, 'name': SERVICES[service]['name'], 'base_url': ''}
        return [dict(row, _meganexus_source=origin) for row in stream_rows(service, media_type, video_id, rows)]
    return [(SERVICES[s]['name'], (lambda s=s: job(s))) for s in services]


# ---- play -------------------------------------------------------------
def decode(token):
    raw = str(token or '')[len(SCHEME):]
    raw += '=' * (-len(raw) % 4)
    return json.loads(base64.urlsafe_b64decode(raw.encode('ascii')).decode('utf-8'))


def _episode_match(name, season, episode):
    text = str(name or '').lower()
    return any(re.search(p, text) for p in (r's0*%d[ ._-]*e0*%d(?!\d)' % (season, episode),
                                             r'(?<!\d)0*%dx0*%d(?!\d)' % (season, episode)))


def pick_file(files, season=None, episode=None, name=lambda f: f.get('short_name') or f.get('name') or f.get('path')):
    """The video to play: the episode asked for, else the largest video."""
    videos = [f for f in files or [] if isinstance(f, dict) and VIDEO.search(str(name(f) or ''))
              and not SAMPLE.search(str(name(f) or '').rsplit('/', 1)[-1])]
    videos = videos or [f for f in files or [] if isinstance(f, dict)]
    if season is not None and episode is not None:
        matches = [f for f in videos if _episode_match(str(name(f) or '').rsplit('/', 1)[-1], season, episode)]
        videos = matches or videos
    return max(videos, key=lambda f: float(f.get('size') or 0)) if videos else None


def _magnet(digest):
    return 'magnet:?xt=urn:btih:%s' % digest


def _wait(monitor, seconds):
    if monitor is not None:
        if monitor.waitForAbort(seconds):
            raise ValueError('Cancelled.')
    else:
        time.sleep(seconds)


def _torbox_resolve(info, monitor, wait):
    auth = {'Authorization': 'Bearer ' + api_key('torbox')}
    form = {'magnet': _magnet(info['h']), 'seed': '3', 'allow_zip': 'false'}
    if info.get('c'):
        form['add_only_if_cached'] = 'true'
    created = (_http(TORBOX + '/torrents/createtorrent', method='POST', form=form, headers=auth, timeout=20) or {}).get('data') or {}
    torrent_id = created.get('torrent_id') or created.get('id')
    if not torrent_id:
        raise ValueError('TorBox did not add the torrent.')
    deadline = time.monotonic() + (wait if wait is not None else (8 if info.get('c') else UNCACHED_WAIT))
    while True:
        listing = (_http(TORBOX + '/torrents/mylist', params={'id': torrent_id, 'bypass_cache': 'true'}, headers=auth) or {}).get('data') or {}
        files = listing.get('files') or []
        if files and (listing.get('download_finished') or listing.get('download_present')):
            break
        if time.monotonic() >= deadline:
            raise ValueError('TorBox is still downloading this one (%d%%). Try again later.'
                             % int(float(listing.get('progress') or 0) * 100))
        _wait(monitor, 2)
    chosen = pick_file(files, info.get('s'), info.get('e'))
    if not chosen:
        raise ValueError('TorBox found no video in this result.')
    link = (_http(TORBOX + '/torrents/requestdl', params={'token': api_key('torbox'), 'torrent_id': torrent_id,
                                                          'file_id': chosen.get('id')}) or {}).get('data')
    if not isinstance(link, str) or not link.startswith('http'):
        raise ValueError('TorBox did not return a link.')
    return link


def _premiumize_resolve(info, monitor, wait):
    key = api_key('premiumize')
    if not info.get('c'):
        created = _http(PREMIUMIZE + '/transfer/create', method='POST', params={'apikey': key},
                        form={'src': _magnet(info['h'])}) or {}
        if created.get('status') != 'success' and 'already' not in str(created.get('message') or '').lower():
            raise ValueError(str(created.get('message') or 'Premiumize did not add it')[:100])
        raise ValueError('Premiumize is downloading this one. Try again later.')
    data = _http(PREMIUMIZE + '/transfer/directdl', method='POST', params={'apikey': key},
                 form={'src': _magnet(info['h'])}, timeout=20) or {}
    if data.get('status') != 'success':
        raise ValueError(str(data.get('message') or 'Premiumize did not return a link')[:100])
    chosen = pick_file(data.get('content') or [], info.get('s'), info.get('e'), name=lambda f: f.get('path'))
    link = (chosen or {}).get('stream_link') or (chosen or {}).get('link')
    if not isinstance(link, str) or not link.startswith('http'):
        raise ValueError('Premiumize found no video in this result.')
    return link


def resolve(token, monitor=None, wait=None):
    """Playable link for a debrid row (adds the torrent to the account)."""
    info = decode(token)
    service = info.get('v')
    if service not in SERVICES or not enabled(service):
        raise ValueError('Turn %s on in HUB Settings > Add-ons.' % SERVICES.get(service, {}).get('name', 'the service'))
    try:
        return (_torbox_resolve if service == 'torbox' else _premiumize_resolve)(info, monitor, wait)
    except ValueError as exc:
        raise ValueError('%s: %s' % (SERVICES[service]['name'], exc))


def check(service):
    if service == 'torbox':
        return bool((_http(TORBOX + '/user/me', headers={'Authorization': 'Bearer ' + api_key('torbox')}) or {}).get('data'))
    data = _http(PREMIUMIZE + '/account/info', params={'apikey': api_key('premiumize')}) or {}
    return data.get('status') == 'success'
