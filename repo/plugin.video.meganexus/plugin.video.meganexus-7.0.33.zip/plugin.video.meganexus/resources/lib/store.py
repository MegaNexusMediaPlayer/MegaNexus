# -*- coding: utf-8 -*-
"""Backward-compat shim. Real implementation lives in meganexus.store."""
from meganexus.store import *  # noqa: F401,F403
