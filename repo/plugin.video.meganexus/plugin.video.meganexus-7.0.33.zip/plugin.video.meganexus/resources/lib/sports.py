"""Sports add-ons (6.0.35, GitHub issue #8).

Sports add-ons get their own Sports screen and never enter the movie/series
Home, Search, Continue Watching or the tracking services (like IPTV channels).

An add-on is a sports add-on when its manifest or catalogs use a sports type
(``sport``, ``sports``, ``events``...) or its name/id/description is clearly
about sports. Its catalogs are loaded with a short cache (live events change
during the day) and its streams are played as previews, which the playback
companion never tracks.
"""
import re
import time

SPORT_TYPES = {'sport', 'sports', 'event', 'events', 'live', 'match', 'matches'}
_WORDS = re.compile(r'\b(sports?|football|soccer|nba|nfl|nhl|mlb|ufc|mma|boxing|f1|formula ?1|motogp|'
                    r'cricket|rugby|tennis|darts|wrestling|live ?events?)\b', re.I)
CATALOG_TTL = 300            # seconds a sports page counts as fresh
CATALOG_STALE = 24 * 3600    # shown at once while it refreshes
STREAM_TIMEOUT = 15


def _manifest(provider):
    return (provider or {}).get('manifest') or {}


def _types(manifest):
    found = {str(t).lower() for t in manifest.get('types') or [] if isinstance(t, str)}
    for catalog in manifest.get('catalogs') or []:
        if isinstance(catalog, dict) and catalog.get('type'):
            found.add(str(catalog['type']).lower())
    for resource in manifest.get('resources') or []:
        if isinstance(resource, dict):
            found.update(str(t).lower() for t in resource.get('types') or [] if isinstance(t, str))
    return found


def is_sports_provider(provider):
    manifest = _manifest(provider)
    types = _types(manifest)
    if types & SPORT_TYPES:
        return True
    if types & {'movie', 'series'}:
        # A movie/series add-on only counts when its name says so.
        text = ' '.join(str(x or '') for x in (manifest.get('name'), provider.get('name'), manifest.get('id')))
    else:
        text = ' '.join(str(x or '') for x in (manifest.get('name'), provider.get('name'), manifest.get('id'),
                                               manifest.get('description')))
    return bool(_WORDS.search(text))


def ensure_enabled(all_providers=None):
    """Every sports add-on serves its own metadata and streams: both switches
    ON (user request, 6.0.35). Returns the add-ons that were switched."""
    from . import metadata_providers, stream_providers
    switched = []
    sports_ids = {p['id'] for p in providers(all_providers)}
    if not sports_ids:
        return switched
    for module in (metadata_providers, stream_providers):
        try:
            rows = module.entries()
        except Exception:
            continue
        for provider, on in rows:
            if provider['id'] in sports_ids and not on:
                try:
                    module.set_enabled(provider['id'], True)
                    switched.append(provider['id'])
                except ValueError:
                    pass
    return switched


def is_sports_type(media_type):
    return str(media_type or '').lower() in SPORT_TYPES


# 7.0.11: sport catalogs of general add-ons (AIOMetadata "⚽ Nogomet • Uživo",
# id ...sports_direct.tv.football_live) belong in the Sports screen too.
_SPORT_EMOJI = re.compile('[\u26bd\u26be\u26f3\U0001F3C0\U0001F3C1\U0001F3C8\U0001F3C9\U0001F3CE\U0001F3CF'
                          '\U0001F3D0\U0001F3D1\U0001F3D2\U0001F3D3\U0001F3F8\U0001F94A\U0001F94D\U0001F94E]')
_SPORT_ID = re.compile(r'sport|football|soccer|basketball|tennis|racing|cricket|rugby|hockey|baseball|'
                       r'boxing|fight|ufc|mma|wrestling|darts|nogomet|ko[sš]ark|rukomet|odbojk|utakmic', re.I)
_TITLES = ('movie', 'series', 'anime')


def is_sports_catalog(catalog_type, catalog_id='', name=''):
    """A sport catalog: a sport type, or a TV/other catalog whose id or name says
    sport. Movie and series catalogs only by a sport emoji in the name, so
    "Sports dramas" stays a movie collection."""
    kind = str(catalog_type or '').lower()
    if kind in SPORT_TYPES:
        return True
    if _SPORT_EMOJI.search(str(name or '')):
        return True
    if kind.startswith(_TITLES):
        return False
    return bool(_SPORT_ID.search('%s %s' % (catalog_id or '', name or '')))


def is_sports_source(source):
    """A collection source (addonId, catalogId, type) pointing at a sport catalog."""
    source = source or {}
    return is_sports_catalog(source.get('type'), source.get('catalogId') or source.get('id'), source.get('name'))


def providers(all_providers=None):
    from .meganexus import store
    rows = store.list_providers() if all_providers is None else all_providers
    return [p for p in rows if is_sports_provider(p)]


def _usable(catalog):
    if not isinstance(catalog, dict) or not catalog.get('id') or not catalog.get('type'):
        return False
    # 7.0.12: a required genre with a list of options (AIOMetadata's sport
    # catalogs: None / Football / Nogomet) still lists its events; only other
    # required inputs (a search text...) make a catalog unusable here.
    required = [e for e in catalog.get('extra') or [] if isinstance(e, dict) and e.get('isRequired')]
    required += [{'name': name} for name in catalog.get('extraRequired') or [] if isinstance(name, str)]
    return all(e.get('name') == 'genre' and _genre_options(catalog) for e in required)


def _genre_options(catalog):
    for extra in catalog.get('extra') or []:
        if isinstance(extra, dict) and extra.get('name') == 'genre':
            return [str(o) for o in extra.get('options') or [] if str(o or '').strip()]
    return []


def _sport_catalogs(provider):
    """The add-on's catalogs for the Sport screen. 7.0.29: a mixed add-on (AIOStreams
    with sport, movie, series and anime catalogs) gives only its sport ones - its
    films and series filled Sport and every one of them was waited for."""
    whole = is_sports_provider(provider)
    found = []
    for catalog in _manifest(provider).get('catalogs') or []:
        if not _usable(catalog):
            continue
        kind = str(catalog.get('type') or '').lower()
        if is_sports_catalog(kind, catalog.get('id'), catalog.get('name')) or (whole and not kind.startswith(_TITLES)):
            found.append(catalog)
    return found


def offers_sport(provider):
    """The add-on has something for the Sport screen (its Sport switch, 7.0.20)."""
    return bool(is_sports_provider(provider) or _sport_catalogs(provider))


def _sport_on(rows):
    """Ids of the add-ons whose Sport switch is on (7.0.20)."""
    from .sport_providers import enabled_ids
    try:
        return enabled_ids(rows)
    except Exception:
        return {p.get('id') for p in rows}


def catalogs(all_providers=None):
    """[(provider, catalog)] in manifest order, live/today first: every catalog of
    a sports add-on and the sport catalogs of general add-ons (7.0.11), for the
    add-ons whose Sport switch is on (7.0.20)."""
    from .meganexus import store
    rows = store.list_providers() if all_providers is None else all_providers
    allowed = _sport_on(rows)
    found = []
    for provider in rows:
        if provider.get('id') not in allowed:
            continue
        for catalog in _sport_catalogs(provider):
            found.append((provider, catalog))

    def rank(pair):
        name = '%s %s' % (pair[1].get('id'), pair[1].get('name'))
        return 0 if re.search(r'live', name, re.I) else (1 if re.search(r'today|now', name, re.I) else 2)
    return sorted(found, key=rank)


def _key(provider, catalog):
    from . import browse_cache
    return browse_cache.key('sports-v1', browse_cache.provider_key(provider), catalog.get('type'), catalog.get('id'))


def cached_page(provider, catalog):
    """(metas, fresh) from the cache, without network."""
    from . import browse_cache
    value, fresh = browse_cache.instance().lookup(_key(provider, catalog))
    metas = (value or {}).get('metas') if isinstance(value, dict) else None
    return (metas if isinstance(metas, list) else None), fresh


def load_page(provider, catalog, timeout=8):
    """First page of a sports catalog from the add-on (and into the cache)."""
    from . import browse_cache
    from .meganexus.client import get_json, build_resource_url
    # No HTTP-level cache: live events change during the day.
    data = get_json(build_resource_url(provider, 'catalog', catalog['type'], catalog['id'], extra={}),
                    ttl_seconds=0, timeout_override=timeout, retry=False, rate_wait=.1)
    metas = [m for m in (data or {}).get('metas') or [] if isinstance(m, dict) and m.get('id')]
    if not metas:
        # A catalog whose genre is required may list nothing without one: its first real option.
        options = [o for o in _genre_options(catalog) if o.lower() != 'none']
        if options:
            data = get_json(build_resource_url(provider, 'catalog', catalog['type'], catalog['id'], extra={'genre': options[0]}),
                            ttl_seconds=0, timeout_override=timeout, retry=False, rate_wait=.1)
            metas = [m for m in (data or {}).get('metas') or [] if isinstance(m, dict) and m.get('id')]
    if not metas:
        # 7.0.29: an empty answer (an add-on busy for a moment) never replaces the
        # events already shown - the posters vanished and Sport stayed empty.
        previous, _ = cached_page(provider, catalog)
        if previous:
            return previous
    browse_cache.instance().put(_key(provider, catalog), {'metas': metas}, ttl=CATALOG_TTL, stale=CATALOG_STALE)
    return metas


def refresh_manifests(stopped=None):
    """7.0.29: the sport add-ons' manifests again at every Sport entry - their
    catalogs change during the day. Returns the names that changed."""
    from . import manifest_refresh
    ids = {p.get('id') for p, _ in catalogs()} | {p.get('id') for p in providers()}
    return manifest_refresh.refresh_all(timeout=5, stopped=stopped, only=ids)


def card(provider, catalog, meta):
    from .plugin import _normalize_meta_art_urls
    try:
        meta = _normalize_meta_art_urls(provider, meta)
    except Exception:
        pass
    art = meta.get('poster') or meta.get('background') or meta.get('logo') or ''
    return {'title': str(meta.get('name') or meta.get('id')), 'id': meta['id'], 'type': meta.get('type') or catalog['type'],
            'art': art, 'background': meta.get('background') or art, 'description': meta.get('description') or '',
            'info': meta.get('releaseInfo') or '', 'provider_id': provider['id'],
            'live': 'live' in str(meta.get('releaseInfo') or '').lower()}


def poster_urls(rows, per_row=8):
    urls, seen = [], set()
    for row in rows:
        for item in row[:per_row]:
            url = str(item.get('art') or '')
            if url.startswith(('https://', 'http://')) and '|' not in url and url not in seen:
                seen.add(url)
                urls.append(url)
    return urls


def _play_url(stream):
    """Kodi URL for one stream, with the add-on's request headers."""
    from urllib.parse import urlencode
    url = str(stream.get('url') or '')
    if not url.startswith(('http://', 'https://')):
        return ''
    hints = stream.get('behaviorHints') or {}
    headers = {}
    proxy = hints.get('proxyHeaders') or {}
    request = proxy.get('request') if isinstance(proxy.get('request'), dict) else proxy
    if isinstance(request, dict):
        headers.update({str(k): str(v) for k, v in request.items() if isinstance(v, (str, int))})
    if isinstance(stream.get('requestHeaders'), dict):
        headers.update({str(k): str(v) for k, v in stream['requestHeaders'].items()})
    return url + ('|' + urlencode(headers) if headers else '')


def streams(item, all_providers=None):
    """Playable streams of one sports event from every sports add-on that serves it."""
    from concurrent.futures import ThreadPoolExecutor
    from .meganexus.client import get_json, build_resource_url
    from .resource_support import supports
    sports_rows = providers(all_providers)
    allowed = _sport_on(sports_rows)
    sports_rows = [p for p in sports_rows if p['id'] in allowed]
    sources = [p for p in sports_rows if supports(p, 'stream', item['type'], item['id'])]
    if not sources:
        sources = [p for p in sports_rows if p['id'] == item.get('provider_id')]
    if not sources:
        # 7.0.12: an event from a general add-on's sport catalog (AIOMetadata):
        # the enabled stream add-ons that serve its type and id (e.g. AIOStreams).
        from .meganexus import store
        from .stream_providers import enabled as stream_enabled
        try:
            allowed = {p['id'] for p in stream_enabled()}
        except Exception:
            allowed = None
        rows = store.list_providers() if all_providers is None else all_providers
        sources = [p for p in rows if (allowed is None or p['id'] in allowed) and supports(p, 'stream', item['type'], item['id'])]

    def fetch(source):
        data = get_json(build_resource_url(source, 'stream', item['type'], item['id']),
                        ttl_seconds=0, timeout_override=STREAM_TIMEOUT, retry=False, rate_wait=.1)
        rows = []
        for stream in (data or {}).get('streams') or []:
            if not isinstance(stream, dict):
                continue
            url = _play_url(stream)
            if url:
                label = str(stream.get('name') or source.get('name') or 'Stream').replace('\n', ' · ')
                detail = str(stream.get('title') or stream.get('description') or '').replace('\n', ' · ')
                rows.append({'label': label, 'detail': detail, 'url': url})
        return rows
    result = []
    if not sources:
        return result
    with ThreadPoolExecutor(max_workers=min(4, len(sources)), thread_name_prefix='MegaNexusSportStreams') as pool:
        for future in [pool.submit(fetch, s) for s in sources]:
            try:
                result.extend(future.result(timeout=STREAM_TIMEOUT + 2))
            except Exception:
                continue
    return result


def now():
    return time.time()
