Import examples: from meganexus import add_provider_from_url, get_stream_results
