# -*- coding: utf-8 -*-
import json
import os
import re
import shutil
import uuid

import xbmc

from .common import profile_path
from .safe_io import write_json as _atomic_write_json, read_json as _safe_read_json

PROVIDERS_PATH = os.path.join(profile_path(), 'providers.json')
CATALOG_STATE_PATH = os.path.join(profile_path(), 'catalog_state.json')

_PROVIDERS_CACHE = None
_PROVIDERS_MTIME = None
_STATE_CACHE = None
_STATE_MTIME = None


def _file_mtime(path):
    try:
        return os.path.getmtime(path)
    except Exception:
        return None


# v3.9.17: state I/O delegated to safe_io for atomic writes + .bak recovery.
# These wrappers exist so the rest of store.py stays unchanged in shape.
def _read_json(path, default):
    return _safe_read_json(path, default)


def _write_json(path, value):
    _atomic_write_json(path, value)


def _invalidate_providers_cache(rows=None):
    global _PROVIDERS_CACHE, _PROVIDERS_MTIME
    _PROVIDERS_CACHE = rows
    _PROVIDERS_MTIME = _file_mtime(PROVIDERS_PATH)


def _invalidate_state_cache(state=None):
    global _STATE_CACHE, _STATE_MTIME
    _STATE_CACHE = state
    _STATE_MTIME = _file_mtime(CATALOG_STATE_PATH)


# 7.0.30: one install of an add-on behind links that differ only in their last,
# encrypted part - AIOStreams: <host>/stremio/<uuid>/<encrypted>/manifest.json,
# and the encrypted part changes each time the link is copied. Every new copy
# (Nuvio sync, phone page) was added as one more add-on: MEGAMAN11 two or three
# times in every list, and its sources three times.
_INSTANCE = re.compile(r'^(https?://[^/?#]+/(?:[^/?#]+/)*?[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})'
                       r'/[^/?#]+/manifest\.json$', re.I)


def instance_key(manifest_url):
    found = _INSTANCE.match(str(manifest_url or '').strip())
    return found.group(1).lower() if found else ''


# Per-role on/off lists, [{"id": provider id, "enabled": bool}] in one setting each.
ROLE_SETTINGS = ('meganexus_metadata_providers', 'meganexus_stream_providers',
                 'meganexus_subtitle_providers', 'meganexus_sport_providers')
REPAIR_SETTING = 'meganexus_merged_switches'   # 7.0.31: devices merged by 7.0.30 repaired once


def _role_lists(addon):
    for setting in ROLE_SETTINGS:
        try:
            rows = json.loads(addon.getSetting(setting) or 'null')
        except ValueError:
            continue
        if isinstance(rows, list):
            yield setting, [row for row in rows if isinstance(row, dict)]


def _carry_switches(moved):
    """7.0.31: the copy that stays takes over the switches of the copies merged
    into it ({removed id: kept id}). 7.0.30 kept only its own: a device whose
    switched-on copy was merged away had no metadata add-on on ("Retry
    details" everywhere) or no stream add-on."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        for setting, rows in _role_lists(addon):
            on = {moved.get(row.get('id'), row.get('id')) for row in rows if row.get('enabled') is True}
            out, seen = [], set()
            for row in rows:
                pid = moved.get(row.get('id'), row.get('id'))
                if pid in seen:
                    continue
                seen.add(pid)
                out.append({'id': pid, 'enabled': pid in on})
            if out != rows:
                addon.setSetting(setting, json.dumps(out))
        from resources.lib import settings_cache
        settings_cache.invalidate()
    except Exception as exc:
        xbmc.log('[MegaNexus] add-on switches not carried over: %s' % exc, xbmc.LOGWARNING)


def _repair_switches(rows):
    """Once per device: a switched-on add-on that 7.0.30 merged away passes its
    switch to the copy of the same install that stayed."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        if addon.getSetting(REPAIR_SETTING) == 'done':
            return
        present = {row.get('id') for row in rows if isinstance(row, dict)}
        copies = {row.get('id') for row in rows if isinstance(row, dict) and instance_key(row.get('manifest_url'))}
        for setting, saved in _role_lists(addon):
            gone_on = [row for row in saved if row.get('enabled') is True and row.get('id') not in present]
            if not gone_on or not copies:
                continue
            ids = [row.get('id') for row in saved]
            out = [dict(row, enabled=True) if row.get('id') in copies else row for row in saved if row.get('id') in present]
            out += [{'id': pid, 'enabled': True} for pid in copies if pid not in ids]
            addon.setSetting(setting, json.dumps(out))
            xbmc.log('[MegaNexus] add-on switches repaired after the 7.0.30 merge (%s)' % setting, xbmc.LOGINFO)
        addon.setSetting(REPAIR_SETTING, 'done')
        from resources.lib import settings_cache
        settings_cache.invalidate()
    except Exception as exc:
        xbmc.log('[MegaNexus] add-on switch repair skipped: %s' % exc, xbmc.LOGWARNING)


def _merge_instances(rows, moved=None):
    """Copies of one install become one: the first row (its id keeps the add-on's
    switches) with the newest link and manifest. ``moved`` collects
    {removed id: kept id}."""
    first, out = {}, []
    for row in rows:
        key = instance_key(row.get('manifest_url')) if isinstance(row, dict) else ''
        if key and key in first:
            kept = first[key]
            if moved is not None and row.get('id') and kept.get('id'):
                moved[row['id']] = kept['id']
            kept['manifest_url'] = row['manifest_url']
            kept['base_url'] = row.get('base_url') or row['manifest_url'].rsplit('/manifest.json', 1)[0]
            if row.get('manifest'):
                kept['manifest'] = row['manifest']
            continue
        if key:
            first[key] = row
        out.append(row)
    return out


_REPAIRED = []


def list_providers():
    global _PROVIDERS_CACHE, _PROVIDERS_MTIME
    mtime = _file_mtime(PROVIDERS_PATH)
    if _PROVIDERS_CACHE is not None and mtime == _PROVIDERS_MTIME:
        return list(_PROVIDERS_CACHE)
    rows = _read_json(PROVIDERS_PATH, [])
    moved = {}
    merged = _merge_instances(rows, moved) if isinstance(rows, list) else rows
    if isinstance(rows, list) and len(merged) != len(rows):
        xbmc.log('[MegaNexus] add-ons: %d copies of the same install merged' % (len(rows) - len(merged)), xbmc.LOGINFO)
        _write_json(PROVIDERS_PATH, merged)
        mtime = _file_mtime(PROVIDERS_PATH)
        _carry_switches(moved)
    if isinstance(merged, list) and not _REPAIRED:
        _REPAIRED.append(True)
        _repair_switches(merged)
    _PROVIDERS_CACHE = merged
    _PROVIDERS_MTIME = mtime
    return list(merged)


def write_providers_raw(rows):
    """v3.9.45: bulk-write the providers list, used by the import path
    when restoring a previously-exported configuration snapshot. Skips
    the per-provider validation flow because the snapshot already
    captured validated manifests at export time."""
    if not isinstance(rows, list):
        return
    _write_json(PROVIDERS_PATH, rows)
    _invalidate_providers_cache(rows)


def add_provider(name, manifest_url, manifest):
    rows = list_providers()
    base_url = manifest_url.rsplit('/manifest.json', 1)[0]
    key = instance_key(manifest_url)
    for row in rows:
        if row.get('manifest_url') == manifest_url or (key and instance_key(row.get('manifest_url')) == key):
            # 7.0.30: a new copy of the same install's link replaces the old one.
            row.update({'name': name, 'manifest_url': manifest_url, 'base_url': base_url, 'manifest': manifest})
            _write_json(PROVIDERS_PATH, rows)
            _invalidate_providers_cache(rows)
            return row
    row = {
        'id': uuid.uuid4().hex[:10],
        'name': name,
        'manifest_url': manifest_url,
        'base_url': base_url,
        'manifest': manifest,
    }
    rows.append(row)
    _write_json(PROVIDERS_PATH, rows)
    _invalidate_providers_cache(rows)
    return row


def refresh_provider_manifest(provider_id, new_manifest):
    """Update a provider's manifest snapshot without touching its id/name."""
    rows = list_providers()
    for row in rows:
        if row.get('id') == provider_id:
            row['manifest'] = new_manifest
            if new_manifest and new_manifest.get('name') and not row.get('name'):
                row['name'] = new_manifest.get('name')
            _write_json(PROVIDERS_PATH, rows)
            _invalidate_providers_cache(rows)
            return row
    return None


def remove_provider(provider_id):
    rows = [row for row in list_providers() if row.get('id') != provider_id]
    _write_json(PROVIDERS_PATH, rows)
    _invalidate_providers_cache(rows)
    state = _catalog_state()
    state = {k: v for k, v in state.items() if not k.startswith(provider_id + ':')}
    _write_json(CATALOG_STATE_PATH, state)
    _invalidate_state_cache(state)


# v3.9.34: provider reordering. The list order returned by
# list_providers() is the order shown in Sources, AND the order used to
# rank streams in the source picker (top of list = top of stream list).
def move_provider(provider_id, direction):
    """Move a provider up (-1) or down (+1) by one position.

    Returns the new index (0-based) on success, or None if the provider
    wasn't found or the move would push it out of bounds.
    """
    rows = list_providers()
    idx = None
    for i, row in enumerate(rows):
        if row.get('id') == provider_id:
            idx = i
            break
    if idx is None:
        return None
    new_idx = idx + (1 if direction > 0 else -1)
    if new_idx < 0 or new_idx >= len(rows):
        return None
    rows.insert(new_idx, rows.pop(idx))
    _write_json(PROVIDERS_PATH, rows)
    _invalidate_providers_cache(rows)
    return new_idx


def move_provider_to(provider_id, new_idx):
    """Move a provider to an absolute index. Used for "Move to top" or
    "Move to bottom" shortcuts where the user knows exactly where they
    want the provider."""
    rows = list_providers()
    src_idx = None
    for i, row in enumerate(rows):
        if row.get('id') == provider_id:
            src_idx = i
            break
    if src_idx is None:
        return None
    new_idx = max(0, min(int(new_idx), len(rows) - 1))
    if new_idx == src_idx:
        return src_idx
    rows.insert(new_idx, rows.pop(src_idx))
    _write_json(PROVIDERS_PATH, rows)
    _invalidate_providers_cache(rows)
    return new_idx


def get_provider(provider_id):
    for row in list_providers():
        if row.get('id') == provider_id:
            return row
    return None


def _catalog_state():
    global _STATE_CACHE, _STATE_MTIME
    mtime = _file_mtime(CATALOG_STATE_PATH)
    if _STATE_CACHE is not None and mtime == _STATE_MTIME:
        return dict(_STATE_CACHE)
    state = _read_json(CATALOG_STATE_PATH, {})
    _STATE_CACHE = state
    _STATE_MTIME = mtime
    return dict(state)


def _catalog_key(provider_id, catalog_id):
    return '%s:%s' % (provider_id or '', catalog_id or '')


def get_catalog_state(provider_id, catalog_id):
    return _catalog_state().get(_catalog_key(provider_id, catalog_id), {})


def set_catalog_filter(provider_id, catalog_id, name, value):
    state = _catalog_state()
    key = _catalog_key(provider_id, catalog_id)
    current = dict(state.get(key, {}))
    if value in (None, '', '__clear__'):
        current.pop(name, None)
    else:
        current[name] = value
    state[key] = current
    _write_json(CATALOG_STATE_PATH, state)
    _invalidate_state_cache(state)
    return current


def clear_catalog_filters(provider_id, catalog_id):
    state = _catalog_state()
    key = _catalog_key(provider_id, catalog_id)
    if key in state:
        del state[key]
        _write_json(CATALOG_STATE_PATH, state)
        _invalidate_state_cache(state)
