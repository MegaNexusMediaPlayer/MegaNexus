"""Dolby Vision diagnostics for the MegaNexus diagnostics window (7.0.24).

Two separate questions, never mixed:

SOURCE      what the stream carries (profile, FEL / MEL enhancement layer)
PROCESSING  what Kodi / CoreELEC / the Amlogic Dolby Vision driver really do

Evidence, from weakest to strongest (checked in the CoreELEC sources:
xbmc branches aml-4.9-21.3 and aml-5.15.196-22.0, kernels linux-amlogic
amlogic-4.9-20 and common_drivers 5.15.196):

1. Source profile / layer
   - Kodi 22: VideoPlayer.HdrDetail. CoreELEC 22 appends FEL / MEL for
     profile 7 (libdovi RPU parsing, VideoPlayer.cpp); upstream Kodi 22 gives
     only "7", so the layer stays unknown there. P8 reads "8.1", "8.4"...
   - CoreELEC 21.3 (no HdrDetail): Kodi's log line
     "CAMLCodec::OpenDecoder DOVI: version x.y, profile 7, full enhancement layer".
   - CoreELEC 22: Player.Process(video.sidedata) JSON - RPU present, the
     dual-layer structure (st-dl / dt-dl) and what the player changed.
2. FEL path requested: Kodi switches the driver's FEL path on for a FEL
   source ("enable_fel 1" to the Dolby Vision driver: sysfs on CE21, the DRM
   dv_debug property on CE22); the driver prints it in the kernel log.
3. EL decoder: /sys/class/vfm/map shows the dveldec provider active.
4. Verified (one short check per video, only while the window is on): the
   driver's debug bit 2 (debug_dolby) is set for a moment; it then logs
   "+++ get bl(...) with el(...) +++" for every base-layer frame it pairs with
   an enhancement-layer frame of the same PTS - the FEL really reaching the
   Dolby Vision composer. The previous debug value is restored at once.

Nothing here writes to the playback path except that debug bit, which only
adds kernel log lines. Every read fails quietly: a missing label, sysfs file
or permission gives "unknown", never an error.
"""
import glob
import json
import os
import re
import time

KMSG = '/dev/kmsg'
VFM_MAP = '/sys/class/vfm/map'
DEBUG_PARAM = '/sys/module/*/parameters/debug_dolby'
STATUS_API = '/sys/class/amdolby_vision/fel_status'   # a future read-only kernel status, used when present
DEEP_SECONDS = 2.5
DEEP_MIN_PAIRS = 10       # paired BL+EL frames that count as proof (~0.4 s of video)

_DOVI_LOG = re.compile(r'DOVI: version [\d.]+, profile (\d+)(?:, (full|minimum) enhancement layer)?', re.I)
_PAIRED = re.compile(r'(?:AMDV|DOLBY): \+\+\+ get bl\(\S+\) with el\(\S+\) \+\+\+')
_EL_FLAGS = re.compile(r'(?:AMDV|DOLBY): update el_flag (\d), melFlag (\d)')
_BYPASS = re.compile(r'(?:AMDV|DOLBY): (?:tv: )?bypass (?:fel|mel)')
_ENABLE_FEL = re.compile(r'\benable_fel (\d)\s*$')

# Dolby Vision output in Kodi (checked in its sources): CoreELEC's Amlogic
# path, and upstream only Android MediaCodec (a device with a DV decoder) and
# webOS. Windows (DXVA) and Linux (DRM PRIME) show the base layer: HDR10 for
# P7 / P8.1, HLG for P8.4; P5 has no HDR10 base, so its colours come out wrong.
STATUS_TEXT = {
    'NOT_DOLBY_VISION': '',
    'DV_ACTIVE': 'Dolby Vision',
    'P7_MEL': 'P7 MEL',
    'P7_FEL_SOURCE': 'P7 FEL · source detected',
    'P7_FEL_PATH_ACTIVE': 'P7 FEL · processing path active',
    'P7_FEL_VERIFIED': 'P7 FEL · full processing verified',
    'P7_FEL_NOT_PROCESSED': 'P7 FEL · enhancement layer not processed',
    'UNKNOWN': 'Dolby Vision',
}


# ------------------------------------------------------------- platform ---

def os_release(path='/etc/os-release'):
    values = {}
    try:
        with open(path, encoding='utf-8') as handle:
            for line in handle:
                key, sep, value = line.strip().partition('=')
                if sep:
                    values[key] = value.strip().strip('"')
    except OSError:
        pass
    return values


def platform(build_version='', release=None, android=False):
    """{'coreelec': bool, 'coreelec_version': '22.0rc1-Piers', 'kodi': 22, 'kernel': '5.15.196',
    'dv_output': True/False} - dv_output: Kodi can send Dolby Vision on this system at all."""
    info = os_release() if release is None else release
    ids = {info.get('ID', '').lower()} | set(info.get('ID_LIKE', '').lower().split())
    match = re.match(r'(\d+)', str(build_version or ''))
    try:
        kernel = os.uname().release
    except Exception:
        kernel = ''
    coreelec = 'coreelec' in ids
    return {'coreelec': coreelec, 'coreelec_version': info.get('VERSION', ''),
            'kodi': int(match.group(1)) if match else 0, 'kernel': kernel,
            'dv_output': coreelec or bool(android) or 'webos' in ids}


# --------------------------------------------------------------- source ---

def parse_detail(hdr_detail):
    """VideoPlayer.HdrDetail -> (profile, compatibility, layer). '7FEL' ->
    ('7', '', 'FEL'); '8.1' -> ('8', '1', ''); '7' -> ('7', '', '')."""
    found = re.match(r'\s*(\d+)(?:\.(\d+))?\s*(FEL|MEL)?\s*$', str(hdr_detail or ''), re.I)
    if not found:
        return '', '', ''
    return found.group(1), found.group(2) or '', (found.group(3) or '').upper()


def parse_log_source(text):
    """CoreELEC's Kodi log (CE21 and CE22) -> (profile, layer)."""
    found = None
    for found in _DOVI_LOG.finditer(text or ''):
        pass
    if not found:
        return '', ''
    return found.group(1), {'full': 'FEL', 'minimum': 'MEL'}.get((found.group(2) or '').lower(), '')


def parse_sidedata(raw):
    """CoreELEC 22 Player.Process(video.sidedata) -> {'rpu': True/False/None,
    'structure': 'ST-DL'/'DT-DL'/'Single layer'/'', 'flags': [...]}."""
    result = {'rpu': None, 'structure': '', 'flags': []}
    if not raw:
        return result
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return result
    if not isinstance(data, dict):
        return result
    result['rpu'] = bool(data.get('dovi.rpu'))
    structure = str(data.get('structure') or '').lower()
    result['structure'] = {'st-dl': 'ST-DL', 'dt-dl': 'DT-DL'}.get(structure, 'Single layer' if data.get('dovi.config') else '')
    flags = data.get('flags')
    result['flags'] = [str(f) for f in flags if isinstance(f, str)] if isinstance(flags, list) else []
    return result


# ------------------------------------------------------- runtime (kernel) ---

def vfm_el_decoder(path=VFM_MAP):
    """True: the dveldec provider is mapped and active; False: not; None: unreadable."""
    try:
        with open(path, encoding='utf-8', errors='replace') as handle:
            text = handle.read()
    except OSError:
        return None
    if re.search(r'\bdveldec\(1\)', text):
        return True
    return False


def uptime_us(path='/proc/uptime'):
    try:
        with open(path, encoding='ascii') as handle:
            return int(float(handle.read().split()[0]) * 1000000)
    except (OSError, ValueError, IndexError):
        return None


def kmsg_open(path=KMSG, tail=False):
    """A non-blocking reader of the kernel log; tail=True starts after the
    newest record (only what is logged from now on). None when unreadable."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
    except OSError:
        return None
    if tail:
        try:
            os.lseek(fd, 0, os.SEEK_END)
        except OSError:
            pass
    return fd


def kmsg_records(since_us=0, path=KMSG, limit=20000, fd=None):
    """Kernel log messages (text) newer than since_us (microseconds since boot).
    Non-blocking: returns what the ring buffer holds; [] when unreadable."""
    messages = []
    own = fd is None
    if own:
        fd = kmsg_open(path)
    if fd is None:
        return messages
    try:
        while len(messages) < limit:
            try:
                record = os.read(fd, 8192)
            except BlockingIOError:
                break
            except OSError as exc:      # EPIPE: overwritten records, keep reading
                if getattr(exc, 'errno', 0) == 32:
                    continue
                break
            if not record:
                break
            head, _, message = record.decode('utf-8', 'replace').partition(';')
            parts = head.split(',')
            try:
                stamp = int(parts[2])
            except (IndexError, ValueError):
                stamp = 0
            if stamp >= since_us:
                messages.append(message.split('\n', 1)[0])
    finally:
        if own:
            os.close(fd)
    return messages


def fel_path_requested(messages):
    """True / False from the driver's own "enable_fel N" lines; None: not seen."""
    state = None
    for message in messages:
        found = _ENABLE_FEL.search(message.strip())
        if found:
            state = found.group(1) == '1'
    return state


def read_status_api(path=STATUS_API):
    """The future read-only kernel status (key=value lines), when present."""
    values = {}
    try:
        with open(path, encoding='utf-8', errors='replace') as handle:
            for line in handle:
                key, sep, value = line.strip().partition('=')
                if sep:
                    values[key.strip()] = value.strip()
    except OSError:
        return None
    return values


def deep_verify(seconds=DEEP_SECONDS, wait=time.sleep, param_glob=DEBUG_PARAM, kmsg=KMSG):
    """Turn the driver's frame-pairing log on for a moment and count the
    base+enhancement layer frames it pairs. Returns {'pairs': n, 'el_flag':
    0/1/None, 'mel_flag': 0/1/None, 'bypass': bool} or None when the debug
    switch or the kernel log cannot be used. The previous value is always restored."""
    paths = sorted(glob.glob(param_glob))
    if not paths:
        return None
    path = paths[0]
    try:
        with open(path, encoding='ascii') as handle:
            previous = handle.read().strip()
        old = int(previous or '0')
    except (OSError, ValueError):
        return None
    reader = kmsg_open(kmsg, tail=True)   # only what the driver logs from now on
    if reader is None:
        return None
    try:
        try:
            with open(path, 'w', encoding='ascii') as handle:
                handle.write(str(old | 2))
        except OSError:
            return None
        try:
            wait(seconds)
        finally:
            try:
                with open(path, 'w', encoding='ascii') as handle:
                    handle.write(previous or '0')
            except OSError:
                pass
        messages = kmsg_records(0, fd=reader)
    finally:
        os.close(reader)
    if not messages:
        return None   # with its debug on the driver always logs: nothing read means no access
    result = {'pairs': 0, 'el_flag': None, 'mel_flag': None, 'bypass': False}
    for message in messages:
        if _PAIRED.search(message):
            result['pairs'] += 1
        flags = _EL_FLAGS.search(message)
        if flags:
            result['el_flag'], result['mel_flag'] = int(flags.group(1)), int(flags.group(2))
        if _BYPASS.search(message):
            result['bypass'] = True
    return result


# --------------------------------------------------------------- verdict ---

def build(hdr_type='', hdr_detail='', log_text='', sidedata=None, coreelec=False,
          fel_requested=None, el_decoder=None, deep=None, status_api=None):
    """The whole model; final_status is decided conservatively by verdict()."""
    model = {'hdr_type': hdr_type, 'profile': '', 'compatibility': '', 'source_el': 'UNKNOWN',
             'rpu': None, 'structure': '', 'flags': [], 'coreelec': coreelec,
             'fel_path_requested': fel_requested, 'el_decoder': el_decoder,
             'bl_el_sync': None, 'sync_pairs': 0, 'composer': None, 'bypass': False}
    if hdr_type != 'dolbyvision':
        model['final_status'] = 'NOT_DOLBY_VISION'
        return model
    profile, compatibility, layer = parse_detail(hdr_detail)
    if not profile and coreelec:
        profile, layer = parse_log_source(log_text)
    elif profile in ('4', '7') and not layer and coreelec:
        layer = parse_log_source(log_text)[1]
    model['profile'], model['compatibility'] = profile, compatibility
    if profile in ('4', '7'):
        model['source_el'] = layer or 'UNKNOWN'
    elif profile:
        model['source_el'] = 'NONE'   # P5 / P8: single layer, FEL / MEL does not apply
    if sidedata:
        model.update(rpu=sidedata.get('rpu'), structure=sidedata.get('structure') or '', flags=sidedata.get('flags') or [])
    if deep:
        model['sync_pairs'] = deep.get('pairs', 0)
        model['bl_el_sync'] = deep.get('pairs', 0) >= DEEP_MIN_PAIRS
        model['bypass'] = bool(deep.get('bypass'))
        if deep.get('el_flag') is not None:
            model['composer'] = deep.get('el_flag') == 1 and deep.get('mel_flag') == 0
    if status_api:
        # A future kernel status wins where it speaks.
        if status_api.get('bl_el_sync') in ('0', '1'):
            model['bl_el_sync'] = status_api['bl_el_sync'] == '1'
        if status_api.get('composer') in ('0', '1'):
            model['composer'] = status_api['composer'] == '1'
        if status_api.get('el_decoder') in ('0', '1'):
            model['el_decoder'] = status_api['el_decoder'] == '1'
    model['final_status'] = verdict(model)
    return model


def verdict(model):
    if model.get('hdr_type') != 'dolbyvision':
        return 'NOT_DOLBY_VISION'
    profile, layer = model.get('profile'), model.get('source_el')
    if profile not in ('4', '7'):
        return 'DV_ACTIVE' if profile else 'UNKNOWN'
    if layer == 'MEL':
        return 'P7_MEL'
    if layer != 'FEL':
        return 'UNKNOWN'
    if model.get('bypass') or model.get('fel_path_requested') is False:
        return 'P7_FEL_NOT_PROCESSED'
    if model.get('bl_el_sync') and model.get('composer') is not False and model.get('el_decoder') is not False:
        return 'P7_FEL_VERIFIED'
    if model.get('fel_path_requested') and model.get('el_decoder'):
        return 'P7_FEL_PATH_ACTIVE'
    return 'P7_FEL_SOURCE'


def rows(model, deep_available=True, dv_output=True):
    """Window properties for the skin: meganexus.dv.<key> -> text ('' hides the row)."""
    if model.get('final_status') == 'NOT_DOLBY_VISION':
        return {key: '' for key in ('active', 'profile', 'source_el', 'structure', 'rpu', 'changes',
                                    'fel_path', 'el_decoder', 'sync', 'status', 'status_note', 'level')}
    profile = model.get('profile') or ''
    if profile and model.get('compatibility'):
        profile = '%s.%s' % (profile, model['compatibility'])
    fel_case = model.get('source_el') == 'FEL'
    yes_no = lambda value, yes, no: '' if value is None else (yes if value else no)
    sync = ''
    if fel_case:
        if model.get('bl_el_sync') is None:
            sync = 'Not checked' if deep_available else 'Unavailable'
        else:
            sync = ('Verified · %d paired frames' % model.get('sync_pairs', 0)) if model['bl_el_sync'] else 'Not seen'
    changes = ', '.join(model.get('flags') or [])
    status = model.get('final_status')
    status_text = STATUS_TEXT.get(status, '')
    if status in ('DV_ACTIVE', 'UNKNOWN') and profile:
        status_text = 'Dolby Vision P%s' % profile
    note = {'P7_FEL_SOURCE': 'Hardware processing not verified',
            'P7_FEL_PATH_ACTIVE': 'Frame pairing not verified yet',
            'UNKNOWN': 'This Kodi does not report FEL / MEL' if profile else '',
            'P7_FEL_NOT_PROCESSED': 'The enhancement layer is bypassed'}.get(status, '')
    if not dv_output:
        # Plays, but this system sends the base layer, not Dolby Vision.
        base = model.get('profile')
        note = ('No Dolby Vision output here; profile 5 has no HDR10 base, colours look wrong' if base == '5' else
                'No Dolby Vision output here; the HLG base layer is shown' if model.get('compatibility') == '4' else
                'No Dolby Vision output here; the HDR10 base layer is shown')
    return {
        'active': '1',
        'profile': profile or 'Unknown',
        'source_el': {'FEL': 'FEL (full enhancement layer)', 'MEL': 'MEL (minimal enhancement layer)',
                      'NONE': 'N/A (single layer)', 'UNKNOWN': 'Unknown'}.get(model.get('source_el'), 'Unknown'),
        'structure': model.get('structure') or '',
        'rpu': yes_no(model.get('rpu'), 'Present', 'Missing'),
        'changes': changes,
        'fel_path': yes_no(model.get('fel_path_requested'), 'Requested', 'Not requested') if fel_case else '',
        'el_decoder': yes_no(model.get('el_decoder'), 'Active', 'Not active') if fel_case else '',
        'sync': sync,
        'status': status_text,
        'status_note': note,
        'level': 'warn' if (status == 'P7_FEL_NOT_PROCESSED' or not dv_output) else
                 {'P7_FEL_VERIFIED': 'ok', 'P7_MEL': 'ok', 'DV_ACTIVE': 'ok', 'UNKNOWN': 'ok'}.get(status, 'info'),
    }
