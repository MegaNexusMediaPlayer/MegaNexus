"""Opt-in service-owned video wallpaper, with exact item-token ownership.

Kodi has one player: relinquish it for foreground media and resume the silent
copy afterwards. Never mute the application, track wallpaper, or stop media
based on a global flag/file name. Unsupported clips keep the static wallpaper.
"""
import hashlib
import json
import os
import time
import uuid
import xbmc
import xbmcgui
import xbmcvfs
from . import mp4loop, refresh_guard

SETTING = 'meganexus_wallpaper_video'
ACTIVE = 'meganexus.wallpaper.video'
READY = 'meganexus.wallpaper.video.ready'
ITEM = 'meganexus.wallpaper.token'
BLOCK = 'meganexus.wallpaper.hold'
POSITION = 'meganexus.wallpaper.position'
RESUME_WAIT = 'meganexus.wallpaper.resume.wait'


def is_background(player):
    try: return bool(player.isPlayingVideo() and player.getPlayingItem().getProperty(ITEM))
    except Exception: return False


def suspend(player=None):
    """Foreground call before queuing video. Stop only our exact marked item."""
    home = xbmcgui.Window(10000)
    home.setProperty(BLOCK, str(time.monotonic() + 15.))
    home.clearProperty(READY)
    player = player or xbmc.Player()
    if not is_background(player): return
    try: home.setProperty(POSITION, str(player.getTime()))
    except Exception: pass
    home.clearProperty(ACTIVE)
    player.stop()
    refresh_guard.restore('wallpaper')


def foreground():
    """7.0.29: right before a film, an episode or a server / local video starts:
    the wallpaper steps aside and every refresh-rate hold is let go, so Kodi
    sets the TV to the video's rate (AFR "on start/stop" works)."""
    try:
        suspend()
    finally:
        refresh_guard.release_all()


def release():
    """Resume promptly once a preview's real item has ended/cancelled."""
    home=xbmcgui.Window(10000)
    if not any(home.getProperty(key) for key in ('meganexus.preview.active','meganexus.preview.pending','meganexus.saver.active')):
        if home.getProperty(BLOCK) or home.getProperty(POSITION):home.setProperty(RESUME_WAIT,'1')
        home.clearProperty(BLOCK)


class _Reader:
    def __init__(self, handle): self.handle = handle
    def read(self, count): return bytes(self.handle.readBytes(count))
    def seek(self, offset): self.handle.seek(offset, 0)


def silent_copy(path, stopped):
    if not path.lower().endswith(('.mp4', '.m4v', '.mov')): return ''
    info = xbmcvfs.Stat(path)
    key = hashlib.sha1(('%s|%s|%s' % (path, info.st_size(), info.st_mtime())).encode('utf-8')).hexdigest()[:16]
    folder = xbmcvfs.translatePath('special://profile/addon_data/script.meganexus/saver_loop/')
    target = os.path.join(folder, key + '.mp4')
    if os.path.isfile(target): return target
    if os.path.isfile(os.path.join(folder, key + '.unsupported')): return ''
    os.makedirs(folder, exist_ok=True)
    temporary = target + '.wallpaper.part'
    handle = xbmcvfs.File(path)
    try:
        with open(temporary, 'wb') as out:
            mp4loop.write_loop(_Reader(handle), handle.size(), out, stopped=stopped)
        if stopped(): return ''
        os.replace(temporary, target)
        return target
    except (OSError, ValueError): return ''
    finally:
        handle.close()
        try: os.remove(temporary)
        except OSError: pass


class BackgroundPlayer(xbmc.Player):
    def __init__(self):
        super().__init__(); self.token = ''; self.cancelled = False; self.failed = False; self.av_started = False

    def owns(self):
        try: return bool(self.token and self.isPlayingVideo() and self.getPlayingItem().getProperty(ITEM) == self.token)
        except Exception: return False

    def onAVStarted(self):
        home = xbmcgui.Window(10000)
        if not self.owns():
            if self.token and home.getProperty(ACTIVE) == self.token:
                refresh_guard.restore('wallpaper'); self.clear()
            return
        if self.cancelled or home.getProperty(ACTIVE) != self.token:
            self.stop(); return
        xbmcgui.Window(10000).setProperty(READY, '1')
        home.clearProperty(POSITION);home.clearProperty(RESUME_WAIT)
        self.av_started=True
        try:
            xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.SetViewMode',
                                           'params': {'viewmode': 'zoom'}}))
        except Exception: pass

    def clear(self):
        home = xbmcgui.Window(10000)
        if self.token and home.getProperty(ACTIVE) == self.token:
            home.clearProperty(ACTIVE); home.clearProperty(READY)

    def ended(self,error=False):
        # Kodi tells every Python player about every stop: a trailer or film
        # stopping is not our clip failing. Only our own clip (it started) or an
        # error while ours was opening counts.
        home=xbmcgui.Window(10000)
        foreground=any(home.getProperty(key) for key in (BLOCK,'meganexus.preview.pending','meganexus.preview.active','meganexus.saver.active'))
        if not self.av_started and foreground:return
        if not self.cancelled and home.getProperty(ACTIVE)==self.token:
            self.failed=error or not self.av_started   # Kodi may send Stopped, not Error, for a clip it cannot open
        self.av_started=False
        self.clear()
    def onPlayBackStopped(self): self.ended()
    def onPlayBackEnded(self): self.ended()
    def onPlayBackError(self): self.ended(True)


class Controller:
    def __init__(self):
        self.player = BackgroundPlayer(); self.path = ''; self.loop = ''; self.retry = 0.; self.started = 0.
        self.home = xbmcgui.Window(10000)
        self.idle_limit = 180.; self.next_idle_read = 0.
        self.identity=None; self.failed_identity=None; self.next_source_read=0.

    def stop(self):
        self.player.cancelled = True
        if self.player.owns():
            try: self.home.setProperty(POSITION, str(self.player.getTime()))
            except Exception: pass
            self.player.stop()
            refresh_guard.restore('wallpaper')
        self.player.clear()

    def tick(self, addon, monitor):
        now = time.monotonic()
        enabled = addon.getSetting(SETTING) == 'true' and addon.getSetting('meganexus_wallpaper') == 'saver'
        source = addon.getSetting('meganexus_screensaver_video') if addon.getSetting('meganexus_screensaver_type') == 'video' else ''
        if not enabled or not source:
            self.stop(); self.identity=None;self.failed_identity=None;return
        if now>=self.next_source_read or source!=self.path:
            self.next_source_read=now+2.
            try:
                stat=xbmcvfs.Stat(source);identity=(source,stat.st_size(),stat.st_mtime())
            except Exception:identity=(source,)
            if identity!=self.identity:
                if self.identity is not None:self.home.setProperty(RESUME_WAIT,'1')
                self.stop();self.identity=identity;self.failed_identity=None;self.path=source;self.loop='';self.retry=0.
                self.home.clearProperty(POSITION);self.player.failed=False
        if self.player.failed:
            self.player.failed=False;self.failed_identity=self.identity
            if not self.player.isPlaying():refresh_guard.restore('wallpaper')
        if self.failed_identity==self.identity:
            self.stop();return  # No repeated failure dialogs; retry on source change or explicit toggle.
        if now > self.next_idle_read:
            self.next_idle_read = now + 30.
            try:
                result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Settings.GetSettingValue','params':{'setting':'screensaver.time'}})))
                self.idle_limit = max(10., float(result['result']['value']) * 60 - 5)
            except Exception: pass
        try: held = float(self.home.getProperty(BLOCK) or 0) > now
        except ValueError: held = False
        busy = held or bool(self.home.getProperty('meganexus.preview.pending') or self.home.getProperty('meganexus.preview.active')
                            or self.home.getProperty('meganexus.saver.active') or self.home.getProperty('meganexus.playback.choosing'))
        allowed = (xbmc.getSkinDir() == 'skin.meganexus' and not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
                   and not xbmc.getCondVisibility('System.IdleTime(%d)' % self.idle_limit))
        if not enabled or not source or busy or not allowed:
            self.stop(); return
        if self.player.isPlaying():
            if not self.player.owns():
                # Foreground playback replaced us. Its refresh policy is its own.
                if self.home.getProperty(ACTIVE) == self.player.token:
                    refresh_guard.restore('wallpaper')
                self.player.clear()
            return
        # Decoder startup can occupy Kodi's renderer briefly. Keep the still
        # while the user navigates, then resume after three seconds of no input.
        if (self.home.getProperty(POSITION) or self.home.getProperty(RESUME_WAIT)) and not xbmc.getCondVisibility('System.IdleTime(3)'):
            return
        if self.home.getProperty(ACTIVE) and now - self.started < 12.: return
        if self.player.token:
            self.player.clear(); refresh_guard.restore('wallpaper')
        if now < self.retry: return
        self.retry = now + .25
        if self.loop and not os.path.isfile(self.loop):self.loop=''
        if not self.loop:
            self.loop = silent_copy(source, lambda: monitor.abortRequested() or addon.getSetting(SETTING) != 'true')
        if not self.loop or monitor.abortRequested():
            self.retry=now+15.; return
        # Recheck after making a loop; another interpreter may have started media.
        if self.player.isPlaying() or self.home.getProperty('meganexus.preview.pending'): return
        token = uuid.uuid4().hex
        self.player = BackgroundPlayer(); self.player.token = token
        item = xbmcgui.ListItem(label='MegaNexus background')
        item.setProperty(ITEM, token); item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        item.setProperty('StartOffset', self.home.getProperty(POSITION) or '0')
        self.home.setProperty(ACTIVE, token); self.started = now
        refresh_guard.suspend('wallpaper')
        self.player.play(self.loop, item, windowed=True)


def run(monitor):
    from .settings_cache import cached_addon
    controller = Controller(); addon = cached_addon()
    try:
        while not monitor.abortRequested():
            try: controller.tick(addon, monitor)
            except Exception:
                controller.stop(); controller.failed_identity=controller.identity
                xbmc.log('[MegaNexus] Experimental video background keeps its still frame.', xbmc.LOGWARNING)
            if monitor.waitForAbort(.5): break
    finally: controller.stop()
