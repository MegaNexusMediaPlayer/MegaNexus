"""Stremio account (7.0 beta): sign in, import the account's add-ons and
Continue Watching, and optionally keep Continue Watching in sync.

Off until the user signs in. Importing only reads the account (add-ons are
added and switched on like a Nuvio import); "Keep in sync" (off by default)
lets the background sync exchange Continue Watching with Stremio too. Stremio
stores add-ons and library progress, not Home collections.
"""
from .meganexus import nuvio_stremio_sync as sync

SYNC_SETTING = 'stremio_sync_enabled'


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.meganexus')


def linked():
    try:
        return sync.Stremio.is_linked()
    except Exception:
        return False


def status():
    if not linked():
        return 'Not connected'
    email = sync.Stremio.token().get('email') or ''
    return 'Connected' + (' · ' + email if email else '')


def keep_in_sync():
    return linked() and _addon().getSetting(SYNC_SETTING) == 'true'


def set_keep_in_sync(on):
    _addon().setSetting(SYNC_SETTING, 'true' if on else 'false')


def sign_in(email, password):
    email, password = str(email or '').strip(), str(password or '')
    if not email or not password:
        raise ValueError('Enter your Stremio email and password.')
    try:
        sync.Stremio.login(email, password)
    except Exception:
        raise ValueError('Stremio did not accept this email and password.')
    return status()


def sign_out():
    sync.Stremio.clear()
    set_keep_in_sync(False)


def fetch():
    """Read the account (network; a job thread): add-ons with current
    manifests and Continue Watching."""
    from . import nuvio_import
    result = {'providers': [], 'collections': None, 'progress': None, 'errors': []}
    try:
        nuvio_import.with_manifests(sync.Stremio.sync_addons([], direction='pull'), result)
    except Exception:
        result['errors'].append('Add-ons could not be read from Stremio.')
    try:
        result['progress'] = sync.Stremio.sync_progress([], direction='pull')
    except Exception:
        result['errors'].append('Continue Watching could not be read from Stremio.')
    return result


def apply(result):
    from . import nuvio_import
    return nuvio_import.apply(result)


def import_now():
    return apply(fetch())
