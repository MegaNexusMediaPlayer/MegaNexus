"""Back up and restore every MegaNexus choice (7.0).

Set MegaNexus up once, export, and import the file on another device: the
settings, API keys, accounts (Nuvio, Stremio, Trakt, Simkl, Plex, Jellyfin),
add-ons, collections, Home folders and the local library / Continue Watching
come along. Left out on purpose: caches, installer state, one-time migration
markers and IDs that belong to one device. The file holds sign-ins, so it
must be kept private like a password.
"""
import base64
import json
import os
import sqlite3
import tempfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path

FORMAT = 'meganexus.backup'
VERSION = 1
MAX_BYTES = 40 * 1024 * 1024
ADDON_ID = 'plugin.video.meganexus'

# Settings that describe this device or this installation, not the user's choices.
DEVICE_SETTINGS = {
    'plex_client_identifier', 'plex_servers_cache_json', 'meganexus_components_for', 'meganexus_moved_from_previous',
    'meganexus_previous_cleanup', 'meganexus_skin_applied', 'meganexus_screensaver_applied', 'meganexus_restart_pending',
    'meganexus_update_checked', 'meganexus_manifests_refreshed', 'meganexus_conflicts_skipped',
    'meganexus_trailer_defaults_627', 'meganexus_weather_clock_migrated', 'meganexus_profile_applied',
    'meganexus_defaults_rev', 'meganexus_v510_defaults_applied', 'meganexus_v520_defaults_applied',
    'meganexus_wizard_applied', 'meganexus_setup_v110_done', 'meganexus_setup_offered', 'meganexus_setup_v110_step',
    'ui_lang_autodetected', 'last_account_sync_at', 'catalog_state_json', 'meganexus_iptv_instance',
    'meganexus_iptv_configured', 'meganexus_iptv_last_unique', 'meganexus_iptv_last_group', 'meganexus_auto_layout_key',
    'meganexus_precache_total', 'meganexus_precache_version',
}
# Personal files in the profile (JSON) and databases (SQLite, copied consistently).
FILES = ('providers.json', 'meganexus_collections.json', 'collection_sets.json', 'continue_hidden.json',
         'hub_catalog_pins.json', 'hub_folder_filters.json', 'hub_folder_prefs.json', 'hub_home_folders.json',
         'hub_home_subfolders.json', 'last_source_map.json', 'library_origins.json', 'sort_prefs.json',
         'trakt_token.json', 'simkl_token.json', 'nuvio_token.json', 'stremio_token.json', 'nuvio_sync_state.json',
         'trakt_outbox.json', 'meganexus_badges.json')
DATABASES = ('favorites.db', 'playback.db')


def _profile():
    import xbmcaddon
    import xbmcvfs
    return Path(xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile')))


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon(ADDON_ID)


def setting_ids():
    """Every setting MegaNexus Hub defines (from its settings.xml)."""
    import xbmcaddon
    import xbmcvfs
    path = Path(xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))) / 'resources' / 'settings.xml'
    return [node.get('id') for node in ET.parse(str(path)).getroot().iter('setting') if node.get('id')]


def _portable(key, value):
    """Local file paths (a custom screensaver video) do not travel."""
    if key in ('meganexus_screensaver_video', 'meganexus_screensaver_art') and value:
        return value.startswith('special://home/addons/')
    return True


def _db_bytes(path):
    """A consistent copy of a live SQLite database (committed WAL rows too)."""
    fd, tmp = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    try:
        src = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
        try:
            dst = sqlite3.connect(tmp)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        return Path(tmp).read_bytes()
    finally:
        os.unlink(tmp)


def export_data(addon=None, profile=None, ids=None):
    addon = addon or _addon()
    profile = Path(profile or _profile())
    ids = ids if ids is not None else setting_ids()
    settings = {}
    for key in ids:
        if key in DEVICE_SETTINGS:
            continue
        value = addon.getSetting(key)
        if value != '' and _portable(key, value):
            settings[key] = value
    files = {}
    for name in FILES:
        path = profile / name
        if path.is_file():
            try:
                files[name] = json.loads(path.read_text(encoding='utf-8-sig'))
            except (OSError, ValueError):
                continue
    databases = {}
    for name in DATABASES:
        path = profile / name
        if path.is_file():
            try:
                databases[name] = base64.b64encode(_db_bytes(path)).decode('ascii')
            except (OSError, sqlite3.Error):
                continue
    try:
        version = addon.getAddonInfo('version') or ''
    except Exception:
        version = ''
    return {'format': FORMAT, 'version': VERSION, 'app_version': version,
            'created': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'settings': settings, 'files': files, 'databases': databases}


def export_text(**kwargs):
    return json.dumps(export_data(**kwargs), ensure_ascii=False, indent=1)


def filename():
    return 'MegaNexus-backup-%s.json' % time.strftime('%Y-%m-%d')


def _validate(data):
    if not isinstance(data, dict) or data.get('format') != FORMAT:
        raise ValueError('This is not a MegaNexus backup file.')
    if int(data.get('version') or 0) > VERSION:
        raise ValueError('This backup comes from a newer MegaNexus. Update MegaNexus first.')
    for key in ('settings', 'files', 'databases'):
        if not isinstance(data.get(key, {}), dict):
            raise ValueError('The backup file is damaged.')


def _restore_db(path, raw):
    """Copy into the live database through SQLite (safe while it is open)."""
    fd, tmp = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    try:
        Path(tmp).write_bytes(raw)
        src = sqlite3.connect(tmp)
        try:
            src.execute('PRAGMA integrity_check').fetchone()
            dst = sqlite3.connect(str(path), timeout=10)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
    finally:
        os.unlink(tmp)


def import_data(data, addon=None, profile=None, ids=None):
    """Apply a backup; returns {'settings', 'files', 'databases'} counts."""
    _validate(data)
    addon = addon or _addon()
    profile = Path(profile or _profile())
    profile.mkdir(parents=True, exist_ok=True)
    known = set(ids if ids is not None else setting_ids())
    report = {'settings': 0, 'files': 0, 'databases': 0}
    for key, value in (data.get('settings') or {}).items():
        if key in known and key not in DEVICE_SETTINGS and isinstance(value, str):
            addon.setSetting(key, value)
            report['settings'] += 1
    for name, value in (data.get('files') or {}).items():
        if name not in FILES:
            continue   # only the files MegaNexus knows, never a path from the file
        target = profile / name
        tmp = target.with_name(name + '.restoring')
        tmp.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        os.replace(tmp, target)
        report['files'] += 1
    for name, value in (data.get('databases') or {}).items():
        if name not in DATABASES:
            continue
        try:
            _restore_db(profile / name, base64.b64decode(value))
            report['databases'] += 1
        except (ValueError, sqlite3.Error, OSError):
            continue
    try:
        from . import settings_cache
        settings_cache.invalidate()
        import xbmcgui
        xbmcgui.Window(10000).setProperty('meganexus.progress.revision', 'restore-%s' % time.time())
    except Exception:
        pass
    return report


def import_text(text, **kwargs):
    if len(text.encode('utf-8')) > MAX_BYTES:
        raise ValueError('The backup file is too large.')
    try:
        data = json.loads(text)
    except ValueError:
        raise ValueError('This is not a MegaNexus backup file.')
    return import_data(data, **kwargs)
