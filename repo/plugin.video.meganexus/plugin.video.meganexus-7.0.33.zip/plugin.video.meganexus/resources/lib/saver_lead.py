"""The screensaver's black starts a second early (7.0.32).

The MegaNexus screensaver begins with a black layer that fades in over a
second (screensaver.meganexus/default.py) - but only once Kodi starts it. The
service shows the same black LEAD seconds before Kodi's screensaver time, so
the screen is already dark when Kodi starts it; its own black then fades in
over a black screen and everything goes on as before. A key in that second
lifts the black at once; when Kodi does not start the screensaver after all
(something keeps it awake) the black lifts after GIVE_UP seconds.
"""
import json
import time

import xbmc
import xbmcgui

LEAD = 1.0          # seconds before Kodi's screensaver time
FADE_IN = 1000      # ms - the same fade as the screensaver's own black
GIVE_UP = 3.5       # seconds after the screensaver time without a screensaver
HANDOVER = 2.0      # seconds the screensaver's own black needs to cover the screen
KEY_GRACE = .5      # Kodi zeroes its idle time as it starts the screensaver too: a key only
                    # when no screensaver follows within this time (it lifted the black: two fades)
SAVER = 'screensaver.meganexus'
DARK = 'meganexus.saver.lead'   # the screen is black already: the screensaver's own black starts black


def _setting(name):
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                                                           'params': {'setting': name}})))
        return (reply.get('result') or {}).get('value')
    except Exception:
        return None


class Lead(object):
    """tick() once per loop; it returns how long to wait before the next one."""

    def __init__(self, show, settings=_setting, active=None, playing=None):
        self.show = show                  # () -> curtain with close(background=...)
        self.settings = settings
        self.active = active or (lambda: xbmc.getCondVisibility('System.ScreenSaverActive')
                                 or bool(xbmcgui.Window(10000).getProperty('meganexus.saver.active')))
        self.playing = playing or (lambda: xbmc.Player().isPlaying())
        self.limit = 0
        self.next_read = 0.0
        self.curtain = None
        self.shown = 0.0
        self.saver_seen = 0.0
        self.idle_dropped = 0.0

    def mark(self, value):
        try:
            xbmcgui.Window(10000).setProperty(DARK, value)
        except Exception:
            pass

    def _read(self, now):
        if now < self.next_read:
            return
        self.next_read = now + 30
        try:
            minutes = float(self.settings('screensaver.time') or 0)
        except (TypeError, ValueError):
            minutes = 0
        self.limit = int(minutes * 60) if self.settings('screensaver.mode') == SAVER else 0

    def _lift(self, fade=True, why=''):
        xbmc.log('[MegaNexus] screensaver lead: lifted (%s)' % why, xbmc.LOGINFO)
        curtain, self.curtain = self.curtain, None
        self.saver_seen = 0.0
        self.idle_dropped = 0.0
        self.mark('')
        try:
            curtain.close(background=True) if fade else curtain.close()
        except Exception:
            pass

    def tick(self, now, idle):
        """idle: Kodi's whole seconds without input (xbmc.getGlobalIdleTime)."""
        self._read(now)
        if self.curtain is not None:
            if self.active():
                self.saver_seen = self.saver_seen or now
                if now - self.saver_seen >= HANDOVER:
                    self._lift(fade=False, why='screensaver on')   # under its own black by now
                return .1
            if idle < self.limit - LEAD - 1:
                self.idle_dropped = self.idle_dropped or now
                if now - self.idle_dropped >= KEY_GRACE:
                    self._lift(why='key, idle %d s' % idle)   # the picture back
            elif now - self.shown >= LEAD + GIVE_UP:
                self._lift(why='no screensaver')        # Kodi did not start it
            return .1
        if self.limit <= LEAD + 1:
            return 5.0
        remaining = self.limit - idle
        if remaining > LEAD:
            # Kodi's idle time counts whole seconds: look often only near the end.
            return min(5.0, max(.1, remaining - LEAD - .5))
        if remaining > 0 and not self.active() and not self.playing():
            self.curtain = self.show()
            self.shown = now
            self.mark(str(time.time()))
            xbmc.log('[MegaNexus] screensaver lead: black at idle %d s of %d' % (idle, self.limit), xbmc.LOGINFO)
            return .1
        return 1.0


def run(monitor):
    from .curtain import Curtain

    def show():
        return Curtain(fade_in=FADE_IN)

    lead = Lead(show)
    xbmc.log('[MegaNexus] screensaver lead: running', xbmc.LOGINFO)
    while not monitor.abortRequested():
        try:
            wait = lead.tick(time.monotonic(), xbmc.getGlobalIdleTime())
        except Exception as exc:
            xbmc.log('[MegaNexus] screensaver lead skipped: %r' % exc, xbmc.LOGWARNING)
            wait = 5.0
        if monitor.waitForAbort(wait):
            break
    if lead.curtain is not None:
        lead._lift(fade=False)
