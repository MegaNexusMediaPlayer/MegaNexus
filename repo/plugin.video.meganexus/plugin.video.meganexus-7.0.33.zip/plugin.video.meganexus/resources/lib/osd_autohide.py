"""The player bar hides after 5 s without a key press (7.0.29); never while paused.

Kodi's video OSD stays until it is closed. Like the TV apps, MegaNexus closes
it once no key was pressed for HIDE seconds - unless something opened from it
is still in use: Kodi's audio / subtitle / video settings, bookmarks, the
channel list and guide, sliders (subtitle offset), pickers, and MegaNexus'
own windows (Sources, Subtitles, Audio, Sync) or the Settings list.
"""
import time

import xbmc

HIDE = 5
# Kodi counts the bar itself as a modal dialog: what keeps it open is listed by name.
BUSY = ' | '.join((
    'Window.IsVisible(yesnodialog)', 'Window.IsVisible(okdialog)', 'Window.IsVisible(textviewer)',
    'Window.IsVisible(virtualkeyboard)', 'Window.IsVisible(numericinput)', 'Window.IsVisible(progressdialog)',
    'Window.IsVisible(movieinformation)', 'Window.IsVisible(pvrguideinfo)',
    'Window.IsVisible(osdaudiosettings)', 'Window.IsVisible(osdsubtitlesettings)', 'Window.IsVisible(osdvideosettings)',
    'Window.IsVisible(osdcmssettings)', 'Window.IsVisible(videobookmarks)', 'Window.IsVisible(pvrosdchannels)',
    'Window.IsVisible(pvrchannelguide)', 'Window.IsVisible(osdteletext)', 'Window.IsVisible(sliderdialog)',
    'Window.IsVisible(selectdialog)', 'Window.IsVisible(contextmenu)', 'Window.IsVisible(busydialog)',
    'Window.IsVisible(1101)', 'Window.IsVisible(1103)', 'Window.IsVisible(1110)', 'Player.Seeking', 'Player.Paused',
) + tuple('Window.IsVisible(meganexus_%s.xml)' % name for name in (
    'sources', 'loading', 'busy', 'context', 'notice', 'info', 'settings')))


def run(monitor):
    opened = None
    while not monitor.abortRequested():
        try:
            if xbmc.getCondVisibility('Window.IsActive(videoosd)'):
                now = time.monotonic()
                opened = opened or now
                if (now - opened >= HIDE and xbmc.getCondVisibility('System.IdleTime(%d)' % HIDE)
                        and not xbmc.getCondVisibility(BUSY)):
                    xbmc.executebuiltin('Dialog.Close(VideoOSD)')
                    opened = None
            else:
                opened = None
        except Exception:
            pass
        if monitor.waitForAbort(0.5):
            break
