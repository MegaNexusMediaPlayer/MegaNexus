"""The MDBList ratings row: a mark and a score per service (7.0.29).

Like Nuvio's MDBListRatingsRow: IMDb, Trakt, TMDB, Rotten Tomatoes (fresh,
rotten or certified fresh), the audience score (hot, stale or verified hot),
Letterboxd, Metacritic, MyAnimeList - and MDBList's own score as an option.
Each service can be switched off (HUB Settings and the phone page); the
ratings come from mdblist.fetch_ratings (an MDBList key is needed).

The windows draw slots meganexus.ratings.<n>.icon / .value (n = 0..8).
"""
SERVICES = ('imdb', 'trakt', 'tmdb', 'rt_crit', 'rt_aud', 'letterboxd', 'metacritic', 'mal', 'mdblist')
LABELS = {'imdb': 'IMDb', 'trakt': 'Trakt', 'tmdb': 'TMDB', 'rt_crit': 'Rotten Tomatoes',
          'rt_aud': 'Rotten Tomatoes audience', 'letterboxd': 'Letterboxd', 'metacritic': 'Metacritic',
          'mal': 'MyAnimeList', 'mdblist': 'MDBList score'}
DEFAULT_OFF = ('mdblist',)            # Nuvio shows the eight services; MDBList's own score is extra
# The services' original logos, loaded like the stream badges: Kodi downloads,
# scales and caches them (nothing bundled). Nuvio TV's pictures where Nuvio has
# PNGs (audience score, Metacritic), the MDBList ratings plugin's otherwise.
NUVIO = 'https://raw.githubusercontent.com/NuvioMedia/NuvioTV/main/app/src/main/res/drawable/'
MDBR = 'https://raw.githubusercontent.com/Druidblack/Jellyfin.Plugin.MDBList_Ratings/main/Jellyfin.Plugin.MdbListRatings/Assets/'
LOGOS = {'imdb': MDBR + 'IMDb.png', 'trakt': MDBR + 'Trakt.png', 'tmdb': MDBR + 'TMDB.png',
         'letterboxd': MDBR + 'letterboxd.png', 'mal': MDBR + 'mal.png', 'metacritic': NUVIO + 'mdblist_metacritic.png',
         'rt_fresh': MDBR + 'Rotten_Tomatoes.png', 'rt_rotten': MDBR + 'Rotten_Tomatoes_rotten.png',
         'rt_certified': MDBR + 'rotten-tomatoes-certified.png', 'audience': NUVIO + 'mdblist_audience.png',
         'audience_stale': NUVIO + 'mdblist_audience_stale.png', 'audience_verified': NUVIO + 'mdblist_audience_verified_hot.png',
         'mdblist': 'https://mdblist.com/static/mdblist_logo.png'}
SLOTS = 9


def setting(service):
    return 'meganexus_rating_%s' % service


def enabled(service, addon=None):
    if addon is None:
        from .settings_cache import cached_addon
        addon = cached_addon()
    value = (addon.getSetting(setting(service)) or '').strip().lower()
    if not value:
        return service not in DEFAULT_OFF
    return value == 'true'


def choices(addon=None):
    return [(service, LABELS[service], enabled(service, addon)) for service in SERVICES]


def set_enabled(service, on, addon=None):
    if service not in SERVICES:
        raise ValueError('Unknown rating service.')
    if addon is None:
        from .settings_cache import cached_addon, invalidate
        addon = cached_addon()
        addon.setSetting(setting(service), 'true' if on else 'false')
        invalidate()
    else:
        addon.setSetting(setting(service), 'true' if on else 'false')


def icon(service, ratings):
    if service == 'rt_crit':
        score = _number(ratings.get('rt_crit'))
        if ratings.get('rt_crit_certified') and score >= 70:
            return LOGOS['rt_certified']
        return LOGOS['rt_fresh' if score >= 60 else 'rt_rotten']
    if service == 'rt_aud':
        score = _number(ratings.get('rt_aud'))
        if ratings.get('rt_aud_certified') and score >= 80:
            return LOGOS['audience_verified']
        return LOGOS['audience' if score >= 60 else 'audience_stale']
    return LOGOS[service]


def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def rows(ratings, addon=None):
    """[(icon, value)] in Nuvio's order, only switched-on services with a score."""
    out = []
    for service in SERVICES:
        value = str((ratings or {}).get(service) or '').strip()
        if value and enabled(service, addon):
            out.append((icon(service, ratings), value))
    return out[:SLOTS]


def publish(window, ratings, addon=None):
    shown = rows(ratings, addon)
    for index in range(SLOTS):
        icon_path, value = shown[index] if index < len(shown) else ('', '')
        window.setProperty('meganexus.ratings.%d.icon' % index, icon_path)
        window.setProperty('meganexus.ratings.%d.value' % index, value)
    window.setProperty('meganexus.ratings.any', '1' if shown else '')
    return len(shown)


def ids(meta):
    """(imdb id, tmdb id, media type) of a MegaNexus title."""
    meta = meta or {}
    raw = str(meta.get('id') or '')
    imdb = str(meta.get('imdb_id') or meta.get('imdbId') or (raw if raw.startswith('tt') else '')).split(':')[0]
    tmdb = str(meta.get('tmdb_id') or meta.get('tmdbId') or (raw.split(':', 1)[1] if raw.startswith('tmdb:') else ''))
    kind = 'show' if meta.get('type') in ('series', 'show', 'tv', 'anime') else 'movie'
    return imdb, tmdb, kind


def any_enabled(addon=None):
    return any(enabled(service, addon) for service in SERVICES)


def publish_for(window, meta, own=None, fetch=None):
    """7.0.29: a title's ratings on a screen: MDBList's full row when MDBList is
    connected and a service is on, else the title's own score (IMDb's logo + the
    number). ``own`` = (icon, value); ``fetch`` runs the MDBList request off the
    GUI thread and calls back with the ratings. Returns True when MDBList is used."""
    try:
        from . import mdblist
        use = mdblist.configured() and any_enabled()
    except Exception:
        use = False
    if use:
        imdb, tmdb, kind = ids(meta)
        if imdb or tmdb:
            cached = mdblist.cached_ratings(imdb_id=imdb, media_type=kind, tmdb_id=tmdb)
            if cached:
                publish(window, cached)
                return True
            clear(window)
            if fetch:
                fetch(lambda: mdblist.fetch_ratings(imdb_id=imdb, media_type=kind, tmdb_id=tmdb))
            return True
    icon_path, value = own or ('', '')
    for index in range(SLOTS):
        window.setProperty('meganexus.ratings.%d.icon' % index, icon_path if index == 0 and value else '')
        window.setProperty('meganexus.ratings.%d.value' % index, value if index == 0 else '')
    window.setProperty('meganexus.ratings.any', '1' if value else '')
    return False


def clear(window):
    for index in range(SLOTS):
        window.setProperty('meganexus.ratings.%d.icon' % index, '')
        window.setProperty('meganexus.ratings.%d.value' % index, '')
    window.setProperty('meganexus.ratings.any', '')
