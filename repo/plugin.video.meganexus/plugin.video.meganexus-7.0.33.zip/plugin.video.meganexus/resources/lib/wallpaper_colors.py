"""Bounded, dependency-free background colour sampling (not image resizing).

JPEG DC coefficients give each 8x8 block's average without an IDCT. Baseline
and the first progressive DC scan are supported. PNG samples use stdlib zlib.
Runs only in the service, never from a Kodi GUI callback. Artwork stays intact.
"""
import colorsys
import math
import struct
import time
import zlib
from collections import Counter

MAX_BYTES = 32 * 1024 * 1024
MAX_PIXELS = 4096 * 4096


def dominant(samples):
    bins = Counter()
    sums = {}
    for rgb in samples:
        r, g, b = (max(0, min(255, int(v))) for v in rgb[:3])
        h, s, v = colorsys.rgb_to_hsv(r / 255., g / 255., b / 255.)
        if v < .08 or v > .96 and s < .1:
            continue
        key = int(h * 24) % 24
        weight = .15 + s
        bins[key] += weight
        old = sums.get(key, (0., 0., 0.))
        sums[key] = tuple(a + c * weight for a, c in zip(old, (r, g, b)))
    if not bins:
        return None
    key = bins.most_common(1)[0][0]
    return tuple(round(c / bins[key]) for c in sums[key])


def _png(data):
    pos, palette, compressed = 8, None, bytearray()
    w = h = 0; color = None
    while pos + 12 <= len(data):
        size = struct.unpack_from('>I', data, pos)[0]
        kind, block = data[pos + 4:pos + 8], data[pos + 8:pos + 8 + size]
        if len(block) != size:
            raise ValueError('Truncated PNG')
        if kind == b'IHDR':
            w, h, depth, color, _, _, interlace = struct.unpack('>IIBBBBB', block)
            if depth != 8 or interlace or w * h > MAX_PIXELS:
                return []
        elif kind == b'PLTE':
            palette = [tuple(block[i:i + 3]) for i in range(0, len(block), 3)]
        elif kind == b'IDAT':
            compressed.extend(block)
        elif kind == b'IEND':
            break
        pos += size + 12
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(color)
    if not channels or not w or not h:
        return []
    stride = w * channels
    raw = zlib.decompressobj().decompress(bytes(compressed), (stride + 1) * h + 1)
    if len(raw) != (stride + 1) * h:
        return []
    prev, samples = bytearray(stride), []
    step = max(1, int(math.sqrt(w * h / 2048.)))
    for y in range(h):
        offset = y * (stride + 1)
        filt, row = raw[offset], bytearray(raw[offset + 1:offset + 1 + stride])
        for x in range(stride):
            a = row[x - channels] if x >= channels else 0
            b = prev[x]
            c = prev[x - channels] if x >= channels else 0
            if filt == 1: row[x] = (row[x] + a) & 255
            elif filt == 2: row[x] = (row[x] + b) & 255
            elif filt == 3: row[x] = (row[x] + ((a + b) // 2)) & 255
            elif filt == 4:
                p = a + b - c
                distances = (abs(p - a), abs(p - b), abs(p - c))
                row[x] = (row[x] + (a, b, c)[distances.index(min(distances))]) & 255
            elif filt != 0: return []
        if y % step == 0:
            for x in range(0, w, step):
                pixel = row[x * channels:(x + 1) * channels]
                if color in (4, 6) and pixel[-1] < 128: continue
                samples.append(palette[pixel[0]] if color == 3 else
                               tuple(pixel[:3]) if color in (2, 6) else (pixel[0],) * 3)
        prev = row
    return samples


class _Bits:
    def __init__(self, data, pos):
        self.data, self.pos, self.value, self.count = data, pos, 0, 0

    def read(self, n):
        while self.count < n:
            b = self.data[self.pos]; self.pos += 1
            if b == 255:
                marker = self.data[self.pos]; self.pos += 1
                if marker != 0: raise ValueError('JPEG marker')
            self.value = (self.value << 8) | b; self.count += 8
        self.count -= n
        return (self.value >> self.count) & ((1 << n) - 1)

    def signed(self, n):
        value = self.read(n)
        return value if not n or value >= (1 << (n - 1)) else value - (1 << n) + 1

    def symbol(self, table):
        code = 0
        for length in range(1, 17):
            code = (code << 1) | self.read(1)
            value = table.get((length, code))
            if value is not None: return value
        raise ValueError('JPEG Huffman')


def _jpeg(data):
    pos, tables, quants, components, restart = 2, {}, {}, {}, 0
    progressive = False
    deadline = time.monotonic() + 2.
    while pos + 4 <= len(data):
        if data[pos] != 255: raise ValueError('JPEG segment')
        while data[pos] == 255: pos += 1
        marker = data[pos]; pos += 1
        if marker == 217: return []
        size = int.from_bytes(data[pos:pos + 2], 'big')
        block = data[pos + 2:pos + size]; pos += size
        if marker == 219:
            i = 0
            while i < len(block):
                info = block[i]; i += 1
                wide = info >> 4
                quants[info & 15] = int.from_bytes(block[i:i + 2], 'big') if wide else block[i]
                i += 128 if wide else 64
        elif marker == 196:
            i = 0
            while i < len(block):
                info = block[i]; counts = block[i + 1:i + 17]; i += 17
                table, code = {}, 0
                for length, count in enumerate(counts, 1):
                    for _ in range(count):
                        table[(length, code)] = block[i]; i += 1; code += 1
                    code <<= 1
                tables[info] = table
        elif marker in (192, 194):
            if block[0] != 8: return []
            height, width = struct.unpack_from('>HH', block, 1)
            if not width or not height or width * height > MAX_PIXELS: return []
            progressive = marker == 194
            for i in range(block[5]):
                cid, sampling, quant = block[6 + i * 3:9 + i * 3]
                components[cid] = (sampling >> 4, sampling & 15, quant)
        elif marker == 221:
            restart = int.from_bytes(block, 'big')
        elif marker == 218:
            count = block[0]
            selectors = [(block[1 + i * 2], block[2 + i * 2]) for i in range(count)]
            if progressive and (block[-3] != 0 or block[-1] >> 4): return []
            if len(components) not in (1, 3) or count != len(components): return []
            mx = max(c[0] for c in components.values()); my = max(c[1] for c in components.values())
            total = math.ceil(width / (8 * mx)) * math.ceil(height / (8 * my))
            step, bits, preds, samples = max(1, total // 2048), _Bits(data, pos), {}, []
            for mcu in range(total):
                if mcu % 128 == 0 and time.monotonic() > deadline: break
                if restart and mcu and mcu % restart == 0:
                    bits.count = bits.value = 0
                    if data[bits.pos] != 255 or not 208 <= data[bits.pos + 1] <= 215: return samples
                    bits.pos += 2; preds.clear()
                means = []
                for cid, selector in selectors:
                    hx, vy, quant = components[cid]; values = []
                    for _ in range(hx * vy):
                        category = bits.symbol(tables[selector >> 4])
                        dc = preds.get(cid, 0) + bits.signed(category); preds[cid] = dc
                        values.append(128 + dc * quants[quant] * (1 << (block[-1] & 15) if progressive else 1) / 8.)
                        if not progressive:
                            k = 1
                            while k < 64:
                                symbol = bits.symbol(tables[16 | (selector & 15)])
                                if not symbol: break
                                run, length = symbol >> 4, symbol & 15
                                if not length and run != 15: raise ValueError('JPEG AC')
                                k += run + 1; bits.read(length)
                    means.append(sum(values) / len(values))
                if mcu % step == 0:
                    if len(means) == 1: samples.append((means[0],) * 3)
                    else:
                        y, cb, cr = means[0], means[1] - 128, means[2] - 128
                        samples.append((y + 1.402 * cr, y - .344136 * cb - .714136 * cr, y + 1.772 * cb))
            return samples
    return []


def sample(data):
    if len(data) > MAX_BYTES: return None
    try:
        if data.startswith(b'\x89PNG\r\n\x1a\n'): return dominant(_png(data))
        if data.startswith(b'\xff\xd8'): return dominant(_jpeg(data))
    except (ValueError, IndexError, KeyError, struct.error, zlib.error, OverflowError):
        pass
    return None
