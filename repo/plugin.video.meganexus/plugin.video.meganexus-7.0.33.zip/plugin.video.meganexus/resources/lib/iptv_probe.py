"""Verify configured IPTV Simple channels before Kodi's native PVR opens them.

Only worker threads call this module. No tokens/playlist URLs are logged or
persisted. Match the real IPTV Simple unique ID, never a guessed channel row.

7.0.29: a channel is refused only when it is known to be offline - the server
answers with an error or refuses the connection. When its stream cannot be
looked up (a big Xtream playlist, a slow server) Kodi simply plays it: the
8 MB / 3 s limits turned every channel of a 34 000-channel playlist into
"not responding".
"""
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from collections import OrderedDict

MAX_PLAYLIST = 96 * 1024 * 1024      # big Xtream playlists (tens of thousands of channels)
PLAYLIST_TTL = 1800
_cache = OrderedDict()
_lock = threading.Lock()


def unique_id(name, url, signed=True):
    # IPTV Simple Channels::GenerateChannelId: 32-bit hash(name + stream URL).
    value = 0
    for byte in (name + url).encode('utf-8'):
        value = (value * 33 + (byte - 256 if signed and byte > 127 else byte)) & 0xffffffff
    return abs(value if value < 0x80000000 else value - 0x100000000)


def parse(text):
    result, name = {}, ''
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith('#EXTINF:'):
            # The comma separating the title may occur inside a quoted attribute.
            parts = re.split(r',(?=(?:[^"]*"[^"]*")*[^"]*$)', line, maxsplit=1)
            name = parts[1].strip() if len(parts) == 2 else ''
        elif line and not line.startswith('#') and name:
            for signed in (True, False):
                key = unique_id(name, line, signed)
                old = result.get(key)
                result[key] = line if old in (None, line) else ''  # ambiguous identity is rejected
            name = ''
    return result


def _playlist(source, stopped):
    now = time.monotonic()
    with _lock:
        cached = _cache.get(source)
        if cached and now < cached[0]: return cached[1]
    if stopped(): return {}
    if source.startswith(('http://', 'https://')):
        with urlopen(Request(source, headers={'User-Agent':'Kodi MegaNexus'}), timeout=20) as response:
            data = response.read(MAX_PLAYLIST + 1)
    else:
        with open(source, 'rb') as handle: data = handle.read(MAX_PLAYLIST + 1)
    if len(data) > MAX_PLAYLIST or stopped(): return {}
    rows = parse(data.decode('utf-8-sig', 'replace'))
    with _lock:
        _cache[source] = (now + PLAYLIST_TTL, rows)
        while len(_cache) > 4: _cache.popitem(last=False)
    return rows


def stream(row, profile, stopped=lambda:False, instance=None):
    uid = row.get('uniqueid')
    if uid is None: return ''
    found = set()
    for name in sorted(os.listdir(profile))[:32]:
        if not name.startswith('instance-settings-') or not name.endswith('.xml'): continue
        if instance is not None and name != 'instance-settings-%d.xml' % int(instance): continue
        if stopped(): return ''
        values = {s.get('id'):s.text or '' for s in ET.parse(os.path.join(profile,name)).getroot().iter('setting')}
        if values.get('kodi_addon_instance_enabled') == 'false': continue
        source = values.get('m3uUrl') if values.get('m3uPathType','1') == '1' else values.get('m3uPath')
        if not source: continue
        try: url = _playlist(source, stopped).get(int(uid))
        except Exception: continue
        if url: found.add(url)
    return found.pop() if len(found) == 1 else ''


def responds(url, stopped=lambda:False):
    """False only when the stream is known to be offline: an HTTP error or a
    refused / unknown host. A slow answer is not proof - Kodi tries it."""
    from urllib.error import HTTPError, URLError
    import socket
    base = str(url).partition('|')[0]
    if not base.startswith(('http://','https://')): return bool(base)
    if stopped(): return False
    try:
        with urlopen(Request(base, headers={'Range':'bytes=0-4095', 'User-Agent':'Kodi MegaNexus'}), timeout=6) as response:
            data = response.read(4096)
        if stopped(): return False
        if '.m3u8' in urlsplit(base).path.lower() and data: return b'#EXTM3U' in data[:2048]
        return True
    except HTTPError as error:
        return error.code in (405, 416, 501)            # the server is up, it just disliked the probe
    except (socket.timeout, TimeoutError):
        return True
    except URLError as error:
        return isinstance(error.reason, (socket.timeout, TimeoutError))
    except Exception:
        return True


def verify(row, profile, stopped=lambda:False, instance=None):
    try: url = stream(row, profile, stopped, instance)
    except Exception: url = ''
    if not url: return not stopped()                     # unknown: let Kodi play it
    return responds(url, stopped)
