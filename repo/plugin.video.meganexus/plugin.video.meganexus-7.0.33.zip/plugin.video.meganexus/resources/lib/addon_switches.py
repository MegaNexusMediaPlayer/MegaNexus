"""Per-add-on on/off lists kept as JSON in one setting (7.0.17, 7.0.20).

Shared by the subtitle and sport switches: [{"id": ..., "enabled": bool}].
Until the user changes one, every add-on that offers the role is on, and
add-ons added later start on too.
"""
import json
import xbmcaddon


def saved(setting):
    from .settings_cache import setting as read
    raw = read(setting) or ''
    if not raw.strip():
        return None
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return None
    return data if isinstance(data, list) else None


def entries(setting, available):
    rows = saved(setting)
    if rows is None:
        return [(p, True) for p in available]
    switches = {row.get('id'): row.get('enabled') is True for row in rows if isinstance(row, dict)}
    return [(p, switches.get(p['id'], True)) for p in available]


def set_enabled(setting, rows, provider_id, on, missing):
    """rows: entries() of the role; missing: the message when the add-on does not offer it."""
    if not any(p['id'] == provider_id for p, _ in rows):
        raise ValueError(missing)
    value = [{'id': p['id'], 'enabled': bool(on) if p['id'] == provider_id else active} for p, active in rows]
    xbmcaddon.Addon('plugin.video.meganexus').setSetting(setting, json.dumps(value))
    from . import settings_cache
    settings_cache.invalidate()
