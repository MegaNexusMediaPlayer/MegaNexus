"""End MegaNexus' background workers together with the script that started them (7.0.5).

Kodi waits for every thread of a finished Python script, daemon threads too,
before it releases that script or closes. Idle pool workers never end on their
own, so a closed interface stayed in memory and Kodi hung on Exit with the old
process still holding its RAM (most visible on Android boxes, where the next
start then competed with it).
"""
import sys

# module name suffix -> function that ends its workers
_STOPS = (('browse_cache', 'stop_refresher'), ('meganexus.client', 'stop_background'), ('browse_meta', 'shutdown'))


def _modules(suffix):
    # The backend is importable as resources.lib.x and as x (both on sys.path).
    for name, module in list(sys.modules.items()):
        if module is not None and (name == suffix or name.endswith('.' + suffix)):
            yield module


def stop():
    for suffix, function in _STOPS:
        for module in _modules(suffix):
            try:
                getattr(module, function)()
            except Exception:
                pass
    for module in _modules('subtitle_files'):
        try:
            module.shutdown_coordinator()   # 7.0.19: running searches finish first
        except Exception:
            pass
