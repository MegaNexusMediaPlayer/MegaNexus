# -*- coding: utf-8 -*-
"""Backward-compat shim. Real implementation lives in meganexus.cache_store."""
from meganexus.cache_store import *  # noqa: F401,F403
