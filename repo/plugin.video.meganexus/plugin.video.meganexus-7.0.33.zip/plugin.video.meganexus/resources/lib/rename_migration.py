"""MegaNexus 7: move an installation from the previous add-on IDs (6.0.x).

Runs once, first thing when MegaNexus Hub starts (service) or opens, and only
when the previous backend add-on is still installed - an update, never a
fresh install that happens to find an old folder. Steps:

1. The previous profiles (backend, interface, skin, screensaver) are copied to
   the MegaNexus profiles with our identifiers translated
   (``legacy_names.prev_translate``): settings, accounts and tokens, the
   Continue Watching / library databases, collections. Caches and old
   installers are left behind. The Nuvio sync integration keeps its own names.
2. Kodi-wide references follow: favourites, keymaps, TMDb Helper players.
3. All or nothing (7.0.2): MegaNexus Skin (required, asked until accepted),
   then MegaNexus Screensaver, then every previous add-on off and the restart
   question. Until skin and screensaver are ours, nothing old is touched.
4. At the next start the previous add-ons, their profiles and Kodi's cached
   installers are removed, after a small backup zip in our profile
   (``previous-profile-backup.zip``).
"""
import json
import os
import shutil
import sqlite3
import time
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from . import legacy_names as L

BACKEND = 'plugin.video.meganexus'
DONE = 'meganexus_moved_from_previous'        # setting: '1' once the profile moved
CLEANUP = 'meganexus_previous_cleanup'        # setting: 'pending' until the old add-ons are gone
BUSY = 'meganexus.migrating'                  # Window(Home) property while it runs
SKIP_DIRS = {'installation-backups', 'updates', 'http_cache', 'art-cache', '__pycache__', 'packages',
             'meganexus-backups'}
DB_SUFFIXES = ('.db', '.sqlite', '.sqlite3')
TEXT_SUFFIXES = ('.json', '.txt', '.xml', '.m3u', '.m3u8', '.csv', '.bak')
BACKUP = 'previous-profile-backup.zip'
# Installer / migration state of the previous installation: never carried over
# (MegaNexus must install its own components and run its own one-time steps).
SKIP_SETTINGS = {DONE, CLEANUP, 'meganexus_components_for', 'meganexus_update_checked', 'meganexus_restart_pending',
                 'meganexus_screensaver_applied', 'meganexus_manifests_refreshed'}
BACKUP_MAX_FILE = 8 * 1024 * 1024


def _special(path):
    import xbmcvfs
    return Path(xbmcvfs.translatePath(path))


def _rpc(method, **params):
    import xbmc
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    except (TypeError, ValueError):
        return None
    return None if reply.get('error') else reply.get('result')


def _log(message, level=None):
    import xbmc
    xbmc.log('[MegaNexus] move from previous IDs: ' + message, xbmc.LOGINFO if level is None else level)


# ------------------------------------------------------------------ files --

def translate_settings_xml(text):
    """Kodi settings document (v1 value= or v2 text) with ids and values translated."""
    root = ET.fromstring(text)
    for node in root.iter('setting'):
        if node.get('id'):
            node.set('id', L.prev_translate(node.get('id')))
        if node.get('value') is not None:
            node.set('value', L.prev_translate(node.get('value')))
        if node.text:
            node.text = L.prev_translate(node.text)
    return ET.tostring(root, encoding='unicode')


def read_settings(path):
    """{translated id: translated value} of a previous settings.xml."""
    try:
        root = ET.fromstring(Path(path).read_text(encoding='utf-8'))
    except (OSError, ET.ParseError, UnicodeDecodeError):
        return {}
    out = {}
    for node in root.iter('setting'):
        key = node.get('id')
        if key:
            value = node.get('value') if node.get('value') is not None else (node.text or '')
            out[L.prev_translate(key)] = L.prev_translate(value)
    return out


def _copy_sqlite(source, target):
    tmp = target.with_name(target.name + '.moving')
    src = sqlite3.connect(source.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
    try:
        dst = sqlite3.connect(str(tmp))
        try:
            src.backup(dst)
            for (name,) in dst.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
                new = L.prev_translate(name)
                if new != name:
                    dst.execute('ALTER TABLE "%s" RENAME TO "%s"' % (name.replace('"', ''), new.replace('"', '')))
            dst.commit()
        finally:
            dst.close()
    finally:
        src.close()
    os.replace(tmp, target)


def copy_profile(source, target, settings_file=True):
    """Copy one previous profile directory; returns the copied relative paths.

    ``settings_file=False`` leaves settings.xml to the caller (the running
    backend applies them through Kodi so its cached settings stay in step)."""
    source, target = Path(source), Path(target)
    copied = []
    if not source.is_dir():
        return copied
    for path in sorted(source.rglob('*')):
        rel = path.relative_to(source)
        if any(part in SKIP_DIRS or part.startswith('.') for part in rel.parts):
            continue
        if not path.is_file() or path.is_symlink() or path.name.endswith(('.lock', '.importing', '.tmp')):
            continue
        if rel.as_posix() == 'settings.xml' and not settings_file:
            continue
        dest = target.joinpath(*[L.prev_translate(part) for part in rel.parts])
        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            if path.suffix.lower() in DB_SUFFIXES:
                _copy_sqlite(path, dest)
            elif path.name == 'settings.xml':
                dest.write_text(translate_settings_xml(path.read_text(encoding='utf-8')), encoding='utf-8')
            elif path.suffix.lower() in TEXT_SUFFIXES or path.name.endswith('.json.bak'):
                try:
                    text = path.read_text(encoding='utf-8')
                except UnicodeDecodeError:
                    shutil.copy2(path, dest)
                else:
                    dest.write_text(L.prev_translate(text), encoding='utf-8')
            else:
                shutil.copy2(path, dest)
            copied.append(rel.as_posix())
        except (OSError, sqlite3.Error, ET.ParseError) as exc:
            _log('kept %s behind (%s)' % (rel.as_posix(), exc.__class__.__name__))
    return copied


# ----------------------------------------------------------- Kodi-wide data --

def fix_text_file(path):
    """Translate our IDs inside a Kodi file (favourites, keymaps, players)."""
    path = Path(path)
    try:
        text = path.read_text(encoding='utf-8')
    except (OSError, UnicodeDecodeError):
        return False
    new = L.prev_translate(text)
    target = path.with_name(L.prev_translate(path.name))
    if new == text and target == path:
        return False
    target.write_text(new, encoding='utf-8')
    if target != path:
        path.unlink()
    return True


def fix_kodi_files():
    changed = 0
    for path in [_special('special://profile/favourites.xml')] + \
            sorted(_special('special://profile/keymaps').glob('*.xml')) + \
            sorted(_special('special://profile/addon_data/plugin.video.themoviedb.helper/players').glob('*.json')):
        if path.is_file() and (L.PREV in path.name.lower() or L.PREV in path.read_text(encoding='utf-8', errors='ignore').lower()):
            changed += fix_text_file(path)
    # The screensaver follows the skin (switch_and_retire), never before it.
    return changed


# ------------------------------------------------------------------- driver --

def previous_installed():
    return (_special('special://home/addons') / L.PREV_ADDONS[BACKEND]).is_dir()


def needed(addon=None):
    import xbmcaddon
    addon = addon or xbmcaddon.Addon(BACKEND)
    return addon.getSetting(DONE) != '1' and previous_installed()


def run(addon=None):
    """Move the installation once; True when something was moved."""
    import xbmc
    import xbmcaddon
    import xbmcgui
    addon = addon or xbmcaddon.Addon(BACKEND)
    if not needed(addon):
        return False
    home = xbmcgui.Window(10000)
    if home.getProperty(BUSY):
        # The other process (service / interface) is moving it: wait for it.
        monitor = xbmc.Monitor()
        for _ in range(600):
            if not home.getProperty(BUSY) or monitor.waitForAbort(0.1):
                break
        return False
    home.setProperty(BUSY, str(time.time()))
    try:
        data = _special('special://profile/addon_data')
        old_backend = data / L.PREV_ADDONS[BACKEND]
        copied = copy_profile(old_backend, data / BACKEND, settings_file=False)
        for key, value in read_settings(old_backend / 'settings.xml').items():
            if key in SKIP_SETTINGS:
                continue
            try:
                addon.setSetting(key, value)
            except Exception:
                pass
        for new_id in ('script.meganexus', 'skin.meganexus', 'screensaver.meganexus'):
            copied += copy_profile(data / L.PREV_ADDONS[new_id], data / new_id)
        # The image server's port is part of every poster address Kodi keeps in
        # its own texture cache: with the old port those images stay cached
        # (otherwise every poster is downloaded again, one by one).
        port = old_backend / 'art-cache' / 'port'
        if port.is_file():
            (data / BACKEND / 'art-cache').mkdir(parents=True, exist_ok=True)
            shutil.copy2(port, data / BACKEND / 'art-cache' / 'port')
            copied.append('art-cache/port')
        fixed = fix_kodi_files()
        addon.setSetting(DONE, '1')
        addon.setSetting(CLEANUP, 'pending')
        _log('profile moved (%d files), %d Kodi settings/files updated' % (len(copied), fixed))
    finally:
        home.clearProperty(BUSY)
    return True


def quiet_previous_skin():
    """7.0.17: the previous backend's service restores *its* skin whenever
    another one is active - with MegaNexus asking for MegaNexus Skin the two
    switched back and forth and Kodi asked "Keep this skin?" again and again.
    Its wish is turned off: its setting, and its "declined" mark for this
    Kodi session (names of the previous version, built at runtime)."""
    import xbmcaddon
    import xbmcgui
    try:
        xbmcaddon.Addon(L.PREV_ADDONS[BACKEND]).setSetting(L.PREV + '_skin_applied', 'false')
    except Exception:
        pass
    xbmcgui.Window(10000).setProperty(L.PREV + '.skin.declined', '1')


NEW_ADDONS = ('script.meganexus', 'screensaver.meganexus', 'skin.meganexus', BACKEND)


def withdraw():
    """7.0.17: MegaNexus Skin was declined during the move - MegaNexus 7 takes
    itself out again (all its add-ons) and the previous MegaNexus stays as it
    was, instead of asking for the skin in a loop. The update is offered again
    at the next Kodi start."""
    import xbmc
    import xbmcgui
    _log('MegaNexus Skin declined during the move: MegaNexus 7 is removed, the previous installation stays')
    xbmcgui.Dialog().ok('MegaNexus 7', 'MegaNexus 7 needs MegaNexus Skin, so it was not installed. Your previous '
                        'MegaNexus stays as it was. The update is offered again the next time Kodi starts.')
    addons = _special('special://home/addons')
    for addon_id in NEW_ADDONS:
        if addon_id == 'skin.meganexus' and xbmc.getSkinDir() == addon_id:
            continue
        if addon_id != BACKEND:
            _rpc('Addons.SetAddonEnabled', addonid=addon_id, enabled=False)
        shutil.rmtree(addons / addon_id, ignore_errors=True)
    xbmc.executebuiltin('UpdateLocalAddons')
    _rpc('Addons.SetAddonEnabled', addonid=BACKEND, enabled=False)   # last: this stops our own service


def ensure_skin():
    """MegaNexus Skin is required before anything old is touched (7.0.2)."""
    import xbmc
    import xbmcgui
    from . import skin_activation
    if xbmc.getSkinDir() == skin_activation.SKIN:
        return True
    if previous_installed():
        quiet_previous_skin()
    status = skin_activation.switch() if skin_activation.wanted() else 'declined'
    if status == 'ok':
        return True
    if status == 'failed':
        skin_activation.report_failure()
    elif previous_installed():
        withdraw()
    else:
        xbmcgui.Dialog().ok('MegaNexus 7', 'MegaNexus needs MegaNexus Skin. Your previous MegaNexus keeps working until '
                            'you choose Yes; MegaNexus asks again the next time Kodi starts or you open it.')
    return False


def ensure_screensaver():
    """MegaNexus Screensaver, set and read back (7.0.2)."""
    _rpc('Settings.SetSettingValue', setting='screensaver.mode', value='screensaver.meganexus')
    return (_rpc('Settings.GetSettingValue', setting='screensaver.mode') or {}).get('value') == 'screensaver.meganexus'


def retire_all():
    """Turn every previous add-on off - only after skin and screensaver are ours."""
    for old_id in L.PREV_ADDONS.values():
        _rpc('Addons.SetAddonEnabled', addonid=old_id, enabled=False)


def switch_and_retire():
    """All or nothing: skin, then screensaver, then the old add-ons off.
    Returns True when the previous installation is retired."""
    if not ensure_skin():
        _log('waiting for MegaNexus Skin; the previous add-ons stay as they are')
        return False
    if not ensure_screensaver():
        _log('screensaver not set yet; the previous add-ons stay as they are')
        return False
    retire_all()
    return True


def cleanup(addon=None):
    """Next start: remove the previous add-ons and profiles (after a backup)."""
    import xbmc
    import xbmcaddon
    addon = addon or xbmcaddon.Addon(BACKEND)
    if addon.getSetting(CLEANUP) != 'pending':
        return False
    if xbmc.getSkinDir() == L.PREV_ADDONS['skin.meganexus']:
        return False   # still on the old skin: keep everything until it moved
    addons = _special('special://home/addons')
    data = _special('special://profile/addon_data')
    backup = data / BACKEND / BACKUP
    try:
        with zipfile.ZipFile(backup, 'a', zipfile.ZIP_DEFLATED) as archive:
            names = set(archive.namelist())
            for old_id in L.PREV_ADDONS.values():
                folder = data / old_id
                for path in sorted(folder.rglob('*')) if folder.is_dir() else []:
                    rel = path.relative_to(data).as_posix()
                    if (path.is_file() and rel not in names and path.stat().st_size <= BACKUP_MAX_FILE
                            and not any(p in SKIP_DIRS for p in path.relative_to(folder).parts)):
                        archive.write(path, rel)
    except (OSError, zipfile.BadZipFile) as exc:
        _log('backup failed, old add-ons kept (%s)' % exc)
        return False
    for old_id in L.PREV_ADDONS.values():
        _rpc('Addons.SetAddonEnabled', addonid=old_id, enabled=False)
        for folder in (addons / old_id, data / old_id):
            shutil.rmtree(folder, ignore_errors=True)
        for cached in (addons / 'packages').glob(old_id + '-*.zip'):   # Kodi's installer cache
            try:
                cached.unlink()
            except OSError:
                pass
    xbmc.executebuiltin('UpdateLocalAddons')
    addon.setSetting(CLEANUP, 'done')
    _log('previous add-ons removed')
    return True


def ask_restart():
    """Once, when no video plays: restart Kodi (or reboot / close it, per platform)."""
    import xbmc
    import xbmcgui
    from .kodi_restart import plan
    builtin, label, _ = plan()
    if xbmcgui.Dialog().yesno('MegaNexus 7', 'MegaNexus now runs as its own add-ons. Your settings, accounts and '
                              'Continue Watching moved with it.[CR][CR]Restart Kodi now to finish?',
                              nolabel='Later', yeslabel=label):
        xbmc.executebuiltin(builtin)
        return True
    return False


def finish_in_service(monitor, busy=lambda: False):
    """Service thread, after the skin check: retire the previous add-ons and
    ask for the restart that removes them."""
    import xbmc
    import xbmcaddon
    addon = xbmcaddon.Addon(BACKEND)
    if addon.getSetting(CLEANUP) != 'pending' or not previous_installed():
        return False
    for _ in range(720):   # up to an hour: never over a video or the open interface
        if not busy() and not xbmc.Player().isPlayingVideo():
            break
        if monitor.waitForAbort(5):
            return False
    else:
        return False
    # Strict order (7.0.2): skin, screensaver, then the old add-ons off, then
    # the restart that removes them. Until then nothing old is touched.
    if not switch_and_retire():
        return False
    return ask_restart()
