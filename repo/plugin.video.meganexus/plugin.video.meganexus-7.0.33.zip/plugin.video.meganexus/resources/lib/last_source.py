"""Remember successfully started sources for a bounded Continue Watching reuse.

Stored only in the existing local cache. Profile/account/provider changes give
a different hashed key; playback tokens and old resume positions are not saved.
"""
import hashlib
import json
import time
from . import cache_store
from .settings_cache import cached_addon

SETTING='meganexus_reuse_last_link_hours'
KIND='meganexus_last_source'
HOURS=('0','12','24')
LABELS={'0':'Off','12':'12 hours','24':'24 hours'}
SERVER_KEYS=('server_type','server_url','token','rating_key','item_id','duration_ms',
             'media_source_id','play_session_id','device_id','session_id','server_flavor',
             'client_id','device_name','product','product_version')


def hours(addon=None):
    value=(addon or cached_addon()).getSetting(SETTING) or '12'
    return int(value) if value in HOURS else 12


def _scope():
    from . import stream_providers
    from .meganexus.common import profile_path
    from .meganexus.nuvio_stremio_sync import Nuvio
    token=Nuvio.token() or {}
    account=(token.get('user_id') or token.get('email'),token.get('profile_index')) if token.get('access_token') else None
    # 7.0.31: an AIOStreams link copied again (only its encrypted part changes) is the
    # same add-on - its new link made every remembered source ask for a source again.
    from .meganexus.store import instance_key
    providers=sorted((p.get('id'),instance_key(p.get('manifest_url')) or p.get('base_url')) for p in stream_providers.enabled())
    addon=cached_addon()
    debrid=[addon.getSetting(k) for k in ('torbox_api_key','torbox_enabled','premiumize_api_key','premiumize_enabled')]
    servers=[addon.getSetting(k) for k in ('plex_auth_json','jellyfin_auth_json','emby_auth_json')]   # 7.0.29: Jellyfin and Emby separate
    values=(profile_path(),account,providers,debrid,servers,
            [addon.getSetting(k) for k in ('meganexus_plex_enabled','meganexus_jellyfin_enabled','meganexus_emby_enabled')])
    return hashlib.sha256(json.dumps(values,sort_keys=True,default=str).encode()).hexdigest()


def _key(context,scope=None):
    media=context.get('media_type') or 'movie'
    title=context.get('canonical_id') or ''
    video=context.get('video_id') or title
    if not title or not video:return ''
    identity=(scope or _scope(),media,title,video,str(context.get('season') or ''),str(context.get('episode') or ''))
    return hashlib.sha256(json.dumps(identity).encode()).hexdigest()


def remember(context):
    """Call only after matching AVStarted, never after merely queueing a URL."""
    if not hours() or not context.get('stream_url') or context.get('_last_source_reused'):return
    if context.get('_last_source_scope') and context['_last_source_scope']!=_scope():return
    key=_key(context)
    if not key:return
    row={'url':context['stream_url'],'name':context.get('stream_name') or '',
         'title':context.get('stream_title') or '', 'requestHeaders':context.get('request_headers') or {},
         'behaviorHints':context.get('behaviorHints') or {},'subtitles':context.get('subtitles') or [],
         '_meganexus_source':{'id':context.get('provider_id') or '',
             'name':context.get('provider_name') or '', 'base_url':context.get('provider_base_url') or ''}}
    if context.get('server_type'):row['_meganexus_server']={k:context[k] for k in SERVER_KEYS if k in context}
    value={'selected_at':time.time(),'row':row}
    if len(json.dumps(value).encode())<=65536:cache_store.update(KIND,key,value)


def tag(context):
    context['_last_source_scope']=_scope()
    return context


def context(meta,current):
    """Return a fresh playback context, or let the normal source search run."""
    if current.get('force_manual') or current.get('play_from_start'):return None
    if not current.get('meganexus_continue') and not current.get('resume_seconds') and not current.get('resume_percent'):return None
    limit=hours()
    if not limit:return None
    target=dict(current,media_type=meta.get('type') or 'movie',canonical_id=meta['id'],video_id=current.get('video_id') or meta['id'])
    key=_key(target);saved=cache_store.get(KIND,key) if key else None
    if not isinstance(saved,dict):return None
    try:
        age=time.time()-float(saved.get('selected_at',0))
        if not 0<=age<limit*3600:return None
        row=saved['row']
        if not isinstance(row,dict) or not row.get('url'):return None
        from . import backend_api
        result=backend_api.playback_context(meta,row,row['_meganexus_source'],
             current.get('season',''),current.get('episode',''),target['video_id'],current.get('resume_seconds') or 0)
        result.update(resume_percent=current.get('resume_percent') or 0,
                      _last_source_reused=True,_last_source_key=key,_last_source_selected_at=saved['selected_at'])
        return result
    except (ValueError,TypeError,KeyError):return None


def forget(context):
    key=context.get('_last_source_key')
    if not key:return
    saved=cache_store.get(KIND,key)
    if isinstance(saved,dict) and saved.get('selected_at')==context.get('_last_source_selected_at'):
        cache_store.update(KIND,key,{})
