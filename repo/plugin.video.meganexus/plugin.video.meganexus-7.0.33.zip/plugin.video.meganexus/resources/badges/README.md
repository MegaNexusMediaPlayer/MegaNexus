MegaNexus starter badges (7.0.29): the set every user has until they import their own.

`starter.json` is a Nuvio badge pack: the Elite badge pictures of a universal Nuvio pack,
referenced by URL (Kodi downloads and caches them like any imported badge; nothing is
bundled), with plain rules for what a source name says (resolution, source, HDR, codec,
audio, channels, language flags). Raise `version` when the set changes: devices still on
the starter set take the new one; an imported set is never replaced.
