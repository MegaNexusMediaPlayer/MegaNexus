# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""YouTube for the HUB's YouTube app (9.0.6): what youtube.com's own pages ask its web API
(InnerTube: youtubei/v1 search and browse) - no key, no account, no other add-on.

Nothing of it is kept on disk: answers live in this process' memory only while the app is
open (KEEP seconds, at most MEMORY of them) and forget() drops them when it closes - "yt
nesmimo spremati nista trajno u cache samo dok app radi, da ne usporava ostatak MegaNexusa".
The channels the person adds are theirs (CHANNELS in the profile), not a cache.

Videos play through Kodi's YouTube add-on (play_path), the same way the trailers do.
"""
import json
import os
import re
import threading
import time
from collections import OrderedDict
from urllib.request import Request, urlopen

from .kodi_text import world

API = 'https://www.youtube.com/youtubei/v1/%s?prettyPrint=false'
PAGE = 'https://www.youtube.com/'
AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'
VERSION = '2.20261029.11.00'   # the web client's version when youtube.com's page cannot be read
TIMEOUT = 8
KEEP = 600            # s an answer is reused while the app is open
MEMORY = 48           # answers held at once
CHANNELS = 'youtube_channels.json'
AUTONEXT = 'meganexus_youtube_autonext'   # Autoplay (the player's switch, Settings › YouTube): off unless turned on
PLAY = 'plugin://plugin.video.youtube/play/?video_id=%s&incognito=true'   # it keeps no history of them either
# search filters (what youtube.com's own filter menu sends): videos only, and how they are chosen
POPULAR_WEEK = 'CAMSBAgDEAE='    # most viewed, this week
MOST_VIEWED = 'CAMSAhAB'         # most viewed
THIS_MONTH = 'EgQIBBAB'          # uploaded this month (YouTube no longer sorts its answers by date)
CHANNELS_ONLY = 'EgIQAg=='       # channels
CHANNEL_VIDEOS = 'EgZ2aWRlb3PyBgQKAjoA'   # a channel's Videos tab
CHANNEL_PAGES = 3                         # its pages read for "All videos" (30 videos each)
# the categories of the app's Home: (row name, what is searched for); search answers are
# chosen by YouTube for the region (gl) - a category word is a question, not a list of titles
TOPICS = (('Music', 'music'), ('Gaming', 'gaming'), ('News', 'news'), ('Movie trailers', 'official trailer'),
          ('Podcasts', 'podcast'), ('Football', 'football highlights'), ('Technology', 'tech review'),
          ('Comedy', 'comedy'), ('Science', 'science'), ('Cars', 'cars'), ('Cooking', 'recipe'),
          ('Fitness', 'workout'), ('Travel', 'travel'), ('Nature', 'nature documentary'))
SEARCH_PAGES = 2      # pages of an answer read for a row (20 videos each)
# YouTube's own Live and Sports pages (their shelves of videos)
LIVE_PAGE, SPORTS_PAGE = 'UC4R8DWoMoI7CAwX8_LjQHig', 'UCEgdi0XIXXZ-qJOFPf4JSKw'

_lock = threading.Lock()
_memory = OrderedDict()
_client = ['', 0.]


def forget():
    """The app is closing: nothing of YouTube stays behind."""
    with _lock:
        _memory.clear()
        _client[:] = ['', 0.]


PICTURE_HOSTS = ('i.ytimg.com', 'yt3.ggpht.com', 'yt3.googleusercontent.com')
CLOSED = 'youtube.closed'    # NotifyAll(meganexus, youtube.closed): the app has closed (the service cleans up)


def forget_pictures():
    """Kodi stores every picture it shows (its Thumbnails and Textures database); the app's go
    once it has closed. Run by the MegaNexus service, so the HUB never waits for it."""
    import xbmc

    def rpc(method, params):
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})) or '{}')
    ids = set()
    for host in PICTURE_HOSTS:
        found = (rpc('Textures.GetTextures', {'properties': ['url'], 'filter': {'field': 'url', 'operator': 'contains', 'value': host}})
                 .get('result') or {}).get('textures') or ()
        ids.update(item['textureid'] for item in found if isinstance(item, dict) and item.get('textureid') is not None)
    removed = sum(1 for texture_id in sorted(ids) if 'error' not in rpc('Textures.RemoveTexture', {'textureid': texture_id}))
    xbmc.log('[MegaNexus] YouTube closed: %d of its pictures removed from Kodi\'s picture store.' % removed, xbmc.LOGINFO)
    return removed


def _kept(key, make):
    now = time.monotonic()
    with _lock:
        held = _memory.get(key)
        if held and held[0] > now:
            _memory.move_to_end(key)
            return held[1]
    value = make()
    if value:
        with _lock:
            _memory[key] = (now + KEEP, value)
            while len(_memory) > MEMORY:
                _memory.popitem(last=False)
    return value


def place():
    """(hl, gl): the language and region chosen for the MegaNexus Catalog (Settings)."""
    try:
        from .settings_snapshot import cached_addon
        addon = cached_addon()
        language = addon.getSetting('meganexus_catalog_language') or 'en-US'
        region = addon.getSetting('meganexus_catalog_region') or 'US'
    except Exception:
        language, region = 'en-US', 'US'
    return language.split('-')[0].lower() or 'en', region.upper() or 'US'


def _version():
    """The web client's version, as youtube.com's page states it - read once per app."""
    with _lock:
        if _client[0]:
            return _client[0]
    version = ''
    try:
        with urlopen(Request(PAGE, headers={'User-Agent': AGENT}), timeout=TIMEOUT) as response:
            found = re.search(r'"INNERTUBE_CLIENT_VERSION":"([0-9.]+)"', response.read().decode('utf-8', 'replace'))
            version = found.group(1) if found else ''
    except Exception:
        version = ''
    with _lock:
        _client[:] = [version or VERSION, time.monotonic()]
        return _client[0]


def _ask(endpoint, body):
    hl, gl = place()
    payload = dict(body, context={'client': {'clientName': 'WEB', 'clientVersion': _version(), 'hl': hl, 'gl': gl}})
    request = Request(API % endpoint, data=json.dumps(payload).encode('utf-8'),
                      headers={'User-Agent': AGENT, 'Content-Type': 'application/json'})
    with urlopen(request, timeout=TIMEOUT) as response:
        return json.loads(response.read().decode('utf-8'))


# ---- reading the answers -----------------------------------------------------------------------
def _text(value):
    if isinstance(value, str):
        return value
    if not isinstance(value, dict):
        return ''
    if 'simpleText' in value:
        return value['simpleText'] or ''
    if 'content' in value:
        return value['content'] or ''
    return ''.join(run.get('text', '') for run in value.get('runs') or ())


def _all(node, names):
    """Every object under one of ``names`` (in the order of the page)."""
    stack = [node]
    while stack:
        item = stack.pop()
        if isinstance(item, dict):
            for key in reversed(list(item)):
                value = item[key]
                if key in names and isinstance(value, dict):
                    yield key, value
                elif isinstance(value, (dict, list)):
                    stack.append(value)
        elif isinstance(item, list):
            stack.extend(reversed(item))


def _picture(thumbnails, video_id=''):
    """(card picture, big picture). A video's are YouTube's plain addresses - the signed ones of the
    answer (…/hq720.jpg?sqp=…) came back 404 to Kodi and the card stayed empty: the card's at 320 px
    (mqdefault, 16:9), the big one at 1280 px when the video has it (the answer lists hq720), else
    480 px. A channel's picture is the largest of the answer."""
    sources = sorted((t for t in thumbnails or () if isinstance(t, dict) and t.get('url')), key=lambda t: t.get('width') or 0)
    if video_id:
        big = 'hq720' if any('/hq720' in t['url'] for t in sources) else 'hqdefault'
        return 'https://i.ytimg.com/vi/%s/mqdefault.jpg' % video_id, 'https://i.ytimg.com/vi/%s/%s.jpg' % (video_id, big)
    if not sources:
        return '', ''
    url = sources[-1]['url']
    url = 'https:' + url if url.startswith('//') else url
    return url, url


def _video(renderer):
    video_id = renderer.get('videoId') or ''
    title = _text(renderer.get('title'))
    if not video_id or not title:
        return None
    styles = [(o.get('thumbnailOverlayTimeStatusRenderer') or {}).get('style') for o in renderer.get('thumbnailOverlays') or ()]
    badges = [(b.get('metadataBadgeRenderer') or {}).get('style') for b in renderer.get('badges') or ()]
    live = 'LIVE' in styles or 'BADGE_STYLE_TYPE_LIVE_NOW' in badges
    if 'SHORTS' in styles or renderer.get('upcomingEventData'):
        return None      # Shorts are made for phones; a stream still to come does not play yet
    owner = (renderer.get('ownerText') or renderer.get('longBylineText') or renderer.get('shortBylineText') or {})
    channel_id = next((((r.get('navigationEndpoint') or {}).get('browseEndpoint') or {}).get('browseId') or ''
                       for r in owner.get('runs') or () if r.get('navigationEndpoint')), '')
    snippet = renderer.get('detailedMetadataSnippets') or ()
    about = _text(snippet[0].get('snippetText')) if snippet else _text(renderer.get('descriptionSnippet'))
    card, big = _picture((renderer.get('thumbnail') or {}).get('thumbnails'), video_id)
    return {'id': video_id, 'title': title, 'channel': _text(owner), 'channel_id': channel_id,
            'views': _text(renderer.get('shortViewCountText') or renderer.get('viewCountText')),
            'age': _text(renderer.get('publishedTimeText')), 'length': _text(renderer.get('lengthText')),
            'live': live, 'about': about, 'card': card, 'picture': big}


def _lockup(model, channel=''):
    """A video in YouTube's newer layout (channel pages, related videos)."""
    if model.get('contentType') != 'LOCKUP_CONTENT_TYPE_VIDEO' or not model.get('contentId'):
        return None
    meta = (model.get('metadata') or {}).get('lockupMetadataViewModel') or {}
    title = _text(meta.get('title'))
    if not title:
        return None
    rows = [[_text(part.get('text')) for part in row.get('metadataParts') or ()]
            for row in ((meta.get('metadata') or {}).get('contentMetadataViewModel') or {}).get('metadataRows') or ()]
    rows = [row for row in rows if any(row)]
    owner = channel
    if len(rows) > 1:
        owner = rows[0][0]
    numbers = rows[-1] if rows else []
    image = (model.get('contentImage') or {}).get('thumbnailViewModel') or {}
    length, live = '', False
    for _, badge in _all(image, ('thumbnailBadgeViewModel',)):
        length = badge.get('text') or length
        live = live or 'LIVE' in str(badge.get('badgeStyle') or '')
    card, big = _picture((image.get('image') or {}).get('sources'), model['contentId'])
    return {'id': model['contentId'], 'title': title, 'channel': owner, 'channel_id': '',
            'views': numbers[0] if numbers else '', 'age': numbers[1] if len(numbers) > 1 else '',
            'length': '' if live else length, 'live': live, 'about': '', 'card': card, 'picture': big}


def videos(answer, channel=''):
    """The videos of an answer, in its order, each once (Shorts left out)."""
    found, seen = [], set()
    for name, node in _all(answer, ('videoRenderer', 'gridVideoRenderer', 'lockupViewModel')):
        video = _lockup(node, channel) if name == 'lockupViewModel' else _video(node)
        if video and video['id'] not in seen:
            seen.add(video['id'])
            found.append(video)
    return found


def channels(answer):
    found = []
    for _, node in _all(answer, ('channelRenderer',)):
        if not node.get('channelId'):
            continue
        avatar, _big = _picture((node.get('thumbnail') or {}).get('thumbnails'))
        # YouTube puts the subscribers in videoCountText and the @name in subscriberCountText
        handle, subscribers = _text(node.get('subscriberCountText')), _text(node.get('videoCountText'))
        found.append({'id': node['channelId'], 'name': _text(node.get('title')), 'avatar': avatar,
                      'handle': handle if handle.startswith('@') else '',
                      'subscribers': subscribers if not subscribers.startswith('@') else handle,
                      'about': _text(node.get('descriptionSnippet'))})
    return found


def shelves(answer):
    """A YouTube page's named shelves: [(name, videos)]."""
    found = []
    for _, shelf in _all(answer, ('richShelfRenderer', 'shelfRenderer')):
        items = videos(shelf.get('contents') or shelf.get('content') or {})
        if items:
            found.append((_text(shelf.get('title')), items))
    return found


# ---- what the app asks for -----------------------------------------------------------------
def search(query, params=''):
    body = {'query': query}
    if params:
        body['params'] = params
    return _kept(('search', query, params), lambda: _pages('search', _ask('search', body), SEARCH_PAGES))


def _pages(endpoint, answer, pages, channel=''):
    """The videos of an answer and of its next ``pages - 1`` pages (asked at ``endpoint``), each once."""
    found = videos(answer, channel)
    token = _more(answer)
    for _ in range(pages - 1):
        if not token:
            break
        page = _ask(endpoint, {'continuation': token})
        seen = {v['id'] for v in found}
        found += [v for v in videos(page, channel) if v['id'] not in seen]
        token = _more(page)
    return found


def find_channels(query):
    return _kept(('channels', query), lambda: channels(_ask('search', {'query': query, 'params': CHANNELS_ONLY})))


def _channel(answer, channel_id):
    """A channel's Videos tab: its name and picture, its newest videos, and where its other
    views are - read from the page (the Popular chip, the Live tab), never guessed."""
    about = (answer.get('metadata') or {}).get('channelMetadataRenderer') or {}
    name = about.get('title') or ''
    pictures = (about.get('avatar') or {}).get('thumbnails') or ()
    chips = [chip for _, chip in _all(answer, ('chipViewModel',))]
    unchosen = [chip for chip in chips if not chip.get('selected')]
    popular = ((((unchosen[0].get('tapCommand') or {}).get('innertubeCommand') or {}).get('continuationCommand') or {})
               .get('token') or '') if len(chips) > 1 and unchosen else ''
    live = ''
    for _, tab in _all(answer, ('tabRenderer',)):
        params = ((tab.get('endpoint') or {}).get('browseEndpoint') or {}).get('params') or ''
        if _tab_is(params, b'streams'):
            live = params
    found = _pages('browse', answer, CHANNEL_PAGES, name)      # all of its videos: the tab's next pages
    return {'id': channel_id, 'name': name, 'avatar': pictures[0]['url'] if pictures else '',
            'videos': found, 'popular': popular, 'live': live}


def _more(answer):
    """The token of a list's next page: the last item of the video grid (a channel) or of the
    results (a search), or of a page that continued it - not the other panels' (comments, filters)."""
    lists = [grid.get('contents') or [] for _, grid in _all(answer, ('richGridRenderer', 'sectionListRenderer'))]
    lists += [action.get('continuationItems') or [] for _, action in
              _all(answer, ('appendContinuationItemsAction', 'reloadContinuationItemsCommand'))]
    for items in lists:
        last = (items[-1] if items else {}).get('continuationItemRenderer') or {}
        token = ((last.get('continuationEndpoint') or {}).get('continuationCommand') or {}).get('token')
        if token:
            return token
    return ''


def _tab_is(params, word):
    import base64
    from urllib.parse import unquote
    try:
        return word in base64.urlsafe_b64decode(unquote(params) + '==')[:24]
    except (ValueError, TypeError):
        return False


def channel(channel_id):
    return _kept(('channel', channel_id), lambda: _channel(_ask('browse', {'browseId': channel_id, 'params': CHANNEL_VIDEOS}), channel_id))


def channel_videos(channel_id):
    return (channel(channel_id) or {}).get('videos') or []


def channel_popular(channel_id):
    found = channel(channel_id) or {}
    if not found.get('popular'):
        return []
    return _kept(('popular', channel_id), lambda: videos(_ask('browse', {'continuation': found['popular']}), found.get('name') or ''))


def channel_live(channel_id):
    found = channel(channel_id) or {}
    if not found.get('live'):
        return []
    from urllib.parse import unquote
    return _kept(('live', channel_id), lambda: videos(_ask('browse', {'browseId': channel_id, 'params': unquote(found['live'])}), found.get('name') or ''))


def page(browse_id):
    return _kept(('page', browse_id), lambda: shelves(_ask('browse', {'browseId': browse_id})))


def related(video_id):
    """What YouTube puts beside a video (its "Up next") - the app's next video comes from here."""
    def make():
        answer = _ask('next', {'videoId': video_id})
        side = (((answer.get('contents') or {}).get('twoColumnWatchNextResults') or {}).get('secondaryResults') or answer)
        return [v for v in videos(side) if v['id'] != video_id]
    return _kept(('related', video_id), make)


def topic(query):
    return search(query, POPULAR_WEEK)


# ---- the person's channels (theirs - kept in the profile) ----------------------------------------
def _channels_file():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), CHANNELS)


def my_channels():
    try:
        with open(_channels_file(), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [c for c in saved if isinstance(c, dict) and c.get('id')] if isinstance(saved, list) else []


def _save_channels(items):
    path = _channels_file()
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(items, handle, ensure_ascii=False)
    os.replace(path + '.part', path)


def add_channel(channel):
    items = [c for c in my_channels() if c['id'] != channel.get('id')]
    items.insert(0, {'id': channel['id'], 'name': channel.get('name') or '', 'avatar': channel.get('avatar') or ''})
    _save_channels(items)
    return items


def remove_channel(channel_id):
    items = [c for c in my_channels() if c['id'] != channel_id]
    _save_channels(items)
    return items


def has_channel(channel_id):
    return any(c['id'] == channel_id for c in my_channels())


# ---- the app's cards ------------------------------------------------------------------------
def meta_line(video):
    """The line under the title, in this order: channel · LIVE · how long · views · when it came out -
    nothing else, no description ("naziv, ime kanala, uzivo, trajanje, broj pregleda... sve ostale
    deskripcije izbaci")."""
    parts = (video.get('channel'), 'LIVE' if video.get('live') else '', video.get('length'), video.get('views'), video.get('age'))
    return '  ·  '.join(p.strip() for p in parts if p and p.strip())


def video_card(video):
    # the words as the chosen font draws them: emoji and the world's scripts in MegaNexus' own font,
    # Chinese, Japanese and Korean in Kodi's (kodi_text.world)
    font, (title, channel, line) = world(video['title'], video.get('channel'), meta_line(video))
    return {'title': title, 'subtitle': channel, 'plot': '', 'meta_line': line, 'font': font,
            'poster': video.get('card') or '', 'landscape': video.get('card') or '',
            'fanart': video.get('picture') or '', 'clearlogo': '', 'shape': 'landscape',
            'youtube': {'video': video['id'], 'channel_id': video.get('channel_id') or '', 'channel': video.get('channel') or ''}}


def channel_card(channel):
    font, (name, line, about) = world(channel.get('name'), '  ·  '.join(p for p in (channel.get('handle'), channel.get('subscribers')) if p),
                                      channel.get('about'))
    return {'title': name, 'subtitle': line, 'plot': about, 'meta_line': line, 'font': font,
            'poster': channel.get('avatar') or '', 'landscape': channel.get('avatar') or '', 'fanart': '', 'clearlogo': '',
            'shape': 'square', 'round': True, 'youtube': {'channel_id': channel['id'], 'channel': channel.get('name') or '',
                                              'avatar': channel.get('avatar') or ''}}


DASH_SETTING = 'kodion.mpd.videos'    # Kodi's YouTube add-on: MPEG-DASH videos (its own setting)


def steady(on=None):
    """Steady playback: the YouTube add-on's MPEG-DASH off. With it on, its 7.4.4 has YouTube refuse
    the rest of a video after about a minute or a seek (its issues #1481, #1483); off, it plays
    the one stream YouTube still serves whole (360p). ``on`` sets it; returns whether it is on."""
    import xbmcaddon
    try:
        addon = xbmcaddon.Addon('plugin.video.youtube')
        if on is not None:
            addon.setSettingBool(DASH_SETTING, not on)
        return not addon.getSettingBool(DASH_SETTING)
    except Exception:
        return False


def play_path(video_id):
    return PLAY % video_id if re.fullmatch(r'[A-Za-z0-9_-]{6,20}', str(video_id or '')) else ''
