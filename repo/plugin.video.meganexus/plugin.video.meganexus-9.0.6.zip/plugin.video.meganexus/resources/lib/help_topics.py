# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The user guide's topics, in the order of HUB Settings (7.0.42: shared by HUB Settings > Help & diagnostics on the
TV, meganexus_ui/help_guide.py, and the Help tab of the phone page, phone_setup.py).

Pure data: (key, title, text). Text uses Kodi's [B]..[/B] for headings; the phone
page turns them into headings of its own.
"""

B, E = '[B]', '[/B]'


def _h(text):
    return '%s%s%s' % (B, text, E)


TOPICS = (
    ('start', 'Getting started', '\n'.join((
        _h('The two screens'),
        'The HUB is the start screen with the tiles at the bottom: MegaNexus, Channels (IPTV), Live Sport, '
        'HUB Settings, Kodi Settings and Power. "MegaNexus" opens Home - your rows of films and series. '
        'Below them peek the apps - Down from the tiles: YouTube, Music (Plex, Jellyfin and Emby come later).',
        '',
        _h('Home'),
        'Up / Down moves between rows, Left / Right along a row. OK opens a title (Continue Watching '
        'resumes it straight away). Long OK or the menu key opens Title options (Play, Trailer, Library, '
        'Mark watched, Remove from Continue Watching...). The Info key shows the full description.',
        'At the top: Home, Library, Search, Settings and HUB.',
        '',
        _h('The quickest set-up'),
        'HUB Settings > Set up on phone · QR code. Scan the code with the phone (same Wi-Fi) and do '
        'everything there: Nuvio or Stremio sign-in, add-ons, API keys, collections, screensaver and badges. '
        'Keep the QR screen open until you press "Save & start MegaNexus".',
        '',
        _h('Quick setup: two ways, one tap each'),
        'The phone page starts with two quick setups. Both use public services - run by their own authors, not '
        'by MegaNexus - and are added beside your own add-ons, never over them:',
        '  - Quick setup · Debrid (the main one): your debrid service\'s key (TorBox, Real-Debrid, AllDebrid, '
        'Premiumize, Offcloud or Easynews) and a TMDB key. MegaNexus makes its own MegaNexus Streams (AIOStreams) '
        'and MegaNexus Metadata (AIOMetadata) with a full set of collections and their pictures. A TVDB key and a '
        'Gemini key are optional. "Change configuration" opens their set-up pages later.',
        '  - Quick setup · Free streams: MegaNexus with PenguPlay - no debrid service. Titles, posters and catalogs '
        'come from the MegaNexus Catalog (TMDB), the streams from PenguPlay. PenguPlay asks you to sign in on its own '
        'page: "Open PenguPlay", sign in (or make its account), copy the install link and paste it. Quality and choice '
        'depend on PenguPlay; for the best streams use the debrid setup.',
        'Below them, "Your add-ons": add-ons that offer metadata, streams and subtitles, each set up on its own '
        'page - that is your private, complete setup, made the way you like (see "Add-ons").',
        '',
        _h('Typing with the phone'),
        'Every on-screen keyboard has "Write with phone" above the keys: scan the QR code, type on the phone and tap '
        '"Send to TV" - the text goes into the keyboard and OK is pressed. Passwords are typed in a hidden field.',
        '',
        _h('Like MegaNexus?'),
        'HUB Settings > Buy me a coffee · Ko-fi (right under the phone set-up) - a QR code to support the development.',
    ))),
    ('catalogs', 'Metadata, catalogs & collections', '\n'.join((
        _h('Three words'),
        '  - Metadata: what MegaNexus knows about a title - its name, posters, logo, description, cast, seasons '
        'and episodes. It comes from your metadata add-ons (HUB Settings > Add-ons > Metadata). The first one '
        'that is ON and knows the title answers; the order of the list matters.',
        '  - Catalog: a list an add-on offers - Popular Movies, Trending Series, Netflix Series, Top Rated... One '
        'add-on can offer dozens. A catalog can be a row on Home by itself.',
        '  - Collection: a card that opens a page of several catalogs - for example "Netflix" with its films and its '
        'series, or "Action" with films from several add-ons. Collections come from your Nuvio account, a quick '
        'setup, a JSON file, or you make them from your installed catalogs.',
        '',
        _h('The built-in MegaNexus Catalog'),
        'MegaNexus brings its own metadata add-on, the MegaNexus Catalog (TMDB, free): titles, descriptions and '
        'catalogs in your language and region (HUB Settings > Add-ons > Metadata > MegaNexus Catalog · language & '
        'region, or under the add-on on the phone). It switches itself on only while no other metadata add-on is '
        'there; switched on or off by you, it stays that way. It offers catalogs, not collections - on Home they '
        'are rows. Some of its rows are filtered by your region (Prime Video answers nothing for Croatia): such a '
        'row comes in English - only once the catalog answered and was empty twice while the English one has '
        'titles, never because of a slow connection.',
        '',
        _h('What Home shows'),
        'Your own collections always win: once you import, choose or make them, MegaNexus never changes them. '
        'Without them, Home is laid out by itself - from the catalogs of your own add-ons, or else from the '
        'MegaNexus Catalog\'s. Collections & Home rows (HUB Settings > Home & library) starts with "Home shows": '
        'your collections, or the MegaNexus Catalog\'s ("automatic" when MegaNexus chose it because you have none '
        'of your own) - choose it to switch, yours are kept aside. Below it: which rows show, their order and names.',
        'Home layout (Home & appearance > Layout & cards): collections (cards that open a collection), rows (every '
        'catalog of your collections as a row of posters) or posters (one wall of everything).',
        '',
        _h('Many rows'),
        'Up to 12 rows Home scrolls as a list. With more, Down and Up go on through all of them: one row slides in '
        'after the other, a row not ready yet comes empty and fills as you stay - holding Down goes straight on.',
        'Browse all (Home & appearance): on, a row ends in a "Browse all" card that opens the whole catalog; off, '
        'the row goes on by itself - empty cards wait at its end while its next titles load, and Right never stops.',
    ))),
    ('connections', 'API keys & accounts', '\n'.join((
        _h('Accounts & tracking'),
        'Nuvio account - sign in to bring your add-ons, collections, library and progress from the Nuvio '
        'apps; Nuvio sync direction decides whether MegaNexus only reads or also writes back.',
        'Stremio - your Stremio add-ons and Continue Watching.',
        'Trakt, Simkl, MDBList - tracking services: what you watch is marked there, their watchlists appear '
        'in the Library, Continue Watching follows them. MDBList also gives the ratings row (IMDb, Rotten '
        'Tomatoes, Metacritic, Letterboxd...) - choose the services in MDBList ratings.',
        '',
        _h('Add-ons'),
        'Metadata, stream, subtitle and sport add-ons (see "Add-ons"), Refresh add-on '
        'catalogs now, Remove an add-on, and the YouTube add-on used for some trailers.',
        '',
        _h('API keys'),
        'Every key is in one place: HUB Settings > API keys, in groups - metadata and artwork, skip and AI '
        'subtitles, tracking, debrid, Usenet. Other pages send you there when a key is missing.',
        'TMDb - actor search, recommendations and TMDB pictures. MDBList - ratings and tracking. '
        'Fanart.tv - posters, backgrounds and logos made by fans. TheIntroDB - where intros and credits are '
        '(Skip button); SkipDB stands in for it and TVmaze for the next episode, both without a key. '
        'Gemini - AI subtitles. Keys are free from each service\'s website.',
        'A TMDb key is recommended for much more than pictures: a film\'s release badge (In cinemas or '
        'Released once it is out digitally or on Blu-ray), the Digital release filter, details and trailers '
        'for titles your metadata add-on only knows by their TMDb ID, and More like this. Without it a film '
        'shows only Released or Coming by its release date, and the Digital release filter lets everything play.',
        '',
        _h('Check the tracking connections'),
        'Help & diagnostics > Diagnostics: checks that every connected service answers and syncs.',
    ))),
    ('addons', 'Add-ons', '\n'.join((
        _h('Where films come from'),
        'MegaNexus plays what your add-ons find - the same add-ons as the Nuvio and Stremio apps. '
        'Each add-on is a link to its manifest (it ends in manifest.json). There are four kinds:',
        '  - Metadata: catalogs, posters, descriptions (the MegaNexus Catalog is built in - its language and region in Settings › Metadata add-ons; AIOMetadata, TMDB add-ons...).',
        '  - Streams: the links that play (Torrentio, Comet, MediaFusion, AIOStreams...).',
        '  - Subtitles: OpenSubtitles and other subtitle add-ons.',
        '  - Sport: live events and their streams.',
        '',
        _h('Adding an add-on'),
        '1. Open the add-on\'s Configure page in a browser (for example torrentio.strem.fun/configure, or the '
        'Configure link on the add-on\'s website).',
        '2. Choose its options - languages, quality, and your debrid service with its API key.',
        '3. Copy the installed link (the manifest URL).',
        '4. HUB Settings > Add-ons > Your add-ons > Add a configured add-on link - or paste it on '
        'the phone page (Add-ons tab).',
        'Already using Nuvio or Stremio? HUB Settings > Add-ons > Import add-ons from Nuvio / Stremio brings '
        'all of them over at once.',
    ))),
    ('usenet', 'Debrid & Usenet', '\n'.join((
        _h('Debrid'),
        'A debrid service (TorBox, Real-Debrid, Premiumize, AllDebrid...) turns torrent results into fast '
        'direct links. Its key goes into the stream add-on\'s Configure page. TorBox, Premiumize and Offcloud '
        'can also be used without an add-on: HUB Settings > Debrid & Usenet > Debrid & Prowlarr (with your own Prowlarr\'s '
        'torrent indexers too); their keys can be typed on the phone setup page. "Debrid: cached (instant) results '
        'first" puts links that start at once at the top. Usenet (Easynews, your provider and indexers): '
        'HUB Settings > Debrid & Usenet > Usenet - below.',
        '',
        _h('What you need'),
        'Usenet is a paid network of servers that keep releases. Two things are needed:',
        '  - a Usenet provider - the account films are read from (Eweka, Newshosting, Frugal Usenet, Easynews...);',
        '  - something that searches it - an indexer (NZBgeek, DrunkenSlug, NZBFinder...). MegaNexus asks your '
        'indexers itself (below), or a stream add-on does (for example Usenet Streamer).',
        'Easynews is built in as well (its own search).',
        '',
        _h('The simplest way: Easynews'),
        '1. HUB Settings > API keys > Easynews: type username:password (or on the phone page, API keys).',
        '2. HUB Settings > Debrid & Usenet > Usenet > Easynews: type the login there (or on the phone page) - its streams are on.',
        'Its sources appear as "[EN+] Easynews" next to your add-ons\' sources. No add-on and no Usenet server needed.',
        '',
        _h('Usenet Streamer and other Usenet add-ons'),
        'Usenet Streamer runs on your own server (Docker) with Prowlarr / NZBHydra or Newznab indexers; set it up in '
        'its own dashboard, then add its manifest link like any add-on (see "Add-ons") and switch it '
        'ON in Stream add-ons. It has two modes:',
        '  - NZBDav mode: it gives ordinary links - they play like any other source.',
        '  - Native mode: it gives NZB sources (a link to the NZB + the Usenet servers). MegaNexus plays them with its '
        'own Usenet player. Enter your provider in its dashboard (NNTP) so it sends the servers, or add your Usenet '
        'server in MegaNexus (below).',
        'MegaNexus asks every add-on for the title you open by the ID it understands best (IMDb when it takes it), so '
        'it searches exactly that film or episode.',
        '',
        _h('Adding your Usenet server'),
        '1. HUB Settings > Debrid & Usenet > Usenet > Usenet server.',
        '2. Address: only the server name, for example news.provider.com (Easynews: news.eu.easynews.com). A special '
        'port goes after a colon: news.provider.com:443. Do not type https:// or nntps://.',
        '3. Username and password: the Usenet (NNTP) login from your provider - often not the website login.',
        '4. Connections: how many your plan allows (MegaNexus uses up to 12).',
        'MegaNexus finds the port and SSL by itself (563 or 443 with SSL, else 119) and tests the login: "Login works". '
        'On the phone page (API keys): username:password@news.provider.com.',
        'Your server is also the backup when a source\'s own server lacks part of a film.',
        '',
        _h('Your own indexers (Newznab)'),
        'With your Usenet server set, MegaNexus searches your indexers straight from this box - with your API keys, '
        'no add-on and no server in between.',
        '1. HUB Settings > Debrid & Usenet > Usenet > Newznab indexers > Add an indexer.',
        '2. Pick your indexer from the list (NZBgeek, DrunkenSlug, NZBFinder, NzbPlanet...) and type only its API key - '
        'the list says where it is (usually the indexer\'s profile page). With a TorBox key in API keys, TorBox Search '
        'is added without typing anything. Another indexer (or a Prowlarr / NZBHydra link): its address and key.',
        'MegaNexus tests the key at once; add as many indexers as you like. On the phone page (API keys): the '
        'indexer\'s name and key, several separated by commas - nzbgeek KEY, drunkenslug KEY.',
        'A film is searched by its IMDb ID, an episode by IMDb ID, season and episode (by its name where the indexer '
        'takes no IMDb ID for series). The sources appear as "[NZB] indexer name"; each answer is kept 6 hours to '
        'spare your daily API calls. Passworded posts and samples are left out.',
        'Within your limits: MegaNexus counts each indexer\'s searches and NZB downloads a day and uses its own '
        'limits when it reports them (else at most 200 searches a day), stops at 90 %, and an indexer that says '
        '"limit reached" rests until the next day - no account gets suspended for asking too much. It only asks '
        'when you open a title\'s sources, never in the background; each answer is kept 6 hours. Indexers > '
        'Newznab indexers shows how many searches each made today.',
        'Before an NZB plays, a few parts through the film are checked on your Usenet server (over the connections '
        'the player opens anyway). A release whose parts are mostly gone is not played - Autoplay goes on to the next source.',
        _h('Spotnet: an index built on this box'),
        'With only your Usenet provider - no indexer account - MegaNexus can build its own index of films and '
        'series from Spotnet, an index that lives on Usenet itself (the free.pt group). HUB Settings > Debrid & Usenet > Usenet > '
        'Spotnet: the first time about a month of the newest spots is read (a few minutes), then the new ones every '
        '6 hours while nothing plays. Its releases appear as "[SPOT] Spotnet" next to your indexers\' and add-ons\'; '
        'only proven spots are kept, never erotica. Its releases are mostly European. Switch it off there at any time.',
        '',
        'Quickest start: HUB Settings > Debrid & Usenet > Usenet > Set up Usenet - your provider first, then your indexers from the list.',
        '',
        _h('The fast Usenet player'),
        'Big releases and 4K need speed, so MegaNexus has two faster ways to read Usenet, both automatic:',
        '  - on CoreELEC, LibreELEC and Linux, the reading runs in its own process on all the processor\'s cores '
        '(it starts about a minute after Kodi; until then the usual player plays);',
        '  - a native player (vfs.meganexus) that MegaNexus installs by itself for your system - Android, '
        'CoreELEC / Linux and Windows, Kodi 21 and 22 - never while a film plays.',
        'Stop leaves a Usenet film at once with either of them. Nothing to set up; without them films play as before.',
        '',
        _h('What plays'),
        'Plain video files and films stored in RAR volumes (also with scrambled names) play and can be fast-forwarded. '
        'Compressed, encrypted or 7z releases can not be streamed - MegaNexus says so; choose another source. A small '
        'missing piece is a short glitch, not a stop.',
        '',
        _h('Choosing and waiting'),
        'Choose streams manually shows every add-on in its own tab. A slow add-on (Usenet searches take time) joins '
        'the open list when it answers - the title shows "Searching: <add-on>" for up to a minute. Its answer is kept '
        'for 30 minutes, so the next time - Autoplay too - its sources are there at once.',
        '',
        _h('When it does not work'),
        '"needs a Usenet server" - add your Usenet server (above). "address ... not found" - check the spelling. '
        '"login refused" - check the username and password. "no Usenet server answered" - type the port after the '
        'address. No Usenet sources at all - check that the add-on is ON in Stream add-ons and that its indexers work '
        'in its own dashboard.',
    ))),
    ('home', 'Home & library', '\n'.join((
        _h('Home & appearance'),
        'Use MegaNexus skin - the HUB look; Kodi\'s own screens follow the theme too.',
        'Layout & cards - Home layout (MegaNexus collections or MegaNexus rows), portrait posters or landscape '
        'cards, and how see-through the posters are.',
        'Home content & titles - the big title area (hero), card titles, ratings, row titles, animated art.',
        'Artwork - where posters, backgrounds, title logos and landscape cards come from: the catalog, TMDB '
        'or Fanart.tv (needs its key), and their language (English, Kodi\'s language, or without text). A title '
        'the provider has no picture for keeps the catalog\'s.',
        '',
        _h('Collections & Home rows'),
        'Which collections and catalogs are rows on Home, their order and names.',
        'Hide unreleased titles - films and series whose release date lies ahead stay out of Home, collections '
        'and search, and episodes not aired yet out of a series\' episode list.',
        '',
        _h('Local & network storage'),
        'On the first page of HUB Settings.',
        'Local storage - folders on a USB disk, NAS or SMB/NFS share. Add the folder (Kodi opens Videos > '
        'Files > Add videos); MegaNexus reads it itself and shows Local Movies and Local Series on Home and '
        'in the Library. Names like "Title (2019)" and "Show/Season 1/Show S01E02" work best.',
        'Plex, Jellyfin, Emby - sign in to your server; its Continue watching and Recently added appear on '
        'Home and in the Library, and its copy of a title is offered as a source.',
        '',
        _h('Continue Watching'),
        'How far back it shows titles, unaired next episodes, refresh interval, and "start with the last '
        'link" (resume with the same source within 12 or 24 hours).',
        '',
        _h('Library'),
        'One Library: every title you saved - on this device (Title options > Add to Library), in your Nuvio '
        'account and on Trakt, Simkl, MDBList and WeTrakr - once, with the marks of every place it is in and the '
        'day it was added. One row at the top: the places with how many titles each holds (choose one to see '
        'only its titles), the filter (All, Movies, Series, Anime), the order (the arrows: recently added, '
        'A-Z, year) and the gear: the view (rows, poster grid, wide cards, list) and the titles under the '
        'cards. It always opens on everything. This device\'s files and your media servers have their own rows '
        'on Home.',
    ))),
    ('playback', 'Playback & subtitles', '\n'.join((
        _h('Playback'),
        'Autoplay the best stream - starts the first matching link without the source list.',
        'Digital release filter - a film only in cinemas, or an episode not aired yet, is not searched or played '
        '(also a manual search and Continue Watching); it tells you when it comes out. Films over a year old '
        'always play. Uses TMDb\'s release dates (digital, Blu-ray, TV) - needs a TMDb key for films.',
        'Continue Watching · start with the last link - reuse the source you used last time.',
        'Automatic stream choice - what "best" means: highest resolution, HDR, Dolby Vision, cached only...',
        'Intro, credits & next episode - Skip button or automatic skipping (times from TheIntroDB, your '
        'Plex / Jellyfin / Emby server and the file\'s chapters); "Next episode" appears beside "Skip outro", '
        'or from the point an episode counts as watched when the credits are unknown.',
        '',
        _h('Subtitles'),
        'Subtitle language, subtitles on video start, subtitle add-ons and Autosync subtitle offset (on by default).',
        'Subtitles come from your subtitle add-ons (their manifests, AIOStreams...), never Kodi\'s own subtitle '
        'service. When a release cannot be downloaded (its server is off or answers with an error), the next '
        'release of the same language is taken; in the list a failed version is marked with ✕.',
        _h('Autosync subtitle'),
        'A subtitle made for another release of the film starts early or late, or drifts away over the film. '
        'The Autosync subtitle button in the player (beside Offset) fixes that in a few seconds, without AI: it '
        'compares the subtitle on screen with the other subtitles of the same title from your subtitle add-ons, '
        'in any language (people speak at the same moments in every language), finds the shift and the speed '
        'difference most of them agree on, and loads the corrected subtitle at once. When they do not agree, '
        'nothing changes - then choose another version. Turn it off with Playback & subtitles > Subtitles > Autosync subtitle offset.',
        '',
        _h('Trailers'),
        'Automatic trailers on Home and the title page, their source, quality, delay and length.',
        '',
        _h('Stream badges'),
        'The pictures in the source list (4K, HDR, Dolby Vision, Atmos...). Import Nuvio badge JSON links or a '
        'file from the badge builder; preview a stream name on the phone page.',
    ))),
    ('player', 'The player', '\n'.join((
        'OK during a video opens the player bar. Buttons from the left:',
        '  Pause / Play · Sources (pause and choose another source, it carries on from the same minute) · '
        'Subtitles (search all subtitle add-ons) · Offset (subtitle delay) · Autosync subtitle · Audio · '
        'Info · Stats - and Settings at the right end.',
        'The seek line: Left / Right step back and forward; the line shows where you will land and the video '
        'jumps once you stop pressing. OK on the line pauses.',
        'Next episode and Skip intro / outro appear at the bottom right when they apply.',
        'The player bar hides after 5 seconds without a key press - not while the film is paused, and not while '
        'a menu opened from it (subtitles, audio, sources, offset, settings, info...) is still open.',
        '',
        _h('As a film starts'),
        'For six seconds, top left: the mode your screen is in (Dolby Vision, HDR or SDR), the age rating and '
        'IMDb\'s parents guide - sex & nudity, violence, language, alcohol & drugs, frightening scenes. On or off: '
        'HUB Settings > Playback & subtitles > Playback > Age rating & content warnings at the start.',
        '',
        _h('Info'),
        'The Info key, or the Info button in the player bar, in every player (films, IPTV, Sport): a panel slides up '
        'with the title\'s logo and its description - a channel\'s programme and a stream\'s description when there '
        'is one. It goes by itself after 10 seconds; Info or Back closes it at once. On the Subtitles button the line '
        'under the buttons names the subtitle on screen in full.',
        '',
        _h('AI subtitles'),
        'The AI button in the player (a free Gemini key: HUB Settings > API keys). When the video has its own '
        'subtitle in your language, the button turns that on - nothing is translated. Otherwise the video\'s own '
        'subtitle (else the one on screen, else one from online) is translated in the background, from where you '
        'are watching, and switches on as it comes. Sound descriptions such as [Thunder crashing] are left out; '
        'every line keeps the time of the original. A finished translation is kept for the next time.',
        '',
        _h('Home while a film plays'),
        'The house button (beside Settings) takes you back to where you started the film; it keeps playing. '
        '"Now playing" at the top of MegaNexus Home and on the HUB brings it back to full screen. Back from the '
        'player stops the film as before.',
        '',
        _h('Starting a film'),
        'The loading screen shows the title\'s picture and its logo filling up. Back and Esc wait while a chosen '
        'source starts (after 25 seconds a source that does not open can be left). Searching subtitles or sources '
        'during a film shows a small pill at the bottom - the film stays in view.',
        'Colours glaring when an HDR film starts or ends? Kodi Settings > System > Display > "Adjust display HDR '
        'mode" switches the screen into HDR; where the interface cannot be drawn in HDR (some Linux desktops), '
        'turn it off and Kodi converts HDR films itself.',
    ))),
    ('party', 'Watch Party', '\n'.join((
        _h('Watch together'),
        'Watch a film at the same time as friends on their own TVs, with messages and a phone remote. There is no '
        'account and no MegaNexus server: the TVs talk through public relays, and everything is encrypted.',
        'Open it with the round button at the top of Home, next to HUB. In a party, the button shows how many '
        'people are in it; a dot means an invite, a friend request, a new message or someone waiting to come in.',
        '',
        _h('Start a party'),
        '1. Watch Party > Start a party.',
        '2. Invite a friend (Invite a friend), or give others a join code (Join code - it works for 10 minutes; you '
        'let each person in).',
        '3. Play a film as usual. It starts on every TV in the party.',
        '',
        _h('Join one'),
        'An invite from a friend shows on Home and in Watch Party - select it. With a join code: Watch Party > Join '
        'with a code, and the host lets you in.',
        '',
        _h('How the film plays on every TV'),
        'Each TV plays the film from its own stream add-ons - the same release when it has it. The host\'s film waits '
        'until everyone\'s has started, then all play together. Pause, play and jumps by the host happen on every '
        'TV; between them each TV plays at its own pace, so a few seconds apart is normal. A guest\'s phone can pause '
        'and jump too - the host\'s TV does it for everyone.',
        'A guest needs a stream add-on of its own - or the host shares the film: "Share my stream" (Watch Party '
        'settings, with TorBox on the host\'s TV) gives guests without the film the host\'s TorBox link to it. That '
        'link has the host\'s TorBox key in it - a guest could find it in their Kodi log; MegaNexus never keeps it in '
        'the guest\'s settings or history. Share only with people you trust.',
        'If a guest is watching something else when the host starts a film, it is not cut off: Watch Party > '
        'Watching plays the party\'s film when the guest is ready.',
        '',
        _h('The phone remote'),
        'Watch Party > Phone remote: scan the QR code (same Wi-Fi). The page shows the film, pause / play, jumps of '
        '10 and 30 seconds, a slider, who is in, the messages and your friends. Add it to the phone\'s home screen '
        '(iPhone: Share > Add to Home Screen; Android: browser menu > Add to Home screen) - its link stays the same. '
        'To keep it working for good, give the TV a fixed address in your router. Watch Party settings > New phone '
        'link makes the old link stop working.',
        'On a computer with a firewall, allow Kodi (port 8095) for the home network, or the phone cannot reach it.',
        '',
        _h('Messages'),
        'Messages written on the phone show on every TV: bottom right in the player, one pill each, for a few '
        'seconds; and under the Watch Party button on Home. Turn them off in Watch Party settings > Messages in the player.',
        '',
        _h('Friends'),
        'Watch Party > Friends: everyone has a friend code (Watch Party settings). Add a friend by code, or by name '
        'when they chose "Friends can find me by name". Both TVs show the same check code - compare it once. A green '
        'dot shows who is online; select a friend to read and write messages (they reach their TV and phone). '
        '"Remove friend" is at the bottom, or hold OK on a name.',
        '',
        _h('When a party ends'),
        'The host ends it with End the party - and it also ends when the host\'s TV goes to standby, restarts or '
        'is gone for a minute and a half. After a restart no party is kept.',
        '',
        _h('Watch Party settings'),
        'HUB Settings > Watch Party: Watch Party on this TV, Friends can find me by name, Messages in the player, '
        'Share my stream, your friend code and New phone link.',
    ))),
    ('downloads', 'Downloads', '\n'.join((
        _h('Keep a film or an episode on this device'),
        '1. HUB Settings > Downloads > Download folder: a folder on this device, a USB disk or a network share.',
        '2. In the source list, hold OK on a source (or press the menu key) and choose Download. The list stays '
        'open, so you can still play something.',
        '3. A small blue ring by the clock fills as it downloads. Select it (Right from the top buttons of '
        'MegaNexus Home, Up on the HUB) for the box with size, speed and time left: "Close · continue" or "Stop".',
        '',
        _h('Nothing stops it'),
        'The download runs in the background - the screensaver, a film or closing MegaNexus do not stop it. When '
        'the internet drops it waits and carries on from where it was. Into a folder on this device it also '
        'carries on after Kodi restarts; on a network share that file starts again.',
        '',
        _h('What can be downloaded'),
        'Direct links (debrid services: TorBox, Real-Debrid...). Torrents, live streams (HLS) and add-on links '
        'cannot be. A debrid link can expire after some hours - then start the download again from the sources.',
        'HUB Settings > Downloads lists every download: select one to see where it was saved, or to remove it.',
    ))),
    ('livetv', 'Live TV, IPTV & Sport', '\n'.join((
        _h('IPTV'),
        'Set up IPTV with an Xtream account (server, username, password) or an M3U playlist with an XMLTV '
        'guide. Channels load in the background when Kodi starts. In IPTV Channels: categories on the left, '
        'OK plays a preview, OK again full screen; the guide shows past programmes when the playlist offers '
        'catch-up. Pause / rewind (timeshift) can freeze Kodi on some boxes.',
        '',
        _h('IPTV lists'),
        'Add as many M3U or Xtream lists as you like (Live TV, IPTV & Sport > IPTV lists). Each has its own '
        'switches: Live TV (its channels in the TV list), IPTV VOD (its films and series as a source) and '
        'Groups; a list can be renamed or removed.',
        'Only live TV in the channel list (on by default): films and series of a list never load as channels - '
        'they are recognised by what the playlist itself says (media marks, a movie / series type, a link to a '
        'video file or a film / series path), never by group names. Less memory and a faster start.',
        'Groups (the button next to Refresh guide): switch channel groups such as countries on or off. '
        'Switched-off groups are not loaded at all.',
        'IPTV VOD: while IPTV is set up, the films and series of your lists show in a title\'s source list next '
        'to the stream add-ons. Nothing loads in advance - a small index on the device is searched by the '
        'title\'s English name and year (or season and episode).',
        '',
        _h('Sport'),
        'Sport add-ons list live events; resting on an event for five seconds can start it.',
    ))),
    ('youtube', 'YouTube', '\n'.join((
        _h('Opening it'),
        'On the HUB press Down from the tiles: the apps rise. YouTube opens MegaNexus\' own screen - its '
        'categories in rows, Search, and at the bottom of Home your channels in circles (OK opens a channel). '
        'Back never leaves the app; the HUB button at the top does.',
        '',
        _h('Playing'),
        'OK plays a video small at the top - its title, channel, LIVE, length, views and age beside it; it plays '
        'on while you browse. OK on it again - or the round play beside HUB - opens Kodi\'s player; Back comes '
        'down to the small one. In the player: Up next, Previous / Next video and Autoplay.',
        'A card\'s options (the menu key) open its channel, add it to your channels or take it out.',
        '',
        _h('Setting it up'),
        'HUB Settings > YouTube (also the Apps tab of the phone page):',
        '  - Autoplay · the next video by itself - off until you switch it on.',
        '  - Steady playback · 360p, seeking works - the one stream YouTube still serves whole.',
        '  - Your channels - add (search a name) or remove.',
        '  - YouTube add-on · quality, sign-in - Kodi\'s YouTube add-on\'s own settings.',
        '',
        _h('Good to know'),
        'Videos play through Kodi\'s YouTube add-on: the app installs it, and asks its first-start questions, '
        'before it opens the first time. Without a sign-in YouTube can send a stream whose sound starts a few '
        'seconds after the picture and which stops on a long jump - that is the add-on and YouTube, not '
        'MegaNexus; signing in to the add-on can help. Nothing of YouTube is kept once the app closes, except '
        'your channels.',
    ))),
    ('music', 'Music', '\n'.join((
        _h('Opening it'),
        'On the HUB press Down from the tiles and choose Music. The first time it asks which artists you follow '
        '(by genre) - Home is made from them: Recently played, Your playlists, For you, Your artists, New from '
        'your artists, Artists like yours and the charts. At the top: Library, Search, Settings and HUB. Back '
        'never leaves the app; the HUB button does.',
        '',
        _h('Playing'),
        'OK on a song plays it and the songs after it; an album or a playlist opens its page, an artist its albums, '
        'singles and popular songs. When the queue ends, songs like the last one follow - the music does not stop. '
        'One song fades into the next.',
        'The music plays on through the whole of MegaNexus and under the screensaver. A film, a trailer or a YouTube '
        'video pauses it and keeps its place; Play goes on from the same second.',
        'The menu key on a card: follow or unfollow an artist, take an imported playlist out.',
        '',
        _h('The small player and Now playing'),
        'While a song plays its icon stands beside your profile, a ring filling as it goes. Right from any screen\'s '
        'top bar - on the HUB, Up from the tiles - and OK: the small player with Previous, Play / Pause, Next, '
        'Shuffle, Repeat, a bar to seek and Stop. The round play beside HUB in the app opens Now playing: the '
        'song\'s picture over the whole screen and the same buttons. "Playing from" says where the song comes from.',
        '',
        _h('Setting it up'),
        'HUB Settings > Music (or Settings in the app; the Apps tab of the phone page does the same):',
        '  - Add a music source - an Eclipse music add-on: set it up on its own page, copy its install link (it ends '
        'with manifest.json) and paste it, or add it from the phone. MegaNexus brings no sources of its own and '
        'never runs their code; an encrypted one is skipped.',
        '  - Import a playlist - a Spotify (with your Spotify app in API keys), Deezer or YouTube share link, or a '
        'CSV (Exportify, TuneMyMusic, Soundiiz) / M3U file. It shows on the app\'s Home.',
        '  - Artists you follow - choose again by genre.',
        '  - YouTube · when no source has a song - the song from the artist\'s own channel, same title and length, '
        'never an almost-the-same one.',
        '  - Your debrid cloud - the music files in your TorBox or Real-Debrid (your existing keys).',
        '  - Songs play from - the order: your sources, your cloud, YouTube.',
        '  - Catalogues - what Home shows and Search finds: Deezer, Apple Music, or Spotify with your own Spotify app.',
        '  - Deezer profile - your public Deezer profile\'s favourites and playlists.',
        '  - Add a music folder - your own music on the TV or the network.',
        '',
        _h('Yours alone'),
        'Each profile has its own songs: what it played, the artists it follows and its playlists - nobody else '
        'sees them. Source links can hold a key: they are kept on this device as Kodi keeps its settings (Kodi has '
        'no safe), never shown or written to the log.',
    ))),
    ('themes', 'Themes & screensaver', '\n'.join((
        'HUB - MegaNexus, IPTV, Sport and the settings as glass pills in the theme\'s colours; above them "Trending now on TMDB", a large '
        'picture that changes every 10 seconds (needs a TMDb key; Home & appearance switches it off).',
        'Screensaver studio - "Trending now on TMDB" (on by default when a TMDb key is set). The screensaver '
        'opens without any darkening. Kodi has one screensaver at a time: with the MegaNexus screensaver off, '
        'Screensaver > "With the MegaNexus screensaver off" chooses Kodi\'s Dim or nothing.',
        'Theme - Light, Dark, Dim, or a custom theme from your own background.',
        'Wallpaper - the background of Home, catalogs, Live TV, Sport and the HUB.',
        'Interface colours - match the background, variation and strength; or your own colour for each '
        'part: accent, background, panels, pills, selection and text (swatches or a hex code).',
        'Screensaver - when it starts, its background (pictures, your posters or a video), clock and widgets.',
        'Clock & weather - on every MegaNexus screen, and the weather location.',
    ))),
    ('performance', 'Performance & image cache', '\n'.join((
        'Memory - MegaNexus gives freed memory back to the system after you leave it, after a video and while '
        'the remote rests. Memory used during a film (the video decoder) comes back when it ends.',
        'Memory for posters and catalogs - how much RAM pictures may use (more = faster scrolling).',
        'Prepare posters and ratings when MegaNexus opens - every time, the opening screen stays until Kodi '
        'keeps 90 % of the posters of Home and of every collection\'s first page (pictures that cannot load '
        'do not count; Back skips - a first setup runs until then, the day\'s new posters at most a minute), and fetches their MDBList ratings in a few requests '
        '(at most 60 % of your daily MDBList requests - the rest stays for titles you open). When everything '
        'is there, Home opens at once.',
        'Cache usage - the posters Kodi keeps on the device and MegaNexus\'s image memory.',
        'Clear MegaNexus images and metadata cache - when pictures look wrong or old.',
        'System check and the Diagnostics overlay (CPU, RAM, FPS, video / audio format) are in '
        'Help & diagnostics > Diagnostics.',
    ))),
    ('backup', 'Backup & updates', '\n'.join((
        'Backup & restore - save all settings, keys and add-ons to a file, restore them on another device.',
        'Updates - check for updates (automatic updates from GitHub), run set-up again, reset '
        'MegaNexus, or remove the MegaNexus build.',
    ))),
    ('trouble', 'When something does not work', '\n'.join((
        _h('No sources'),
        'Check the stream add-ons (HUB Settings > Add-ons) and their debrid key; a source that freezes - try '
        'another from the list, or turn on "Debrid: cached results first".',
        _h('Nothing on Home'),
        'Sign in to Nuvio or add a metadata add-on; Collections & Home rows decides what shows.',
        _h('Live TV empty'),
        'IPTV setup: check the playlist link; channels load about half a minute after Kodi starts.',
        _h('Video judders'),
        'Kodi Settings > Player > Adjust display refresh rate: "On start / stop". MegaNexus gives it back '
        'before every film even while a trailer plays.',
        _h('Search finds nothing'),
        'Search uses the search catalogs of your metadata add-ons (AIOMetadata, the MegaNexus Catalog...). Check that one is '
        'switched on in HUB Settings > Add-ons > Metadata.',
        _h('After an update'),
        'Restart Kodi once and give the interface a moment: MegaNexus, its interface, skin and screensaver must all '
        'show the same version (HUB Settings > Help & diagnostics > Diagnostics > System check). Settings that do '
        'not stay after a Kodi 22 test build: update and restart Kodi once, then enter them again.',
        _h('Trailers repeat their first seconds'),
        'A Kodi audio setting, not MegaNexus: Kodi Settings > System > Audio > Sync - choose a less aggressive '
        'option than "All" (CoreELEC builds).',
        _h('HDR / Dolby Vision films stutter, the screen goes black between modes'),
        'Kodi Settings > Player > Videos > Adjust display refresh rate, and Kodi Settings > System > Display > HDR. '
        'MegaNexus switches the refresh rate only for films and episodes in the main player, never for trailers, '
        'IPTV or Sport; on Windows with HDR it keeps the display in HDR for SDR trailers.',
        _h('A wrong title in the Library'),
        'Hold OK on it: Remove from Library.',
        _h('Nuvio stopped syncing'),
        'HUB Settings > Accounts & tracking > Nuvio: sign in once more - MegaNexus then signs in again by itself.',
        _h('Kodi slow overall'),
        'Other Kodi video add-ons are not needed by MegaNexus and slow Kodi down - System check lists them.',
        _h('Still stuck'),
        'Help & diagnostics > Diagnostics: the tracking connections and the System check.',
        _h('Report a problem'),
        'Help & diagnostics > Report a problem: scan the QR code, describe what happened on the phone and send it. '
        'It reaches the MegaNexus developer as a GitHub issue together with the end of the Kodi log - add-on '
        'configurations, links, log-ins, keys and e-mail addresses are removed first. The report is public; '
        'three reports a day per device.',
    ))),
    ('whatsnew', 'What is new, and what is missing', '\n'.join((
        _h('New in 9.0.6'),
        'Apps on the HUB: YouTube and Music - a whole music app (see "Music"), Plex, Jellyfin and Emby to come.',
        'The HUB: new tiles in your theme\'s colours, IPTV is now Channels; the apps row stands still, the music by '
        'your profile is reached with Up from the tiles.',
        'Collections: choose what Home shows - your collections, the MegaNexus Catalog or one add-on\'s catalogs - on '
        'the phone (Collections) or HUB Settings > Collections & Home rows > Home shows. Your own are kept aside.',
        'Every add-on that offers metadata or catalogs is used: search, Browse all, trailers and Next episode no '
        'longer ask one add-on by name; a new add-on is switched on at once.',
        'Fixed: a show saved under two ids (IMDb, TMDB, TVDB) - removed from Continue Watching it stays removed, one '
        'Next episode card; your Home layout is no longer replaced after a restart (GitHub #31, #32).',
        '',
        _h('New in 9.0.5'),
        'AI subtitles: the video\'s own subtitle in your language is turned on when it has one; a translation '
        'keeps every line on its own time, has no [sound descriptions] and covers the whole film.',
        'Library: one screen - every saved title once, the places at the top as filters, the day it was added '
        'on each card; it no longer flashes or moves the cursor when you come back from a film.',
        'Search: the add-ons\' results show at once, your chosen pictures follow into the same cards.',
        'Subtitles: Hebrew and Arabic ones no longer come garbled. Next episode never at an episode\'s start; '
        'the player\'s Home button keeps the film playing, Now playing takes you back to it.',
        '',
        _h('New in 9.0.4'),
        'Player: the screen\'s mode, age rating and parents guide as a film starts; Info in every player with the '
        'logo and the description; the subtitle\'s full name on the Subtitles button.',
        'Home: past 12 rows Home goes round - no page turns; with Browse all off Right never stops.',
        'Metadata: the MegaNexus Catalog in place of Cinemeta, in your language and region; a row your region '
        'leaves empty (Prime Video) comes in English.',
        'Phone: Quick setup · Free streams (MegaNexus with PenguPlay, its own sign-in) beside the debrid setup.',
        'IPTV and Sport: no Kodi banner on a channel switch, the start time of every event in your time.',
        'Fixed: Kodi could stand still on waking from the screensaver; rating posters from your add-ons '
        '(BetterPosters, RPDB...) show again; PenguPlay\'s sport posters.',
        '',
        _h('Dimming and the MegaNexus screensaver'),
        'Kodi runs one screensaver at a time. While the MegaNexus screensaver is on, Kodi\'s own "Dim" cannot run '
        'as well - that is Kodi, not a fault. With the MegaNexus screensaver off, Screensaver > "With the MegaNexus '
        'screensaver off" chooses Kodi\'s Dim or nothing.',
        '',
        _h('Not there yet'),
        'IPTV VOD finds a title by its English name: a list that uses translated names finds fewer.',
        'Live TV without Kodi\'s TV part (channels straight from MegaNexus) - only if Kodi\'s TV part still '
        'costs much memory with live TV only.',
        'The phone setup page does not list IPTV lists and groups yet - use the TV.',
    ))),
)
