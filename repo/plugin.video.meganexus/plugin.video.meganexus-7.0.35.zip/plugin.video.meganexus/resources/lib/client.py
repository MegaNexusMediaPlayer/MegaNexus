# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Backward-compat shim. Real implementation lives in meganexus.client."""
from meganexus.client import *  # noqa: F401,F403
