# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The users' own API keys (7.0): one list for HUB Settings and the phone
setup page. Keys are stored in MegaNexus settings, never sent back to the
phone (only whether one is set) and never written to the log."""
from collections import OrderedDict

KEYS = OrderedDict([
    ('tmdb', {'setting': 'tmdb_api_key', 'name': 'TMDb',
              'purpose': 'TMDB collections (networks, companies, lists) and actor search',
              'url': 'https://www.themoviedb.org/settings/api', 'min': 16}),
    ('mdblist', {'setting': 'mdblist_api_key', 'name': 'MDBList',
                 'purpose': 'MDBList lists and ratings',
                 'url': 'https://mdblist.com/preferences/', 'min': 10}),
    ('fanarttv', {'setting': 'fanarttv_api_key', 'name': 'Fanart.tv',
                  'purpose': 'more and newer logos and backgrounds (personal key)',
                  'url': 'https://fanart.tv/get-an-api-key/', 'min': 16}),
    ('introdb', {'setting': 'meganexus_introdb_key', 'name': 'TheIntroDB',
                 'purpose': 'skip intro / recap / credits timings',
                 'url': 'https://theintrodb.org/', 'min': 8}),
    # 7.0.12: a debrid service built in - streams without a stream add-on.
    ('torbox', {'setting': 'torbox_api_key', 'name': 'TorBox',
                'purpose': 'streams straight from your TorBox account (no add-on needed)',
                'url': 'https://torbox.app/settings', 'min': 20}),
    ('premiumize', {'setting': 'premiumize_api_key', 'name': 'Premiumize',
                    'purpose': 'streams straight from your Premiumize account (no add-on needed)',
                    'url': 'https://www.premiumize.me/account', 'min': 10}),
])


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_cache import cached_addon
    return cached_addon()


def status(addon=None):
    """[{'id', 'name', 'purpose', 'url', 'set'}] - no key values."""
    addon = _addon(addon)
    return [{'id': key, 'name': row['name'], 'purpose': row['purpose'], 'url': row['url'],
             'set': bool((addon.getSetting(row['setting']) or '').strip())} for key, row in KEYS.items()]


def save(key, value, addon=None):
    """Store (or with an empty value, remove) one key."""
    if key not in KEYS:
        raise ValueError('Unknown API key.')
    row = KEYS[key]
    value = str(value or '').strip()
    if value and (len(value) < row['min'] or any(ch.isspace() for ch in value)):
        raise ValueError('That does not look like a %s API key. Copy it again from %s.' % (row['name'], row['url']))
    addon = _addon(addon)
    addon.setSetting(row['setting'], value)
    try:
        from . import settings_cache
        settings_cache.invalidate()
    except Exception:
        pass
    return {}
