# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from .api import (
    add_provider_from_url,
    list_providers,
    get_provider,
    remove_provider,
    search_catalogs,
    fetch_provider_catalog,
    get_best_meta,
    get_stream_results,
)
