# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Screensaver tab of the phone page (7.0.25).

From the phone: pictures (edited in the phone's browser and sent as a
1920 x 1080 JPEG) and one video (up to 100 MB) for the screensaver, the
background choice (MegaNexus, animated, one picture, a slideshow of the
pictures, the video), the MegaNexus Ambient widgets (style, colour,
position, text - the same scene as the TV's studio) and "Show on TV".

Files go to the profile (addon_data/plugin.video.meganexus/screensaver/),
never anywhere the phone names: the server makes every file name, an
upload arrives in order in pieces of at most CHUNK_MAX bytes and is checked
(size, type by its first bytes) before it is kept. Runs inside the phone
page's service, i.e. in MegaNexus's own interpreter (meganexus_ui is there).
"""
import os
import re
import secrets
import shutil
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'plugin.video.meganexus'
FOLDER = 'special://profile/addon_data/plugin.video.meganexus/screensaver/'
MAX_FILE = 100 * 1024 * 1024        # the user's limit for phone uploads
CHUNK_MAX = 4 * 1024 * 1024
MAX_PICTURES = 40
SPARE = 50 * 1024 * 1024            # free space kept on the device
PICTURE_ID = re.compile(r'^[0-9a-f]{16}\.jpg$')
UPLOAD_ID = re.compile(r'^[0-9a-f]{16}$')
VIDEO_TYPES = {'.mp4': 'mp4', '.m4v': 'mp4', '.mov': 'mp4', '.mkv': 'mkv', '.webm': 'mkv'}
MEDIA_KINDS = ('meganexus', 'animated', 'picture', 'slideshow', 'video')
# QuickTime / MP4 boxes a file may start with (iPhone videos: 'ftyp', older QuickTime: 'wide', 'moov'...).
MP4_BOXES = (b'ftyp', b'moov', b'wide', b'free', b'mdat', b'skip')
_LOCK = threading.Lock()
# 7.0.25: results of finished uploads, so a piece sent again (its answer was
# lost on Wi-Fi, iOS paused the page) gets the same answer, not an error.
_FINISHED = {}


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


def root():
    return xbmcvfs.translatePath(FOLDER)


def pictures_dir():
    return os.path.join(root(), 'pictures')


def video_dir():
    return os.path.join(root(), 'video')


STILL = 'still.jpg'          # 7.0.29: a sharp frame of the video (up to 4K, made on the phone)


def still_path():
    from .wallpaper import sharp_path
    video=_video_path()
    return sharp_path(video) if video else os.path.join(video_dir(),STILL)


def _video_path():
    folder = video_dir()
    try:
        names = [n for n in os.listdir(folder) if n.startswith(('screensaver.','screensaver-')) and os.path.splitext(n)[1].lower() in VIDEO_TYPES]
    except OSError:
        return ''
    return os.path.join(folder, names[0]) if names else ''


def pictures():
    try:
        names = sorted((n for n in os.listdir(pictures_dir()) if PICTURE_ID.match(n)), reverse=True)
    except OSError:
        return []
    return names


def picture_file(picture_id):
    """The path of one of our pictures, or '' (only names we made)."""
    if not isinstance(picture_id, str) or not PICTURE_ID.match(picture_id):
        return ''
    path = os.path.join(pictures_dir(), picture_id)
    return path if os.path.isfile(path) else ''


def media_state(addon=None):
    """What the background is now, and the phone's files."""
    addon = addon or _addon()
    kind = addon.getSetting('meganexus_screensaver_type') or 'image'
    art = addon.getSetting('meganexus_screensaver_art')
    video = addon.getSetting('meganexus_screensaver_video')
    folder = addon.getSetting('meganexus_screensaver_folder')
    names = pictures()
    current, chosen = 'meganexus', ''
    if kind == 'animated':
        current = 'animated'
    elif kind == 'video':
        current = 'video' if video and video == _video_path() else 'other'
    elif kind == 'slideshow' and folder:
        current = 'slideshow' if os.path.normpath(xbmcvfs.translatePath(folder)) == os.path.normpath(pictures_dir()) else 'other'
    elif art:
        name = os.path.basename(art)
        if PICTURE_ID.match(name) and os.path.normpath(os.path.dirname(art)) == os.path.normpath(pictures_dir()):
            current, chosen = 'picture', name
        else:
            current = 'other'
    path = _video_path()
    return {'current': current, 'picture': chosen, 'pictures': names,
            'wallpaper': addon.getSetting('meganexus_wallpaper') == 'saver',
            'video': os.path.basename(path) if path else '', 'max_mb': MAX_FILE // (1024 * 1024),
            'still': bool(path and os.path.isfile(still_path())),
            'max_pictures': MAX_PICTURES}


def ambient_state():
    from meganexus_ui import ambient
    scene = ambient.load(_addon())
    return {'scene': scene,
            'designs': {name: [[k, label, w, h] for k, label, w, h in ambient.DESIGNS[name]] for name in ambient.WIDGETS},
            'colors': {k: '#' + v[2:] for k, v in ambient.COLORS.items()},
            'color_labels': ambient.COLOR_LABELS,
            'positions': list(ambient.POSITIONS), 'position_labels': ambient.POSITION_LABELS,
            'sizes': [[k, ambient.SIZE_LABELS[k], ambient.SIZE_SCALE[k]] for k in ambient.SIZES],
            'speeds': list(ambient.SPEEDS), 'margin': [ambient.MARGIN_X, ambient.MARGIN_Y, ambient.GAP],
            'media': media_state()}


def save_scene(scene):
    from meganexus_ui import ambient
    from . import settings_cache
    if not isinstance(scene, dict):
        raise ValueError('Nothing to save.')
    ambient.save(scene, _addon())
    settings_cache.invalidate()
    return {'scene': ambient.load(_addon())}


def set_media(kind, picture_id=''):
    from . import settings_cache
    addon = _addon()
    if kind not in MEDIA_KINDS:
        raise ValueError('Unknown background.')
    if kind in ('meganexus', 'animated'):
        addon.setSetting('meganexus_screensaver_art', '')
        addon.setSetting('meganexus_screensaver_video', '')
        addon.setSetting('meganexus_screensaver_type', 'image' if kind == 'meganexus' else 'animated')
    elif kind == 'picture':
        path = picture_file(picture_id) or (picture_file(pictures()[0]) if pictures() else '')
        if not path:
            raise ValueError('Add a picture first.')
        addon.setSetting('meganexus_screensaver_art', path)
        addon.setSetting('meganexus_screensaver_video', '')
        addon.setSetting('meganexus_screensaver_type', 'image')
    elif kind == 'slideshow':
        if not pictures():
            raise ValueError('Add pictures first.')
        addon.setSetting('meganexus_screensaver_folder', pictures_dir() + os.sep)
        addon.setSetting('meganexus_screensaver_art', '')
        addon.setSetting('meganexus_screensaver_type', 'slideshow')
    else:
        path = _video_path()
        if not path:
            raise ValueError('Add a video first.')
        addon.setSetting('meganexus_screensaver_video', path)
        addon.setSetting('meganexus_screensaver_art', '')
        addon.setSetting('meganexus_screensaver_type', 'video')
    settings_cache.invalidate()
    _wallpaper_sync(addon)
    return {'media': media_state(addon)}


def _wallpaper_sync(addon):
    """7.0.28: a wallpaper 'same as the screensaver' follows a new background."""
    try:
        from . import wallpaper
        wallpaper.sync(addon)
    except Exception:
        pass


def set_wallpaper(on):
    """The phone's "Also as Home and HUB wallpaper" switch."""
    from . import wallpaper
    addon = _addon()
    wallpaper.choose('saver' if on else 'off', addon=addon)
    return {'media': media_state(addon)}


def delete(item):
    """A picture by its id, or 'video'. A background using it falls back to MegaNexus."""
    addon = _addon()
    if item == 'video':
        path = _video_path()
    else:
        path = picture_file(item)
    if not path:
        raise ValueError('Already removed.')
    state = media_state(addon)
    os.remove(path)
    if item == 'video' and os.path.isfile(still_path()):
        os.remove(still_path())
    if (item == 'video' and state['current'] == 'video') or (item == state['picture'] and state['current'] == 'picture') \
            or (state['current'] == 'slideshow' and not pictures()):
        set_media('meganexus')
    return {'media': media_state(addon)}


def preview():
    """The screensaver on the TV, over the QR screen, until a key is pressed."""
    xbmc.executebuiltin('RunScript(script.meganexus,saverpreview)')
    return {}


# ---------------------------------------------------------------- uploads ---

def _kind_of(head, kind):
    """The file type from its first bytes: picture = JPEG; video = MP4 / MOV or Matroska / WebM."""
    if kind in ('picture', 'still'):
        return 'jpg' if head[:3] == b'\xff\xd8\xff' else ''
    if head[4:8] in MP4_BOXES:
        return 'mp4'
    if head[:4] == b'\x1a\x45\xdf\xa3':
        return 'mkv'
    return ''


def _part(upload_id):
    return os.path.join(root(), '.upload-' + upload_id)


def receive(kind, upload_id, offset, total, name, data, video_token=''):
    """One piece of an upload, in order. Returns {'done': bool, ...}."""
    if kind not in ('picture', 'video', 'still'):
        raise ValueError('Unknown upload.')
    if kind == 'still' and not _video_path():
        raise ValueError('Add a video first.')
    if not isinstance(upload_id, str) or not UPLOAD_ID.match(upload_id):
        raise ValueError('Bad upload.')
    if not (0 < total <= MAX_FILE) or not (0 <= offset < total) or not data or len(data) > CHUNK_MAX or offset + len(data) > total:
        raise ValueError('The file is larger than %d MB.' % (MAX_FILE // (1024 * 1024)) if total > MAX_FILE else 'Bad upload.')
    if kind == 'picture' and len(pictures()) >= MAX_PICTURES:
        raise ValueError('Up to %d pictures - remove one first.' % MAX_PICTURES)
    extension = os.path.splitext(name or '')[1].lower()
    if kind == 'video' and extension and extension not in VIDEO_TYPES:
        raise ValueError('Use an MP4, MOV, MKV or WebM video.')
    with _LOCK:
        if kind=='still' and video_token and os.path.basename(_video_path() or '')!=video_token:
            raise ValueError('The video changed. Create its frame again.')
        if upload_id in _FINISHED:
            return _FINISHED[upload_id]          # the last piece, sent again
        os.makedirs(root(), exist_ok=True)
        part = _part(upload_id)
        size = os.path.getsize(part) if os.path.exists(part) else 0
        if offset < size and offset + len(data) <= size:
            return {'done': False, 'received': size}   # a piece we already have, sent again
        if offset != size:
            raise ValueError('The upload was interrupted. Try again.')
        if offset == 0:
            if shutil.disk_usage(root()).free < total + SPARE:
                raise ValueError('Not enough free space on the TV.')
            found = _kind_of(data[:16], kind)
            if not found or (kind == 'video' and extension and found != VIDEO_TYPES[extension]):
                raise ValueError('This is not a %s the TV can show.' % ('supported video' if kind == 'video' else 'JPEG picture'))
        with open(part, 'ab') as handle:
            handle.write(data)
        if offset + len(data) < total:
            return {'done': False, 'received': offset + len(data)}
        if kind == 'video' and not extension:
            # iPhone names some videos without an extension: the bytes decide.
            with open(part, 'rb') as handle:
                extension = '.mp4' if _kind_of(handle.read(16), 'video') == 'mp4' else '.mkv'
        result = _finish(kind, part, extension)
        _FINISHED[upload_id] = result
        while len(_FINISHED) > 8:
            _FINISHED.pop(next(iter(_FINISHED)))
        return result


def _finish(kind, part, extension):
    if kind == 'picture':
        os.makedirs(pictures_dir(), exist_ok=True)
        picture_id = '%08x%s.jpg' % (int(time.time()) & 0xffffffff, secrets.token_hex(4))
        os.replace(part, os.path.join(pictures_dir(), picture_id))
        return {'done': True, 'picture': picture_id, 'media': media_state()}
    if kind == 'still':
        os.replace(part, still_path())
        _wallpaper_sync(_addon())          # the wallpaper takes the sharp frame
        return {'done': True, 'media': media_state()}
    os.makedirs(video_dir(), exist_ok=True)
    if os.path.isfile(still_path()):
        os.remove(still_path())            # the frame of the previous video
    old = _video_path()
    target = os.path.join(video_dir(), 'screensaver-' + secrets.token_hex(6) + extension)
    if old and old != target:
        os.remove(old)
    os.replace(part, target)
    set_media('video')
    _prepare_loop(target)
    return {'done': True, 'video': os.path.basename(target), 'media': media_state()}


def _prepare_loop(path):
    """The seamless silent loop copy, made in the background (as the TV's own video choice does)."""
    def work():
        try:
            from meganexus_ui.saver import prepare_loop, LOOP_EXTENSIONS
            if path.lower().endswith(LOOP_EXTENSIONS):
                prepare_loop(path)
        except Exception as exc:
            xbmc.log('[MegaNexus] Screensaver loop copy skipped: %s' % exc.__class__.__name__, xbmc.LOGWARNING)
    threading.Thread(target=work, name='MegaNexusSaverLoop', daemon=True).start()


def cancel(upload_id):
    if isinstance(upload_id, str) and UPLOAD_ID.match(upload_id):
        try:
            os.remove(_part(upload_id))
        except OSError:
            pass
    return {}


def clean_partial(max_age=6 * 3600):
    """Pieces of uploads that never finished (phone closed mid-way)."""
    try:
        for name in os.listdir(root()):
            path = os.path.join(root(), name)
            if name.startswith('.upload-') and time.time() - os.path.getmtime(path) > max_age:
                os.remove(path)
    except OSError:
        pass
