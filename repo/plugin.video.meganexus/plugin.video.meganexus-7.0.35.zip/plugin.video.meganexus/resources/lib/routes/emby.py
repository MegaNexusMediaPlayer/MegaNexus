# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Emby route boundary."""
ROUTE_NAMES = ('emby_login','emby_logout','emby_menu','emby_library','emby_children','emby_play')
