# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""First-run setup chooser kept outside the large plugin router."""

def choose_setup_path(dialog, tr=lambda x: x):
    labels = [
        tr('Nuvio — link Continue Watching'),
        tr('Stremio — import addons + Continue Watching'),
        tr('Manual setup — Stremio / Plex / Emby myself'),
    ]
    idx = dialog.select(tr('Quick Start • choose a setup method'), labels)
    if idx < 0:
        return None
    return ('nuvio', 'stremio', 'manual')[idx]
