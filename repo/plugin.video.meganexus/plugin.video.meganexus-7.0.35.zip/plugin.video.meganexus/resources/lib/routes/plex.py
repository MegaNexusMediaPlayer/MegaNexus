# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Plex route boundary.
Routes remain delegated to plugin.py during phase one to preserve Kodi URLs.
"""
ROUTE_NAMES = ('plex_login','plex_logout','plex_menu','plex_refresh','plex_servers','plex_server','plex_library','plex_children','plex_search','plex_play')
