# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Unified ranking facade."""
from .. import stream_ranking as _backend

def __getattr__(name): return getattr(_backend, name)
