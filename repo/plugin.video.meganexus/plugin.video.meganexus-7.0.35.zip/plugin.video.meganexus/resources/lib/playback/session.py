# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Playback and source-session facade."""
from .. import session_store as _sessions
from ..search import source_cache

def save_session(*args, **kwargs): return _sessions.save_session(*args, **kwargs)
def load_session(*args, **kwargs): return _sessions.load_session(*args, **kwargs)
def clear_session(*args, **kwargs): return _sessions.clear_session(*args, **kwargs)
def __getattr__(name): return getattr(_sessions, name)
