# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Subtitle policy and runtime facade."""
from .. import subtitle_policy as policy
from .. import subtitle_logic as logic

is_ai_subtitle = policy.is_ai_subtitle
allow_automatic = policy.allow_automatic
automatic_rows = policy.automatic_rows

def __getattr__(name):
    if hasattr(policy, name): return getattr(policy, name)
    return getattr(logic, name)
