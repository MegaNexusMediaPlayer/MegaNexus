# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Home and HUB wallpaper (7.0.28).

Your own picture, a slideshow of a folder, or simply the screensaver's
background, behind MegaNexus Home, the catalogs, Library, Live TV, Sport and
the HUB - darkened so text stays readable. Off by default (the MegaNexus
look). The choice is the setting meganexus_wallpaper (off / saver / picture /
folder, with meganexus_wallpaper_path); sync() writes what to show into
MegaNexus Skin strings, so the HUB has it at Kodi start without any Python:

    Skin.String(meganexus.wallpaper.mode)    image | still | slideshow | (empty = off)
    Skin.String(meganexus.wallpaper)         the picture
    Skin.String(meganexus.wallpaper.folder)  the slideshow folder

A video screensaver gives a still frame of that video (7.0.29): the sharp one
the phone page made (still.jpg next to the video, up to 4K), otherwise Kodi's
own small frame through image://video@ -
Home, Live TV and Sport stay still. No motion: Home stays as light for the GPU
as before.
"""
import os
import hashlib

import xbmc
import xbmcaddon

ADDON_ID = 'plugin.video.meganexus'
SETTING = 'meganexus_wallpaper'
PATH_SETTING = 'meganexus_wallpaper_path'
MODES = ('off', 'saver', 'picture', 'folder')
LABELS = {'off': 'Off · the MegaNexus look', 'saver': 'Same as the screensaver background',
          'picture': 'A picture', 'folder': 'A folder of pictures (slideshow)'}
SKIN = 'skin.meganexus'
KEYS = ('meganexus.wallpaper.mode', 'meganexus.wallpaper', 'meganexus.wallpaper.folder', 'meganexus.hub.tint')
HUB_TINT = 'FF737373'           # the HUB picture darkened to 45 % when it is your wallpaper


def mode(addon=None):
    addon = addon or xbmcaddon.Addon(ADDON_ID)
    value = addon.getSetting(SETTING)
    return value if value in MODES else 'off'


def resolve(addon=None):
    """(mode, picture, folder) the windows show: mode 'image', 'slideshow' or ''."""
    addon = addon or xbmcaddon.Addon(ADDON_ID)
    choice = mode(addon)
    if choice == 'picture':
        path = addon.getSetting(PATH_SETTING)
        return ('image', path, '') if path else ('', '', '')
    if choice == 'folder':
        path = addon.getSetting(PATH_SETTING)
        return ('slideshow', '', _folder(path)) if path else ('', '', '')
    if choice == 'saver':
        kind = addon.getSetting('meganexus_screensaver_type') or 'image'
        folder = addon.getSetting('meganexus_screensaver_folder')
        art = addon.getSetting('meganexus_screensaver_art')
        if kind == 'slideshow' and folder:
            return 'slideshow', '', _folder(folder)
        if kind == 'image' and art:
            return 'image', art, ''
        video = addon.getSetting('meganexus_screensaver_video')
        if kind == 'video' and video:
            picture = sharp(video)
            if picture:
                return 'image', picture, ''          # a distinct frame for this exact video
            return 'still', still(video), ''         # Kodi's own (small) frame
    return '', '', ''


def still(video):
    """A still frame of a video, made and cached by Kodi."""
    from urllib.parse import quote
    return 'image://video@%s/' % quote(video, safe='')


def sharp_path(video):
    """A new texture identity whenever the source changes, including overwrites."""
    try:
        import xbmcvfs
        path=xbmcvfs.translatePath(video);info=os.stat(path)
        identity='%s|%s|%s'%(video,info.st_size,int(info.st_mtime))
    except (OSError,ValueError):identity=video
    digest=hashlib.sha1(identity.encode('utf-8')).hexdigest()[:12]
    return os.path.join(os.path.dirname(video),'still-'+digest+'.jpg')


def sharp(video):
    path=sharp_path(video)
    if os.path.isfile(path):return path
    legacy=os.path.join(os.path.dirname(video),'still.jpg')
    if os.path.isfile(legacy):return legacy
    return ''


def _folder(path):
    """multiimage wants the folder with its trailing separator."""
    if not path or path.endswith(('/', '\\')):
        return path
    return path + ('\\' if '\\' in path and '/' not in path else '/')


def label(addon=None):
    addon = addon or xbmcaddon.Addon(ADDON_ID)
    choice = mode(addon)
    text = LABELS[choice].split(' · ')[0] if choice == 'off' else LABELS[choice]
    if choice in ('picture', 'folder') and addon.getSetting(PATH_SETTING):
        text += ' · ' + os.path.basename(addon.getSetting(PATH_SETTING).rstrip('/\\'))
    elif choice == 'saver' and not resolve(addon)[0]:
        text += ' (now the MegaNexus look)'
    return text


def choose(choice, path='', addon=None):
    addon = addon or xbmcaddon.Addon(ADDON_ID)
    if choice not in MODES:
        raise ValueError('Unknown wallpaper.')
    addon.setSetting(SETTING, choice)
    if choice in ('picture', 'folder'):
        addon.setSetting(PATH_SETTING, path)
    sync(addon)


def sync(addon=None):
    """Write the wallpaper into MegaNexus Skin's strings (only when they change)."""
    try:
        if xbmc.getSkinDir() != SKIN:
            return False
        mode, picture, folder = resolve(addon)
        if mode == 'slideshow':
            import xbmcgui
            home = xbmcgui.Window(10000)
            if home.getProperty('meganexus.wallpaper.slide.folder') == folder:
                picture = home.getProperty('meganexus.wallpaper.slide')
        values = dict(zip(KEYS, (mode, picture, folder, HUB_TINT if picture else '')))
        changed = False
        for key in KEYS:
            if xbmc.getInfoLabel('Skin.String(%s)' % key) != values[key]:
                if values[key]:
                    xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (key, values[key].replace('"', '')))
                else:
                    xbmc.executebuiltin('Skin.Reset(%s)' % key)
                changed = True
        return changed
    except Exception as exc:
        xbmc.log('[MegaNexus] Wallpaper not applied: %s' % exc.__class__.__name__, xbmc.LOGWARNING)
        return False
