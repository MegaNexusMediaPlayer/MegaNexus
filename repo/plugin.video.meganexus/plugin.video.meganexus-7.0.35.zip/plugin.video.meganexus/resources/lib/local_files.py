# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Local storage without Kodi's library scan (7.0.29).

A folder added as a Kodi video source showed nothing in MegaNexus until it was
also given a content type ("This directory contains: Movies / TV shows") and
scanned by a Kodi scraper - most people stop after adding the folder. MegaNexus
now reads the folders itself: video files are recognised by their names
("Title (2019)", "Title.2019.1080p...", "Show S01E02", "Show/Season 1/02 ..."),
titles get TMDB pictures when a TMDB key is connected, and they play straight
from the file. Kodi's own library, when it has titles, still comes first
(local_media); this fills the kinds it has none of.

The index is kept for a while in the add-on profile and rebuilt in a Home
worker - never on the GUI thread.
"""
import json
import os
import re
import time

from .local_media import rpc

VIDEO = ('.mkv', '.mp4', '.m4v', '.avi', '.mov', '.ts', '.m2ts', '.mts', '.wmv', '.webm', '.mpg', '.mpeg',
         '.iso', '.strm', '.vob', '.divx', '.flv', '.3gp')
SKIP = re.compile(r'(?i)(^|[ ._\-\[(])(sample|trailer|featurette|extras?|behind ?the ?scenes|deleted ?scenes)([ ._\-\])]|$)')
SKIP_FOLDERS = re.compile(r'(?i)^(\.|@eadir$|\.@__thumb$|sample$|samples$|extras$|featurettes$|trailers$|subs$|subtitles$)')
EPISODE = re.compile(r'(?i)(?:^|[ ._\-\[(])s(\d{1,2})[ ._\-]?e(\d{1,3})(?:[ ._\-]?e\d{1,3})*|(?:^|[ ._\-\[(])(\d{1,2})x(\d{2,3})(?=[ ._\-\])]|$)')
SEASON_FOLDER = re.compile(r'(?i)^(?:season|staffel|saison|sezona|temporada)[ ._\-]*(\d{1,2})$|^s(\d{1,2})$')
YEAR = re.compile(r'(?:^|[ ._\-\[(])((?:19|20)\d{2})(?=[ ._\-\])]|$)')
NOISE = re.compile(r'(?i)[ ._\-\[(](?:2160p|1080p|720p|480p|4k|uhd|hdr10?\+?|dv|dolby ?vision|web[ ._\-]?dl|webrip|bluray|blu[ ._\-]?ray|'
                   r'bdrip|brrip|dvdrip|hdtv|remux|x26[45]|h\.?26[45]|hevc|avc|aac|ac3|dts|atmos|truehd|ddp?5\.1|10bit|proper|repack|'
                   r'extended|unrated|directors ?cut|multi|dual|subbed|dubbed)\b.*$')
CACHE_NAME = 'local_files.json'
FRESH_SECONDS = 1800
MAX_FILES = 4000
MAX_DEPTH = 6
BUDGET_SECONDS = 25
ROW_LIMIT = 40
HOME_MIGRATED = 'meganexus_home_local_on'


def _profile():
    try:
        from .common import profile_path
        return profile_path()
    except Exception:
        import xbmcvfs
        return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/')


def folders():
    """The video sources that are folders (not add-ons or other plugins)."""
    from .local_media import sources
    out = []
    for source in sources():
        path = str(source.get('file') or '')
        if path and not path.startswith(('plugin://', 'addons://', 'library://', 'videodb://', 'special://', 'http://', 'https://')):
            out.append(path)
    return out


def clean_title(text):
    text = NOISE.sub('', ' ' + str(text or '')).strip()
    text = re.sub(r'[._]+', ' ', text)
    text = re.sub(r'\s*[\[(][^\])]*[\])]\s*', ' ', text)
    text = re.sub(r'\s+-\s*$', '', text)
    return re.sub(r'\s{2,}', ' ', text).strip(' -_.')


def parse(path):
    """{'kind': 'episode', 'show', 'season', 'episode'} / {'kind': 'movie', 'title', 'year'} / None."""
    path = str(path or '').rstrip('/\\')
    parts = re.split(r'[/\\]', path)
    name, ext = os.path.splitext(parts[-1])
    if ext.lower() not in VIDEO or SKIP.search(name):
        return None
    parent = parts[-2] if len(parts) > 1 else ''
    grand = parts[-3] if len(parts) > 2 else ''
    found = EPISODE.search(name)
    season_folder = SEASON_FOLDER.match(parent or '')
    if found:
        season = int(found.group(1) or found.group(3))
        episode = int(found.group(2) or found.group(4))
        show = clean_title(name[:found.start()])
        if not show:
            show = clean_title(grand if season_folder else parent)
        return {'kind': 'episode', 'show': show or 'Series', 'season': season, 'episode': episode}
    if season_folder:
        number = re.match(r'^\D*(\d{1,3})', name)
        if number:
            return {'kind': 'episode', 'show': clean_title(grand) or 'Series',
                    'season': int(season_folder.group(1) or season_folder.group(2)), 'episode': int(number.group(1))}
    for text in (name, parent):
        year = YEAR.search(text)
        if year and clean_title(text[:year.start()]):
            return {'kind': 'movie', 'title': clean_title(text[:year.start()]), 'year': year.group(1)}
    generic = re.match(r'(?i)^(movie|video|film|vts_\d+_\d+|\d+)$', clean_title(name) or '')
    title = clean_title(parent if generic and parent else name)
    return {'kind': 'movie', 'title': title or name, 'year': ''} if title or name else None


def walk(roots, stopped=None, budget=BUDGET_SECONDS, max_files=MAX_FILES):
    """Video files below the source folders (Kodi's VFS: local disks, SMB, NFS...)."""
    files, queue, end = [], [(root, 0) for root in roots], time.monotonic() + budget
    while queue and len(files) < max_files and time.monotonic() < end:
        if stopped and stopped():
            break
        folder, depth = queue.pop(0)
        listing = rpc('Files.GetDirectory', {'directory': folder, 'media': 'video', 'properties': ['size']})
        for entry in listing.get('files') or []:
            path = str(entry.get('file') or '')
            label = str(entry.get('label') or '')
            if entry.get('filetype') == 'directory':
                if depth < MAX_DEPTH and not SKIP_FOLDERS.match(label):
                    queue.append((path, depth + 1))
            elif path.lower().endswith(VIDEO):
                files.append(path)
    return files


def build(files):
    movies, shows = {}, {}
    for path in files:
        found = parse(path)
        if not found:
            continue
        if found['kind'] == 'movie':
            key = (found['title'].casefold(), found['year'])
            movies.setdefault(key, {'title': found['title'], 'year': found['year'], 'path': path})
        else:
            show = shows.setdefault(found['show'].casefold(), {'title': found['show'], 'episodes': {}})
            show['episodes'].setdefault((found['season'], found['episode']), path)
    return ({'movies': list(movies.values()),
             'shows': [{'title': s['title'], 'episodes': [{'season': k[0], 'episode': k[1], 'path': v}
                                                          for k, v in sorted(s['episodes'].items())]}
                       for s in shows.values()]})


def _cache_path():
    return os.path.join(_profile(), CACHE_NAME)


def cached():
    try:
        with open(_cache_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def index(fresh=False, stopped=None):
    """The index of the source folders; rebuilt when older than half an hour,
    when the folders changed, or on request (Scan folders)."""
    roots = folders()
    data = cached()
    if data and not fresh and data.get('roots') == roots and time.time() - float(data.get('at') or 0) < FRESH_SECONDS:
        return data
    if not roots:
        return {'roots': [], 'at': time.time(), 'movies': [], 'shows': []}
    data = dict(build(walk(roots, stopped)), roots=roots, at=time.time())
    if stopped and stopped():
        return data
    try:
        os.makedirs(_profile(), exist_ok=True)
        temp = _cache_path() + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
        os.replace(temp, _cache_path())
    except OSError:
        pass
    return data


def has(kind):
    """From the saved index only (no folder reads): None when not indexed yet."""
    data = cached()
    if data is None:
        return None
    return bool(data.get('movies' if kind == 'movie' else 'shows'))


def forget():
    try:
        os.remove(_cache_path())
    except OSError:
        pass


def _art(title, year, kind):
    try:
        from . import tmdb_direct
        if not tmdb_direct._api_key():
            return {}
        return tmdb_direct.art_for(media_type='series' if kind == 'series' else 'movie', title=title, year=year) or {}
    except Exception:
        return {}


def cards(kind, limit=ROW_LIMIT, stopped=None):
    data = index(stopped=stopped)
    if kind == 'movie':
        items = sorted(data.get('movies') or [], key=lambda m: (m.get('year') or '', m['title']), reverse=True)[:limit]
    else:
        items = sorted(data.get('shows') or [], key=lambda s: s['title'].casefold())[:limit]
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=6, thread_name_prefix='MegaNexusLocalArt') as pool:
        arts = list(pool.map(lambda item: _art(item['title'], item.get('year') or '', kind), items))
    out = []
    for item, art in zip(items, arts):
        if kind == 'movie':
            local = {'type': 'file', 'path': item['path'], 'title': item['title']}
            subtitle = item.get('year') or ''
            line = '  |  '.join(x for x in (item.get('year'), 'Movie', 'On this device') if x)
        else:
            local = {'type': 'file_series', 'title': item['title'], 'episodes': item['episodes']}
            count = len(item['episodes'])
            subtitle = '%d episode%s' % (count, '' if count == 1 else 's')
            line = '  |  '.join(('Series', 'On this device'))
        out.append({'title': item['title'], 'subtitle': subtitle, 'meta_line': line, 'plot': '',
                    'poster': art.get('poster') or '', 'fanart': art.get('fanart') or '',
                    'landscape': art.get('landscape') or art.get('fanart') or '', 'clearlogo': art.get('clearlogo') or '',
                    'local': local, 'path': '', 'is_folder': False})
    return out


def migrate_home_rows(addon=None, data=None):
    """Once: a device whose folders hold films or series shows its Local rows on
    Home (decided on the first index, so empty default folders change nothing)."""
    from .settings_cache import cached_addon
    from .local_media import HOME_SETTING
    addon = addon or cached_addon()
    if addon.getSetting(HOME_MIGRATED) == 'true' or data is None:
        return
    if data.get('movies') or data.get('shows'):
        addon.setSetting(HOME_SETTING, 'true')
    addon.setSetting(HOME_MIGRATED, 'true')


def run(monitor, busy=None):
    """Service thread: keep the index fresh (start, then every half hour, and
    soon after the video folders change) - Home and the Library only read it."""
    roots = None
    while not monitor.abortRequested():
        try:
            current = folders()
            if current and (current != roots or time.time() - float((cached() or {}).get('at') or 0) >= FRESH_SECONDS):
                if not (busy and busy()):
                    data = index(fresh=current != roots and roots is not None, stopped=monitor.abortRequested)
                    roots = current
                    migrate_home_rows(data=data)
            elif not current:
                roots = current
        except Exception:
            pass
        if monitor.waitForAbort(60):
            break
