# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Cross-interpreter safeguards for screensaver startup and cancelled playback."""
import json
import time
import xbmc
import xbmcgui


def _read(key):
    try:
        value=json.loads(xbmcgui.Window(10000).getProperty(key) or '{}')
        return value if isinstance(value,dict) else {}
    except (ValueError,TypeError):return {}


def active():
    home=xbmcgui.Window(10000);token=home.getProperty('meganexus.saver.active')
    pending=_read('meganexus.saver.pending')
    if token and pending.get('token')==token:
        try:expired=not 0<=time.time()-float(pending.get('issued',0))<=10
        except (ValueError,TypeError):expired=True
        if expired:
            home.clearProperty('meganexus.saver.pending');home.clearProperty('meganexus.saver.active');return False
    return bool(token)


def wake_for_entry():
    """Close an ordinary saver left over an explicit Home/Sport/IPTV entry."""
    home=xbmcgui.Window(10000)
    home.setProperty('meganexus.saver.wake',str(time.time()))
    if xbmc.getCondVisibility('System.ScreenSaverActive'):
        xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Input.ExecuteAction',
                                       'params':{'action':'contextmenu'}}))


def cancel_play(token):
    if token:
        home=xbmcgui.Window(10000);previous=_read('meganexus.saver.cancelled');now=time.time()
        tokens=previous.get('tokens') or ([previous] if previous.get('token') else [])
        def keep(item):
            try:return item.get('token')!=token and 0<=now-float(item.get('issued',0))<=30
            except (ValueError,TypeError,AttributeError):return False
        tokens=[t for t in tokens if keep(t)]
        current={'token':token,'issued':now};tokens.append(current)
        home.setProperty('meganexus.saver.cancelled',json.dumps(dict(current,tokens=tokens[-16:])))


def stop_cancelled_preview(player):
    """Service guard: a late queued AV start must not survive its saver owner.

    Item-token identity, not a file path or global flag, authorizes Stop. A
    concurrent user-selected movie is never stopped by this cleanup.
    """
    home=xbmcgui.Window(10000);value=_read('meganexus.saver.cancelled')
    if not value.get('token'):return False
    try:
        recent=[t['token'] for t in value.get('tokens',[value]) if t.get('token') and 0<=time.time()-float(t.get('issued',0))<=30]
    except (ValueError,TypeError):recent=[]
    if not recent:home.clearProperty('meganexus.saver.cancelled');return False
    try:owned=player.isPlayingVideo() and player.getPlayingItem().getProperty('meganexus.preview') in recent
    except Exception:return False
    if not owned:return False
    xbmc.executebuiltin('PlayerControl(Stop)')
    return True
