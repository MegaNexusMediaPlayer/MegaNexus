# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Small Kodi entry point.

Keep default.py stable and defer the very large legacy compatibility module
until an invocation actually runs. This also gives future versions one place
to swap the legacy router for fully split routes.
"""

def run():
    # --- meganexus-401-patch ---
    try:
        from .settings_cache import invalidate as _dh_invalidate
        _dh_invalidate()
    except Exception:
        pass
    try:
        from .i18n import reset_language_cache
        reset_language_cache()
    except Exception:
        pass
    from .plugin import run as plugin_run
    return plugin_run()
