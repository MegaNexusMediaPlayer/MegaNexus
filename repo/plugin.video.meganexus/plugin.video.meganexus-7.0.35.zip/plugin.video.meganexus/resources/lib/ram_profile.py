# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Memory presets for posters, catalog pages and details (7.0.3).

Three choices in HUB Settings > Performance: 128 MiB for low-end devices
(1-2 GB sticks), 256 MiB (default, recommended) and 512 MiB for high-end
boxes and PCs. Earlier names (the 6.0/7.0 "auto", ram96, ram150, ram160,
ram200) map to the nearest preset; disk and off choices are kept as they are.
"""
MIB = 1024 * 1024
DEFAULT = 'ram256'
SETTING = 'meganexus_art_cache'
PRESETS = ('ram128', 'ram256', 'ram512')
# preset -> (posters, catalog pages, details) in bytes
BUDGETS = {'ram128': (128 * MIB, 48 * MIB, 16 * MIB),
           'ram256': (256 * MIB, 96 * MIB, 32 * MIB),
           'ram512': (512 * MIB, 160 * MIB, 48 * MIB)}
LABELS = {'ram128': 'Low-end device · RAM 128 MiB',
          'ram256': 'Recommended · RAM 256 MiB',
          'ram512': 'High-end device · RAM 512 MiB'}
LEGACY = {'': DEFAULT, 'auto': DEFAULT, 'ram96': 'ram128', 'ram150': 'ram256', 'ram160': 'ram256', 'ram200': 'ram256'}


def chosen(addon):
    """The stored choice, earlier names mapped."""
    try:
        value = addon.getSetting(SETTING) or ''
    except Exception:
        value = ''
    return LEGACY.get(value, value)


def effective(mode):
    return LEGACY.get(mode or '', mode or DEFAULT)


def pages(mode, fallback):
    return BUDGETS.get(effective(mode), (0, fallback, 0))[1]


def details(mode, fallback):
    return BUDGETS.get(effective(mode), (0, 0, fallback))[2]
