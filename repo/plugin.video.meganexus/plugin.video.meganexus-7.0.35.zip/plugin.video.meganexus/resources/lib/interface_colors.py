# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Live colour tokens shared by the interface, native dialogs and OSD.

The service alone samples files; every other interpreter publishes from a
cached RGB setting. No skin reload, profile-specific XML, or generated runtime
textures. Changing hue/strength keeps the alpha of translucent surfaces.
"""
import colorsys
import json
import os
import time
import xbmc
import xbmcgui
import xbmcvfs

PREFIX = 'meganexus.ui.'
FOLLOW = 'meganexus_color_follow'
TONE = 'meganexus_color_tone'
STRENGTH = 'meganexus_color_strength'
SEED = 'meganexus_color_seed'
TONES = ('natural', 'cool', 'warm', 'soft', 'deep')
LABELS = dict(zip(TONES, ('Natural', 'Cool', 'Warm', 'Soft', 'Deep')))
_signature = None
_next_sample = 0.
_tokens = None
_slide_folder = ''
_slide_files = []
_slide_at = 0.
_slide_index = 0


def cached_video_frame(url):
    """Palette fallback from Kodi's thumbnail file, without polling its DB."""
    if not str(url).startswith('image://video@'):return url
    value=0xffffffff
    for byte in url.lower().encode('utf-8'):
        value^=byte<<24
        for _ in range(8):value=((value<<1)^0x04c11db7)&0xffffffff if value&0x80000000 else (value<<1)&0xffffffff
    digest='%08x'%value
    folder=xbmcvfs.translatePath('special://thumbnails/')
    for suffix in ('.jpg','.png'):
        path=os.path.join(folder,digest[0],digest+suffix)
        if os.path.isfile(path):return path
    return ''


def slide(folder):
    """One shared slideshow frame across windows and the preview's blend."""
    global _slide_folder, _slide_files, _slide_at, _slide_index
    now = time.monotonic()
    if folder != _slide_folder:
        _slide_folder = folder; _slide_at = 0.; _slide_index = 0; _slide_files = []
    if now >= _slide_at:
        if not _slide_files:
            try:
                _, files = xbmcvfs.listdir(folder)
                _slide_files = [folder + name for name in sorted(files)[:4096] if name.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))]
            except Exception: pass
        _slide_at = now + 30.
        if _slide_files:
            path = _slide_files[_slide_index % len(_slide_files)]; _slide_index += 1
            home = xbmcgui.Window(10000)
            home.setProperty('meganexus.wallpaper.slide', path)
            home.setProperty('meganexus.wallpaper.slide.folder', folder)
    return xbmcgui.Window(10000).getProperty('meganexus.wallpaper.slide') if _slide_files else ''


def options(addon):
    tone = addon.getSetting(TONE)
    try: strength = max(0, min(100, int(addon.getSetting(STRENGTH) or '35')))
    except ValueError: strength = 35
    return addon.getSetting(FOLLOW) != 'false', tone if tone in TONES else 'natural', strength


def _rgb(value, fallback=(80, 150, 220)):
    try:
        value = value.lstrip('#')[-6:]
        if len(value) != 6: return fallback
        return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))
    except (ValueError, AttributeError): return fallback


def _hex(rgb, alpha=255):
    return '%02X%02X%02X%02X' % ((alpha,) + tuple(max(0, min(255, round(c))) for c in rgb))


def mix(a, b, amount):
    return tuple(x + (y - x) * amount for x, y in zip(a, b))


def palette(seed, tone='natural', strength=35, base='light'):
    h, s, v = colorsys.rgb_to_hsv(*(c / 255. for c in _rgb(seed)))
    shift, saturation, lightness = {'natural': (0, 1, 1), 'cool': (.04, 1, 1),
                                  'warm': (-.04, 1, 1), 'soft': (0, .65, 1.12),
                                  'deep': (0, 1.15, .82)}.get(tone, (0, 1, 1))
    accent = tuple(c * 255 for c in colorsys.hsv_to_rgb((h + shift) % 1, min(.65, s * saturation),
                                                       min(.9, max(.65, v) * lightness)))
    amount = max(0, min(100, strength)) / 100.
    page = (4, 15, 34) if base == 'light' else (0, 0, 0)
    panel = (17, 20, 25) if base == 'dark' else (6, 22, 50)
    surface = mix(page, accent, amount * .16)
    raised = mix(panel, accent, amount * .20)
    text = mix((245, 247, 250), accent, amount * .10)
    muted = mix((180, 193, 211), accent, amount * .16)
    return {'page': _hex(surface), 'bottom': _hex(mix((10,35,80),accent,amount*.16)),
            'panel': _hex(raised, 232), 'card': _hex(raised, 172),
            'focus': _hex(mix((210, 218, 230), accent, amount * .7), 92),
            'pill': _hex(mix((200, 208, 220), accent, amount * .7), 45),
            'accent': _hex(mix((100, 169, 238), accent, amount)),
            'text': _hex(text), 'muted': _hex(muted), 'disabled': _hex(muted, 100)}


# 7.0.29: your own colours on top of the theme - each part of the interface
# can take a colour of its own (independent of the background); "Automatic"
# keeps the theme's. Surfaces keep their transparency.
ROLES = ('accent', 'page', 'panel', 'pill', 'focus', 'text')
ROLE_LABELS = {'accent': 'Accent · icons, progress and highlights', 'page': 'Background · behind every screen',
               'panel': 'Panels & cards', 'pill': 'Buttons & pills', 'focus': 'Selection · the focused pill',
               'text': 'Text'}
LIGHT = (('FFFFFF', 'White'), ('F5F0E6', 'Ivory'), ('E3ECF5', 'Ice'), ('CFD8DC', 'Silver'), ('FFE082', 'Amber'),
         ('FFB74D', 'Orange'), ('FF8A65', 'Coral'), ('EF5350', 'Red'), ('F06292', 'Pink'), ('CE93D8', 'Orchid'),
         ('9575CD', 'Violet'), ('7986CB', 'Indigo'), ('64B5F6', 'Sky'), ('4FC3F7', 'Azure'), ('4DD0E1', 'Cyan'),
         ('4DB6AC', 'Teal'), ('81C784', 'Green'), ('AED581', 'Lime'), ('FFD54F', 'Gold'), ('BCAAA4', 'Taupe'))
DARK = (('000000', 'Black'), ('101114', 'Graphite'), ('1C1E22', 'Charcoal'), ('263238', 'Slate'), ('041026', 'Midnight'),
        ('0B1F3A', 'Navy'), ('102A43', 'Ocean'), ('0D3B3E', 'Petrol'), ('0B2E26', 'Pine'), ('15301A', 'Forest'),
        ('1A1033', 'Deep purple'), ('2A1036', 'Plum'), ('3A0E1E', 'Wine'), ('3B0A0A', 'Oxblood'), ('2B1B12', 'Espresso'),
        ('33261A', 'Bronze'), ('1F2A44', 'Steel blue'), ('2E3440', 'Nord'))
SWATCHES = {'accent': LIGHT, 'pill': LIGHT, 'focus': LIGHT, 'text': LIGHT,
            'page': DARK, 'panel': DARK}


def role_setting(role):
    return 'meganexus_color_' + role


def own_colours(addon):
    """{role: 'RRGGBB'} the viewer chose (valid hex only)."""
    out = {}
    for role in ROLES:
        value = (addon.getSetting(role_setting(role)) or '').strip().lstrip('#').upper()
        if len(value) == 6 and all(c in '0123456789ABCDEF' for c in value):
            out[role] = value
    return out


def set_own(addon, role, value):
    if role not in ROLES:
        raise ValueError('Unknown interface part.')
    value = (value or '').strip().lstrip('#').upper()
    if value and not (len(value) == 6 and all(c in '0123456789ABCDEF' for c in value)):
        raise ValueError('Use six hex digits, e.g. 5096DC.')
    addon.setSetting(role_setting(role), value)


def with_own(colors, own):
    """The palette with the chosen colours; every alpha stays the theme's."""
    colors = dict(colors)
    for role, value in own.items():
        colors[role] = colors[role][:2] + value
    if 'panel' in own:
        colors['card'] = colors['card'][:2] + own['panel']
    if 'page' in own:
        colors['bottom'] = colors['bottom'][:2] + own['page']
    if 'text' in own:
        page = _rgb(colors['page'][2:])
        muted = _hex(mix(_rgb(own['text']), page, .3))[2:]
        colors['muted'] = colors['muted'][:2] + muted
        colors['disabled'] = colors['disabled'][:2] + muted
    return colors


def publish(addon=None):
    from .settings_cache import cached_addon
    addon = addon or cached_addon()
    follow, tone, strength = options(addon)
    from . import wallpaper, theme
    if follow and not wallpaper.resolve(addon)[0]:strength=0
    colors = palette(addon.getSetting(SEED) if follow else '5096DC', tone, strength,
                     theme.current(addon))
    colors = with_own(colors, own_colours(addon))
    home = xbmcgui.Window(10000)
    global _tokens
    if _tokens is None:
        try:
            with open(os.path.join(os.path.dirname(__file__), 'interface_tokens.json'), encoding='utf-8') as handle:
                _tokens = json.load(handle)
        except (OSError, ValueError): _tokens = []
    for name in _tokens:
        key, alpha = name.rsplit('_', 1)
        if key in colors: colors[name] = alpha + colors[key][2:]
    for key, value in colors.items():
        if getattr(home, 'getProperty', lambda k: '')(PREFIX + key) != value: home.setProperty(PREFIX + key, value)
    return colors


def sample_background(addon=None):
    """Service call: bounded VFS reads, once per changed source, retries missing art."""
    global _signature, _next_sample
    from . import wallpaper, theme
    from .settings_cache import cached_addon
    addon = addon or cached_addon()
    follow, _, _ = options(addon)
    mode, picture, folder = wallpaper.resolve(addon)
    path = picture or theme.banner(addon)
    if mode=='still':
        path=cached_video_frame(path)
        if not path:return publish(addon)
    if folder:
        path = slide(folder) or path
        wallpaper.sync(addon)
    if not follow: return publish(addon)
    try:
        translated = xbmcvfs.translatePath(path)
        info = os.stat(translated)
        signature = (path, info.st_mtime_ns, info.st_size)
    except (OSError, ValueError): signature = (path,)
    if signature == _signature or time.monotonic() < _next_sample: return publish(addon)
    _next_sample = time.monotonic() + 5.
    try:
        from .wallpaper_colors import MAX_BYTES, sample
        handle = xbmcvfs.File(path)
        try: data = bytes(handle.readBytes(MAX_BYTES + 1))
        finally: handle.close()
        rgb = sample(data)
        if rgb:
            addon.setSetting(SEED, _hex(rgb)[2:])
        _signature = signature
    except Exception:
        pass
    return publish(addon)


def run():
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try: sample_background()
        except Exception: xbmc.log('[MegaNexus] Background colours unavailable.', xbmc.LOGWARNING)
        if monitor.waitForAbort(2.): break
