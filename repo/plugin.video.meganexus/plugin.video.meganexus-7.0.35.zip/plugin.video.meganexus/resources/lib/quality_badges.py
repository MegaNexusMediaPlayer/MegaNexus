# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Nuvio stream badge JSON: local rules, grouped matches and optional artwork.

Network imports are explicit worker/phone actions. Source-window callbacks
only consume rows prepared ahead of time. No remote assets are bundled.
"""
import json
import os
import re
import base64
import binascii
import hashlib
import struct
import unicodedata
from urllib.parse import urlsplit
from urllib.request import Request,urlopen
from .settings_cache import cached_addon
from .meganexus.common import profile_path
from .meganexus.safe_io import write_json

ENABLED='elite_badges_enabled'
MAX_BYTES=1024*1024
EXAMPLE='4K 2160p WEB-DL Dolby Vision HDR10+ HEVC 10bit Dolby Atmos DD+ Cached'
_compiled={}
_fallbacks={}
_refreshed=[]


def _marker_pattern(pattern):
    rendered=re.sub(r'\\+u([0-9a-fA-F]{4})',lambda m:chr(int(m[1],16)),str(pattern or ''))
    return len(rendered)>=6 and set(rendered)<={'\u2060','\u200b','\u200c','\u200d'}


def _ordinary_pattern(name):
    """Known technical badges can match real source facts without a formatter."""
    key=unicodedata.normalize('NFKC',str(name)).casefold().strip()
    patterns={
        'remux':r'\b(?:bd)?remux\b','blu-ray disc':r'\b(?:blu[ ._-]?ray|bdrip)\b',
        'web-dl':r'\bweb[ ._-]?dl\b','webrip':r'\bweb[ ._-]?rip\b','hdtv':r'\bhdtv\b','dvd rip':r'\bdvd[ ._-]?rip\b',
        '4k ultra hd':r'\b(?:4k|2160p|uhd)\b','4k':r'\b(?:4k|2160p|uhd)\b',
        '1080p full hd':r'\b(?:1080p|fhd)\b','1080p':r'\b1080p\b','720p hd':r'\b720p\b','480p sd':r'\b480p\b',
        'dolby vision':r'\b(?:dolby[ ._-]?vision|dovi|dv)\b','hdr10+':r'hdr[ ._-]?10\+',
        'hdr10':r'\bhdr[ ._-]?10\b(?!\+)','hdr':r'\bhdr(?:10)?\b','sdr':r'\bsdr\b',
        'hevc':r'\b(?:hevc|h[ ._-]?265|x265)\b','avc':r'\b(?:avc|h[ ._-]?264|x264)\b','av1':r'\bav1\b',
        '10bit':r'\b10[ ._-]?bit\b','10 bit':r'\b10[ ._-]?bit\b','8bit':r'\b8[ ._-]?bit\b','8 bit':r'\b8[ ._-]?bit\b',
        'imax':r'\bimax\b','imax enhanced':r'\bimax[ ._-]?enhanced\b',
        'dolby atmos':r'\batmos\b','atmos':r'\batmos\b','truehd':r'\btrue[ ._-]?hd\b','dolby truehd':r'\btrue[ ._-]?hd\b',
        'dolby digital plus':r'\b(?:ddp|e[ ._-]?ac[ ._-]?3)\b|\bdd\+','dolby digital':r'\bac[ ._-]?3\b',
        'dts':r'\bdts\b','dts-hd':r'\bdts[ ._-]?hd\b','dts-x':r'\bdts[ ._:-]?x\b',
        'dts-hd master audio':r'\bdts[ ._-]?hd[ ._-]?(?:ma|master)\b','aac':r'\baac\b','flac':r'\bflac\b','opus':r'\bopus\b',
        '5.1 audio':r'\b5[ ._-]1\b','7.1 audio':r'\b7[ ._-]1\b',
        # 7.0.29: the names of the starter set (a universal Nuvio / AIOStreams pack)
        '2160p':r'\b(?:4k|2160p|uhd)\b','720p':r'\b720p\b','480p':r'\b480p\b',
        '5.1':r'\b5[ ._-]1\b','5.1 ch':r'\b5[ ._-]1\b','6.1 ch':r'\b6[ ._-]1\b','7.1':r'\b7[ ._-]1\b','7.1 ch':r'\b7[ ._-]1\b',
        'dd':r'\b(?:ac[ ._-]?3|dd[ ._-]?[25][ ._-][01]|dd)\b(?![+p])','dd+':r'\b(?:ddp|e[ ._-]?ac[ ._-]?3)\b|\bdd\+',
        'dolby digital +':r'\b(?:ddp|e[ ._-]?ac[ ._-]?3)\b|\bdd\+','dts-hd ma':r'\bdts[ ._-]?hd[ ._-]?(?:ma|master)\b',
        'dts:x':r'\bdts[ ._:-]?x\b','dv':r'\b(?:dolby[ ._-]?vision|dovi|dv)\b',
        '\U0001F1EC\U0001F1E7':r'\U0001F1EC\U0001F1E7|\b(?:english|eng)\b','\U0001F1E9\U0001F1EA':r'\U0001F1E9\U0001F1EA|\b(?:german|deu|ger)\b',
        '\U0001F1EB\U0001F1F7':r'\U0001F1EB\U0001F1F7|\b(?:french|fra|fre|vff|vf)\b','\U0001F1EA\U0001F1F8':r'\U0001F1EA\U0001F1F8|\b(?:spanish|spa|castellano)\b',
        '\U0001F1EE\U0001F1F9':r'\U0001F1EE\U0001F1F9|\b(?:italian|ita)\b','\U0001F1EF\U0001F1F5':r'\U0001F1EF\U0001F1F5|\b(?:japanese|jpn)\b',
        '\U0001F1F0\U0001F1F7':r'\U0001F1F0\U0001F1F7|\b(?:korean|kor)\b','\U0001F1F7\U0001F1FA':r'\U0001F1F7\U0001F1FA|\b(?:russian|rus)\b',
        '\U0001F1E8\U0001F1F3':r'\U0001F1E8\U0001F1F3|\b(?:chinese|chi|mandarin)\b','\U0001F1EE\U0001F1F3':r'\U0001F1EE\U0001F1F3|\b(?:hindi|hin)\b',
        '\U0001F1E7\U0001F1F7':r'\U0001F1E7\U0001F1F7|\b(?:portuguese|por|pt[ ._-]?br)\b','\U0001F1F8\U0001F1E6':r'\U0001F1F8\U0001F1E6|\b(?:arabic|ara)\b',
        'english':r'\b(?:english|eng)\b','croatian':r'\b(?:croatian|hrv|hrvatski)\b',
        'german':r'\b(?:german|deu|ger)\b','french':r'\b(?:french|fra|fre)\b','italian':r'\b(?:italian|ita)\b',
        'spanish':r'\b(?:spanish|spa)\b'}
    return patterns.get(key,'')


def _path():return os.path.join(profile_path(),'meganexus_badges.json')


def _url(value):
    value=str(value or '').strip();parts=urlsplit(value)
    if parts.scheme not in ('http','https') or not parts.netloc or len(value)>2048:return ''
    return value


def _color(value,fallback):
    value=str(value or '').lstrip('#')
    if re.fullmatch('[0-9a-fA-F]{6}',value):value='FF'+value
    return value.upper() if re.fullmatch('[0-9a-fA-F]{8}',value) else fallback


def _embedded(value):
    if not isinstance(value,str) or not value.startswith('data:image/png;base64,'):return None
    if len(value)>180000:raise ValueError('An embedded badge image is too large.')
    try:raw=base64.b64decode(value.split(',',1)[1],validate=True)
    except (ValueError,binascii.Error):raise ValueError('An embedded badge PNG is invalid.') from None
    if len(raw)<33 or raw[:16]!=b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR':raise ValueError('Use embedded PNG badge images.')
    width,height=struct.unpack('>II',raw[16:24])
    if not 0<width<=4096 or not 0<height<=4096 or width*height>4194304:raise ValueError('A badge image has unsupported dimensions.')
    return raw


def _compile(pattern):
    if not isinstance(pattern,str) or not 0<len(pattern)<=512:raise ValueError('Bad badge pattern.')
    parser=getattr(re,'_parser',None)
    if parser is None:
        import sre_parse as parser
    tree=parser.parse(pattern)
    def check(nodes,repeated=False):
        for operation,arg in nodes:
            name=str(operation)
            if name in ('MAX_REPEAT','MIN_REPEAT','POSSESSIVE_REPEAT'):
                if repeated:raise ValueError('Nested badge repetition is not supported.')
                check(arg[2],True)
            elif name=='SUBPATTERN':check(arg[-1],repeated)
            elif name=='BRANCH':
                if repeated:raise ValueError('Repeated badge alternatives are not supported.')
                for branch in arg[1]:check(branch,repeated)
            elif name in ('ASSERT','ASSERT_NOT'):check(arg[1],repeated)
            elif name.startswith('GROUPREF'):raise ValueError('Badge backreferences are not supported.')
    check(tree)
    return re.compile(pattern,re.I)


def normalize(data):
    rows=data.get('filters') if isinstance(data,dict) else data
    if not isinstance(rows,list) or len(rows)>256:raise ValueError('Use a Nuvio badge JSON with up to 256 filters.')
    disabled={g.get('id') for g in data.get('groups',[]) if isinstance(g,dict) and g.get('isEnabled') is False} if isinstance(data,dict) else set()
    result=[]
    for row in rows:
        if not isinstance(row,dict) or row.get('isEnabled') is False or row.get('groupId') in disabled:continue
        pattern=row.get('pattern');name=str(row.get('name') or row.get('id') or '').strip()[:64]
        try:_compile(pattern)
        except (ValueError,re.error):raise ValueError('A badge rule has an unsupported pattern: '+name)
        if not name:continue
        original=row.get('imageURL')
        image=original if _embedded(original) is not None else _url(original)
        # Kodi 21 cannot reliably display remote SVG; keep its readable name.
        if urlsplit(image).path.lower().endswith('.svg'):image=''
        result.append({'name':name,'group':str(row.get('groupId') or row.get('id') or name)[:80],
                       'pattern':pattern,'image':image,'background':_color(row.get('tagColor'),'00000000'),
                       'border':_color(row.get('borderColor'),'00000000'),
                       'text':_color(row.get('textColor'),'FFF5F7FA'),
                       # Nuvio fills the chip only for tagStyle "filled"; the border whenever set
                       'style':str(row.get('tagStyle') or '').strip()[:32]})
    if not result:raise ValueError('This badge JSON has no enabled filters.')
    return result


def _load():
    try:
        with open(_path(),encoding='utf-8') as handle:data=json.loads(handle.read(3*MAX_BYTES+1))
        if not isinstance(data,dict) or not isinstance(data.get('urls'),list) or not isinstance(data.get('rules'),list):return {}
        folder=os.path.join(os.path.dirname(_path()),'badge_images')
        for row in data['rules'][:768]:
            if not isinstance(row,dict) or not str(row.get('image') or '').startswith('data:image/png;base64,'):continue
            path=row.get('kodi_image') or ''
            if isinstance(path,str) and os.path.dirname(path)==folder and os.path.isfile(path):continue
            # Portable backups carry the PNG in JSON, never a device path.
            raw=_embedded(row['image']);row['kodi_image']=_write_image(raw,folder)
        return data
    except (OSError,ValueError):return {}


def save(urls):
    if not isinstance(urls,list) or not 1<=len(urls)<=3:raise ValueError('Add one to three badge JSON URLs.')
    rules=[];clean=[]
    for value in urls:
        url=_url(value)
        if not url:raise ValueError('Use a direct HTTP or HTTPS badge JSON URL.')
        try:
            with urlopen(Request(url,headers={'User-Agent':'MegaNexus'}),timeout=5) as response:raw=response.read(MAX_BYTES+1)
            if len(raw)>MAX_BYTES:raise ValueError('Badge JSON is too large.')
            rules.extend(normalize(json.loads(raw.decode('utf-8-sig'))));clean.append(url)
        except ValueError:raise
        except Exception:raise ValueError('Could not load the badge JSON. Check the URL and connection.') from None
    return _commit(rules[:768],clean)


def _write_image(raw,folder):
    os.makedirs(folder,exist_ok=True)
    path=os.path.join(folder,hashlib.sha256(raw).hexdigest()+'.png')
    if not os.path.isfile(path):
        temporary=path+'.part'
        with open(temporary,'wb') as handle:handle.write(raw)
        os.replace(temporary,path)
    return path


def _commit(rules,urls,name=''):
    folder=os.path.join(os.path.dirname(_path()),'badge_images');used=set()
    for row in rules:
        raw=_embedded(row['image'])
        if raw is None:continue
        path=_write_image(raw,folder);used.add(path)
        row['kodi_image']=path
    saved={'urls':urls,'rules':rules,'name':name}
    if name==STARTER_NAME:saved['starter_version']=_starter_version()
    write_json(_path(),saved)
    # Only generated badge cache assets are retired after a successful import.
    if os.path.isdir(folder):
        for filename in os.listdir(folder):
            path=os.path.join(folder,filename)
            if re.fullmatch(r'[0-9a-f]{64}\.png',filename) and path not in used:
                try:os.remove(path)
                except OSError:pass
    cached_addon().setSetting(ENABLED,'true');_compiled.clear()
    return status()


def save_pack(data,name=''):
    if len(json.dumps(data).encode('utf-8'))>MAX_BYTES:raise ValueError('Badge JSON is too large.')
    return _commit(normalize(data),[],str(name or 'Imported JSON')[:80])


def save_file(path):
    import xbmcvfs
    handle=xbmcvfs.File(path)
    try:raw=handle.read(MAX_BYTES+1)
    finally:handle.close()
    if len(raw)>MAX_BYTES:raise ValueError('Badge JSON is too large.')
    return save_pack(json.loads(raw),os.path.basename(path))


STARTER_NAME='MegaNexus starter badges'


def starter_pack():
    """7.0.29: the starter set every user has until they import their own - the
    Elite badge pictures of a universal Nuvio pack (Kodi loads them like any
    imported badge), with plain rules for what a source name says."""
    folder=os.path.join(os.path.dirname(os.path.dirname(__file__)),'badges')
    with open(os.path.join(folder,'starter.json'),encoding='utf-8') as handle:data=json.load(handle)
    for row in data['filters']:
        if not _url(row.get('imageURL')):raise ValueError('Invalid starter badge picture.')
    return data


def _starter_version():
    try:return int(starter_pack().get('version') or 1)
    except (OSError,ValueError):return 1


def prepare_rules():
    """Explicit worker action: preserve user imports, migrate a URL, or seed."""
    data=_load()
    if data.get('rules') and data.get('name')==STARTER_NAME and data.get('starter_version')!=_starter_version():
        save_pack(starter_pack(),STARTER_NAME)        # a newer starter set (the user never imported their own)
        data=_load()
    if data.get('rules'):
        # 7.0.29: imports from before Nuvio-style strips lack tagStyle and local
        # copies of web pictures - read the same URLs once more (worker).
        stale=[r for r in data['rules'] if isinstance(r,dict) and 'style' not in r]
        if stale and not _refreshed and data.get('urls'):
            _refreshed.append(1)
            try:
                save(data['urls'])
                return _load().get('rules') or data['rules']
            except ValueError:pass
        return data['rules']
    legacy=cached_addon().getSetting('elite_badges_json_url')
    if legacy:save([legacy])
    else:save_pack(starter_pack(),STARTER_NAME)
    return _load().get('rules') or []


def toggle(on):
    if on:prepare_rules()
    cached_addon().setSetting(ENABLED,'true' if on else 'false')
    return status()


def match(text,rules=None):
    rules=(_load().get('rules') or []) if rules is None else rules
    text=str(text or '')[:2048];normalized=unicodedata.normalize('NFKC',text);result=[];groups=set();meanings=set()
    for row in rules[:768]:
        if not isinstance(row,dict) or not all(isinstance(row.get(k),str) for k in ('group','pattern','name')):continue
        group=row['group'];pattern=row['pattern']
        if group in groups:continue
        compiled=_compiled.get(pattern)
        if compiled is None:
            try:compiled=_compile(pattern)
            except (ValueError,re.error):continue
            if len(_compiled)>=768:_compiled.clear()
            _compiled[pattern]=compiled
        matched=compiled.search(text) or (normalized!=text and compiled.search(normalized))
        if not matched and _marker_pattern(pattern):
            key=(pattern,row['name']);fallback=_fallbacks.get(key)
            if key not in _fallbacks:
                expression=_ordinary_pattern(row['name'])
                fallback=re.compile(expression,re.I) if expression else None
                if len(_fallbacks)>=768:_fallbacks.clear()
                _fallbacks[key]=fallback
            matched=fallback and fallback.search(normalized)
        if matched:
            meaning=_ordinary_pattern(row['name']) or unicodedata.normalize('NFKC',row['name']).casefold()
            if meaning in meanings:continue
            result.append({k:v for k,v in row.items() if k!='pattern'});groups.add(group)
            meanings.add(meaning)
            if len(result)==8:break
    return result


def status(text=EXAMPLE):
    data=_load();urls=data.get('urls') or []
    if not urls and not data.get('rules'):
        legacy=cached_addon().getSetting('elite_badges_json_url')
        if legacy:urls=[legacy]
    return {'enabled':cached_addon().getSetting(ENABLED)=='true','urls':urls,
            'count':len(data.get('rules') or []),'name':data.get('name') or '',
            'marker_rules':sum(_marker_pattern(row.get('pattern')) for row in data.get('rules') or [] if isinstance(row,dict)),
            'example':text,'preview':match(text,data.get('rules') or [])}


def decorate(rows):
    if cached_addon().getSetting(ENABLED)!='true':return rows
    rules=prepare_rules()
    if not rules:return rows
    result=[]
    for original in rows:
        text=' '.join(str(original.get(k) or '') for k in ('name','title','description','filename','label2','badge_blob_raw'))
        text+=' '+str((original.get('behaviorHints') or {}).get('filename') or '')
        result.append(dict(original,_meganexus_badges=match(text,rules)))
    return result
