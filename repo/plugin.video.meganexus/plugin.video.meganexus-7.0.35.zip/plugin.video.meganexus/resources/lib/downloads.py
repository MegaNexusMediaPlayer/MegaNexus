# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Downloads (7.0.29): a source kept on this device's storage.

A long OK on a source in the source list asks "Download this source?". The
download runs in the service, so nothing in the interface, the screensaver or
a film stops it. When the network drops it waits and carries on from the byte
it reached (HTTP Range); into a local folder it also carries on after Kodi
restarts (a network folder - SMB, NFS - starts that file again then).

The queue lives in downloads.json; the running one shows as a blue ring in the
corner by the clock (Window(Home).Property(meganexus.download.*)), and its box
offers "Close · continue" or "Stop".
"""
import json
import os
import re
import threading
import time
import uuid

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

FOLDER_SETTING = 'meganexus_download_folder'
PROFILE = 'special://profile/addon_data/plugin.video.meganexus/'
QUEUE = 'downloads.json'
PROP = 'meganexus.download.'
WAKE = PROP + 'wake'
STOP = PROP + 'stop'
CHUNK = 512 * 1024
TIMEOUT = 20            # seconds without data -> reconnect from the byte reached
BACKOFF_MAX = 30
SAVE_EVERY = 10         # seconds between progress saves
_LOCK = threading.Lock()


# ----------------------------------------------------------------- queue ---

def _queue_path():
    return os.path.join(xbmcvfs.translatePath(PROFILE), QUEUE)


def load():
    try:
        with open(_queue_path(), encoding='utf-8') as handle:
            items = json.load(handle)
        return [i for i in items if isinstance(i, dict) and i.get('id')] if isinstance(items, list) else []
    except (OSError, ValueError):
        return []


def _save(items):
    path = _queue_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temp = path + '.tmp'
    with open(temp, 'w', encoding='utf-8') as handle:
        json.dump(items, handle)
    os.replace(temp, path)


def _update(item_id, **fields):
    with _LOCK:
        items = load()
        for item in items:
            if item['id'] == item_id:
                item.update(fields)
        _save(items)


def folder():
    return xbmcaddon.Addon('plugin.video.meganexus').getSetting(FOLDER_SETTING)


def set_folder(path):
    xbmcaddon.Addon('plugin.video.meganexus').setSetting(FOLDER_SETTING, path or '')


def _safe(text):
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', ' ', str(text or '')).strip(' .')
    return re.sub(r'\s+', ' ', text)[:120] or 'MegaNexus download'


def file_name(ctx, url):
    """'Title (2004).mkv' / 'Show S01E02.mkv'; the extension from the link."""
    title = ctx.get('show_title') or ctx.get('title') or 'MegaNexus download'
    if ctx.get('media_type') == 'series' and ctx.get('season') not in (None, '') and ctx.get('episode') not in (None, ''):
        try:
            base = '%s S%02dE%02d' % (title, int(ctx['season']), int(ctx['episode']))
        except (TypeError, ValueError):
            base = '%s S%sE%s' % (title, ctx['season'], ctx['episode'])
    else:
        base = '%s (%s)' % (title, ctx['year']) if ctx.get('year') else title
    path = url.split('|', 1)[0].split('?', 1)[0].lower()
    ext = next((e for e in ('mkv', 'mp4', 'avi', 'm4v', 'mov', 'ts', 'webm', 'wmv') if path.endswith('.' + e)), 'mkv')
    return _safe(base) + '.' + ext


def downloadable(url):
    """'' or why this source cannot be downloaded."""
    url = str(url or '')
    from .debrid import SCHEME
    if url.startswith(SCHEME):
        return ''          # TorBox / Premiumize direct: the link is asked for when it starts
    if not url.lower().startswith(('http://', 'https://')):
        return 'This source is not a direct link (torrent or add-on link) and cannot be downloaded.'
    if '.m3u8' in url.lower().split('|', 1)[0] or '/hls/' in url.lower():
        return 'This source is a live stream (HLS) and cannot be downloaded.'
    return ''


def add(ctx):
    """Queue the source of a playback context. Returns the new item, raises ValueError."""
    url = str(ctx.get('stream_url') or '')
    why = downloadable(url)
    if why:
        raise ValueError(why)
    target = folder()
    if not target:
        raise ValueError('Choose the download folder first: HUB Settings > Downloads.')
    headers = dict(ctx.get('request_headers') or {})
    from .debrid import SCHEME
    token = url if url.startswith(SCHEME) else ''
    if token:
        url = ''
    elif '|' in url:
        from urllib.parse import parse_qsl
        url, raw = url.split('|', 1)
        headers.update(dict(parse_qsl(raw, keep_blank_values=True)))
    with _LOCK:
        items = load()
        if any((i.get('token') or i.get('url')) == (token or url) and i.get('state') in ('queued', 'downloading') for i in items):
            raise ValueError('This source is already being downloaded.')
        item = {'id': uuid.uuid4().hex[:12], 'title': ctx.get('title') or 'MegaNexus download',
                'name': file_name(ctx, url or str(ctx.get('stream_name') or '')), 'url': url, 'token': token,
                'headers': headers, 'folder': target,
                'state': 'queued', 'done': 0, 'size': 0, 'added': time.time()}
        items.append(item)
        _save(items)
    xbmcgui.Window(10000).setProperty(WAKE, item['id'])
    return item


def stop(item_id):
    """Stop (the running one through the service) and remove it with its partial file."""
    home = xbmcgui.Window(10000)
    if home.getProperty(PROP + 'id') == item_id:
        home.setProperty(STOP, item_id)
        return
    with _LOCK:
        items = load()
        gone = [i for i in items if i['id'] == item_id]
        _save([i for i in items if i['id'] != item_id])
    for item in gone:
        if item.get('state') != 'done':
            _delete_partial(item)


def remove_finished():
    with _LOCK:
        _save([i for i in load() if i.get('state') not in ('done', 'error')])


def _delete_partial(item):
    path = _join(item['folder'], item['name'] + '.part')
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception:
        pass


def _join(base, name):
    base = str(base or '')
    return base + name if base.endswith(('/', '\\')) else base + '/' + name


# ---------------------------------------------------------------- display ---

def _service(token):
    try:
        from .debrid import decode, SERVICES
        return SERVICES.get(decode(token).get('v'), {}).get('name', 'the service')
    except Exception:
        return 'the service'


def human(size):
    size = float(size or 0)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if size < 1024 or unit == 'TB':
            return ('%.0f %s' if unit in ('B', 'KB') else '%.1f %s') % (size, unit)
        size /= 1024.0


def _publish(home, item, done, size, speed, state):
    percent = int(done * 100 / size) if size else 0
    home.setProperty(PROP + 'active', '1')
    home.setProperty(PROP + 'id', item['id'])
    home.setProperty(PROP + 'title', item.get('title') or item['name'])
    home.setProperty(PROP + 'name', item['name'])
    home.setProperty(PROP + 'percent', str(percent))
    # the loading screen's rings: ring_00..ring_19, ring_done at the end
    home.setProperty(PROP + 'ring', 'done' if percent >= 100 else '%02d' % min(19, percent // 5))
    home.setProperty(PROP + 'done', human(done))
    home.setProperty(PROP + 'size', human(size) if size else '')
    home.setProperty(PROP + 'speed', (human(speed) + '/s') if speed > 0 else '')
    left = (size - done) / speed if speed > 0 and size else 0
    home.setProperty(PROP + 'eta', ('%d min' % max(1, round(left / 60.0))) if left >= 60 else ('%d s' % left) if left else '')
    home.setProperty(PROP + 'state', state)
    waiting = len([i for i in load() if i.get('state') == 'queued' and i['id'] != item['id']])
    home.setProperty(PROP + 'queue', ('%d more waiting' % waiting) if waiting else '')


def _clear(home):
    for key in ('active', 'id', 'title', 'name', 'percent', 'ring', 'done', 'size', 'speed', 'eta', 'state', 'queue'):
        home.clearProperty(PROP + key)


# ---------------------------------------------------------------- service ---

class _Stopped(Exception):
    pass


class _Gone(Exception):
    """The server refused for good (an expired link)."""


def _writer(item, restart):
    """(write(bytes), close(), bytes already there, local?) for the .part file."""
    part = _join(item['folder'], item['name'] + '.part')
    local_dir = xbmcvfs.translatePath(item['folder'])
    if not str(item['folder']).startswith(('smb://', 'nfs://', 'ftp://', 'sftp://', 'dav://', 'davs://', 'upnp://')):
        try:
            os.makedirs(local_dir, exist_ok=True)
        except OSError:
            pass
    if os.path.isdir(local_dir):
        path = os.path.join(local_dir, item['name'] + '.part')
        if restart and os.path.exists(path):
            os.remove(path)
        handle = open(path, 'ab')
        return handle.write, handle.close, handle.tell(), True
    if not xbmcvfs.exists(item['folder'] if item['folder'].endswith('/') else item['folder'] + '/'):
        xbmcvfs.mkdirs(item['folder'])
    handle = xbmcvfs.File(part, 'w')        # a network folder: from the start
    return handle.write, handle.close, 0, False


def _finish(item):
    part = _join(item['folder'], item['name'] + '.part')
    final = _join(item['folder'], item['name'])
    local_dir = xbmcvfs.translatePath(item['folder'])
    if os.path.isdir(local_dir):
        os.replace(os.path.join(local_dir, item['name'] + '.part'), os.path.join(local_dir, item['name']))
    else:
        if xbmcvfs.exists(final):
            xbmcvfs.delete(final)
        xbmcvfs.rename(part, final)


def _download(item, monitor, home):
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    import http.client
    import socket
    write = close = None
    done, size, local = 0, int(item.get('size') or 0), True
    backoff, last_save, speed = 2, time.monotonic(), 0.0
    restart = False
    resolves = 0
    _update(item['id'], state='downloading')
    try:
        while not monitor.abortRequested():
            if home.getProperty(STOP) == item['id']:
                raise _Stopped()
            try:
                if item.get('token') and not item.get('url'):
                    # TorBox / Premiumize direct: the service gives the link now (again
                    # when an old one expired).
                    _publish(home, item, done, size, 0, 'Asking %s for the link…' % _service(item['token']))
                    from .debrid import resolve
                    try:
                        item['url'] = resolve(item['token'], monitor=monitor)
                    except ValueError as exc:
                        raise _Gone(str(exc))
                    resolves += 1
                    _update(item['id'], url=item['url'])
                if write is None:
                    write, close, done, local = _writer(item, restart)
                    restart = False
                headers = dict(item.get('headers') or {})
                headers.setdefault('User-Agent', 'Mozilla/5.0 (MegaNexus)')
                if done:
                    headers['Range'] = 'bytes=%d-' % done
                _publish(home, item, done, size, 0, 'Connecting…')
                with urlopen(Request(item['url'], headers=headers), timeout=TIMEOUT) as response:
                    status = getattr(response, 'status', 200)
                    if done and status == 200:
                        # The server cannot resume: the file starts again.
                        close()
                        write = None
                        restart = True
                        done = 0
                        continue
                    found = re.search(r'/(\d+)\s*$', response.headers.get('Content-Range') or '')
                    length = int(response.headers.get('Content-Length') or 0)
                    size = int(found.group(1)) if found else (done + length if length else size)
                    _update(item['id'], size=size)
                    backoff, window_start, window_bytes = 2, time.monotonic(), 0
                    while True:
                        if monitor.abortRequested():
                            return
                        if home.getProperty(STOP) == item['id']:
                            raise _Stopped()
                        chunk = response.read(CHUNK)
                        if not chunk:
                            break
                        write(chunk)
                        done += len(chunk)
                        window_bytes += len(chunk)
                        now = time.monotonic()
                        if now - window_start >= 1.0:
                            rate = window_bytes / (now - window_start)
                            speed = rate if not speed else speed * 0.7 + rate * 0.3
                            window_start, window_bytes = now, 0
                            _publish(home, item, done, size, speed, 'Downloading')
                        if now - last_save >= SAVE_EVERY:
                            last_save = now
                            _update(item['id'], done=done)
                if size and done < size:
                    raise http.client.IncompleteRead(b'', size - done)   # the connection ended early
                close()
                write = None
                _finish(item)
                _update(item['id'], state='done', done=done, size=size or done)
                xbmc.log('[MegaNexus] Download finished: %s' % item['name'], xbmc.LOGINFO)
                xbmcgui.Dialog().notification('Download finished', item.get('title') or item['name'],
                                              xbmcgui.NOTIFICATION_INFO, 5000)
                return
            except HTTPError as exc:
                if exc.code == 416 and size and done >= size:
                    if close:
                        close()
                    write = None
                    _finish(item)
                    _update(item['id'], state='done', done=done)
                    return
                if exc.code in (408, 425, 429) or exc.code >= 500:
                    pass                                     # try again below
                elif item.get('token') and resolves < 3:
                    item['url'] = ''                         # an expired debrid link: ask again
                    _update(item['id'], url='')
                    continue
                else:
                    raise _Gone('The link expired or was refused (%d). Start the download again from the sources.' % exc.code)
            except (OSError, socket.timeout, http.client.HTTPException, ValueError) as exc:
                xbmc.log('[MegaNexus] Download waits for the network: %s' % exc, xbmc.LOGDEBUG)
            # No network / the connection broke: wait, then carry on from the byte reached.
            _update(item['id'], done=done)
            _publish(home, item, done, size, 0, 'Waiting for the network…')
            until = time.monotonic() + backoff
            backoff = min(BACKOFF_MAX, backoff * 2)
            while time.monotonic() < until:
                if monitor.waitForAbort(0.5) or home.getProperty(STOP) == item['id']:
                    break
    except _Stopped:
        if close:
            close()
        write = None
        with _LOCK:
            _save([i for i in load() if i['id'] != item['id']])
        _delete_partial(item)
        home.clearProperty(STOP)
        xbmc.log('[MegaNexus] Download stopped: %s' % item['name'], xbmc.LOGINFO)
    except _Gone as exc:
        if write is not None and close:
            close()
        write = None
        _update(item['id'], state='error', error=str(exc), done=done)
        xbmcgui.Dialog().notification('Download stopped', str(exc), xbmcgui.NOTIFICATION_WARNING, 6000)
    finally:
        if write is not None and close:
            try:
                close()
            except Exception:
                pass
            if not local:
                _update(item['id'], done=0)          # a network folder starts again next time
            else:
                _update(item['id'], done=done)


def run(monitor):
    """The service's download thread."""
    home = xbmcgui.Window(10000)
    xbmc.log('[MegaNexus] Downloads ready.', xbmc.LOGINFO)
    while not monitor.abortRequested():
        try:
            item = next((i for i in load() if i.get('state') in ('downloading', 'queued')), None)
            if item:
                _download(item, monitor, home)
                continue
            _clear(home)
        except Exception:
            import traceback
            xbmc.log('[MegaNexus] Downloads: ' + traceback.format_exc(), xbmc.LOGWARNING)
            _clear(home)
            if monitor.waitForAbort(10):
                break
        home.clearProperty(WAKE)
        for _ in range(20):                               # 2 s, or at once for a new one
            if monitor.waitForAbort(0.1) or home.getProperty(WAKE):
                break
    _clear(home)
