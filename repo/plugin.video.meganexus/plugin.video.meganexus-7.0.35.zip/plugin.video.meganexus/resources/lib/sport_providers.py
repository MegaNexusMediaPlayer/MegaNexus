# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Sport switches per add-on (7.0.20), like the subtitle ones.

An add-on with sport catalogs (a sports add-on, or AIOMetadata's sport
catalogs) can be left out of the Sport screen on its own, whatever else it
serves. Until the user changes one, every sport add-on is on, and add-ons
added later start on too.
"""
from . import addon_switches

SETTING = 'meganexus_sport_providers'


def candidates(providers=None):
    from .meganexus import store
    from .sports import offers_sport
    providers = store.list_providers() if providers is None else providers
    return [p for p in providers if p.get('id') and offers_sport(p)]


def entries(providers=None):
    return addon_switches.entries(SETTING, candidates(providers))


def enabled_ids(providers=None):
    return {p['id'] for p, on in entries(providers) if on}


def set_enabled(provider_id, on):
    addon_switches.set_enabled(SETTING, entries(), provider_id, on, 'This add-on has no sport catalogs.')
