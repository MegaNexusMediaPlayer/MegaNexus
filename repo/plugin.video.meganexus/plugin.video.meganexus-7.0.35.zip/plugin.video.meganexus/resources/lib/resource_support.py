# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Stremio capability/identity checks shared by metadata and stream routing.

Resource objects have their own filters. Missing idPrefixes on an object means
all IDs, NOT inheritance from the manifest (SDK manifest specification).
"""
import re


def supports(provider, resource_name, media_type, content_id=''):
    manifest = provider.get('manifest') or {}
    for resource in manifest.get('resources') or []:
        if isinstance(resource, dict):
            if resource.get('name') != resource_name:
                continue
            types = resource.get('types')
            prefixes = resource.get('idPrefixes')
        elif resource == resource_name:
            types = manifest.get('types')
            prefixes = manifest.get('idPrefixes')
        else:
            continue
        if types is not None and (not isinstance(types, list) or media_type not in types):
            continue
        if prefixes is not None and (not isinstance(prefixes, list) or
                not any(isinstance(prefix, str) and str(content_id).startswith(prefix) for prefix in prefixes)):
            continue
        return True
    return False


def media_type(value):
    value = str(value or '')
    return 'series' if value in ('tv', 'show', 'tvshow', 'episode') else value


# 7.0.31: every external id an add-on states for the title it returns. AIOMetadata
# names them _imdbId, _tmdbId, _tvdbId, _malId, _kitsuId, _anilistId ...; an
# anime title asked for by its MAL / Kitsu id was refused ("Retry details").
_ID_FIELD = re.compile(r'^_?([a-z]+?)(?:_?id)$', re.I)
_FAMILIES = {'imdb', 'tmdb', 'moviedb', 'tvdb', 'mal', 'myanimelist', 'kitsu', 'anilist', 'anidb', 'tvmaze', 'trakt', 'simkl'}
_FAMILY_NAMES = {'moviedb': 'tmdb', 'myanimelist': 'mal'}


def _kind_matches(found, asked):
    found, asked = media_type(found), media_type(asked)
    # A catalog may file a title under "anime" while its details say series or movie.
    return found == asked or 'anime' in (found, asked)


def same_identity(meta, kind, content_id):
    """Allow only exact IDs or explicit provider-declared external-ID aliases."""
    if not isinstance(meta, dict):
        return False
    if meta.get('type') and not _kind_matches(meta['type'], kind):
        return False
    aliases = {str(meta.get('id') or '')}
    ids = meta.get('ids') if isinstance(meta.get('ids'), dict) else {}
    pairs = [(name, value) for name, value in meta.items() if isinstance(name, str)]
    pairs += [(name + '_id', value) for name, value in ids.items() if isinstance(name, str)]
    for name, value in pairs:
        found = _ID_FIELD.match(name)
        if not found or value is None or isinstance(value, (dict, list, bool)) or str(value) == '':
            continue
        family = found.group(1).lower()
        if family not in _FAMILIES:
            continue
        family = _FAMILY_NAMES.get(family, family)
        value = str(value)
        aliases.add(value if family == 'imdb' or value.startswith(family + ':') else family + ':' + value)
    return str(content_id) in aliases and bool(content_id)
