# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Best stream first, by the user's preferences (7.0.12).

Every stream row (add-ons, TorBox) is read for resolution, size, Dolby Vision /
HDR, audio, cached state and CAM releases, then ordered so the first row is
the one Autoplay starts and the top of the source list. Nothing is hidden:
rows over the size limit or above the resolution limit only move down, so a
title with nothing inside the limits still plays. The user's own Plex /
Jellyfin copies stay first. HUB Settings > Playback > Automatic stream choice.
"""
import re

SORT = 'stream_sort_prefs'           # on: order by these preferences
MAX_RES = 'stream_max_res'           # 4k | 1080p | 720p
MOVIE_GB = 'stream_movie_max_gb'     # 0 = no limit
EPISODE_GB = 'stream_episode_max_gb'
DOLBY_VISION = 'stream_dolby_vision'  # prefer | neutral | avoid
HDR = 'stream_hdr'                   # prefer | neutral
CACHED = 'stream_prefer_cached'      # debrid: cached (instant) first

RES_CHOICES = ('4k', '1080p', '720p')
RES_LABELS = {'4k': 'Up to 4K', '1080p': 'Up to 1080p', '720p': 'Up to 720p'}
MOVIE_GB_CHOICES = ('0', '5', '10', '15', '20', '30', '50')
EPISODE_GB_CHOICES = ('0', '1', '2', '3', '5', '8', '10')
DV_CHOICES = ('prefer', 'neutral', 'avoid')
DV_LABELS = {'prefer': 'Prefer Dolby Vision', 'neutral': 'No preference', 'avoid': 'Avoid Dolby Vision'}
HDR_CHOICES = ('prefer', 'neutral')
HDR_LABELS = {'prefer': 'Prefer HDR', 'neutral': 'No preference'}
RES_RANK = {'4k': 4, '1080p': 3, '720p': 2}

_RES = ((4, re.compile(r'(?<!\d)(?:2160p?|4k|uhd)(?!\d)', re.I)), (3, re.compile(r'(?<!\d)1080[pi]?(?!\d)', re.I)),
        (2, re.compile(r'(?<!\d)720p?(?!\d)', re.I)), (1, re.compile(r'(?<!\d)(?:480p?|576p?|360p?)(?!\d)|\bsd\b', re.I)))
_DV = re.compile(r'\b(?:dolby[ ._-]?vision|dovi|dv)\b', re.I)
_HDR = re.compile(r'\b(?:hdr10\+?|hdr|hlg)\b', re.I)
_CAM = re.compile(r'\b(?:cam|camrip|hdcam|ts|telesync|hdts|tc|telecine|scr|screener)\b', re.I)
_CACHED = re.compile(r'⚡|\[(?:rd|ad|pm|tb|ed|dl|oc|pp)\+\]|\bcached\b|\binstant\b', re.I)
_UNCACHED = re.compile(r'⏳|\[(?:rd|ad|pm|tb|ed|dl)\s*(?:download|⏳)\]|\bnot cached\b|\buncached\b|\bdownload\b', re.I)
_SIZE = re.compile(r'(\d+(?:[.,]\d+)?)\s*(TB|GB|GiB|MB|MiB)\b', re.I)
# 7.0.29: the best audio first - TrueHD Atmos, DTS:X / DTS-HD MA, Atmos (DD+), lossless
# TrueHD / DTS-HD, DD+ / 7.1, DTS / AC3 5.1.
_AUDIO = ((6, re.compile(r'\btruehd\b.*\batmos\b|\batmos\b.*\btruehd\b', re.I)),
          (5, re.compile(r'\bdts[ ._:-]?x\b|\bdts[ ._-]?hd[ ._-]?ma\b|\bdts[ ._-]?ma\b', re.I)),
          (4, re.compile(r'\batmos\b', re.I)),
          (3, re.compile(r'\btruehd\b|\bdts[ ._-]?hd\b|\blpcm\b|\bflac\b', re.I)),
          (2, re.compile(r'\b(?:dd\+|ddp|eac3|e-ac-3)|\b7[ .]1\b', re.I)),
          (1, re.compile(r'\bdts\b|\bac3\b|\bdd(?:5[ .]?1)?\b|\b5[ .]1\b', re.I)))
# 7.0.29: the release's source - REMUX, Blu-ray, WEB-DL, WEBRip, TV / DVD.
_SOURCE = ((6, re.compile(r'\b(?:bd|uhd|bluray|blu[ ._-]?ray)?[ ._-]?remux\b', re.I)),
           (5, re.compile(r'\b(?:blu[ ._-]?ray|bluray|bdrip|brrip|bd(?:25|50|66|100)?|uhd[ ._-]?bd)\b', re.I)),
           (4, re.compile(r'\bweb[ ._-]?dl\b|\bwebdl\b|\b(?:amzn|nf|dsnp|atvp|hmax|max|pcok|hulu)[ ._-]web\b', re.I)),
           (3, re.compile(r'\bweb[ ._-]?rip\b|\bweb\b', re.I)),
           (2, re.compile(r'\bhdtv\b|\bpdtv\b|\bdvd(?:rip|5|9)?\b|\bhdrip\b', re.I)))
# Add-ons decorate names with invisible joiners and look-alike brackets ("Web\u200d-\u200ddl").
_INVISIBLE = re.compile('[\u00ad\u200b-\u200f\u2060-\u2064\ufeff]')


def _setting(addon, name, default):
    try:
        return (addon.getSetting(name) or default).strip().lower()
    except Exception:
        return default


def preferences(addon=None):
    if addon is None:
        from .settings_cache import cached_addon
        addon = cached_addon()
    def number(name):
        try:
            return float(_setting(addon, name, '0'))
        except ValueError:
            return 0.0
    return {'sort': _setting(addon, SORT, 'true') != 'false',
            'max_res': RES_RANK.get(_setting(addon, MAX_RES, '4k'), 4),
            'movie_gb': number(MOVIE_GB), 'episode_gb': number(EPISODE_GB),
            'dv': _setting(addon, DOLBY_VISION, 'neutral'), 'hdr': _setting(addon, HDR, 'prefer'),
            'cached': _setting(addon, CACHED, 'true') != 'false'}


def _text(row):
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    text = ' '.join(str(x or '') for x in (row.get('name'), row.get('title'), row.get('description'), hints.get('filename')))
    text = _INVISIBLE.sub('', text).replace('\u00a0', ' ')
    return text.translate({0x3008: '[', 0x3009: ']', 0x2010: '-', 0x2011: '-', 0x2012: '-', 0x2013: '-'})


def size_bytes(row, text=None):
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    for value in (hints.get('videoSize'), row.get('size')):
        try:
            if value and float(value) > 0:
                return float(value)
        except (TypeError, ValueError):
            pass
    match = _SIZE.search(text if text is not None else _text(row))
    if not match:
        return 0.0
    number = float(match.group(1).replace(',', '.'))
    unit = match.group(2).upper()
    return number * {'TB': 1e12, 'GB': 1e9, 'GIB': 1073741824, 'MB': 1e6, 'MIB': 1048576}[unit]


def traits(row):
    text = _text(row)
    resolution = next((rank for rank, pattern in _RES if pattern.search(text)), 0)
    cached = row.get('meganexus_cached')
    if cached is None:
        cached = True if _CACHED.search(text) else (False if _UNCACHED.search(text) else None)
    return {'res': resolution, 'size': size_bytes(row, text), 'dv': bool(_DV.search(text)),
            'hdr': bool(_HDR.search(text)) or bool(_DV.search(text)), 'cam': bool(_CAM.search(text)),
            'cached': cached, 'audio': next((score for score, pattern in _AUDIO if pattern.search(text)), 0),
            'source': next((score for score, pattern in _SOURCE if pattern.search(text)), 0)}


def score(row, prefs, episode):
    t = traits(row)
    limit = (prefs['episode_gb'] if episode else prefs['movie_gb']) * 1e9
    within_size = not limit or not t['size'] or t['size'] <= limit
    within_res = not t['res'] or t['res'] <= prefs['max_res']
    dv = (1 if prefs['dv'] == 'prefer' else -1 if prefs['dv'] == 'avoid' else 0) if t['dv'] else 0
    hdr = 1 if (prefs['hdr'] == 'prefer' and t['hdr']) else 0
    cached = (1 if t['cached'] else (-1 if t['cached'] is False else 0)) if prefs['cached'] else 0
    # 7.0.29: at the same resolution the better release first (REMUX, Blu-ray, WEB-DL...),
    # then Dolby Vision / HDR, the better audio, and the bigger file.
    return (not t['cam'], within_size, within_res, cached, t['res'] if within_res else 0, t['source'], dv, hdr, t['audio'], t['size'])


def order(rows, media_type='movie', prefs=None):
    """Best first; the user's own servers stay on top; ties keep add-on order."""
    prefs = prefs or preferences()
    if not prefs['sort']:
        return list(rows or [])
    episode = str(media_type or '').lower() not in ('movie', 'movies')
    own = [r for r in rows or [] if r.get('_meganexus_server')]
    rest = [r for r in rows or [] if not r.get('_meganexus_server')]
    ranked = sorted(enumerate(rest), key=lambda pair: (score(pair[1], prefs, episode), -pair[0]), reverse=True)
    return own + [row for _, row in ranked]
