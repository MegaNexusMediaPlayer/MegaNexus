# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Install our UI, skin and screensaver packages, with hashes and rollback."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
import zipfile

from .legacy_names import OLD_ADDON_ID

ALLOWED = {'script.meganexus', 'skin.meganexus', 'screensaver.meganexus'}
# The service's automatic install and the GitHub updater share one process.
_INSTALL_LOCK = threading.Lock()
# 7.0.25: Windows refuses to rename a folder while any file in it is open -
# typically the antivirus scanning the files just unpacked (7.0.24 added fonts
# and icons) or Kodi still reading the old copy. Such a lock lasts moments.
MOVE_ATTEMPTS = 12
MOVE_PAUSE = .5


def _move(src, dst, attempts=None, pause=None):
    """os.replace, tried again for a while when the folder is locked (Windows)."""
    attempts = MOVE_ATTEMPTS if attempts is None else attempts
    pause = MOVE_PAUSE if pause is None else pause
    for attempt in range(attempts):
        try:
            os.replace(src, dst);return
        except PermissionError:
            if attempt == attempts - 1:raise
            time.sleep(min(2.0, pause * (attempt + 1)))


def validate_archive(path, addon_id, version, sha256):
    if addon_id not in ALLOWED: raise ValueError('Unknown bundle component')
    if hashlib.sha256(Path(path).read_bytes()).hexdigest() != sha256:
        raise ValueError('Bundle checksum mismatch')
    with zipfile.ZipFile(path) as archive:
        total=0
        for info in archive.infolist():
            parts=info.filename.replace('\\','/').split('/')
            if parts[0]!=addon_id or any(p in ('..','.') for p in parts) or any(p=='' for p in parts[:-1]) or ':' in info.filename:
                raise ValueError('Unsafe bundle path')
            if (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Bundle links are not allowed')
            total+=info.file_size
            if total>150_000_000:raise ValueError('Bundle is too large')
        root=ET.fromstring(archive.read(addon_id+'/addon.xml'))
        if root.get('id')!=addon_id or root.get('version')!=version:
            raise ValueError('Bundle identity mismatch')


def installed_version(directory):
    try:return ET.parse(Path(directory)/'addon.xml').getroot().get('version','')
    except (OSError,ET.ParseError):return ''


def installed_matches(directory,row):
    try:
        return installed_version(directory)==row['version'] and (Path(directory)/'.meganexus-bundle-sha256').read_text(encoding='ascii').strip()==row['sha256']
    except OSError:return False


def install_components(packages, addons_dir, backup_dir, force=False):
    """Filesystem-only seam. Existing user profiles are never touched."""
    with _INSTALL_LOCK:
        return _install_components(packages, addons_dir, backup_dir, force)


def outdated(packages, addons_dir):
    """Bundled components whose installed copy differs from this backend's packages."""
    try:desired=json.loads((Path(packages)/'bundle.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):return []
    return [r['id'] for r in desired if isinstance(r,dict) and r.get('id') in ALLOWED
            and not installed_matches(Path(addons_dir)/r['id'],r)]


def _install_components(packages, addons_dir, backup_dir, force=False):
    packages,addons_dir,backup_dir=Path(packages),Path(addons_dir),Path(backup_dir)
    manifest=json.loads((packages/'bundle.json').read_text(encoding='utf-8'))
    if not isinstance(manifest,list) or {r.get('id') for r in manifest}!=ALLOWED or len(manifest)!=len(ALLOWED):
        raise ValueError('Incomplete bundle')
    pending=[]
    for row in manifest:
        if row.get('file')!=row['id']+'.zip':raise ValueError('Invalid package filename')
        validate_archive(packages/row['file'],row['id'],row['version'],row['sha256'])
        if force or not installed_matches(addons_dir/row['id'],row):pending.append(row)
    if not pending:return []
    addons_dir.mkdir(parents=True,exist_ok=True)
    stage=Path(tempfile.mkdtemp(prefix='.meganexus-stage-',dir=str(addons_dir)))
    backup=backup_dir/str(time.time_ns())
    changed=[];backed_up=[]
    try:
        for row in pending:
            with zipfile.ZipFile(packages/row['file']) as archive:archive.extractall(stage)
            (stage/row['id']/'.meganexus-bundle-sha256').write_text(row['sha256'],encoding='ascii')
        backup.mkdir(parents=True,exist_ok=True)
        for row in pending:
            aid=row['id'];target=addons_dir/aid
            if target.is_symlink():raise ValueError('An installed component is a link')
            if target.exists():
                _move(target,backup/aid);backed_up.append(aid)
            _move(stage/aid,target);changed.append(aid)
        return changed
    except Exception:
        for aid in reversed(changed):
            # These are exact allowlisted folders created in this transaction.
            target=addons_dir/aid
            if target.exists():_move(target,stage/(aid+'.failed'))
        for aid in reversed(backed_up):_move(backup/aid,addons_dir/aid)
        raise
    finally:
        if stage.parent.resolve()==addons_dir.resolve() and stage.name.startswith('.meganexus-stage-'):
            # A file still held open (Windows) must not turn a finished install
            # into a failure; Kodi ignores the hidden leftover folder.
            shutil.rmtree(stage,ignore_errors=True)


def paths():
    import xbmcaddon
    import xbmcvfs
    addon=xbmcaddon.Addon('plugin.video.meganexus')
    return (Path(addon.getAddonInfo('path'))/'resources/packages', Path(xbmcvfs.translatePath('special://home/addons')))


VERSION_SETTING='meganexus_components_for'  # backend version whose components were installed


def backend_version(packages):
    try:return ET.parse(Path(packages).parents[1]/'addon.xml').getroot().get('version','')
    except (OSError,ET.ParseError):return ''


def component_report(packages=None, addons_dir=None):
    """Per bundled component: the version this backend brings ('wanted'), the
    one on disk ('files') and the one Kodi has loaded ('kodi'). 6.0.36: the
    update check compared only the backend, so a device with an updated
    backend but an old interface said "up to date"."""
    import xbmcaddon
    if packages is None or addons_dir is None:
        packages, addons_dir = paths()
    try:desired=json.loads((Path(packages)/'bundle.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):return []
    report=[]
    for row in desired:
        if not isinstance(row,dict) or row.get('id') not in ALLOWED:continue
        try:kodi=xbmcaddon.Addon(row['id']).getAddonInfo('version')
        except Exception:kodi=''
        report.append({'id':row['id'],'wanted':row.get('version',''),
                       'files':installed_version(Path(addons_dir)/row['id']),'kodi':kodi,
                       'current':installed_matches(Path(addons_dir)/row['id'],row)})
    return report


def auto_install(monitor, busy=lambda: False, wait=10, retry=30, attempts=2880, failures_allowed=5):
    """Service: after the backend was installed or updated (Kodi repository,
    ZIP or GitHub), install the bundled interface, skin and screensaver without
    "Install or repair". Once a backend version has installed them, a component
    the user uninstalled is NOT put back (only the next update reinstalls).
    Waits while video plays, the interface is open or a removal runs - up to
    ``attempts`` rounds of ``retry`` seconds (24 h; it was 1 h, 6.0.36) - and a
    failed install is retried (``failures_allowed``) instead of ending the run."""
    import xbmc
    import xbmcaddon
    import xbmcgui
    if monitor.waitForAbort(wait):return []
    addon=xbmcaddon.Addon('plugin.video.meganexus')
    failures=0
    for _ in range(attempts):
        packages,addons_dir=paths()
        version=backend_version(packages)
        home=xbmcgui.Window(10000)
        if home.getProperty('meganexus.uninstalling'):return []
        if version and addon.getSetting(VERSION_SETTING)==version:return []
        if not outdated(packages,addons_dir):
            addon.setSetting(VERSION_SETTING,version);return []
        if not xbmc.Player().isPlayingVideo() and not home.getProperty('meganexus.frontend.running') and not busy():
            previous=addon.getSetting(VERSION_SETTING)
            try:changed=ensure_components()
            except Exception as exc:
                failures+=1
                xbmc.log('[MegaNexus] Component install attempt %d failed: %s'%(failures,exc),xbmc.LOGWARNING)
                if failures>=failures_allowed or monitor.waitForAbort(retry):return []
                continue
            addon.setSetting(VERSION_SETTING,version)
            if changed:
                xbmcgui.Dialog().notification('MegaNexus','Interface, skin and screensaver updated',xbmcgui.NOTIFICATION_INFO,5000)
                if previous:
                    # An update replaced components while Kodi was running: parts
                    # of the old ones stay loaded (e.g. the small trailer video on
                    # Android) until a restart. Same question as the GitHub updater.
                    from . import updater
                    updater.mark_pending(addon,version)
                    updater.prompt_when_safe(addon,monitor)
            return changed
        if monitor.waitForAbort(retry):return []
    return []


def ensure_components(force=False):
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    addon=xbmcaddon.Addon('plugin.video.meganexus')
    packages=Path(addon.getAddonInfo('path'))/'resources/packages'
    addons_dir=Path(xbmcvfs.translatePath('special://home/addons'))
    desired=json.loads((packages/'bundle.json').read_text(encoding='utf-8'))
    needs_change=force or any(not installed_matches(addons_dir/r['id'],r) for r in desired)
    if needs_change and xbmc.Player().isPlayingVideo():
        raise RuntimeError('Stop playback before installing or updating the MegaNexus interface.')
    if needs_change and xbmcgui.Window(10000).getProperty('meganexus.frontend.running'):
        raise RuntimeError('Close the MegaNexus interface and restart Kodi before updating the bundled components.')
    changed=install_components(packages,addons_dir,Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))/'installation-backups',force)
    xbmc.executebuiltin('UpdateLocalAddons')
    monitor=xbmc.Monitor()
    versions={r['id']:r.get('version','') for r in desired}
    for aid in ('script.meganexus','skin.meganexus','screensaver.meganexus'):
        found=None
        for attempt in range(60):  # slow boxes need up to ~30 s to discover new add-ons
            result=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.GetAddonDetails','params':{'addonid':aid,'properties':['enabled','version']}})))
            found=(result.get('result') or {}).get('addon') if isinstance(result.get('result'),dict) else None
            # 6.0.33: wait for the NEW version, not just any. The skin requires
            # script.meganexus of the same version; with the old one still loaded
            # Kodi dropped the skin at the next start.
            if found and (not versions.get(aid) or not found.get('version') or found.get('version')==versions[aid]):break
            if found and attempt>=20:break  # still the old version after 10 s: the restart loads it
            if monitor.waitForAbort(0.5):return changed
        if not found:raise RuntimeError('Kodi has not discovered '+aid+'. Restart Kodi and reopen MegaNexus.')
        if found.get('version') and versions.get(aid) and found['version']!=versions[aid]:
            xbmc.log('[MegaNexus] Kodi still reports %s %s (installed %s); a restart loads it.'%(aid,found['version'],versions[aid]),xbmc.LOGWARNING)
            changed=list(changed) if changed else []
            if aid not in changed:changed.append(aid)  # triggers the restart question after updates
        enabled=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':aid,'enabled':True}})))
        if enabled.get('error'):raise RuntimeError('Kodi could not enable '+aid+'. Restart Kodi and retry.')
    # The original service uses some of the same legacy playback property names.
    # The profile has already been copied read-only by default.py; preserve its data.
    if not xbmc.Player().isPlayingVideo():
        old=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.GetAddonDetails',
            'params':{'addonid':OLD_ADDON_ID,'properties':['enabled']}})))
        if old.get('result',{}).get('addon',{}).get('enabled'):
            xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled',
                'params':{'addonid':OLD_ADDON_ID,'enabled':False}}))
    if addon.getSetting('meganexus_screensaver_applied')!='true':
        result=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Settings.SetSettingValue','params':{'setting':'screensaver.mode','value':'screensaver.meganexus'}})))
        if not result.get('error'):addon.setSetting('meganexus_screensaver_applied','true')
    if 'skin.meganexus' in changed and xbmc.getSkinDir()=='skin.meganexus':
        xbmc.executebuiltin('ReloadSkin')
    return changed
