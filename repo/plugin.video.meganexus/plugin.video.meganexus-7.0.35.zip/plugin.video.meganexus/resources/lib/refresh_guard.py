# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""No display mode switch for small preview videos (6.0.35, GitHub issue #4).

With Kodi's "Adjust display refresh rate" on, starting a trailer or a Sports
preview switched the TV's mode. On some CoreELEC builds (Dolby Vision
avdvplus) a video in a small window then stays black - audio only - and the
GUI hangs. While a preview plays the setting is turned off and afterwards put
back. When the setting is already off nothing is touched, so devices that
work today keep working exactly the same way. The original value is also
kept in the add-on settings, so the service restores it after a crash.
"""
import json
import xbmc

SETTING = 'videoplayer.adjustrefreshrate'
STORE = 'meganexus_refresh_restore'          # original value while suspended
PROPERTY = 'meganexus.refresh.suspended'     # Window(Home): previews holding it


def _rpc(method, params):
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    except (TypeError, ValueError):
        return None
    return reply.get('result') if isinstance(reply, dict) else None


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.meganexus')


def _home():
    import xbmcgui
    return xbmcgui.Window(10000)


def _holders(home):
    raw = home.getProperty(PROPERTY)
    if not raw:
        return []
    if raw == '1':
        return ['preview']                       # a hold written before 7.0.29
    try:
        value = json.loads(raw)
    except ValueError:
        return ['preview']
    return [str(v) for v in value] if isinstance(value, list) else ['preview']


def _store(home, holders):
    if holders:
        home.setProperty(PROPERTY, json.dumps(sorted(set(holders))))
    else:
        home.clearProperty(PROPERTY)


def suspend(holder='preview'):
    """Before a small-window video starts. Returns True while the setting is held off.

    7.0.29: every holder is counted (video wallpaper, Home previews, trailers,
    Sport); the setting comes back only when the last one lets go - a trailer
    ending no longer switched it on under the running wallpaper, nor the
    wallpaper stopping under a starting trailer.
    """
    home = _home()
    holders = _holders(home)
    if holders:
        _store(home, holders + [holder])
        return True
    result = _rpc('Settings.GetSettingValue', {'setting': SETTING}) or {}
    value = result.get('value')
    if not value:
        return False  # off (0) or unknown: nothing to do
    _addon().setSetting(STORE, str(value))
    if _rpc('Settings.SetSettingValue', {'setting': SETTING, 'value': 0}) is None:
        _addon().setSetting(STORE, '')
        return False
    _store(home, [holder])
    return True


def restore(holder='preview', force=False):
    """A holder lets go (cheap when nothing was held). The setting comes back
    when no holder is left. ``force`` releases every hold: service start (a
    crash left one behind) and right before real playback (release_all)."""
    home = _home()
    holders = _holders(home)
    if not force:
        if not holders:
            return False
        holders = [h for h in holders if h != holder]
        if holders:
            _store(home, holders)
            return False
    addon = _addon()
    stored = addon.getSetting(STORE)
    if not stored and not holders and not home.getProperty(PROPERTY):
        return False
    _store(home, [])
    addon.setSetting(STORE, '')
    if stored:
        try:
            _rpc('Settings.SetSettingValue', {'setting': SETTING, 'value': int(stored)})
        except ValueError:
            return False
    return True


def release_all():
    """7.0.29: right BEFORE a film, an episode or a channel starts. Kodi picks the
    TV's refresh rate when playback opens: restored after the start (as before),
    the film ran at the menu's rate - judder - and the setting looked "off"."""
    return restore(force=True)
