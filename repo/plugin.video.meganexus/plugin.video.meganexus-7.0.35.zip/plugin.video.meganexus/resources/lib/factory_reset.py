# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Reset MegaNexus to a new installation (7.0.21).

HUB Settings > Maintenance & updates > Reset MegaNexus erases every MegaNexus
setting and saved file: add-ons, collections, accounts and keys, preferences,
Continue Watching and the caches (the add-on data of the four MegaNexus
add-ons). Kodi keeps settings in memory and running services write their
files, so the request only leaves a marker and restarts Kodi; the next start
erases the data first thing (service.py and the interface entry point), before
anything reads a setting. MegaNexus then starts like a new installation.
"""
import os

import xbmc

MARKER = 'special://profile/meganexus_factory_reset'


def _path(special):
    import xbmcvfs
    return xbmcvfs.translatePath(special)


def request():
    """Leave the marker and reset the MegaNexus skin's own switches."""
    with open(_path(MARKER), 'w', encoding='utf-8') as handle:
        handle.write('reset')
    if xbmc.getSkinDir() == 'skin.meganexus':
        xbmc.executebuiltin('Skin.ResetSettings')


def pending():
    return os.path.exists(_path(MARKER))


def apply():
    """Erase the MegaNexus add-on data when a reset was requested. True when done."""
    marker = _path(MARKER)
    if not os.path.exists(marker):
        return False
    try:
        from .meganexus_uninstall import purge_bundle_profiles
        purge_bundle_profiles(_path('special://profile/addon_data'))
        os.remove(marker)
        xbmc.log('[MegaNexus] factory reset: all MegaNexus settings and data erased', xbmc.LOGINFO)
        return True
    except Exception as exc:
        xbmc.log('[MegaNexus] factory reset failed: %s' % exc, xbmc.LOGERROR)
        return False
