# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""No black flash when a small video stops on Amlogic boxes (9.0.2).

CoreELEC / LibreELEC on Amlogic show video on a hardware layer under Kodi's interface.
When a video stops the kernel's video driver blacks that layer out (blackout_policy 1),
and on a Fire TV Cube the whole picture flashed each time a trailer, Sport or IPTV
preview stopped or switched. Measured there: with Kodi alone it flashed, with the policy
at 0 (keep the last frame) it did not.

Only for the small videos, though. Kept after a film, the last frame holds the box in
that film's colour processing: after a Dolby Vision episode every colour of the interface
was wrong. So the frame is kept while a small video plays (refresh_guard.suspend) and the
black-out comes back before a film or an episode starts (release_all), once no small video
is left (sweep) and at every start of the service. PCs and Android have no such file, or
may not write it: nothing happens there.
"""
POLICY = '/sys/class/video/blackout_policy'


def _set(value, path):
    try:
        with open(path) as handle:
            if handle.read().strip() == value:
                return True
    except OSError:
        return False                 # not an Amlogic box
    try:
        with open(path, 'w') as handle:
            handle.write(value)
        return True
    except OSError:
        return False                 # not allowed here (Android)


def keep_last_frame(path=None):
    """A small video is about to play: its stop keeps the frame (no flash)."""
    return _set('0', path or POLICY)


def black_out(path=None):
    """The driver's own way again (films, episodes, nothing playing)."""
    return _set('1', path or POLICY)


def keeping(path=None):
    try:
        with open(path or POLICY) as handle:
            return handle.read().strip() == '0'
    except OSError:
        return False
