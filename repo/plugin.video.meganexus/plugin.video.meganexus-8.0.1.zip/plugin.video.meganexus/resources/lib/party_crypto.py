# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Watch Party cryptography (7.0.52): what Nostr needs, in plain Python.

Kodi's Python has no secp256k1, no Schnorr signatures and no ChaCha20, and an add-on
can not bring native libraries to every box. These are the standard algorithms, written
from their specifications and checked against the official test vectors
(tests/vectors: BIP-340, NIP-44 v2):

* secp256k1 and BIP-340 Schnorr signatures - every Nostr event is signed;
* NIP-44 v2 - ECDH, HKDF-SHA256, ChaCha20 (RFC 8439), HMAC-SHA256, padding;
* NIP-01 event id and signing.

Nothing here is invented: no own cipher, no shortcuts in the checks. ~1-2 ms per point
multiplication on a PC, a few tens on a TV box - a party signs a few events a second.
"""
import base64
import hashlib
import hmac
import json
import os
import struct
import time

# --- secp256k1 -----------------------------------------------------------------------------

P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
G = (0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,
     0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8)
_INFINITY = (0, 1, 0)        # Jacobian


class CryptoError(ValueError):
    pass


def _double(p):
    x, y, z = p
    if not z or not y:
        return _INFINITY
    ysq = y * y % P
    s = 4 * x * ysq % P
    m = 3 * x * x % P
    nx = (m * m - 2 * s) % P
    ny = (m * (s - nx) - 8 * ysq * ysq) % P
    return nx, ny, 2 * y * z % P


def _add(p, q):
    if not p[2]:
        return q
    if not q[2]:
        return p
    z1s, z2s = p[2] * p[2] % P, q[2] * q[2] % P
    u1, u2 = p[0] * z2s % P, q[0] * z1s % P
    s1, s2 = p[1] * z2s * q[2] % P, q[1] * z1s * p[2] % P
    if u1 == u2:
        return _double(p) if s1 == s2 else _INFINITY
    h, r = (u2 - u1) % P, (s2 - s1) % P
    h2 = h * h % P
    h3 = h * h2 % P
    u1h2 = u1 * h2 % P
    nx = (r * r - h3 - 2 * u1h2) % P
    ny = (r * (u1h2 - nx) - s1 * h3) % P
    return nx, ny, h * p[2] * q[2] % P


def _multiply(k, point):
    result, addend = _INFINITY, (point[0], point[1], 1)
    while k:
        if k & 1:
            result = _add(result, addend)
        addend = _double(addend)
        k >>= 1
    return result


def _affine(p):
    if not p[2]:
        return None
    zinv = pow(p[2], P - 2, P)
    zinv2 = zinv * zinv % P
    return p[0] * zinv2 % P, p[1] * zinv2 * zinv % P


def point_mul(k, point=G):
    return _affine(_multiply(k % N, point))


def lift_x(x):
    """The point with this x and an even y (BIP-340), or None."""
    if not 0 < x < P:
        return None
    ysq = (pow(x, 3, P) + 7) % P
    y = pow(ysq, (P + 1) // 4, P)
    if y * y % P != ysq:
        return None
    return x, y if y % 2 == 0 else P - y


def _int(data):
    return int.from_bytes(data, 'big')


def _bytes(value):
    return value.to_bytes(32, 'big')


def tagged_hash(tag, data):
    digest = hashlib.sha256(tag.encode('ascii')).digest()
    return hashlib.sha256(digest + digest + data).digest()


def new_secret():
    while True:
        value = _int(os.urandom(32))
        if 0 < value < N:
            return _bytes(value)


def public_key(secret):
    """x-only public key (32 bytes) of a 32-byte secret key."""
    d = _int(secret)
    if not 0 < d < N:
        raise CryptoError('bad secret key')
    return _bytes(point_mul(d)[0])


def schnorr_sign(message, secret, aux=None):
    """BIP-340 signature (64 bytes) of a 32-byte message."""
    d0 = _int(secret)
    if not 0 < d0 < N:
        raise CryptoError('bad secret key')
    public = point_mul(d0)
    d = d0 if public[1] % 2 == 0 else N - d0
    aux = os.urandom(32) if aux is None else aux
    t = _bytes(d ^ _int(tagged_hash('BIP0340/aux', aux)))
    k0 = _int(tagged_hash('BIP0340/nonce', t + _bytes(public[0]) + message)) % N
    if not k0:
        raise CryptoError('nonce')
    r = point_mul(k0)
    k = k0 if r[1] % 2 == 0 else N - k0
    e = _int(tagged_hash('BIP0340/challenge', _bytes(r[0]) + _bytes(public[0]) + message)) % N
    signature = _bytes(r[0]) + _bytes((k + e * d) % N)
    if not schnorr_verify(message, _bytes(public[0]), signature):
        raise CryptoError('signature did not verify')
    return signature


def schnorr_verify(message, public, signature):
    if len(public) != 32 or len(signature) != 64:
        return False
    point = lift_x(_int(public))
    r, s = _int(signature[:32]), _int(signature[32:])
    if point is None or r >= P or s >= N:
        return False
    e = _int(tagged_hash('BIP0340/challenge', signature[:32] + public + message)) % N
    sum_point = _affine(_add(_multiply(s, G), _multiply(N - e, point)))
    return sum_point is not None and sum_point[1] % 2 == 0 and sum_point[0] == r


# --- NIP-44 v2 -----------------------------------------------------------------------------

def _hkdf_extract(salt, key):
    return hmac.new(salt, key, hashlib.sha256).digest()


def _hkdf_expand(prk, info, length):
    out, block, counter = b'', b'', 1
    while len(out) < length:
        block = hmac.new(prk, block + info + bytes((counter,)), hashlib.sha256).digest()
        out += block
        counter += 1
    return out[:length]


def conversation_key(secret, public):
    """NIP-44: HKDF-extract(ECDH x coordinate, salt 'nip44-v2') - the same both ways."""
    point = lift_x(_int(public))
    d = _int(secret)
    if point is None or not 0 < d < N:
        raise CryptoError('bad key')
    shared = point_mul(d, point)
    return _hkdf_extract(b'nip44-v2', _bytes(shared[0]))


def message_keys(conversation, nonce):
    if len(conversation) != 32 or len(nonce) != 32:
        raise CryptoError('bad key length')
    keys = _hkdf_expand(conversation, nonce, 76)
    return keys[:32], keys[32:44], keys[44:76]


def _rotl(v, c):
    return ((v << c) & 0xFFFFFFFF) | (v >> (32 - c))


def _quarter(s, a, b, c, d):
    s[a] = (s[a] + s[b]) & 0xFFFFFFFF; s[d] = _rotl(s[d] ^ s[a], 16)
    s[c] = (s[c] + s[d]) & 0xFFFFFFFF; s[b] = _rotl(s[b] ^ s[c], 12)
    s[a] = (s[a] + s[b]) & 0xFFFFFFFF; s[d] = _rotl(s[d] ^ s[a], 8)
    s[c] = (s[c] + s[d]) & 0xFFFFFFFF; s[b] = _rotl(s[b] ^ s[c], 7)


def _chacha_block(key_words, counter, nonce_words):
    state = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574] + key_words + [counter] + nonce_words
    working = list(state)
    for _ in range(10):
        _quarter(working, 0, 4, 8, 12); _quarter(working, 1, 5, 9, 13)
        _quarter(working, 2, 6, 10, 14); _quarter(working, 3, 7, 11, 15)
        _quarter(working, 0, 5, 10, 15); _quarter(working, 1, 6, 11, 12)
        _quarter(working, 2, 7, 8, 13); _quarter(working, 3, 4, 9, 14)
    return struct.pack('<16I', *((working[i] + state[i]) & 0xFFFFFFFF for i in range(16)))


def chacha20(key, nonce, data, counter=0):
    """RFC 8439 ChaCha20 (12-byte nonce)."""
    key_words = list(struct.unpack('<8I', key))
    nonce_words = list(struct.unpack('<3I', nonce))
    out = bytearray(len(data))
    for block_index in range(0, len(data), 64):
        stream = _chacha_block(key_words, counter + block_index // 64, nonce_words)
        chunk = data[block_index:block_index + 64]
        out[block_index:block_index + len(chunk)] = bytes(a ^ b for a, b in zip(chunk, stream))
    return bytes(out)


def padded_length(length):
    if length <= 32:
        return 32
    next_power = 1 << (length - 1).bit_length()
    chunk = 32 if next_power <= 256 else next_power // 8
    return chunk * ((length - 1) // chunk + 1)


def _pad(plaintext):
    length = len(plaintext)
    if not 1 <= length <= 65535:
        raise CryptoError('message length')
    return struct.pack('>H', length) + plaintext + b'\x00' * (padded_length(length) - length)


def _unpad(padded):
    length = struct.unpack('>H', padded[:2])[0]
    if not length or len(padded) != 2 + padded_length(length) or len(padded) < 2 + length:
        raise CryptoError('bad padding')
    return padded[2:2 + length]


def encrypt(plaintext, conversation, nonce=None):
    """NIP-44 v2 payload (base64) of a text."""
    nonce = os.urandom(32) if nonce is None else nonce
    cipher_key, chacha_nonce, hmac_key = message_keys(conversation, nonce)
    ciphertext = chacha20(cipher_key, chacha_nonce, _pad(plaintext.encode('utf-8')))
    mac = hmac.new(hmac_key, nonce + ciphertext, hashlib.sha256).digest()
    return base64.b64encode(b'\x02' + nonce + ciphertext + mac).decode('ascii')


def decrypt(payload, conversation):
    if not payload or payload[0] == '#':
        raise CryptoError('unknown version')
    if not 132 <= len(payload) <= 87472:
        raise CryptoError('payload size')
    try:
        data = base64.b64decode(payload, validate=True)
    except Exception:
        raise CryptoError('bad base64')
    if not 99 <= len(data) <= 65603 or data[0] != 2:
        raise CryptoError('unknown version')
    nonce, ciphertext, mac = data[1:33], data[33:-32], data[-32:]
    cipher_key, chacha_nonce, hmac_key = message_keys(conversation, nonce)
    if not hmac.compare_digest(hmac.new(hmac_key, nonce + ciphertext, hashlib.sha256).digest(), mac):
        raise CryptoError('bad mac')
    return _unpad(chacha20(cipher_key, chacha_nonce, ciphertext)).decode('utf-8')


# --- NIP-01 events -------------------------------------------------------------------------

_ESCAPES = {'\n': '\\n', '"': '\\"', '\\': '\\\\', '\r': '\\r', '\t': '\\t', '\b': '\\b', '\f': '\\f'}


def _string(text):
    return '"' + ''.join(_ESCAPES.get(ch, ch) for ch in text) + '"'


def _serialize(value):
    """NIP-01's exact serialisation: no spaces, only those seven characters escaped."""
    if isinstance(value, str):
        return _string(value)
    if isinstance(value, bool) or value is None:
        return json.dumps(value)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, (list, tuple)):
        return '[' + ','.join(_serialize(v) for v in value) + ']'
    raise CryptoError('unexpected value in an event')


def event_id(event):
    data = [0, event['pubkey'], event['created_at'], event['kind'], event['tags'], event['content']]
    return hashlib.sha256(_serialize(data).encode('utf-8')).hexdigest()


def sign_event(kind, content, tags, secret, created_at=None):
    event = {'pubkey': public_key(secret).hex(), 'created_at': int(created_at if created_at is not None else time.time()),
             'kind': int(kind), 'tags': [[str(x) for x in tag] for tag in tags], 'content': content}
    event['id'] = event_id(event)
    event['sig'] = schnorr_sign(bytes.fromhex(event['id']), secret).hex()
    return event


def verify_event(event):
    try:
        if event_id(event) != event['id']:
            return False
        return schnorr_verify(bytes.fromhex(event['id']), bytes.fromhex(event['pubkey']), bytes.fromhex(event['sig']))
    except Exception:
        return False


# --- NIP-59 gift wrap ----------------------------------------------------------------------

def _tweaked(now=None):
    """A time up to two days back (NIP-59: against timing analysis)."""
    return int((now if now is not None else time.time()) - _int(os.urandom(4)) % (2 * 86400))


def gift_wrap(rumor, sender_secret, recipient_public, kind=1059, expires=None):
    """A rumor (unsigned event dict: kind, content, tags) sealed by the sender and wrapped with a
    one-time key for the recipient (hex public key). Relays see only the recipient.
    ``expires``: a unix time (NIP-40) after which relays drop the wrap."""
    sender_public = public_key(sender_secret).hex()
    rumor = dict(rumor, pubkey=sender_public, created_at=int(time.time()))
    rumor['id'] = event_id(rumor)
    seal_content = encrypt(json.dumps(rumor, separators=(',', ':')), conversation_key(sender_secret, bytes.fromhex(recipient_public)))
    seal = sign_event(13, seal_content, [], sender_secret, _tweaked())
    one_time = new_secret()
    wrap_content = encrypt(json.dumps(seal, separators=(',', ':')), conversation_key(one_time, bytes.fromhex(recipient_public)))
    tags = [['p', recipient_public]] + ([['expiration', str(int(expires))]] if expires else [])
    return sign_event(kind, wrap_content, tags, one_time, _tweaked())


def unwrap(wrap, recipient_secret):
    """(sender public key hex, rumor) of a gift wrap for us; raises CryptoError when it is not
    valid (bad signatures, a rumor claiming another author than the seal)."""
    if not verify_event(wrap):
        raise CryptoError('bad wrap')
    seal = json.loads(decrypt(wrap['content'], conversation_key(recipient_secret, bytes.fromhex(wrap['pubkey']))))
    if seal.get('kind') != 13 or not verify_event(seal):
        raise CryptoError('bad seal')
    rumor = json.loads(decrypt(seal['content'], conversation_key(recipient_secret, bytes.fromhex(seal['pubkey']))))
    if rumor.get('pubkey') != seal['pubkey'] or event_id(rumor) != rumor.get('id'):
        raise CryptoError('rumor and seal disagree')
    return seal['pubkey'], rumor


# --- small helpers -----------------------------------------------------------------------------

def fingerprint(public_hex, length=6):
    """A short code both sides read aloud when pairing (decimal, from the two keys)."""
    return str(_int(hashlib.sha256(public_hex.encode('ascii')).digest()[:8]) % 10 ** length).zfill(length)


def pair_code(public_a, public_b, length=6):
    """The code both TVs show when two people pair - the same on both sides."""
    first, second = sorted((public_a, public_b))
    digest = hashlib.sha256(('meganexus-pair|%s|%s' % (first, second)).encode('ascii')).digest()
    return str(_int(digest[:8]) % 10 ** length).zfill(length)


def party_tag(party_secret):
    """The tag a party's events carry: relays can match it, but can not tell which party."""
    return hmac.new(party_secret, b'meganexus-party-tag', hashlib.sha256).hexdigest()[:32]


def party_conversation(party_secret):
    """The NIP-44 conversation key everyone in a party shares (from the party's secret)."""
    return _hkdf_extract(b'nip44-v2', hmac.new(party_secret, b'meganexus-party-key', hashlib.sha256).digest())
