# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Watch Party between MegaNexus' playback (the interface) and the party (the service), 7.0.52.

Host: when a film starts, its title and the release chosen (infohash / file / name - never
a link) are left for the service (Window(Home) property), which tells the party. The
stream's link is kept in the profile (this user only); it is shared only when the host
turned "Share my stream" on, and only when it is a plain link to the file: an add-on's own
playback link can carry the user's keys (AIOStreams and others encrypt the whole
configuration into it), our Usenet player is local - neither is ever shared.
7.0.60: the host's TorBox file link is shared too (the same link the film plays from - never
the add-on's configuration). It carries the host's TorBox key: the host is told so when
"Share my stream" is turned on, and a guest never keeps it (no Continue Watching link, no
reused source - only Kodi's own log shows it).

Guest: the host's film plays here from this box's own sources - the same release when one
of them has it (infohash, then the file name), else the host's shared stream, else the
source list opens as usual.
"""
import json
import os
import re
import time
from urllib.parse import urlsplit

PROP = 'meganexus.party.'
STREAM_FILE = 'party_stream.json'
SECRET_PARAMS = re.compile(r'(^|[?&;])(token|apikey|api_key|key|password|pass|auth|secret|sig|access_token)=', re.I)
PRIVATE_HOST = re.compile(r'^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|0\.0\.0\.0|\[?::1\]?)', re.I)
CONFIG_PATH = re.compile(r'/(stremio|playback|resolve|proxy|addon)/[A-Za-z0-9_.~-]{40,}', re.I)
# an add-on's configuration in the path (it carries the debrid key): base64 JSON ("eyJ...") or
# any long token without dots - file names have dots, configurations do not
CONFIG_SEGMENT = re.compile(r'^(eyJ[A-Za-z0-9_=-]{8,}|[A-Za-z0-9_=%-]{40,})$')
# 7.0.60: TorBox's file link (its CDN: /dld/<file>?token=<the account key>) - shared when the host
# chose to; the key cannot be left out (TorBox refuses the link without it)
TORBOX_HOST = re.compile(r'(^|\.)tb-cdn\.(st|io)$', re.I)
GUEST_LINK = PROP + 'guestlink'          # Window(Home): the host's link playing here as a guest (its hash)


def _home():
    import xbmcgui
    return xbmcgui.Window(10000)


def _profile():
    from .meganexus.common import profile_path
    return profile_path()


# --- host ----------------------------------------------------------------------------------

def release_of(row):
    """What identifies a release across boxes (no link, no key)."""
    row = row if isinstance(row, dict) else {}
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    out = {'infohash': str(row.get('infoHash') or row.get('infohash') or '').lower()[:40],
           'file_idx': row.get('fileIdx') if isinstance(row.get('fileIdx'), int) else None,
           'filename': str(hints.get('filename') or row.get('filename') or '')[:200],
           'size': int(hints.get('videoSize') or 0) if str(hints.get('videoSize') or '').isdigit() else 0,
           'name': ' '.join(str(row.get('name') or '').split())[:80]}
    return {k: v for k, v in out.items() if v not in ('', None, 0)}


def note_release(row):
    """playback.remember_playing: the release just chosen."""
    try:
        if _home().getProperty(PROP + 'hosting'):
            _home().setProperty(PROP + 'release', json.dumps(release_of(row)))
    except Exception:
        pass


def note_start(meta, ctx):
    """playback._start: the host's film starts - the service tells the party."""
    try:
        home = _home()
        if not home.getProperty(PROP + 'hosting'):
            return
        release = json.loads(home.getProperty(PROP + 'release') or '{}')
        media = {'id': ctx.get('canonical_id') or meta.get('id'), 'type': ctx.get('media_type') or meta.get('type') or 'movie',
                 'title': ctx.get('title') or meta.get('name') or '', 'year': ctx.get('year') or meta.get('year') or '',
                 'poster': ctx.get('poster') or meta.get('poster') or '', 'background': ctx.get('background') or '',
                 'logo': ctx.get('clearlogo') or '', 'season': ctx.get('season') or '', 'episode': ctx.get('episode') or '',
                 'video_id': ctx.get('video_id') or '', 'show': ctx.get('show_title') or '', 'release': release}
        path = os.path.join(_profile(), STREAM_FILE)
        if _sharing():
            temp = path + '.tmp'
            with open(temp, 'w', encoding='utf-8') as handle:
                json.dump({'url': str(ctx.get('stream_url') or ''), 'headers': ctx.get('request_headers') or {}}, handle)
            try:
                os.chmod(temp, 0o600)
            except Exception:
                pass
            os.replace(temp, path)
        else:
            try:                                       # 7.0.58: a link with the account key is never kept
                os.remove(path)                        # when sharing is off
            except OSError:
                pass
        home.setProperty(PROP + 'media', json.dumps({'media': media, 'at': time.time()}))
    except Exception:
        pass


def _sharing():
    """The host chose "Share my stream" (HUB Settings > Watch Party)."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.meganexus').getSetting('watch_party_share') == 'true'
    except Exception:
        return False


def torbox_link(url):
    """TorBox's own link to one file (after the add-on's redirects)."""
    parts = urlsplit(str(url or '').split('|', 1)[0])
    return (parts.scheme == 'https' and bool(TORBOX_HOST.search(parts.hostname or ''))
            and (parts.path or '').startswith('/dld/'))


def torbox_on():
    """TorBox is set up on this TV - "Share my stream" is for it (7.0.60)."""
    try:
        from . import debrid
        return debrid.enabled('torbox')
    except Exception:
        return False


def plain_link(url, torbox=False):
    """A link that only reaches this one file: http(s), not on this box or network, no key in
    it, no add-on configuration in its path. torbox: TorBox's file link counts too (its key in it)."""
    url = str(url or '').split('|', 1)[0]
    parts = urlsplit(url)
    if parts.scheme not in ('http', 'https') or not parts.hostname:
        return False
    if torbox and torbox_link(url) and not parts.username and not parts.password:
        return True
    if PRIVATE_HOST.match(parts.hostname) or parts.username or parts.password:
        return False
    if SECRET_PARAMS.search(parts.query or '') or CONFIG_PATH.search(parts.path or ''):
        return False
    if any(CONFIG_SEGMENT.match(segment) for segment in (parts.path or '').split('/')):
        return False
    return True


def shareable(url, opener=None, torbox=False):
    """The file's own link (after the add-on's redirects), when it is plain; else ''."""
    url = str(url or '').split('|', 1)[0]
    if not url.startswith(('http://', 'https://')):
        return ''
    try:
        from urllib.request import Request, urlopen
        from .mkv_subtitle_times import kodi_headers
        with (opener or urlopen)(Request(url, method='HEAD', headers=kodi_headers({})), timeout=10) as reply:
            final = reply.geturl() or url
    except Exception:
        return ''                                       # not checked: nothing is shared
    return final if plain_link(final, torbox) else ''


def shared_stream():
    """The host's stream to share (the service, when "Share my stream" is on), or None."""
    try:
        with open(os.path.join(_profile(), STREAM_FILE), encoding='utf-8') as handle:
            url = json.load(handle).get('url') or ''
    except (OSError, ValueError):
        url = ''
    if not url:                                        # sharing turned on during the film: what Kodi plays
        try:
            import xbmc
            url = xbmc.Player().getPlayingFile() if xbmc.Player().isPlayingVideo() else ''
        except Exception:
            url = ''
    link = shareable(url, torbox=torbox_on())
    return {'url': link} if link else None


# --- guest -----------------------------------------------------------------------------------

def _digest(url):
    import hashlib
    return hashlib.sha256(str(url or '').split('|', 1)[0].encode('utf-8')).hexdigest()


def mark_guest_link(url):
    """The host's shared link plays here: nothing of MegaNexus keeps it (from_host)."""
    try:
        _home().setProperty(GUEST_LINK, _digest(url) if url else '')
    except Exception:
        pass


def from_host(url):
    """This link is the host's shared one (its TorBox key in it) - never stored here."""
    try:
        mark = _home().getProperty(GUEST_LINK)
        return bool(url and mark and mark == _digest(url))
    except Exception:
        return False


def match(rows, release):
    """The row with the host's release: the same infohash (and file), else the same file name."""
    release = release or {}
    infohash, filename = release.get('infohash'), (release.get('filename') or '').lower()
    for row in rows:
        mine = release_of(row)
        if infohash and mine.get('infohash') == infohash and (release.get('file_idx') is None or mine.get('file_idx') in (None, release.get('file_idx'))):
            return row
    if filename:
        for row in rows:
            if (release_of(row).get('filename') or '').lower() == filename:
                return row
    return None


def playing_now(media):
    """The same title (and episode) is already playing here."""
    try:
        import xbmc
        playing = json.loads(_home().getProperty('meganexus.playing.request') or '{}')
        meta, context = playing.get('meta') or {}, playing.get('context') or {}
        return (xbmc.Player().isPlayingVideo() and meta.get('id') == media.get('id')
                and str(context.get('season') or '') == str(media.get('season') or '')
                and str(context.get('episode') or '') == str(media.get('episode') or ''))
    except Exception:
        return False
