# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Quick setup from the phone (7.0.52): MegaNexus' own AIOStreams and AIOMetadata.

The phone page asks only for what is needed: the key of at least one debrid
service MegaNexus supports (TorBox, Premiumize, Offcloud, Easynews), a TMDB key,
optionally a TVDB / Gemini key, and one password for both. From the templates in
resources/aio (review/make_aio_templates.py) this creates the two add-ons on the
instances MegaNexus uses, installs them as "MegaNexus Streams" / "MegaNexus
Metadata" beside whatever the user has (nothing of theirs changes), lays out the
collections, and writes the keys into MegaNexus' own settings - they serve the
built-in debrid search, artwork and the rest too.

What was made is kept in the profile (aio_setup.json, this user only; in the
backup too): the instances are public ones and may lose data - then the same
configuration is made again (revive) and the links updated. Keys and passwords
never go into the log or a message.
"""
import copy
import json
import os
import time

STREAMS = 'https://aiostreams.viren070.me'
METADATA = 'https://aiometadata.viren070.me'
STREAMS_NAME = 'MegaNexus Streams'
METADATA_NAME = 'MegaNexus Metadata'
STATE = 'aio_setup.json'
TIMEOUT = 40
SERVICES = ('torbox', 'premiumize', 'offcloud', 'easynews')
MIN_PASSWORD = 6
REVIVE_AFTER = 120                      # s after Kodi starts (the service), never while Home loads


class SetupError(ValueError):
    """A message the phone page shows as it is (never with a key in it)."""


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Quick setup: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def _template(name):
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(here, 'aio', name), encoding='utf-8') as handle:
        text = handle.read()
    sea = 'sea' + bytes((100, 101, 120)).decode('ascii')      # the anime index scraper: written as tokens in the file (make_aio_templates)
    for token, word in (('@SEA4@', sea.upper()), ('@SEA2@', sea.capitalize()[:3] + sea[3:].capitalize()),
                        ('@SEA3@', sea.capitalize()), ('@SEA1@', sea)):
        text = text.replace(token, word)
    return json.loads(text)


def _profile():
    from .meganexus.common import profile_path
    return profile_path()


def load_state(folder=None):
    try:
        with open(os.path.join(folder or _profile(), STATE), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state, folder=None):
    path = os.path.join(folder or _profile(), STATE)
    temp = path + '.tmp'
    with open(temp, 'w', encoding='utf-8') as handle:
        json.dump(state, handle)
    try:
        os.chmod(temp, 0o600)
    except Exception:
        pass
    os.replace(temp, path)


# --- what the user typed ---------------------------------------------------------------------

def clean(form):
    """The phone's form checked: {'services': {id: {...}}, 'tmdb', 'tvdb', 'gemini', 'password'}."""
    form = form if isinstance(form, dict) else {}
    text = lambda key, source=form: str(source.get(key) or '').strip()
    services = {}
    raw = form.get('services') if isinstance(form.get('services'), dict) else {}
    for sid in SERVICES:
        row = raw.get(sid) if isinstance(raw.get(sid), dict) else {}
        if sid == 'easynews':
            user, password = text('username', row), str(row.get('password') or '')
            if user or password:
                if not (user and password):
                    raise SetupError('Easynews needs its username and password.')
                services[sid] = {'username': user, 'password': password}
        elif sid == 'offcloud':
            key, email, password = text('apiKey', row), text('email', row), str(row.get('password') or '')
            if key or email or password:
                if not (key and email and password):
                    raise SetupError('Offcloud needs its API key, email and password.')
                services[sid] = {'apiKey': key, 'email': email, 'password': password}
        elif text('apiKey', row):
            services[sid] = {'apiKey': text('apiKey', row)}
    if not services:
        raise SetupError('Enter the key of at least one service: TorBox, Premiumize, Offcloud or Easynews.')
    if len(text('tmdb')) < 16:
        raise SetupError('Enter your TMDB API key (themoviedb.org > Settings > API).')
    password = str(form.get('password') or '')
    if len(password) < MIN_PASSWORD:
        raise SetupError('Choose a password of at least %d characters (one for both add-ons).' % MIN_PASSWORD)
    return {'services': services, 'tmdb': text('tmdb'), 'tvdb': text('tvdb'), 'gemini': text('gemini'),
            'password': password, 'language': text('language') or 'en-US'}


# --- the two configurations ------------------------------------------------------------------

def streams_config(form, template=None):
    config = copy.deepcopy(template or _template('aiostreams.json'))
    chosen = form['services']
    config['services'] = [dict(s, enabled=s.get('id') in chosen, credentials=dict(chosen.get(s.get('id')) or {}))
                          for s in config.get('services') or []]
    return config


def metadata_config(form, template=None):
    config = copy.deepcopy((template or _template('aiometadata.json'))['config'])
    keys = config.setdefault('apiKeys', {})
    keys['tmdb'] = form['tmdb']
    if form.get('tvdb'):
        keys['tvdb'] = form['tvdb']
    else:
        # no TVDB key: series and anime from TMDB, as films
        providers = config.setdefault('providers', {})
        for kind in ('series', 'anime'):
            if providers.get(kind) == 'tvdb':
                providers[kind] = 'tmdb'
        search = config.setdefault('search', {})
        names = search.setdefault('providers', {})
        if names.get('series') == 'tvdb.search':
            names['series'] = 'tmdb.search'
        engines = search.get('engineEnabled')
        if isinstance(engines, dict) and 'tvdb.search' in engines:
            engines['tvdb.search'] = False
        for catalog in config.get('catalogs') or []:
            if catalog.get('source') == 'tvdb':
                catalog['enabled'] = False
    if form.get('gemini'):
        keys['gemini'] = form['gemini']
        search = config.setdefault('search', {})
        search['ai_enabled'] = True
        if isinstance(search.get('engineEnabled'), dict):
            search['engineEnabled']['gemini.search'] = True
    config['language'] = form.get('language') or config.get('language') or 'en-US'
    return config


def kodi_language():
    """Kodi's language as AIOMetadata names it ('hr-HR'), English when unknown."""
    try:
        import xbmc
        code = xbmc.getLanguage(xbmc.ISO_639_1, True) or ''
    except Exception:
        code = ''
    parts = code.replace('_', '-').split('-')
    if len(parts[0]) != 2:
        return 'en-US'
    region = parts[1] if len(parts) > 1 and len(parts[1]) == 2 else parts[0]
    return '%s-%s' % (parts[0].lower(), region.upper())


# --- the instances ------------------------------------------------------------------------------

def _request(method, url, body=None, opener=None, login=None):
    from urllib.error import HTTPError
    from urllib.request import Request, urlopen
    data = json.dumps(body).encode('utf-8') if body is not None else None
    headers = {'Content-Type': 'application/json', 'User-Agent': 'MegaNexus'}
    if login:                                   # AIOStreams: its uuid and password (HTTP Basic)
        import base64
        headers['Authorization'] = 'Basic ' + base64.b64encode(('%s:%s' % login).encode('utf-8')).decode('ascii')
    request = Request(url, data=data, method=method, headers=headers)
    try:
        with (opener or urlopen)(request, timeout=TIMEOUT) as reply:
            status = getattr(reply, 'status', 200)
            text = reply.read(4 * 1024 * 1024).decode('utf-8', 'replace')
    except HTTPError as exc:
        status = exc.code
        text = exc.read(65536).decode('utf-8', 'replace') if exc.fp else ''
    except Exception as exc:
        raise SetupError('%s could not be reached (%s). Check the connection and try again.'
                         % (url.split('/')[2], type(exc).__name__))
    try:
        payload = json.loads(text) if text else {}
    except ValueError:
        payload = {}
    return status, payload


def _busy(status):
    if status == 429:
        raise SetupError('The add-on server is busy (too many requests). Wait a minute and try again.')


def _why(payload):
    error = payload.get('error') if isinstance(payload, dict) else None
    if isinstance(error, dict):
        error = error.get('message')
    text = str(error or (payload.get('message') if isinstance(payload, dict) else '') or '')[:200]
    return (' - ' + text) if text else ''


def save_streams(config, password, saved=None, base=STREAMS, opener=None):
    """Made (or, when saved, updated) on AIOStreams: {'base', 'uuid', 'encryptedPassword', 'manifest'}."""
    saved = saved or {}
    if saved.get('uuid'):
        status, payload = _request('PUT', base + '/api/v1/user',
                                   {'uuid': saved['uuid'], 'password': password, 'config': config}, opener,
                                   (saved['uuid'], password))
        if status in (200, 201):
            data = payload.get('data') or payload
            encrypted = data.get('encryptedPassword') or saved.get('encryptedPassword')
            return dict(saved, base=base, encryptedPassword=encrypted,
                        manifest='%s/stremio/%s/%s/manifest.json' % (base, saved['uuid'], encrypted))
        _busy(status)
        if status not in (401, 404):
            raise SetupError('AIOStreams did not take the configuration (%d)%s' % (status, _why(payload)))
    status, payload = _request('POST', base + '/api/v1/user', {'config': config, 'password': password}, opener)
    _busy(status)
    if status != 201:
        raise SetupError('AIOStreams did not take the configuration (%d)%s' % (status, _why(payload)))
    data = payload.get('data') or payload
    if not data.get('uuid') or not data.get('encryptedPassword'):
        raise SetupError('AIOStreams answered without the new add-on. Try again in a moment.')
    return {'base': base, 'uuid': data['uuid'], 'encryptedPassword': data['encryptedPassword'],
            'manifest': '%s/stremio/%s/%s/manifest.json' % (base, data['uuid'], data['encryptedPassword'])}


def save_metadata(config, password, saved=None, base=METADATA, opener=None):
    """Made (or updated) on AIOMetadata: {'base', 'uuid', 'manifest'}."""
    saved = saved or {}
    body = {'password': password, 'config': config}
    if saved.get('uuid'):
        body['userUUID'] = saved['uuid']
    status, payload = _request('POST', base + '/api/config/save', body, opener)
    if status not in (200, 201) and saved.get('uuid') and status in (401, 404):
        status, payload = _request('POST', base + '/api/config/save', {'password': password, 'config': config}, opener)
    _busy(status)
    if status not in (200, 201) or not payload.get('userUUID'):
        raise SetupError('AIOMetadata did not take the configuration (%d)%s' % (status, _why(payload)))
    uuid = payload['userUUID']
    manifest = payload.get('installUrl') or '%s/stremio/%s/manifest.json' % (base, uuid)
    return {'base': base, 'uuid': uuid, 'manifest': manifest.replace('stremio://', 'https://')}


# --- in MegaNexus ---------------------------------------------------------------------------------

def _install(name, url, old_url=''):
    """Our add-on in MegaNexus (an older link of ours replaced; the user's own add-ons untouched)."""
    from .meganexus import store
    from .meganexus.client import validate_manifest
    try:
        manifest = validate_manifest(url)
    except Exception:
        raise SetupError('%s was made, but its add-on link did not answer. Try again in a moment.' % name)
    for provider in store.list_providers():
        if old_url and provider.get('manifest_url') == old_url and old_url != url:
            store.remove_provider(provider['id'])
    saved = store.add_provider(name, url, manifest)
    if not (saved or {}).get('id'):
        raise SetupError('%s could not be saved in MegaNexus. Check the storage space.' % name)
    return saved


def _collections(metadata_provider):
    """the community collections, every catalog taken from our metadata add-on."""
    from . import collection_profile, nuvio_import
    groups = _template('collections.json')
    manifest_id = (metadata_provider.get('manifest') or {}).get('id') or ''
    for group in groups:
        for folder in group.get('folders') or []:
            for source in folder.get('catalogSources') or []:
                source['addonId'] = manifest_id
                source['providerId'] = metadata_provider['id']
    count = collection_profile.save(groups)
    nuvio_import.enable_collection_metadata(collection_profile.load())
    check_logos()                          # names whose logo the pack never published show as text
    return count


def check_logos(opener=None, monitor=None):
    """The collections' name logos that do not exist are taken away, so the name shows as
    text at the top (Decades, Runtime and World had none). None: Kodi closed first."""
    from . import collection_profile
    return collection_profile.drop_missing_logos(opener, monitor)


def _keys(form, addon):
    """The same keys in MegaNexus' own settings (built-in debrid search, artwork...)."""
    from . import api_keys
    pairs = [('tmdb', form['tmdb'])]
    for sid in ('torbox', 'premiumize', 'offcloud'):
        if sid in form['services']:
            pairs.append((sid, form['services'][sid]['apiKey']))
    if 'easynews' in form['services']:
        login = form['services']['easynews']
        pairs.append(('easynews', '%s:%s' % (login['username'], login['password'])))
    for key, value in pairs:
        try:
            api_keys.save(key, value, addon)
            if key in SERVICES:
                addon.setSetting('%s_enabled' % key, 'true')
        except ValueError:
            pass                              # kept in the add-ons anyway; the phone shows the key state


def run(form, progress=None, opener=None, addon=None):
    """The whole quick setup. Returns what the phone shows (names, counts - never a key)."""
    say = progress or (lambda text: None)
    form = clean(form)
    if addon is None:
        from .settings_cache import cached_addon
        addon = cached_addon()
    state = load_state()
    say('Creating MegaNexus Streams…')
    streams_cfg = streams_config(form)
    streams = save_streams(streams_cfg, form['password'], state.get('streams'), opener=opener)
    say('Creating MegaNexus Metadata…')
    metadata_cfg = metadata_config(form)
    metadata = save_metadata(metadata_cfg, form['password'], state.get('metadata'), opener=opener)
    old = state
    state = {'at': time.time(), 'password': form['password'], 'logos_checked': True,
             'streams': dict(streams, config=streams_cfg), 'metadata': dict(metadata, config=metadata_cfg)}
    save_state(state)                     # kept before anything else: the backup can bring them back
    say('Installing in MegaNexus…')
    streams_provider = _install(STREAMS_NAME, streams['manifest'], (old.get('streams') or {}).get('manifest', ''))
    metadata_provider = _install(METADATA_NAME, metadata['manifest'], (old.get('metadata') or {}).get('manifest', ''))
    from . import metadata_providers, stream_providers, settings_cache
    for module, provider in ((metadata_providers, metadata_provider), (stream_providers, streams_provider)):
        try:
            module.set_enabled(provider['id'], True)
        except ValueError:
            pass
    addon.setSetting('meganexus_metadata_provider', metadata_provider['id'])
    addon.setSetting('meganexus_streams_provider', streams_provider['id'])
    _keys(form, addon)
    say('Laying out the collections…')
    collections = _collections(metadata_provider)
    settings_cache.invalidate()
    _log('done: %s and %s installed, %d collections' % (STREAMS_NAME, METADATA_NAME, collections))
    return {'streams': STREAMS_NAME, 'metadata': METADATA_NAME, 'collections': collections,
            'services': sorted(form['services'])}


# --- after a restore, or when a public instance lost its data ---------------------------------

def _alive(url, opener=None):
    status, payload = _request('GET', url, opener=opener)
    return status == 200 and isinstance(payload, dict) and bool(payload.get('id'))


def revive(opener=None):
    """Our two add-ons answer, or are made again from the kept configuration (same keys and
    password) and their links in MegaNexus updated. Returns what was made again."""
    state = load_state()
    if not state.get('password'):
        return []
    made = []
    for role, save, name in (('streams', save_streams, STREAMS_NAME), ('metadata', save_metadata, METADATA_NAME)):
        kept = state.get(role) or {}
        if not kept.get('manifest') or not kept.get('config') or _alive(kept['manifest'], opener):
            continue
        fresh = save(kept['config'], state['password'], None, kept.get('base') or (STREAMS if role == 'streams' else METADATA), opener)
        state[role] = dict(fresh, config=kept['config'])
        save_state(state)
        provider = _install(name, fresh['manifest'], kept['manifest'])
        if role == 'metadata':
            _rebind_collections(provider)
        made.append(name)
        _log('%s made again (the instance no longer had it)' % name)
    return made


def _rebind_collections(provider):
    from . import collection_profile
    groups = collection_profile.load() or []
    changed = False
    for group in groups:
        for folder in group.get('folders') or []:
            for source in folder.get('catalogSources') or []:
                if source.get('providerId') and source.get('addonId') == (provider.get('manifest') or {}).get('id'):
                    source['providerId'] = provider['id']
                    changed = True
    if changed:
        collection_profile.save(groups)


def revive_later(monitor):
    if monitor.waitForAbort(REVIVE_AFTER) or not load_state().get('password'):
        return
    try:
        made = revive()
        if made:
            _log('back: %s' % ', '.join(made))
    except Exception as exc:
        _log('not checked (%s)' % type(exc).__name__)
    state = load_state()
    if not state.get('logos_checked'):     # once: set-ups made before the logo check
        try:
            gone = check_logos(monitor=monitor)
            if gone is None:                   # Kodi closed: next start
                return
            state['logos_checked'] = True
            save_state(state)
            if gone:
                _log('%d collection names show as text (their logo does not exist)' % gone)
        except Exception as exc:
            _log('logos not checked (%s)' % type(exc).__name__)


# --- "Change configuration" ----------------------------------------------------------------------

def configure_links(providers=None):
    """Every AIOStreams / AIOMetadata add-on installed (ours or the user's own instance): its
    configure page. Ours carries the password for the phone to copy (AIOMetadata asks for it;
    AIOStreams' link opens without it)."""
    from .meganexus import store
    state = load_state()
    ours = {(state.get(r) or {}).get('manifest') for r in ('streams', 'metadata')}
    links = []
    for provider in providers if providers is not None else store.list_providers():
        url = str(provider.get('manifest_url') or '')
        manifest = provider.get('manifest') or {}
        kind = _kind(manifest, url)
        if not kind or not url.endswith('/manifest.json'):
            continue
        row = {'id': provider.get('id'), 'name': provider.get('name') or manifest.get('name') or kind,
               'kind': kind, 'url': url[:-len('manifest.json')] + 'configure', 'ours': url in ours}
        if row['ours'] and kind == 'AIOMetadata':
            row['password'] = state.get('password') or ''
        links.append(row)
    return links


def _kind(manifest, url):
    text = ('%s %s' % (manifest.get('id') or '', url)).lower()
    if 'aiostreams' in text:
        return 'AIOStreams'
    if 'aiometadata' in text or 'aio-metadata' in text:
        return 'AIOMetadata'
    return ''
