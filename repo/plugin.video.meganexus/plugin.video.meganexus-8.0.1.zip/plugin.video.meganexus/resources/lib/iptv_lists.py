# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""IPTV lists (7.0.37): any number of M3U / Xtream lists, each with two switches.

* Live TV - its channels in Kodi's TV (its own IPTV Simple instance; off = the
  instance is switched off, its settings stay). With "Only live TV in the
  channel list" (iptv_live.SETTING, default on) Kodi reads a local file with
  the channels only, else the provider's playlist as it is.
* IPTV VOD - its films and series are a source in the source list ("IPTV
  VOD"), next to the stream add-ons: nothing is loaded into Kodi, a small index
  on disk (name, year, season / episode, link) is searched when a title's
  sources are asked for. Shown only while IPTV is set up.

Both come from one pass through the playlist (iptv_live.build), made again
each morning (BUILD_HOUR) while nothing plays; IPTV Simple reads its file
again at REFRESH_HOUR. The lists, the indexes and the channel files hold the
providers' links (with their logins): owner-only files in the add-on profile,
never logged; source rows carry a token, the link is read when it plays.
"""
import base64
import hashlib
import json
import os
import re
import time
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urlsplit

from . import iptv_catchup, iptv_live

LISTS_FILE = 'iptv-lists.json'
SCHEME = 'meganexus-iptv://'
SOURCE_NAME = 'IPTV VOD'
SOURCE_ID = 'iptv_vod'
BUILD_HOUR = 4
REFRESH_HOUR = 5
MAX_AGE = 20 * 3600
MAX_ROWS = 12
INSTANCE_PREFIX = 'MegaNexus IPTV'


# ---- the lists ---------------------------------------------------------
def _path(folder):
    return Path(folder) / LISTS_FILE


def _private(path):
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def load(folder):
    try:
        data = json.loads(_path(folder).read_text(encoding='utf-8'))
        lists = [row for row in data.get('lists') or [] if isinstance(row, dict) and row.get('id')]
        return lists
    except (OSError, ValueError, AttributeError):
        return []


def save(folder, lists):
    path = _path(folder)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps({'version': 1, 'lists': lists}, ensure_ascii=False), encoding='utf-8')
    _private(temp)
    os.replace(temp, path)


def find(folder, list_id):
    return next((row for row in load(folder) if row.get('id') == list_id), None)


def update(folder, list_id, **values):
    lists = load(folder)
    for row in lists:
        if row.get('id') == list_id:
            row.update(values)
    save(folder, lists)
    return find(folder, list_id)


def new_id(lists):
    used = {row.get('id') for row in lists}
    number = 1
    while 'l%d' % number in used:
        number += 1
    return 'l%d' % number


def default_name(m3u):
    try:
        return urlsplit(m3u).hostname or 'IPTV'
    except ValueError:
        return 'IPTV'


def live_file(folder, row):
    return str(Path(folder) / ('iptv-live-%s.m3u' % row['id']))


def vod_file(folder, row):
    return str(Path(folder) / ('iptv-vod-%s.tsv' % row['id']))


def migrate(folder, profile, configured, instance):
    """7.0.36 and older had one list: its instance becomes the first list."""
    if load(folder) or not configured or not instance:
        return False
    try:
        values = instance_values(profile, instance)
    except (OSError, ET.ParseError, ValueError):
        return False
    m3u = values.get('m3uUrl') if values.get('m3uPathType') == '1' else ''
    try:      # a 7.0.37 test build kept the link aside
        m3u = m3u or json.loads((Path(folder) / 'iptv-source.json').read_text(encoding='utf-8')).get('m3u') or ''
    except (OSError, ValueError, AttributeError):
        pass
    if not m3u:
        return False
    save(folder, [{'id': 'l1', 'name': default_name(m3u), 'm3u': m3u, 'epg': values.get('epgUrl') or '',
                   'live': True, 'vod': True, 'instance': int(instance), 'rules': 0}])
    for old in ('iptv-source.json', 'iptv-live.m3u'):
        try:
            (Path(folder) / old).unlink()
        except OSError:
            pass
    return True


def add(folder, profile, name, m3u, epg='', timeshift=False, catchup=True):
    """A new list with its own IPTV Simple instance (call with IPTV Simple off)."""
    from .iptv_config import write_instance
    lists = load(folder)
    row = {'id': new_id(lists), 'name': str(name or default_name(m3u))[:40], 'm3u': m3u, 'epg': epg or '',
           'live': True, 'vod': True, 'rules': 0}
    row['instance'] = write_instance(profile, m3u, epg, None, timeshift, catchup,
                                     name='%s · %s' % (INSTANCE_PREFIX, row['name']), fresh=True)
    lists.append(row)
    save(folder, lists)
    return row


def remove(folder, profile, list_id):
    """The list goes; its instance is kept switched off in a backup folder."""
    lists = load(folder)
    row = next((r for r in lists if r.get('id') == list_id), None)
    if row is None:
        return False
    path = Path(profile) / ('instance-settings-%d.xml' % int(row.get('instance') or 0))
    if path.exists():
        backup = Path(profile) / 'meganexus-backups'
        backup.mkdir(exist_ok=True)
        os.replace(path, backup / ('%d-%s' % (time.time_ns(), path.name)))
    for file in (live_file(folder, row), vod_file(folder, row), groups_file(folder, row), catchup_file(folder, row)):
        try:
            os.unlink(file)
        except OSError:
            pass
    save(folder, [r for r in lists if r.get('id') != list_id])
    return True


# ---- IPTV Simple instances --------------------------------------------
def instance_values(profile, instance_id):
    path = Path(profile) / ('instance-settings-%d.xml' % int(instance_id))
    root = ET.parse(path).getroot()
    return {node.get('id'): node.text or '' for node in root.findall('setting')}


def wanted(folder, row):
    """What the list's instance should say: its local file (channels of the
    groups switched on; films and series too while Only live TV is off)."""
    if not row.get('live'):
        return {'kodi_addon_instance_enabled': 'false'}
    return {'kodi_addon_instance_enabled': 'true', 'm3uPathType': '0', 'm3uPath': live_file(folder, row),
            'm3uUrl': '', 'm3uRefreshMode': '2', 'm3uRefreshHour': str(REFRESH_HOUR)}


def catchup_file(folder, row):
    """7.0.48: the channels whose archive MegaNexus plays itself (iptv_catchup.index)."""
    return str(Path(folder) / ('iptv-catchup-%s.json' % row['id']))


def catchup_index(folder):
    """name -> the archive index of its list (every list together)."""
    merged = {}
    for row in load(folder):
        try:
            data = json.loads(Path(catchup_file(folder, row)).read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        for name in (data.get('channels') or {}):
            merged.setdefault(name, data)
    return merged


def groups_file(folder, row):
    return str(Path(folder) / ('iptv-groups-%s.json' % row['id']))


def list_groups(folder, row):
    """{group: channels} of a list's last pass (all groups, also switched-off ones)."""
    try:
        return json.loads(Path(groups_file(folder, row)).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def set_hidden(folder, list_id, hidden):
    """Switch groups off (their channels are left out of Kodi at the next pass, at once)."""
    return update(folder, list_id, hidden_groups=sorted(set(hidden)), rules=0)


def write_values(profile, instance_id, values):
    path = Path(profile) / ('instance-settings-%d.xml' % int(instance_id))
    tree = ET.parse(path)
    root = tree.getroot()
    for key, value in values.items():
        node = root.find("setting[@id='%s']" % key)
        if node is None:
            node = ET.SubElement(root, 'setting', id=key)
        node.attrib.pop('default', None)
        node.text = value
    temp = path.with_name(path.name + '.tmp')
    tree.write(temp, encoding='utf-8', xml_declaration=True)
    _private(temp)
    os.replace(temp, path)


def due(path, now=None, hour=None):
    """Made again: no file yet, or an old one in the morning hour."""
    path = Path(path)
    if not path.exists():
        return True
    now = time.time() if now is None else now
    age = now - path.stat().st_mtime
    hour = time.localtime(now).tm_hour if hour is None else hour
    return age >= 2 * 24 * 3600 or (age >= MAX_AGE and hour == BUILD_HOUR)


def sync(folder, profile, live_only, rpc=None, log=None, stopped=None, opener=None, wait=None):
    """Every list: make its files when due, point its instance where the
    switches say. IPTV Simple is reloaded (off and on) only when an instance
    changed or a file was made outside the morning (it reads it at
    REFRESH_HOUR by itself). Returns the ids of the lists made; None when
    another process is making them right now."""
    with _Lock(folder) as lock:
        if not lock.held:
            return None
        return _sync(folder, profile, live_only, rpc, log, stopped, opener, wait)


def _sync(folder, profile, live_only, rpc, log, stopped, opener, wait):
    log = log or (lambda text: None)
    made, rewrite = [], []
    for row in load(folder):
        need_live = bool(row.get('live'))
        need_vod = bool(row.get('vod'))
        files = ([live_file(folder, row)] if need_live else []) + ([vod_file(folder, row)] if need_vod else [])
        rules_changed = int(row.get('rules') or 0) != iptv_live.RULES or bool(row.get('live_only', True)) != bool(live_only)
        if files and (rules_changed or any(due(f) for f in files)):
            morning = time.localtime().tm_hour == BUILD_HOUR and not rules_changed
            counted, archive = {}, {}
            # 7.0.48: an Xtream server says which channels keep an archive (iptv_catchup.py)
            catchup = iptv_catchup.for_list(row.get('m3u'), log=log) if need_live and opener is None else None
            try:
                kept, dropped = iptv_live.build(row.get('m3u'), live_file(folder, row) if need_live else None,
                                                vod_file(folder, row) if need_vod else None, vod_row,
                                                opener=opener, stopped=stopped, hidden=row.get('hidden_groups') or (),
                                                groups=counted, keep_vod=not live_only, catchup=catchup, archive=archive)
            except Exception as exc:
                log('[MegaNexus] IPTV list %s not made: %s' % (row.get('id'), iptv_live.describe(exc)))
                continue
            log('[MegaNexus] IPTV list %s: %d channels, %d films and series' % (row.get('id'), kept, dropped))
            try:
                Path(groups_file(folder, row)).write_text(json.dumps(counted, ensure_ascii=False), encoding='utf-8')
            except OSError:
                pass
            _write_catchup(folder, row, catchup)
            update(folder, row['id'], rules=iptv_live.RULES, live_only=bool(live_only),
                   catchup=[int(archive.get('channels', 0)), int(archive.get('days', 0))])
            made.append(row['id'])
            if need_live and not morning:
                rewrite.append((row, {}))
        try:
            current = instance_values(profile, row.get('instance'))
        except (OSError, ET.ParseError, ValueError, TypeError):
            continue
        if need_live and not Path(live_file(folder, row)).exists():
            continue          # nothing to point at yet
        values = wanted(folder, row)
        changes = {k: v for k, v in values.items() if current.get(k, '') != v}
        if changes:
            rewrite.append((row, changes))
    if rewrite:
        _rewrite(rpc, lambda: [write_values(profile, row.get('instance'), changes) for row, changes in rewrite if changes],
                 wait, stopped)
    _guide_days(rpc, max([int((row.get('catchup') or [0, 0])[1] or 0) for row in load(folder)] or [0]))
    return made


def _write_catchup(folder, row, catchup):
    """The list's archive index (with the login, private like the playlist), or none."""
    path = Path(catchup_file(folder, row))
    if catchup is None or not catchup.marked:
        try:
            path.unlink()
        except OSError:
            pass
        return
    temp = path.with_name('%s.%d.tmp' % (path.name, os.getpid()))
    try:
        temp.write_text(json.dumps(catchup.index(), ensure_ascii=False), encoding='utf-8')
        _private(temp)
        os.replace(temp, path)
    except OSError:
        try:
            temp.unlink()
        except OSError:
            pass


GUIDE_DAYS = 'epg.pastdaystodisplay'


def _answer(value):
    """The result of either RPC helper (the service's whole answer, the interface's result)."""
    return value.get('result') if isinstance(value, dict) and 'result' in value else value


def _guide_days(rpc, days):
    """7.0.48: Kodi keeps the guide one day back by default - a two or three day archive
    showed one day. Raised to the longest archive of the lists (7 at most), never lowered."""
    if rpc is None or days <= 1:
        return
    try:
        current = int((_answer(rpc('Settings.GetSettingValue', {'setting': GUIDE_DAYS})) or {}).get('value') or 0)
        if 0 < current < min(7, days):
            rpc('Settings.SetSettingValue', {'setting': GUIDE_DAYS, 'value': min(7, days)})
            from .kodi_keep import keep
            keep()
    except Exception:
        pass


def _pvr_up(rpc):
    try:
        data = rpc('PVR.GetProperties', {'properties': ['available']}) or {}
        return bool((data.get('result', data) or {}).get('available'))     # the service gets the whole answer
    except Exception:
        return False


def _wait_for(check, seconds, wait, stopped=None):
    for _ in range(int(seconds * 2)):
        if check():
            return True
        if stopped is not None and stopped():
            return False
        wait(.5)
    return check()


def _rewrite(rpc, write, wait=None, stopped=None):
    """Change instance files with IPTV Simple off, then on again - it reads them anew.
    7.0.38: switched on again only once Kodi's PVR has really stopped, and
    checked that it starts; else once more. Switched off and on at once, Kodi
    kept the add-on on with its PVR stopped - no channels (seen on a Cube)."""
    if rpc is None:
        return write()
    from .iptv_config import ensure_client_enabled
    wait = wait or time.sleep
    rpc('Addons.SetAddonEnabled', {'addonid': 'pvr.iptvsimple', 'enabled': False})
    try:
        _wait_for(lambda: not _pvr_up(rpc), 15, wait, stopped)
        wait(2)                        # its client is destroyed after the manager stops
        return write()
    finally:
        for attempt in range(2):
            ensure_client_enabled(rpc)
            if _wait_for(lambda: _pvr_up(rpc), 60, wait, stopped) or (stopped is not None and stopped()):
                break
            rpc('Addons.SetAddonEnabled', {'addonid': 'pvr.iptvsimple', 'enabled': False})
            wait(5)


class _Lock:
    """One pass at a time, across Kodi's Python processes (the service and the
    interface both make lists): a lock file, taken over after STALE seconds."""
    STALE = 600

    def __init__(self, folder):
        self.path = Path(folder) / 'iptv-lists.lock'
        self.held = False

    def __enter__(self):
        for _ in range(2):
            try:
                os.close(os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600))
                self.held = True
                return self
            except FileExistsError:
                try:
                    if time.time() - self.path.stat().st_mtime < self.STALE:
                        return self
                    self.path.unlink()
                except OSError:
                    pass
        return self

    def __exit__(self, *exc):
        if self.held:
            try:
                self.path.unlink()
            except OSError:
                pass


def instances(folder):
    return [int(row['instance']) for row in load(folder) if row.get('instance')]


def run(monitor, busy, folder, profile, setting, log=None, first_wait=90, every=120):
    """Service loop: at start (after ``first_wait``) and every ``every`` seconds;
    never while ``busy()`` (a video or live TV plays, a TV screen is open)."""
    if monitor.waitForAbort(first_wait):
        return
    while not monitor.abortRequested():
        try:
            configured, instance, live_only = setting()
            migrate(folder, profile, configured, instance)
            if configured and load(folder) and not busy():
                sync(folder, profile, live_only, rpc=_rpc, log=log, stopped=monitor.abortRequested,
                     wait=monitor.waitForAbort)
        except Exception as exc:
            if log:
                log('[MegaNexus] IPTV lists not refreshed: %s' % iptv_live.describe(exc))
        if monitor.waitForAbort(every):
            return


def _rpc(method, params):
    import xbmc
    return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))


# ---- IPTV VOD: the index -----------------------------------------------
_TAGS = re.compile(r'^\s*(?:\[[^\]]*\]|\|[^|]*\||\([A-Z]{2,3}\)|[A-Z]{2,3}\s+[-•]\s+|[A-Z]{2,3}\s*\|)\s*')
_YEAR = re.compile(r'[\(\[]\s*((?:19|20)\d\d)\s*[\)\]]|(?:^|\s)((?:19|20)\d\d)\s*$')
_EPISODE = re.compile(r'^(?P<name>.*?)[\s._-]*(?:S(?P<s>\d{1,2})\s*[._-]?\s*E(?P<e>\d{1,3})|(?P<s2>\d{1,2})x(?P<e2>\d{2,3}))\b', re.I)
_QUALITY = re.compile(r'\b(?:4k|uhd|fhd|hd|sd|hevc|h265|x265|h264|x264|multi|sub|subs|titl\w*|dub\w*|1080p|720p|2160p)\b', re.I)
_FOLD = str.maketrans({'đ': 'd', 'Đ': 'd', 'ß': 'ss', 'æ': 'ae', 'ø': 'o', 'ł': 'l'})


def norm(name):
    """The name as a search key: no language tags, year, quality words,
    accents or punctuation ("|HR| Kum (1972) 4K" -> "kum")."""
    text = str(name or '')
    for _ in range(3):
        text = _TAGS.sub('', text)
    text = _YEAR.sub(' ', text)
    text = re.sub(r'[\(\[][^\)\]]*[\)\]]', ' ', text)
    text = _QUALITY.sub(' ', text.translate(_FOLD))
    text = unicodedata.normalize('NFKD', text)
    text = ''.join(ch for ch in text if not unicodedata.combining(ch)).lower()
    return ' '.join(re.split(r'[^0-9a-z]+', text)).strip()


def parse(name):
    """(kind 'm' / 's', key, year, season, episode) of an entry's name."""
    name = str(name or '').strip()
    year = _YEAR.search(name)
    year = (year.group(1) or year.group(2)) if year else ''
    episode = _EPISODE.match(name)
    if episode and (episode.group('s') or episode.group('s2')):
        season = int(episode.group('s') or episode.group('s2'))
        number = int(episode.group('e') or episode.group('e2'))
        return 's', norm(episode.group('name')), year, season, number
    return 'm', norm(name), year, 0, 0


def _hash(url):
    return hashlib.sha1(str(url).encode('utf-8')).hexdigest()[:16]


def vod_row(name, url):
    kind, key, year, season, episode = parse(name)
    if not key or '\t' in url or '\n' in url:
        return None
    label = ' '.join(str(name).split())[:120]
    return '\t'.join((kind, key, year, str(season), str(episode), label, _hash(url), url)) + '\n'


# ---- IPTV VOD: the source ----------------------------------------------
def vod_lists(folder):
    return [row for row in load(folder) if row.get('vod') and Path(vod_file(folder, row)).exists()]


def search(folder, kind, name, year='', season=None, episode=None, limit=MAX_ROWS):
    """[(list row, label, hash)] - the index lines of this title."""
    key = norm(name)
    if not key:
        return []
    want = 's' if season is not None else 'm'
    found = []
    for row in vod_lists(folder):
        try:
            handle = open(vod_file(folder, row), encoding='utf-8')
        except OSError:
            continue
        with handle:
            for line in handle:
                if not line.startswith(want + '\t'):
                    continue
                parts = line.rstrip('\n').split('\t')
                if len(parts) < 8 or parts[1] != key:
                    continue
                if want == 's' and (int(parts[3] or 0), int(parts[4] or 0)) != (season, episode):
                    continue
                if want == 'm' and year and parts[2] and abs(int(parts[2]) - int(year)) > 1:
                    continue
                found.append((row, parts[5], parts[6]))
                if len(found) >= limit:
                    return found
    return found


def _token(list_id, digest):
    return SCHEME + base64.urlsafe_b64encode(json.dumps({'l': list_id, 'h': digest}).encode('utf-8')).decode('ascii')


def rows(folder, media_type, video_id, title=None):
    """Stremio-shaped rows for the source list. ``title(kind, imdb)`` -> (name, year)."""
    from .debrid import _video_ref, title_of
    ref = _video_ref(media_type, video_id)
    if not ref or not vod_lists(folder):
        return []
    kind, stremio_id, season, episode = ref
    name, year = (title or title_of)(kind, stremio_id.split(':')[0])
    several = len(vod_lists(folder)) > 1
    out = []
    for row, label, digest in search(folder, kind, name, year, season, episode):
        quality = re.search(r'(?<!\d)(2160|1080|720|480)p|\b4k\b|\buhd\b', label, re.I)
        out.append({'name': '[IPTV] %s\n%s' % (SOURCE_NAME, quality.group(0).upper() if quality else (row.get('name') if several else 'IPTV')),
                    'title': label + (('\n' + row.get('name')) if several else ''),
                    'url': _token(row['id'], digest),
                    'behaviorHints': {'filename': label, 'bingeGroup': 'iptv-%s' % row['id']}})
    return out


def jobs(folder, media_type, video_id, configured=True):
    """[(name, fn)] while IPTV is set up and a list has IPTV VOD on."""
    if not configured or not vod_lists(folder):
        return []
    origin = {'id': SOURCE_ID, 'name': SOURCE_NAME, 'base_url': ''}
    return [(SOURCE_NAME, lambda: [dict(row, _meganexus_source=origin) for row in rows(folder, media_type, video_id)])]


def resolve(folder, token):
    """The link of an IPTV VOD row (read from the index now)."""
    raw = str(token or '')[len(SCHEME):]
    raw += '=' * (-len(raw) % 4)
    info = json.loads(base64.urlsafe_b64decode(raw.encode('ascii')).decode('utf-8'))
    row = find(folder, info.get('l'))
    if row is None:
        raise ValueError('This IPTV list was removed.')
    with open(vod_file(folder, row), encoding='utf-8') as handle:
        for line in handle:
            parts = line.rstrip('\n').split('\t')
            if len(parts) >= 8 and parts[6] == info.get('h'):
                return parts[7]
    raise ValueError('The IPTV list no longer has this one.')
