# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Watch Party in the MegaNexus service (7.0.52).

The party engine (party_engine) lives here, for as long as Kodi runs and Watch Party is
on. A small HTTP API serves both the phone (the party page at the TV's address: chat,
pause / play, seek, members, invites) and the TV's own Watch Party screen (on 127.0.0.1;
its key is in the profile, readable by this user only). Every request needs the key.

While a party plays: the host's player is read every second (JSON-RPC - it never holds
Python, player_state) and its state goes to the party on every change and every few
seconds; a guest's player follows the host (seek / pause / play). What the host plays -
the title and the release, never a link - goes to the guests when it starts; a guest's
MegaNexus plays the same release from its own sources, or the host's shared stream when
the host chose to share it (party_bridge.shareable: a plain CDN link only).

Chat lines show at the bottom of the player (Window(Home) properties, no dialog, never the
focus) and go after MESSAGE_SECONDS.
"""
import json
import os
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PROP = 'meganexus.party.'
API_FILE = 'party_api.json'
SETTING = 'watch_party'                 # 'true' (default) / 'false'
FINDABLE = 'watch_party_findable'       # others can find me by my profile name
MESSAGES = 'watch_party_messages'       # chat lines in the player ('true' default)
SHARE = 'watch_party_share'             # host: share my stream ('false' default)
MESSAGE_SECONDS = 5                     # a message in the player (7.0.55: like the user asked)
# 7.0.60: TorBox's file link is shared (the host was told it carries the TorBox key); an add-on's
# own link (its configuration), Easynews' login or our Usenet player never are
NOT_SHARED = 'This stream cannot be shared - only a TorBox link is. Guests play it from their own add-ons.'
NEEDS_TORBOX = 'Share my stream needs TorBox on this TV - add your TorBox key first.'
LINES = 3
TICK = 1.0
FILM_GONE = 6.0                         # s the host's film is gone before the party hears it stopped
SETTLE = 4.0                            # a guest's player after a correction: let it buffer first
PORT = 8095                             # the phone page's port - always the same, so is its address
PORT_TRIES = 15                         # a Kodi still closing holds it a moment: asked again first
PORT_WAIT = 1.0
ELSEWHERE_CHECK = 30                    # s: another Kodi holds Watch Party - is it still there
BODY_MAX = 64 * 1024

_service = {}


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Watch Party: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def _addon():
    from .settings_cache import cached_addon
    return cached_addon()


def _on(setting, default=True):
    try:
        value = _addon().getSetting(setting)
    except Exception:
        value = ''
    return default if value == '' else value == 'true'


PILL_WIDTHS = (360, 520, 720, 960, 1240)   # skin.meganexus VideoFullScreen.xml: the five message pills
CHAR_WIDTH = 14                             # font12 at 1080 lines, a little wide on purpose
PILL_PADDING = 64


def pill_size(text):
    """Which of the player's message pills fits the text (1-5; a longer one scrolls)."""
    width = PILL_PADDING + CHAR_WIDTH * len(str(text).replace('[B]', '').replace('[/B]', ''))
    return next((i + 1 for i, w in enumerate(PILL_WIDTHS) if width <= w), len(PILL_WIDTHS))


SCROLL_SPEED = 90                           # px/s - the pills' <scrollspeed> (Custom_1112_PartyMessages.xml)
SCROLL_WAIT = 2.0                           # s: Kodi waits before a long label starts to move, and a moment at its end


def seconds_for(text):
    """How long a message stays: MESSAGE_SECONDS, or as long as a long one needs to scroll to
    its end (7.0.61: it went after 5 s while still scrolling)."""
    width = PILL_PADDING + CHAR_WIDTH * len(str(text).replace('[B]', '').replace('[/B]', ''))
    over = width - PILL_WIDTHS[-1]
    return MESSAGE_SECONDS if over <= 0 else max(MESSAGE_SECONDS, SCROLL_WAIT * 2 + over / float(SCROLL_SPEED))


def has_emoji(text):
    """7.0.61: the message has an emoji - its pill draws it with the chat font (MNChat.ttf: text and
    emoji); every other one keeps Kodi's own font (it has Chinese, Japanese and Korean too)."""
    for char in str(text or ''):
        code = ord(char)
        if code >= 0x1F000 or 0x2600 <= code <= 0x27BF or 0x2B05 <= code <= 0x2B55 or 0x231A <= code <= 0x23FF \
                or code == 0xFE0F:
            return True
    return False


def _plain(text):
    """A name or message as plain text in Kodi's labels (no [B] / [COLOR] of its own)."""
    return str(text or '').replace('[', '(').replace(']', ')')


def _home():
    import xbmcgui
    return xbmcgui.Window(10000)


def _rpc(method, params=None):
    import xbmc
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        return (json.loads(xbmc.executeJSONRPC(json.dumps(request))) or {}).get('result')
    except Exception:
        return None


# --- the player, through JSON-RPC ---------------------------------------------------------

def player_now():
    """{'playerid', 'paused', 'pos', 'dur'} of the video playing, or None."""
    players = _rpc('Player.GetActivePlayers') or []
    video = next((p for p in players if isinstance(p, dict) and p.get('type') == 'video'), None)
    if not video:
        return None
    props = _rpc('Player.GetProperties', {'playerid': video['playerid'], 'properties': ['time', 'totaltime', 'speed']}) or {}

    def ms(value):
        value = value or {}
        return ((value.get('hours', 0) * 60 + value.get('minutes', 0)) * 60 + value.get('seconds', 0)) * 1000 + value.get('milliseconds', 0)
    return {'playerid': video['playerid'], 'paused': props.get('speed', 1) == 0, 'pos': ms(props.get('time')),
            'dur': ms(props.get('totaltime'))}


def player_do(action, position_ms=None):
    now = player_now()
    if not now:
        return False
    if position_ms is not None and action in ('seek', 'play', 'pause'):
        total = max(0, int(position_ms)) // 1000
        _rpc('Player.Seek', {'playerid': now['playerid'],
                             'value': {'time': {'hours': total // 3600, 'minutes': total // 60 % 60, 'seconds': total % 60,
                                                'milliseconds': int(position_ms) % 1000}}})
    if action == 'pause' and not now['paused']:
        _rpc('Player.PlayPause', {'playerid': now['playerid'], 'play': False})
    elif action == 'play' and now['paused']:
        _rpc('Player.PlayPause', {'playerid': now['playerid'], 'play': True})
    return True

def _wordmark():
    """The MegaNexus wordmark (script.meganexus), as the setup page shows it."""
    try:
        import xbmcaddon
        folder = xbmcaddon.Addon('script.meganexus').getAddonInfo('path')
    except Exception:
        folder = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))))), 'script.meganexus')
    try:
        with open(os.path.join(folder, 'resources', 'media', 'meganexus_wordmark.png'), 'rb') as handle:
            return handle.read()
    except OSError:
        return b''


# --- the service -----------------------------------------------------------------------------

class PartyService(object):
    def __init__(self, engine):
        self.engine = engine
        self.key = secrets.token_urlsafe(18)
        self.server = None
        self.lines = []                     # (shown until, text)
        self.last_until = 0.0               # the Home pill's message goes then
        self.media_at = ''
        self.last_sent = 0.0
        self.last_state = None
        self.pending = None                 # a guest's latest host state, to follow
        self.settle_until = 0.0
        self.started_media = None           # a guest: the host's film this TV started by itself
        self.applied_event = None           # a guest: the host's last event followed here
        self.film_on = False                # a guest: the party's film plays here
        self.start_until = 0.0              # the host: holding the film until the guests' films play
        self.start_paused = False
        self.film_gone = 0.0                # the host: when the party's film stopped playing here
        self.stopping = threading.Event()
        engine.on_change = self._changed
        engine.on_chat = self._chat
        engine.on_state = self._state
        engine.on_media = self._media
        engine.on_invite = self._invite
        engine.on_control = self._guest_control
        engine.on_dm = self._dm

    # --- start / stop -------------------------------------------------------------------------
    def start(self):
        self.engine.start()
        self._serve()
        threading.Thread(target=self._loop, name='MegaNexusParty', daemon=True).start()
        self._changed()
        return self

    def stop(self):
        self.stopping.set()
        try:
            self.engine.stop()
        except Exception:
            pass
        if self.server is not None:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
        try:
            home = _home()
            for name in ('on', 'count', 'invites', 'requests', 'waiting', 'hosting', 'url', 'msg.last', 'msg.last.emoji', 'unread', 'online') \
                    + tuple('msg.%d' % i for i in range(LINES)) + tuple('msg.%d.size' % i for i in range(LINES)):
                home.clearProperty(PROP + name)
        except Exception:
            pass

    def _serve(self):
        from .phone_setup import lan_ip
        service = self
        try:                                            # the same key as before: the phone's page and
            from .party_identity import _read           # its address stay the same after a restart
            self.key = str(_read(API_FILE, {}).get('key') or '') or self.key
        except Exception:
            pass

        class Handler(BaseHTTPRequestHandler):
            server_version = 'MegaNexusParty'
            sys_version = ''

            def log_message(self, *args):
                pass                                    # paths carry the key: never logged

            def _send(self, code, body, ctype='application/json; charset=utf-8'):
                data = body if isinstance(body, bytes) else body.encode('utf-8')
                self.send_response(code)
                self.send_header('Content-Type', ctype)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Referrer-Policy', 'no-referrer')
                self.end_headers()
                self.wfile.write(data)

            def _key_ok(self):
                from urllib.parse import urlsplit, parse_qs
                given = self.headers.get('X-Party-Key') or (parse_qs(urlsplit(self.path).query).get('k') or [''])[0]
                return secrets.compare_digest(given, service.key)

            def do_GET(self):
                from urllib.parse import urlsplit
                path = urlsplit(self.path).path
                if not self._key_ok():
                    return self._send(403, '{"ok":false,"error":"Scan the QR code on the TV again."}')
                resources = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                if path == '/':
                    with open(os.path.join(resources, 'phone_setup', 'party.html'), 'rb') as handle:
                        page = handle.read().replace(b'__KEY__', service.key.encode('ascii'))
                    return self._send(200, page, 'text/html; charset=utf-8')
                if path == '/app.webmanifest':                  # the phone's home-screen app
                    return self._send(200, json.dumps({
                        'name': 'MegaNexus Watch Party', 'short_name': 'Watch Party',
                        'start_url': '/?k=' + service.key, 'scope': '/', 'display': 'standalone',
                        'background_color': '#0b1020', 'theme_color': '#0b1020',
                        'icons': [{'src': '/icon.png?k=' + service.key, 'sizes': '1024x1024', 'type': 'image/png'}]}),
                        'application/manifest+json')
                if path == '/icon.png':
                    with open(os.path.join(resources, 'media', 'meganexus_icon.png'), 'rb') as handle:
                        return self._send(200, handle.read(), 'image/png')
                if path == '/logo.png':                         # the MegaNexus wordmark at the top of the page
                    return self._send(200, _wordmark(), 'image/png')
                if path == '/api/party/state':
                    return self._send(200, json.dumps(dict(service.state(), ok=True)))
                self._send(404, '{"ok":false}')

            def do_POST(self):
                from urllib.parse import urlsplit
                if not self._key_ok():
                    return self._send(403, '{"ok":false,"error":"Scan the QR code on the TV again."}')
                try:
                    length = int(self.headers.get('Content-Length') or 0)
                except ValueError:
                    length = -1
                if length < 0 or length > BODY_MAX:
                    return self._send(413, '{"ok":false}')
                try:
                    body = json.loads(self.rfile.read(length).decode('utf-8') or '{}') if length else {}
                    result = service.call(urlsplit(self.path).path, body if isinstance(body, dict) else {})
                    self._send(200, json.dumps(dict(result or {}, ok=True)))
                except ValueError as exc:
                    self._send(200, json.dumps({'ok': False, 'error': str(exc)[:200]}))
                except Exception as exc:
                    _log('a phone request failed (%s)' % type(exc).__name__)
                    self._send(200, json.dumps({'ok': False, 'error': 'That did not work. Try again.'}))

        for attempt in range(PORT_TRIES if PORT else 0):
            try:
                self.server = ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
                break
            except OSError:
                if self.stopping.wait(PORT_WAIT):
                    raise RuntimeError('stopped while the port was busy')
        if self.server is None:                         # still taken: another port (the QR shows it)
            self.server = ThreadingHTTPServer(('0.0.0.0', 0), Handler)
            if PORT:
                _log('port %d stayed busy - the phone needs the new QR code' % PORT)
        self.server.daemon_threads = True
        threading.Thread(target=self.server.serve_forever, name='MegaNexusPartyServer', daemon=True).start()
        port = self.server.server_address[1]
        self.url = 'http://%s:%d/?k=%s' % (lan_ip(), port, self.key)
        try:                                            # the TV's own screen: this profile only
            from .party_identity import _write
            _write(API_FILE, {'port': port, 'key': self.key, 'url': self.url})
        except Exception:
            pass

    # --- what the phone and the TV ask --------------------------------------------------------
    def state(self):
        snap = self.engine.snapshot()
        # 7.0.55: the controls are for the party's film only - never a trailer or another video
        now = player_now() if snap['party'] and self._party_film(self.engine.party) else None
        snap['player'] = {'paused': now['paused'], 'pos': now['pos'], 'dur': now['dur']} if now else None
        from .party_bridge import torbox_on
        snap['settings'] = {'findable': _on(FINDABLE, False), 'messages': _on(MESSAGES), 'share': _on(SHARE, False),
                            'torbox': torbox_on()}
        return snap

    def call(self, path, body):
        e = self.engine
        routes = {
            '/api/party/create': lambda: {'party': e.create()},
            '/api/party/leave': lambda: e.leave(),
            '/api/party/invite': lambda: e.invite(str(body.get('public') or '')),
            '/api/party/code': lambda: {'code': e.open_code()},
            '/api/party/join': lambda: e.join_code(str(body.get('code') or '')),
            '/api/party/accept': lambda: e.accept(str(body.get('party') or '')),
            '/api/party/decline': lambda: e.decline(str(body.get('party') or '')),
            '/api/party/approve': lambda: e.approve(str(body.get('public') or '')),
            '/api/party/deny': lambda: e.deny(str(body.get('public') or '')),
            '/api/party/remove': lambda: e.remove(str(body.get('public') or '')),
            '/api/party/say': lambda: {'sent': self._said(body.get('text'))},
            '/api/party/play': lambda: self.play_here(),
            '/api/party/dm': lambda: {'sent': e.message(str(body.get('public') or ''), body.get('text'))},
            '/api/party/read': lambda: e.read(str(body.get('public') or '')),
            '/api/party/newkey': lambda: self.new_key(),
            '/api/party/control': lambda: self.control(body),
            '/api/party/find': lambda: {'found': e.find(code=str(body.get('code') or ''), name=str(body.get('name') or ''))},
            '/api/party/friend/add': lambda: {'pair': e.add_friend(str(body.get('public') or ''), str(body.get('name') or ''))},
            '/api/party/friend/accept': lambda: {'pair': e.accept_friend(str(body.get('public') or ''))},
            '/api/party/friend/remove': lambda: e.remove_friend(str(body.get('public') or '')),
            '/api/party/setting': lambda: self.setting(body),
        }
        if path not in routes:
            raise ValueError('Unknown request.')
        result = routes[path]()
        self._changed()
        return result if isinstance(result, dict) else {}

    def control(self, body):
        """Pause / play / seek from the phone. The host's player does it and everyone follows;
        a guest's phone asks the host (through the party)."""
        action = str(body.get('action') or '')
        party = self.engine.party
        if party is not None and not party.hosting:
            position = int(float(body['position']) * 1000) if 'position' in body else None
            delta = int(float(body.get('delta') or 0) * 1000) if 'delta' in body else None
            self.engine.ask_host(action, position, delta)
            return {}
        now = player_now()
        if not now:
            raise ValueError('Nothing is playing.')
        if action == 'toggle':
            action = 'play' if now['paused'] else 'pause'
        if action == 'seek':
            target = int(float(body['position']) * 1000) if 'position' in body else now['pos'] + int(float(body.get('delta') or 0) * 1000)
            player_do('seek', max(0, target))
        elif action in ('pause', 'play'):
            player_do(action)
        else:
            raise ValueError('Unknown control.')
        self.last_sent = 0                             # the host's new state goes out at once
        return {}

    @staticmethod
    def _party_film(party):
        """The party's film is what plays here (a trailer, a preview or another video is not)."""
        if party is None or not party.media:
            return False
        try:
            from .party_bridge import playing_now
            return playing_now(party.media)
        except Exception:
            return False

    def new_key(self):
        """A new phone link: the old one (a guest who once scanned the QR) stops working."""
        from .phone_setup import lan_ip
        self.key = secrets.token_urlsafe(18)
        self.url = 'http://%s:%d/?k=%s' % (lan_ip(), self.server.server_address[1], self.key)
        try:
            from .party_identity import _write
            _write(API_FILE, {'port': self.server.server_address[1], 'key': self.key, 'url': self.url})
        except Exception:
            pass
        return {'url': self.url}

    def _said(self, text):
        """Our own message: to the party, and in our own player too."""
        sent = self.engine.say(text)
        if sent and self.engine.party is not None and self.engine.party.chat:
            self._chat(self.engine.party.chat[-1])
        return sent

    def play_here(self):
        """A guest: the host's film on this TV (when it did not start by itself)."""
        party = self.engine.party
        if party is None or party.hosting:
            raise ValueError('Only a guest plays the host\'s film.')
        if not party.media:
            raise ValueError('The host is not playing anything yet.')
        self._media(party.media, party.share, announce=False, asked=True)
        return {}

    def setting(self, body):
        names = {'findable': FINDABLE, 'messages': MESSAGES, 'share': SHARE}
        name = str(body.get('name') or '')
        if name not in names:
            raise ValueError('Unknown setting.')
        if name == 'share' and body.get('on'):
            from .party_bridge import torbox_on
            if not torbox_on():
                raise ValueError(NEEDS_TORBOX)
        _addon().setSetting(names[name], 'true' if body.get('on') else 'false')
        from .settings_cache import invalidate
        invalidate()
        if name == 'findable':
            self.engine.findable = bool(body.get('on'))
            threading.Thread(target=self.engine._announce, daemon=True).start()
        party = self.engine.party
        if name == 'share' and party is not None and party.hosting and party.media:
            threading.Thread(target=self._reshare, args=(bool(body.get('on')),), daemon=True).start()
        return {}

    def _reshare(self, on):
        """Share turned on / off during a film: the guests get (or lose) the stream at once."""
        try:
            from .party_bridge import shared_stream
            party = self.engine.party
            if party is not None and party.hosting and party.media:
                share = shared_stream() if on else None
                if on and share is None:
                    self._line(NOT_SHARED)
                self.engine.set_media(party.media, share)
        except Exception as exc:
            _log('sharing not changed (%s)' % type(exc).__name__)

    # --- the party's events ---------------------------------------------------------------------
    def _changed(self):
        try:
            snap = self.engine.snapshot()
            party = snap['party']
            home = _home()
            home.setProperty(PROP + 'on', '1' if party else '')
            home.setProperty(PROP + 'hosting', '1' if party and party['hosting'] else '')
            home.setProperty(PROP + 'count', str(len(party['members'])) if party else '')
            home.setProperty(PROP + 'invites', str(len(snap['invites'])) if snap['invites'] else '')
            requests = sum(1 for f in snap['friends'] if f.get('state') == 'asking')
            home.setProperty(PROP + 'requests', str(requests) if requests else '')
            home.setProperty(PROP + 'waiting', str(len(party['waiting'])) if party and party['waiting'] else '')
            home.setProperty(PROP + 'url', getattr(self, 'url', ''))
            unread = sum(int(f.get('unread') or 0) for f in snap['friends'])
            home.setProperty(PROP + 'unread', str(unread) if unread else '')
            online = sum(1 for f in snap['friends'] if f.get('online'))
            home.setProperty(PROP + 'online', str(online) if online else '')
        except Exception:
            pass

    def _chat(self, message):
        self._line('[B]%s[/B]   %s' % (_plain(message['name']), _plain(message['text'])))

    def _line(self, text):
        """A message or notice: a pill in the player (setting "Messages in the player") and the
        latest one under the Watch Party button on Home - never a Kodi notification."""
        self.last_until = time.time() + max(MESSAGE_SECONDS * 2, seconds_for(text[:160]))
        try:                                            # Home: the latest one beside Watch Party
            _home().setProperty(PROP + 'msg.last.emoji', '1' if has_emoji(text) else '')
            _home().setProperty(PROP + 'msg.last', text[:160])
        except Exception:
            pass
        if _on(MESSAGES):
            self.lines.append((time.time() + seconds_for(text[:160]), text[:160]))
            self.lines = self.lines[-LINES:]
        self._show_lines()

    def _show_lines(self):
        now = time.time()
        self.lines = [(until, text) for until, text in self.lines if until > now]
        try:
            home = _home()
            newest = [text for _, text in reversed(self.lines)]          # msg.0: the newest, at the bottom
            shown = tuple(newest[i] if i < len(newest) else '' for i in range(LINES))
            if shown != getattr(self, '_shown', None):                   # 7.0.59: only a change redraws the player
                self._shown = shown
                for i, text in enumerate(shown):
                    home.setProperty(PROP + 'msg.%d.size' % i, str(pill_size(text)) if text else '')
                    home.setProperty(PROP + 'msg.%d.emoji' % i, '1' if has_emoji(text) else '')
                    home.setProperty(PROP + 'msg.%d' % i, text)
            if self.last_until and now > self.last_until:
                self.last_until = 0.0
                home.clearProperty(PROP + 'msg.last')
        except Exception:
            pass

    def _dm(self, message):
        """A friend's direct message: a pill (in the player and on Home - never a Kodi
        notification); the Watch Party button gets its dot (meganexus.party.unread)."""
        self._line('[B]%s[/B] to you   %s' % (_plain(message['name']), _plain(message['text'])))
        self._changed()

    def _invite(self, invite):
        self._line('[B]%s[/B]   invites you to watch together - open Watch Party' % _plain(invite['name']))

    def _guest_control(self, sender, payload):
        name = (self.engine.party.members.get(sender) or {}).get('name', 'A guest') if self.engine.party else 'A guest'
        body = {'action': payload.get('action')}
        if payload.get('pos') is not None:
            body['position'] = int(payload['pos']) / 1000.0
        elif payload.get('delta') is not None:
            body['delta'] = int(payload['delta']) / 1000.0
        try:
            self.control(body)
            self._line('[B]%s[/B]   %s' % (_plain(name), {'pause': 'paused', 'play': 'resumed', 'toggle': 'paused / resumed'}.get(body['action'], 'moved the film')))
        except ValueError:
            pass

    def _state(self, state):
        self.pending = state

    def _media(self, media, share, announce=True, asked=False):
        """The host started something: the same here (unless it already plays)."""
        if not media:
            self.started_media = None          # the host stopped: the same film again starts again
            return
        key = (media.get('id'), str(media.get('season') or ''), str(media.get('episode') or ''))
        if not asked and key == self.started_media:
            return            # the same film again (someone joined, a link shared): started once, never again
        if not asked:
            self.started_media = key
            if player_now() and not self._party_film(self.engine.party):
                # the guest watches something else: never cut off - a pill says where the party is
                self._line('The party plays [B]%s[/B] - Watch Party > Watching to join' % _plain(media.get('title') or 'a film'))
                return
        try:
            home = _home()
            home.setProperty(PROP + 'play', json.dumps({'media': media, 'share': share, 'at': time.time(), 'asked': asked}))
            import xbmc
            xbmc.executebuiltin('RunScript(script.meganexus,party_play)')
        except Exception:
            pass
        if announce:
            self._line('Playing together: %s' % (media.get('title') or ''))

    # --- every second ------------------------------------------------------------------------------
    def _loop(self):
        import xbmc
        monitor = xbmc.Monitor()
        while not self.stopping.is_set() and not monitor.waitForAbort(TICK):
            try:
                self._tick()
            except Exception as exc:
                _log('tick (%s)' % type(exc).__name__)

    def _tick(self):
        if self.lines or self.last_until:
            self._show_lines()
        party = self.engine.party
        if party is None:
            return
        try:
            if self.engine.keep_alive():                   # 7.0.58: the host went quiet - the party is over
                self._line('The party has ended - the host is gone')
                self._changed()
                return
        except Exception:
            pass
        if party.hosting:
            self._host_tick()
        else:
            self._guest_tick(party)

    def _guest_tick(self, party):
        """7.0.55: the guest follows the host's EVENTS (start, play, pause, jump); between them it
        plays at its own pace (party_sync) - no seeking every few seconds."""
        from . import party_sync
        try:
            self.engine.hello_again()                     # 7.0.56: until the host answers
            self.engine.keep_clock()                      # 7.0.61: the host's clock against ours
        except Exception:
            pass
        if not self._party_film(party):
            self.film_on = False                       # never another video of the guest's
            return
        started = not self.film_on
        if started:
            self.film_on = True
            self.engine.ready(party.media)              # the host waits for this at the start
        if self.pending is None or time.time() < self.settle_until:
            return
        now = player_now()
        if not now:
            return
        event = started or self.pending.get('event') != self.applied_event
        todo = party_sync.correction(now['pos'], now['paused'], self.pending, int(time.time() * 1000), event)
        if event:
            self.applied_event = self.pending.get('event')
        if todo:
            player_do(todo[0], todo[1])
            self.settle_until = time.time() + SETTLE      # a jump is not at once: no jump after jump

    def _host_tick(self):
        from . import party_sync
        home = _home()
        media = home.getProperty(PROP + 'media')
        if media and media != self.media_at:
            self.media_at = media
            try:
                from .party_bridge import shared_stream
                data = json.loads(media)
                share = shared_stream() if _on(SHARE, False) else None
                if _on(SHARE, False) and share is None:
                    self._line(NOT_SHARED)
                self.engine.set_media(data.get('media'), share)
                # 7.0.55: the film waits, paused, until the guests' films play - everyone starts together
                self.start_until, self.start_paused, self.last_state = time.time() + party_sync.START_WAIT, False, None
            except Exception as exc:
                _log('the film was not shared (%s)' % type(exc).__name__)
        now = player_now() if self._party_film(self.engine.party) else None   # not a trailer or another video
        if not now:
            self.last_state = None
            self._film_stopped()
            return
        self.film_gone = 0.0
        if self.start_until and self._starting(now):
            return
        paused, position = now['paused'], now['pos']
        if self.last_state is None:
            bump = True
        else:
            was_paused, was_at, when = self.last_state
            expected = was_at + (0 if was_paused else (time.time() - when) * 1000)
            bump = paused != was_paused or abs(position - expected) > party_sync.SEEK_AFTER_MS
        if bump or time.time() - self.last_sent >= party_sync.STATE_EVERY:
            self.engine.send_state(paused, position, now['dur'], bump=bump)
            self.last_sent = time.time()
        self.last_state = (paused, position, time.time())

    def _film_stopped(self):
        """The host stopped the party's film: after FILM_GONE seconds (a jump or a reload is quicker)
        everyone hears that nothing plays - "Watching" goes on every TV and phone."""
        party = self.engine.party
        if party is None or not party.media:
            return
        if not self.film_gone:
            self.film_gone = time.time()
            return
        if time.time() - self.film_gone < FILM_GONE:
            return
        self.film_gone, self.start_until = 0.0, 0
        try:
            _home().clearProperty(PROP + 'media')
            self.media_at = ''
            self.engine.set_media(None)
        except Exception as exc:
            _log('the film end was not told (%s)' % type(exc).__name__)

    def _starting(self, now):
        """The host at the start: True while the film is held for the guests."""
        if not self.engine.guests():
            self.start_until = 0                         # nobody to wait for
            return False
        if not self.start_paused:
            if not now['paused']:
                player_do('pause')
            self.start_paused = True
            self.engine.send_state(True, now['pos'], now['dur'], waiting=True, bump=True)
            self.last_sent = time.time()
            self._line('Waiting for everyone\'s film to start')
            return True
        go = self.engine.guests_ready() or time.time() > self.start_until or not now['paused']   # the host pressed play
        if go:
            self.start_until = 0
            if now['paused']:
                player_do('play')
            self.engine.send_state(False, now['pos'], now['dur'], bump=True)
            self.last_sent = time.time()
            self.last_state = (False, now['pos'], time.time())
            self._line('Everyone is in - playing')
            return True
        if time.time() - self.last_sent >= 5:
            self.engine.send_state(True, now['pos'], now['dur'], waiting=True)
            self.last_sent = time.time()
        return True


def start(monitor=None):
    """The service, a little after Kodi starts (never while Home loads)."""
    if not _on(SETTING) or _service.get('running') or _service.get('starting'):
        return
    _service['starting'] = True

    def later():
        import xbmc
        watch = monitor or xbmc.Monitor()
        try:
            if watch.waitForAbort(20):
                return
            # another Kodi holds Watch Party: this one takes over when that one closes
            while not _start_now() and _running_elsewhere():
                if watch.waitForAbort(ELSEWHERE_CHECK) or not _on(SETTING):
                    return
        finally:
            _service.pop('starting', None)
    threading.Thread(target=later, name='MegaNexusPartyStart', daemon=True).start()


def _running_elsewhere():
    """Another Kodi of this profile already runs Watch Party (its address answers with our
    key): this one stays out - two would answer for the same person."""
    found = api()
    if not found:
        return False
    from urllib.request import Request, urlopen
    try:
        with urlopen(Request('http://127.0.0.1:%d/api/party/state' % found[0], headers={'X-Party-Key': found[1]}),
                     timeout=3) as reply:
            return bool(json.loads(reply.read().decode('utf-8')).get('ok'))
    except Exception:
        return False


def _start_now():
    """True once Watch Party runs here."""
    try:
        if _running_elsewhere():
            if not _service.get('told'):
                _service['told'] = True
                _log('already running in another Kodi - not started here (takes over when that one closes)')
            return False
        from .party_engine import PartyEngine
        engine = PartyEngine(findable=_on(FINDABLE, False))
        _service['running'] = PartyService(engine).start()
        _log('ready')
        return True
    except Exception as exc:
        _log('not started (%s)' % type(exc).__name__)
        return False


def stop():
    running = _service.pop('running', None)
    if running is not None:
        running.stop()


def sleep():
    """Kodi goes to standby: the host ends the party for everyone, a guest leaves (7.0.58)."""
    stop()


def wake():
    """Back from standby: Watch Party again, with no party."""
    start()


def follow_setting():
    """Watch Party turned off (or on again) on its screen: at once, no wait."""
    if not _on(SETTING):
        stop()
        try:                                            # the TV screen sees it is off
            os.remove(os.path.join(_profile(), API_FILE))
        except OSError:
            pass
    elif not _service.get('running') and not _service.get('starting'):
        threading.Thread(target=_start_now, name='MegaNexusPartyStart', daemon=True).start()


def _profile():
    from .meganexus.common import profile_path
    return profile_path()


def api():
    """The TV screen's way in: (port, key) of this profile's party service, or None."""
    try:
        from .party_identity import _read
        data = _read(API_FILE, {})
        return (int(data['port']), data['key'], data.get('url', '')) if data.get('key') else None
    except Exception:
        return None
