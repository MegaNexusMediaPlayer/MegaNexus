# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""8.0.1: MegaNexus' settings readable again after Kodi went back to an older build.

Kodi marks the settings file with its own format number (Kodi 21: 2, Kodi 22 builds: 3-5)
and refuses a file with a higher number than it knows ("unable to read setting values from
version 5 (current version: 4)"): every setting reads as its default and nothing typed in
stays - API keys included. The values themselves are the same in every format, so when Kodi
did not load the file, the number goes back to 2 (every Kodi from 21 reads it). A file Kodi
loaded is never touched."""
import os
import re
import xml.etree.ElementTree as ET

ADDON_ID = 'plugin.video.meganexus'
READABLE = 2       # the format every Kodi from 21 reads
SAMPLE = 12        # values compared with what Kodi answers
_ROOT = re.compile(r'(<settings\b[^>]*?\bversion=")(\d+)(")')


def _defaults(addon_path):
    try:
        root = ET.parse(os.path.join(addon_path, 'resources', 'settings.xml')).getroot()
    except Exception:
        return {}
    return {node.get('id'): node.get('default', '') for node in root.iter('setting') if node.get('id')}


def _changed_values(text, defaults):
    """Values of the file that differ from their default (only those show whether Kodi read it)."""
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return {}
    values = {}
    for node in root.iter('setting'):
        key = node.get('id')
        value = node.get('value', node.text or '') or ''
        if key and key in defaults and value and value != defaults[key] and node.get('default') != 'true':
            values[key] = value
    return values


def unreadable(text, defaults, read):
    """True when the file has a newer format than 2 and Kodi answers none of its values."""
    found = _ROOT.search(text[:400])
    if not found or int(found.group(2)) <= READABLE:
        return False
    values = list(_changed_values(text, defaults).items())[:SAMPLE]
    if not values:
        return False
    return not any(read(key) == value for key, value in values)


def readable(text):
    return _ROOT.sub(lambda m: m.group(1) + str(READABLE) + m.group(3), text, count=1)


def repair():
    """Called by the service before anything reads a setting. Returns True when it fixed the file."""
    import xbmc
    import xbmcaddon
    import xbmcvfs
    addon = xbmcaddon.Addon(ADDON_ID)
    path = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('profile')), 'settings.xml')
    try:
        with open(path, encoding='utf-8') as handle:
            text = handle.read()
    except OSError:
        return False
    if not unreadable(text, _defaults(xbmcvfs.translatePath(addon.getAddonInfo('path'))), addon.getSetting):
        return False
    temp = path + '.mnx-tmp'
    with open(temp, 'w', encoding='utf-8') as handle:
        handle.write(readable(text))
    os.replace(temp, path)
    xbmc.log('[MegaNexus] settings: Kodi could not read the settings file (a newer Kodi wrote it) - made readable again',
             xbmc.LOGWARNING)
    return True
