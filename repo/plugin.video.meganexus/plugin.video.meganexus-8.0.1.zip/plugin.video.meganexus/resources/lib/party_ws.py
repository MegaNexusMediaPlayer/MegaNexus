# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A small WebSocket client (RFC 6455) for the Watch Party's Nostr relays (7.0.52).

Kodi's Python has no WebSocket; Nostr relays speak only that. Text frames, ping / pong,
close, fragmented messages, client masking; TLS through the ssl module (certificates
checked). One connection per relay; party_relays reads it on a thread of its own.
"""
import base64
import hashlib
import os
import socket
import ssl
import struct
from urllib.parse import urlparse

GUID = b'258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
MAX_MESSAGE = 1024 * 1024          # a relay's message bigger than this is dropped (the connection closes)
CONNECT_TIMEOUT = 10


class WebSocketError(Exception):
    pass


class Closed(WebSocketError):
    pass


class WebSocket(object):
    def __init__(self, url, timeout=CONNECT_TIMEOUT, context=None):
        parts = urlparse(url)
        if parts.scheme not in ('ws', 'wss') or not parts.hostname:
            raise WebSocketError('not a ws(s) address')
        port = parts.port or (443 if parts.scheme == 'wss' else 80)
        raw = socket.create_connection((parts.hostname, port), timeout=timeout)
        try:
            if parts.scheme == 'wss':
                raw = (context or ssl.create_default_context()).wrap_socket(raw, server_hostname=parts.hostname)
            self.sock = raw
            self.buffer = b''
            self._handshake(parts, port)
        except Exception:
            raw.close()
            raise
        self.closed = False

    def _handshake(self, parts, port):
        key = base64.b64encode(os.urandom(16)).decode('ascii')
        host = parts.hostname + ('' if port in (80, 443) else ':%d' % port)
        path = (parts.path or '/') + ('?' + parts.query if parts.query else '')
        request = ('GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n'
                   'Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\nUser-Agent: MegaNexus\r\n\r\n') % (path, host, key)
        self.sock.sendall(request.encode('ascii'))
        while b'\r\n\r\n' not in self.buffer:
            chunk = self.sock.recv(4096)
            if not chunk or len(self.buffer) > 65536:
                raise WebSocketError('no handshake')
            self.buffer += chunk
        head, self.buffer = self.buffer.split(b'\r\n\r\n', 1)
        lines = head.decode('latin-1').split('\r\n')
        if ' 101 ' not in lines[0] + ' ':
            raise WebSocketError('refused (%s)' % lines[0][:40])
        headers = {k.strip().lower(): v.strip() for k, _, v in (line.partition(':') for line in lines[1:])}
        accept = base64.b64encode(hashlib.sha1(key.encode('ascii') + GUID).digest()).decode('ascii')
        if headers.get('sec-websocket-accept') != accept:
            raise WebSocketError('bad handshake')

    def settimeout(self, value):
        self.sock.settimeout(value)

    def _frame(self, opcode, payload):
        header = bytes((0x80 | opcode,))
        length = len(payload)
        if length < 126:
            header += bytes((0x80 | length,))
        elif length < 65536:
            header += bytes((0x80 | 126,)) + struct.pack('>H', length)
        else:
            header += bytes((0x80 | 127,)) + struct.pack('>Q', length)
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        self.sock.sendall(header + mask + masked)

    def send(self, text):
        if self.closed:
            raise Closed('closed')
        self._frame(0x1, text.encode('utf-8'))

    def _read(self, count):
        while len(self.buffer) < count:
            chunk = self.sock.recv(65536)
            if not chunk:
                self.closed = True
                raise Closed('connection closed')
            self.buffer += chunk
        data, self.buffer = self.buffer[:count], self.buffer[count:]
        return data

    def receive(self):
        """The next text message (str). Answers pings; raises Closed when the relay closes;
        socket.timeout when nothing came in time."""
        parts, opcode = [], None
        while True:
            first, second = self._read(2)
            final, code = first & 0x80, first & 0x0F
            length = second & 0x7F
            if length == 126:
                length = struct.unpack('>H', self._read(2))[0]
            elif length == 127:
                length = struct.unpack('>Q', self._read(8))[0]
            if length > MAX_MESSAGE:
                self.close()
                raise WebSocketError('message too large')
            mask = self._read(4) if second & 0x80 else None
            payload = self._read(length) if length else b''
            if mask:
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
            if code == 0x8:
                self.closed = True
                raise Closed('closed by the relay')
            if code == 0x9:
                self._frame(0xA, payload)
                continue
            if code == 0xA:
                continue
            if code in (0x1, 0x2):
                opcode, parts = code, [payload]
            elif code == 0x0 and opcode is not None:
                parts.append(payload)
                if sum(len(p) for p in parts) > MAX_MESSAGE:
                    self.close()
                    raise WebSocketError('message too large')
            else:
                continue
            if final:
                return b''.join(parts).decode('utf-8', 'replace')

    def ping(self):
        if not self.closed:
            self._frame(0x9, b'mnx')

    def close(self):
        if self.closed:
            try:
                self.sock.close()
            except Exception:
                pass
            return
        self.closed = True
        try:
            self._frame(0x8, struct.pack('>H', 1000))
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass
