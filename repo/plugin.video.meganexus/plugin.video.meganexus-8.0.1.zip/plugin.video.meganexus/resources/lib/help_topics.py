# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The user guide's topics (7.0.42: shared by HUB Settings > Help & support on the
TV, meganexus_ui/help_guide.py, and the Help tab of the phone page, phone_setup.py).

Pure data: (key, title, text). Text uses Kodi's [B]..[/B] for headings; the phone
page turns them into headings of its own.
"""

B, E = '[B]', '[/B]'


def _h(text):
    return '%s%s%s' % (B, text, E)


TOPICS = (
    ('start', 'Getting started', '\n'.join((
        _h('The two screens'),
        'The HUB is the start screen with the pills at the bottom: MegaNexus, IPTV Channels, Sport, '
        'HUB Settings, Kodi Settings and Power. "MegaNexus" opens Home - your rows of films and series.',
        '',
        _h('Home'),
        'Up / Down moves between rows, Left / Right along a row. OK opens a title (Continue Watching '
        'resumes it straight away). Long OK or the menu key opens Title options (Play, Trailer, Library, '
        'Mark watched, Remove from Continue Watching...). The Info key shows the full description.',
        'At the top: Home, Library, Search, Settings and HUB.',
        '',
        _h('The quickest set-up'),
        'HUB Settings > Set up on phone · QR code. Scan the code with the phone (same Wi-Fi) and do '
        'everything there: Nuvio or Stremio sign-in, add-ons, API keys, collections, screensaver and badges. '
        'Keep the QR screen open until you press "Save & start MegaNexus".',
        '',
        _h('Quick setup: streams, metadata and collections in one step'),
        'On the phone page, Quick setup makes two add-ons for you: MegaNexus Streams (AIOStreams) and MegaNexus '
        'Metadata (AIOMetadata), with a full set of collections and their pictures. It needs one key for streams - '
        'TorBox, Premiumize, Offcloud or Easynews - and a TMDB key; a TVDB key and a Gemini key are optional.',
        'They are added beside your own add-ons: an AIOStreams or AIOMetadata you already use stays as it is. '
        'Your backup keeps both set-ups with their keys. "Change configuration" (also on the phone) opens the '
        'set-up page of any AIOStreams or AIOMetadata you have - ours or your own.',
        '',
        _h('Typing with the phone'),
        'Every on-screen keyboard has "Write with phone" above the keys: scan the QR code, type on the phone and tap '
        '"Send to TV" - the text goes into the keyboard and OK is pressed. Passwords are typed in a hidden field.',
        '',
        _h('Like MegaNexus?'),
        'HUB Settings > Buy me a coffee · Ko-fi (right under the phone set-up) - a QR code to support the development.',
    ))),
    ('addons', 'Add-ons, manifests and debrid', '\n'.join((
        _h('Where films come from'),
        'MegaNexus plays what your add-ons find - the same add-ons as the Nuvio and Stremio apps. '
        'Each add-on is a link to its manifest (it ends in manifest.json). There are four kinds:',
        '  - Metadata: catalogs, posters, descriptions (Cinemeta is built in; AIOMetadata, TMDB add-ons...).',
        '  - Streams: the links that play (Torrentio, Comet, MediaFusion, AIOStreams...).',
        '  - Subtitles: OpenSubtitles and other subtitle add-ons.',
        '  - Sport: live events and their streams.',
        '',
        _h('Adding an add-on'),
        '1. Open the add-on\'s Configure page in a browser (for example torrentio.strem.fun/configure, or the '
        'Configure link on the add-on\'s website).',
        '2. Choose its options - languages, quality, and your debrid service with its API key.',
        '3. Copy the installed link (the manifest URL).',
        '4. HUB Settings > Connections > Add-ons > Your add-ons > Add a configured add-on link - or paste it on '
        'the phone page (Add-ons tab).',
        'Already using Nuvio or Stremio? Connections > Add-ons > Import add-ons from Nuvio / Stremio brings '
        'all of them over at once.',
        '',
        _h('Debrid'),
        'A debrid service (TorBox, Real-Debrid, Premiumize, AllDebrid...) turns torrent results into fast '
        'direct links. Its key goes into the stream add-on\'s Configure page. TorBox, Premiumize and Offcloud '
        'can also be used without an add-on: HUB Settings > Debrid & Prowlarr (with your own Prowlarr\'s '
        'torrent indexers too); their keys can be typed on the phone setup page. "Debrid: cached (instant) results '
        'first" puts links that start at once at the top. Usenet (Easynews, your provider and indexers): '
        'HUB Settings > Usenet - see "Usenet & NZB sources".',
    ))),
    ('usenet', 'Usenet & NZB sources', '\n'.join((
        _h('What you need'),
        'Usenet is a paid network of servers that keep releases. Two things are needed:',
        '  - a Usenet provider - the account films are read from (Eweka, Newshosting, Frugal Usenet, Easynews...);',
        '  - something that searches it - an indexer (NZBgeek, DrunkenSlug, NZBFinder...). MegaNexus asks your '
        'indexers itself (below), or a stream add-on does (for example Usenet Streamer).',
        'Easynews is built in as well (its own search).',
        '',
        _h('The simplest way: Easynews'),
        '1. HUB Settings > Connections > API keys > Easynews: type username:password (or on the phone page, API keys).',
        '2. HUB Settings > Usenet > Easynews: type the login there (or on the phone page) - its streams are on.',
        'Its sources appear as "[EN+] Easynews" next to your add-ons\' sources. No add-on and no Usenet server needed.',
        '',
        _h('Usenet Streamer and other Usenet add-ons'),
        'Usenet Streamer runs on your own server (Docker) with Prowlarr / NZBHydra or Newznab indexers; set it up in '
        'its own dashboard, then add its manifest link like any add-on (see "Add-ons, manifests and debrid") and switch it '
        'ON in Stream add-ons. It has two modes:',
        '  - NZBDav mode: it gives ordinary links - they play like any other source.',
        '  - Native mode: it gives NZB sources (a link to the NZB + the Usenet servers). MegaNexus plays them with its '
        'own Usenet player. Enter your provider in its dashboard (NNTP) so it sends the servers, or add your Usenet '
        'server in MegaNexus (below).',
        'MegaNexus asks every add-on for the title you open by the ID it understands best (IMDb when it takes it), so '
        'it searches exactly that film or episode.',
        '',
        _h('Adding your Usenet server'),
        '1. HUB Settings > Usenet > Usenet server.',
        '2. Address: only the server name, for example news.provider.com (Easynews: news.eu.easynews.com). A special '
        'port goes after a colon: news.provider.com:443. Do not type https:// or nntps://.',
        '3. Username and password: the Usenet (NNTP) login from your provider - often not the website login.',
        '4. Connections: how many your plan allows (MegaNexus uses up to 12).',
        'MegaNexus finds the port and SSL by itself (563 or 443 with SSL, else 119) and tests the login: "Login works". '
        'On the phone page (API keys): username:password@news.provider.com.',
        'Your server is also the backup when a source\'s own server lacks part of a film.',
        '',
        _h('Your own indexers (Newznab)'),
        'With your Usenet server set, MegaNexus searches your indexers straight from this box - with your API keys, '
        'no add-on and no server in between.',
        '1. HUB Settings > Usenet > Newznab indexers > Add an indexer.',
        '2. Pick your indexer from the list (NZBgeek, DrunkenSlug, NZBFinder, NzbPlanet...) and type only its API key - '
        'the list says where it is (usually the indexer\'s profile page). With a TorBox key in API keys, TorBox Search '
        'is added without typing anything. Another indexer (or a Prowlarr / NZBHydra link): its address and key.',
        'MegaNexus tests the key at once; add as many indexers as you like. On the phone page (API keys): the '
        'indexer\'s name and key, several separated by commas - nzbgeek KEY, drunkenslug KEY.',
        'A film is searched by its IMDb ID, an episode by IMDb ID, season and episode (by its name where the indexer '
        'takes no IMDb ID for series). The sources appear as "[NZB] indexer name"; each answer is kept 6 hours to '
        'spare your daily API calls. Passworded posts and samples are left out.',
        'Within your limits: MegaNexus counts each indexer\'s searches and NZB downloads a day and uses its own '
        'limits when it reports them (else at most 200 searches a day), stops at 90 %, and an indexer that says '
        '"limit reached" rests until the next day - no account gets suspended for asking too much. It only asks '
        'when you open a title\'s sources, never in the background; each answer is kept 6 hours. Indexers > '
        'Newznab indexers shows how many searches each made today.',
        'Before an NZB plays, a few parts through the film are checked on your Usenet server (over the connections '
        'the player opens anyway). A release whose parts are mostly gone is not played - Autoplay goes on to the next source.',
        _h('Spotnet: an index built on this box'),
        'With only your Usenet provider - no indexer account - MegaNexus can build its own index of films and '
        'series from Spotnet, an index that lives on Usenet itself (the free.pt group). HUB Settings > Usenet > '
        'Spotnet: the first time about a month of the newest spots is read (a few minutes), then the new ones every '
        '6 hours while nothing plays. Its releases appear as "[SPOT] Spotnet" next to your indexers\' and add-ons\'; '
        'only proven spots are kept, never erotica. Its releases are mostly European. Switch it off there at any time.',
        '',
        'Quickest start: HUB Settings > Usenet > Set up Usenet - your provider first, then your indexers from the list.',
        '',
        _h('The fast Usenet player'),
        'Big releases and 4K need speed, so MegaNexus has two faster ways to read Usenet, both automatic:',
        '  - on CoreELEC, LibreELEC and Linux, the reading runs in its own process on all the processor\'s cores '
        '(it starts about a minute after Kodi; until then the usual player plays);',
        '  - a native player (vfs.meganexus) that MegaNexus installs by itself for your system - Android, '
        'CoreELEC / Linux and Windows, Kodi 21 and 22 - never while a film plays.',
        'Stop leaves a Usenet film at once with either of them. Nothing to set up; without them films play as before.',
        '',
        _h('What plays'),
        'Plain video files and films stored in RAR volumes (also with scrambled names) play and can be fast-forwarded. '
        'Compressed, encrypted or 7z releases can not be streamed - MegaNexus says so; choose another source. A small '
        'missing piece is a short glitch, not a stop.',
        '',
        _h('Choosing and waiting'),
        'Choose streams manually shows every add-on in its own tab. A slow add-on (Usenet searches take time) joins '
        'the open list when it answers - the title shows "Searching: <add-on>" for up to a minute. Its answer is kept '
        'for 30 minutes, so the next time - Autoplay too - its sources are there at once.',
        '',
        _h('When it does not work'),
        '"needs a Usenet server" - add your Usenet server (above). "address ... not found" - check the spelling. '
        '"login refused" - check the username and password. "no Usenet server answered" - type the port after the '
        'address. No Usenet sources at all - check that the add-on is ON in Stream add-ons and that its indexers work '
        'in its own dashboard.',
    ))),
    ('connections', 'Connections', '\n'.join((
        _h('Accounts & tracking'),
        'Nuvio account - sign in to bring your add-ons, collections, library and progress from the Nuvio '
        'apps; Nuvio sync direction decides whether MegaNexus only reads or also writes back.',
        'Stremio (beta) - your Stremio add-ons and Continue Watching.',
        'Trakt, Simkl, MDBList - tracking services: what you watch is marked there, their watchlists appear '
        'in the Library, Continue Watching follows them. MDBList also gives the ratings row (IMDb, Rotten '
        'Tomatoes, Metacritic, Letterboxd...) - choose the services in MDBList ratings.',
        '',
        _h('Add-ons'),
        'Metadata, stream, subtitle and sport add-ons (see "Add-ons, manifests and debrid"), Refresh add-on '
        'catalogs now, Remove an add-on, and the YouTube add-on used for some trailers.',
        '',
        _h('API keys'),
        'TMDb - actor search, recommendations and TMDB pictures. MDBList - ratings and tracking. '
        'Fanart.tv - posters, backgrounds and logos made by fans. TheIntroDB - where intros and credits are '
        '(Skip button). Keys are free from each service\'s website.',
        'A TMDb key is recommended for much more than pictures: a film\'s release badge (In cinemas or '
        'Released once it is out digitally or on Blu-ray), the Digital release filter, details and trailers '
        'for titles your metadata add-on only knows by their TMDb ID, and More like this. Without it a film '
        'shows only Released or Coming by its release date, and the Digital release filter lets everything play.',
        '',
        _h('Verify tracking connections'),
        'Checks that every connected service answers and syncs.',
    ))),
    ('home', 'Home & library', '\n'.join((
        _h('Home & appearance'),
        'Use MegaNexus skin - the HUB look; Kodi\'s own screens follow the theme too.',
        'Layout & cards - Home layout (MegaNexus collections or MegaNexus rows), portrait posters or landscape '
        'cards, and how see-through the posters are.',
        'Home content & titles - the big title area (hero), card titles, ratings, row titles, animated art.',
        'Artwork - where posters, backgrounds, title logos and landscape cards come from: the catalog, TMDB '
        'or Fanart.tv (needs its key), and their language (English, Kodi\'s language, or without text). A title '
        'the provider has no picture for keeps the catalog\'s.',
        '',
        _h('Collections & Home rows'),
        'Which collections and catalogs are rows on Home, their order and names.',
        'Hide unreleased titles - films and series whose release date lies ahead stay out of Home, collections '
        'and search, and episodes not aired yet out of a series\' episode list.',
        '',
        _h('Local & network storage'),
        'Local storage - folders on a USB disk, NAS or SMB/NFS share. Add the folder (Kodi opens Videos > '
        'Files > Add videos); MegaNexus reads it itself and shows Local Movies and Local Series on Home and '
        'in the Library. Names like "Title (2019)" and "Show/Season 1/Show S01E02" work best.',
        'Plex, Jellyfin, Emby - sign in to your server; its Continue watching and Recently added appear on '
        'Home and in the Library, and its copy of a title is offered as a source.',
        '',
        _h('Continue Watching'),
        'How far back it shows titles, unaired next episodes, refresh interval, and "start with the last '
        'link" (resume with the same source within 12 or 24 hours).',
        '',
        _h('Library'),
        'Local: titles you saved (Title options > Add to Library), this device\'s storage and your servers. '
        'The tracking tab: Trakt / Simkl / MDBList watchlists. Calendar: everything by the month it was added.',
    ))),
    ('playback', 'Playback & subtitles', '\n'.join((
        _h('Playback'),
        'Autoplay the best stream - starts the first matching link without the source list.',
        'Digital release filter - a film only in cinemas, or an episode not aired yet, is not searched or played '
        '(also a manual search and Continue Watching); it tells you when it comes out. Films over a year old '
        'always play. Uses TMDb\'s release dates (digital, Blu-ray, TV) - needs a TMDb key for films.',
        'Continue Watching · start with the last link - reuse the source you used last time.',
        'Automatic stream choice - what "best" means: highest resolution, HDR, Dolby Vision, cached only...',
        'Intro, credits & next episode - Skip button or automatic skipping (times from TheIntroDB, your '
        'Plex / Jellyfin / Emby server and the file\'s chapters); "Next episode" appears beside "Skip outro", '
        'or from the point an episode counts as watched when the credits are unknown.',
        '',
        _h('Subtitles'),
        'Subtitle language, subtitles on video start, subtitle add-ons and Autosync subtitle offset (on by default).',
        'Subtitles come from your subtitle add-ons (their manifests, AIOStreams...), never Kodi\'s own subtitle '
        'service. When a release cannot be downloaded (its server is off or answers with an error), the next '
        'release of the same language is taken; in the list a failed version is marked with ✕.',
        _h('Autosync subtitle'),
        'A subtitle made for another release of the film starts early or late, or drifts away over the film. '
        'The Autosync subtitle button in the player (beside Offset) fixes that in a few seconds, without AI: it '
        'compares the subtitle on screen with the other subtitles of the same title from your subtitle add-ons, '
        'in any language (people speak at the same moments in every language), finds the shift and the speed '
        'difference most of them agree on, and loads the corrected subtitle at once. When they do not agree, '
        'nothing changes - then choose another version. Turn it off with Playback & subtitles > Subtitles > Autosync subtitle offset.',
        '',
        _h('Trailers'),
        'Automatic trailers on Home and the title page, their source, quality, delay and length.',
        '',
        _h('Stream badges'),
        'The pictures in the source list (4K, HDR, Dolby Vision, Atmos...). Import Nuvio badge JSON links or a '
        'file from the badge builder; preview a stream name on the phone page.',
    ))),
    ('player', 'The player', '\n'.join((
        'OK during a video opens the player bar. Buttons from the left:',
        '  Pause / Play · Sources (pause and choose another source, it carries on from the same minute) · '
        'Subtitles (search all subtitle add-ons) · Offset (subtitle delay) · Autosync subtitle · Audio · '
        'Info · Stats - and Settings at the right end.',
        'The seek line: Left / Right step back and forward; the line shows where you will land and the video '
        'jumps once you stop pressing. OK on the line pauses.',
        'Next episode and Skip intro / outro appear at the bottom right when they apply.',
        'The player bar hides after 5 seconds without a key press - not while the film is paused, and not while '
        'a menu opened from it (subtitles, audio, sources, offset, settings, info...) is still open.',
        '',
        _h('Home while a film plays'),
        'The house button (beside Settings) takes you back to where you started the film; it keeps playing. '
        '"Now playing" at the top of MegaNexus Home and on the HUB brings it back to full screen. Back from the '
        'player stops the film as before.',
        '',
        _h('Starting a film'),
        'The loading screen shows the title\'s picture and its logo filling up. Back and Esc wait while a chosen '
        'source starts (after 25 seconds a source that does not open can be left). Searching subtitles or sources '
        'during a film shows a small pill at the bottom - the film stays in view.',
        'Colours glaring when an HDR film starts or ends? Kodi Settings > System > Display > "Adjust display HDR '
        'mode" switches the screen into HDR; where the interface cannot be drawn in HDR (some Linux desktops), '
        'turn it off and Kodi converts HDR films itself.',
    ))),
    ('party', 'Watch Party', '\n'.join((
        _h('Watch together'),
        'Watch a film at the same time as friends on their own TVs, with messages and a phone remote. There is no '
        'account and no MegaNexus server: the TVs talk through public relays, and everything is encrypted.',
        'Open it with the round button at the top of Home, next to HUB. In a party, the button shows how many '
        'people are in it; a dot means an invite, a friend request, a new message or someone waiting to come in.',
        '',
        _h('Start a party'),
        '1. Watch Party > Start a party.',
        '2. Invite a friend (Invite a friend), or give others a join code (Join code - it works for 10 minutes; you '
        'let each person in).',
        '3. Play a film as usual. It starts on every TV in the party.',
        '',
        _h('Join one'),
        'An invite from a friend shows on Home and in Watch Party - select it. With a join code: Watch Party > Join '
        'with a code, and the host lets you in.',
        '',
        _h('How the film plays on every TV'),
        'Each TV plays the film from its own stream add-ons - the same release when it has it. The host\'s film waits '
        'until everyone\'s has started, then all play together. Pause, play and jumps by the host happen on every '
        'TV; between them each TV plays at its own pace, so a few seconds apart is normal. A guest\'s phone can pause '
        'and jump too - the host\'s TV does it for everyone.',
        'A guest needs a stream add-on of its own - or the host shares the film: "Share my stream" (Watch Party '
        'settings, with TorBox on the host\'s TV) gives guests without the film the host\'s TorBox link to it. That '
        'link has the host\'s TorBox key in it - a guest could find it in their Kodi log; MegaNexus never keeps it in '
        'the guest\'s settings or history. Share only with people you trust.',
        'If a guest is watching something else when the host starts a film, it is not cut off: Watch Party > '
        'Watching plays the party\'s film when the guest is ready.',
        '',
        _h('The phone remote'),
        'Watch Party > Phone remote: scan the QR code (same Wi-Fi). The page shows the film, pause / play, jumps of '
        '10 and 30 seconds, a slider, who is in, the messages and your friends. Add it to the phone\'s home screen '
        '(iPhone: Share > Add to Home Screen; Android: browser menu > Add to Home screen) - its link stays the same. '
        'To keep it working for good, give the TV a fixed address in your router. Watch Party settings > New phone '
        'link makes the old link stop working.',
        'On a computer with a firewall, allow Kodi (port 8095) for the home network, or the phone cannot reach it.',
        '',
        _h('Messages'),
        'Messages written on the phone show on every TV: bottom right in the player, one pill each, for a few '
        'seconds; and under the Watch Party button on Home. Turn them off in Watch Party settings > Messages in the player.',
        '',
        _h('Friends'),
        'Watch Party > Friends: everyone has a friend code (Watch Party settings). Add a friend by code, or by name '
        'when they chose "Friends can find me by name". Both TVs show the same check code - compare it once. A green '
        'dot shows who is online; select a friend to read and write messages (they reach their TV and phone). '
        '"Remove friend" is at the bottom, or hold OK on a name.',
        '',
        _h('When a party ends'),
        'The host ends it with End the party - and it also ends when the host\'s TV goes to standby, restarts or '
        'is gone for a minute and a half. After a restart no party is kept.',
        '',
        _h('Watch Party settings'),
        'HUB Settings > Watch Party: Watch Party on this TV, Friends can find me by name, Messages in the player, '
        'Share my stream, your friend code and New phone link.',
    ))),
    ('downloads', 'Downloads', '\n'.join((
        _h('Keep a film or an episode on this device'),
        '1. HUB Settings > Downloads > Download folder: a folder on this device, a USB disk or a network share.',
        '2. In the source list, hold OK on a source (or press the menu key) and choose Download. The list stays '
        'open, so you can still play something.',
        '3. A small blue ring by the clock fills as it downloads. Select it (Right from the top buttons of '
        'MegaNexus Home, Up on the HUB) for the box with size, speed and time left: "Close · continue" or "Stop".',
        '',
        _h('Nothing stops it'),
        'The download runs in the background - the screensaver, a film or closing MegaNexus do not stop it. When '
        'the internet drops it waits and carries on from where it was. Into a folder on this device it also '
        'carries on after Kodi restarts; on a network share that file starts again.',
        '',
        _h('What can be downloaded'),
        'Direct links (debrid services: TorBox, Real-Debrid...). Torrents, live streams (HLS) and add-on links '
        'cannot be. A debrid link can expire after some hours - then start the download again from the sources.',
        'HUB Settings > Downloads lists every download: select one to see where it was saved, or to remove it.',
    ))),
    ('livetv', 'Live TV, IPTV & Sport', '\n'.join((
        _h('IPTV'),
        'Set up IPTV with an Xtream account (server, username, password) or an M3U playlist with an XMLTV '
        'guide. Channels load in the background when Kodi starts. In IPTV Channels: categories on the left, '
        'OK plays a preview, OK again full screen; the guide shows past programmes when the playlist offers '
        'catch-up. Pause / rewind (timeshift) is experimental.',
        '',
        _h('IPTV lists'),
        'Add as many M3U or Xtream lists as you like (Live TV, IPTV & Sport > IPTV lists). Each has its own '
        'switches: Live TV (its channels in the TV list), IPTV VOD (its films and series as a source) and '
        'Groups; a list can be renamed or removed.',
        'Only live TV in the channel list (on by default): films and series of a list never load as channels - '
        'they are recognised by what the playlist itself says (media marks, a movie / series type, a link to a '
        'video file or a film / series path), never by group names. Less memory and a faster start.',
        'Groups (the button next to Refresh guide): switch channel groups such as countries on or off. '
        'Switched-off groups are not loaded at all.',
        'IPTV VOD: while IPTV is set up, the films and series of your lists show in a title\'s source list next '
        'to the stream add-ons. Nothing loads in advance - a small index on the device is searched by the '
        'title\'s English name and year (or season and episode).',
        '',
        _h('Sport'),
        'Sport add-ons list live events; resting on an event for five seconds can start it.',
    ))),
    ('themes', 'Themes & screensaver', '\n'.join((
        'HUB - MegaNexus, IPTV, Sport and the settings as glass pills in the theme\'s colours; above them "Trending now on TMDB", a large '
        'picture that changes every 10 seconds (needs a TMDb key; Home & appearance switches it off).',
        'Screensaver studio - "Trending now on TMDB" (on by default when a TMDb key is set). The screensaver '
        'opens without any darkening. Kodi has one screensaver at a time: with the MegaNexus screensaver off, '
        'Screensaver > "With the MegaNexus screensaver off" chooses Kodi\'s Dim or nothing.',
        'Theme - Light, Dark, Dim, or a custom theme from your own background.',
        'Wallpaper - the background of Home, catalogs, Live TV, Sport and the HUB.',
        'Interface colours - match the background, variation and strength; or your own colour for each '
        'part: accent, background, panels, pills, selection and text (swatches or a hex code).',
        'Screensaver - when it starts, its background (pictures, your posters or a video), clock and widgets.',
        'Clock & weather - on every MegaNexus screen, and the weather location.',
        'Experimental video wallpaper - a looping video behind the interface; it pauses for trailers, Sport, '
        'IPTV and films.',
    ))),
    ('performance', 'Performance & image cache', '\n'.join((
        'Memory - MegaNexus gives freed memory back to the system after you leave it, after a video and while '
        'the remote rests. Memory used during a film (the video decoder) comes back when it ends.',
        'Memory for posters and catalogs - how much RAM pictures may use (more = faster scrolling).',
        'Prepare posters and ratings when MegaNexus opens - every time, the opening screen stays until Kodi '
        'keeps 90 % of the posters of Home and of every collection\'s first page (pictures that cannot load '
        'do not count; Back skips - a first setup runs until then, the day\'s new posters at most a minute), and fetches their MDBList ratings in a few requests '
        '(at most 60 % of your daily MDBList requests - the rest stays for titles you open). When everything '
        'is there, Home opens at once.',
        'Cache usage - the posters Kodi keeps on the device and MegaNexus\'s image memory.',
        'Clear MegaNexus images and metadata cache - when pictures look wrong or old.',
        'System check - add-ons that slow MegaNexus down.',
        'Diagnostics overlay - CPU, RAM, FPS and the video / audio format on screen.',
    ))),
    ('backup', 'Backup & maintenance', '\n'.join((
        'Backup & restore - save all settings, keys and add-ons to a file, restore them on another device.',
        'Maintenance & updates - check for updates (automatic updates from GitHub), run set-up again, reset '
        'MegaNexus, or remove the MegaNexus build.',
    ))),
    ('whatsnew', 'What is new, and what is missing', '\n'.join((
        _h('New in 8.0 (since 7.0.43)'),
        'Watch Party: watch together with friends, a phone remote, messages in the player, friends and direct '
        'messages (see "Watch Party").',
        'Phone: Quick setup - streams, metadata and collections in one step; profiles; the posters layout and Browse all.',
        'Profiles: who is watching, with a picture or initials and an optional PIN; each has its own accounts, '
        'Continue Watching and Library.',
        'Usenet: your own Newznab indexers, Spotnet, releases checked before they play, and a faster player.',
        'Live TV and Sport: OK plays small, OK again opens the full player; catch-up for any IPTV list.',
        'Home: the MegaNexus posters layout, all your collections, Library views; title pages with reviews and '
        'episode ratings.',
        'Subtitles: Autosync goes further with each press, and a synced subtitle is kept for the film.',
        'Playback: Skip outro as its own option, Next episode when a stream ends early, films with DTS-HD sound '
        'continue where you stopped.',
        '',
        _h('New in 7.0.36 - 7.0.42'),
        'Home: one row at a time at the bottom with the focused title\'s description above it (also inside '
        'collections); Ongoing / Ended badges for series; release badges at once.',
        'HUB: modern glass pills; Trending now on TMDB.',
        'Playback: "Next episode" 1 min 30 s before the end when the credits are unknown, as the next episode\'s '
        'picture; the player\'s buttons keep Skip intro / Skip outro / Next episode if you closed the prompt.',
        'Stream badges: six sets to choose from (Stream badges > Badge set, or the phone\'s Badges tab).',
        'Phone: a new look, a Start tab (metadata, streams and subtitle add-ons in three steps) and this guide.',
        'IPTV: several lists, only live TV in the channel list, groups that are not loaded, IPTV VOD as a source.',
        'Sources: Offcloud and Easynews built in; with "No limit" the link fits 80 % of the network\'s speed.',
        'Memory: given back after leaving MegaNexus, after videos and while the remote rests; Kodi closes cleanly.',
        'Screensaver: no darkening on the way in; Trending now on TMDB in the studio; widgets in the theme\'s colours.',
        '',
        _h('Dimming and the MegaNexus screensaver'),
        'Kodi runs one screensaver at a time. While the MegaNexus screensaver is on, Kodi\'s own "Dim" cannot run '
        'as well - that is Kodi, not a fault. With the MegaNexus screensaver off, Screensaver > "With the MegaNexus '
        'screensaver off" chooses Kodi\'s Dim or nothing.',
        '',
        _h('Not there yet'),
        'IPTV VOD finds a title by its English name: a list that uses translated names finds fewer.',
        'Live TV without Kodi\'s TV part (channels straight from MegaNexus) - only if Kodi\'s TV part still '
        'costs much memory with live TV only.',
        'The phone setup page does not list IPTV lists and groups yet - use the TV.',
    ))),
    ('trouble', 'When something does not work', '\n'.join((
        _h('No sources'),
        'Check the stream add-ons (Connections > Add-ons) and their debrid key; a source that freezes - try '
        'another from the list, or turn on "Debrid: cached results first".',
        _h('Nothing on Home'),
        'Sign in to Nuvio or add a metadata add-on; Collections & Home rows decides what shows.',
        _h('Live TV empty'),
        'IPTV setup: check the playlist link; channels load about half a minute after Kodi starts.',
        _h('Video judders'),
        'Kodi Settings > Player > Adjust display refresh rate: "On start / stop". MegaNexus gives it back '
        'before every film even while the video wallpaper or a trailer plays.',
        _h('Search finds nothing'),
        'Search uses the search catalogs of your metadata add-ons (AIOMetadata, Cinemeta...). Check that one is '
        'switched on in Connections > Add-ons > Metadata.',
        _h('Still stuck'),
        'Connections > Verify tracking connections; HUB Settings > Performance > System check.',
        _h('Report a problem'),
        'Help & support > Report a problem: scan the QR code, describe what happened on the phone and send it. '
        'It reaches the MegaNexus developer as a GitHub issue together with the end of the Kodi log - add-on '
        'configurations, links, log-ins, keys and e-mail addresses are removed first. The report is public; '
        'three reports a day per device.',
    ))),
)
