# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Watch Party's Nostr relays (7.0.52): several public relays at once, no server of ours.

Each relay has a thread: it connects, sends our subscriptions again, reads, and on any
error waits longer each time (up to a minute) and connects again. An event is published
to every relay that is connected; one that arrives from several relays is handed on once.
Every event's signature is checked before anyone sees it. Relays that ask for a login
(NIP-42 AUTH - some serve gift wraps only to their recipient) get one, signed with our key.
Nothing of an event's content or of a relay's link goes into the log.
"""
import json
import re
import threading
import time
from collections import OrderedDict

from . import party_crypto as crypto
from .party_ws import WebSocket, Closed

# public relays (a party works while any one of them does); HUB Settings > Watch Party adds others
# 7.0.61: two more - one relay refusing us (relay.damus.io banned a household's address for its
# rate) left too few for a party; both checked to pass party messages and keep gift wraps
DEFAULT_RELAYS = ('wss://relay.damus.io', 'wss://nos.lol', 'wss://relay.primal.net', 'wss://nostr.mom',
                  'wss://offchain.pub', 'wss://relay.snort.social')
REFUSED = re.compile(r'rate|limit|banned|blocked|slow down|too many', re.I)
QUIET_FIRST, QUIET_MAX = 120.0, 1800.0             # s a relay that refused us for our rate gets nothing
RETRY_FIRST, RETRY_MAX = 2.0, 60.0
READ_TIMEOUT = 30                                   # s without a message: a ping keeps NAT routers open
SEEN = 4000                                         # event ids remembered (the same event from several relays)


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Watch Party: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def _host(url):
    return url.split('//', 1)[-1].split('/', 1)[0][:60]


class Relay(object):
    def __init__(self, url, pool):
        self.url, self.pool = url, pool
        self.ws = None
        self.lock = threading.Lock()
        self.connected = threading.Event()
        self.stopping = False
        self.quiet_until = 0.0              # 7.0.61: it refused us for our rate - nothing sent until then
        self.quiet_for = 0.0
        self.thread = threading.Thread(target=self._run, name='MegaNexusRelay', daemon=True)

    def start(self):
        self.thread.start()

    def send(self, message):
        with self.lock:
            ws = self.ws
            if ws is None or not self.connected.is_set():
                return False
            try:
                ws.send(json.dumps(message, separators=(',', ':'), ensure_ascii=False))
                return True
            except Exception:
                return False

    def _run(self):
        wait = RETRY_FIRST
        while not self.stopping:
            try:
                ws = WebSocket(self.url)
                ws.settimeout(READ_TIMEOUT)
                with self.lock:
                    self.ws = ws
                self.connected.set()
                wait = RETRY_FIRST
                for sub_id, filters in self.pool.subscriptions():
                    self.send(['REQ', sub_id] + filters)
                self.pool._relay_up(self)
                self._read(ws)
            except Exception as exc:
                if not self.stopping:
                    self.pool._relay_down(self, type(exc).__name__)
            finally:
                self.connected.clear()
                with self.lock:
                    ws, self.ws = self.ws, None
                if ws is not None:
                    ws.close()
            if self.stopping or self.pool.stopped.wait(wait):
                return
            wait = min(RETRY_MAX, wait * 2)

    def _read(self, ws):
        import socket
        while not self.stopping:
            try:
                text = ws.receive()
            except socket.timeout:
                ws.ping()
                continue
            except Closed:
                return
            try:
                message = json.loads(text)
            except ValueError:
                continue
            if isinstance(message, list) and message:
                self.pool._message(self, message)

    def stop(self):
        self.stopping = True
        with self.lock:
            ws = self.ws
        if ws is not None:
            ws.close()


class RelayPool(object):
    """``secret``: our key (32 bytes) - for relays that ask us to log in."""

    def __init__(self, relays=DEFAULT_RELAYS, secret=None):
        self.secret = secret
        self.stopped = threading.Event()
        self.lock = threading.Lock()
        self.subs = OrderedDict()           # id -> (filters, callback)
        self.seen = OrderedDict()           # (subscription, event id): from several relays, handed on once
        self.own = OrderedDict()            # our own events: never handed back to us
        self.waiting_ok = {}                # event id -> [Event, accepted relays]
        self.relays = [Relay(url, self) for url in dict.fromkeys(relays)]
        self.on_status = None

    def start(self):
        for relay in self.relays:
            relay.start()
        return self

    def stop(self):
        self.stopped.set()
        for relay in self.relays:
            relay.stop()

    def connected(self):
        return sum(1 for r in self.relays if r.connected.is_set())

    def wait_connected(self, timeout=10.0, count=1):
        until = time.monotonic() + timeout
        while self.connected() < count and time.monotonic() < until and not self.stopped.is_set():
            time.sleep(0.05)
        return self.connected() >= count

    def subscriptions(self):
        with self.lock:
            return [(sub_id, filters) for sub_id, (filters, _) in self.subs.items()]

    def subscribe(self, sub_id, filters, callback):
        """``callback(event, relay host)`` for every new verified event matching the filters."""
        with self.lock:
            self.subs[sub_id] = (list(filters), callback)
        for relay in self.relays:
            relay.send(['REQ', sub_id] + list(filters))

    def unsubscribe(self, sub_id):
        with self.lock:
            self.subs.pop(sub_id, None)
        for relay in self.relays:
            relay.send(['CLOSE', sub_id])

    def publish(self, event, wait=0.0):
        """Sent to every connected relay; with ``wait`` seconds, how many said OK."""
        waiter = [threading.Event(), set(), None]          # done, relays that said OK, how many were sent
        if wait:
            with self.lock:
                self.waiting_ok[event['id']] = waiter
        with self.lock:
            self.own[event['id']] = True
            while len(self.own) > SEEN:
                self.own.popitem(last=False)
        now = time.monotonic()
        sent = sum(1 for relay in self.relays if relay.quiet_until <= now and relay.send(['EVENT', event]))
        if not wait:
            return sent
        with self.lock:
            waiter[2] = sent
            if len(waiter[1]) >= sent:
                waiter[0].set()
        waiter[0].wait(wait)
        with self.lock:
            self.waiting_ok.pop(event['id'], None)
        return len(waiter[1])

    def _remember(self, key):
        with self.lock:
            if key in self.seen:
                return False
            self.seen[key] = True
            while len(self.seen) > SEEN:
                self.seen.popitem(last=False)
            return True

    def _message(self, relay, message):
        kind = message[0]
        if kind == 'EVENT' and len(message) >= 3 and isinstance(message[2], dict):
            event = message[2]
            key = (message[1], event.get('id'))
            with self.lock:
                entry = self.subs.get(message[1])
                if not entry or key in self.seen or event.get('id') in self.own:
                    return
            if not crypto.verify_event(event) or not self._remember(key):
                return
            try:
                entry[1](event, _host(relay.url))
            except Exception as exc:
                _log('an event was not handled (%s)' % type(exc).__name__)
        elif kind == 'OK' and len(message) >= 3:
            with self.lock:
                waiter = self.waiting_ok.get(message[1])
            if message[2] is False and REFUSED.search(str(message[3] if len(message) > 3 else '')):
                # it refused us for our rate (or banned the address): it gets nothing for a while,
                # longer each time - sending on only made it worse
                relay.quiet_for = min(QUIET_MAX, (relay.quiet_for * 2) or QUIET_FIRST)
                if relay.quiet_until <= time.monotonic():
                    _log('%s refused us (%s) - nothing sent there for %d s'
                         % (_host(relay.url), str(message[3])[:60], relay.quiet_for))
                relay.quiet_until = time.monotonic() + relay.quiet_for
            elif message[2] is True:
                relay.quiet_for = 0.0
            if waiter is not None and message[2] is True:
                with self.lock:
                    waiter[1].add(relay.url)
                    if waiter[2] is not None and len(waiter[1]) >= waiter[2]:
                        waiter[0].set()
        elif kind == 'AUTH' and len(message) >= 2 and self.secret:
            event = crypto.sign_event(22242, '', [['relay', relay.url], ['challenge', str(message[1])]], self.secret)
            relay.send(['AUTH', event])
            for sub_id, filters in self.subscriptions():      # asked again, now logged in
                relay.send(['REQ', sub_id] + filters)

    def _relay_up(self, relay):
        if self.on_status:
            self.on_status(self.connected(), len(self.relays))

    def _relay_down(self, relay, reason):
        _log('%s not reachable (%s) - trying again' % (_host(relay.url), reason))
        if self.on_status:
            self.on_status(self.connected(), len(self.relays))
