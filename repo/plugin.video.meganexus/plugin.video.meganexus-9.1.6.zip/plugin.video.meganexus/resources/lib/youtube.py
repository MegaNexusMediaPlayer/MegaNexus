# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""YouTube for the HUB's YouTube app (9.0.6): what youtube.com's own pages ask its web API
(InnerTube: youtubei/v1 search and browse) - no key, no account, no other add-on.

Nothing of it is kept on disk: answers live in this process' memory only while the app is
open (KEEP seconds, at most MEMORY of them) and forget() drops them when it closes - "yt
nesmimo spremati nista trajno u cache samo dok app radi, da ne usporava ostatak MegaNexusa".
The channels the person adds are theirs (CHANNELS in the profile), not a cache.

Videos play through Kodi's YouTube add-on (play_path), the same way the trailers do.
"""
import json
import os
import re
import threading
import time
from collections import OrderedDict
from urllib.request import Request, urlopen

from .kodi_text import world

API = 'https://www.youtube.com/youtubei/v1/%s?prettyPrint=false'
PAGE = 'https://www.youtube.com/'
AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36'
VERSION = '2.20261029.11.00'   # the web client's version when youtube.com's page cannot be read
TIMEOUT = 8
KEEP = 600            # s an answer is reused while the app is open
MEMORY = 48           # answers held at once
CHANNELS = 'youtube_channels.json'
AUTONEXT = 'meganexus_youtube_autonext'   # Autoplay (the player's switch, Settings › YouTube): off unless turned on


def home_rows():
    """9.0.8: the names of the app's Home rows, in their order (Settings › YouTube › Rows on Home) - 9.1.2: with the
    ones to add (EXTRA, off until switched on) where they belong."""
    names = [title for title, _ in TOPICS]
    live = [title for title, _ in LIVE_ROWS]
    more = [title for title, _ in MORE_TOPICS]
    return ['Live now'] + live + [REGION] + names[:2] + ['Sports'] + names[2:] + more + [LEARNING, 'Your channels']


def _setting(addon, key, value):
    if addon is None:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.meganexus')
    if value is not None:
        addon.setSetting(key, ','.join(value))
    return [name for name in (addon.getSetting(key) or '').split(',') if name]


def hidden(addon=None, value=None):
    """The Home rows taken off (names); ``value``: a new list."""
    return _setting(addon, HIDDEN, value)


def added(addon=None, value=None):
    """9.1.2: the rows to add that were switched on (names); ``value``: a new list."""
    return _setting(addon, ADDED, value)


def shown_rows(addon=None):
    """The names of the rows the app shows, in their order: the first ones but those taken off, the ones to add that
    were switched on."""
    off, on = set(hidden(addon)), set(added(addon))
    return [name for name in home_rows() if (name in on if name in EXTRA else name not in off)]


def offered_rows():
    """The rows offered to choose from: the region's own only where MegaNexus has its words (else it is never there)."""
    return [name for name in home_rows() if name != REGION or LOCAL.get(region_language(*place()))]


def row_label(name):
    return 'From %s' % region_name() if name == REGION else name


def choose_rows(chosen, addon=None):
    """The rows chosen (names) - the first ones not chosen taken off, the ones to add chosen switched on; a row not
    offered now (the region's own elsewhere) keeps its choice."""
    offered, shown = set(offered_rows()), set(shown_rows(addon))
    chosen = set(chosen) | {name for name in shown if name not in offered}
    hidden(addon, [name for name in home_rows() if name not in EXTRA and name not in chosen])
    added(addon, [name for name in home_rows() if name in EXTRA and name in chosen])
PLAY = 'plugin://plugin.video.youtube/play/?video_id=%s&incognito=true'   # it keeps no history of them either
# search filters (what youtube.com's own filter menu sends): videos only, and how they are chosen
# 9.0.8: a category's row is this month's videos as YouTube ranks them for the region (THIS_MONTH, relevance) - the
# most viewed this week were the whole world's: with HR as the region News, Comedy, Travel and the trailers were half
# India's (measured 2026-11-04: 0-4 of 20 so ranked, 6-10 of 20 by views)
MOST_VIEWED = 'CAMSAhAB'         # most viewed
THIS_MONTH = 'EgQIBBAB'          # uploaded this month (YouTube no longer sorts its answers by date)
CHANNELS_ONLY = 'EgIQAg=='       # channels
CHANNEL_VIDEOS = 'EgZ2aWRlb3PyBgQKAjoA'   # a channel's Videos tab
CHANNEL_PAGES = 3                         # its pages read for "All videos" (30 videos each)
# the categories of the app's Home: (row name, what is searched for); search answers are
# chosen by YouTube for the region (gl) - a category word is a question, not a list of titles
# 9.0.8: no Football row - it brought F1 and basketball too, and Sports (YouTube's own page, in your region's
# language and channels) is there; Cars asks for "car review" - "cars" brought toy cars and Pixar's Cars
TOPICS = (('Music', 'music'), ('Gaming', 'gaming'), ('News', 'news'), ('Movie trailers', 'official trailer'),
          ('Podcasts', 'podcast'), ('Technology', 'tech review'),
          ('Comedy', 'comedy'), ('Science', 'science'), ('Cars', 'car review'), ('Cooking', 'recipe'),
          ('Fitness', 'workout'), ('Travel', 'travel'), ('Nature', 'nature documentary'))
HIDDEN = 'meganexus_youtube_hidden'   # 9.0.8: the Home rows you took off (Settings › YouTube › Rows on Home), by name
ADDED = 'meganexus_youtube_added'     # 9.1.2: the rows to add you switched on (the app's Options › Rows), by name
# 9.1.2: rows to add ("provjeriti koje redove sve nudi youtube addon, dodamo dodatne"). Kodi's YouTube add-on offers
# Trending (gone from YouTube in 2025), My location (its API key), Live, Upcoming and Completed live (its API key too) and
# what needs its sign-in; what YouTube itself answers without a key or an account is here: what is live now by kind
# (search's Live filter, every page of it, in the region's own words where MegaNexus has them), more categories and
# YouTube's Learning page. Off until switched on.
LIVE = 'EgJAAQ=='                    # search filter: live now
LIVE_ROWS = (('Live · News', 'news'), ('Live · Sports', 'sports'), ('Live · Gaming', 'gaming'), ('Live · Music', 'music'))
MORE_TOPICS = (('Documentaries', 'documentary'), ('History', 'history documentary'), ('Animals', 'animals'),
               ('Kids', 'kids'), ('DIY & crafts', 'diy'), ('Fashion & beauty', 'fashion'), ('Anime', 'anime'))
LEARNING, LEARNING_PAGE = 'Learning', 'UCtFRv9O2AHqOZjjynzrv-xg'   # YouTube's Learning page (its shelves, one row)
EXTRA = frozenset([title for title, _ in LIVE_ROWS + MORE_TOPICS] + [LEARNING])
REGION = 'Your region'                # 9.0.8: the region's own row, by that name in Rows on Home ("From Croatia" on Home)
SEARCH_PAGES = 2      # pages of an answer read for a row (20 videos each)
# YouTube's own Live and Sports pages (their shelves of videos)
LIVE_PAGE, SPORTS_PAGE = 'UC4R8DWoMoI7CAwX8_LjQHig', 'UCEgdi0XIXXZ-qJOFPf4JSKw'

_lock = threading.Lock()
_memory = OrderedDict()
_feeds = OrderedDict()   # 9.1.2: a row's pages and where its next one is - the row goes on as the cursor nears its end
FEEDS = 64               # rows held at once
_client = ['', 0.]


def forget():
    """The app is closing: nothing of YouTube stays behind."""
    with _lock:
        _memory.clear()
        _feeds.clear()
        _client[:] = ['', 0.]


PICTURE_HOSTS = ('i.ytimg.com', 'yt3.ggpht.com', 'yt3.googleusercontent.com')
CLOSED = 'youtube.closed'    # NotifyAll(meganexus, youtube.closed): the app has closed (the service cleans up)


def forget_pictures():
    """Kodi stores every picture it shows (its Thumbnails and Textures database); the app's go
    once it has closed. Run by the MegaNexus service, so the HUB never waits for it."""
    import xbmc

    def rpc(method, params):
        return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})) or '{}')
    ids = set()
    for host in PICTURE_HOSTS:
        found = (rpc('Textures.GetTextures', {'properties': ['url'], 'filter': {'field': 'url', 'operator': 'contains', 'value': host}})
                 .get('result') or {}).get('textures') or ()
        ids.update(item['textureid'] for item in found if isinstance(item, dict) and item.get('textureid') is not None)
    removed = sum(1 for texture_id in sorted(ids) if 'error' not in rpc('Textures.RemoveTexture', {'textureid': texture_id}))
    xbmc.log('[MegaNexus] YouTube closed: %d of its pictures removed from Kodi\'s picture store.' % removed, xbmc.LOGINFO)
    return removed


def _held(key):
    """What is kept under ``key`` while it is fresh - nothing asked (None: not kept)."""
    with _lock:
        held = _memory.get(key)
        return held[1] if held and held[0] > time.monotonic() else None


def _kept(key, make):
    now = time.monotonic()
    with _lock:
        held = _memory.get(key)
        if held and held[0] > now:
            _memory.move_to_end(key)
            return held[1]
    value = make()
    if value:
        with _lock:
            _memory[key] = (now + KEEP, value)
            while len(_memory) > MEMORY:
                _memory.popitem(last=False)
    return value


def place():
    """(hl, gl): the language and region set in Kodi's YouTube add-on (its own Language and Region), else the ones
    chosen for the MegaNexus Catalog (Settings). 9.0.8: the add-on's were never read - Croatia set there gave no
    "From Croatia" row; the add-on's own defaults (en, US) mean "not set" and leave MegaNexus' choice."""
    try:
        from .settings_snapshot import cached_addon
        addon = cached_addon()
        language = addon.getSetting('meganexus_catalog_language') or 'en-US'
        region = addon.getSetting('meganexus_catalog_region') or 'US'
        # 9.1.2: chosen in the app's Options - its own, whatever the add-on's default (United States chosen there is)
        chosen_language, chosen_region = addon.getSetting(APP_LANGUAGE), addon.getSetting(APP_REGION)
    except Exception:
        language, region, chosen_language, chosen_region = 'en-US', 'US', '', ''
    try:
        import xbmcaddon
        theirs = xbmcaddon.Addon('plugin.video.youtube')
        own_language, own_region = theirs.getSetting('youtube.language') or '', theirs.getSetting('youtube.region') or ''
    except Exception:
        own_language = own_region = ''
    if own_region and own_region.upper() != YOUTUBE_DEFAULT[1]:
        region = own_region
    if own_language and own_language.split('-')[0].lower() != YOUTUBE_DEFAULT[0]:
        language = own_language
    region, language = chosen_region or region, chosen_language or language
    return language.split('-')[0].lower() or 'en', region.upper() or 'US'


YOUTUBE_DEFAULT = ('en', 'US')       # the YouTube add-on's own defaults: not chosen by anyone
APP_REGION, APP_LANGUAGE = 'meganexus_youtube_region', 'meganexus_youtube_language'   # 9.1.2: the app's Options


def _version():
    """The web client's version, as youtube.com's page states it - read once per app."""
    with _lock:
        if _client[0]:
            return _client[0]
    version = ''
    try:
        with urlopen(Request(PAGE, headers={'User-Agent': AGENT}), timeout=TIMEOUT) as response:
            found = re.search(r'"INNERTUBE_CLIENT_VERSION":"([0-9.]+)"', response.read().decode('utf-8', 'replace'))
            version = found.group(1) if found else ''
    except Exception:
        version = ''
    with _lock:
        _client[:] = [version or VERSION, time.monotonic()]
        return _client[0]


def _ask(endpoint, body):
    hl, gl = place()
    payload = dict(body, context={'client': {'clientName': 'WEB', 'clientVersion': _version(), 'hl': hl, 'gl': gl}})
    request = Request(API % endpoint, data=json.dumps(payload).encode('utf-8'),
                      headers={'User-Agent': AGENT, 'Content-Type': 'application/json'})
    with urlopen(request, timeout=TIMEOUT) as response:
        return json.loads(response.read().decode('utf-8'))


# ---- reading the answers -----------------------------------------------------------------------
def _text(value):
    if isinstance(value, str):
        return value
    if not isinstance(value, dict):
        return ''
    if 'simpleText' in value:
        return value['simpleText'] or ''
    if 'content' in value:
        return value['content'] or ''
    return ''.join(run.get('text', '') for run in value.get('runs') or ())


def _all(node, names):
    """Every object under one of ``names`` (in the order of the page)."""
    stack = [node]
    while stack:
        item = stack.pop()
        if isinstance(item, dict):
            for key in reversed(list(item)):
                value = item[key]
                if key in names and isinstance(value, dict):
                    yield key, value
                elif isinstance(value, (dict, list)):
                    stack.append(value)
        elif isinstance(item, list):
            stack.extend(reversed(item))


def _picture(thumbnails, video_id=''):
    """(card picture, big picture). A video's are YouTube's plain addresses - the signed ones of the
    answer (…/hq720.jpg?sqp=…) came back 404 to Kodi and the card stayed empty: the card's at 320 px
    (mqdefault, 16:9), the big one at 1280 px when the video has it (the answer lists hq720), else
    480 px. A channel's picture is the largest of the answer."""
    sources = sorted((t for t in thumbnails or () if isinstance(t, dict) and t.get('url')), key=lambda t: t.get('width') or 0)
    if video_id:
        big = 'hq720' if any('/hq720' in t['url'] for t in sources) else 'hqdefault'
        return 'https://i.ytimg.com/vi/%s/mqdefault.jpg' % video_id, 'https://i.ytimg.com/vi/%s/%s.jpg' % (video_id, big)
    if not sources:
        return '', ''
    url = sources[-1]['url']
    url = 'https:' + url if url.startswith('//') else url
    return url, url


def _video(renderer):
    video_id = renderer.get('videoId') or ''
    title = _text(renderer.get('title'))
    if not video_id or not title:
        return None
    styles = [(o.get('thumbnailOverlayTimeStatusRenderer') or {}).get('style') for o in renderer.get('thumbnailOverlays') or ()]
    badges = [(b.get('metadataBadgeRenderer') or {}).get('style') for b in renderer.get('badges') or ()]
    labels = [(b.get('metadataBadgeRenderer') or {}).get('label') for b in renderer.get('badges') or ()]
    live = 'LIVE' in styles or 'BADGE_STYLE_TYPE_LIVE_NOW' in badges
    if 'SHORTS' in styles or renderer.get('upcomingEventData'):
        return None      # Shorts are made for phones; a stream still to come does not play yet
    owner = (renderer.get('ownerText') or renderer.get('longBylineText') or renderer.get('shortBylineText') or {})
    channel_id = next((((r.get('navigationEndpoint') or {}).get('browseEndpoint') or {}).get('browseId') or ''
                       for r in owner.get('runs') or () if r.get('navigationEndpoint')), '')
    snippet = renderer.get('detailedMetadataSnippets') or ()
    about = _text(snippet[0].get('snippetText')) if snippet else _text(renderer.get('descriptionSnippet'))
    card, big = _picture((renderer.get('thumbnail') or {}).get('thumbnails'), video_id)
    owners = [(b.get('metadataBadgeRenderer') or {}).get('style') or '' for b in renderer.get('ownerBadges') or ()]
    return {'id': video_id, 'title': title, 'channel': _text(owner), 'channel_id': channel_id,
            'verified': any(style.startswith('BADGE_STYLE_TYPE_VERIFIED') for style in owners),   # YouTube's tick
            'uhd': '4K' in labels,
            'views': _text(renderer.get('shortViewCountText') or renderer.get('viewCountText')),
            'age': _text(renderer.get('publishedTimeText')), 'length': _text(renderer.get('lengthText')),
            'live': live, 'about': about, 'card': card, 'picture': big}


def _lockup(model, channel=''):
    """A video in YouTube's newer layout (channel pages, related videos)."""
    if model.get('contentType') != 'LOCKUP_CONTENT_TYPE_VIDEO' or not model.get('contentId'):
        return None
    meta = (model.get('metadata') or {}).get('lockupMetadataViewModel') or {}
    title = _text(meta.get('title'))
    if not title:
        return None
    rows = [[_text(part.get('text')) for part in row.get('metadataParts') or ()]
            for row in ((meta.get('metadata') or {}).get('contentMetadataViewModel') or {}).get('metadataRows') or ()]
    rows = [row for row in rows if any(row)]
    owner = channel
    if len(rows) > 1:
        owner = rows[0][0]
    numbers = rows[-1] if rows else []
    image = (model.get('contentImage') or {}).get('thumbnailViewModel') or {}
    length, live = '', False
    for _, badge in _all(image, ('thumbnailBadgeViewModel',)):
        length = badge.get('text') or length
        live = live or 'LIVE' in str(badge.get('badgeStyle') or '')
    card, big = _picture((image.get('image') or {}).get('sources'), model['contentId'])
    return {'id': model['contentId'], 'title': title, 'channel': owner, 'channel_id': '',
            'views': numbers[0] if numbers else '', 'age': numbers[1] if len(numbers) > 1 else '',
            'length': '' if live else length, 'live': live, 'about': '', 'card': card, 'picture': big}


def videos(answer, channel=''):
    """The videos of an answer, in its order, each once (Shorts left out)."""
    found, seen = [], set()
    for name, node in _all(answer, ('videoRenderer', 'gridVideoRenderer', 'lockupViewModel')):
        video = _lockup(node, channel) if name == 'lockupViewModel' else _video(node)
        if video and video['id'] not in seen:
            seen.add(video['id'])
            found.append(video)
    return found


def channels(answer):
    found = []
    for _, node in _all(answer, ('channelRenderer',)):
        if not node.get('channelId'):
            continue
        avatar, _big = _picture((node.get('thumbnail') or {}).get('thumbnails'))
        # YouTube puts the subscribers in videoCountText and the @name in subscriberCountText
        handle, subscribers = _text(node.get('subscriberCountText')), _text(node.get('videoCountText'))
        found.append({'id': node['channelId'], 'name': _text(node.get('title')), 'avatar': avatar,
                      'handle': handle if handle.startswith('@') else '',
                      'subscribers': subscribers if not subscribers.startswith('@') else handle,
                      'about': _text(node.get('descriptionSnippet'))})
    return found


def shelves(answer):
    """A YouTube page's named shelves: [(name, videos)]."""
    found = []
    for _, shelf in _all(answer, ('richShelfRenderer', 'shelfRenderer')):
        items = videos(shelf.get('contents') or shelf.get('content') or {})
        if items:
            found.append((_text(shelf.get('title')), items))
    return found


# ---- what the app asks for -----------------------------------------------------------------
def search(query, params='', pages=SEARCH_PAGES):
    """An answer's videos, its first SEARCH_PAGES pages. 9.0.7 ``pages=1``: its first page alone, kept on its own
    - the Music app's song is nearly always on it (both pages were asked for every song); asked for all pages
    after it, only the pages after it are asked."""
    body = {'query': query}
    if params:
        body['params'] = params

    def first():
        answer = _ask('search', body)
        found, token = videos(answer), _more(answer)
        if not (found or token):
            return None
        _feed(('search', query, params), 'search', [found], token)
        return found, token                                    # (a page of Shorts only still leads to the next)
    if pages <= 1:
        page = _kept(('search', query, params, 1), first)
        return list(page[0]) if page else []

    def make():
        page = _held(('search', query, params, 1)) or first()
        if not page:
            return []
        walked, token = _walk('search', page[0], page[1], pages)
        _feed(('search', query, params), 'search', walked, token)
        return _flat(walked)
    return _kept(('search', query, params), make)


def _pages(endpoint, answer, pages, channel=''):
    """The videos of an answer and of its next ``pages - 1`` pages (asked at ``endpoint``), each once."""
    return _flat(_walk(endpoint, videos(answer, channel), _more(answer), pages, channel)[0])


def _walk(endpoint, found, token, pages, channel=''):
    """([``found`` (a first page's videos), the next ``pages - 1`` pages from ``token`` on], the token after them)."""
    walked = [list(found)]
    for _ in range(pages - 1):
        if not token:
            break
        page = _ask(endpoint, {'continuation': token})
        walked.append(videos(page, channel))
        token = _more(page)
    return walked, token


def _flat(walked):
    """The pages' videos, each once, in their order."""
    found, seen = [], set()
    for page in walked:
        for video in page:
            if video['id'] not in seen:
                seen.add(video['id'])
                found.append(video)
    return found


def _feed(key, endpoint, walked, token, channel=''):
    """9.1.2: a row's pages read so far and where its next one is (``key``: the row's own, as next_page asks)."""
    with _lock:
        _feeds[key] = {'endpoint': endpoint, 'pages': [list(page) for page in walked], 'token': token or '', 'channel': channel}
        _feeds.move_to_end(key)
        while len(_feeds) > FEEDS:
            _feeds.popitem(last=False)


def next_page(key, count):
    """9.1.2: a row's page after its first ``count`` - its videos ("premalo sadržaja u jednom redu"): read once, kept
    while the app is open; [] at its end, or when the row was never read here."""
    with _lock:
        feed = _feeds.get(key)
    if not feed:
        return []
    while len(feed['pages']) <= count:
        if not feed['token']:
            return []
        answer = _ask(feed['endpoint'], {'continuation': feed['token']})
        with _lock:
            feed['pages'].append(videos(answer, feed['channel']))
            feed['token'] = _more(answer)
    return list(feed['pages'][count])


def more_after(key, count):
    """A row's feed has a page after its first ``count``, or can ask for one."""
    with _lock:
        feed = _feeds.get(key)
        return bool(feed) and (len(feed['pages']) > count or bool(feed['token']))


def pages_read(key):
    """How many pages of a row were read (what its cards were made of)."""
    with _lock:
        return len((_feeds.get(key) or {}).get('pages') or ())


def find_channels(query):
    return _kept(('channels', query), lambda: channels(_ask('search', {'query': query, 'params': CHANNELS_ONLY})))


def _channel(answer, channel_id):
    """A channel's Videos tab: its name and picture, its newest videos, and where its other
    views are - read from the page (the Popular chip, the Live tab), never guessed."""
    about = (answer.get('metadata') or {}).get('channelMetadataRenderer') or {}
    name = about.get('title') or ''
    pictures = (about.get('avatar') or {}).get('thumbnails') or ()
    chips = [chip for _, chip in _all(answer, ('chipViewModel',))]
    unchosen = [chip for chip in chips if not chip.get('selected')]
    popular = ((((unchosen[0].get('tapCommand') or {}).get('innertubeCommand') or {}).get('continuationCommand') or {})
               .get('token') or '') if len(chips) > 1 and unchosen else ''
    live = ''
    for _, tab in _all(answer, ('tabRenderer',)):
        params = ((tab.get('endpoint') or {}).get('browseEndpoint') or {}).get('params') or ''
        if _tab_is(params, b'streams'):
            live = params
    walked, token = _walk('browse', videos(answer, name), _more(answer), CHANNEL_PAGES, name)   # its videos: the tab's next pages
    _feed(('channel', channel_id), 'browse', walked, token, name)
    found = _flat(walked)
    return {'id': channel_id, 'name': name, 'avatar': pictures[0]['url'] if pictures else '',
            'videos': found, 'popular': popular, 'live': live}


def _more(answer):
    """The token of a list's next page: the last item of the video grid (a channel) or of the
    results (a search), or of a page that continued it - not the other panels' (comments, filters)."""
    lists = [grid.get('contents') or [] for _, grid in _all(answer, ('richGridRenderer', 'sectionListRenderer'))]
    lists += [action.get('continuationItems') or [] for _, action in
              _all(answer, ('appendContinuationItemsAction', 'reloadContinuationItemsCommand'))]
    for items in lists:
        last = (items[-1] if items else {}).get('continuationItemRenderer') or {}
        token = ((last.get('continuationEndpoint') or {}).get('continuationCommand') or {}).get('token')
        if token:
            return token
    return ''


def _tab_is(params, word):
    import base64
    from urllib.parse import unquote
    try:
        return word in base64.urlsafe_b64decode(unquote(params) + '==')[:24]
    except (ValueError, TypeError):
        return False


def channel(channel_id):
    return _kept(('channel', channel_id), lambda: _channel(_ask('browse', {'browseId': channel_id, 'params': CHANNEL_VIDEOS}), channel_id))


def channel_videos(channel_id):
    return (channel(channel_id) or {}).get('videos') or []


def channel_popular(channel_id):
    found = channel(channel_id) or {}
    if not found.get('popular'):
        return []
    return _kept(('popular', channel_id), lambda: _one('popular', channel_id, _ask('browse', {'continuation': found['popular']}), found.get('name') or ''))


def _one(kind, channel_id, answer, name):
    """A channel view's first page - kept as its row's feed (the row goes on from there)."""
    found = videos(answer, name)
    _feed((kind, channel_id), 'browse', [found], _more(answer), name)
    return found


def channel_live(channel_id):
    found = channel(channel_id) or {}
    if not found.get('live'):
        return []
    from urllib.parse import unquote
    return _kept(('live', channel_id), lambda: _one('live', channel_id, _ask('browse', {'browseId': channel_id, 'params': unquote(found['live'])}),
                                                     found.get('name') or ''))


def page(browse_id):
    return _kept(('page', browse_id), lambda: shelves(_ask('browse', {'browseId': browse_id})))


def related(video_id):
    """What YouTube puts beside a video (its "Up next") - the app's next video comes from here."""
    def make():
        answer = _ask('next', {'videoId': video_id})
        side = (((answer.get('contents') or {}).get('twoColumnWatchNextResults') or {}).get('secondaryResults') or answer)
        return [v for v in videos(side) if v['id'] != video_id]
    return _kept(('related', video_id), make)


def topic(query, params=THIS_MONTH):
    """A category's row as YouTube's own: asked in English, this month as YouTube ranks it for your region - never
    another region's videos (foreign(): the Hindi, Bengali or Thai a European never asked for). 9.1.2 ``params``:
    LIVE - what is live now."""
    where = place()
    return [video for video in search(query, params) if not foreign(video, where)]


def topic_page(query, params, count):
    """9.1.2: a category row's page after its first ``count`` (foreign ones left out, as the row's own)."""
    where = place()
    return [video for video in next_page(('search', query, params), count) if not foreign(video, where)]


def live_word(english):
    """9.1.2: what a Live row asks for - in the region's own words where MegaNexus has them ("vijesti": HRT live)."""
    return (LOCAL.get(region_language(*place())) or {}).get(english) or english


def regional():
    """9.0.8: your region's own row - every category asked in your language (LOCAL: "vijesti" brings HRT's news,
    "službeni trailer" the Croatian distributor's trailers), their videos taken in turn (news, music, a trailer, ...)
    so the row is a mix; [] for a language without its words (its categories' rows are its own already)."""
    where = place()
    words = _region_words(where)
    if not words:
        return []
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=REGION_AT_ONCE) as pool:
        answers = list(pool.map(_answer, words))
    found, seen = [], set()
    for turn in range(max(map(len, answers), default=0)):
        for videos in answers:
            if turn < len(videos) and videos[turn]['id'] not in seen and not foreign(videos[turn], where):
                seen.add(videos[turn]['id'])
                found.append(videos[turn])
    return found[:REGION_MOST]


def _region_words(where):
    # a category whose word is the English one ("gaming", "podcast") is no question of the region's own
    return [word for english, word in (LOCAL.get(region_language(*where)) or {}).items() if word.lower() != english]


def region_keys():
    """9.1.2: the region's row's feeds (next_page), one for each of its words."""
    return [('search', word, THIS_MONTH) for word in _region_words(place())]


def regional_page(count):
    """9.1.2: the region's row after its first ``count`` pages of every word: their next pages, taken in turn."""
    where = place()
    answers = [next_page(('search', word, THIS_MONTH), count) for word in _region_words(where)]
    found, seen = [], set()
    for turn in range(max(map(len, answers), default=0)):
        for videos in answers:
            if turn < len(videos) and videos[turn]['id'] not in seen and not foreign(videos[turn], where):
                seen.add(videos[turn]['id'])
                found.append(videos[turn])
    return found


REGION_AT_ONCE = 4    # the region's categories asked at the same time
REGION_MOST = 60      # videos in its row


def _answer(word):
    try:
        return search(word, THIS_MONTH, pages=1)
    except Exception:
        return []         # one category not answering leaves the others in the row


# 9.0.8: a region's own language, for its row when the language chosen is another (English with Croatia as the region)
REGION_LANGUAGE = {'HR': 'hr', 'RS': 'sr', 'ME': 'sr', 'BA': 'bs', 'SI': 'sl', 'MK': 'mk', 'BG': 'bg', 'DE': 'de', 'AT': 'de',
                   'CH': 'de', 'LI': 'de', 'ES': 'es', 'MX': 'es', 'AR': 'es', 'CO': 'es', 'CL': 'es', 'PE': 'es', 'VE': 'es',
                   'EC': 'es', 'UY': 'es', 'FR': 'fr', 'LU': 'fr', 'IT': 'it', 'PT': 'pt', 'BR': 'pt', 'NL': 'nl', 'BE': 'nl',
                   'PL': 'pl', 'CZ': 'cs', 'SK': 'sk', 'HU': 'hu', 'RO': 'ro', 'MD': 'ro', 'TR': 'tr', 'RU': 'ru', 'UA': 'uk',
                   'GR': 'el', 'CY': 'el', 'SE': 'sv', 'NO': 'no', 'DK': 'da', 'FI': 'fi'}


def region_language(hl, gl):
    """The language of the region's own row: the one chosen when it has the words, else the region's own."""
    return hl if hl in LOCAL else REGION_LANGUAGE.get(gl, '')


def region_name():
    """The region's name in English ("Croatia"), as Settings shows it."""
    try:
        from .default_setup import options
        return dict(options()['regions']).get(place()[1]) or place()[1]
    except Exception:
        return place()[1]


# 9.0.8: the categories' words in the languages MegaNexus offers (Settings: the MegaNexus Catalog's language) -
# the words people put in their own titles, for the region's own row (regional()); a language not here has none
_WORDS = ('music', 'gaming', 'news', 'official trailer', 'podcast', 'tech review', 'comedy', 'science', 'car review',
          'recipe', 'workout', 'travel', 'nature documentary')
LOCAL = {hl: dict(zip(_WORDS, words.split('|'))) for hl, words in {
    'hr': 'glazba|gaming|vijesti|službeni trailer|podcast|tehnologija recenzija|komedija|znanost|test auta|recept|trening|putovanje|dokumentarac priroda',
    'sr': 'muzika|gejming|vesti|zvanični trejler|podkast|tehnologija recenzija|komedija|nauka|test automobila|recept|trening|putovanje|dokumentarni film priroda',
    'bs': 'muzika|gaming|vijesti|zvanični trailer|podcast|tehnologija recenzija|komedija|nauka|test auta|recept|trening|putovanje|dokumentarac priroda',
    'sl': 'glasba|gaming|novice|uradni napovednik|podkast|tehnologija test|komedija|znanost|test avtomobila|recept|vadba|potovanje|dokumentarec narava',
    'mk': 'музика|гејминг|вести|официјален трејлер|подкаст|технологија|комедија|наука|тест автомобил|рецепт|вежбање|патување|документарец природа',
    'bg': 'музика|гейминг|новини|официален трейлър|подкаст|технологии ревю|комедия|наука|тест драйв|рецепта|тренировка|пътуване|документален филм природа',
    'de': 'Musik|Gaming|Nachrichten|offizieller Trailer|Podcast|Technik Test|Comedy|Wissenschaft|Autotest|Rezept|Workout|Reise|Naturdoku',
    'es': 'música|gaming|noticias|tráiler oficial|podcast|tecnología review|comedia|ciencia|prueba de coche|receta|rutina de ejercicios|viajes|documental naturaleza',
    'fr': 'musique|gaming|actualités|bande annonce officielle|podcast|test tech|humour|science|essai voiture|recette|entraînement|voyage|documentaire nature',
    'it': 'musica|gaming|notizie|trailer ufficiale|podcast|recensione tecnologia|comicità|scienza|prova auto|ricetta|allenamento|viaggio|documentario natura',
    'pt': 'música|gameplay|notícias|trailer oficial|podcast|review tecnologia|comédia|ciência|teste carro|receita|treino|viagem|documentário natureza',
    'nl': 'muziek|gaming|nieuws|officiële trailer|podcast|tech review|comedy|wetenschap|autotest|recept|workout|reizen|natuurdocumentaire',
    'pl': 'muzyka|gaming|wiadomości|oficjalny zwiastun|podcast|recenzja technologia|kabaret|nauka|test samochodu|przepis|trening|podróże|film przyrodniczy',
    'cs': 'hudba|gaming|zprávy|oficiální trailer|podcast|recenze technologie|komedie|věda|test auta|recept|cvičení|cestování|dokument příroda',
    'sk': 'hudba|gaming|správy|oficiálny trailer|podcast|recenzia technológie|komédia|veda|test auta|recept|cvičenie|cestovanie|dokument príroda',
    'hu': 'zene|gaming|hírek|hivatalos előzetes|podcast|tech teszt|vígjáték|tudomány|autóteszt|recept|edzés|utazás|természetfilm',
    'ro': 'muzică|gaming|știri|trailer oficial|podcast|review tehnologie|comedie|știință|test auto|rețetă|antrenament|călătorie|documentar natură',
    'tr': 'müzik|oyun|haberler|resmi fragman|podcast|teknoloji inceleme|komedi|bilim|araba inceleme|tarif|antrenman|gezi|belgesel doğa',
    'ru': 'музыка|игры|новости|официальный трейлер|подкаст|обзор техники|комедия|наука|тест драйв|рецепт|тренировка|путешествия|документальный фильм природа',
    'uk': 'музика|ігри|новини|офіційний трейлер|подкаст|огляд техніки|комедія|наука|тест драйв|рецепт|тренування|подорожі|документальний фільм природа',
    'el': 'μουσική|gaming|ειδήσεις|επίσημο τρέιλερ|podcast|τεχνολογία|κωμωδία|επιστήμη|δοκιμή αυτοκινήτου|συνταγή|γυμναστική|ταξίδι|ντοκιμαντέρ φύση',
    'sv': 'musik|gaming|nyheter|officiell trailer|podcast|teknik recension|komedi|vetenskap|biltest|recept|träning|resor|naturdokumentär',
    'no': 'musikk|gaming|nyheter|offisiell trailer|podkast|teknologi test|komedie|vitenskap|biltest|oppskrift|trening|reise|naturdokumentar',
    'da': 'musik|gaming|nyheder|officiel trailer|podcast|tech anmeldelse|komik|videnskab|biltest|opskrift|træning|rejser|naturdokumentar',
    'fi': 'musiikki|pelit|uutiset|virallinen traileri|podcast|teknologia arvostelu|komedia|tiede|autotesti|resepti|treeni|matkailu|luontodokumentti',
}.items()}
# the scripts a language is written in besides the Latin one (the Balkan ones read each other's Cyrillic)
SCRIPTS = {'sr': ('CYRILLIC',), 'mk': ('CYRILLIC',), 'bg': ('CYRILLIC',), 'hr': ('CYRILLIC',), 'bs': ('CYRILLIC',),
           'ru': ('CYRILLIC',), 'uk': ('CYRILLIC',), 'kk': ('CYRILLIC',), 'el': ('GREEK',), 'ar': ('ARABIC',),
           'fa': ('ARABIC',), 'ur': ('ARABIC',), 'he': ('HEBREW',), 'hi': ('DEVANAGARI',), 'bn': ('BENGALI',),
           'zh': ('CJK',), 'ja': ('CJK', 'HIRAGANA', 'KATAKANA'), 'ko': ('HANGUL', 'CJK'), 'th': ('THAI',),
           'hy': ('ARMENIAN',), 'ka': ('GEORGIAN',)}


# another country's or language's channels and videos ("Prime Video India", "Final Hindi Trailer", "T-Series Telugu",
# "... Latino"): left out but where they are at home (the regions, gl)
_INDIA = {'IN'}
_SPANISH = {'ES', 'MX', 'AR', 'CO', 'CL', 'PE', 'VE', 'EC', 'GT', 'CU', 'BO', 'DO', 'HN', 'PY', 'SV', 'NI', 'CR', 'PA', 'UY', 'PR'}
PLACES = ((re.compile(r'\b(india|hindi|telugu|tamil|malayalam|kannada|marathi|bhojpuri|punjabi|gujarati|bollywood|tollywood)\b', re.I), _INDIA),
          (re.compile(r'\b(bangla|bangladesh|bd news)\b', re.I), {'BD', 'IN'}),
          (re.compile(r'\b(pakistan|urdu)\b', re.I), {'PK'}),
          (re.compile(r'\b(latino|latinoam[eé]rica|latam|espa[ñn]a|en espa[ñn]ol|m[eé]xico)\b', re.I), _SPANISH),
          (re.compile(r'\b(brasil|brazil|portugu[eê]s)\b', re.I), {'BR', 'PT'}),
          (re.compile(r'\b(indonesia)\b', re.I), {'ID'}),
          (re.compile(r'\b(philippines|pinoy|tagalog)\b', re.I), {'PH'}),
          (re.compile(r'\b(t[üu]rkiye|t[üu]rk[çc]e)\b', re.I), {'TR'}))
FOREIGN_LETTERS = 4      # letters of another script that make a title foreign ("... LIVE: ट्रंप की हार")


def foreign(video, where):
    """A video that is another region's: its title has letters of a script the language (``where``: (hl, gl)) is not
    written in, or its title or channel names another country or language (PLACES) - not where they are at home."""
    import unicodedata
    hl, gl = where
    allowed = ('LATIN',) + SCRIPTS.get(hl, ())
    other = 0
    title, channel = str(video.get('title') or ''), str(video.get('channel') or '')
    for char in title + channel:
        if char.isalpha():
            try:
                script = unicodedata.name(char).split(' ')[0]
            except ValueError:
                continue
            if script not in allowed:
                other += 1
                if other >= FOREIGN_LETTERS:
                    return True
    return any(gl not in home and (names.search(title) or names.search(channel)) for names, home in PLACES)


# ---- the person's channels (theirs - kept in the profile) ----------------------------------------
def _channels_file():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), CHANNELS)


def my_channels():
    try:
        with open(_channels_file(), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [c for c in saved if isinstance(c, dict) and c.get('id')] if isinstance(saved, list) else []


def _save_channels(items):
    path = _channels_file()
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(items, handle, ensure_ascii=False)
    os.replace(path + '.part', path)


def add_channel(channel):
    items = [c for c in my_channels() if c['id'] != channel.get('id')]
    items.insert(0, {'id': channel['id'], 'name': channel.get('name') or '', 'avatar': channel.get('avatar') or ''})
    _save_channels(items)
    return items


def remove_channel(channel_id):
    items = [c for c in my_channels() if c['id'] != channel_id]
    _save_channels(items)
    return items


def has_channel(channel_id):
    return any(c['id'] == channel_id for c in my_channels())


# ---- the app's cards ------------------------------------------------------------------------
def meta_line(video):
    """The line under the title, in this order: channel · LIVE · how long · views · when it came out -
    nothing else, no description ("naziv, ime kanala, uzivo, trajanje, broj pregleda... sve ostale
    deskripcije izbaci")."""
    parts = (video.get('channel'), 'LIVE' if video.get('live') else '', video.get('length'), video.get('views'), video.get('age'))
    return '  ·  '.join(p.strip() for p in parts if p and p.strip())


def video_card(video):
    # the words as the chosen font draws them: emoji and the world's scripts in MegaNexus' own font,
    # Chinese, Japanese and Korean in Kodi's (kodi_text.world)
    font, (title, channel, line) = world(video['title'], video.get('channel'), meta_line(video))
    return {'title': title, 'subtitle': channel, 'plot': '', 'meta_line': line, 'font': font,
            'poster': video.get('card') or '', 'landscape': video.get('card') or '',
            'fanart': video.get('picture') or '', 'clearlogo': '', 'shape': 'landscape',
            'youtube': {'video': video['id'], 'channel_id': video.get('channel_id') or '', 'channel': video.get('channel') or ''}}


def channel_card(channel):
    font, (name, line, about) = world(channel.get('name'), '  ·  '.join(p for p in (channel.get('handle'), channel.get('subscribers')) if p),
                                      channel.get('about'))
    return {'title': name, 'subtitle': line, 'plot': about, 'meta_line': line, 'font': font,
            'poster': channel.get('avatar') or '', 'landscape': channel.get('avatar') or '', 'fanart': '', 'clearlogo': '',
            'shape': 'square', 'round': True, 'youtube': {'channel_id': channel['id'], 'channel': channel.get('name') or '',
                                              'avatar': channel.get('avatar') or ''}}


DASH_SETTING = 'kodion.mpd.videos'    # Kodi's YouTube add-on: MPEG-DASH videos (its own setting)


def steady(on=None):
    """Steady playback: the YouTube add-on's MPEG-DASH off. With it on, its 7.4.4 has YouTube refuse
    the rest of a video after about a minute or a seek (its issues #1481, #1483); off, it plays the
    streams YouTube still serves whole - in the quality of the add-on's own setting (720p, 1080p for a
    live one: nothing here limits it; 9.0.8 - it was said to be 360p). ``on`` sets it; returns whether it is on."""
    import xbmcaddon
    try:
        addon = xbmcaddon.Addon('plugin.video.youtube')
        if on is not None:
            addon.setSettingBool(DASH_SETTING, not on)
        return not addon.getSettingBool(DASH_SETTING)
    except Exception:
        return False


# 9.1.2: Kodi's YouTube add-on's own options set from the app's Options ("koje opcije nudi da ih možemo kroz naš
# Options podešavati"): its video quality - one stream's (Steady playback) or MPEG-DASH's - and its region and language
QUALITY = ('kodion.video.quality', 'kodion.mpd.quality.selection')
THEIR_REGION, THEIR_LANGUAGE = 'youtube.region', 'youtube.language'


def addon_choices(setting_id, addon=None):
    """[(value, its name)] of one of Kodi's YouTube add-on's own choices as its settings page lists them - its
    settings.xml and its own words, read now (nothing of it written here); [] when it has none."""
    import xml.etree.ElementTree as ET
    import xbmc
    import xbmcvfs
    try:
        if addon is None:
            import xbmcaddon
            addon = xbmcaddon.Addon('plugin.video.youtube')
        root = ET.parse(os.path.join(xbmcvfs.translatePath(addon.getAddonInfo('path')), 'resources', 'settings.xml')).getroot()
    except Exception:
        return []
    for setting in root.iter('setting'):
        if setting.get('id') != setting_id:
            continue
        found = []
        for option in setting.iter('option'):
            value, label = (option.text or '').strip(), option.get('label') or ''
            number = int(label) if label.isdigit() else 0
            name = (addon.getLocalizedString(number) if number >= 30000 else xbmc.getLocalizedString(number)) if number else label
            found.append((value, name or value))
        return found
    return []


def quality_setting():
    """The add-on's quality setting that counts now: one stream's with Steady playback, MPEG-DASH's without."""
    return QUALITY[0] if steady() else QUALITY[1]


def their_setting(key, value=None):
    """One of the YouTube add-on's settings - ``value`` written first (a fresh instance: Kodi saves the whole of the
    one it writes with). '' when it is not there."""
    import xbmcaddon
    try:
        addon = xbmcaddon.Addon('plugin.video.youtube')
        if value is not None:
            addon.setSetting(key, str(value))
        return addon.getSetting(key) or ''
    except Exception:
        return ''


DASH_CHOSEN = 'meganexus_youtube_dash'   # 9.0.8: MPEG-DASH (4K) chosen by you in Settings > YouTube - else Steady


def dash_chosen():
    """You turned MPEG-DASH on yourself (Settings > YouTube, after its warning)."""
    import xbmcaddon
    try:
        return xbmcaddon.Addon('plugin.video.meganexus').getSetting(DASH_CHOSEN) == 'true'
    except Exception:
        return False


def dash_trouble():
    """9.0.8: a box where MPEG-DASH stays off - an Amlogic one (CoreELEC, a Fire TV Cube: the video driver's file
    video_layer knows): YouTube's refusals of the rest of a DASH video (403, the add-on's issues #1481, #1483) froze
    the whole box there when the video was left (2026-11-03, 2026-11-04); elsewhere they stall the video only, and
    4K stays your choice (Settings > YouTube)."""
    from .video_layer import POLICY
    return os.path.exists(POLICY)


def keep_steady():
    """Steady playback on again (the add-on's wizard, a restore or its own default may have turned DASH on) - unless
    you chose MPEG-DASH yourself, and on an Amlogic box always. True when it had to be switched.
    9.0.8: Steady is the standard everywhere - on the PC too a DASH video stopped on a seek (the same refusals, the
    add-on's issues #1481, #1483); 4K stays yours to choose where it does not freeze the box."""
    if steady() or (dash_chosen() and not dash_trouble()):
        return False
    return steady(True)


def play_path(video_id):
    return PLAY % video_id if re.fullmatch(r'[A-Za-z0-9_-]{6,20}', str(video_id or '')) else ''
