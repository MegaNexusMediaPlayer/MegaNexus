# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Account-scoped watched snapshot: no network request while painting a poster."""
import hashlib
import os
import time
import copy
from . import simkl_api
_MEM={}
_NO_ACCOUNT={'items':{}}  # Shared, never mutated: snapshot() deep-copies it.

def _invalidate_view():
    # An open Home must remove progress that was marked watched on Simkl too.
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty('meganexus.progress.revision',str(time.time_ns()))
    except Exception:pass

def _account():
    token=simkl_api.token_data().get('access_token') or ''
    return hashlib.sha256(token.encode()).hexdigest() if token else ''

def _path():return os.path.join(os.path.dirname(simkl_api.TOKEN_PATH),'simkl_watched.json')

def _remote_snapshot():
    account=_account()
    if not account:return _NO_ACCOUNT
    path=_path()
    try:stamp=os.stat(path).st_mtime_ns
    except OSError:stamp=0
    memo=(account,path,stamp)
    if _MEM.get('key')==memo:return _MEM['data']
    data=simkl_api._read_json(path,{})
    _MEM.update(key=memo,data=data if data.get('account')==account else {'account':account,'items':{}})
    return _MEM['data']

_MERGED={}
_TRAKT_MEM={}
_NO_TRAKT={}   # shared and never mutated: keeps the merged view cached


def _trakt_items():
    """Trakt watched items, re-read only when trakt_watched.json changes."""
    try:
        # Deleted on Trakt sign-out, so its presence is the sign-in check (no token read per paint).
        from .meganexus.paths import profile_path
        path=os.path.join(profile_path(),'trakt_watched.json')
        stamp=os.stat(path).st_mtime_ns
    except Exception:return _NO_TRAKT
    if _TRAKT_MEM.get('stamp')!=(path,stamp):
        from . import trakt_watched
        _TRAKT_MEM.update(stamp=(path,stamp),items=trakt_watched.snapshot().get('items') or {})
    return _TRAKT_MEM['items']


_MDBLIST_MEM={}


def _mdblist_items():
    """MDBList watched items (7.0.12), re-read only when mdblist_watched.json changes."""
    try:
        from . import mdblist_tracking
        if not mdblist_tracking.enabled():return _NO_TRAKT
        path=mdblist_tracking._path()
        stamp=os.stat(path).st_mtime_ns
    except Exception:return _NO_TRAKT
    if _MDBLIST_MEM.get('stamp')!=(path,stamp):
        _MDBLIST_MEM.update(stamp=(path,stamp),items=mdblist_tracking.snapshot().get('items') or {})
    return _MDBLIST_MEM['items']


_WETRAKR_MEM={}


def _wetrakr_items():
    """What WeTrakr counts as watched (8.1.2), re-read only when wetrakr_cache.json changes.

    9.1.4: never wetrakr_api.watched_items() here. It read the file into a new dictionary on
    every call, so the merged view never matched and was deep-copied again - 1.1 s of every
    Home and collection paint on the Cube - and every 3 hours it asked WeTrakr from the paint
    itself. The service keeps the list (progress_sync._wetrakr)."""
    try:
        from . import wetrakr_api
        if not wetrakr_api.authorized():return _NO_TRAKT
        path=wetrakr_api.CACHE_PATH
        stamp=os.stat(path).st_mtime_ns
    except Exception:return _NO_TRAKT
    if _WETRAKR_MEM.get('stamp')!=(path,stamp):
        _WETRAKR_MEM.update(stamp=(path,stamp),items=wetrakr_api.kept_watched() or _NO_TRAKT)
    return _WETRAKR_MEM['items']


def snapshot():
    """Merged watched view. Read-only: callers that change it must deep-copy.

    Rebuilt only when the Simkl file or the local playback database changes, so
    painting every Home shelf does not deep-copy the whole watched history.

    8.1.2: it still asks five files whether they have changed, so the drawing path
    takes ONE of these per paint and hands it down (home_window._set_rows) instead of
    calling it for every row - that is where a paint of twelve rows was disappearing
    into the Cube's eMMC.
    """
    remote=_remote_snapshot()
    try:
        from .meganexus import progress_db
        watched=progress_db.watched_snapshot()
    except Exception:watched=None
    trakt_items=_trakt_items()
    mdblist_items=_mdblist_items()
    wetrakr_items=_wetrakr_items()
    from . import watched_local
    marks=watched_local.overrides()
    if (_MERGED.get('remote') is remote and _MERGED.get('watched') is watched and _MERGED.get('trakt') is trakt_items
            and _MERGED.get('mdblist') is mdblist_items and _MERGED.get('wetrakr') is wetrakr_items
            and _MERGED.get('marks') is marks and 'data' in _MERGED):
        return _MERGED['data']
    local=copy.deepcopy(remote)
    # 6.0.39: Trakt watched marks too; 7.0.12: and MDBList's.
    for identity,entry in list(trakt_items.items())+list(mdblist_items.items())+list(wetrakr_items.items()):
        target=local.setdefault('items',{}).get(identity)
        if target is None:local['items'][identity]=copy.deepcopy(entry);continue
        target['watched']=bool(target.get('watched') or entry.get('watched'))
        target['episodes']=sorted(set(target.get('episodes',[]))|set(entry.get('episodes',[])))
        target['seasons']=sorted(set(target.get('seasons',[]))|set(entry.get('seasons',[])))
    for identity,entry in (watched or {}).items():
        target=local.setdefault('items',{}).setdefault(identity,{'watched':False,'seasons':[],'episodes':[]})
        target['watched']=bool(target.get('watched') or entry.get('watched'))
        target['episodes']=sorted(set(target.get('episodes',[]))|set(entry.get('episodes',[])))
    # 8.1.2: and last, what this box says - the union can only ever add, so without
    # this nothing could be taken back: unmark a film and any service that still listed
    # it put the mark straight back. A mark set by hand wins until the title is played
    # again (watched_local).
    watched_local.apply(local.setdefault('items',{}),marks)
    _MERGED.clear();_MERGED.update(remote=remote,watched=watched,trakt=trakt_items,mdblist=mdblist_items,
                                   wetrakr=wetrakr_items,marks=marks,data=local)
    return local


def aliases(ids):
    out=[]
    for key in ('imdb','tmdb','tvdb','simkl'):
        value=str(ids.get(key) or '').strip()
        if value:out.append(('tt'+value if not value.startswith('tt') else value) if key=='imdb' else key+':'+value)
    return out

def key(media,mid):return ('movie' if media=='movie' else 'series')+'|'+str(mid)

def state(data,media,mid):return data.get('items',{}).get(key(media,mid),{})


def watched_mark(data,media,mid,others=()):
    """9.1.1: the watched mark a card shows. A film: as the services say. A series: only once nothing of it is
    still to come - Trakt and Simkl call a show watched when every episode OUT is ("MobLand mi oznaku pogledano
    iako serija nije zavrsila": S2E8 tomorrow); its season over, the mark is there. Never changes what the
    services keep, nor Continue Watching or the next episodes (which read state())."""
    if not state(data,media,mid).get('watched'):return False
    if media=='movie':return True
    try:
        from .watch_nextup import still_to_come
        coming=still_to_come()
    except Exception:
        return True
    return not any(str(x) in coming for x in (mid,)+tuple(others) if x)

def parse(data,kind):
    import re
    from .trakt_api import _parse_trakt_ts
    result={};media='movie' if kind=='movies' else 'series'
    for row in data.get(kind) or []:
        node=row.get('movie') or row.get('show') or {};episodes=[];times={}
        for season in row.get('seasons') or []:
            for episode in season.get('episodes') or []:
                episode_key='%s:%s'%(season.get('number'),episode.get('number'))
                episodes.append(episode_key)
                stamp=_parse_trakt_ts(episode.get('watched_at'))
                if stamp:times[episode_key]=stamp
        total=int(row.get('total_episodes_count') or 0)
        # 7.0.50: every episode out so far seen = watched, as Trakt / Plex count it - a show
        # still running (the next season announced, or not yet) is watched until a new
        # episode is out; Simkl's total also held the announced ones, so it never was
        aired=max(0,total-int(row.get('not_aired_episodes_count') or 0))
        watched=row.get('status')=='completed' or (aired>0 and int(row.get('watched_episodes_count') or 0)>=aired)
        entry={'watched':watched,'episodes':episodes,'seasons':[]}
        stamp=_parse_trakt_ts(row.get('last_watched_at'))
        if stamp:
            if media=='movie':entry['watched_at']=stamp
            else:
                last=re.fullmatch(r'S(\d+)E(\d+)',str(row.get('last_watched') or ''),re.I)
                if last:times['%s:%s'%(int(last[1]),int(last[2]))]=stamp
        if times:entry['episode_watched_at']=times
        for mid in aliases(node.get('ids') or {}):result[key(media,mid)]=entry
    return result

KINDS={'movies':'movies','shows':'tv_shows','anime':'anime'}   # all-items kind -> /sync/activities section
GROUPS=(('movie|',('movies',)),('series|',('shows','anime')))   # kinds that share watched keys


def _stamp(activities,section,field='all'):
    return str(((activities or {}).get(section) or {}).get(field) or '')


def _fetch(kind,since=''):
    path='/sync/all-items/%s/?extended=full'%kind+('&date_from='+since if since else '')
    data=simkl_api._request(path,auth=True,timeout=8)
    if since and not data:return {}   # nothing changed since the last sync
    if not isinstance(data,dict) or (not since and kind not in data):
        raise ValueError('Simkl did not return a complete watched list.')
    return parse(data,kind)


def refresh(force=False, max_age=900):
    """Simkl watched lists, the way Simkl asks apps to sync (6.0.39).

    /sync/activities first (one tiny request); a list is downloaded only when
    its timestamp moved, and then only the titles changed since the last sync
    (date_from). The first sync or a removal from a list reads that group in
    full. Before 6.0.39 all three full lists were downloaded every two
    minutes, even during playback."""
    old=_remote_snapshot();account=old.get('account')   # Simkl only, without local plays
    if not account:return snapshot()
    start=time.time()
    if not force and start-float(old.get('updated') or 0)<max_age:return snapshot()
    activities=simkl_api._request('/sync/activities',auth=True,timeout=8)
    if not isinstance(activities,dict) or not activities.get('all'):
        raise ValueError('Simkl did not return its activity times.')
    previous=old.get('activities') or {}
    items=dict(old.get('items') or {}) if previous else {}
    changed=False
    for prefix,kinds in GROUPS:
        moved=[k for k in kinds if not previous or _stamp(activities,KINDS[k])!=_stamp(previous,KINDS[k])]
        if not moved:continue
        changed=True
        full=not previous or any(_stamp(activities,KINDS[k],'removed_from_list')!=_stamp(previous,KINDS[k],'removed_from_list') for k in kinds)
        if full:
            fresh={}
            for kind in kinds:fresh.update(_fetch(kind))
            items={k:v for k,v in items.items() if not k.startswith(prefix)}
            items.update(fresh)
        else:
            for kind in moved:items.update(_fetch(kind,_stamp(previous,KINDS[kind])))
    # A manual mark or account change during the fetch takes precedence.
    latest=_remote_snapshot()
    if _account()!=account or float(latest.get('updated') or 0)>start:return snapshot()
    result={'account':account,'updated':time.time(),'items':items,'activities':activities}
    simkl_api._write_json(_path(),result)
    if changed:_invalidate_view()
    return result

def mark(ctx,scope='title',season=None,episode=None):
    if not simkl_api.authorized():raise ValueError('Connect Simkl in HUB Settings first.')
    ids=simkl_api._ids_from_ctx(ctx)
    if not ids:raise ValueError('This title has no IMDb, TMDb or TVDb ID for Simkl.')
    account=_account();media='movie' if ctx.get('media_type')=='movie' else 'series'
    item={'ids':ids,'title':ctx.get('title') or ''}
    if media=='series' and scope in ('season','episode'):
        if season is None or int(season)<0:raise ValueError('Select a season first.')
        part={'number':int(season)}
        if scope=='episode':
            if episode is None or int(episode)<0:raise ValueError('Select an episode first.')
            part['episodes']=[{'number':int(episode)}]
        item['seasons']=[part]
    kind='movies' if media=='movie' else 'shows'
    response=simkl_api._request('/sync/history',payload={kind:[item]},method='POST',auth=True,timeout=8)
    if not isinstance(response,dict) or response.get('error') or any((response.get('not_found') or {}).values()):
        raise ValueError('Simkl could not confirm this watched change.')
    added=response.get('added') or {}
    if not (added.get('statuses') or any(isinstance(added.get(k),(int,float)) and added[k]>0 for k in ('movies','shows','episodes'))):
        raise ValueError('Simkl did not confirm the change. Refresh your watched status and retry.')
    if _account()!=account:raise ValueError('The Simkl account changed. Reopen the title to refresh its status.')
    record(ctx,scope,season,episode)
    from . import continue_local
    continue_local.complete_matching(aliases(ids)+[ctx.get('canonical_id')],media,scope,season,episode)
    simkl_api.invalidate_cache('/sync/all-items')
    return True

def cleared(entry,scope='title',season=None,episode=None):
    """7.0.29: a watched entry without the marks that Unmark watched removes."""
    entry=dict(entry or {'watched':False,'seasons':[],'episodes':[]})
    entry['watched']=False
    if scope=='title':
        entry['seasons'],entry['episodes']=[],[]
    else:
        entry['seasons']=[s for s in entry.get('seasons',[]) if s!=str(season)]
        if scope=='season':entry['episodes']=[e for e in entry.get('episodes',[]) if not e.startswith('%s:'%season)]
        else:entry['episodes']=[e for e in entry.get('episodes',[]) if e!='%s:%s'%(season,episode)]
    return entry


def unmark(ctx,scope='title',season=None,episode=None):
    """7.0.29: Unmark watched on Simkl (POST /sync/history/remove), then locally."""
    if not simkl_api.authorized():raise ValueError('Connect Simkl in HUB Settings first.')
    ids=simkl_api._ids_from_ctx(ctx)
    if not ids:raise ValueError('This title has no IMDb, TMDb or TVDb ID for Simkl.')
    media='movie' if ctx.get('media_type')=='movie' else 'series'
    item={'ids':ids}
    if media=='series' and scope in ('season','episode'):
        part={'number':int(season)}
        if scope=='episode':part['episodes']=[{'number':int(episode)}]
        item['seasons']=[part]
    response=simkl_api._request('/sync/history/remove',payload={'movies' if media=='movie' else 'shows':[item]},method='POST',auth=True,timeout=8)
    if not isinstance(response,dict) or response.get('error'):raise ValueError('Simkl could not confirm this change.')
    local=copy.deepcopy(_remote_snapshot());items=local.setdefault('items',{})   # 9.0.7: Simkl's own list (see record)
    mids=aliases(ids)
    if ctx.get('canonical_id'):mids.append(ctx['canonical_id'])
    for mid in set(mids):
        if key(media,mid) in items:items[key(media,mid)]=cleared(items[key(media,mid)],scope,season,episode)
    local['updated']=time.time()
    simkl_api._write_json(_path(),local)
    _invalidate_view()
    simkl_api.invalidate_cache('/sync/all-items')
    return True


def record(ctx,scope='title',season=None,episode=None):
    """Record only after a successful Simkl history write.

    9.0.7: into Simkl's own list (_remote_snapshot), as trakt_watched.mark keeps Trakt's. The
    merged view (snapshot: Trakt, MDBList, WeTrakr, what played here and the marks set by hand)
    was written over simkl_watched.json, and from then on every one of those marks read as
    Simkl's: a film unmarked on Trakt, or its local progress gone, stayed watched until Simkl's
    next full read of its lists."""
    ids=simkl_api._ids_from_ctx(ctx);media='movie' if ctx.get('media_type')=='movie' else 'series'
    local=copy.deepcopy(_remote_snapshot());items=local.setdefault('items',{})
    mids=aliases(ids)
    if ctx.get('canonical_id'):mids.append(ctx['canonical_id'])
    for mid in set(mids):
        entry=dict(items.get(key(media,mid)) or {'watched':False,'seasons':[],'episodes':[]})
        if media=='movie' or scope=='title':entry['watched']=True
        elif scope=='season':entry['seasons']=sorted(set(entry.get('seasons',[]))|{str(season)})
        else:entry['episodes']=sorted(set(entry.get('episodes',[]))|{'%s:%s'%(season,episode)})
        items[key(media,mid)]=entry
    local['updated']=time.time()
    if not simkl_api._write_json(_path(),local):raise ValueError('Saved on Simkl, but the local watched cache could not be written. Check Kodi profile storage.')
    _invalidate_view()

def is_episode_watched(entry,season,episode):
    return bool(entry.get('watched') or str(season) in entry.get('seasons',[]) or '%s:%s'%(season,episode) in entry.get('episodes',[]))
