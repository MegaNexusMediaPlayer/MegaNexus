# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import base64
import html
import json
import math
import os
import re
import sys
import threading
import time
import unicodedata
from urllib.parse import parse_qsl, parse_qs, urlencode, urlparse, urljoin, quote_plus

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .meganexus import keyed_cache
from .meganexus import progress_db
from . import library_orders
from .meganexus import addon_registry
from .card_art import addon_fanart, catalog_art, enrich_meta_art, mixed_meta_pictures, layered_meta_pictures, posters_prefer_local, poster_source_mode, native_meta_art, extract_ids, media_path, provider_art, root_art, neutral_fanart, kodi_safe_url as _wrap_tokenized_url
from .texts import tr
from .meganexus.addon_wire import fetch_catalog, fetch_meta, fetch_streams, all_at_once, each_parallel, begin_race, offers, manifest_ok, fast_timeout, meta_ttl, parallel_workers
from . import stremio_adapter as _stremio_adapter
from .finding import recall as _recall
from .scan_pacing import (
    fair_job_order as _fair_search_job_order,
    iter_search_results as _iter_search_race,
    source_rows_until_enough as _iter_source_race,
)
from . import server_health as _server_health


class _Later(object):
    """A module, or one function of it, imported the first time it is used: hub is
    imported on every start, most of these are needed only now and then."""
    __slots__ = ('where', 'what', 'got')

    def __init__(self, where, what=None):
        self.where, self.what, self.got = where, what, None

    def _get(self):
        if self.got is None:
            from importlib import import_module
            found = import_module(self.where, package=_PKG)
            self.got = getattr(found, self.what) if self.what else found
        return self.got

    def __getattr__(self, name):
        return getattr(self._get(), name)

    def __call__(self, *args, **kwargs):
        return self._get()(*args, **kwargs)


_PKG = __package__ or 'resources.lib'


trakt_api              = _Later('.trakt_api')
mdblist            = _Later('.mdblist_api')
simkl_api              = _Later('.simkl_api')
_plex              = _Later('.plex')
plex_link_window            = _Later('.plex_link_window')
anime_ids          = _Later('.anime_id_map')
_stream_ids        = _Later('.stream_ids')
_emby              = _Later('.mediabrowser')
helper_player_file       = _Later('.helper_player_file')
_tmdb_art_db       = _Later('.tmdb_helper_db')
_tmdb_api       = _Later('.tmdb_api')
_collections_mod   = _Later('.shared_collections')
_nuvio_sync_mod     = _Later('.nuvio_import_share')
_setup_center_mod    = _Later('.screens.setup_page')
_accounts_route_mod  = _Later('.screens.accounts_page')
_fast_dispatch_mod    = _Later('.screens.quick_routes')
library_titles    = _Later('.library_titles')
tmdb_helper_live   = _Later('.tmdb_helper_live')
_meta_choice       = _Later('.meta_choice')

_rank_finalize_stream_entries = _Later('.source_order', 'finalize_stream_entries')
_nextup_invalidate_cache = _Later('.next_episodes',    'invalidate_nextup_cache')
_nextup_series_videos_cached = _Later('.next_episodes', 'show_videos_kept')
_nextup_items_cached_logic   = _Later('.next_episodes', 'nextup_items_cached')
save_session             = _Later('.player_session', 'save_session')
load_session             = _Later('.player_session', 'load_session')
_submit_optional         = _Later('.side_jobs', 'maybe_run')

_subtitle_for_switch = _Later('.playing.subtitle_handoff', 'capture_for_switch')
_gather_subtitles = _Later('.playing.subtitle_handoff', 'collect')
_first_subtitle_index = _Later('.subtitle_names', 'default_index')
_subtitle_paths = _Later('.playing.subtitle_handoff', 'prepare')
_publish_post_start_job = _Later(
    '.playing.after_start', 'leave_job')
_publish_subtitle_ids = _Later('.playing.subtitle_handoff', 'publish_ids')
_subtitle_mode = _Later('.subtitle_names', 'pick_mode')
_subtitle_summary = _Later('.subtitle_names', 'summary')
_subtitle_prefetch_start = _Later('.playing.subtitle_prefetch', 'start')
_kodi_subtitle_search = _Later('.playing.subtitle_handoff', 'open_kodi_search')

def _search_progress(**kwargs):
    """The search screen the `search_style` setting picks (search_progress)."""
    from .search_progress import open_progress
    return open_progress(_setting('search_style', '0') or '0', **kwargs)
# ─────────────────────────────────────────────────────────────────────

from .hub_base import *  # noqa: F401,F403
from .hub_log import log  # noqa: E402  (used by fallback/except paths below)
from .hub_base import ADDON, HANDLE, BASE_URL, WINDOW_ID, PROP, SERIES_PROP_PREFIX, SUBS_DIR, FILTER_NAMES, HEX_ENTITIES, SPECIAL_BLANKS, COLOR_TAG_RE, STREAM_ICON_RE, REGIONAL_FLAG_RE, BRACKET_RE, MULTI_WS_RE, SIZE_RE, YEAR_RE, build_url, is_show, source_list_url, source_list_url_for, notify, error, _get_int_setting, _get_bool_setting, _no_pages, clean_defaults_once

# MegaNexus updates preserve stored settings. New profiles use schema defaults;
# do not replay the upstream clean-baseline migration during module loading.

_subtitle_selected_first = _Later('.subtitle_choice', 'selected_first')
_subtitle_to_turn_on    = _Later('.subtitle_choice', 'first_to_turn_on')

from .kodi_rows import end_dir, add_item, _merge_seed_ids, _profile_path, _listing_page_size, _get_tmdbh_seed_ids




def _source_pref_path():
    return os.path.join(_profile_path(), 'last_source_map.json')


def _playback_monitor_path():
    try:
        path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/playback_monitor.log')
    except Exception:
        path = os.path.join(_profile_path(), 'playback_monitor.log')
    return path


def _log_safe(value):
    """7.0.13: links in the monitor log lose their query (debrid CDN tokens, keys)."""
    text = str(value)
    if text.startswith(('http://', 'https://')) and '?' in text:
        return text.split('?', 1)[0] + '?…'
    return text


def _play_note(event, level=xbmc.LOGINFO, **payload):
    """A playback event in Kodi's log and the playback log (empty fields left out, texts made log-safe)."""
    from . import play_log
    try:
        path = _playback_monitor_path()
    except Exception:
        path = ''
    play_log.write(play_log.record(event, payload, _log_safe, whole=(dict, list, tuple)), level, path)


def _source_choice_list(media_type='movie', canonical_id='', title='', season='', episode='', video_id='', resume_seconds='', preferred_provider_name='', source_provider_id='', source_mode=''):
    """The 'Choose add-on' menu entries of a title row (a show: 'Open seasons'); from a known add-on
    also its other streams only and direct play from it."""
    common = dict(media_type=media_type, canonical_id=canonical_id, title=title, season=season, episode=episode,
                  video_id=video_id, resume_seconds=resume_seconds, preferred_provider_name=preferred_provider_name,
                  source_provider_id=source_provider_id)
    url = source_list_url(source_mode=source_mode, **common)
    if not url:
        return []
    show_root = is_show(media_type) and not _shown_number(season) and not _shown_number(episode)
    menu = [(tr('Open seasons') if show_root else tr('Choose add-on'), 'Container.Update(%s)' % url)]
    if not source_provider_id or show_root:
        return menu
    same = source_list_url(source_mode='only', **common)
    if same:
        menu.append(('Pick another stream from the same source only', 'Container.Update(%s)' % same))
    play = {'action': 'play_item', 'media_type': 'series' if is_show(media_type) else (media_type or 'movie'),
            'canonical_id': canonical_id, 'title': title or canonical_id, 'source_provider_id': source_provider_id,
            'source_mode': 'only'}
    if video_id:
        play['video_id'] = video_id
    play.update((key, str(value)) for key, value in (('season', season), ('episode', episode),
                                                      ('resume_seconds', resume_seconds)) if _shown_number(value))
    menu.append(('Direct play from the same add-on', 'RunPlugin(%s)' % build_url(**play)))
    return menu


_DISPATCH_PROP = 'meganexus.dispatch.in_flight'


def _route_running(key, window_seconds=2.5):
    """True when the same route already ran within the window (Kodi sometimes sends a click twice)."""
    if not key:
        return False
    now = time.time()
    try:
        home = xbmcgui.Window(WINDOW_ID)
        last_key, _sep, stamp = (home.getProperty(_DISPATCH_PROP) or '').partition('|')
        try:
            last = float(stamp) if _sep else 0.0
        except Exception:
            last = 0.0
        if _sep and last_key == key and now - last < window_seconds:
            return True
        home.setProperty(_DISPATCH_PROP, '%s|%.3f' % (key, now))
    except Exception:
        pass
    return False


_TMDBH_HANDOFF_UNTIL_PROP = 'meganexus.tmdbh_handoff_until'
_TMDBH_TRANSIENT_PROPS = ('meganexus.invoked_by_tmdbh', 'meganexus.tmdbh_seed_ids', 'meganexus.tmdbh_seed_for', _TMDBH_HANDOFF_UNTIL_PROP)
_SOURCE_TRANSIENT_PROPS = (
    'meganexus.source.clearlogo', 'meganexus.source.logo', 'meganexus.source.poster', 'meganexus.source.thumb',
    'meganexus.source.fanart', 'meganexus.source.title', 'meganexus.source.plot', 'meganexus.source.year',
    'meganexus.source.rating', 'meganexus.source.genre', 'meganexus.source.studio', 'meganexus.source.key'
)
# the artwork other skins (Arctic Fuse) read while something plays - cleared with ours
_ARCTIC_NOW = ('Logo', 'Thumb', 'Fanart', 'Title', 'Plot', 'Year', 'Studio', 'Genre', 'Rating', 'Episode', 'ShowTitle')
_ARCTIC_PLAYER = ('Logo', 'Thumb', 'Fanart', 'Studio', 'Genre', 'Rating', 'Episode', 'ShowTitle')
_GLOBAL_ART_TRANSIENT_PROPS = (('clearlogo', 'logo', 'tvshow.clearlogo', 'poster', 'thumb', 'fanart', 'fanart_image')
                               + tuple('meganexus.' + face for face in ('clearlogo', 'poster', 'fanart'))
                               + tuple('ArcticFuse.NowPlaying.' + part for part in _ARCTIC_NOW)
                               + tuple('ArcticFuse.Player.' + part for part in _ARCTIC_PLAYER)
                               + ('ArcticFuse.CurrentlyPlaying',))


def _note_helper_handoff(seconds=45):
    try:
        until = time.time() + max(8, int(seconds or 45))
        for win_id in (WINDOW_ID, 10000, 12005):
            try:
                xbmcgui.Window(win_id).setProperty(_TMDBH_HANDOFF_UNTIL_PROP, '%.3f' % until)
            except Exception:
                pass
    except Exception:
        pass


def _helper_handoff_on():
    try:
        now = time.time()
        for win_id in (WINDOW_ID, 10000, 12005):
            try:
                win = xbmcgui.Window(win_id)
                if (win.getProperty('meganexus.invoked_by_tmdbh') or '').strip() == '1':
                    return True
                raw_until = win.getProperty(_TMDBH_HANDOFF_UNTIL_PROP) or ''
                if raw_until:
                    try:
                        if float(raw_until) > now:
                            return True
                    except Exception:
                        pass
            except Exception:
                continue
    except Exception:
        pass
    return False


def _forget_helper_handoff():
    for win_id in (WINDOW_ID, 10000, 12005):
        try:
            win = xbmcgui.Window(win_id)
        except Exception:
            continue
        for key in _TMDBH_TRANSIENT_PROPS:
            try:
                win.clearProperty(key)
            except Exception:
                pass


def _forget_source_scan_props(clear_global=False):
    if clear_global:
        try:
            if _player_has_video():
                clear_global = False
        except Exception:
            clear_global = False
    for win_id in (WINDOW_ID, 10000):
        try:
            win = xbmcgui.Window(win_id)
        except Exception:
            continue
        for key in _SOURCE_TRANSIENT_PROPS:
            try:
                win.clearProperty(key)
            except Exception:
                pass
        if clear_global:
            for key in _GLOBAL_ART_TRANSIENT_PROPS:
                try:
                    win.clearProperty(key)
                except Exception:
                    pass


_PICTURE_REF_FIELDS = (('media_type', 'type'), ('canonical_id', 'id'), ('video_id',), ('tmdb_id',), ('imdb_id',),
                       ('tvdb_id',), ('season',), ('episode',))


def _source_picture_ref(payload=None):
    """What identifies a source window's title (its pictures belong to it)."""
    data = payload or {}
    try:
        parts = [str(next((data[k] for k in keys if data.get(k)), '') or '').strip() for keys in _PICTURE_REF_FIELDS]
        parts[0] = parts[0].lower()
        parts.append(str(data.get('show_title') or data.get('originaltitle') or data.get('title') or data.get('name')
                         or '').strip().lower())
        return '|'.join(parts)
    except Exception:
        return ''


def play_item(media_type='', canonical_id='', title='', video_id='', season='', episode='', resume_seconds='0', resume_percent='', preferred_provider_name='', tmdb_id='', imdb_id='', tvdb_id='', source_provider_id='', source_mode='', ui_poster='', ui_fanart='', ui_clearlogo='', ui_seed_key=''):
    from .frontend_bridge import legacy_streams
    return legacy_streams(**locals())


def _drop_next_up_cache():
    try:
        _nextup_invalidate_cache(xbmcgui.Window(WINDOW_ID))
    except Exception:
        pass


class _Answers(object):
    """Search answers kept ``seconds``, at most ``most`` of them (the oldest goes first)."""

    def __init__(self, most, seconds):
        from collections import OrderedDict
        self.most, self.seconds, self.lock, self.rows = most, seconds, threading.Lock(), OrderedDict()

    def get(self, key):
        with self.lock:
            until, value = self.rows.get(key, (0, None))
            if until >= time.time():
                return value
            self.rows.pop(key, None)
            return None

    def put(self, key, value):
        with self.lock:
            self.rows.pop(key, None)
            self.rows[key] = (time.time() + self.seconds, value)
            while len(self.rows) > self.most:
                self.rows.popitem(last=False)

    def clear(self):
        with self.lock:
            self.rows.clear()


_searches = _Answers(32, 180)


def _play_addon_ref(ctx=None):
    ctx = ctx or {}
    bits = []
    for key in ('server_type', 'provider_id', 'provider_name', 'provider_base_url', 'stream_url'):
        value = str((ctx or {}).get(key) or '').strip().lower()
        if value:
            bits.append(value)
    return ' '.join(bits)


def _is_server_stream(ctx=None):
    sig = _play_addon_ref(ctx)
    if not sig:
        return False
    return any(marker in sig for marker in ('plex', 'plexio', 'emby', 'jellyfin', 'streambridge'))


def _is_plex_chooser(ctx=None, stream_url=''):
    sig = '%s %s' % (_play_addon_ref(ctx), str(stream_url or '').lower())
    return (str(stream_url or '').lower().startswith('plugin://') and
            any(marker in sig for marker in ('plexbridge', 'plexio')))


def _dialog_open(name):
    return xbmc.getCondVisibility('Window.IsActive(%s)' % name) or xbmc.getCondVisibility('Dialog.IsActive(%s)' % name)


def _watch_selector_cancel(ctx, stream_url):
    """After Plex's version chooser is cancelled, Kodi's false 'playback failed' dialog is closed
    (watched for up to 90 s in the background)."""
    if not _is_plex_chooser(ctx, stream_url):
        return

    def watch():
        seen, closed_at = False, 0.0
        for _tick in range(900):
            xbmc.sleep(100)
            try:
                if _player_has_video(xbmc.Player()):
                    return
                if _dialog_open('selectdialog'):
                    seen, closed_at = True, 0.0
                    continue
                if not seen:
                    continue
                closed_at = closed_at or time.monotonic()
                waited = time.monotonic() - closed_at
                if waited >= 0.8 and _dialog_open('okdialog'):
                    xbmc.executebuiltin('Dialog.Close(okdialog,true)')
                    xbmc.log('[MegaNexus] suppressed false playback failure after Plex selector cancel', xbmc.LOGINFO)
                    return
                if waited > 4.0:
                    return
            except Exception:
                return
    _submit_optional(watch, key='selector-cancel:%s' % abs(hash(str(stream_url or ''))))


def _online_posters_only(value=''):
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'remote', 'tmdb', 'trakt')


def _online_query(force_remote=False):
    return {'force_remote': '1'} if force_remote else {}


def _page_of(rows, page='0'):
    try:
        page_num = max(0, int(page or 0))
    except Exception:
        page_num = 0
    size = _listing_page_size()
    start = page_num * size
    end = start + size
    total = len(rows or [])
    return page_num, size, (rows or [])[start:end], end < total


def _set_unique_ids(item, ids, show=False):
    """The ids on the item's InfoTag (Kodi 20+), else on the item itself."""
    found, default = _unique_id_map(ids, show)
    if not found:
        return
    if _KODI_MAJOR >= 20:
        try:
            item.getVideoInfoTag().setUniqueIDs(found, default)
            return
        except Exception:
            pass
    if hasattr(item, 'setUniqueIDs'):
        item.setUniqueIDs(found, default)


def _put_unique_ids(item, ids, info=None):
    ids = ids or {}
    if info is not None and ids.get('imdb_id') and not info.get('imdbnumber'):
        info['imdbnumber'] = ids['imdb_id']
    try:
        for name, key in (('imdb_id', 'imdb_id'), ('IMDBNumber', 'imdb_id'), ('tmdb_id', 'tmdb_id'), ('tvdb_id', 'tvdb_id')):
            if ids.get(key):
                item.setProperty(name, str(ids[key]))
        _set_unique_ids(item, ids)
    except Exception:
        pass


def _meta_keep_ref(media_type, canonical_id, source_provider_id=''):
    return '%s:%s:%s' % (media_type or '', canonical_id or '', _meta_variant(source_provider_id))


def _meta_kept(media_type, canonical_id, source_provider_id=''):
    key = _meta_keep_ref(media_type, canonical_id, source_provider_id)
    ttl = max(60, int(meta_ttl() or 3600))
    with _META_MEM_LOCK:
        row = _META_MEM.get(key)
        if not row:
            return None
        saved_at, payload = row
        if (time.time() - saved_at) > ttl:
            _META_MEM.pop(key, None)
            try:
                _META_MEM_ORDER.remove(key)
            except ValueError:
                pass
            return None
        return dict(payload or {})


def _meta_keep(media_type, canonical_id, payload, source_provider_id=''):
    if not payload:
        return
    key = _meta_keep_ref(media_type, canonical_id, source_provider_id)
    with _META_MEM_LOCK:
        if key not in _META_MEM:
            _META_MEM_ORDER.append(key)
        _META_MEM[key] = (time.time(), dict(payload))
        while len(_META_MEM_ORDER) > _META_MEM_MAX:
            old = _META_MEM_ORDER.pop(0)
            _META_MEM.pop(old, None)


def _favorite_props(is_favorite=None):
    if not bool(is_favorite):
        return {}
    return {
        'IsFavorite': 'true',
        'IsFavourite': 'true',
        'MegaNexus.IsFavorite': 'true',
        'MegaNexus.IsFavourite': 'true',
    }


_RATING_PICTURE_MARKS = ('easyratingsdb.com', 'easyratingsdb', 'erdb', 'ratingposterdb.com', 'rating-poster', 'ratingposter',
                         'rpdb', 'poster-ratings', 'ratings-poster', 'btttr.cc', 'betterposters', 'top-streaming.stream',
                         'top-posters', 'topposters', 'aiometadata', 'aioratings', 'mdblist.com/poster')


def _is_rating_picture(value):
    """A poster with ratings drawn on it (ERDB, RPDB, better posters...)."""
    low = str(value or '').lower()
    return any(mark in low for mark in _RATING_PICTURE_MARKS)


def _is_overlay_picture(value):
    text = str(value or '').lower()
    return _is_rating_picture(text) or any(token in text for token in (
        'plexio', 'plexbridge',
    ) + (
        '/:/transcode', 'composite', 'overlay', 'photo/:/transcode',
        '/photo/', '/composite/',
        '/items/', '/emby/', '/jellyfin/',
    ))


_POSTER_COPIES = ('tvshow.poster', 'season.poster', 'thumbnail', 'cover', 'image', 'tvshow.thumb')


_POSTER_FACES = ('thumb', 'icon', 'thumbnail', 'cover', 'image', 'tvshow.thumb')


def _kodi_pictures(art):
    """Pictures as Kodi's art dictionary: a lone address becomes icon/thumb/poster; the poster is
    copied into every poster slot (a decorated poster replaces the small faces too)."""
    if not art:
        return art
    if isinstance(art, bytes):
        art = art.decode('utf-8', 'replace')
    if not isinstance(art, (str, dict)):
        try:
            art = dict(art)
        except (TypeError, ValueError):
            art = str(art or '')
    if isinstance(art, str):
        value = art.strip()
        return {'icon': value, 'thumb': value, 'poster': value} if value else {}
    out = dict(art)
    poster = out.get('poster') or out.get('tvshow.poster') or out.get('season.poster') or out.get('thumb') or out.get('icon')
    if not poster:
        return out
    # every poster slot gets it; a decorated (framed) poster also takes the small faces
    decorated = _is_overlay_picture(poster)
    for slot in ('poster',) + tuple(_POSTER_COPIES) + ('thumb', 'icon'):
        if decorated and slot in _POSTER_FACES:
            out[slot] = poster
        else:
            out.setdefault(slot, poster)
    return out


def _metahub(face, imdb):
    """Stremio's own picture of a title by its IMDb id (poster / background / logo)."""
    return 'https://images.metahub.space/%s/%s/%s/img' % (face, 'medium' if face == 'logo' else 'large', imdb)



_PROXY_HEALTH = {}
_PROXY_HEALTH_LOCK = threading.Lock()
_PROXY_HEALTH_TTL = 300.0
_PROXY_PROBE_TIMEOUT = 1.5


def _proxy_url_domain(url):
    try:
        return (urlparse(url).netloc or '').lower()
    except Exception:
        return ''


def _check_proxy(url):
    try:
        from urllib.request import Request, urlopen
        req = Request(url, method='HEAD',
                      headers={'User-Agent': 'MegaNexus-poster-probe/1.0'})
        with urlopen(req, timeout=_PROXY_PROBE_TIMEOUT) as resp:
            code = getattr(resp, 'status', None) or resp.getcode()
            return 200 <= int(code) < 400
    except Exception:
        return False


def _proxy_verdict(domain, now):
    """A still valid answer about the poster proxy (this process, else the window's); None when there is none."""
    with _PROXY_HEALTH_LOCK:
        kept = _PROXY_HEALTH.get(domain)
        if kept and now < kept[1]:
            return kept[0]
    try:
        raw = xbmcgui.Window(WINDOW_ID).getProperty('meganexus.proxyhealth.%s' % domain) or ''
        if raw:
            verdict, until = raw.split('|', 1)
            if now < float(until):
                with _PROXY_HEALTH_LOCK:
                    _PROXY_HEALTH[domain] = (verdict == '1', float(until))
                return verdict == '1'
    except Exception:
        pass
    return None


def _proxy_answers(url):
    """Whether the decorated-poster proxy answers (asked once per while, shared through the window)."""
    domain = _proxy_url_domain(url)
    if not domain:
        return True
    now = time.time()
    known = _proxy_verdict(domain, now)
    if known is not None:
        return known
    healthy = _check_proxy(url)
    until = now + _PROXY_HEALTH_TTL
    with _PROXY_HEALTH_LOCK:
        _PROXY_HEALTH[domain] = (healthy, until)
    try:
        xbmcgui.Window(WINDOW_ID).setProperty('meganexus.proxyhealth.%s' % domain, '%s|%s' % ('1' if healthy else '0', until))
    except Exception:
        pass
    xbmc.log('[MegaNexus] poster-proxy %s probed: %s' % (domain, 'healthy' if healthy else 'UNREACHABLE — falling back to clean'),
             xbmc.LOGINFO)
    return healthy


def _imdb_found_in(meta):
    raw = meta or {}
    for key in ('imdb_id', 'imdb', 'id'):
        candidate = str(raw.get(key) or '').strip()
        if candidate.startswith('tt'):
            return candidate.split(':')[0]
    return ''


def _drop_bad_pictures(meta):
    """MetaHub's plain poster, backdrop and logo by the IMDb id ({} without one)."""
    imdb = _imdb_found_in(meta)
    if not imdb:
        return {}
    poster, backdrop = _metahub('poster', imdb), _metahub('background', imdb)
    return {'poster': poster, 'thumb': poster, 'fanart': backdrop, 'landscape': backdrop, 'clearlogo': _metahub('logo', imdb)}


_POSTER_SLOTS = ('poster', 'thumb', 'thumbnail', 'cover', 'image', 'tvshow.poster', 'season.poster', 'tvshow.thumb', 'icon')


_FRAMED_SLOTS = ('poster', 'tvshow.poster', 'season.poster')


def _with_clean_backdrop(out, clean):
    if not out.get('fanart') and clean.get('fanart'):
        out['fanart'] = clean['fanart']
        out.setdefault('landscape', clean['fanart'])
    return out


def _steady_poster(art, meta):
    """A rating poster (BetterPosters, RPDB, ERDB...) chosen in the add-on stays the poster - through our
    proxy, or as it is while its service answers, else the plain poster; the plain one fills the other
    slots. Any other poster is left as it is. (9.0.4: an always-plain rule put MetaHub's English
    poster on every card - Xperience's BetterPosters never showed, new titles stayed empty.)"""
    poster = (art.get('poster') or '').strip() if art else ''
    if not poster or not _is_overlay_picture(poster):
        return art
    clean = _drop_bad_pictures(meta or {})
    plain = clean.get('poster')
    if not plain:
        return art
    out = dict(art)
    try:
        from . import framed_posters
        framed = framed_posters.build_url(poster, plain)
    except Exception:
        framed = ''
    if not framed:
        framed = poster if _proxy_answers(poster) else plain
    for slot in _POSTER_SLOTS:
        out[slot] = framed if slot in _FRAMED_SLOTS else plain
    return _with_clean_backdrop(out, clean)

# The data layer and the background sync are the
# catalog_index (8.1: store, sync). service.py runs the scheduler.
# ─────────────────────────────────────────────────────────────────────

def _index_mode():
    raw = (ADDON.getSetting('index_mode') or 'Live (current)').strip()
    low = raw.lower()
    if 'fast' in low:
        return 'fast'
    if 'hybrid' in low:
        return 'hybrid'
    return 'live'


def _index_mode_active():
    return _index_mode() in ('fast', 'hybrid')


def _index_filters(bucket):
    """The section's genre / year / language filter for the local index (None where unset)."""
    try:
        extras = _folder_extra_for(bucket, '', '', {}) or {}
    except Exception:
        return None, None, None
    try:
        year = int(str(extras.get('year')).strip()) if extras.get('year') else None
    except (TypeError, ValueError):
        year = None
    return (extras.get('genre') or '').strip() or None, year, (extras.get('language') or '').strip() or None


def _show_from_index(bucket, page_num, page_size, fetch_limit, entries):
    """The section's page from the local catalog index (None when it has nothing for it): rows of
    (add-on, catalog, type, id, meta) with each title's own add-on and catalog."""
    from . import catalog_index
    if not catalog_index.bucket_has_data(bucket):
        return None
    genre, year, language = _index_filters(bucket)
    kind = _section_media_type(bucket)
    metas = catalog_index.query_bucket_metas(bucket, sort=_section_sort(bucket), media_type=kind, genre=genre, year=year,
                                             language=language, limit=fetch_limit, offset=page_num * page_size)
    if not metas:
        return None
    entries = entries or []
    addons = dict((p.get('id'), p) for p, _c, _b, _pin in entries if p and p.get('id'))
    catalogs = dict((c.get('id'), c) for _p, c, _b, _pin in entries if c and c.get('id'))
    first_addon, first_catalog = (entries[0][0], entries[0][1]) if entries else ({}, {})
    rows = []
    for meta in metas:
        meta_id = (meta.get('id') or meta.get('imdb_id')) if isinstance(meta, dict) else None
        if meta_id:
            rows.append((addons.get(meta.get('_meganexus_provider_id') or '', first_addon),
                         catalogs.get(meta.get('_meganexus_catalog_id') or '', first_catalog),
                         meta.get('type') or kind or 'movie', meta_id, meta))
    return rows


def _section_sort(bucket):
    try:
        extras = _folder_extra_for(bucket, '', '', {}) or {}
        sort_raw = (extras.get('sort') or '').lower()
        if 'rating' in sort_raw or 'popular' in sort_raw:
            return 'rating'
        if 'name' in sort_raw or 'title' in sort_raw or 'a-z' in sort_raw:
            return 'title'
        if 'year' in sort_raw:
            return 'year'
        if 'last_added' in sort_raw or 'added' in sort_raw:
            return 'added_date'
    except Exception:
        pass
    return 'release_date'


def _kodi_major_version():
    try:
        ver = xbmc.getInfoLabel('System.BuildVersion') or ''
        return int(str(ver).split('.', 1)[0])
    except Exception:
        return 19

_KODI_MAJOR = _kodi_major_version()


def _safe_start_on():
    try:
        raw = (ADDON.getSetting('safe_playback_handoff') or 'true').strip().lower()
        enabled = raw in ('true', '1', 'yes', 'on')
    except Exception:
        enabled = True
    return bool(_KODI_MAJOR >= 22 and enabled)


def _playlist_start_on_kodi22():
    try:
        return _KODI_MAJOR >= 22 and _safe_start_on()
    except Exception:
        return False


def _bare_item_on_kodi22():
    try:
        raw = (ADDON.getSetting('kodi22_minimal_item') or 'true').strip().lower()
        enabled = raw in ('true', '1', 'yes', 'on')
    except Exception:
        enabled = True
    return bool(_playlist_start_on_kodi22() and enabled)


from .info_tag import apply as _videoinfotag_apply, unique_ids as _unique_id_map  # noqa: E402


_LIBRARY_CONTENT = ('movies', 'tvshows', 'episodes', 'seasons')


def _add_kodi_sorting(content=None, sortable=True):
    """Kodi's sort choices for the list: unsorted always; year / rating / date / length for library
    content; name (ignoring 'The') for folders."""
    methods = [xbmcplugin.SORT_METHOD_UNSORTED]
    if sortable and content in _LIBRARY_CONTENT:
        methods += [xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_VIDEO_RATING, xbmcplugin.SORT_METHOD_DATE,
                    xbmcplugin.SORT_METHOD_DURATION]
    if sortable and content in (None, 'files', 'addons'):
        methods.append(xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    for method in sorted(set(methods), key=methods.index):
        try:
            xbmcplugin.addSortMethod(HANDLE, method)
        except Exception:
            pass


# (url, ListItem, isFolder) waiting for end_dir, which hands them to Kodi in ONE
# addDirectoryItems call instead of N - a catalog page of 30+ items is much faster
# that way. It belongs here and not only inside the functions that write it: with
# reuselanguageinvoker, _fresh_call_state() reads it before anything has filled it,
# and the first plugin call of a fresh VM died with a NameError (8.1.1) - nothing
# played, and the interface looked frozen.
_PENDING_ITEMS = []


def _add_waiting_items():
    global _PENDING_ITEMS
    if not _PENDING_ITEMS:
        return
    try:
        xbmcplugin.addDirectoryItems(HANDLE, _PENDING_ITEMS, len(_PENDING_ITEMS))
    except Exception:
        for path, item, is_folder in _PENDING_ITEMS:
            try:
                xbmcplugin.addDirectoryItem(HANDLE, path, item, isFolder=is_folder)
            except Exception:
                pass
    _PENDING_ITEMS = []


def _meta_mem_clear():
    try:
        _META_MEM.clear()
        _META_MEM_ORDER[:] = []
    except Exception:
        pass


def _addon_catalogs(provider, media_type=None):
    """An add-on's visible catalogs (of one type), in the manifest's order."""
    if (provider or {}).get('enabled') is False:
        return []
    listed = sorted(list((provider or {}).get('manifest', {}).get('catalogs', []) or []),
                    key=lambda c: int((c or {}).get('order', 0) or 0))
    return [c for c in listed if isinstance(c, dict) and c.get('enabled') is not False and c.get('hidden') is not True
            and (not media_type or c.get('type') == media_type)]


def _types_offered(provider):
    types = []
    for media_type in provider.get('manifest', {}).get('types') or []:
        if _addon_catalogs(provider, media_type):
            types.append(media_type)
    if types:
        return types
    seen = []
    for catalog in _addon_catalogs(provider):
        media_type = catalog.get('type')
        if media_type and media_type not in seen:
            seen.append(media_type)
    return seen


def _addon_searchable(provider, media_type=None):
    for catalog in _addon_catalogs(provider, media_type):
        for extra in catalog.get('extra') or []:
            if isinstance(extra, str) and extra.strip().lower() == 'search':
                return True
            if isinstance(extra, dict) and extra.get('name') == 'search':
                return True
    return False


_RATING_ADDON_MARKS = ('easyratingsdb.com', 'easyratingsdb', 'erdb proxy', 'erdb', 'ratingposterdb.com', 'rating poster',
                       'ratingposter', 'rpdb')


def _addon_is_rating_bridge(provider):
    """True for an add-on that serves rating-decorated posters (ERDB, RPDB)."""
    provider = provider or {}
    manifest = provider.get('manifest') or {}
    text = ' '.join(str(source.get(key) or '') for source, key in (
        (provider, 'name'), (provider, 'id'), (provider, 'base_url'), (provider, 'manifest_url'), (manifest, 'name'),
        (manifest, 'id'), (manifest, 'description'))).lower()
    return any(mark in text for mark in _RATING_ADDON_MARKS)

def _addon_is_plex_bridge(provider):
    return any(mark in _addon_text(provider) for mark in ('plexio', 'plexbridge', 'com.stremio.plexio',
                                                          'com.stremio.plexbridge'))


def _addon_text(provider):
    """An add-on's name, id, addresses and manifest name / id / description in one lower-case text."""
    provider = provider or {}
    manifest = provider.get('manifest') or {}
    return ' '.join(str(source.get(key) or '') for source, key in (
        (provider, 'name'), (provider, 'id'), (provider, 'base_url'), (provider, 'manifest_url'), (manifest, 'name'),
        (manifest, 'id'), (manifest, 'description'))).lower()


def _addon_keeps_pictures(provider):
    """A media-server bridge add-on (Plex, Emby, Jellyfin): its own pictures are the right ones."""
    return any(mark in _addon_text(provider) for mark in ('plex', 'plexio', 'emby', 'jellyfin'))


_ART_URL_KEYS = (
    'poster', 'thumbnail', 'thumb', 'image', 'posterUrl', 'posterURL',
    'imageUrl', 'imageURL', 'thumbUrl', 'thumbURL', 'background', 'fanart',
    'landscape', 'banner', 'backdrop', 'clearlogo', 'logo', 'clearart',
    'parentThumb', 'grandparentThumb', 'art', 'key'
)


def _addon_origin(provider):
    provider = provider or {}
    for raw in (provider.get('base_url'), provider.get('manifest_url')):
        origin = _safe_http_origin(raw)
        if origin:
            return origin
    return ''


_WHOLE_ADDRESSES = ('image://', 'special://', 'file://', 'plugin://', 'smb://', 'nfs://', 'http://', 'https://')


def _addon_picture_value(provider, value):
    """A picture address of an add-on made whole (a '/path' joined to the add-on's origin)."""
    text = str(value or '').strip()
    if not text or text.lower().startswith(_WHOLE_ADDRESSES):
        return text
    origin = _addon_origin(provider)
    if not (text.startswith('/') and origin):
        return text
    try:
        return urljoin(origin + '/', text.lstrip('/'))
    except Exception:
        return origin + text


def _plex_token_in(value):
    try:
        qs = parse_qs(urlparse(str(value or '')).query or '')
        return (qs.get('X-Plex-Token') or qs.get('x-plex-token') or qs.get('token') or [''])[0]
    except Exception:
        return ''


def _with_plex_token(url, token):
    text = str(url or '').strip()
    token = str(token or '').strip()
    if not text or not token or 'x-plex-token=' in text.lower():
        return text
    return '%s%sX-Plex-Token=%s' % (text, '&' if '?' in text else '?', token)


def _plex_full_picture(provider, value):
    text = str(value or '').strip()
    if not text:
        return ''
    lower = text.lower()
    if '/:/transcode' not in lower and 'transcode' not in lower and 'composite' not in lower and 'overlay' not in lower:
        return ''
    try:
        parsed = urlparse(text)
        qs = parse_qs(parsed.query or '')
        src = (qs.get('url') or qs.get('thumb') or qs.get('path') or [''])[0]
        if not src:
            return ''
        src = _addon_picture_value(provider, src)
        return _with_plex_token(src, _plex_token_in(text))
    except Exception:
        return ''


_NOT_PLEX_HOSTS = ('themoviedb.org', 'image.tmdb.org', 'fanart.tv', 'trakt.tv', 'catalog.nuvio.tv')


# a Plex server's own paths only: a bare /thumb/, /art/ or /metadata/ is any poster service's too
_PLEX_PICTURE_MARKS = ('/library/metadata/', '/library/collections/', '/photo/:/transcode',
                       '/:/transcode', 'x-plex-token=', 'plex.direct', 'plex.tv', 'plexapp.com')


def _is_plex_picture(value):
    """A picture a Plex server serves (never one of the public picture sites)."""
    low = str(value or '').strip().lower()
    return bool(low) and not any(h in low for h in _NOT_PLEX_HOSTS) and any(m in low for m in _PLEX_PICTURE_MARKS)


def _is_composed_poster(value):
    text = str(value or '').lower()
    return _is_rating_picture(text) or any(token in text for token in (
        'overlay', 'composite', 'ratingposter', 'rating-poster', 'rpdb', 'erdb',
        '/photo/:/transcode', '/:/transcode', '/collection-image/',
        '/composite/', '/overlay/'
    ))


_LOCAL_PICTURES = ('image://', 'special://', 'file://', 'plugin://', 'smb://', 'nfs://')


def _plex_resize_origin(provider, text):
    """The server that resizes the picture: a Plex bridge add-on's own, or the picture's when that is a
    Plex one ('' = none). Any other add-on's picture on its own host is a plain picture (PenguPlay's
    sport poster has no Plex resizer behind it: photo/:/transcode answered 404, the card stayed empty)."""
    origin = _addon_origin(provider)
    try:
        parsed = urlparse(text)
    except Exception:
        return ''
    plex = _is_plex_picture(text)
    if not (parsed.scheme and parsed.netloc):
        return origin if plex or _addon_is_plex_bridge(provider) else ''
    own_host = urlparse(origin).netloc.lower() if origin else ''
    if (own_host and parsed.netloc.lower() != own_host) or not origin:
        return '%s://%s' % (parsed.scheme, parsed.netloc) if plex else ''
    return origin if plex or _addon_is_plex_bridge(provider) else ''


def _plex_picture_url(provider, value, width=500, height=750):
    """A Plex bridge add-on's picture through Plex's own resizer (poster size), with its token."""
    text = _addon_picture_value(provider, value)
    if not text or text.lower().startswith(_LOCAL_PICTURES):
        return text or ''
    origin = _plex_resize_origin(provider, text)
    if not origin:
        return ''
    token = _plex_token_in(text)
    original = _addon_picture_value(provider, _plex_full_picture(provider, text) or text)
    if token:
        original = _with_plex_token(original, token)
    path = 'photo/:/transcode?url=%s&width=%s&height=%s&minSize=1&upscale=1' % (quote_plus(original), int(width), int(height))
    if token and 'x-plex-token=' not in path.lower():
        path += '&X-Plex-Token=%s' % token
    return urljoin(origin + '/', path)

def _addon_pictures_in(provider, node):
    """Every picture text in an 'images' / 'behaviorHints' block (one level deep) made playable."""
    out = {}
    for key, value in node.items():
        if isinstance(value, dict):
            value = dict((k, _addon_picture_value(provider, v) if isinstance(v, str) and v.strip() else v)
                         for k, v in value.items())
        elif isinstance(value, str) and value.strip():
            value = _addon_picture_value(provider, value)
        out[key] = value
    return out


def _poster_everywhere(out, poster, provider):
    if poster:
        out.update(poster=poster, thumb=poster, thumbnail=poster, icon=poster, image=poster)
        for slot in ('tvshow.poster', 'season.poster', 'tvshow.thumb'):
            out.setdefault(slot, poster)
    original = _plex_full_picture(provider, poster)
    if original:
        for slot in ('plex_original_poster', 'thumb_fallback', 'thumbnail_fallback'):
            out.setdefault(slot, original)


def _meta_picture_urls(provider, meta):
    """An add-on meta's pictures as Kodi can load them (unless a metadata source was chosen or
    the meta's pictures are fixed); a Plex bridge's or rating add-on's poster stays the poster."""
    if not isinstance(meta, dict):
        return meta
    source = str(meta.get('_meganexus_meta_source_id') or '').strip().lower()
    if str(meta.get('_meganexus_art_strict') or '').strip().lower() in ('1', 'true', 'yes', 'on') \
            or (source and source not in ('auto', 'native')):
        return meta
    out = dict(meta)
    for key in _ART_URL_KEYS:
        if out.get(key):
            out[key] = _addon_picture_value(provider, out[key])
    for block in ('images', 'behaviorHints'):
        if isinstance(out.get(block), dict):
            out[block] = _addon_pictures_in(provider, out[block])
    primary = out.get('poster') or out.get('thumbnail') or out.get('thumb') or out.get('image') or ''
    if _addon_is_plex_bridge(provider):
        _poster_everywhere(out, primary, provider)
        if primary and not _is_composed_poster(primary):
            resized = _plex_picture_url(provider, primary)
            if resized and resized != primary:
                out.setdefault('plex_transcode_poster', resized)
        return out
    if _addon_is_rating_bridge(provider) or _is_composed_poster(primary):
        _poster_everywhere(out, primary, provider)
        return out
    original, resized = _plex_full_picture(provider, primary), _plex_picture_url(provider, primary)
    if original:
        for slot in ('thumb', 'thumbnail', 'icon', 'plex_original_poster'):
            out.setdefault(slot, original)
    if resized:
        if primary:
            out.setdefault('plex_overlay_poster', primary)
        out['poster'] = resized
        out.setdefault('thumbnail', original or resized)
        out.setdefault('thumb', original or resized)
    return out


def _addon_meta_source(provider):
    try:
        provider_id = (provider or {}).get('id') or ''
        source_id = (_meta_choice.choice_for(provider_id) if provider_id else 'auto') or 'auto'
        if source_id == 'auto' and _addon_is_plex_bridge(provider):
            return 'native'
        return source_id
    except Exception:
        return 'auto'


def _addon_sets_pictures(provider):
    source_id = _addon_meta_source(provider)
    return source_id not in ('', 'auto')


def _meta_art_is_strict(meta):
    return str((meta or {}).get('_meganexus_art_strict') or '').strip().lower() in ('1', 'true', 'yes', 'on')


def _meta_source_id_from_meta(meta):
    return str((meta or {}).get('_meganexus_meta_source_id') or '').strip()


def _target_meta_source_id(target_key):
    try:
        return (_meta_choice.choice_for(target_key) if target_key else 'auto') or 'auto'
    except Exception:
        return 'auto'


def _meta_source_chosen(target_key):
    return _target_meta_source_id(target_key) not in ('', 'auto')


def _is_meta_pseudo_addon(target_key):
    return str(target_key or '').strip().startswith('virtual.')


def _needs_exact_meta(source_provider_id):
    sid = str(source_provider_id or '').strip()
    if not sid:
        return False
    if _is_meta_pseudo_addon(sid):
        return _meta_source_chosen(sid)
    try:
        provider = addon_registry.get_provider(sid)
    except Exception:
        provider = None
    return _addon_sets_pictures(provider or {'id': sid})


def _meta_variant(source_provider_id=''):
    try:
        source_map = ADDON.getSetting('provider_meta_map') or '{}'
    except Exception:
        source_map = '{}'
    return '|'.join([
        str(source_provider_id or ''),
        str(source_map or '{}'),
        str(poster_source_mode() or ''),
    ])


def _meta_from_addon_first(providers, source_provider_id=''):
    providers = [p for p in (providers or []) if p]
    sid = str(source_provider_id or '').strip()
    if not sid:
        return providers
    head = []
    tail = []
    seen = set()
    for p in providers:
        pid = str((p or {}).get('id') or '')
        if not pid or pid in seen:
            continue
        seen.add(pid)
        if pid == sid:
            head.append(p)
        else:
            tail.append(p)
    if not head:
        try:
            p = addon_registry.get_provider(sid)
        except Exception:
            p = None
        if p:
            head.append(p)
    return head + tail


def _addons_for_id_in(media_type, canonical_id, source_provider_id=''):
    return _meta_from_addon_first(_addons_for_id(media_type, canonical_id), source_provider_id=source_provider_id)


def _meta_pictures(provider, media_type, meta, fallback_art=None, force_remote=False, lazy=False):
    if lazy:
        return _meta_pictures_quick(provider, media_type, meta, fallback_art)
    art = _meta_pictures_work(provider, media_type, meta,
                                    fallback_art=fallback_art,
                                    force_remote=force_remote)
    try:
        art = _steady_poster(art, meta)
    except Exception as exc:
        xbmc.log('[MegaNexus] poster reliability filter failed: %s' % exc, xbmc.LOGDEBUG)
    try:
        art = _row_art_by_global_order(art, media_type, meta, provider)
    except Exception as exc:
        xbmc.log('[MegaNexus] global art priority failed: %s' % exc, xbmc.LOGDEBUG)
    try:
        art = _row_art_by_section_order(art, media_type, meta, provider)
    except Exception as exc:
        xbmc.log('[MegaNexus] bucket art priority failed: %s' % exc, xbmc.LOGDEBUG)
    return art


def _meta_pictures_quick(provider, media_type, meta, fallback_art=None):
    """The title's pictures from what is at hand (its meta, else the row's art), no asking."""
    known, spare = meta or {}, fallback_art or {}
    poster = known.get('poster') or spare.get('poster') or spare.get('thumb') or ''
    backdrop = known.get('background') or known.get('fanart') or spare.get('fanart') or ''
    art = dict.fromkeys(('poster', 'thumb', 'icon'), poster)
    art.update(dict.fromkeys(('fanart', 'banner', 'landscape'), backdrop))
    art['clearlogo'] = known.get('logo') or spare.get('clearlogo') or ''
    try:
        art = _steady_poster(art, meta)
    except Exception:
        pass
    return art


_SLOTS = 'poster:poster thumb icon tvshow.poster season.poster|background:fanart|landscape:landscape|' \
         'banner:banner|clearlogo:clearlogo logo tvshow.clearlogo|clearart:clearart tvshow.clearart'


def _picture_slots():
    """Each kind of picture and the Kodi art slots it fills."""
    return {kind: slots.split() for kind, slots in (part.split(':') for part in _SLOTS.split('|'))}


def _row_art_by_global_order(art, media_type, meta, current_provider):
    try:
        from . import meta_choice as _ms
    except Exception:
        return art
    if _ms.art_mode() != 'unified':
        return art
    out = None
    meta_id = (meta or {}).get('id') or (meta or {}).get('imdb_id') or ''
    for art_type, slot_keys in _picture_slots().items():
        priority = _ms.global_art_order(art_type)
        if not priority:
            continue
        chosen_url = _picture_by_order(
            art_type, priority, media_type, meta_id, meta, current_provider,
        )
        if not chosen_url:
            continue
        if out is None:
            out = dict(art)
        for key in slot_keys:
            out[key] = chosen_url
    return out if out is not None else art


def _row_art_by_section_order(art, media_type, meta, current_provider):
    try:
        bucket = xbmcgui.Window(WINDOW_ID).getProperty('meganexus.render_bucket') or ''
    except Exception:
        bucket = ''
    if not bucket:
        return art
    try:
        from . import meta_choice as _ms
    except Exception:
        return art
    if _ms.art_mode() != 'custom':
        return art

    art_slot_targets = _picture_slots()
    out = None
    meta_id = (meta or {}).get('id') or (meta or {}).get('imdb_id') or ''

    for art_type, slot_keys in art_slot_targets.items():
        priority = _ms.folder_art_order(bucket, art_type)
        if not priority:
            continue
        chosen_url = _picture_by_order(
            art_type, priority, media_type, meta_id, meta, current_provider,
        )
        if not chosen_url:
            continue
        if out is None:
            out = dict(art)
        for k in slot_keys:
            out[k] = chosen_url
    return out if out is not None else art


_ORDER_FIELDS = {'poster': 'poster', 'background': 'background', 'landscape': 'landscape', 'banner': 'banner',
                 'clearlogo': 'logo', 'clearart': 'clearart'}


_HELPER_FIELDS = {'poster': ('poster', 'thumbnail', 'thumb'), 'background': ('background', 'fanart'),
                  'landscape': ('landscape', 'background', 'fanart'), 'banner': ('banner', 'landscape', 'background'),
                  'clearlogo': ('clearlogo', 'logo'), 'clearart': ('clearart',)}


_OWN_FALLBACK = {'background': 'fanart', 'clearlogo': 'logo'}


def _first_text(source, fields):
    return next((str(source.get(f) or '').strip() for f in fields if str(source.get(f) or '').strip()), '')


def _picture_by_order(art_type, priority_pids, media_type, meta_id, meta, current_provider):
    """The first picture of the kind found along the chosen order of sources: the item's own
    ('native'), TMDb Helper, the listing add-on, then any add-on's cached details."""
    field = _ORDER_FIELDS.get(art_type)
    if not field:
        return ''
    meta = meta or {}
    listing = (current_provider or {}).get('id') or ''
    for pid in priority_pids:
        if not pid:
            continue
        if pid == 'native':
            value = _first_text(meta, (art_type,) + ((_OWN_FALLBACK[art_type],) if art_type in _OWN_FALLBACK else ()))
            if value:
                return value
            continue
        if pid == 'tmdb_helper':
            try:
                from . import meta_choice
                value = _first_text(meta_choice.from_helper(meta_choice.extract_ids(meta), meta, media_type) or {},
                                    _HELPER_FIELDS.get(art_type, (field,)))
                if value:
                    return value
            except Exception:
                pass
            continue
        if pid == listing and isinstance(meta, dict) and str(meta.get(field) or '').strip():
            return str(meta.get(field)).strip()
        try:
            from . import detail_cache
            cached = detail_cache.get_one(media_type, pid, meta_id) if meta_id else None
            if isinstance(cached, dict) and str(cached.get(field) or '').strip():
                return str(cached.get(field)).strip()
        except Exception:
            pass
    return ''


_RATING_KEEP_POSTER = ('poster', 'thumb', 'icon', 'thumbnail', 'cover', 'image', 'tvshow.poster', 'season.poster',
                       'tvshow.thumb')


def _rating_addon_pictures(meta, media_type, fallback_art):
    """A rating add-on's own (decorated) poster and logo over the enriched pictures; its backdrop
    only when the meta has one."""
    own = native_meta_art(meta, media_type, fallback_art=fallback_art)
    out = enrich_meta_art(meta, media_type, fallback_art=fallback_art)
    keys = list(_RATING_KEEP_POSTER)
    if own.get('clearlogo'):
        keys += ['clearlogo', 'logo', 'tvshow.clearlogo', 'clearart']
    if any((meta or {}).get(k) for k in ('background', 'fanart', 'backdrop', 'landscape')):
        keys += ['fanart', 'landscape', 'banner']
    out.update((key, own[key]) for key in keys if own.get(key))
    return out


def _meta_pictures_work(provider, media_type, meta, fallback_art=None, force_remote=False):
    """Which picture builder a catalog title gets: the chosen metadata source's as given, the
    add-on's own ('native'), a rating add-on's decorated poster, or enriched / mixed per the
    poster setting."""
    source = _meta_source_id_from_meta(meta)
    plex = _addon_is_plex_bridge(provider)
    if _meta_art_is_strict(meta) or (source and source not in ('auto', 'native')):
        return (layered_meta_pictures if plex else native_meta_art)(meta, media_type, fallback_art={})
    addon_source = _addon_meta_source(provider)
    if addon_source == 'native':
        return (layered_meta_pictures if plex else native_meta_art)(meta, media_type, fallback_art=fallback_art)
    if addon_source not in ('', 'auto'):
        return native_meta_art(meta, media_type, fallback_art={})
    if _addon_is_rating_bridge(provider):
        return _rating_addon_pictures(meta, media_type, fallback_art)
    if force_remote:
        builder = enrich_meta_art
    elif plex:
        builder = layered_meta_pictures
    elif _addon_keeps_pictures(provider):
        builder = native_meta_art if posters_prefer_local() else enrich_meta_art
    else:
        builder = mixed_meta_pictures if posters_prefer_local() else enrich_meta_art
    return builder(meta, media_type, fallback_art=fallback_art)


def _addon_summary(provider):
    """'3 Movies catalogs • 2 Series catalogs • Movie Search' - what an add-on offers."""
    counts = [(len(_addon_catalogs(provider, kind)), label) for kind, label in (('movie', 'Movies'), ('series', 'Series'))]
    parts = ['%d %s catalogs' % (count, label) for count, label in counts if count]
    parts += ['%s Search' % label for kind, label in (('movie', 'Movie'), ('series', 'Series')) if _addon_searchable(provider, kind)]
    if not parts and _addon_catalogs(provider):
        parts.append('%d catalogs' % len(_addon_catalogs(provider)))
    return ' • '.join(parts) or ((provider.get('manifest') or {}).get('description') or provider.get('manifest_url') or '')


def _group_title(media_type):
    return 'Movies' if media_type == 'movie' else 'TV Shows' if media_type == 'series' else media_type


def _fallback_pictures(provider=None, media_type='movie', catalog=None, name=''):
    """The add-on's pictures for a title without its own (the catalog's backdrops over them)."""
    provider = provider or {}
    manifest = provider.get('manifest') or {}
    art = provider_art(provider.get('name') or manifest.get('name') or 'Provider', manifest, base_url=provider.get('base_url') or '')
    if not catalog:
        return art
    own = catalog_art(name or catalog.get('name') or catalog.get('id') or media_type, media_type, manifest, catalog)
    return dict(art, **dict((key, own[key]) for key in ('fanart', 'landscape', 'banner') if own.get(key)))


def _plain_values(value):
    """The texts and numbers in a value (one level into dicts, lists and tuples)."""
    simple = (str, int, float)
    if isinstance(value, dict):
        out = []
        for sub in value.values():
            if isinstance(sub, simple):
                out.append(str(sub))
            elif isinstance(sub, (list, tuple)):
                out.extend(str(x) for x in sub if isinstance(x, simple))
        return out
    if isinstance(value, (list, tuple)):
        return [str(x) for x in value if isinstance(x, simple)]
    return [] if value is None else [str(value)]


def _row_words(*values):
    """All words of the values in one lower-case text (accents taken apart) for matching."""
    text = ' '.join(part for value in values for part in _plain_values(value))
    try:
        return unicodedata.normalize('NFKD', text).lower()
    except Exception:
        return text.lower()


def _catalog_words(provider, catalog):
    """Every word naming an add-on catalog (for placing it in a Hub section)."""
    provider, catalog = provider or {}, catalog or {}
    manifest = provider.get('manifest') or {}
    return _row_words(provider.get('name'), provider.get('manifest_url'),
                      *([manifest.get(k) for k in ('name', 'id', 'description', 'types')]
                        + [catalog.get(k) for k in ('name', 'id', 'type', 'description', 'genres', 'extra')]))


_SECTION_WORDS = (('turkish', ('turkish', 'turkey', 'turk', 'turkiye', 'türkiye', 'dizi', 'diziler', 'turkish series',
                               'turkish drama', 'Turkish')),
                  ('korean', ('korean', 'korea', 'k-drama', 'kdrama', 'k drama', 'korean drama', 'drakor', 'korean series',
                              'Korean')),
                  ('anime', ('anime', 'animu', 'anilist', 'kitsu', 'crunchyroll', 'myanimelist', 'Anime')))


_LIVE_WORDS = ('live', 'iptv', 'channel', 'channels', 'tv channel', 'television', 'Channels', 'Live TV', 'Live')


def _catalog_section(provider, catalog):
    """The Hub section a catalog belongs to: live, turkish, korean, anime, movies, series or other."""
    kind = str((catalog or {}).get('type') or '').strip().lower()
    words = _catalog_words(provider, catalog or {})
    if kind in ('tv', 'channel', 'channels', 'live', 'iptv') or any(w in words for w in _LIVE_WORDS):
        return 'live'
    for section, marks in _SECTION_WORDS:
        if any(w in words for w in marks):
            return section
    if kind == 'movie':
        return 'movies'
    return 'series' if kind in ('series', 'show', 'tvshow', 'anime') else 'other'


def _hub_bucket_title(bucket):
    return {
        'movies': 'Movies',
        'series': 'TV Shows',
        'anime': 'Anime',
        'turkish': 'Turkish',
        'korean': 'Korean',
        'live': 'Live TV',
        'other': 'Other catalogs',
    }.get(str(bucket or ''), _sub_section_title(bucket) or _own_section_title(bucket) or str(bucket or 'Catalogs'))


def _section_media_type(bucket):
    if _is_sub_section(bucket):
        return _section_media_type(_sub_section_parent(bucket))
    if bucket == 'movies':
        return 'movie'
    if bucket in ('series', 'anime', 'turkish', 'korean'):
        return 'series'
    return ''


def _section_content(bucket):
    if _is_sub_section(bucket):
        bucket = _sub_section_parent(bucket)
    if bucket == 'movies':
        return 'movies'
    if bucket in ('series', 'anime', 'turkish', 'korean'):
        return 'tvshows'
    return 'videos'


_SECTION_ICONS = {'movies': ('movies', 'movie'), 'series': ('series', 'series'), 'anime': ('anime', 'series'),
                  'turkish': ('turkish series drama', 'series'), 'korean': ('korean drama kdrama', 'series'),
                  'live': ('live tv channels', 'tv')}


def _section_icon(bucket):
    """A Hub section's picture (a sub folder uses its parent's)."""
    while _is_sub_section(bucket):
        bucket = _sub_section_parent(bucket)
    return catalog_art(*_SECTION_ICONS[bucket]) if bucket in _SECTION_ICONS else root_art('catalogs')


def _home_folders_path():
    return os.path.join(_profile_path(), 'hub_home_folders.json')


def _section_slug(name):
    text = _words_of(name or '')
    text = re.sub(r'[\W_]+', '-', text).strip('-').lower()
    if not text:
        text = 'folder-%d' % int(time.time())
    return 'custom:%s' % text[:48]


def _json_kept(path, empty):
    """What is kept as JSON in the profile, of the kind of ``empty`` ([] or {}); ``empty``
    when the file is missing, unreadable or holds something else."""
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return empty
    return data if isinstance(data, type(empty)) else empty


def _keep_json(path, data, empty):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data or empty, handle, ensure_ascii=False, indent=2)
    except (OSError, TypeError, ValueError):
        pass


def _json_list(path):
    return [row for row in _json_kept(path, []) if isinstance(row, dict)]


def _keep_json_list(path, rows):
    _keep_json(path, rows, [])


def _when(row):
    try:
        return int(row.get('created') or 0)
    except (TypeError, ValueError):
        return 0


def _stored_own_sections():
    """The user's own home folders (key, title, when made); [] when there are none."""
    rows = []
    for row in _json_list(_home_folders_path()):
        key, title = (str(row.get(name) or '').strip() for name in ('bucket', 'title'))
        if key and title:
            rows.append({'bucket': key, 'title': title, 'created': _when(row)})
    return rows


def _store_own_sections(rows):
    _keep_json_list(_home_folders_path(), rows)


def _home_subfolders_path():
    return os.path.join(_profile_path(), 'hub_home_subfolders.json')


def _stored_sub_sections():
    """The user's sub folders (parent section, key, title, when made); [] when there are none."""
    rows = []
    for row in _json_list(_home_subfolders_path()):
        parent, key, title = (str(row.get(name) or '').strip() for name in ('parent', 'bucket', 'title'))
        if parent and key and title:
            rows.append({'parent': parent, 'bucket': key, 'title': title, 'created': _when(row)})
    return rows


def _store_sub_sections(rows):
    _keep_json_list(_home_subfolders_path(), rows)


def _is_sub_section(bucket):
    return str(bucket or '').startswith('sub:')


def _sub_sections(parent=''):
    parent = str(parent or '').strip()
    return [r for r in _stored_sub_sections() if (r.get('parent') or '') == parent]


def _sub_section_info(bucket=''):
    bucket = str(bucket or '').strip()
    for row in _stored_sub_sections():
        if row.get('bucket') == bucket:
            return row
    return {}


def _sub_section_parent(bucket=''):
    return (_sub_section_info(bucket) or {}).get('parent') or ''


def _sub_section_title(bucket=''):
    return (_sub_section_info(bucket) or {}).get('title') or ''


def _sub_section_of(parent, name):
    parent = str(parent or '').strip() or 'home'
    slug = _section_slug(name).replace('custom:', '')
    parent_slug = re.sub(r'[^a-z0-9_-]+', '-', parent, flags=re.I).strip('-') or 'home'
    return 'sub:%s:%s' % (parent_slug[:36], slug[:40])


def _section_of_catalog(bucket):
    bucket = str(bucket or '').strip()
    if _is_sub_section(bucket):
        return _sub_section_parent(bucket) or bucket
    return bucket


def _standard_sections():
    return [
        {'bucket': 'movies', 'title': 'Movies'},
        {'bucket': 'series', 'title': 'TV Shows'},
        {'bucket': 'anime', 'title': 'Anime'},
        {'bucket': 'turkish', 'title': 'Turkish'},
        {'bucket': 'korean', 'title': 'Korean'},
        {'bucket': 'live', 'title': 'Live TV'},
    ]


def _home_sections(include_collection=False):
    rows = list(_standard_sections())
    seen = set([r.get('bucket') for r in rows])
    for row in _stored_own_sections():
        if row.get('bucket') in seen:
            continue
        rows.append(row)
        seen.add(row.get('bucket'))
    if include_collection:
        rows.append({'bucket': 'collection', 'title': 'Collection'})
    return rows


def _own_section_title(bucket):
    bucket = str(bucket or '').strip()
    if not bucket:
        return ''
    for row in _stored_own_sections():
        if row.get('bucket') == bucket:
            return row.get('title') or ''
    return ''


def _bucket_meta_map_path():
    return os.path.join(_profile_path(), 'bucket_meta_map.json')


def _stored_section_meta():
    try:
        with xbmcvfs.File(_bucket_meta_map_path(), 'r') as fh:
            data = fh.read()
        return json.loads(data) if data else {}
    except Exception:
        return {}


def section_meta_source(bucket):
    if not bucket:
        return ''
    return (_stored_section_meta() or {}).get(bucket, '')


_ACTIVE_BUCKET_TLS = threading.local()


def _note_section(bucket):
    _ACTIVE_BUCKET_TLS.bucket = bucket or ''


def _get_active_bucket():
    return getattr(_ACTIVE_BUCKET_TLS, 'bucket', '') or ''


def _free_key(first, taken):
    """first, else first-2, first-3... whichever is not taken."""
    key, number = first, 2
    while key in taken:
        key, number = '%s-%d' % (first, number), number + 1
    return key


def add_section():
    """A new home folder (its name typed; its key made unique)."""
    keyboard = xbmc.Keyboard('', tr('New home folder name'))
    keyboard.doModal()
    title = keyboard.getText().strip() if keyboard.isConfirmed() else ''
    if not title:
        return end_dir(content='files', cache=False)
    rows = _stored_own_sections()
    taken = set([r.get('bucket') for r in rows] + [r.get('bucket') for r in _standard_sections()])
    rows.append({'bucket': _free_key(_section_slug(title), taken), 'title': title, 'created': int(time.time())})
    _store_own_sections(rows)
    notify(tr('Home folder added'))
    _forget_quietly(lambda: xbmc.executebuiltin('Container.Refresh'))
    return end_dir(content='files', cache=False)


def add_sub_section(parent=''):
    """A new sub folder inside a Hub section (its name typed; its key made unique)."""
    parent = str(parent or '').strip()
    keyboard = None
    if parent:
        keyboard = xbmc.Keyboard('', tr('Sub folder name'))
        keyboard.doModal()
    title = keyboard.getText().strip() if keyboard is not None and keyboard.isConfirmed() else ''
    if not title:
        return end_dir(content='files', cache=False)
    rows = _stored_sub_sections()
    taken = set([r.get('bucket') for r in rows] + [r.get('bucket') for r in _home_sections(include_collection=False)])
    first = key = _sub_section_of(parent, title)
    number = 2
    while key in taken:
        key, number = '%s-%d' % (first, number), number + 1
    rows.append({'parent': parent, 'bucket': key, 'title': title, 'created': int(time.time())})
    _store_sub_sections(rows)
    notify(tr('Sub folder added'))
    _forget_quietly(lambda: xbmc.executebuiltin('Container.Refresh'))
    return end_dir(content='files', cache=False)


def remove_sub_section(bucket=''):
    bucket = str(bucket or '').strip()
    if not _is_sub_section(bucket):
        return end_dir(content='files', cache=False)
    _store_sub_sections([r for r in _stored_sub_sections() if (r.get('bucket') or '') != bucket])
    pins = [p for p in _stored_pins() if (p.get('bucket') or '') != bucket]
    _store_pins(pins)
    notify(tr('Sub folder removed'))
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    return end_dir(content='files', cache=False)


_SECTION_ORDER = {'movies': 0, 'series': 1, 'anime': 2, 'turkish': 4, 'korean': 5, 'live': 6, 'other': 9}


def _section_catalogs(bucket=None, provider_id=None):
    """(add-on, catalog, section) of every catalog (of one add-on / section), by section then name."""
    try:
        addons = [addon_registry.get_provider(provider_id)] if provider_id else addon_registry.list_providers()
    except Exception as exc:
        xbmc.log('[MegaNexus] _section_catalogs: list_providers failed: %s' % exc, xbmc.LOGWARNING)
        return []
    rows = []
    for addon in [a for a in addons if a]:
        try:
            catalogs = _addon_catalogs(addon) or []
        except Exception as exc:
            xbmc.log('[MegaNexus] _section_catalogs: provider_catalogs failed for %s: %s' % ((addon or {}).get('name') or '?',
                                                                                            exc), xbmc.LOGWARNING)
            continue
        for catalog in catalogs:
            if not isinstance(catalog, dict):
                continue
            try:
                section = _catalog_section(addon, catalog)
            except Exception:
                section = 'other'
            if not bucket or section == bucket:
                rows.append((addon, catalog, section))

    def order(row):
        try:
            addon, catalog, section = row
            name = '%s %s' % (catalog.get('name') or catalog.get('id') or '',
                              (addon.get('name') if isinstance(addon, dict) else None) or '')
            return (_SECTION_ORDER.get(section, 8), name.lower())
        except Exception:
            return (99, '')
    try:
        return sorted(rows, key=order)
    except Exception:
        return rows


def _words_of(*values):
    blob = _row_words(*values)
    return re.sub(r'[\W_]+', ' ', blob, flags=re.U).strip()


def _hub_pin_context(provider_id, catalog_id, media_type, bucket):
    return [
        ('Move up', 'RunPlugin(%s)' % build_url(action='catalog_pin_move', provider_id=provider_id, media_type=media_type, catalog_id=catalog_id, bucket=bucket, direction='up')),
        ('Move down', 'RunPlugin(%s)' % build_url(action='catalog_pin_move', provider_id=provider_id, media_type=media_type, catalog_id=catalog_id, bucket=bucket, direction='down')),
        ('Remove from this section', 'RunPlugin(%s)' % build_url(action='catalog_unpin', provider_id=provider_id, media_type=media_type, catalog_id=catalog_id, bucket=bucket)),
    ]


def _show_pinned(bucket):
    pins = [x for x in _stored_pins() if (x.get('bucket') or '') == bucket]
    for pin in pins:
        provider = addon_registry.get_provider(pin.get('provider_id') or '')
        if not provider:
            continue
        catalog_def = _catalog_entry_of(provider, pin.get('catalog_id') or '', pin.get('media_type') or '') or {}
        cname = pin.get('label') or catalog_def.get('name') or pin.get('catalog_id') or 'Catalog'
        media_type = pin.get('media_type') or catalog_def.get('type') or _section_media_type(bucket)
        pname = provider.get('name') or pin.get('provider_name') or 'Source'
        label = '📌 %s' % cname
        url = build_url(action='catalog_all', provider_id=provider.get('id'), media_type=media_type, catalog_id=pin.get('catalog_id'), label=cname)
        ctx = _add_folder_menu_entries(_hub_pin_context(provider.get('id') or '', pin.get('catalog_id') or '', media_type, bucket) + _catalog_menu_entries(provider, catalog_def or {'id': pin.get('catalog_id'), 'name': cname, 'type': media_type}, bucket), bucket)
        add_item(label, url, info={'title': label, 'plot': tr('Section pinned from %s') % pname}, art=catalog_art(cname, media_type, provider.get('manifest') or {}, catalog_def), context_menu=ctx)
    return len(pins)


def _row_menu_entries(provider, media_type, meta_id, item_label, source_mode=''):
    provider_id = (provider or {}).get('id') or ''
    return _source_choice_list(media_type=media_type, canonical_id=meta_id, title=item_label, source_provider_id=provider_id)


def _catalog_pins_path():
    return os.path.join(_profile_path(), 'hub_catalog_pins.json')


def _stored_pins():
    return _json_kept(_catalog_pins_path(), [])


def _store_pins(rows):
    _keep_json(_catalog_pins_path(), rows, [])


def _pin_ref(provider_id, catalog_id, media_type):
    return '%s|%s|%s' % (provider_id or '', catalog_id or '', media_type or '')


def _catalog_entry_of(provider, catalog_id, media_type=''):
    for c in _addon_catalogs(provider or {}):
        if str(c.get('id') or '') == str(catalog_id or '') and (not media_type or str(c.get('type') or '') == str(media_type or '')):
            return c
    for c in _addon_catalogs(provider or {}):
        if str(c.get('id') or '') == str(catalog_id or ''):
            return c
    return {}


def _catalog_menu_entries(provider, catalog, bucket=''):
    """'Add inside …' for every home folder and sub folder, then new sub / home folder."""
    pin = dict(provider_id=(provider or {}).get('id') or '',
               media_type=(catalog or {}).get('type') or _section_media_type(bucket) or '',
               catalog_id=(catalog or {}).get('id') or '')
    pin['label'] = (catalog or {}).get('name') or pin['catalog_id'] or 'Catalog'
    pin_url = lambda key: 'RunPlugin(%s)' % build_url(action='catalog_pin', **dict(pin, bucket=key))
    menu = []
    for section in _home_sections(include_collection=False):
        key = section.get('bucket') or ''
        title = section.get('title') or _hub_bucket_title(key)
        menu.append((tr('Add inside %s') % title, pin_url(key)))
        menu += [(tr('Add inside %s / %s') % (title, sub.get('title') or _hub_bucket_title(sub.get('bucket') or '')),
                  pin_url(sub.get('bucket') or '')) for sub in _sub_sections(key)]
    return menu + [('Add a new sub folder', 'RunPlugin(%s)' % build_url(action='home_subfolder_add', parent=bucket or 'movies')),
                   ('Add new home folder', 'RunPlugin(%s)' % build_url(action='home_folder_add'))]


def _pin_places():
    targets = []
    for row in _home_sections(include_collection=False):
        b = row.get('bucket') or ''
        title = row.get('title') or _hub_bucket_title(b)
        targets.append((title, b))
        for sub in _sub_sections(b):
            sb = sub.get('bucket') or ''
            st = sub.get('title') or _hub_bucket_title(sb)
            targets.append(('%s / %s' % (title, st), sb))
    return [(t, b) for t, b in targets if b and b != 'collection']


def pin_place_menu(provider_id='', catalog_id='', media_type='', label=''):
    targets = _pin_places()
    if not targets:
        notify(tr('Add a home folder or sub folder first'))
        return end_dir()
    idx = xbmcgui.Dialog().select(tr('Add catalog inside'), [tr(t[0]) for t in targets])
    if idx < 0:
        return end_dir()
    title, bucket = targets[idx]
    return pin_catalog(provider_id=provider_id, catalog_id=catalog_id, media_type=media_type, label=label, bucket=bucket)


def _catalog_filter_menu(provider_id='', media_type='', catalog_id='', catalog_def=None, force_remote='', return_action='', return_bucket=''):
    """'Catalog filter' in a catalog row's menu (naming the filters in use) when the catalog has filters."""
    provider_id, media_type, catalog_id = str(provider_id or ''), str(media_type or ''), str(catalog_id or '')
    if not provider_id or not catalog_id:
        return []
    try:
        if catalog_def is None:
            catalog_def = _catalog_entry_of(addon_registry.get_provider(provider_id) or {}, catalog_id, media_type) or {}
        names = [e.get('name') or '' for e in _filters_offered(catalog_def or {})
                 if _catalog_extra_kind(e.get('name') or '', catalog_def or {}) == 'filter']
        if not names:
            return []
        state = _filter_now(provider_id, catalog_id) or {}
        used = ['%s: %s' % (_filter_caption(name), state[name]) for name in names if name and state.get(name) not in (None, '')]
        label = 'Catalog filter' + ('  •  %s' % ' | '.join(used[:3]) if used else '')
        return [(label, 'Container.Update(%s)' % build_url(action='filters_menu', provider_id=provider_id,
                                                           media_type=media_type, catalog_id=catalog_id,
                                                           force_remote=force_remote or '', return_action=return_action or '',
                                                           return_bucket=return_bucket or ''))]
    except Exception:
        return []


def _catalog_tool_rows(provider, provider_id, media_type, catalog_id, catalog_def, label=''):
    try:
        _clean = (ADDON.getSetting('clean_catalog_view') or 'false').strip().lower() in ('true', '1', 'yes', 'on')
    except Exception:
        _clean = False
    if _clean:
        return
    cname = label or (catalog_def or {}).get('name') or catalog_id or 'Catalog'
    ctx = _catalog_menu_entries(provider, catalog_def or {'id': catalog_id, 'name': cname, 'type': media_type}, _catalog_section(provider, catalog_def or {}))
    add_item(
        '[COLOR yellow]+ Add this catalog to home[/COLOR]',
        build_url(action='catalog_pin_target_menu', provider_id=provider_id, media_type=media_type, catalog_id=catalog_id, label=cname),
        is_folder=False,
        info={'title': 'Add to home', 'plot': 'Pin this catalog inside Movies/Series/Anime or any sub folder. It is not added to a collection.'},
        art=root_art('add'),
        context_menu=ctx,
        properties={'SpecialSort': 'top'},
    )


def _folder_searchable(entries):
    try:
        return any(_searchable_catalog(catalog) for _provider, catalog, _b, _pin in (entries or []))
    except Exception:
        return False


def _folder_filter_label(bucket, entries):
    """'Folder filter' (naming the filters in use) when the section's catalogs have filters; '' else."""
    groups = _filter_groups(entries)
    if not groups:
        return ''
    labels = dict((g.get('key'), g.get('label')) for g in groups)
    used = ['%s: %s' % (labels.get(key) or _folder_filter_caption(key), value)
            for key, value in (_folder_filters_now(bucket) or {}).items() if value not in (None, '')]
    return 'Folder filter' + ('  •  %s' % ' | '.join(used) if used else '')


def _folder_menu_entries(bucket, entries=None):
    """A Hub section's menu: filter, search inside, merge / group, duplicates, quick play, refresh, order."""
    bucket = bucket or 'movies'
    try:
        entries = list(entries or _pinned_catalogs(bucket) or [])
    except Exception:
        entries = []
    menu = []
    try:
        label = _folder_filter_label(bucket, entries)
        if label:
            menu.append((label, 'Container.Update(%s)' % build_url(action='folder_filters_menu', bucket=bucket)))
    except Exception:
        pass
    if _folder_searchable(entries):
        menu.append((tr('Search inside %s') % _hub_bucket_title(bucket),
                     'Container.Update(%s)' % build_url(action='hub_search_folder', bucket=bucket)))
    toggles = (('Group by add-on' if _folder_layout(bucket) == 'merged' else 'Merge content', 'folder_toggle_view'),
               ('Show duplicates' if _folder_merges_duplicates(bucket) else 'Hide duplicates', 'folder_toggle_dedupe'),
               ('Quick play from the same add-on' if _folder_click_play(bucket) == 'normal' else 'Normal playback mode',
                'folder_toggle_play_mode'),
               ('Refresh this folder', 'folder_refresh'))
    menu += [(label, 'RunPlugin(%s)' % build_url(action=action, bucket=bucket)) for label, action in toggles]
    if entries:
        menu.append(('Order the add-ons in this folder',
                     'Container.Update(%s)' % build_url(action='hub_section', bucket=bucket, raw='1')))
    return menu


def _add_folder_menu_entries(ctx, bucket, entries=None):
    out = list(ctx or [])
    try:
        tools = _folder_menu_entries(bucket, entries=entries)
        if tools:
            out.extend(tools)
    except Exception:
        pass
    return out


def _folder_tool_rows(bucket, entries):
    return None


def _pin_filter_rows(bucket, entries):
    return _folder_tool_rows(bucket, entries)


def _folder_prefs_path():
    return os.path.join(_profile_path(), 'hub_folder_prefs.json')


def _stored_folder_choices():
    return _json_kept(_folder_prefs_path(), {})


def _store_folder_choices(data):
    _keep_json(_folder_prefs_path(), data, {})


def _folder_choice(bucket, key, default=None):
    prefs = _stored_folder_choices().get(str(bucket or ''), {})
    if not isinstance(prefs, dict):
        return default
    return prefs.get(key, default)


def _keep_folder_choice(bucket, key, value):
    data = _stored_folder_choices()
    bucket = str(bucket or '')
    current = dict(data.get(bucket, {}) if isinstance(data.get(bucket, {}), dict) else {})
    if value in (None, '', '__clear__'):
        current.pop(key, None)
    else:
        current[key] = value
    if current:
        data[bucket] = current
    else:
        data.pop(bucket, None)
    _store_folder_choices(data)
    return current


def _folder_layout(bucket):
    value = str(_folder_choice(bucket, 'view_mode', 'merged') or 'merged').strip().lower()
    return 'sources' if value in ('sources', 'source', 'by_source', 'by-source') else 'merged'


def _folder_merges_duplicates(bucket):
    value = str(_folder_choice(bucket, 'dedupe', '1') or '1').strip().lower()
    return value not in ('0', 'false', 'no', 'off')


def _folder_click_play(bucket):
    value = str(_folder_choice(bucket, 'play_mode', 'normal') or 'normal').strip().lower()
    return 'same_source_auto' if value in ('same_source_auto', 'same-source-auto', 'same', 'only') else 'normal'


def _say_and_refresh(message=''):
    if message:
        notify(message)
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    return end_dir()


def switch_folder_layout(bucket='movies'):
    current = _folder_layout(bucket)
    new_value = 'sources' if current == 'merged' else 'merged'
    _keep_folder_choice(bucket, 'view_mode', new_value)
    label = 'Group by add-on' if new_value == 'sources' else 'Merge content'
    return _say_and_refresh(tr('Folder view changed: %s') % label)


def switch_folder_merge(bucket='movies'):
    enabled = _folder_merges_duplicates(bucket)
    _keep_folder_choice(bucket, 'dedupe', '0' if enabled else '1')
    return _say_and_refresh(tr('Hide duplicates: %s') % (tr('Stopped') if enabled else tr('Enabled')))


def switch_folder_click(bucket='movies'):
    current = _folder_click_play(bucket)
    new_value = 'same_source_auto' if current == 'normal' else 'normal'
    _keep_folder_choice(bucket, 'play_mode', new_value)
    label = 'Quick play from the same add-on' if new_value == 'same_source_auto' else 'Normal mode'
    return _say_and_refresh(tr('Playback mode: %s') % label)


def refresh_folder(bucket='movies'):
    removed = 0
    try:
        from .meganexus import addon_wire as _client_mod
        removed += int(_client_mod.clear_http_cache() or 0)
    except Exception:
        pass
    try:
        _searches.clear()
    except Exception:
        pass
    try:
        _reset_folder_filters(bucket)
    except Exception:
        pass
    return _say_and_refresh('Folder refreshed and catalog cache cleared')


_TITLE_NOISE = re.compile(r'\[[^\]]+\]|\([^\)]*\b(?:\d{4}|1080p|720p|4k|uhd|hdr|dubbed|subbed)\b[^\)]*\)', re.I)


_TITLE_ARTICLES = re.compile(r'\b(?:the|a|an)\b', re.I)


def _title_for_matching(value):
    """A title reduced for comparing: lower case, accents apart, no [tags] / (year, quality), no articles, words only."""
    text = str(value or '').strip().lower()
    try:
        text = unicodedata.normalize('NFKD', text)
    except Exception:
        pass
    text = re.sub(r'[\W_]+', ' ', _TITLE_ARTICLES.sub(' ', _TITLE_NOISE.sub(' ', text)))
    return ' '.join(text.split())


def _year_of(meta):
    meta = meta or {}
    for key in ('year', 'releaseInfo', 'released', 'premiered'):
        value = meta.get(key)
        if value in (None, ''):
            continue
        m = re.search(r'(19|20)\d{2}', str(value))
        if m:
            return m.group(0)
    return ''


_ID_PREFIXES = (('imdb_id', 'imdb'), ('tmdb_id', 'tmdb'), ('tvdb_id', 'tvdb'))


def _meta_other_refs(media_type, meta_id, meta):
    """(the keys that make two catalog titles one: ids, IMDb in the id, title + year; the title
    alone when there is no year)."""
    meta = meta or {}
    kind = str(media_type or '').lower()
    ids = extract_ids(meta) or {}
    strong = ['%s:%s:%s' % (kind, short, str(ids.get(key) or '').strip().lower()) for key, short in _ID_PREFIXES
              if str(ids.get(key) or '').strip()]
    raw = str(meta_id or meta.get('id') or '').strip().lower()
    found = re.search(r'\btt\d{5,10}\b', raw)
    if found and '%s:imdb:%s' % (kind, found.group(0)) not in strong:
        strong.append('%s:imdb:%s' % (kind, found.group(0)))
    title, year = _title_for_matching(meta.get('name') or meta.get('title') or meta_id), _year_of(meta)
    if title and year:
        strong.append('%s:title:%s:%s' % (kind, title, year))
    weak = '%s:title:%s' % (kind, title) if title and not year else None
    if not strong and not weak:
        strong.append('%s:id:%s' % (kind, raw))
    return strong, weak


class _Linked(object):
    """Keys joined into groups: join(a, b) puts both in one group, head(k) names k's group."""

    def __init__(self):
        self.up = {}

    def head(self, key):
        path = []
        while self.up.get(key, key) != key:
            path.append(key)
            key = self.up[key]
        for step in path:
            self.up[step] = key
        return key

    def join(self, first, other):
        a, b = self.head(first), self.head(other)
        if a != b:
            self.up[b] = a


def _drop_duplicate_rows(rows, rank_of, keys_of):
    """One row per title: rows sharing an id key are one title; a row with only a title key joins
    the single title group of that name (else stands alone). The best ranked row of each is kept."""
    links, keyed, titled = _Linked(), [], []
    for row in rows:
        strong, weak = keys_of(row)
        if not strong:
            titled.append((row, weak))
            continue
        for key in strong:
            links.up.setdefault(key, key)
        for key in strong[1:]:
            links.join(strong[0], key)
        keyed.append((row, strong))
    groups, by_title = {}, {}
    for row, strong in keyed:
        groups.setdefault(links.head(strong[0]), []).append(row)
    for row, strong in keyed:
        for key in strong:
            if ':title:' in key:
                by_title.setdefault(key.rsplit(':', 1)[0], set()).add(links.head(strong[0]))
    for row, weak in titled:
        owners = by_title.get(weak) if weak else None
        if owners and len(owners) == 1:
            groups[next(iter(owners))].append(row)
        else:
            groups[weak or id(row)] = [row]
    return [min(members, key=rank_of) for members in groups.values()]


def _meta_ref(media_type, meta_id, meta):
    """One key per catalog title: its first id, an IMDb id in its id, its own tmdb/tvdb/imdb id, title + year, the id."""
    meta = meta or {}
    kind = str(media_type or '').lower()
    ids = extract_ids(meta) or {}
    for key, short in _ID_PREFIXES:
        value = str(ids.get(key) or '').strip().lower()
        if value:
            return '%s:%s:%s' % (kind, short, value)
    raw = str(meta_id or meta.get('id') or '').strip().lower()
    found = re.search(r'\btt\d{5,10}\b', raw)
    if found:
        return '%s:imdb:%s' % (kind, found.group(0))
    if raw.startswith(('tmdb:', 'tvdb:', 'imdb:')):
        return '%s:%s' % (kind, raw)
    title = _title_for_matching(meta.get('name') or meta.get('title') or meta_id)
    return '%s:title:%s:%s' % (kind, title, _year_of(meta)) if title else '%s:id:%s' % (kind, raw)


def _date_stamp(year, month, day):
    return time.mktime((year, month, day, 0, 0, 0, 0, 0, -1))


def _time_of(value, prefer_day_first=True):
    """Seconds since 1970 for a date in a listing (a stamp, 2024-05-01, 01.05.2024, 01.05 this
    year or a bare year); 0.0 when there is none."""
    if value in (None, ''):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value) if float(value) > 100000 else 0.0
    text = str(value or '').strip()
    found = re.search(r'((?:19|20)\d{2})[-/.](\d{1,2})[-/.](\d{1,2})', text)
    if found:
        try:
            return _date_stamp(int(found.group(1)), int(found.group(2)), int(found.group(3)))
        except Exception:
            pass
    for pattern in (r'\b(\d{1,2})[-/.](\d{1,2})[-/.]((?:19|20)\d{2})\b', r'\b(\d{1,2})[-/.](\d{1,2})\b'):
        found = re.search(pattern, text)
        if not found:
            continue
        a, b = int(found.group(1)), int(found.group(2))
        day, month = (a, b) if prefer_day_first or a > 12 else (b, a)
        try:
            year = int(found.group(3)) if found.lastindex == 3 else int(time.localtime().tm_year)
            return _date_stamp(year, month, day)
        except Exception:
            pass
    found = re.search(r'\b((?:19|20)\d{2})\b', text)
    if found:
        try:
            return _date_stamp(int(found.group(1)), 1, 1)
        except Exception:
            return float(int(found.group(1)))
    return 0.0


def _first_time(meta, fields, hint_fields):
    """The first readable date among the meta's fields (then its behaviorHints'); 0.0 when none."""
    meta = meta or {}
    hints = meta.get('behaviorHints') if isinstance(meta.get('behaviorHints'), dict) else {}
    for value in [meta.get(f) for f in fields] + [hints.get(f) for f in hint_fields]:
        stamp = _time_of(value)
        if stamp:
            return stamp
    return 0.0


def _release_time(meta):
    return _first_time(meta, ('released', 'releaseDate', 'release_date', 'premiered', 'firstAired', 'aired', 'date',
                              'releaseInfo', 'year'), ('released', 'releaseDate', 'release_date', 'date'))


def _added_time(meta):
    return _first_time(meta, ('added', 'dateAdded', 'date_added', 'createdAt', 'created_at', 'updatedAt', 'updated_at',
                              'modifiedAt', 'modified_at', 'lastAdded', 'last_added'),
                       ('dateAdded', 'added', 'createdAt', 'updatedAt'))


def _rating_of(meta):
    meta = meta or {}
    for key in ('imdbRating', 'rating', 'voteAverage', 'score'):
        value = meta.get(key)
        try:
            if value not in (None, ''):
                return float(str(value).replace(',', '.'))
        except Exception:
            continue
    return 0.0


_FOLDER_ORDER_WORDS = (('release_desc', ('lastrelease', 'latestrelease', 'releasedate', 'released', 'release')),
                       ('added_desc', ('lastadded', 'recentlyadded', 'dateadded', 'added')),
                       ('title_asc', ('atoz', 'az', 'titleasc', 'alphabetical')), ('title_desc', ('ztoa', 'za', 'titledesc')),
                       ('rating_desc', ('toprated', 'rating', 'imdb', 'score')))


def _folder_sorting(bucket):
    """The order a section's filters ask for ('rank_mix' = each catalog's own order, interleaved)."""
    words = [_filter_word(part) for pair in (_folder_filters_now(bucket) or {}).items() for part in pair]
    joined = ''.join(w for w in words if w).replace(' ', '').replace('-', '').replace('_', '')
    return next((order for order, marks in _FOLDER_ORDER_WORDS if any(m in joined for m in marks)), 'rank_mix')


def _sort_folder_rows(rows, bucket):
    """A section's rows in its chosen order (newest release / newest added / title / rating; else
    each catalog's own order, interleaved)."""
    mode = _folder_sorting(bucket)
    newest = {'release_desc': _release_time, 'added_desc': _added_time, 'rating_desc': _rating_of}

    def order(row):
        _addon, _catalog, _kind, meta_id, meta, catalog_spot, own_spot = row
        catalog_spot, own_spot = int(catalog_spot or 0), int(own_spot or 0)
        title = _title_for_matching((meta or {}).get('name') or (meta or {}).get('title') or meta_id)
        if mode in newest:
            value = newest[mode](meta)
            return (0 if value else 1, -float(value or 0.0), catalog_spot, own_spot, title)
        if mode == 'title_asc':
            return (title, catalog_spot, own_spot)
        if mode == 'title_desc':
            return (''.join(chr(0x10FFFF - ord(ch)) for ch in title[:80]), catalog_spot, own_spot)
        return (own_spot, catalog_spot, title)
    try:
        return sorted(rows or [], key=order)
    except Exception:
        return list(rows or [])


def _folder_filters_path():
    return os.path.join(_profile_path(), 'hub_folder_filters.json')


def _stored_folder_filters():
    return _json_kept(_folder_filters_path(), {})


def _store_folder_filters(data):
    _keep_json(_folder_filters_path(), data, {})


def _folder_filters_now(bucket):
    state = _stored_folder_filters().get(str(bucket or ''), {})
    return dict(state) if isinstance(state, dict) else {}


def _keep_folder_filter(bucket, filter_key, value):
    data = _stored_folder_filters()
    bucket = str(bucket or '')
    current = dict(data.get(bucket, {}) if isinstance(data.get(bucket, {}), dict) else {})
    if value in (None, '', '__clear__'):
        current.pop(filter_key, None)
    else:
        current[filter_key] = value
    if current:
        data[bucket] = current
    else:
        data.pop(bucket, None)
    _store_folder_filters(data)
    return current


def _reset_folder_filters(bucket):
    data = _stored_folder_filters()
    data.pop(str(bucket or ''), None)
    _store_folder_filters(data)


def _filter_word(value):
    text = str(value or '').strip().lower()
    text = text.replace('_', ' ').replace('-', ' ')
    text = re.sub(r'\s+', ' ', text).strip()
    return text


_FILTER_KINDS = (('sort', ('sortby', 'orderby')), ('lastrelease', ('lastrelease', 'latestrelease', 'releasedate', 'released',
                                                                    'release')),
                 ('lastadded', ('lastadded', 'recentlyadded', 'added', 'dateadded')), ('contentrating', ('contentrating', 'rating')))


def _folder_filter_ref(name):
    """The kind of a catalog filter (sort, lastrelease, lastadded, contentrating or its own word)."""
    word = _filter_word(name)
    joined = word.replace(' ', '')
    return next((kind for kind, words in _FILTER_KINDS if joined in words), joined or word)


_FILTER_CAPTIONS = {'sort': 'Sort', 'order': 'Order', 'lastrelease': 'Last Release', 'lastadded': 'Last Added', 'genre': 'Genre',
                    'year': 'Year', 'language': 'Language', 'country': 'Country', 'network': 'Network', 'studio': 'Studio',
                    'collection': 'Collection', 'availability': 'Availability', 'contentrating': 'Rating',
                    'unwatched': 'Unwatched', 'category': 'Category', 'type': 'Type'}


def _folder_filter_caption(filter_key, sample_name=''):
    return _FILTER_CAPTIONS.get(filter_key) or _filter_caption(sample_name or filter_key)


def _filter_skips(name):
    return _folder_filter_ref(name) in ('skip', 'search', 'limit')


def _option_word(value):
    text = _filter_word(value)
    text = text.replace('_', ' ')
    return re.sub(r'\s+', ' ', text).strip()


_FILTER_ORDER = {'sort': 0, 'order': 1, 'lastrelease': 2, 'lastadded': 3, 'genre': 4, 'year': 5, 'language': 6, 'country': 7}


def _filter_groups(entries):
    """The section's catalog filters merged by kind (genre, year...): each kind's options once and
    the catalogs it applies to; sort / order first."""
    groups = {}
    for addon, catalog, _bucket, pin in entries or []:
        addon_id = (addon or {}).get('id') or ''
        catalog_id = (catalog or {}).get('id') or (pin or {}).get('catalog_id') or ''
        if not addon_id or not catalog_id:
            continue
        kind = (catalog or {}).get('type') or (pin or {}).get('media_type') or ''
        for extra in _filters_offered(catalog or {}):
            name = extra.get('name') or '' if isinstance(extra, dict) else ''
            if not name or _filter_skips(name):
                continue
            key = _folder_filter_ref(name)
            group = groups.setdefault(key, {'key': key, 'label': _folder_filter_caption(key, name), 'sample_name': name,
                                            'options': [], 'option_map': {}, 'targets': []})
            options = [str(x) for x in extra.get('options') or [] if x not in (None, '')]
            for option in options:
                word = _option_word(option)
                if word and word not in group['option_map']:
                    group['option_map'][word] = option
                    group['options'].append(option)
            group['targets'].append({'provider_id': addon_id, 'catalog_id': catalog_id, 'media_type': kind, 'name': name,
                                     'options': options})
    return sorted(groups.values(), key=lambda g: (_FILTER_ORDER.get(g.get('key'), 50), str(g.get('label') or '').lower()))


def _filter_groups_by_name(entries):
    return {g.get('key'): g for g in _filter_groups(entries)}


def _folder_extra_for(bucket, provider_id, catalog_id, catalog_def):
    state = _folder_filters_now(bucket)
    if not state:
        return {}
    extra_out = {}
    for extra in _filters_offered(catalog_def or {}):
        if not isinstance(extra, dict):
            continue
        name = extra.get('name') or ''
        if not name or _filter_skips(name):
            continue
        key = _folder_filter_ref(name)
        value = state.get(key)
        if value in (None, ''):
            continue
        opts = [str(x) for x in (extra.get('options') or []) if x not in (None, '')]
        if opts:
            want = _option_word(value)
            match = None
            for opt in opts:
                if _option_word(opt) == want:
                    match = opt
                    break
            if match is None:
                continue
            extra_out[name] = match
        else:
            extra_out[name] = value
    return extra_out


def folder_filter_menu(bucket='movies'):
    bucket = bucket or 'movies'
    entries = _pinned_catalogs(bucket)
    groups = _filter_groups(entries)
    if not groups:
        notify(tr('No filters available in this folder'))
        return section_rows(bucket)
    state = _folder_filters_now(bucket)
    labels = []
    actions = []
    for group in groups:
        key = group.get('key') or ''
        if not key:
            continue
        current = state.get(key)
        suffix = ('  •  %s' % current) if current not in (None, '') else ''
        labels.append('%s%s' % (group.get('label') or _folder_filter_caption(key), suffix))
        actions.append(('set', key))
    if state:
        labels.append('Clear all folder filters')
        actions.append(('clear', ''))
    idx = xbmcgui.Dialog().select(tr('Folder filter: %s') % tr(_hub_bucket_title(bucket)), [tr(x) for x in labels])
    if idx < 0:
        return section_rows(bucket)
    action, key = actions[idx]
    if action == 'clear':
        _reset_folder_filters(bucket)
        return section_rows(bucket)
    return pick_folder_filter(bucket=bucket, filter_key=key)


def pick_folder_filter(bucket='movies', filter_key=''):
    bucket = bucket or 'movies'
    filter_key = str(filter_key or '')
    entries = _pinned_catalogs(bucket)
    group = _filter_groups_by_name(entries).get(filter_key)
    if not group:
        return section_rows(bucket)
    options = list(group.get('options') or [])
    title = group.get('label') or _folder_filter_caption(filter_key)
    if options:
        labels = ['Clear filter'] + options
        idx = xbmcgui.Dialog().select(tr('Choose %s') % tr(title), [tr(x) for x in labels])
        if idx < 0:
            return section_rows(bucket)
        if idx == 0:
            _keep_folder_filter(bucket, filter_key, '__clear__')
        else:
            _keep_folder_filter(bucket, filter_key, labels[idx])
    else:
        default = _folder_filters_now(bucket).get(filter_key, '')
        kb = xbmc.Keyboard(default, tr('Type %s') % tr(title))
        kb.doModal()
        if not kb.isConfirmed():
            return section_rows(bucket)
        value = kb.getText().strip()
        _keep_folder_filter(bucket, filter_key, value or '__clear__')
    return section_rows(bucket)

def pin_catalog(provider_id='', catalog_id='', media_type='', label='', bucket=''):
    """Pin an add-on catalog into a Hub section (never into Collection; never twice)."""
    if not provider_id or not catalog_id or not bucket:
        return end_dir()
    if str(bucket or '').strip().lower() == 'collection':
        notify(tr('Collection is for Favorites and lists only. Pick a home folder or sub folder.'))
        return end_dir()
    pins = _stored_pins()
    ref = _pin_ref(provider_id, catalog_id, media_type)
    if any(_pin_ref(p.get('provider_id'), p.get('catalog_id'), p.get('media_type')) == ref and (p.get('bucket') or '') == bucket
           for p in pins):
        notify(tr('Section already exists'))
        return end_dir()
    pins.append({'provider_id': provider_id, 'provider_name': (addon_registry.get_provider(provider_id) or {}).get('name') or '',
                 'catalog_id': catalog_id, 'media_type': media_type, 'label': label or catalog_id, 'bucket': bucket,
                 'created': int(time.time())})
    _store_pins(pins)
    notify(tr('Section added'))
    _forget_quietly(lambda: xbmc.executebuiltin('Container.Refresh'))
    return end_dir()


def _is_same_pin(row, provider_id='', catalog_id='', media_type='', bucket=''):
    if _pin_ref(row.get('provider_id'), row.get('catalog_id'), row.get('media_type')) != _pin_ref(provider_id, catalog_id, media_type):
        return False
    if bucket and (row.get('bucket') or '') != bucket:
        return False
    return True


def unpin_catalog(provider_id='', catalog_id='', media_type='', bucket=''):
    rows = _stored_pins()
    new_rows = [r for r in rows if not _is_same_pin(r, provider_id, catalog_id, media_type, bucket)]
    _store_pins(new_rows)
    try:
        from . import catalog_index as index_render
        index_render.get_db().forget_catalog(provider_id, catalog_id, bucket=bucket or None)
    except Exception as _exc:
        xbmc.log('[MegaNexus] purge_catalog failed: %s' % _exc, xbmc.LOGWARNING)
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    return end_dir()


def _hub_bucket_pins(bucket):
    return [x for x in _stored_pins() if (x.get('bucket') or '') == bucket]


def _pinned_catalogs(bucket):
    rows = []
    for pin in _hub_bucket_pins(bucket):
        provider = addon_registry.get_provider(pin.get('provider_id') or '')
        if not provider:
            continue
        catalog_def = _catalog_entry_of(provider, pin.get('catalog_id') or '', pin.get('media_type') or '') or {}
        if not catalog_def:
            continue
        rows.append((provider, catalog_def, _catalog_section(provider, catalog_def), pin))
    return rows


_LAZY_FROM = 12


def _add_media_row(bucket, place, row, favorites):
    addon, catalog, kind, meta_id, meta = row
    name = (meta or {}).get('name') or meta_id
    addon_id = (addon or {}).get('id') or ''
    try:
        _meta_keep(kind, meta_id, meta, source_provider_id=addon_id)
    except Exception:
        pass
    art = _meta_pictures(addon, kind, meta, fallback_art=_fallback_pictures(addon, kind, catalog, name), lazy=place >= _LAZY_FROM)
    ids = extract_ids(meta)
    only = 'only' if _folder_click_play(bucket) == 'same_source_auto' and not is_show(kind) else ''
    path, is_folder = _item_click_url(media_type=kind, canonical_id=meta_id, title=name, tmdb_id=ids.get('tmdb_id') or '',
                                      imdb_id=ids.get('imdb_id') or '', tvdb_id=ids.get('tvdb_id') or '',
                                      source_provider_id=addon_id, source_mode=only, force_meganexus=bool(only), ui_seed=art)
    info = _info_of(meta)
    menu = _add_folder_menu_entries(_row_menu_entries(addon, kind, meta_id, name), bucket)
    favorite = (str(kind or ''), str(meta_id or '')) in favorites
    if favorite:
        menu.append(('Remove from favorites', 'RunPlugin(%s)' % build_url(action='fav_remove', media_type=kind,
                                                                         canonical_id=meta_id)))
    else:
        menu.append(('Add to favorites', 'RunPlugin(%s)' % build_url(
            action='fav_add', media_type=kind, canonical_id=meta_id, title=name, poster=art.get('poster') or '',
            background=art.get('fanart') or '', clearlogo=art.get('clearlogo') or '', year=str(info.get('year') or 0))))
    add_item(name, path, is_folder=is_folder, info=info, art=art, ids=ids, context_menu=menu, is_favorite=favorite)
    return art.get('fanart') or ''


def _show_media_rows(ordered_rows, bucket='', page_num=0, has_more=False):
    """A Hub section's titles (each catalog title as a row; the first backdrop for the background)."""
    if not ordered_rows:
        return False
    try:
        xbmcgui.Window(WINDOW_ID).setProperty('meganexus.render_bucket', str(bucket or ''))
    except Exception:
        pass
    try:
        favorites = library_titles.favorite_keys()
    except Exception:
        favorites = set()
    backdrop = ''
    for place, row in enumerate(ordered_rows):
        fanart = _add_media_row(bucket, place, row, favorites)
        backdrop = backdrop or fanart
    if backdrop:
        try:
            xbmcgui.Window(WINDOW_ID).setProperty('fanart', backdrop)
        except Exception:
            pass
    if has_more and not _no_pages():
        add_item(tr('More'), build_url(action='hub_section', bucket=bucket, page=str(page_num + 1)), art=root_art('catalogs'),
                 info={'title': tr('More')})
    return True


_SECTION_WAIT = 3.5          # a section shows what came within this many seconds


def _add_sub_section_rows(bucket, title, subs):
    pins = _stored_pins()
    for sub in subs:
        key = sub.get('bucket') or ''
        name = sub.get('title') or _hub_bucket_title(key)
        count = sum(1 for pin in pins if (pin.get('bucket') or '') == key)
        menu = _add_folder_menu_entries([
            ('Delete sub folder', 'RunPlugin(%s)' % build_url(action='home_subfolder_remove', bucket=key)),
            ('Show the add-ons in this sub folder', 'Container.Update(%s)' % build_url(action='hub_section', bucket=key,
                                                                                       raw='1'))], key)
        add_item('%s (%d)' % (name, count) if count else name, build_url(action='hub_section', bucket=key),
                 art=_section_icon(key), info={'title': name, 'plot': tr('Sub folder inside %s') % title}, context_menu=menu)


def _add_new_sub_section_row(bucket):
    if not _is_sub_section(bucket):
        add_item(tr('+ Add sub folder'), build_url(action='home_subfolder_add', parent=bucket), art=root_art('add'),
                 info={'title': tr('Add sub folder')})


def _empty_section(bucket, title, entries):
    add_item(tr("[COLOR yellow]Pick this folder's content from Sources[/COLOR]"), build_url(action='providers'),
             art=root_art('providers'), context_menu=_folder_menu_entries(bucket, entries),
             info={'title': title, 'plot': tr('Open Add-ons, long-press any catalog, then choose "Add into %s". Content '
                                              'will appear here directly without folders.') % title})
    add_item(tr('All matching add-on catalogs'), build_url(action='hub_section', bucket=bucket, raw='1'),
             art=root_art('catalogs'),
             info={'title': tr('All add-on catalogs'), 'plot': tr('Pick the catalogs you want to pin inside this folder from here')})
    _add_new_sub_section_row(bucket)
    add_item(tr('+ Add new home folder'), build_url(action='home_folder_add'), art=root_art('add'),
             info={'title': tr('Add new home folder')})
    return end_dir(content='files', cache=False)


class _SectionHarvest(object):
    """The section's pinned catalogs asked at once: rows (with their catalog's and own place),
    unreachable catalogs, how many answered and whether time ran out."""

    def __init__(self, bucket, entries, limit):
        self.rows, self.failed, self.answered, self.late, self.more = [], [], 0, False, False
        place = dict((id(job), spot) for spot, job in enumerate(entries))
        deadline = time.time() + _SECTION_WAIT
        ask = lambda job: self._ask(bucket, job, limit)
        for job, answer in each_parallel(ask, entries, workers=max(1, min(parallel_workers(), 4, len(entries))),
                                         timeout=_SECTION_WAIT):
            if time.time() > deadline:
                self.late = True
                xbmc.log('[MegaNexus] hub_section folder budget exceeded — rendering partial set', xbmc.LOGINFO)
                break
            self.take(bucket, job, answer, place.get(id(job), len(self.rows)), limit)

    @staticmethod
    def _ask(bucket, job, limit):
        addon, catalog = job[0], job[1]
        addon_id, catalog_id = (addon or {}).get('id') or '', (catalog or {}).get('id') or ''
        extra = dict(_folder_extra_for(bucket, addon_id, catalog_id, catalog) or {}, limit=str(limit))
        return fetch_catalog(addon, catalog.get('type') or _section_media_type(bucket) or 'movie', catalog_id, extra=extra,
                             timeout_override=fast_timeout('catalog'))

    def take(self, bucket, job, answer, spot, limit):
        addon, catalog = job[0], job[1]
        self.answered += 1
        if isinstance(answer, Exception):
            self.failed.append(addon)
            return
        metas = (answer or {}).get('metas') or []
        self.more = self.more or len(metas) >= limit
        kind = catalog.get('type') or _section_media_type(bucket) or 'movie'
        for own_spot, meta in enumerate(metas):
            meta_id = str((meta or {}).get('id') or '')
            if meta_id:
                self.rows.append((addon, catalog, kind, meta_id, meta, spot, own_spot))


def _warn_unreachable_once(addons):
    """One notice per session for the first add-on that could not be reached."""
    try:
        home = xbmcgui.Window(WINDOW_ID)
        for addon in addons[:1]:
            name = (addon or {}).get('name') or 'source'
            key = 'meganexus.fail_warn.%s' % ((addon or {}).get('id') or name)
            if home.getProperty(key) != '1':
                home.setProperty(key, '1')
                xbmcgui.Dialog().notification('MegaNexus', tr('Could not reach %s — skipped') % name,
                                              xbmcgui.NOTIFICATION_WARNING, 2200, sound=False)
    except Exception:
        pass


def _section_came_back_empty(bucket, title, entries, harvest, page):
    missing = max(0, len(entries) - harvest.answered)
    if harvest.late or missing or harvest.failed:
        label = tr('%d of %d add-ons timed out — press to retry') % (max(missing, len(harvest.failed)), len(entries))
        plot = tr('Some add-ons did not respond within %d seconds. Try again, or open "Add-on diagnostics" to see which '
                  'one is slow.') % int(_SECTION_WAIT)
    else:
        label = '[COLOR yellow]%s[/COLOR]' % tr('No content available from the pinned add-ons')
        plot = tr('The add-on may be empty or may not support this page. Try pinning another catalog from Add-ons.')
    add_item('[COLOR cyan]↻ %s[/COLOR]' % label, build_url(action='hub_section', bucket=bucket, page=str(page)),
             art=root_art('catalogs'), info={'title': title, 'plot': plot}, context_menu=_folder_menu_entries(bucket, entries))
    if harvest.late or harvest.failed:
        add_item('[COLOR cyan]🩺 %s[/COLOR]' % tr('Add-on diagnostics'), build_url(action='diagnose_sources'),
                 art=root_art('catalogs'),
                 info={'title': tr('Add-on diagnostics'),
                       'plot': tr('Test the response time of every pinned add-on to find the slow one')})
    add_item(tr('All matching add-on catalogs'), build_url(action='hub_section', bucket=bucket, raw='1'),
             art=root_art('catalogs'), info={'title': 'All add-on catalogs'})
    _add_new_sub_section_row(bucket)
    return end_dir(content='files', cache=False)


def _section_rows_now(bucket='movies', page='0'):
    """A Hub section: its sub sections, then the titles of its pinned catalogs (from the index
    when it is on, else asked live), or the add-ons themselves in 'sources' layout."""
    bucket = bucket or 'movies'
    title = _hub_bucket_title(bucket)
    entries, subs = _pinned_catalogs(bucket), _sub_sections(bucket)
    if not entries and not subs:
        return _empty_section(bucket, title, entries)
    _pin_filter_rows(bucket, entries)
    if subs:
        _add_sub_section_rows(bucket, title, subs)
    if entries and _folder_layout(bucket) == 'sources':
        _show_pinned(bucket)
        return end_dir(content='files', cache=False)
    if not entries:
        add_item(tr('All matching add-on catalogs'), build_url(action='hub_section', bucket=bucket, raw='1'),
                 art=root_art('catalogs'), info={'title': tr('All add-on catalogs')})
        return end_dir(content='files', cache=False)
    try:
        page = max(0, int(page or 0))
    except Exception:
        page = 0
    size = _listing_page_size()
    limit = max(size, min(80, size * (page + 1)))
    if _index_mode_active():
        try:
            indexed = _show_from_index(bucket, page, size, limit, entries)
            if indexed is not None:
                _show_media_rows(indexed[:size], bucket=bucket, page_num=page, has_more=len(indexed) >= size)
                return end_dir(content=_section_content(bucket), cache=True)
        except Exception as exc:
            xbmc.log('[MegaNexus] index render failed, falling back to live: %s' % exc, xbmc.LOGWARNING)
    harvest = _SectionHarvest(bucket, entries, limit)
    if harvest.failed:
        _warn_unreachable_once(harvest.failed)
    rows = harvest.rows
    if _folder_merges_duplicates(bucket):
        rows = _drop_duplicate_rows(rows, rank_of=lambda row: (row[5], row[6]),
                                    keys_of=lambda row: _meta_other_refs(row[2], row[3], row[4]))
    rows = _sort_folder_rows(rows, bucket)
    shown = [row[:5] for row in rows[page * size:(page + 1) * size]]
    if not shown:
        return _section_came_back_empty(bucket, title, entries, harvest, page)
    _show_media_rows(shown, bucket=bucket, page_num=page, has_more=harvest.more or len(rows) > (page + 1) * size)
    return end_dir(content=_section_content(bucket), cache=True)




def section_rows(bucket='movies', raw='', page='0'):
    """A Hub section; with raw=1 every add-on catalog that fits it (to pin from)."""
    bucket = bucket or 'movies'
    _note_section(bucket)
    if raw != '1':
        return _section_rows_now(bucket=bucket, page=page)
    rows = _section_catalogs(bucket=_section_of_catalog(bucket))
    if not rows and (str(bucket or '').startswith('custom:') or _is_sub_section(bucket)):
        rows = _section_catalogs(bucket=None)
    if not rows:
        add_item(tr('[COLOR yellow]No catalogs in this section[/COLOR]'), build_url(action='providers'),
                 art=root_art('providers'), info={'title': 'Sources'})
        return end_dir(content='files', cache=False)
    for addon, catalog, _section in rows:
        kind = catalog.get('type') or _section_media_type(bucket) or ''
        name, addon_name = catalog.get('name') or catalog.get('id') or 'Catalog', addon.get('name') or 'Source'
        menu = (_catalog_menu_entries(addon, catalog, bucket)
                + _catalog_filter_menu(provider_id=addon.get('id') or '', media_type=kind, catalog_id=catalog.get('id') or '',
                                       catalog_def=catalog))
        add_item('%s  •  %s' % (name, addon_name),
                 build_url(action='catalog_all', provider_id=addon.get('id'), media_type=kind, catalog_id=catalog.get('id'),
                           label=name),
                 art=catalog_art(name, kind, addon.get('manifest') or {}, catalog), info={'title': name, 'plot': addon_name},
                 context_menu=menu)
    return end_dir(content='files', cache=True)

def move_pin(provider_id='', catalog_id='', media_type='', bucket='', direction='up'):
    """Move a pinned catalog one place up / down among its section's pins."""
    pins = _stored_pins()
    at = next((place for place, pin in enumerate(pins) if _is_same_pin(pin, provider_id, catalog_id, media_type, bucket)), None)
    if at is None:
        return end_dir()
    bucket = bucket or pins[at].get('bucket') or ''
    places = range(at - 1, -1, -1) if direction == 'up' else range(at + 1, len(pins))
    other = next((place for place in places if (pins[place].get('bucket') or '') == bucket), None)
    if other is not None:
        pins[other], pins[at] = pins[at], pins[other]
        _store_pins(pins)
    _forget_quietly(lambda: xbmc.executebuiltin('Container.Refresh'))
    return end_dir()

def search_menu(query=''):
    """Search everything (every add-on, the media servers and TMDb) for a typed query."""
    _set_render_section('search')
    _forget_source_scan_props(clear_global=True)
    home = xbmcgui.Window(WINDOW_ID)
    query = str(query or '').strip()
    if not query:
        keyboard = xbmc.Keyboard(home.getProperty('meganexus.last_search.unified') or '', tr('Search TMDb'))
        keyboard.doModal()
        query = keyboard.getText().strip() if keyboard.isConfirmed() else ''
    if not query:
        return end_dir(content='files', cache=False)
    home.setProperty('meganexus.last_search.unified', query)
    try:
        from .finding import recall as _queries
        _queries.note_query(query, media_type='all')
    except Exception:
        pass
    return _show_search_results(query, addon_registry.list_providers(), include_tmdb=True)


_PLEX_DOWN = 'meganexus.plex.down_until'


def _plex_down_for(seconds):
    _forget_quietly(lambda: xbmcgui.Window(10000).setProperty(_PLEX_DOWN, str(time.time() + seconds) if seconds else ''))


def _plex_servers_quick(budget_seconds=6.0, down_memo_seconds=90.0):
    """The Plex servers within a time limit (asked in a thread); after a failure Plex rests for a while."""
    try:
        resting = float(xbmcgui.Window(10000).getProperty(_PLEX_DOWN) or 0.0) - time.time()
    except Exception:
        resting = 0.0
    if resting > 0:
        xbmc.log('[MegaNexus] Plex Native targets skipped: marked down for %.0fs more' % resting, xbmc.LOGINFO)
        return []
    answer = {}

    def ask():
        try:
            answer['servers'] = _plex.servers() or _plex.servers(force=True) or []
        except Exception as exc:
            answer['exc'] = exc
    try:
        worker = threading.Thread(target=ask, name='MegaNexusPlexServers', daemon=True)
        worker.start()
    except RuntimeError as exc:
        xbmc.log('[MegaNexus] Plex discovery worker unavailable: %s' % exc, xbmc.LOGWARNING)
        _plex_down_for(down_memo_seconds)
        return []
    worker.join(budget_seconds)
    if worker.is_alive() or answer.get('exc'):
        xbmc.log('[MegaNexus] Plex Native target discovery failed: %s' % (answer.get('exc') or 'no reply within %.0fs'
                                                                         % budget_seconds), xbmc.LOGWARNING)
        _plex_down_for(down_memo_seconds)
        return []
    _plex_down_for(0)
    return answer.get('servers') or []


SERVER_BACKENDS = ('plex', 'emby')


def _server_addon(backend, server):
    """A media server dressed as an add-on with a search catalog per type (so search can ask it)."""
    name = '%s • %s' % ('Plex' if backend == 'plex' else 'Emby', server.get('name') or 'Server')
    own = server.get('id') or ''
    return {'id': '%s:%s' % (backend, own), 'name': name, 'backend': backend, 'server': server,
            'manifest': {'id': 'meganexus.%s.%s' % (backend, own), 'name': name, 'types': ['movie', 'series'],
                         'catalogs': [{'id': '%s_search' % backend, 'type': kind, 'name': name,
                                       'extra': [{'name': 'search', 'isRequired': True}]} for kind in ('movie', 'series')]}}


def _server_addons():
    providers = []
    try:
        if _plex.is_signed_in():
            for server in _plex.servers():
                providers.append(_server_addon('plex', server))
    except Exception:
        pass
    try:
        if _emby.is_signed_in():
            for server in _emby.servers():
                providers.append(_server_addon('emby', server))
    except Exception:
        pass
    return providers


def _server_item_pictures(item, provider):
    backend, server = provider.get('backend'), provider.get('server') or {}
    if backend == 'plex':
        return (_plex.artwork_url(item, item.get('thumb') or ''), _plex.artwork_url(item, item.get('art') or ''),
                _plex.logo_url(item))
    return (_emby.artwork_url(server, item.get('thumb') or ''),
            _emby.artwork_url(server, item.get('art') or '', kind='Backdrop'),
            _emby.logo_url(server, item.get('rating_key') or ''))


def _server_meta_of(item, provider):
    """A Plex / Jellyfin / Emby item as an add-on meta (so it lists like any catalog title)."""
    backend, server = provider.get('backend'), provider.get('server') or {}
    poster, backdrop, logo = _server_item_pictures(item, provider)
    found = item.get('ids') or {}
    facts, plot = item.get('info_line') or '', item.get('summary') or ''
    plex = backend == 'plex'
    badge = '[COLOR %s]%s[/COLOR] • %s' % (PLEX_COLOR if plex else EMBY_COLOR, 'PLEX' if plex else 'EMBY', server.get('name') or '')
    meta = {'id': '%s:%s:%s' % (backend, server.get('id') or '', item.get('rating_key') or ''),
            'type': 'movie' if (item.get('media_type') or 'movie') == 'movie' else 'series',
            'name': item.get('title') or 'Untitled', 'poster': poster, 'background': backdrop, 'logo': logo,
            'clearlogo': logo, 'description': ('%s\n\n%s' % (facts, plot) if plot else facts) if facts else plot,
            'releaseInfo': str(item.get('year') or ''), 'imdb_id': found.get('imdb_id') or '',
            'moviedb_id': found.get('tmdb_id') or '', '_backend': backend, '_server_item': item,
            '_provider_name': provider.get('name') or '', '_label2': '%s • %s' % (facts, badge) if facts else badge,
            '_size_label': item.get('size_label') or ''}
    if item.get('rating'):
        meta['imdbRating'] = str(item['rating'])
    if item.get('genres'):
        meta['genres'] = list(item['genres'])
    return meta


def _server_listing(provider, media_type, extra=None):
    """A media server's search answer as add-on metas (films for a film search, the rest otherwise)."""
    query = str((extra or {}).get('search') or '').strip()
    if not query:
        return {'metas': []}
    client = _plex if provider.get('backend') == 'plex' else _emby
    films = media_type == 'movie'
    found = client.server_find(provider.get('server') or {}, query, media_type=media_type, limit=40) or []
    return {'metas': [_server_meta_of(item, provider) for item in found
                      if ((item.get('media_type') or 'movie') == 'movie') == films and item.get('rating_key')]}


def _server_row_url(meta):
    """(link, opens a folder) of a media-server title in a listing."""
    item = meta.get('_server_item') or {}
    folder = (item.get('media_type') or 'movie') in ('show', 'season')
    if meta.get('_backend') == 'plex':
        if folder:
            return build_url(action='plex_children', server_id=item.get('server_id') or '', key=item.get('key') or '',
                             title=item.get('title') or ''), True
        return build_url(action='plex_play', server_id=item.get('server_id') or '',
                         rating_key=item.get('rating_key') or ''), False
    if folder:
        return build_url(action='emby_children', key=item.get('rating_key') or '', title=item.get('title') or ''), True
    return build_url(action='emby_play', item_id=item.get('rating_key') or ''), False


_ID_NAMESPACES = ('imdb', 'tmdb', 'tvdb', 'kitsu', 'mal', 'anilist', 'anidb', 'tvmaze')

# the names add-ons give these ids under: imdb, imdbid, imdb_id, ... and a few longer ones
_ID_FIELD_MAP = dict([(form % space, space) for space in _ID_NAMESPACES for form in ('%s', '%sid', '%s_id')]
                     + [('moviedb_id', 'tmdb'), ('themoviedb_id', 'tmdb'), ('thetvdb_id', 'tvdb'), ('myanimelist_id', 'mal')])


def _who_value(namespace, value):
    """'imdb:tt123' / 'tmdb:55' for an id, '' when it is not one."""
    value = str(value or '').strip().lower()
    if not value or namespace not in _ID_NAMESPACES:
        return ''
    value = value.split(':')[0]
    if not value or (namespace == 'imdb' and not value.startswith('tt')):
        return ''
    return '%s:%s' % (namespace, value)


def _meta_who(meta):
    """Every id a meta names (its own id, id fields and id blocks); 'raw:<id>' when none is known."""
    meta = meta or {}
    found = set()
    own = str(meta.get('id') or '').strip().lower()
    if own.startswith('tt'):
        found.add(_who_value('imdb', own))
    else:
        for sep in (':', '-'):
            if sep in own:
                head, tail = own.split(sep, 1)
                if head.strip() in _ID_NAMESPACES:
                    found.add(_who_value(head.strip(), tail))
                    break
    blocks = [meta] + [holder for holder in (meta.get('behaviorHints') or {}, meta.get('externalIds') or {},
                                             meta.get('external_ids') or {}, meta.get('ids') or {}) if isinstance(holder, dict)]
    for block in blocks:
        for key, value in list(block.items()):
            namespace = _ID_FIELD_MAP.get(str(key).strip().lower())
            if namespace and not isinstance(value, (dict, list)):
                found.add(_who_value(namespace, value))
    found.discard('')
    if not found and own:
        found.add('raw:%s' % own)
    return found


def _extra_name_of(entry):
    """(name, required) of a catalog extra given as a dict or a bare name."""
    if isinstance(entry, dict):
        return str(entry.get('name') or '').strip().lower(), bool(entry.get('isRequired') or entry.get('required'))
    return str(entry or '').strip().lower(), False


def _searchable_catalog(catalog):
    """A catalog search can use: it takes 'search' and needs nothing else."""
    catalog = catalog or {}
    required = set()
    for name in catalog.get('extraRequired') or []:
        name = name.get('name') if isinstance(name, dict) else name
        if name:
            required.add(str(name).strip().lower())
    search = False
    other = bool(required - {'search'})
    for field in ('extra', 'extraSupported'):
        for entry in catalog.get(field) or []:
            name, needed = _extra_name_of(entry)
            if name == 'search':
                search = True
            elif name and (needed or name in required):
                other = True
    return search and not other

def _setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


# 8.1: what a stream row says (file, picture / sound tags, add-on, service, transport) is
# worked out by the sourcefacts package; these names are what the source list calls.
from . import sourcefacts as _sourcefacts   # noqa: E402
from .sourcefacts import identity as _source_identity   # noqa: E402
from .sourcefacts.text import plain as _clean_stream_text   # noqa: E402

_stream_facts = _sourcefacts.describe
_stream_label = _sourcefacts.card_lines
_stream_badges = _sourcefacts.badge_row
_safe_http_origin = _source_identity.http_origin
_collect_stream_texts = _source_identity.row_texts
_provider_badge = _source_identity.service_badge
_extract_size = _source_identity.size
_SOURCE_TYPE_STYLES = _source_identity.KINDS


from . import title_match as _title_match   # noqa: E402


def _search_partial_row(failed, silent, ceiling):
    if not failed and not silent:
        return
    bits = []
    if silent:
        bits.append(tr('%d did not respond within %ds') % (len(silent), int(ceiling)))
    if failed:
        bits.append(tr('%d failed') % len(failed))
    names = ', '.join((silent + sorted(failed))[:6])
    add_item(tr('[COLOR grey]⚠ Incomplete results: %s[/COLOR]') % ' • '.join(bits),
             build_url(action='hub_search_menu'), is_folder=False,
             art=root_art('search'),
             info={'title': 'Incomplete results',
                   'plot': tr('These add-ons did not return results for this search:\n%s\n\n'
                              'Increase the search timeout in settings if they are slow, '
                              'or check that they support search.') % (names or '-')})


_TMDB_SEARCH = {'id': '__tmdb_search__', 'name': 'TMDb', 'backend': 'tmdb',
                'manifest': {'types': ['movie', 'series'], 'catalogs': []}}
# the order and caption of the result groups
_RESULT_GROUPS = (('movie', 'Movies'), ('series', 'TV Shows'), ('anime', 'Anime'), ('tv', 'Channels'),
                  ('channel', 'Channels'))


def _search_jobs(addons, include_tmdb):
    """(add-on, catalog, type) for every searchable catalog, one add-on at a time."""
    jobs = [(_TMDB_SEARCH, {'id': '__tmdb_search__', 'name': 'TMDb'}, 'mixed')] if include_tmdb else []
    for addon in addons:
        manifest = addon.get('manifest') or {}
        kinds = set(c.get('type') for c in manifest.get('catalogs') or [] if isinstance(c, dict) and c.get('type'))
        for kind in sorted(kinds | set(manifest.get('types') or []) | {'movie', 'series'}):
            jobs.extend((addon, catalog, kind) for catalog in _addon_catalogs(addon, kind) if _searchable_catalog(catalog))
    return _fair_search_job_order(jobs)


def _addon_label(addon):
    return (addon.get('name') if isinstance(addon, dict) else str(addon)) or '?'


def _search_one(job, query, ceiling):
    """One catalog's answer for the query (kept a while); the exception when it failed."""
    addon, catalog, kind = job
    name = addon if isinstance(addon, str) else (addon.get('name') or addon.get('base_url') or '?')
    key = 'job|%s|%s|%s|%s' % (query.strip().casefold(), name, (catalog or {}).get('id') or (catalog or {}).get('name') or '', kind)
    kept = _searches.get(key)
    if kept is not None:
        return kept
    try:
        if addon.get('backend') == 'tmdb':
            from . import tmdb_api
            answer = {'metas': tmdb_api.find_titles(query, limit=40)}
        elif addon.get('backend') in SERVER_BACKENDS:
            answer = _server_listing(addon, kind, extra={'search': query})
        else:
            answer = fetch_catalog(addon, kind, catalog.get('id'), extra={'search': query},
                                   timeout_override=min(fast_timeout('search'), float(ceiling)))
    except Exception as exc:
        return exc
    _searches.put(key, answer)
    return answer


class _SearchTally(object):
    """What the search has gathered: titles per type (each title once, media-server rows always),
    who answered, who failed."""

    def __init__(self, jobs):
        self.groups, self.seen, self.count = {}, set(), 0
        self.answered, self.failed, self.useful = set(), {}, set()
        self.place = dict((id(job), spot) for spot, job in enumerate(jobs))

    def take(self, job, answer, query, turn):
        addon, _catalog, kind = job
        name = _addon_label(addon)
        if isinstance(answer, Exception):
            self.failed[name] = str(answer)[:90]
            return 0
        self.answered.add(name)
        rows = [meta for meta in ((answer or {}).get('metas') or []) if isinstance(meta, dict) and meta.get('id')]
        scored, dropped = _title_match.keep_relevant(rows, query, lambda meta: meta, fallback_when_empty=False)
        if dropped:
            xbmc.log('[MegaNexus] search: dropped %d irrelevant row(s) of %d from %s' % (dropped, len(rows), name),
                     xbmc.LOGINFO)
        if scored and addon.get('backend') != 'tmdb':
            self.useful.add(name)
        by_kind = {}
        for meta, _score in scored:
            if meta.get('_backend') not in SERVER_BACKENDS:
                who = _meta_who(meta)
                if who & self.seen:
                    continue
                self.seen |= who
            self.count += 1
            by_kind.setdefault(meta.get('type') or (kind if kind != 'mixed' else 'movie'), []).append(meta)
        added = 0
        own_meta = addon.get('backend') not in SERVER_BACKENDS and addon.get('backend') != 'tmdb'
        for found_kind, metas in by_kind.items():
            if own_meta:
                try:
                    from . import meta_choice
                    metas = meta_choice.apply_many(addon, found_kind, metas)
                except Exception:
                    pass
            self.groups.setdefault(found_kind, []).append((self.place.get(id(job), turn), addon, metas))
            added += len(metas)
        return added


def _gather_search(query, jobs, ceiling):
    """Ask every job at once behind the progress sheet; (tally, cancelled)."""
    tally = _SearchTally(jobs)
    names = []
    for job in jobs:
        name = str((job[0] or {}).get('name') or '').strip() if isinstance(job[0], dict) else ''
        if name and name not in names:
            names.append(name)
    with _search_progress(title=tr('Search: %s') % query, fanart='', provider_count=len(jobs),
                          provider_names=names) as sheet:
        race = begin_race(lambda job: _search_one(job, query, ceiling), jobs,
                          workers=max(2, min(4, parallel_workers(), len(jobs))), timeout=float(ceiling), lane='search')
        rows = _iter_search_race(race, lambda: tally.count, lambda: bool(tally.useful), should_stop=sheet.is_stopped,
                                 on_ready=lambda: sheet.mark_sufficient(auto_seconds=0))
        for turn, (job, answer) in enumerate(rows, start=1):
            if sheet.is_stopped():
                break
            sheet.update(provider_name=job[0].get('name') or '', index=turn, status=tr('Searching add-ons...'),
                         sub_status=('%d %s' % (tally.count, tr('result'))) if tally.count else '')
            added = tally.take(job, answer, query, turn)
            if added:
                sheet.add_found(added, provider_name=_addon_label(job[0]), unique_total=tally.count)
        cancelled = sheet.is_cancelled()
        sheet.set_finalizing()
    return tally, cancelled


def _search_year(meta):
    try:
        found = YEAR_RE.search(str(meta.get('year') or meta.get('releaseInfo') or ''))
        return int(found.group(1)) if found else None
    except Exception:
        return None


def _add_search_row(addon, meta, kind):
    """The title's row in the result list; its record for the search window."""
    meta_id = meta.get('id') or ''
    title = meta.get('name') or meta.get('title') or meta_id
    year = _search_year(meta)
    fallback = catalog_art('search', kind)
    try:
        art = native_meta_art(meta, media_type=meta.get('type') or kind or 'movie', fallback_art=fallback) or fallback or {}
    except Exception:
        art = fallback or {}
    try:
        _meta_keep(kind, meta_id, meta, source_provider_id=addon.get('id') or '')
    except Exception:
        pass
    ids = extract_ids(meta)
    path, is_folder = _item_click_url(media_type=kind, canonical_id=meta_id, title=title,
                                      tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                                      tvdb_id=ids.get('tvdb_id') or '', source_provider_id=addon.get('id') or '',
                                      ui_seed=art)
    info = {'title': title, 'plot': meta.get('description') or '', 'mediatype': 'movie' if kind == 'movie' else 'tvshow'}
    if year:
        info['year'] = year
    extra = {}
    if meta.get('_backend') in SERVER_BACKENDS:
        path, is_folder = _server_row_url(meta)
        extra = {'label2': meta.get('_label2') or '', 'properties': None if is_folder else {'IsPlayable': 'true'}}
    add_item('%s  •  %s' % (title, year) if year else title, path, is_folder=is_folder, info=info, art=art,
             context_menu=_source_choice_list(media_type=kind, canonical_id=meta_id, title=title), **extra)
    return {'title': title, 'year': str(year) if year else '', 'media_type': kind, 'plot': info['plot'],
            'rating': meta.get('imdbRating') or meta.get('rating') or '',
            'genre': meta.get('genres') or meta.get('genre') or [], 'runtime': meta.get('runtime') or '',
            'poster': art.get('poster') or art.get('thumb') or '', 'fanart': art.get('fanart') or art.get('landscape') or '',
            'landscape': art.get('landscape') or art.get('fanart') or '',
            'clearlogo': art.get('clearlogo') or art.get('logo') or '', 'path': path, 'is_folder': '1' if is_folder else '',
            'source_label': extra.get('label2') or addon.get('name') or '', 'is_anime': kind == 'anime'}


def _add_search_group(kind, batches, query):
    """One type's results, best match first (then add-on order, then the add-on's own order)."""
    rows = [(addon, meta, batch, spot) for batch, (_rank, addon, metas) in enumerate(sorted(batches, key=lambda b: b[0]))
            for spot, meta in enumerate(metas)]
    scored, dropped = _title_match.keep_relevant(rows, query, lambda row: row[1], fallback_when_empty=False)
    if not scored:
        return []
    caption = dict(_RESULT_GROUPS).get(kind, kind.title())
    add_item('[B][COLOR yellow]──  %s  •  %d  ──[/COLOR][/B]' % (caption, len(scored)), build_url(action='hub_search_menu'),
             is_folder=False, info={'title': dict(_RESULT_GROUPS).get(kind, kind),
                                    'plot': tr('%d results of type %s') % (len(scored), dict(_RESULT_GROUPS).get(kind, kind))})
    if dropped:
        xbmc.log('[MegaNexus] search: dropped %d irrelevant row(s) of %d in "%s"' % (dropped, dropped + len(scored), kind),
                 xbmc.LOGINFO)
    best_first = sorted(scored, key=lambda pair: (-pair[1], pair[0][2], pair[0][3]))
    return [_add_search_row(row[0], row[1], kind) for row, _score in best_first]


def _show_search_results(query, providers_list, include_tmdb=False):
    """Search every add-on catalog that can (and the media servers, and TMDb) and list the titles by type."""
    try:
        from .meganexus.addon_wire import provider_health_pause
        provider_health_pause(0)
    except Exception:
        pass
    jobs = _search_jobs(list(providers_list or []) + _server_addons(), include_tmdb)
    if not jobs:
        notify(tr('No catalogs in your add-ons support search'))
        return end_dir(content='files', cache=False)
    ceiling = _get_int_setting('search_ceiling_seconds', 6, minimum=3, maximum=60)
    tally, cancelled = _gather_search(query, jobs, ceiling)
    if cancelled:
        return end_dir(content='files', cache=False)
    asked = set(job[0].get('name') or '?' for job in jobs if isinstance(job[0], dict))
    silent = sorted(asked - tally.answered - set(tally.failed))
    try:
        xbmc.log('[MegaNexus] search done: %d results | answered=%d/%d | failed=%s | timed_out=%s' % (
            tally.count, len(tally.answered), len(asked),
            ', '.join('%s(%s)' % pair for pair in tally.failed.items()) or 'none', ', '.join(silent) or 'none'),
            xbmc.LOGINFO)
    except Exception:
        pass
    again = build_url(action='hub_search_menu')
    add_item(tr('[B][COLOR cyan]🔍 Search: %s[/COLOR][/B]    [COLOR lightgrey]results: %d[/COLOR]') % (query, tally.count),
             again, is_folder=False,
             info={'title': 'Search results',
                   'plot': 'Press to search again with a different term. Results are grouped by content type below.'})
    if not tally.count:
        add_item(tr('[COLOR yellow]No results found for "%s"[/COLOR]') % query, again, is_folder=False,
                 info={'title': 'No results', 'plot': 'Try a different phrasing, or an id like tt1234567 or tmdb:123'})
        return end_dir(content='videos', cache=False)
    known = [kind for kind, _caption in _RESULT_GROUPS]
    kinds = [kind for kind in known if kind in tally.groups] + [kind for kind in tally.groups if kind not in known]
    window_rows = []
    for kind in kinds:
        window_rows.extend(_add_search_group(kind, tally.groups[kind], query))
    _search_partial_row(tally.failed, silent, ceiling)
    result = end_dir(content='videos', cache=False)
    return result


def _searchable(catalog):
    return any(isinstance(x, dict) and x.get('name') == 'search' for x in (catalog or {}).get('extra') or [])


def _folder_search_rows(bucket, query, entries, most):
    """Titles matching the query from the section's searchable catalogs (at most `most`)."""
    found, seen = [], set()
    merge = _folder_merges_duplicates(bucket)

    def ask(job):
        addon, catalog = job[0], job[1]
        extra = dict(_folder_extra_for(bucket, (addon or {}).get('id') or '', (catalog or {}).get('id') or '', catalog) or {},
                     search=query)
        return fetch_catalog(addon, catalog.get('type') or _section_media_type(bucket) or 'movie', catalog.get('id'),
                             extra=extra, timeout_override=fast_timeout('search'))
    for job, answer in each_parallel(ask, _fair_search_job_order(entries), workers=max(1, min(parallel_workers(), 4,
                                                                                              len(entries))),
                                     timeout=6.0, lane='search'):
        addon, catalog = job[0], job[1]
        kind = (catalog or {}).get('type') or _section_media_type(bucket) or 'movie'
        if isinstance(answer, Exception):
            continue
        for meta in (answer or {}).get('metas') or []:
            meta_id = str((meta or {}).get('id') or '')
            if not meta_id or _title_match.best_score(query, meta) <= 0:
                continue
            key = _meta_ref(kind, meta_id, meta) if merge else '%s:%s:%s' % ((addon or {}).get('id') or '',
                                                                             (catalog or {}).get('id') or '', meta_id)
            if key not in seen:
                seen.add(key)
                found.append((addon, catalog, kind, meta_id, meta))
            if len(found) >= most:
                return found
    return found


def search_folder(bucket='movies'):
    """Search inside a Hub section: its pinned catalogs that can search, best matches first."""
    bucket = bucket or 'movies'
    entries = [row for row in _pinned_catalogs(bucket) if _searchable(row[1])]
    if not entries:
        notify(tr('No pinned catalogs support search inside this folder'))
        return section_rows(bucket)
    keyboard = xbmc.Keyboard('', tr('Search inside %s') % tr(_hub_bucket_title(bucket)))
    keyboard.doModal()
    query = (keyboard.getText() or '').strip() if keyboard.isConfirmed() else ''
    if not query:
        return section_rows(bucket)
    try:
        from .finding import recall as _queries
        _queries.note_query(query, media_type=bucket or 'all')
    except Exception:
        pass
    most = _listing_page_size() * 2
    rows = _folder_search_rows(bucket, query, entries, most)
    if not rows:
        notify(tr('No results inside this folder'))
        return section_rows(bucket)
    rows.sort(key=lambda row: -_title_match.best_score(query, row[4]))
    _show_media_rows(rows[:most], bucket=bucket, page_num=0, has_more=False)
    return end_dir(content=_section_content(bucket), cache=False)


# ─────────────────────────────────────────────────────────────────────
# home-folder pre-fetch.


def home():
    # Only a small recovery directory sits behind the MegaNexus interface.
    add_item('MegaNexus', build_url(action='home_xml'))
    add_item('HUB Settings', build_url(action='first_run_wizard'), is_folder=False)
    add_item('Repair MegaNexus installation', build_url(action='meganexus_install'), is_folder=False)
    add_item('Remove MegaNexus build', build_url(action='meganexus_uninstall'), is_folder=False)
    end_dir(content='files', cache=False)
    from .frontend_bridge import open_home
    return open_home()


# ─── First-run wizard ─────────────────────────────────────────────────


def first_run_wizard():
    from .frontend_bridge import open_home
    return open_home(settings=True)


def _setting_ids():
    import xml.etree.ElementTree as ET
    tree = ET.parse(os.path.join(ADDON.getAddonInfo('path'), 'resources', 'settings.xml'))
    return [node.get('id') for node in tree.findall('.//setting') if node.get('id')]


def _settings_backup():
    """The whole setup as one JSON-able backup: add-ons, pins, sections, section pictures, every setting."""
    backup = {'meganexus_export_version': 1, 'created_unix': int(time.time()),
              'plugin_version': ADDON.getAddonInfo('version')}
    for key, read in (('providers', lambda: addon_registry.list_providers() or []), ('catalog_pins', lambda: _stored_pins() or []),
                      ('home_buckets', lambda: _home_sections(include_collection=False) or [])):
        try:
            backup[key] = read()
        except Exception:
            backup[key] = []
    try:
        raw = (ADDON.getSetting('bucket_art_map') or '{}').strip()
        backup['bucket_art_map'] = json.loads(raw) if raw else {}
    except Exception:
        backup['bucket_art_map'] = {}
    backup['settings'] = {}
    try:
        for key in _setting_ids():
            try:
                backup['settings'][key] = ADDON.getSetting(key) or ''
            except Exception:
                pass
    except Exception:
        pass
    return backup


def export_settings():
    snapshot = _settings_backup()
    dest_dir = xbmcgui.Dialog().browse(0, tr('Choose a save folder'), 'files', '', False, False, '')
    if not dest_dir:
        return
    timestamp = time.strftime('%Y%m%d-%H%M%S')
    filename = 'meganexus-config-%s.json' % timestamp
    dest_path = os.path.join(dest_dir, filename)
    try:
        body = json.dumps(snapshot, ensure_ascii=False, indent=2)
        with xbmcvfs.File(dest_path, 'w') as fh:
            fh.write(body)
        notify(tr('Exported: %s') % filename)
    except Exception as exc:
        error(tr('Export failed: %s') % exc)


def _read_backup(path):
    """The backup file's content (None after saying what is wrong)."""
    try:
        with xbmcvfs.File(path, 'r') as handle:
            text = handle.read()
        if not text:
            error(tr('The file is empty'))
            return None
        backup = json.loads(text)
    except Exception as exc:
        error(tr('Could not read file: %s') % exc)
        return None
    if not isinstance(backup, dict):
        error(tr('Invalid file format'))
        return None
    if int(backup.get('meganexus_export_version') or 0) < 1:
        error(tr('Unsupported file version'))
        return None
    return backup


def _restore_list(backup, key, keep, what):
    rows = backup.get(key) or []
    try:
        if rows:
            keep(rows)
            return len(rows)
    except Exception as exc:
        xbmc.log('[MegaNexus] import %s failed: %s' % (what, exc), xbmc.LOGWARNING)
    return 0


def import_settings():
    """Restore an exported setup (add-ons, pinned catalogs, section pictures, settings) after asking."""
    path = xbmcgui.Dialog().browse(1, tr('Choose a previously-exported JSON file'), 'files', '.json', False, False, '')
    if not path or not path.lower().endswith('.json'):
        return
    if not xbmcgui.Dialog().yesno('MegaNexus', tr('This will replace your current configuration with the file contents. Continue?')):
        return
    backup = _read_backup(path)
    if backup is None:
        return
    addons = _restore_list(backup, 'providers', addon_registry.store_addons_text, 'providers')
    pins = _restore_list(backup, 'catalog_pins', _store_pins, 'pins')
    try:
        if backup.get('bucket_art_map'):
            ADDON.setSetting('bucket_art_map', json.dumps(backup['bucket_art_map'], ensure_ascii=False))
    except Exception:
        pass
    settings = 0
    try:
        for key, value in (backup.get('settings') or {}).items():
            if key in ('bucket_art_map', 'catalog_pins_json'):
                continue
            try:
                ADDON.setSetting(key, str(value) if value is not None else '')
                settings += 1
            except Exception:
                pass
    except Exception:
        pass
    xbmcgui.Dialog().ok('MegaNexus', tr('Imported successfully:\n• Providers: %d\n• Pinned catalogs: %d\n• Settings: %d')
                        % (addons, pins, settings))
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass



PERFORMANCE_PRESET = (
    ('lightweight_mode',   'true'),
    ('catalog_cache_ttl',  '1800'),
    ('meta_cache_ttl',     '14400'),
)


RECOMMENDED_PRESET = (
    ('quality_profile',    'Balanced (recommended)'),
    ('lightweight_mode',   'true'),
    ('catalog_cache_ttl',  '1800'),
    ('meta_cache_ttl',     '14400'),
    ('bypass_all_filters', 'false'),
)


def _speed_mode_now():
    return _preset_state(PERFORMANCE_PRESET)


_SPEED_LABELS = {'lightweight_mode': 'Lite mode (disables grouping folders and index sync)',
                 'catalog_cache_ttl': 'Catalog cache: 30 minutes (instead of 10)',
                 'meta_cache_ttl': 'Metadata cache: 4 hours (instead of 1)'}


def _ask_speed_setup(state):
    if state['all_active']:
        text, yes, no = tr('All lite-mode optimisations are already applied. Re-apply them anyway?'), tr('Re-apply'), tr('Close')
    else:
        lines = [tr('Will be applied to these settings:'), '']
        lines += ['[COLOR %s]%s[/COLOR] %s' % ('green' if ok else 'yellow', '✓' if ok else '○',
                                               tr(_SPEED_LABELS[key]) if key in _SPEED_LABELS else key)
                  for key, _now, _want, ok in state['items']]
        lines += ['', tr("The skin becomes lighter and faster. Lists use the cache instead of live fetches, and posters come "
                         "from Kodi's cache after the first load. You lose no sources — everything stays on the Sources page.")]
        text, yes, no = '\n'.join(lines), tr('Enable all'), tr('Cancel')
    try:
        return xbmcgui.Dialog().yesno(tr('MegaNexus • performance tuning'), text, yeslabel=yes, nolabel=no)
    except Exception:
        return False


def use_speed_setup():
    """Apply the performance tuning after showing what it changes."""
    if not _ask_speed_setup(_speed_mode_now()):
        return services_menu()
    done, failed = [], []
    for key, value in PERFORMANCE_PRESET:
        try:
            ADDON.setSetting(key, value)
            done.append(key)
        except Exception as exc:
            xbmc.log('[MegaNexus] performance preset setSetting(%s, %s) failed: %s' % (key, value, exc), xbmc.LOGWARNING)
            failed.append(key)
    xbmc.log('[MegaNexus] performance preset applied: %s, failed: %s' % (', '.join(done) or 'none', ', '.join(failed) or 'none'),
             xbmc.LOGINFO)
    notify(tr('Partially applied (%d succeeded, %d failed)') % (len(done), len(failed)) if failed
           else tr('Performance tuning applied ✓'))
    _forget_quietly(lambda: xbmc.executebuiltin('Container.Refresh'))
    return services_menu()


def _preset_state(preset):
    """How far the settings already match a setup bundle: all active, how many differ, each (key, now, wanted, matches)."""
    state = {'all_active': True, 'missing_count': 0, 'items': []}
    try:
        for key, wanted in preset:
            now = (ADDON.getSetting(key) or '').strip()
            matches = now.lower() == wanted.lower()
            state['items'].append((key, now, wanted, matches))
            if not matches:
                state['all_active'] = False
                state['missing_count'] += 1
    except Exception:
        state.update(all_active=False, missing_count=len(preset))
    return state


def _suggested_setup_state():
    return _preset_state(RECOMMENDED_PRESET)


_SUGGESTED_LABELS = {'quality_profile': 'Quality profile: Balanced (recommended)',
                     'lightweight_mode': 'Lite mode (disables grouping folders and index sync)',
                     'catalog_cache_ttl': 'Catalog cache: 30 minutes', 'meta_cache_ttl': 'Metadata cache: 4 hours',
                     'bypass_all_filters': 'Add-on filtering: on (filters are never bypassed)'}


def _ask_suggested_setup(state):
    """True when the user wants the recommended setup (again)."""
    if state['all_active']:
        text, yes, no = tr('All recommended settings are already applied. Re-apply them anyway?'), tr('Re-apply'), tr('Close')
    else:
        lines = [tr('The recommended setup will apply:'), '']
        lines += ['[COLOR %s]%s[/COLOR] %s' % ('green' if ok else 'yellow', '✓' if ok else '○',
                                               tr(_SUGGESTED_LABELS[key]) if key in _SUGGESTED_LABELS else key)
                  for key, _now, _want, ok in state['items']]
        lines += ['', tr('Balanced: prefers 1080p+ and hides camera copies, with Debrid first. '
                         'Lite mode serves lists from cache instead of fetching them live. '
                         'You do not lose any add-ons — they all remain available on the Sources page.')]
        text, yes, no = '\n'.join(lines), tr('Enable all'), tr('Cancel')
    try:
        return xbmcgui.Dialog().yesno('MegaNexus • ' + tr('Recommended setup'), text, yeslabel=yes, nolabel=no)
    except Exception:
        return False


def use_suggested_setup():
    """Apply the recommended setup after showing what it changes."""
    if not _ask_suggested_setup(_suggested_setup_state()):
        return services_menu()
    done, failed = [], []
    for key, value in RECOMMENDED_PRESET:
        try:
            ADDON.setSetting(key, value)
            done.append(key)
        except Exception as exc:
            xbmc.log('[MegaNexus] recommended preset setSetting(%s, %s) failed: %s' % (key, value, exc), xbmc.LOGWARNING)
            failed.append(key)
    xbmc.log('[MegaNexus] recommended preset applied: %s, failed: %s' % (', '.join(done) or 'none', ', '.join(failed) or 'none'),
             xbmc.LOGINFO)
    notify(tr('Partially applied (%d succeeded, %d failed)') % (len(done), len(failed)) if failed
           else tr('Recommended setup applied ✓'))
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    return services_menu()




def _plex_error(exc):
    try:
        xbmc.log('[MegaNexus] Plex: %s' % exc, xbmc.LOGWARNING)
    except Exception:
        pass
    error(str(exc) or 'Could not connect to Plex')


def _plex_server(server_id):
    server = _plex.server_by_id(server_id)
    if not server:
        raise _plex.PlexFailure('This server is no longer available. Refresh the Plex list and try again.')
    return server


_ART_WARM_SEEN = set()
_ART_WARM_LOCK = threading.Lock()


def _warm_server_pictures(tmdb_id, imdb_id, media_type, title, year):
    key = '%s|%s|%s' % (media_type, tmdb_id, imdb_id)
    with _ART_WARM_LOCK:
        if key in _ART_WARM_SEEN or len(_ART_WARM_SEEN) > 400:
            return
        _ART_WARM_SEEN.add(key)

    def _run():
        try:
            _tmdb_api.art_for(tmdb_id=tmdb_id, imdb_id=imdb_id,
                                 media_type=media_type, title=title, year=year)
        except Exception:
            pass

    _submit_optional(_run, key='art:%s' % key)


def _server_meta_origin(backend):
    target = 'emby_server' if backend == 'emby' else 'plex_server'
    try:
        return (_meta_choice.choice_for(target) or 'auto')
    except Exception:
        return 'auto'


def _server_tmdb_pictures(item, fallback, backend='plex'):
    """A media-server item's TMDB pictures when they are already known (the local copy or the
    TMDB cache); else they are fetched for next time and the server's own are used."""
    if _server_meta_origin(backend) == 'native' or not _setting_bool('server_art_from_tmdb', True):
        return fallback
    found = item.get('ids') or {}
    tmdb_id, imdb_id = str(found.get('tmdb_id') or '').strip(), str(found.get('imdb_id') or '').strip()
    if not (tmdb_id or imdb_id):
        return fallback
    kind = 'tv' if (item.get('media_type') or 'movie') in ('show', 'season', 'episode') else 'movie'
    title, year = item.get('raw_title') or item.get('title') or '', item.get('year') or ''
    ask = dict(tmdb_id=tmdb_id, imdb_id=imdb_id, media_type=kind, title=title, year=year)
    try:
        bundle = _tmdb_art_db.stored_pictures(**ask) or {}
    except Exception:
        bundle = {}
    if not bundle.get('poster'):
        try:
            bundle = _tmdb_api.art_cached_only(**ask) or {}
        except Exception:
            bundle = {}
    if not bundle.get('poster'):
        _warm_server_pictures(tmdb_id, imdb_id, kind, title, year)
        return fallback
    out = dict(fallback or {}, poster=bundle['poster'], thumb=bundle['poster'], icon=bundle['poster'])
    if bundle.get('fanart'):
        out.update(fanart=bundle['fanart'], landscape=bundle['fanart'])
    if bundle.get('clearlogo'):
        out['clearlogo'] = bundle['clearlogo']
    return out


def _plex_item_art(item):
    poster = _plex.artwork_url(item, item.get('thumb') or item.get('parent_thumb') or '')
    fanart = _plex.artwork_url(item, item.get('art') or item.get('thumb') or '')
    return _server_tmdb_pictures(
        item, {'poster': poster, 'thumb': poster, 'fanart': fanart, 'landscape': fanart},
        backend='plex')


_PLEX_INFO = (('content_rating', 'mpaa'), ('studio', 'studio'), ('tagline', 'tagline'), ('premiered', 'premiered'))


_PLEX_INFO_LISTS = (('genres', 'genre'), ('directors', 'director'), ('writers', 'writer'), ('cast', 'cast'))


def _plex_info_of(item):
    """Kodi's video information for a Plex library item (its facts line above the plot)."""
    kind = item.get('media_type') or 'movie'
    plot, facts = item.get('summary') or '', item.get('info_line') or ''
    info = {'title': item.get('raw_title') or item.get('title') or 'Plex',
            'plot': ('%s\n\n%s' % (facts, plot) if plot else facts) if facts else plot,
            'year': item.get('year') or 0,
            'mediatype': {'show': 'tvshow', 'season': 'season', 'episode': 'episode'}.get(kind, 'movie'),
            'duration': int((item.get('duration_ms') or 0) / 1000)}
    if item.get('rating'):
        info['rating'] = float(item.get('rating') or 0)
    info.update((field, item[key]) for key, field in _PLEX_INFO if item.get(key))
    info.update((field, list(item[key])) for key, field in _PLEX_INFO_LISTS if item.get(key))
    if kind == 'episode':
        info.update(tvshowtitle=item.get('show_title') or '', season=item.get('season') or 0, episode=item.get('index') or 0)
    return info


def _plex_ids_of(item):
    ids = dict(item.get('ids') or {})
    return {k: v for k, v in ids.items() if v}


def _server_episode_label(item, label):
    if item.get('media_type') == 'episode':
        return '%s  [COLOR grey](S%02dE%02d)[/COLOR]' % (label, int(item.get('season') or 0), int(item.get('index') or 0))
    return label


def _server_label2(item, brand, fallback):
    facts, name = item.get('info_line') or '', item.get('server_name') or fallback
    return '%s • %s • %s' % (facts, brand, name) if facts else '%s • %s' % (brand, name)


def _plex_row(item):
    """A Plex library row (a show / season opens, anything else plays); False when it cannot be listed."""
    kind, server_id = item.get('media_type') or 'movie', item.get('server_id') or ''
    rating_key, key = item.get('rating_key') or '', item.get('key') or ''
    if not server_id or not (rating_key or key) or (kind in ('show', 'season') and not key):
        return False
    folder = kind in ('show', 'season')
    path = (build_url(action='plex_children', server_id=server_id, key=key, title=item.get('title') or 'Plex') if folder else
            build_url(action='plex_play', server_id=server_id, rating_key=rating_key))
    add_item(_server_episode_label(item, item.get('title') or 'Plex'), path, is_folder=folder, info=_plex_info_of(item),
             art=_plex_item_art(item), ids=_plex_ids_of(item), label2=_server_label2(item, 'Plex', 'Plex'), properties=None)
    return True


def _plex_listing_rows(items, empty_label='No items in Plex'):
    emitted = 0
    for item in items or []:
        if _plex_row(item):
            emitted += 1
    if not emitted:
        add_item('[COLOR grey]%s[/COLOR]' % empty_label,
                 build_url(action='plex_menu'), is_folder=True,
                 art=root_art('plex'), info={'title': empty_label})
    return emitted


_PLEX_PIN_TICKS = 150


def _plex_pins():
    """(the PIN for plex.tv/link, the strong PIN the QR code opens or None, the QR picture)."""
    pin = _plex.request_pin()
    xbmc.log('[MegaNexus] Plex PIN created id=%s flavor=%s' % (pin.get('id'), pin.get('flavor')), xbmc.LOGINFO)
    try:
        strong = _plex.request_pin(strong=True)
        xbmc.log('[MegaNexus] Plex strong PIN created id=%s' % strong.get('id'), xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] strong PIN unavailable (%s) — QR falls back to plex.tv/link' % exc, xbmc.LOGWARNING)
        strong = None
    try:
        code = str(pin.get('code') or '')
        scan = _plex.auth_link_url(strong.get('code') or '') if strong else (pin.get('link_url')
                                                                             or 'https://plex.tv/link/?pin=%s' % code)
        picture = plex_link_window.qr_png(scan)
    except Exception:
        picture = ''
    return pin, strong, picture


def _wait_for_plex_link(pins, code, window, progress):
    """Poll the PINs in turn until one is linked (the account), the user cancels or time runs out (None);
    ('error', exc) after five failed polls in a row."""
    monitor, failures = xbmc.Monitor(), 0
    for tick in range(_PLEX_PIN_TICKS):
        if (window is not None and window.cancelled) or (progress is not None and progress.iscanceled()):
            return None
        pin = pins[tick % len(pins)]
        try:
            linked = _plex.poll_pin(pin.get('id'), pin.get('code'), flavor=pin.get('flavor') or 'legacy')
            failures = 0
        except Exception as exc:
            failures += 1
            if failures >= 5:
                xbmc.log('[MegaNexus] Plex PIN poll failed: %s' % exc, xbmc.LOGERROR)
                return ('error', exc)
            linked = None
        if linked:
            return linked
        if progress is not None:
            progress.update(min(99, int((tick + 1) * 100 / _PLEX_PIN_TICKS)),
                            tr('Open plex.tv/link on your phone or browser.\nPIN: %s\nWaiting for Plex to confirm the link…') % code)
        if monitor.waitForAbort(2):
            return None
    return False


def plex_sign_in():
    """Link a Plex account: a QR code (or plex.tv/link with the PIN) until Plex confirms."""
    try:
        pin, strong, picture = _plex_pins()
    except Exception as exc:
        return _plex_error(exc)
    code = str(pin.get('code') or '')
    window = progress = None
    try:
        window = plex_link_window.PlexLinkWindow(qr_path=picture, code=code)
        window.show()
    except Exception as exc:
        xbmc.log('[MegaNexus] QR window unavailable (%s) — falling back to dialog' % exc, xbmc.LOGWARNING)
        window = None
        progress = xbmcgui.DialogProgress()
        progress.create('Plex', tr('Open plex.tv/link on your phone or browser.\nPIN: %s\nWaiting for confirmation…') % code)
    try:
        linked = _wait_for_plex_link([pin] + ([strong] if strong else []), code, window, progress)
    finally:
        try:
            if window is not None:
                window.close()
            if progress is not None:
                progress.close()
        except Exception:
            pass
    if linked is None:
        return
    if isinstance(linked, tuple):
        return _plex_error(linked[1])
    if not linked:
        notify('Linking timed out — try again')
        return
    try:
        servers = _plex.servers(force=True)
    except Exception as exc:
        servers = []
        xbmc.log('[MegaNexus] Plex linked but resource discovery is temporarily unavailable: %s' % exc, xbmc.LOGWARNING)
    xbmc.log('[MegaNexus] Plex linked: user=%s servers=%d' % (linked.get('username') or '?', len(servers)), xbmc.LOGINFO)
    notify(tr('Plex linked • %d servers') % len(servers) if servers else 'Plex linked • servers will refresh automatically')
    xbmc.executebuiltin('Container.Refresh')


def plex_logout():
    try:
        confirmed = xbmcgui.Dialog().yesno('Plex', tr('Disconnect the Plex account from MegaNexus?'))
    except Exception:
        confirmed = True
    if confirmed:
        _plex.sign_out()
        notify('Plex disconnected')
        try:
            xbmc.executebuiltin('Container.Refresh')
        except Exception:
            pass


def plex_home():
    _set_render_section('plex')
    if not _plex.is_signed_in():
        add_item('Link Plex with a PIN', build_url(action='plex_login'), is_folder=False,
                 art=root_art('accounts'),
                 info={'title': 'Plex', 'plot': 'Link Plex through plex.tv/link without entering a token by hand.'})
        add_item('Account &amp; settings', build_url(action='integrations_menu'),
                 art=root_art('accounts'))
        return end_dir(cache=False)
    account = _plex.account()
    name = account.get('username') or 'Connected'
    add_item('Plex • %s' % name, build_url(action='plex_menu'),
             art=root_art('accounts'), is_folder=True,
             info={'title': 'Plex', 'plot': 'Every Plex library and server linked to this account.'})
    add_item('Continue on Plex', build_url(action='plex_continue'), art=root_art('continue'),
             info={'title': 'Continue on Plex', 'plot': 'Combines On Deck from every available server.'})
    add_item('All Plex servers', build_url(action='plex_servers'), art=root_art('plex'),
             info={'title': 'Plex servers', 'plot': 'Every private and shared server linked to the account.'})
    add_item('Search Plex', build_url(action='plex_search'), art=root_art('search_movie'),
             info={'title': 'Search Plex', 'plot': 'Search every library on every server, like Dplex.'})
    add_item('Refresh servers', build_url(action='plex_refresh'), is_folder=False,
             art=root_art('settings'), info={'title': 'Refresh Plex'})
    add_item('Disconnect Plex', build_url(action='plex_logout'), is_folder=False,
             art=root_art('accounts'), info={'title': 'Disconnect Plex'})
    end_dir(cache=False)


def plex_refresh():
    try:
        count = len(_plex.servers(force=True))
        notify(tr('Plex refreshed • %d servers') % count)
    except Exception as exc:
        _plex_error(exc)
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def plex_server_list():
    """The Plex servers of the account (own ones marked Local, shared ones Shared)."""
    try:
        servers = _plex.servers()
    except Exception as exc:
        _plex_error(exc)
        return end_dir(cache=False)
    for server in servers:
        name, kind = server.get('name') or 'Plex Server', 'Local' if server.get('owned') else 'Shared'
        add_item('%s  [COLOR grey](%s)[/COLOR]' % (name, kind), build_url(action='plex_server', server_id=server.get('id') or ''),
                 art=root_art('plex'),
                 info={'title': name, 'plot': '%s • %s' % (server.get('product') or 'Plex Media Server', kind)})
    if not servers:
        add_item('[COLOR yellow]No Plex servers found[/COLOR]', build_url(action='plex_refresh'), is_folder=False,
                 art=root_art('settings'),
                 info={'title': 'Plex', 'plot': 'Check that your account owns or shares a server, then refresh the list.'})
    end_dir(content='files', cache=False)


_PLEX_SORTS = (('Last Added', 'addedAt:desc'), ('Last Release', 'originallyAvailableAt:desc'), ('Rating', 'rating:desc'),
               ('Name', 'titleSort'), ('Year', 'year:desc'))


def _add_plex_library_row(server_id, server_name, library):
    title, kind, key = library.get('title') or 'Library', library.get('type') or '', library.get('key') or ''
    sorts = list(_PLEX_SORTS)
    if kind == 'show':
        sorts.insert(1, ('Latest episode released', 'episode.addedAt:desc'))
    saved = library_orders.sort_of('plex', server_id, key, '')
    sort_url = lambda order: build_url(action='plex_sort', server_id=server_id, key=key, title=title, library_type=kind,
                                       sort=order)
    menu = [(tr('Sort: %s%s') % ('● ' if order == saved else '', label), 'RunPlugin(%s)' % sort_url(order))
            for label, order in sorts] + [('Sort: default', 'RunPlugin(%s)' % sort_url(''))]
    plot = '%s • %s' % (server_name, kind or 'library')
    saved_label = next((label for label, order in sorts if order == saved), '')
    if saved_label:
        plot = tr('%s • sorted by: %s') % (plot, saved_label)
    add_item(title, build_url(action='plex_library', server_id=server_id, key=key, title=title, library_type=kind,
                              sort=saved),
             art=root_art('plex'), info={'title': title, 'plot': plot}, context_menu=menu)


def plex_server_rows(server_id):
    """A Plex server: Continue, then its video libraries (each opening in its saved order)."""
    try:
        server = _plex_server(server_id)
        libraries = _plex.libraries(server)
    except Exception as exc:
        _plex_error(exc)
        return end_dir(cache=False)
    name = server.get('name') or 'Plex Server'
    add_item(tr('Continue • %s') % name, build_url(action='plex_continue', server_id=server_id), art=root_art('continue'),
             info={'title': 'Continue on Plex', 'plot': tr('Next content from %s') % name})
    for library in libraries:
        _add_plex_library_row(server_id, name, library)
    if not libraries:
        add_item('[COLOR grey]No video libraries visible for this account[/COLOR]', build_url(action='plex_servers'),
                 art=root_art('plex'))
    end_dir(content='files', cache=False)


def plex_continue_rows(server_id=''):
    rows = []
    try:
        servers = [_plex_server(server_id)] if server_id else _plex.servers()
        for server in servers:
            try:
                rows.extend(_plex.on_deck(server))
            except Exception as exc:
                try:
                    xbmc.log('[MegaNexus] Plex On Deck skipped: %s' % exc, xbmc.LOGWARNING)
                except Exception:
                    pass
    except Exception as exc:
        _plex_error(exc)
    _plex_listing_rows(rows, 'Nothing to continue on Plex')
    end_dir(content='videos', cache=False)


def plex_sorting(server_id, key, title='', library_type='', sort=''):
    library_orders.keep_sort('plex', server_id, key, sort or '')
    url = build_url(action='plex_library', server_id=server_id, key=key,
                    title=title, library_type=library_type, sort=sort or '',
                    start='0')
    xbmc.executebuiltin('Container.Update(%s,replace)' % url)


def plex_library_rows(server_id, key, title='', library_type='', start='0', sort=''):
    """A Plex library page in its saved (or chosen) order, with More."""
    sort = sort or library_orders.sort_of('plex', server_id, key, '')
    try:
        first = int(start or 0)
        rows, total = _plex.children(_plex_server(server_id), '/library/sections/%s/all' % key, start=first, sort=sort)
        _plex_listing_rows(rows, 'No items in this library')
        if rows and total > first + len(rows):
            add_item('More', build_url(action='plex_library', server_id=server_id, key=key, title=title, sort=sort,
                                       library_type=library_type, start=str(first + len(rows))),
                     art=root_art('plex'), info={'title': 'More'})
    except Exception as exc:
        _plex_error(exc)
    end_dir(content='tvshows' if library_type == 'show' else 'movies', cache=False)


def plex_child_rows(server_id, key, title='', start='0'):
    """A Plex show's seasons / a season's episodes, a page at a time."""
    try:
        first = int(start or 0)
        rows, total = _plex.children(_plex_server(server_id), key, start=first)
        _plex_listing_rows(rows, 'Nothing here')
        if rows and total > first + len(rows):
            add_item('More', build_url(action='plex_children', server_id=server_id, key=key, title=title,
                                       start=str(first + len(rows))),
                     art=root_art('plex'), info={'title': 'More'})
    except Exception as exc:
        _plex_error(exc)
    end_dir(content='episodes', cache=False)


def plex_find(query='', media_type=''):
    if not _plex.is_signed_in():
        return plex_home()
    if not query:
        keyboard = xbmc.Keyboard('', tr('Search all Plex servers'))
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return end_dir(cache=False)
        query = keyboard.getText().strip()
    if not query:
        return end_dir(cache=False)
    try:
        rows = _plex.search_all(query, media_type)
    except Exception as exc:
        _plex_error(exc)
        rows = []
    add_item(tr('🔍 Plex: %s • %d results') % (query, len(rows)),
             build_url(action='plex_search', query=query, media_type=media_type),
             art=root_art('search_movie'), info={'title': 'Search Plex', 'plot': query})
    _plex_listing_rows(rows, 'No Plex results for this search')
    end_dir(content=_kodi_content_of(media_type or 'movie'), cache=False)


def _foreground_playback():
    try:
        from .refresh_guard import release_all
        release_all()   # the TV's refresh rate is chosen as playback opens
    except Exception:
        pass


def _pick_version(versions, item, poster, fallback):
    """The version to play: the only one, or the one chosen in the list (None when cancelled)."""
    if len(versions) <= 1:
        return versions[0] if versions else {}
    try:
        rows = []
        for spot, version in enumerate(versions):
            row = xbmcgui.ListItem(item.get('raw_title') or item.get('title') or fallback)
            try:
                row.setLabel2(version.get('version_label') or 'Version %d' % (spot + 1))
                if poster:
                    row.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
            except Exception:
                pass
            rows.append(row)
        choice = xbmcgui.Dialog().select(tr('Choose version'), rows, useDetails=True)
    except Exception:
        choice = xbmcgui.Dialog().select(tr('Choose version'), [v.get('version_label') or '?' for v in versions])
    return versions[choice] if choice >= 0 else None


def _server_item_ids(found):
    return {'imdb_id': _clean_imdb(found.get('imdb_id')) or '', 'tmdb_id': found.get('tmdb_id') or '',
            'tvdb_id': found.get('tvdb_id') or ''}


def _server_canonical(found, own):
    return found.get('imdb_id') or ('tmdb:%s' % found['tmdb_id'] if found.get('tmdb_id') else own)


def plex_start(server_id, rating_key):
    """Play a Plex library item (its version chosen when it has several)."""
    _foreground_playback()
    try:
        server = _plex_server(server_id)
        item = _plex.metadata(server, rating_key)
    except Exception as exc:
        return _plex_error(exc)
    version = _pick_version([v for v in item.get('versions') or [] if v.get('part_key')], item,
                            _plex.artwork_url(item, item.get('thumb') or ''), 'Plex')
    if version is None:
        return
    try:
        url = _plex.playback_url(item, part_key=version.get('part_key') or '')
    except Exception as exc:
        return _plex_error(exc)
    found = item.get('ids') or {}
    own = 'plex:%s:%s' % (server_id, rating_key)
    length = item.get('duration_ms') or 0
    ctx = dict(_server_item_ids(found), **{
        'stream_url': url, 'stream_key': own, 'provider_id': 'plex_native',
        'provider_name': 'Plex Native • %s' % (server.get('name') or 'Server'), 'server_type': 'plex',
        'server_url': item.get('server_url') or '', 'token': item.get('token') or server.get('token') or '',
        'rating_key': str(rating_key), 'client_id': _plex.client_identifier(), 'product': 'MegaNexus',
        'product_version': ADDON.getAddonInfo('version') or '8.1.0', 'device_name': 'Kodi',
        'canonical_id': _server_canonical(found, own) or own, 'video_id': str(rating_key),
        'media_type': 'series' if (item.get('media_type') or 'movie') in ('show', 'season', 'episode') else 'movie',
        'title': item.get('raw_title') or item.get('title') or 'Plex', 'show_title': item.get('show_title') or '',
        'year': item.get('year') or 0, 'plot': item.get('summary') or '', 'duration_ms': length,
        'duration': int(length / 1000), 'resume_seconds': float(item.get('view_offset_ms') or 0) / 1000.0,
        'season': item.get('season') or 0, 'episode': item.get('index') or 0,
        'poster': _plex.artwork_url(item, item.get('thumb') or ''),
        'background': _plex.artwork_url(item, item.get('art') or item.get('thumb') or ''),
        'subtitles': list(version.get('subtitles') or [])})
    return _start_playback(ctx, stream_key=ctx['stream_key'], use_resolved_url=False)


def _emby_error(exc):
    notify('Emby: %s' % exc)


def _emby_server(flavor=None):
    # 7.0.29: Jellyfin and Emby are separate connections; flavor picks one.
    servers = _emby.servers(flavor or None)
    if not servers:
        raise Exception('%s is not linked yet' % ('Jellyfin' if flavor == 'jellyfin' else 'Emby'))
    return servers[0]


def _emby_art(item, server):
    thumb = _emby.artwork_url(server, item.get('thumb') or '')
    fan = _emby.artwork_url(server, item.get('art') or '', kind='Backdrop')
    return _server_tmdb_pictures(
        item, {'poster': thumb, 'thumb': thumb, 'icon': thumb, 'fanart': fan},
        backend='emby')


def _mediabrowser_row(item, server):
    """A Jellyfin / Emby library row (a show / season opens, anything else plays)."""
    item_id = item.get('rating_key') or ''
    if not item_id:
        return False
    folder = (item.get('media_type') or 'movie') in ('show', 'season')
    path = (build_url(action='emby_children', key=item_id, title=item.get('title') or 'Emby') if folder else
            build_url(action='emby_play', item_id=item_id))
    add_item(_server_episode_label(item, item.get('title') or 'Emby'), path, is_folder=folder, info=_plex_info_of(item),
             art=_emby_art(item, server), ids=_plex_ids_of(item), label2=_server_label2(item, 'Emby', 'Emby'), properties=None)
    return True


def mediabrowser_continue():
    rows = []
    try:
        server = _emby_server()
        try:
            resumed, _total = _emby.resume(server)
            rows.extend(resumed)
        except Exception as exc:
            try:
                xbmc.log('[MegaNexus] Emby Resume skipped: %s' % exc, xbmc.LOGWARNING)
            except Exception:
                pass
        try:
            seen = {r.get('rating_key') for r in rows}
            for row in _emby.next_up(server):
                if row.get('rating_key') not in seen:
                    rows.append(row)
        except Exception as exc:
            try:
                xbmc.log('[MegaNexus] Emby NextUp skipped: %s' % exc, xbmc.LOGWARNING)
            except Exception:
                pass
    except Exception as exc:
        _emby_error(exc)
    _mediabrowser_rows(rows, 'Nothing to continue on Emby')
    end_dir(content='videos', cache=False)


def _mediabrowser_rows(items, empty_label='No items in Emby'):
    try:
        server = _emby_server()
    except Exception as exc:
        _emby_error(exc)
        return 0
    count = 0
    for item in items or []:
        if _mediabrowser_row(item, server):
            count += 1
    if not count:
        add_item('[COLOR grey]%s[/COLOR]' % empty_label, build_url(action='emby_menu'),
                 art=root_art('emby'))
    return count


def emby_login():
    url = xbmcgui.Dialog().input(tr('Emby server address (example: http://192.168.1.10:8096)'))
    if not url:
        return
    user = xbmcgui.Dialog().input(tr('Username'))
    if not user:
        return
    password = xbmcgui.Dialog().input(tr('Password'), option=xbmcgui.ALPHANUM_HIDE_INPUT)
    try:
        auth = _emby.sign_in(url, user, password or '')
    except Exception as exc:
        return _emby_error(exc)
    xbmc.log('[MegaNexus] Emby linked: user=%s server=%s' % (auth.get('username'), auth.get('server_name')), xbmc.LOGINFO)
    notify(tr('Emby linked • %s') % (auth.get('server_name') or ''))
    xbmc.executebuiltin('Container.Refresh')


def emby_logout():
    _emby.sign_out()
    notify('Emby disconnected')
    xbmc.executebuiltin('Container.Refresh')


_MEDIABROWSER_SORTS = (('Last Added', 'DateCreated:desc'), ('Last Release', 'PremiereDate:desc'),
                       ('Rating', 'CommunityRating:desc'), ('Name', 'SortName'), ('Year', 'ProductionYear:desc'))


def _add_mediabrowser_library(library):
    key, title, kind = library.get('key') or '', library.get('title') or 'Library', library.get('type') or ''
    saved = library_orders.sort_of('emby', 'emby', key, '')
    menu = [(tr('Sort: %s%s') % ('● ' if order == saved else '', label),
             'RunPlugin(%s)' % build_url(action='emby_sort', key=key, title=title, library_type=kind, current=saved))
            for label, order in _MEDIABROWSER_SORTS]
    saved_label = next((label for label, order in _MEDIABROWSER_SORTS if order == saved), '')
    add_item(title, build_url(action='emby_library', key=key, title=title, library_type=kind, sort=saved),
             art=root_art('emby'), context_menu=menu,
             info={'title': title, 'plot': tr('Sorted by: %s') % saved_label if saved_label else ''})


def mediabrowser_menu():
    """Emby / Jellyfin: link it, or Continue Watching and the libraries (each in its saved order)."""
    _set_render_section('emby')
    if not _emby.is_signed_in():
        add_item('Link Emby', build_url(action='emby_login'), is_folder=False, art=root_art('settings'),
                 info={'title': 'Link Emby'})
        return end_dir(content='files', cache=False)
    try:
        server = _emby_server()
        add_item('Continue Watching • Emby', build_url(action='emby_continue'), art=root_art('continue'),
                 info={'title': 'Continue Watching', 'plot': 'Pick up where you left off on Emby.'})
        for library in _emby.libraries(server):
            _add_mediabrowser_library(library)
    except Exception as exc:
        _emby_error(exc)
    add_item('[COLOR grey]Disconnect Emby[/COLOR]', build_url(action='emby_logout'), is_folder=False,
             art=root_art('settings'))
    end_dir(content='files', cache=False)


_EMBY_SORTS = [
    ('SortName', 'Name'),
    ('DateCreated:desc', 'Newest added'),
    ('PremiereDate:desc', 'Newest released'),
    ('ProductionYear:desc', 'Year'),
    ('CommunityRating:desc', 'Rating'),
]


def mediabrowser_sort(key, title='', library_type='', current=''):
    """Choose (and keep) the order of a Jellyfin / Emby library, then reopen it so."""
    saved = library_orders.sort_of('emby', 'emby', key, '') or current or 'SortName'
    choice = xbmcgui.Dialog().select(tr('Emby sort'), ['[COLOR limegreen]● %s[/COLOR]' % label if order == saved else label
                                                       for order, label in _EMBY_SORTS])
    if choice < 0:
        return
    order = _EMBY_SORTS[choice][0]
    library_orders.keep_sort('emby', 'emby', key, order)
    xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(action='emby_library', key=key, title=title,
                                                                    library_type=library_type, sort=order, start='0'))


def mediabrowser_library(key, title='', library_type='', start='0', sort=''):
    """A Jellyfin / Emby library page in its saved (or chosen) order, with More."""
    sort = sort or library_orders.sort_of('emby', 'emby', key, '') or 'SortName'
    try:
        first = int(start or 0)
        rows, total = _emby.children(_emby_server(), key, start=first, sort=sort,
                                     include_types='Series' if library_type == 'show' else 'Movie', recursive=True)
        _mediabrowser_rows(rows)
        if rows and total > first + len(rows):
            add_item('More', build_url(action='emby_library', key=key, title=title, library_type=library_type, sort=sort,
                                       start=str(first + len(rows))),
                     art=root_art('emby'), info={'title': 'More'})
    except Exception as exc:
        _emby_error(exc)
    end_dir(content='tvshows' if library_type == 'show' else 'movies', cache=False)


def mediabrowser_children(key, title='', start='0'):
    try:
        server = _emby_server()
        rows, total = _emby.children(server, key, start=int(start or 0))
        _mediabrowser_rows(rows)
        nxt = int(start or 0) + len(rows)
        if rows and total > nxt:
            add_item('More', build_url(action='emby_children', key=key, title=title,
                                          start=str(nxt)),
                     art=root_art('emby'), info={'title': 'More'})
    except Exception as exc:
        _emby_error(exc)
    end_dir(content='episodes', cache=False)


def mediabrowser_play(item_id, flavor=''):
    """Play a Jellyfin / Emby library item (its version chosen when it has several)."""
    _foreground_playback()
    try:
        server = _emby_server(flavor)
        item = _emby.metadata(server, item_id)
    except Exception as exc:
        return _emby_error(exc)
    version = _pick_version(list(item.get('versions') or []), item, _emby.artwork_url(server, item.get('thumb') or ''),
                            'Emby')
    if version is None:
        return
    source_id = version.get('media_source_id') or ''
    try:
        resolved = _emby.playable_of(server, item_id, source_id)
        url = resolved.get('url') or ''
        version = resolved.get('version') or version
        source_id = resolved.get('media_source_id') or source_id
    except Exception as exc:
        return _emby_error(exc)
    found = item.get('ids') or {}
    length = item.get('duration_ms') or 0
    session = resolved.get('play_session_id') or ''
    subtitles = list(version.get('subtitles') or [])
    ctx = dict(_server_item_ids(found), **{
        'media_type': 'series' if item.get('media_type') == 'episode' else 'movie',
        'canonical_id': _server_canonical(found, 'emby:%s' % item_id), 'video_id': str(item_id),
        'title': item.get('raw_title') or item.get('title') or 'Emby', 'show_title': item.get('show_title') or '',
        'stream_url': url, 'provider_id': 'emby_native',
        'provider_name': 'Emby Native • %s' % (server.get('name') or 'Server'), 'server_type': 'emby',
        'server_url': server.get('url') or '', 'server_flavor': _emby.flavor_of(server), 'token': server.get('token') or '',
        'item_id': str(item_id), 'device_id': _emby.device_id(), 'session_id': session, 'play_session_id': session,
        'media_source_id': source_id or '', 'native_playback_resolved': True,
        'poster': _emby.artwork_url(server, item.get('thumb') or ''),
        'background': _emby.artwork_url(server, item.get('art') or item.get('thumb') or '', kind='Backdrop'),
        'duration_ms': length, 'duration': int(length / 1000), 'season': item.get('season') or None,
        'episode': item.get('index') or None, 'subtitles': subtitles})
    ctx['stream_key'] = keyed_cache.put('stream', {
        'stream_url': url, 'name': item.get('title') or 'Emby',
        'provider_name_raw': 'Emby • %s' % (server.get('name') or ''), 'size_label': item.get('size_label') or '',
        'subtitles': subtitles})
    return _start_playback(ctx, stream_key=ctx['stream_key'], use_resolved_url=False)


def libraries_menu():
    add_item('Plex', build_url(action='plex_menu'), art=root_art('plex'),
             info={'title': 'Plex', 'plot': 'Link a Plex account and manage all servers and libraries.'})
    add_item('Emby / Jellyfin', build_url(action='emby_menu'), art=root_art('emby_jellyfin'),
             info={'title': 'Emby / Jellyfin', 'plot': 'Link the server and manage libraries and Continue Watching.'})
    return end_dir(content='files', cache=False)

def nuvio_cloud_menu():
    """Nuvio account: link (or by QR), sync now, unlink, collection import, sync timing and settings."""
    from resources.lib.meganexus import cloud_sync as sync
    linked = sync.NuvioCloud.is_linked()
    add_item('Nuvio • %s' % (tr('Linked ✓') if linked else tr('Link account')),
             build_url(action='account_sync_now', service='nuvio') if linked else build_url(action='nuvio_login'),
             is_folder=False, art=media_path('sync_accounts.png'),
             info={'title': 'Nuvio', 'plot': 'Sync addons and watch progress with your Nuvio account.'})
    if linked:
        add_item('Sync Nuvio now', build_url(action='account_sync_now', service='nuvio'), is_folder=False,
                 art=root_art('refresh'))
        add_item('Unlink Nuvio', build_url(action='nuvio_logout'), is_folder=False, art=root_art('settings'))
    else:
        add_item('Log in via QR', build_url(action='meganexus_qr_login'), is_folder=False, art=media_path('sync_accounts.png'))
    add_item('Import collection from JSON', build_url(action='nuvio_sync_import'), is_folder=False, art=root_art('add'),
             info={'title': 'Import collection from JSON', 'plot': 'Standalone collection tool — not account sync.'})
    add_item(tr('Sync mode and timing'), build_url(action='sync_options'), is_folder=False, art=root_art('refresh'),
             info={'title': tr('Sync mode and timing')})
    add_item('Sync settings', build_url(action='open_settings'), is_folder=False, art=root_art('settings'))
    return end_dir(content='files', cache=False)


def stremio_repair_library():
    try:
        from resources.lib.meganexus.cloud_sync import StremioCloud
        scanned, repaired = StremioCloud.mend_library()
        if repaired:
            notify(tr('Scanned %s items, repaired %s — reopen Stremio now') % (scanned, repaired))
        else:
            notify(tr('Scanned %s items — no broken dates found') % scanned)
    except Exception as exc:
        error(tr('Stremio library repair failed: %s') % exc)
    return stremio_cloud_menu()


def stremio_cloud_menu():
    """Stremio account: link (or by QR), sync now, unlink, sync timing and settings, library repair."""
    from resources.lib.meganexus import cloud_sync as sync
    linked = sync.StremioCloud.is_linked()
    add_item('Stremio • %s' % (tr('Linked ✓') if linked else tr('Link account')),
             build_url(action='account_sync_now', service='stremio') if linked else build_url(action='stremio_login'),
             is_folder=False, art=media_path('sync_accounts.png'),
             info={'title': 'Stremio', 'plot': 'Pulls installed addons and syncs watch progress.'})
    if linked:
        add_item('Sync Stremio now', build_url(action='account_sync_now', service='stremio'), is_folder=False,
                 art=root_art('refresh'))
        add_item('Unlink Stremio', build_url(action='stremio_logout'), is_folder=False, art=root_art('settings'))
    else:
        add_item('Log in via QR', build_url(action='stremio_qr_login'), is_folder=False, art=media_path('sync_accounts.png'))
    add_item(tr('Sync mode and timing'), build_url(action='sync_options'), is_folder=False, art=root_art('refresh'),
             info={'title': tr('Sync mode and timing')})
    add_item('Sync settings', build_url(action='open_settings'), is_folder=False, art=root_art('settings'))
    add_item(tr('Repair Stremio library (broken dates)'), build_url(action='stremio_repair_library'), is_folder=False,
             art=root_art('stremio'),
             info={'title': tr('Repair Stremio library (broken dates)'),
                   'plot': tr('Scans every cloud library item and fixes invalid timestamps that stop Stremio loading the '
                              'library (the LibraryItemsPulledFromAPI error)')})
    return end_dir(content='files', cache=False)

def _cloud_import_text(raw, source_label='Nuvio Sync'):
    result = _nuvio_sync_mod.take_backup(
        raw,
        source_label=source_label,
        manifest_resolver=_addon_manifest_finder(''),
    )
    notify(tr('Synced • %d add-ons • %d collections') % (
        int(result.get('providers') or 0), int(result.get('collections') or 0)))
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass
    return result


def nuvio_cloud_import():
    kb = xbmc.Keyboard('', tr('Paste a collection link or the full JSON'))
    kb.doModal()
    if not kb.isConfirmed():
        return nuvio_cloud_menu()
    raw = kb.getText().strip()
    if not raw:
        return nuvio_cloud_menu()
    try:
        if raw.startswith(('http://', 'https://')):
            text = _collections_mod.text_of(raw)
            _nuvio_sync_mod.set_sync_url(raw)
            _cloud_import_text(text, source_label='Nuvio Sync')
        else:
            _cloud_import_text(raw, source_label='Nuvio Import')
    except Exception as exc:
        error(tr('Import failed: %s') % exc)
    return nuvio_cloud_menu()


def _setup(page):
    """One page of the set-up centre (screens/setup_page), given this module."""
    return lambda: getattr(_setup_center_mod, page)(sys.modules[__name__])


setup_center, setup_playback, setup_subtitles, setup_quality, setup_stability, setup_diagnostics = (
    _setup(page) for page in ('render', 'playback', 'subtitles', 'quality', 'stability', 'diagnostics'))


_LINK_WORDS = {'connected': 'Connected', 'ready': 'Ready to link'}


def _preset_row(state, done_label, open_label, action, title, done_plot, open_plot):
    """A setup bundle's row: applied, or how many changes it would make."""
    if state['all_active']:
        add_item(tr(done_label), build_url(action=action), is_folder=False, art=root_art('settings'),
                 info={'title': title, 'plot': done_plot})
    else:
        add_item(tr(open_label) % state['missing_count'], build_url(action=action), is_folder=False, art=root_art('settings'),
                 info={'title': title, 'plot': open_plot})


def _helper_row():
    if not helper_player_file.has_tmdbhelper():
        add_item(tr('[COLOR grey]TMDb Helper is not installed[/COLOR]'), build_url(action='integrations_menu'),
                 is_folder=False, art=root_art('tmdb'))
    elif helper_player_file.player_installed():
        add_item(tr('TMDb Helper - registered'), build_url(action='tmdbh_install'), is_folder=False, art=root_art('tmdb'),
                 info={'title': 'TMDb Helper', 'plot': 'MegaNexus is registered as a player in TMDb Helper. Its button '
                       'appears in the player list when you press Play on any item inside TMDb Helper widgets.'},
                 context_menu=[('Unregister MegaNexus from TMDb Helper',
                                'RunPlugin(%s)' % build_url(action='tmdbh_uninstall'))])
    else:
        add_item(tr('TMDb Helper • Not registered'), build_url(action='tmdbh_install'), is_folder=False, art=root_art('tmdb'),
                 info={'title': 'TMDb Helper', 'plot': 'Press to register MegaNexus as a player'})


def services_menu():
    """Accounts and services: libraries, the setup bundles, Trakt / Simkl / MDBList, TMDb Helper,
    metadata add-ons, backup and settings."""
    add_item('Accounts & sync', build_url(action='sync_accounts_menu'), art=media_path('sync_accounts.png'),
             info={'title': 'Nuvio + Stremio', 'plot': 'Nuvio for Continue Watching, Stremio for addons and Continue Watching.'})
    add_item('Libraries', build_url(action='media_libraries_menu'), art=media_path('media_libraries.png'),
             info={'title': 'Plex + Emby / Jellyfin', 'plot': 'Link and manage your home libraries.'})
    _preset_row(_suggested_setup_state(), 'Recommended setup - applied',
                '[COLOR yellow]Recommended setup - %d changes available[/COLOR]', 'apply_recommended_preset',
                tr('Recommended setup'),
                tr('Quality profile "Balanced (recommended)" + full performance tuning + source filtering enabled. Press to '
                   're-apply if you changed any setting.'),
                tr('One bundle that makes MegaNexus ready for most users: a balanced quality profile, lite mode, and a '
                   'larger cache for lists and metadata. You lose no sources — they all stay on the Sources page.'))
    _preset_row(_speed_mode_now(), 'Performance tuning - applied',
                '[COLOR yellow]Performance tuning - %d improvements available[/COLOR]', 'apply_performance_preset',
                'Performance tuning',
                'Every lite-mode optimisation is active: lite mode + maximum catalog cache + maximum metadata cache + '
                'MegaNexus as the default TMDb Helper player. Press to re-apply if you changed any setting.',
                'One bundle that speeds up posters and lists on slower devices: maximum catalog and metadata cache, lite '
                'mode, and MegaNexus as the default TMDb Helper player.')
    trakt_state = trakt_api.authorization_status()
    add_item('Trakt • %s' % dict(_LINK_WORDS, needs_api='Needs API').get(trakt_state, trakt_state or '—'),
             build_url(action='trakt_menu'), art=root_art('trakt'),
             info={'title': 'Trakt', 'plot': 'Link/unlink, import progress, watch history, your lists'})
    simkl_state = simkl_api.authorization_status()
    add_item('Simkl • %s' % tr(dict(_LINK_WORDS, needs_api='Needs a Client ID').get(simkl_state, simkl_state or '—')),
             build_url(action='simkl_menu'), art=root_art('simkl'),
             info={'title': 'Simkl', 'plot': tr('Link/unlink, watch-history sync, your lists (watching/plan/completed)')})
    add_item('MDBList • %s' % tr('Connected' if mdblist.configured() else 'Needs an API Key'), build_url(action='mdblist_menu'),
             art=root_art('mdblist'), info={'title': 'MDBList', 'plot': tr('Your MDBList watchlist and lists inside MegaNexus')})
    _helper_row()
    add_item(tr('Metadata add-ons'), build_url(action='meta_sources_menu'), is_folder=True, art=root_art('catalogs'),
             info={'title': 'Metadata add-ons', 'plot': 'Choose the metadata add-on for each type (Movies/TV/Anime)'})
    add_item(tr('Export settings and add-ons'), build_url(action='config_export'), is_folder=False, art=root_art('settings'),
             info={'title': tr('Export settings and add-ons'),
                   'plot': 'Save your whole setup (add-ons, pinned catalogs, add-on order, settings) into one portable JSON '
                           'file you can move to another device or restore after reinstalling Kodi.'})
    add_item(tr('Import settings and add-ons'), build_url(action='config_import'), is_folder=False, art=root_art('settings'),
             info={'title': tr('Import settings and add-ons'),
                   'plot': 'Restore your whole setup from a previously exported JSON file. This replaces the current setup '
                           'with the one in the file.'})
    add_item(tr('Settings'), build_url(action='open_settings'), is_folder=False, art=root_art('settings'),
             info={'title': 'Settings', 'plot': 'Open MegaNexus settings'})
    add_item(tr('Quality badges'), build_url(action='badges_url'), is_folder=False, art=root_art('settings'),
             info={'title': tr('Quality badges'), 'plot': tr('Set the badges JSON URL or go back to the built-in set')})
    end_dir()


def meta_source_menu():
    """Metadata add-ons: each add-on with the metadata source it uses (a warning where a
    stream-only add-on would show its own), and reset all."""
    try:
        from . import meta_choice
    except Exception as exc:
        error('meta_choice module missing: %s' % exc)
        return end_dir()
    addons = addon_registry.list_providers() or []
    if not addons:
        add_item(tr('[COLOR grey]No add-ons — add a manifest URL first[/COLOR]'), build_url(action='add_provider'),
                 is_folder=True, art=root_art('add'))
        return end_dir()
    add_item(tr('[COLOR yellow]ℹ Each addon can use its own metadata add-on[/COLOR]'), build_url(action='meta_sources_menu'),
             is_folder=False, art=root_art('catalogs'),
             info={'title': 'Metadata add-ons', 'plot': 'Automatic = smart (Plex/Emby gets replaced, others stay native)'})
    for addon in addons:
        addon_id = addon.get('id') or ''
        name = addon.get('name') or addon_id or 'Provider'
        chosen = meta_choice.choice_for(addon_id)
        warn = ' [COLOR orange]⚠[/COLOR]' if meta_choice.stream_only(addon) and chosen == 'native' else ''
        add_item('%s → %s%s' % (name, meta_choice.label_of(chosen), warn),
                 build_url(action='meta_pick_for_provider', provider_id=addon_id), is_folder=True,
                 art=provider_art(name, addon.get('manifest') or {}, base_url=addon.get('base_url') or ''),
                 info={'title': name, 'plot': 'Press to change the metadata add-on for this addon'})
    add_item(tr('[COLOR grey]─ Reset all to "Automatic" ─[/COLOR]'), 'RunPlugin(%s)' % build_url(action='meta_reset_all'),
             is_folder=False, art=root_art('providers'))
    end_dir()


def meta_choice_for_addon(provider_id=''):
    if not provider_id:
        return
    provider = addon_registry.get_provider(provider_id)
    if not provider:
        error(tr('Addon not found'))
        return
    return _meta_choice_for(provider_id, tr('Metadata %s') % (provider.get('name') or provider_id))


def meta_reset_all():
    try:
        from . import meta_choice as _meta_choice
        _meta_choice.forget_choices()
        _meta_mem_clear()
        notify(tr('Reset completed'))
    except Exception as exc:
        error(tr('Failed: %s') % exc)
    xbmc.executebuiltin('Container.Refresh')


_SERVER_TARGETS = {'plex_server': 'Plex', 'emby_server': 'Emby'}


def _meta_source_choices(target_key):
    """The metadata sources offered for a target (an add-on never itself; a media server only
    automatic, TMDb Helper or its own posters) and the target's title."""
    from . import meta_choice
    sources, title = meta_choice.choices(), ''
    addon = addon_registry.get_provider(target_key)
    if addon:
        sources = [s for s in sources if s.get('id') != target_key]
        title = addon.get('name') or target_key
    server = _SERVER_TARGETS.get(target_key)
    if server:
        sources = [s for s in sources if s.get('id') in ('auto', 'tmdb_helper', 'native')]
        for source in sources:
            if source.get('id') == 'native':
                source['name'] = tr('The %s posters themselves (overlays are kept)') % server
    return sources, title


def _meta_choice_for(target_key='', title=''):
    """Choose the metadata source of a section / add-on / server from a list (the current one preselected)."""
    try:
        from . import meta_choice
    except Exception as exc:
        error('meta_choice missing: %s' % exc)
        return
    if not target_key:
        return
    sources, own_title = _meta_source_choices(target_key)
    title = title or own_title
    current = meta_choice.choice_for(target_key)
    at = next((place for place, source in enumerate(sources) if source.get('id') == current), 0)
    choice = xbmcgui.Dialog().select(tr(title or tr('Choose metadata add-on')),
                                     [tr(s.get('name') or s.get('id') or 'Source') for s in sources], preselect=at)
    if choice < 0:
        return
    picked = sources[choice]
    meta_choice.choose(target_key, picked.get('id') or 'auto')
    _meta_mem_clear()
    notify('%s → %s' % (title or target_key, picked.get('name') or picked.get('id') or ''))
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def _set_render_section(section):
    try:
        xbmcgui.Window(WINDOW_ID).setProperty('meganexus.render_bucket', str(section or ''))
    except Exception:
        pass


def open_settings_action():
    open_addon_settings()


def sync_options_action():
    return _accounts_route_mod.sync_options(ADDON, tr, _setting)


def badges_url_action():
    """Quality badge settings live in the frontend, with Nuvio JSON previews."""
    xbmc.executebuiltin('RunScript(script.meganexus,badges)')


def _secure_url(manifest_url, silent=False):
    """An http:// manifest moved to https:// when that works; else plain http only after the user
    accepts the warning (never without asking: None)."""
    if not manifest_url or not manifest_url.lower().startswith('http://'):
        return manifest_url
    secure = 'https://' + manifest_url[len('http://'):]
    try:
        manifest_ok(secure)
        xbmc.log('[MegaNexus] HTTPS upgrade succeeded for %s -> %s' % (manifest_url, secure), xbmc.LOGINFO)
        notify(tr('URL automatically upgraded to HTTPS'))
        return secure
    except Exception as exc:
        xbmc.log('[MegaNexus] HTTPS upgrade not possible for %s: %s' % (manifest_url, exc), xbmc.LOGINFO)
    if silent:
        xbmc.log('[MegaNexus] refusing http-only manifest for a headless caller: %s' % manifest_url, xbmc.LOGWARNING)
        error(tr('This add-on uses unencrypted HTTP. Add it from the TV to accept the warning.'))
        return None
    accepted = xbmcgui.Dialog().yesno(
        'MegaNexus', tr('This add-on uses unencrypted HTTP. Anyone on the same network could intercept or tamper with the '
                        'data. Continue at your own risk?'),
        nolabel=tr('Cancel'), yeslabel=tr('Continue on HTTP'), defaultbutton=xbmcgui.DLG_YESNO_NO_BTN)
    return manifest_url if accepted else None


def _ask_manifest_address():
    keyboard = xbmc.Keyboard('', tr('Paste a manifest.json or collections.json URL'))
    keyboard.doModal()
    return keyboard.getText().strip() if keyboard.isConfirmed() else ''


def add_provider(manifest_url=''):
    """Add a Stremio add-on by its manifest (a collections link becomes its manifest); typed in
    when no address was given."""
    given = (manifest_url or '').strip()
    url = given or _ask_manifest_address()
    if not url:
        return end_dir()
    try:
        from_collection = _collections_mod.manifest_of_collection(url)
    except Exception:
        from_collection = ''
    converted = bool(from_collection and from_collection != url)
    url = _secure_url(from_collection or url, silent=bool(given))
    if not url:
        notify(tr('Add-on addition cancelled'))
        return end_dir()
    try:
        manifest = manifest_ok(url)
        name = manifest.get('name') or manifest.get('id') or 'Provider'
        addon_registry.add_provider(name=name, manifest_url=url, manifest=manifest)
        notify((tr('Add-on added from collection URL: %s') if converted else tr('Added add-on: %s')) % name)
    except Exception as exc:
        error(tr('Add-on add failed: %s') % exc)
    if given:
        _forget_quietly(lambda: xbmc.executebuiltin('Container.Refresh'))
        return
    return providers()

def _refresh_addon_logos(addons):
    """Add-ons saved without a logo get their manifest read again (in the background)."""
    for addon in addons:
        try:
            url = addon.get('manifest_url') or ''
            fresh = manifest_ok(url) if url else None
            if fresh and (fresh.get('logo') or fresh.get('icon') or '').strip():
                addon_registry.reload_manifest(addon.get('id'), fresh)
        except Exception as exc:
            xbmc.log('[MegaNexus] manifest logo refresh failed for %s: %s' % (addon.get('name', ''), exc), xbmc.LOGDEBUG)


def _add_addon_row(addon, place, total):
    name, addon_id = addon.get('name') or addon.get('id'), addon.get('id')
    label = '[%d/%d]  %s' % (place, total, name)
    menu = [(tr('Change add-on position'), 'RunPlugin(%s)' % build_url(action='provider_set_position',
                                                                       provider_id=addon_id))] if total >= 2 else []
    menu += [(tr('Change metadata add-on'), 'RunPlugin(%s)' % build_url(action='meta_pick_for_provider', provider_id=addon_id)),
             ('Refresh this add-on', 'RunPlugin(%s)' % build_url(action='refresh_provider', provider_id=addon_id)),
             ('Remove this add-on', 'RunPlugin(%s)' % build_url(action='remove_provider', provider_id=addon_id)),
             ('Open filters and categories', 'Container.Update(%s)' % build_url(action='provider_menu', provider_id=addon_id))]
    plot = ((addon.get('manifest') or {}).get('description') or addon.get('manifest_url') or '') + tr(
        '\n\nCurrent position: %d of %d. To change it, open the context menu and choose "Change add-on order".') % (place, total)
    add_item(label, build_url(action='provider_menu', provider_id=addon_id), info={'title': label, 'plot': plot},
             art=provider_art(name, addon.get('manifest') or {}, base_url=addon.get('base_url') or ''), context_menu=menu)


def providers():
    """Add-ons: accounts, libraries, add one, then the installed add-ons in their order."""
    _set_render_section('stremio')
    addons = addon_registry.list_providers()
    add_item('Accounts & sync', build_url(action='sync_accounts_menu'), art=media_path('sync_accounts.png'),
             info={'title': 'Nuvio + Stremio', 'plot': 'Nuvio for Continue Watching, Stremio for addons and Continue Watching.'})
    add_item('Libraries', build_url(action='media_libraries_menu'), art=media_path('media_libraries.png'),
             info={'title': 'Plex + Emby / Jellyfin', 'plot': 'Link and manage your home libraries.'})
    add_item(tr('Add a Stremio add-on'), build_url(action='add_provider'), art=root_art('add'),
             info={'title': 'Add Manifest URL', 'plot': 'Add the manifest.json of any Stremio addon.'})
    if not addons:
        add_item(tr('[COLOR grey]No Stremio addons installed[/COLOR]'), build_url(action='first_run_wizard'), is_folder=False,
                 art=root_art('providers'), info={'title': 'Add-ons', 'plot': 'Use Stremio sync or add a manifest URL manually.'})
        return end_dir(content='files', cache=False)
    unlogoed = [a for a in addons if not (a.get('manifest') or {}).get('logo') and not (a.get('manifest') or {}).get('icon')]
    if unlogoed:
        _submit_optional(_refresh_addon_logos, args=(unlogoed,), key='provider-logo-refresh')
    for place, addon in enumerate(addons, start=1):
        _add_addon_row(addon, place, len(addons))
    end_dir()


def _add_catalog_entry(addon, addon_id, catalog):
    name = catalog.get('name') or catalog.get('id') or 'Catalog'
    kind = catalog.get('type')
    plot = catalog.get('description') or tr('Browse %s section') % name
    extras = [x.get('name') for x in catalog.get('extra') or [] if isinstance(x, dict) and x.get('name') not in ('skip',)]
    if extras:
        plot += '\nExtras: ' + ', '.join(extras)
    menu = (_catalog_menu_entries(addon, catalog, _catalog_section(addon, catalog))
            + _catalog_filter_menu(provider_id=addon_id, media_type=kind, catalog_id=catalog.get('id') or '', catalog_def=catalog))
    add_item(name, build_url(action='catalog_all', provider_id=addon_id, media_type=kind, catalog_id=catalog.get('id'),
                             label=name),
             info={'title': name, 'plot': plot}, art=catalog_art(name, kind, addon.get('manifest') or {}, catalog),
             context_menu=menu)


def addon_menu(provider_id):
    """One add-on: its catalogs, search per type, refresh and delete."""
    addon = addon_registry.get_provider(provider_id)
    if not addon:
        return end_dir()
    for catalog in _addon_catalogs(addon):
        _add_catalog_entry(addon, provider_id, catalog)
    for kind in _types_offered(addon):
        if _addon_searchable(addon, kind):
            label = tr('Search %s') % _group_title(kind)
            add_item(label, build_url(action='search', media_type=kind, provider_id=provider_id),
                     info={'title': label, 'plot': tr('Search inside %s') % (addon.get('name') or 'Provider')},
                     art=root_art('search_movie' if kind == 'movie' else 'search_series'))
    add_item(tr('Refresh manifest'), build_url(action='refresh_provider', provider_id=provider_id), art=root_art('providers'),
             info={'title': tr('Refresh manifest'), 'plot': _addon_summary(addon)})
    add_item(tr('Delete add-on'), build_url(action='remove_provider', provider_id=provider_id), art=root_art('add'))
    end_dir()


def remove_provider(provider_id):
    provider = addon_registry.get_provider(provider_id)
    if provider and xbmcgui.Dialog().yesno('MegaNexus', tr('Delete add-on: %s?') % provider.get('name')):
        addon_registry.remove_provider(provider_id)
        try:
            from . import catalog_index as index_render
            index_render.get_db().forget_provider(provider_id)
        except Exception as _exc:
            xbmc.log('[MegaNexus] purge_provider failed: %s' % _exc, xbmc.LOGWARNING)
        notify(tr('Add-on deleted'))
    return providers()


def _safe_metadata_rating(value):
    try:
        number = float(str(value or 0).replace(',', '.'))
        return number if 0.0 <= number <= 10.0 else 0.0
    except (TypeError, ValueError, OverflowError):
        return 0.0


_YOUTUBE_PLAY = 'plugin://plugin.video.youtube/play/?video_id=%s'


_STUDIO_KEYS = ('studios', 'production_companies', 'studio', 'network', 'networks')


def _as_names(value):
    return value if isinstance(value, list) else [str(value)]


def _meta_trailer(meta):
    """A trailer Kodi's Trailer button can play: the given link, or the first YouTube trailer
    (never a YouTube link when the YouTube add-on may not be used)."""
    trailer = meta.get('trailer') or ''
    listed = meta.get('trailers')
    if not trailer and isinstance(listed, list) and listed:
        first = listed[0]
        if isinstance(first, dict) and first.get('source'):
            trailer = _YOUTUBE_PLAY % first['source']
        elif isinstance(first, str):
            trailer = _YOUTUBE_PLAY % first
    if trailer.startswith('plugin://plugin.video.youtube/'):
        try:
            from .trailer_support import youtube_allowed
            trailer = trailer if youtube_allowed() else ''
        except Exception:
            trailer = ''
    return trailer


def _meta_cast(meta):
    cast = []
    for person in (meta.get('cast') or meta.get('credits_cast') or [])[:25]:
        if isinstance(person, dict):
            cast.append({'name': str(person.get('name') or '').strip(),
                         'role': str(person.get('character') or person.get('role') or '').strip(),
                         'thumbnail': str(person.get('photo') or person.get('thumbnail') or person.get('profile_path')
                                          or '').strip()})
        elif isinstance(person, str) and person.strip():
            cast.append({'name': person.strip(), 'role': '', 'thumbnail': ''})
    return cast


def _meta_studios(meta):
    """Studios / networks once each (case-blind): a list, one name, or None."""
    names, seen = [], set()
    for key in _STUDIO_KEYS:
        value = meta.get(key)
        if not value:
            continue
        for entry in (value if isinstance(value, list) else [value] if isinstance(value, str) else []):
            name = (str(entry['name']).strip() if isinstance(entry, dict) and entry.get('name') else
                    entry.strip() if isinstance(entry, str) else '')
            if name and name.lower() not in seen:
                seen.add(name.lower())
                names.append(name)
    return (names if len(names) > 1 else names[0]) if names else None


def _info_of(meta):
    """Kodi's video information for an add-on's meta."""
    release = str(meta.get('releaseInfo') or meta.get('year') or '')
    found_year = YEAR_RE.search(release) if release else None
    found_date = re.search(r'(\d{4}-\d{2}-\d{2})', release) if release else None
    premiered = found_date.group(1) if found_date else ''
    title = str(meta.get('name') or meta.get('title') or 'Unknown').strip() or 'Unknown'
    info = {'title': title, 'sorttitle': title, 'plot': meta.get('description') or meta.get('overview') or '',
            'year': int(found_year.group(1)) if found_year else 0,
            'genre': ' / '.join(_text_list(meta.get('genres') or meta.get('genre'))),
            'rating': _safe_metadata_rating(meta.get('imdbRating') or meta.get('rating')), 'premiered': premiered,
            'date': premiered, 'mediatype': 'tvshow' if meta.get('type') == 'series' else 'movie'}
    minutes = re.match(r'\s*(\d+)', str(meta.get('runtime') or '').strip()) if meta.get('runtime') else None
    if minutes and int(minutes.group(1)):
        info['duration'] = int(minutes.group(1)) * 60
    for key in ('director', 'writer', 'country'):
        if meta.get(key):
            info[key] = _as_names(meta[key])
    if meta.get('tagline'):
        info['tagline'] = str(meta['tagline'])
    if meta.get('trailer') or meta.get('trailers'):
        trailer = _meta_trailer(meta)
        if trailer:
            info['trailer'] = trailer
    if meta.get('certification'):
        info['mpaa'] = str(meta['certification'])
    if meta.get('imdbRating') and meta.get('imdb_votes'):
        try:
            info['votes'] = int(meta['imdb_votes'])
        except Exception:
            pass
    cast = _meta_cast(meta)
    if cast:
        info['cast'] = cast
    studios = _meta_studios(meta)
    if studios:
        info['studio'] = studios
    imdb = extract_ids(meta).get('imdb_id')
    if imdb:
        info['imdbnumber'] = imdb
    return info


def _split_names(text):
    return [part.strip() for part in re.split(r'[,/]', text) if part.strip()]


def _text_list(value):
    """Names from a value ('A, B', 'A / B', a list of names or of {'name': …}), each once (case-blind)."""
    if value in (None, ''):
        return []
    names = []
    if isinstance(value, (list, tuple)):
        for item in value:
            if isinstance(item, dict):
                name = str(item.get('name') or item.get('title') or '').strip()
                names += [name] if name else []
            else:
                text = str(item or '').strip()
                names += (_split_names(text) if ',' in text or '/' in text else [text]) if text else []
    else:
        text = str(value or '').strip()
        names = _split_names(text) if text else []
    seen, out = set(), []
    for name in names:
        if name.lower() and name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)
    return out


_STUDIO_FIELDS = ('studios', 'production_companies', 'productionCompanies', 'network', 'networks', 'studio')


_NAME_LISTS = ('studio', 'country', 'director', 'writer', 'genre')


def _minutes_to_seconds(runtime):
    """'90 min' / 90 -> 5400 (values of 10000 or more are already seconds)."""
    if isinstance(runtime, str):
        found = re.search(r'(\d+(?:\.\d+)?)', runtime)
        number = float(found.group(1)) if found else 0.0
    else:
        number = float(runtime)
    return int(number * 60) if number and number < 10000 else int(number)


def _stream_info(best_meta, media_type='', title='', show_title='', season=None, episode=None):
    """The video information a source carries to the player (the title's, as an episode when it is one)."""
    meta = best_meta or {}
    try:
        info = dict(_info_of(meta) or {})
    except Exception:
        info = {}
    if title:
        info['title'] = title
    if _shown_number(season) or _shown_number(episode):
        info['mediatype'] = 'episode'
        for key, value in (('season', season), ('episode', episode)):
            try:
                info[key] = int(value or 0)
            except Exception:
                info[key] = 0
        show = show_title or meta.get('name') or meta.get('title')
        if show:
            info['tvshowtitle'] = show
    else:
        kind = str(media_type or meta.get('type') or '').lower()
        info['mediatype'] = 'tvshow' if kind in ('series', 'show', 'tv', 'anime', 'tvshow') else 'movie'
    for key in _NAME_LISTS:
        if info.get(key) not in (None, ''):
            names = _text_list(info[key])
            if names:
                info[key] = names
    if not info.get('studio'):
        studios = [name for key in _STUDIO_FIELDS for name in _text_list(meta.get(key))]
        if studios:
            info['studio'] = studios
    if not info.get('genre'):
        genres = _text_list(meta.get('genres') or meta.get('genre'))
        if genres:
            info['genre'] = genres
    if not info.get('duration'):
        runtime = meta.get('runtime') or meta.get('duration') or ''
        try:
            if runtime or isinstance(runtime, str):
                info['duration'] = _minutes_to_seconds(runtime)
        except Exception:
            pass
    return dict((k, v) for k, v in info.items() if v not in (None, '', [], {}))


def _tmdb_kind_of(ctx):
    ctx = ctx or {}
    if ctx.get('season') not in (None, '', 0, '0') or ctx.get('episode') not in (None, '', 0, '0'):
        return 'tv'
    mt = str(ctx.get('media_type') or '').strip().lower()
    if mt in ('series', 'show', 'tv', 'anime', 'tvshow'):
        return 'tv'
    return 'movie'


_PLAY_SHOW_PICTURES = (('tvshow.clearlogo', 'clearlogo'), ('tvshow.clearart', 'clearart'), ('tvshow.poster', 'poster'),
                       ('tvshow.thumb', 'poster'), ('tvshow.fanart', 'fanart'), ('tvshow.landscape', 'landscape'),
                       ('season.poster', 'poster'), ('season.thumb', 'poster'))


def _play_pictures_of(ctx):
    """The player item's pictures (the full handoff also names them as the show's and season's)."""
    ctx = ctx or {}
    poster = ctx.get('poster') or ctx.get('thumb') or ''
    fanart = ctx.get('background') or ctx.get('fanart') or poster or neutral_fanart()
    base = {'poster': poster, 'fanart': fanart, 'clearlogo': ctx.get('clearlogo') or ctx.get('logo') or '',
            'landscape': ctx.get('landscape') or fanart, 'clearart': ctx.get('clearart') or '', 'banner': ctx.get('banner') or ''}
    art = dict(base, thumb=poster, icon=poster, thumbnail=poster, fanart_image=fanart, logo=base['clearlogo'])
    if not _safe_start_on():
        art.update((slot, base[key]) for slot, key in _PLAY_SHOW_PICTURES)
    return dict((k, v) for k, v in art.items() if v)


def _stored_logo_for(ctx):
    ctx = ctx or {}
    if ctx.get('clearlogo') or ctx.get('logo'):
        return ctx.get('clearlogo') or ctx.get('logo') or ''
    try:
        ids = _playback_ids_of(ctx)
    except Exception:
        ids = {}
    tmdb_id = str(ids.get('tmdb_id') or ctx.get('tmdb_id') or '').strip()
    imdb_id = str(ids.get('imdb_id') or ctx.get('imdb_id') or '').strip()
    if not (tmdb_id or imdb_id):
        return ''
    media_type = 'tv' if _tmdb_kind_of(ctx) == 'tv' else 'movie'
    try:
        from .tmdb_helper_db import stored_logo
        return stored_logo(tmdb_id=tmdb_id, media_type=media_type, imdb_id=imdb_id) or ''
    except Exception:
        return ''


def _with_playback_pictures(ctx):
    out = dict(ctx or {})
    logo = out.get('clearlogo') or out.get('logo') or _stored_logo_for(out)
    if logo:
        out['clearlogo'] = logo
        out['logo'] = logo
    return out

def _int_or_zero(value, default=0):
    try:
        return int(float(str(value).strip()))
    except Exception:
        try:
            m = YEAR_RE.search(str(value or ''))
            return int(m.group(1)) if m else default
        except Exception:
            return default


def _shown_number(value):
    return value not in (None, '', 0, '0')


def _play_info_of(ctx):
    """The player item's video information: the source's own, completed from the playback."""
    ctx = ctx or {}
    info = dict(ctx.get('kodi_info') or {})
    episode = _shown_number(ctx.get('season')) or _shown_number(ctx.get('episode'))
    if ctx.get('title'):
        info['title'] = ctx['title']
    info['year'] = _int_or_zero(ctx.get('year') or info.get('year') or 0, 0)
    info['mediatype'] = 'episode' if episode else ('tvshow' if _tmdb_kind_of(ctx) == 'tv' else 'movie')
    if episode:
        info['season'] = _int_or_zero(ctx.get('season') or info.get('season') or 0, 0)
        info['episode'] = _int_or_zero(ctx.get('episode') or info.get('episode') or 0, 0)
        info['tvshowtitle'] = ctx.get('show_title') or info.get('tvshowtitle') or ctx.get('title') or ''
    for key in ('plot', 'genre', 'studio'):
        if ctx.get(key) and not info.get(key):
            info[key] = ctx[key]
    if ctx.get('rating') not in (None, '') and not info.get('rating'):
        try:
            info['rating'] = float(ctx['rating'])
        except Exception:
            pass
    if ctx.get('duration_ms') and not info.get('duration'):
        try:
            info['duration'] = int(float(ctx['duration_ms']) / 1000.0)
        except Exception:
            pass
    if ctx.get('imdb_id'):
        info['imdbnumber'] = ctx['imdb_id']
    for key in ('studio', 'country', 'director', 'writer', 'genre'):
        if info.get(key) not in (None, ''):
            names = _text_list(info[key])
            if names:
                info[key] = names
    return dict((k, v) for k, v in info.items() if v not in (None, '', [], {}))


_PLAYER_ID_PROPS = (('tmdb_id', 'tmdb_id'), ('imdb_id', 'imdb_id'), ('tvdb_id', 'tvdb_id'), ('imdb', 'imdb_id'),
                    ('imdbnumber', 'imdb_id'), ('IMDBNumber', 'imdb_id'))


_PLAYER_ID_PROPS_FULL = (('VideoPlayer.IMDBNumber', 'imdb_id'), ('VideoPlayer.UniqueID(imdb)', 'imdb_id'),
                         ('VideoPlayer.UniqueID(tmdb)', 'tmdb_id'), ('VideoPlayer.UniqueID(tvdb)', 'tvdb_id'))


_SAFE_PICTURES = ('poster', 'thumb', 'icon', 'thumbnail', 'fanart', 'fanart_image', 'landscape', 'clearlogo', 'logo',
                  'clearart', 'banner')


def _joined_names(value):
    return ' / '.join(value if isinstance(value, (list, tuple)) else _text_list(value))


def _player_props(ctx, art, info):
    """The player item's properties skins and TMDb Helper read: ids, the title's facts and pictures
    (the safe handoff carries fewer of them)."""
    ctx, art, info = ctx or {}, art or {}, info or {}
    safe = _safe_start_on()
    values = [('tmdb_type', _tmdb_kind_of(ctx))]
    values += [(name, ctx.get(key) or '') for name, key in _PLAYER_ID_PROPS + (() if safe else _PLAYER_ID_PROPS_FULL)]
    values += [(key, ctx.get(key) if ctx.get(key) not in (None, '') else '') for key in ('season', 'episode')]
    values += [('title', info.get('title') or ctx.get('title') or ''),
               ('tvshowtitle', info.get('tvshowtitle') or ctx.get('show_title') or ''),
               ('year', info.get('year') or ctx.get('year') or ''),
               ('studio', _joined_names(info.get('studio'))), ('genre', _joined_names(info.get('genre'))),
               ('rating', info.get('rating') or ctx.get('rating') or ''), ('plot', info.get('plot') or ctx.get('plot') or '')]
    if not safe:
        values += [('premiered', info.get('premiered') or ''), ('duration', info.get('duration') or '')]
    props = dict((name, str(value)) for name, value in values if value not in (None, ''))
    pictures = ((key, art.get(key)) for key in _SAFE_PICTURES) if safe else art.items()
    props.update((key, str(value)) for key, value in pictures if value)
    return props


def _detail_kind(media_type):
    return 'series' if media_type in ('series', 'show', 'tv', 'tvshow', 'anime') else 'movie'


def _kept_details(metas, kind, source):
    """{place: the cached full meta (keeping the listing's id and type)} and the places without one."""
    kept, missing, places = {}, [], {}
    for place, meta in enumerate(metas):
        meta_id = str((meta or {}).get('id') or '').strip()
        if meta_id:
            places.setdefault(meta_id, []).append(place)
        else:
            missing.append(place)
    try:
        from . import detail_cache
        found = detail_cache.get_many(kind, list(places), source_id=source or 'auto') if places else {}
    except Exception:
        return {}, list(range(len(metas)))
    for meta_id, spots in places.items():
        for place in spots:
            if found.get(meta_id):
                listed = metas[place] or {}
                kept[place] = dict(found[meta_id], **dict((k, listed[k]) for k in ('id', 'type') if listed.get(k)))
            else:
                missing.append(place)
    return kept, missing


def _complete_listing_metas(provider, media_type, metas):
    """A catalog page's metas made whole: the chosen metadata source applied, pictures made loadable,
    full details from the cache or (with 'deep meta' on) from the add-on, fanart.tv pictures added."""
    source = 'auto'
    try:
        from . import meta_choice
        source = meta_choice.choice_for((provider or {}).get('id') or '') or 'auto'
        metas = meta_choice.apply_many(provider, media_type, metas)
    except Exception as exc:
        xbmc.log('[MegaNexus] meta override failed: %s' % exc, xbmc.LOGWARNING)
    metas = [_meta_picture_urls(provider, meta) for meta in metas or []]
    kind = _detail_kind(media_type)
    kept, missing = _kept_details(metas, kind, source)
    if (source not in ('', 'auto', 'native') or _addon_keeps_pictures(provider)
            or not ADDON.getSettingBool('deep_meta_enrich') or not metas):
        return [_with_fanart_tv(kept.get(place) or meta, media_type) for place, meta in enumerate(metas)]

    def full(meta):
        try:
            return fetch_meta(provider, media_type, meta.get('id'), timeout_override=fast_timeout('meta')).get('meta') or {}
        except Exception:
            return {}
    answers = all_at_once(full, [metas[place] for place in missing]) if missing else []
    fetched = {}
    for spot, place in enumerate(missing):
        try:
            deep = answers[spot][1]
            fetched[place] = {} if isinstance(deep, Exception) else deep
        except Exception:
            fetched[place] = {}
    try:
        from . import detail_cache
    except Exception:
        detail_cache, kind = None, 'movie'
    out = []
    for place, meta in enumerate(metas):
        base = kept.get(place) or meta
        deep = {} if place in kept else (fetched.get(place) or {})
        if deep:
            base = _meta_picture_urls(provider, dict(meta, **dict((k, v) for k, v in deep.items()
                                                                  if v not in (None, '', [], {}))))
            meta_id = str((base or {}).get('id') or meta.get('id') or '').strip()
            if detail_cache is not None and meta_id:
                try:
                    detail_cache.put(kind, meta_id, base, source_id=source or 'auto')
                except Exception:
                    pass
        out.append(_with_fanart_tv(base, media_type))
    return out


def _with_fanart_tv(meta, media_type):
    try:
        from . import fanart_tv as _ft
    except Exception:
        return meta
    if not isinstance(meta, dict):
        return meta
    try:
        ids = extract_ids(meta) or {}
        return _ft.fill_meta(
            meta, media_type,
            tmdb_id=ids.get('tmdb_id') or '',
            tvdb_id=ids.get('tvdb_id') or '',
            imdb_id=ids.get('imdb_id') or '',
        )
    except Exception:
        return meta


def _filter_now(provider_id, catalog_id):
    return dict(addon_registry.catalog_settings(provider_id, catalog_id) or {})


def _filters_offered(catalog_def):
    """The catalog's extras a user can choose (paging - 'skip' - is ours to set)."""
    return [extra for extra in catalog_def.get('extra') or [] if isinstance(extra, dict) and extra.get('name') != 'skip']


# extras that order or page a catalog, and extras that divide it into folders
_SORT_LIKE_EXTRAS = frozenset('sort sortby orderby order limit search skip'.split())
_CATEGORY_LIKE_EXTRAS = frozenset('genre year category language country network studio contentrating collection type'.split())


def _extra_key(name):
    return (name or '').strip().lower().replace('_', '').replace('-', '')


def _extras_setting(setting):
    return set(_extra_key(part) for part in (ADDON.getSetting(setting) or '').split(',') if part.strip())


def _catalog_extra_kind(name, catalog_def=None):
    """Whether a catalog extra is shown as folders or as a filter (sort-like ones are always a
    filter; the user's lists decide next; category-like ones are folders)."""
    key = _extra_key(name)
    if key in _SORT_LIKE_EXTRAS:
        return 'filter'
    try:
        folders, filters = _extras_setting('extras_as_folder'), _extras_setting('extras_as_filter')
    except Exception:
        folders, filters = set(), set()
    if key in filters:
        return 'filter'
    return 'folder' if key in folders or key in _CATEGORY_LIKE_EXTRAS else 'filter'


def _folder_extra_choices(catalog_def):
    out = []
    for extra in (catalog_def.get('extra') or []):
        if not isinstance(extra, dict):
            continue
        name = extra.get('name') or ''
        if _catalog_extra_kind(name, catalog_def) != 'folder':
            continue
        opts = [str(o) for o in (extra.get('options') or []) if o not in (None, '')]
        if opts:
            out.append((name, opts))
    return out


def _filter_caption(name):
    return FILTER_NAMES.get(name, name)


def _catalog_toolbar(provider, provider_id, media_type, catalog_id, catalog_def, state, force_remote=False):
    return None


def _catalog_with_request(provider, media_type, catalog_id, state):
    extra = {}
    for key, value in (state or {}).items():
        if value in (None, ''):
            continue
        extra[key] = value
    if 'limit' not in extra:
        extra['limit'] = str(_listing_page_size())
    return fetch_catalog(provider, media_type, catalog_id, extra=extra)


def _catalog_presets(genre, year):
    """Filters the link itself carries (genre / year) plus the extra chosen in the filter dialog."""
    presets = dict((name, value) for name, value in (('genre', genre), ('year', year)) if value)
    try:
        home = xbmcgui.Window(WINDOW_ID)
        name, value = home.getProperty('meganexus.catalog_extra_name') or '', home.getProperty('meganexus.catalog_extra_value') or ''
        if name and value:
            presets[name] = value
    except Exception:
        pass
    return presets


def _catalog_folder_gate(provider, provider_id, media_type, catalog_id, catalog_def, label, state, force_remote):
    """With genre folders on and nothing chosen yet, the catalog opens as its genre / year / extra
    folders (plus 'show all'); True when it did."""
    online = _online_query(force_remote)
    pictures = _fallback_pictures(provider, media_type, catalog_def, catalog_def.get('name') or catalog_id)
    poster = pictures.get('poster') or ''
    art = {'thumb': poster, 'poster': poster, 'icon': poster, 'fanart': pictures.get('fanart') or addon_fanart()}
    shown = False
    for name, choices in _folder_extra_choices(catalog_def):
        kind = name.lower()
        if kind == 'year' and len(choices) > 40:
            continue
        for choice in choices:
            if kind in ('genre', 'year'):
                link = build_url(action='catalog', provider_id=provider_id, media_type=media_type, catalog_id=catalog_id,
                                 label=label, **dict({kind: choice}, **online))
            else:
                link = build_url(action='catalog_extra', provider_id=provider_id, media_type=media_type,
                                 catalog_id=catalog_id, label=label, extra_name=name, extra_value=choice, **online)
            caption = choice if kind == 'genre' else '%s: %s' % (_filter_caption(name), choice)
            add_item(caption, link, info={'title': caption}, art=art)
            shown = True
    if shown:
        _catalog_toolbar(provider, provider_id, media_type, catalog_id, catalog_def, state, force_remote=force_remote)
        add_item('[COLOR yellow]◉ Show all items without filtering[/COLOR]',
                 build_url(action='catalog_all', provider_id=provider_id, media_type=media_type, catalog_id=catalog_id,
                           label=label, **online),
                 art=root_art('catalogs'), info={'title': 'All items', 'plot': 'Skip folders and show the full list'})
        end_dir(content='files')
    return shown


def _distinct_metas(metas):
    seen, out = set(), []
    for meta in metas:
        key = str((meta or {}).get('id') or '')
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        out.append(meta)
    return out


def _catalog_page(provider, media_type, catalog_id, request, page, size, pages_online):
    """(page, metas, more); pages_online: the add-on pages itself (skip=), else the whole list is paged here."""
    if pages_online:
        request = dict(request, skip=str(page * size))
    answer = (_catalog_with_request(provider, media_type, catalog_id, request).get('metas') or [])
    metas = _distinct_metas(answer)
    if not pages_online:
        page, _size, metas, more = _page_of(metas, page)
        return page, metas, more
    return page, metas[:size], len(answer) >= size or len(metas) > size


def _add_catalog_row(provider, media_type, catalog_id, catalog_def, meta, place, force_remote, favorites):
    meta = _meta_picture_urls(provider, meta)
    meta_id = meta.get('id')
    name = str(meta.get('name') or meta.get('title') or meta_id or 'Unknown')
    addon_id = provider.get('id') or ''
    art = _meta_pictures(provider, media_type, meta,
                         fallback_art=_fallback_pictures(provider, media_type, catalog_def, meta.get('name') or meta_id or ''),
                         force_remote=force_remote, lazy=place >= 12 and not force_remote)
    try:
        _meta_keep(media_type, meta_id, meta, source_provider_id=addon_id)
    except Exception:
        pass
    info, ids = _info_of(meta), extract_ids(meta)
    id_args = dict((key, ids.get(key) or '') for key in ('tmdb_id', 'imdb_id', 'tvdb_id'))
    path, is_folder = _item_click_url(media_type=media_type, canonical_id=meta_id, title=name, source_provider_id=addon_id,
                                      ui_seed=art, **id_args)
    favorite = (str(media_type or ''), str(meta_id or '')) in favorites
    if favorite:
        toggle = ('Remove from favorites', 'RunPlugin(%s)' % build_url(action='fav_remove', media_type=media_type,
                                                                       canonical_id=meta_id))
    else:
        toggle = ('Add to favorites', 'RunPlugin(%s)' % build_url(
            action='fav_add', media_type=media_type, canonical_id=meta_id, title=name, poster=art.get('poster') or '',
            background=art.get('fanart') or '', clearlogo=art.get('clearlogo') or '', year=str(info.get('year') or 0)))
    menu = (_catalog_filter_menu(provider_id=addon_id, media_type=media_type, catalog_id=catalog_id, catalog_def=catalog_def,
                                 force_remote='1' if force_remote else '')
            + _source_choice_list(media_type=media_type, canonical_id=meta_id, title=name, source_provider_id=addon_id)
            + _player_choices(media_type=media_type, canonical_id=meta_id, title=name, source_provider_id=addon_id,
                              **id_args)
            + [toggle])
    add_item(name, path, is_folder=is_folder, info=info, art=art, ids=ids, context_menu=menu, is_favorite=favorite)
    return art.get('fanart') or ''


def _warm_next_catalog_page(provider, media_type, catalog_id, request):
    def ask():
        try:
            _catalog_with_request(provider, media_type, catalog_id, request)
        except Exception:
            pass
    try:
        threading.Thread(target=ask, daemon=True).start()
    except Exception:
        pass


def catalog(provider_id, media_type, catalog_id, label='', page='0', genre='', year='', force_remote=''):
    """One add-on catalog as a Kodi list: its folders first when set so, else a page of titles."""
    provider = addon_registry.get_provider(provider_id)
    if not provider:
        return end_dir()
    force_remote = _online_posters_only(force_remote)
    catalog_def = _catalog_entry_of(provider, catalog_id, media_type)
    state = _filter_now(provider_id, catalog_id)
    _catalog_tool_rows(provider, provider_id, media_type, catalog_id, catalog_def, label=label)
    presets = _catalog_presets(genre, year)
    try:
        folders = (ADDON.getSetting('catalog_genre_folders') or 'false').lower() != 'false'
    except Exception:
        folders = True
    if (folders and not presets and not any(state.get(key) for key in (state or {}))
            and xbmcgui.Window(WINDOW_ID).getProperty('meganexus.catalog_skip_gate') != '1'
            and _catalog_folder_gate(provider, provider_id, media_type, catalog_id, catalog_def, label, state,
                                     force_remote)):
        return
    _catalog_toolbar(provider, provider_id, media_type, catalog_id, catalog_def, state, force_remote=force_remote)
    pages_online = any(isinstance(x, dict) and x.get('name') == 'skip' for x in catalog_def.get('extra') or [])
    try:
        page = max(0, int(page or 0))
    except Exception:
        page = 0
    size = _listing_page_size()
    request = dict(state or {}, **presets)
    try:
        page, metas, more = _catalog_page(provider, media_type, catalog_id, request, page, size, pages_online)
    except Exception as exc:
        error(tr('Catalog load failed: %s') % exc)
        return end_dir()
    metas = _complete_listing_metas(provider, media_type, metas)
    try:
        favorites = library_titles.favorite_keys()
    except Exception:
        favorites = set()
    backdrop = ''
    for place, meta in enumerate(metas):
        fanart = _add_catalog_row(provider, media_type, catalog_id, catalog_def, meta, place, force_remote, favorites)
        backdrop = backdrop or fanart
    if backdrop:
        xbmcgui.Window(WINDOW_ID).setProperty('fanart', backdrop)
    if more and metas:
        more_args = dict(action='catalog', provider_id=provider_id, media_type=media_type, catalog_id=catalog_id,
                         label=label, page=str(page + 1))
        more_args.update((key, value) for key, value in (('genre', genre), ('year', year)) if value)
        if force_remote:
            more_args['force_remote'] = '1'
        if not _no_pages():
            add_item(tr('More'), build_url(**more_args), art=root_art('catalogs'),
                     info={'title': tr('More'), 'plot': tr('Load more results from this catalog')})
        if pages_online:
            _warm_next_catalog_page(provider, media_type, catalog_id, dict(request, skip=str((page + 1) * size)))
    end_dir(content=_kodi_content_of(media_type))



def _back_from_filters(provider_id, media_type, catalog_id, force_remote='', return_action='', return_bucket=''):
    if return_action == 'hub_section' and return_bucket:
        return section_rows(return_bucket)
    return catalog(provider_id, media_type, catalog_id, force_remote=force_remote)


def filter_menu(provider_id, media_type, catalog_id, force_remote='', return_action='', return_bucket=''):
    provider = addon_registry.get_provider(provider_id)
    if not provider:
        return end_dir()
    catalog_def = _catalog_entry_of(provider, catalog_id, media_type)
    extras = [e for e in _filters_offered(catalog_def)
              if _catalog_extra_kind((e.get('name') or ''), catalog_def) == 'filter']
    if not extras:
        return _back_from_filters(provider_id, media_type, catalog_id, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)
    state = _filter_now(provider_id, catalog_id)
    labels = []
    actions = []
    for extra in extras:
        name = extra.get('name')
        if not name:
            continue
        current = state.get(name)
        labels.append('%s%s' % (_filter_caption(name), ('  •  %s' % current) if current not in (None, '') else ''))
        actions.append(('set', name))
    if state:
        labels.append('Clear all filters')
        actions.append(('clear', ''))
    idx = xbmcgui.Dialog().select(tr('Sort & filter'), [tr(x) for x in labels])
    if idx < 0:
        return _back_from_filters(provider_id, media_type, catalog_id, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)
    action, value = actions[idx]
    if action == 'clear':
        addon_registry.reset_catalog_filters(provider_id, catalog_id)
        return _back_from_filters(provider_id, media_type, catalog_id, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)
    return pick_filter(provider_id, media_type, catalog_id, value, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)


def pick_filter(provider_id, media_type, catalog_id, filter_name, force_remote='', return_action='', return_bucket=''):
    provider = addon_registry.get_provider(provider_id)
    if not provider:
        return end_dir()
    catalog_def = _catalog_entry_of(provider, catalog_id, media_type)
    extra_def = None
    for extra in catalog_def.get('extra') or []:
        if isinstance(extra, dict) and extra.get('name') == filter_name:
            extra_def = extra
            break
    if not extra_def:
        return _back_from_filters(provider_id, media_type, catalog_id, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)

    options = list(extra_def.get('options') or [])
    title = _filter_caption(filter_name)
    if options:
        labels = ['Clear filter'] + [str(x) for x in options]
        idx = xbmcgui.Dialog().select(tr('Choose %s') % tr(title), [tr(x) for x in labels])
        if idx < 0:
            return _back_from_filters(provider_id, media_type, catalog_id, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)
        if idx == 0:
            addon_registry.keep_catalog_filter(provider_id, catalog_id, filter_name, '__clear__')
        else:
            addon_registry.keep_catalog_filter(provider_id, catalog_id, filter_name, labels[idx])
    else:
        default = _filter_now(provider_id, catalog_id).get(filter_name, '')
        kb = xbmc.Keyboard(default, tr('Type %s') % tr(title))
        kb.doModal()
        if not kb.isConfirmed():
            return _back_from_filters(provider_id, media_type, catalog_id, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)
        value = kb.getText().strip()
        addon_registry.keep_catalog_filter(provider_id, catalog_id, filter_name, value or '__clear__')
    return _back_from_filters(provider_id, media_type, catalog_id, force_remote=force_remote, return_action=return_action, return_bucket=return_bucket)


def _is_id_query(query):
    q = (query or '').strip().lower()
    return q.startswith('tmdb:') or q.startswith('tt') or q.startswith('imdb:') or q.startswith('tvdb:')


def _search_refs(meta):
    """What makes two search results one title: id, IMDb id, TMDB id, letters of the title + year."""
    keys = set()
    own = str(meta.get('id') or '').strip().lower()
    imdb = str(meta.get('imdb_id') or meta.get('imdbId') or '').strip().lower()
    tmdb = str(meta.get('moviedb_id') or meta.get('tmdb_id') or meta.get('tmdbId') or '').strip().lower()
    keys.update(key for key, wanted in ((own, own), (imdb, imdb.startswith('tt')),
                                        ('tmdb:' + tmdb, tmdb and tmdb not in ('0', 'none'))) if wanted)
    title = str(meta.get('name') or meta.get('title') or '').strip().lower()
    year = str(meta.get('year') or meta.get('releaseInfo') or '')[:4]
    if len(title) >= 3 and year.isdigit():
        keys.add('ty:%s|%s' % (''.join(ch for ch in title if ch.isalnum()), year))
    return keys


def _ask_search_text(media_type, query):
    """The query given, else typed (the last one offered); '' when the user backs out."""
    home = xbmcgui.Window(WINDOW_ID)
    key = 'meganexus.last_search.%s' % (media_type or 'any')
    query = (query or '').strip()
    if not query:
        keyboard = xbmc.Keyboard(home.getProperty(key) or '', tr('Search or type tmdb:123 / tt1234567'))
        keyboard.doModal()
        query = keyboard.getText().strip() if keyboard.isConfirmed() else ''
        if not query:
            return ''
    home.setProperty(key, query)
    try:
        from .finding import recall as _queries
        _queries.note_query(query, media_type=media_type or 'all')
    except Exception:
        pass
    return query


def _search_type_catalogs(media_type, query, jobs):
    """(add-on, id, meta) for the query from the type's search catalogs, each title once, at most
    eight pages' worth (60-240); stops early once enough came or nothing new arrives."""
    found, seen = [], set()
    enough = min(max(60, _listing_page_size() * 8), 240)
    race = begin_race(lambda job: fetch_catalog(job[0], media_type, job[1].get('id'), extra={'search': query},
                                                timeout_override=fast_timeout('search')),
                      _fair_search_job_order(jobs), workers=max(2, min(parallel_workers(), 4, len(jobs))),
                      timeout=6.0, lane='search')
    for (addon, _catalog), answer in _iter_search_race(race, lambda: len(found), lambda: True, real_goal=enough,
                                                       quiet_seconds=0.30, fallback_seconds=6.0):
        if isinstance(answer, Exception):
            continue
        metas = []
        for meta in (answer or {}).get('metas') or []:
            if not meta.get('id') or _title_match.best_score(query, meta) <= 0:
                continue
            refs = _search_refs(meta)
            if refs & seen:
                continue
            seen |= refs
            metas.append(meta)
        if not metas:
            continue
        try:
            from . import meta_choice
            metas = meta_choice.apply_many(addon, media_type, metas)
        except Exception:
            pass
        found.extend((addon, meta.get('id'), meta) for meta in metas)
    return found[:enough]


def _search_grouped(rows):
    """Rows of one title merged: [(first add-on, meta, names of every add-on that has it)]."""
    groups, order = {}, []
    for addon, meta_id, meta in rows:
        name = addon.get('name') or addon.get('id')
        if meta_id not in groups:
            groups[meta_id] = (addon, meta, [name])
            order.append(meta_id)
        elif name not in groups[meta_id][2]:
            groups[meta_id][2].append(name)
    return [(meta_id,) + groups[meta_id] for meta_id in order]


def _add_search_title(media_type, meta_id, addon, meta, names):
    name = meta.get('name') or meta_id
    addon_id = addon.get('id') or ''
    try:
        _meta_keep(media_type, meta_id, meta, source_provider_id=addon_id)
    except Exception:
        pass
    art = _meta_pictures(addon, media_type, meta, fallback_art=_fallback_pictures(addon, media_type, None, name))
    ids = extract_ids(meta)
    path, is_folder = _item_click_url(media_type=media_type, canonical_id=meta_id, title=name,
                                      tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                                      tvdb_id=ids.get('tvdb_id') or '', source_provider_id=addon_id, ui_seed=art)
    info = _info_of(meta)
    if len(names) > 1:
        plot = info.get('plot') or ''
        info = dict(info, plot=plot + ('\n\n' if plot else '')
                    + tr('Available from %d add-ons: %s') % (len(names), tr(', ').join(names)))
    add_item('%s  ·  📡 %d' % (name, len(names)) if len(names) > 1 else name, path, is_folder=is_folder, info=info,
             art=art, ids=ids,
             context_menu=_source_choice_list(media_type=media_type, canonical_id=meta_id, title=name,
                                              source_provider_id=addon_id))


def search(media_type, provider_id=None, query=''):
    """Search one type in the add-ons' catalogs (or open an id typed as tt… / tmdb:…)."""
    addons = [x for x in ([addon_registry.get_provider(provider_id)] if provider_id else addon_registry.list_providers()) if x]
    if not addons:
        return providers()
    query = _ask_search_text(media_type, query)
    if not query:
        return end_dir()
    _forget_source_scan_props(clear_global=True)
    content = _kodi_content_of(media_type)
    if _is_id_query(query):
        path, is_folder = _item_click_url(media_type=media_type, canonical_id=query, title=query)
        extra = {} if media_type == 'series' else {
            'context_menu': _source_choice_list(media_type=media_type, canonical_id=query, title=query)}
        add_item(query, path, is_folder=is_folder, info={'title': query}, art=catalog_art('search', media_type), **extra)
        return end_dir(content=content, cache=False)
    jobs = [(addon, cat) for addon in addons for cat in _addon_catalogs(addon, media_type)
            if any(x.get('name') == 'search' for x in cat.get('extra') or [] if isinstance(x, dict))]
    if not jobs:
        return end_dir(content=content, cache=False)
    key = ('v500', str(media_type or ''), str(provider_id or ''), query.casefold(), _meta_variant(provider_id or ''))
    rows = _searches.get(key)
    if rows:
        for addon, meta_id, meta in rows:
            try:
                _meta_keep(media_type, meta_id, meta, source_provider_id=addon.get('id') or '')
            except Exception:
                pass
    else:
        rows = _search_type_catalogs(media_type, query, jobs)
        if rows:
            _searches.put(key, rows)
    rows = sorted((row for row in rows or [] if _title_match.best_score(query, row[2]) > 0),
                  key=lambda row: -_title_match.best_score(query, row[2]))
    sources = len(set(a.get('id') for a, _id, _m in rows) | set(a.get('id') for a, _c in jobs))
    parts = [tr('Results: %d') % len(rows), tr('Active add-ons: %d') % sources]
    if not rows:
        parts.append('No results — try different wording')
    heading = tr('🔍 Search: %s') % query
    add_item('%s — %s' % (heading, ' • '.join(parts)), build_url(action='search', media_type=media_type), is_folder=True,
             info={'title': heading, 'plot': tr('Your query: "%s"\n\n%s') % (query, '\n'.join(parts))},
             art=catalog_art('search', media_type))
    for meta_id, addon, meta, names in _search_grouped(rows):
        _add_search_title(media_type, meta_id, addon, meta, names)
    end_dir(content=content, cache=False)




def _addons_for_id(media_type, canonical_id):
    rows = []
    for provider in addon_registry.list_providers():
        if offers(provider, 'stream', media_type=media_type, item_id=canonical_id) or offers(provider, 'meta', media_type=media_type, item_id=canonical_id):
            rows.append(provider)
    if not rows:
        for provider in addon_registry.list_providers():
            if offers(provider, 'stream', media_type=media_type) or offers(provider, 'meta', media_type=media_type):
                rows.append(provider)
    return rows


def _clean_imdb(value):
    raw = str(value or '').strip()
    if not raw:
        return ''
    m = re.search(r'(?i)\btt(\d{5,12})\b', raw)
    if m:
        return 'tt' + m.group(1)
    if raw.isdigit() and 5 <= len(raw) <= 12:
        return 'tt' + raw
    return ''


from .stream_ids import unique as _unique  # noqa: E402


_KEYLESS_IMDB_CACHE = {}
_stream_ids_kept = _Answers(256, 1800)          # a title's ids found for its streams, half an hour
_TMDB_ADDON_BASES = ('https://catalog.nuvio.tv', 'https://tmdb.elfhosted.com')   # 9.0.4: the MegaNexus Catalog first

def _http_json(url, timeout=3):
    import json as _json
    from urllib.request import Request as _Req, urlopen as _open
    req = _Req(url, headers={'Accept': 'application/json',
                             'User-Agent': 'Mozilla/5.0 (compatible; MegaNexus)'})
    with _open(req, timeout=timeout) as resp:
        return _json.loads(resp.read().decode('utf-8', 'replace') or '{}')

def _imdb_keyless(tmdb_id, media_type):
    """A TMDB id's IMDb id from the public TMDB add-ons (no key needed); '' when it has none (kept per run)."""
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id.isdigit():
        return ''
    kind = 'series' if media_type in ('series', 'tv', 'show', 'anime') else 'movie'
    key = '%s:%s' % (kind, tmdb_id)
    if key not in _KEYLESS_IMDB_CACHE:
        found = ''
        for base in _TMDB_ADDON_BASES:
            try:
                meta = _http_json('%s/meta/%s/tmdb:%s.json' % (base, kind, tmdb_id)).get('meta') or {}
            except Exception:
                continue
            for candidate in (str(meta.get('imdb_id') or '').strip(), str(meta.get('id') or '').strip()):
                if candidate.startswith('tt'):
                    found = candidate
                    break
            if found:
                break
        xbmc.log('[MegaNexus] tmdb->imdb (keyless) tmdb:%s -> %s' % (tmdb_id, found or 'MISS'), xbmc.LOGINFO)
        _KEYLESS_IMDB_CACHE[key] = found
    return _KEYLESS_IMDB_CACHE[key]


_ID_KEYS = ('tmdb_id', 'imdb_id', 'tvdb_id')


from .stream_ids import from_canonical as _ids_from_canonical  # noqa: E402


def _fill_missing(out, found):
    for key, value in (found or {}).items():
        if value and not out.get(key):
            out[key] = value


def _remembered_stream_ids(key):
    return _stream_ids_kept.get(key)


def _remember_stream_ids(key, ids):
    _stream_ids_kept.put(key, dict(ids))


def _imdb_by_race(out, media_type, title, year):
    """Ask TMDB (and, with a TMDB id, the keyless TMDB add-ons) for the IMDb id at once; the first answer wins (3 s)."""
    def ask(kind):
        if kind == 'keyless':
            return {'imdb_id': _imdb_keyless(out.get('tmdb_id'), media_type)}
        return _tmdb_api.art_for(tmdb_id=out.get('tmdb_id') or '', imdb_id='', media_type=media_type, title=title,
                                 year=year) or {}
    jobs = ['tmdb', 'keyless'] if out.get('tmdb_id') else ['tmdb']
    race = begin_race(ask, jobs, workers=len(jobs), timeout=3.0, lane='identity')
    try:
        for _kind, answer in race.each_done(timeout=3.0, poll_interval=0.05):
            if not isinstance(answer, dict):
                continue
            if answer.get('imdb_id'):
                out['imdb_id'] = answer['imdb_id']
            if answer.get('tmdb_id') and not out.get('tmdb_id'):
                out['tmdb_id'] = str(answer['tmdb_id'])
            if out.get('imdb_id'):
                break
    finally:
        race.cancel()


def _complete_title_ids(ids, media_type, meta=None, canonical_id='', title=''):
    """The title's TMDB / IMDb / TVDB ids as complete as they can be had: from the item, its
    canonical id, the local TMDB database and at last online (kept 30 minutes)."""
    meta = meta or {}
    out = dict(ids or {})
    _fill_missing(out, dict((key, value) for key, value in extract_ids(meta).items() if key in _ID_KEYS))
    cid = str(canonical_id or meta.get('id') or '').strip()
    _fill_missing(out, _ids_from_canonical(cid))
    year = _info_of(meta).get('year') or meta.get('year') or meta.get('releaseInfo') or ''
    name = title or meta.get('name') or meta.get('title') or ''
    key = (str(media_type or ''), cid.lower(), str(out.get('tmdb_id') or ''), str(out.get('imdb_id') or '').lower(),
           str(out.get('tvdb_id') or ''), str(name or '').casefold(), str(year or '')[:4])
    kept = _remembered_stream_ids(key)
    if kept is not None:
        _fill_missing(out, kept)
        return out
    try:
        found = _tmdb_art_db.get_external_ids_from_db(tmdb_id=out.get('tmdb_id') or '', imdb_id=out.get('imdb_id') or '',
                                                      tvdb_id=out.get('tvdb_id') or '', media_type=media_type,
                                                      title=name, year=year) or {}
        _fill_missing(out, dict((k, found.get(k)) for k in _ID_KEYS))
    except Exception:
        pass
    if not out.get('imdb_id') and (out.get('tmdb_id') or name):
        _imdb_by_race(out, media_type, name, year)
    if out.get('imdb_id'):
        out['imdb_id'] = _clean_imdb(out['imdb_id']) or str(out['imdb_id']).strip()
    _remember_stream_ids(key, out)
    return out


def _candidate_ids_from_meta(canonical_id, meta=None, season=None, episode=None, include_episode_variants=False):
    return _stream_ids.candidates(canonical_id, meta=meta, season=season, episode=episode,
                                  with_episodes=include_episode_variants)


from .stream_ids import id_prefixes as _stream_resource_id_prefixes, matching as _candidate_ids_matching_prefixes, ordered as _ordered_stream_candidate_ids  # noqa: E402,E501


def _anime_id_addons():
    out = []
    for provider in addon_registry.list_providers():
        for prefix in _stream_resource_id_prefixes(provider):
            if str(prefix).split(':')[0] in ('kitsu', 'mal', 'anilist', 'anidb'):
                out.append(provider)
                break
    return out


def _with_anime_ids(ids, media_type):
    ids = dict(ids or {})
    try:
        if not anime_ids.enabled():
            return ids
        if all(ids.get(k) for k in ('kitsu_id', 'mal_id', 'anilist_id', 'anidb_id')):
            return ids
        if not _anime_id_addons():
            return ids
        extra = anime_ids.lookup(ids)
        for key, value in (extra or {}).items():
            if value and not ids.get(key):
                ids[key] = value
        if extra:
            xbmc.log('[MegaNexus] anime id policy: added %s' % ', '.join(sorted(extra)),
                     xbmc.LOGINFO)
    except Exception:
        pass
    return ids


def _target_key(provider, item_id):
    provider = provider or {}
    return (provider.get('id') or provider.get('base_url') or provider.get('name') or '', str(item_id))


def _addon_targets(media_type, canonical_id, candidate_ids, season, episode):
    """(add-on, id) pairs: each add-on that has streams for the type, with up to four of the
    title's ids it understands (the episode's own ids first)."""
    found, seen = [], set()
    if _get_bool_setting('stremio_sources_enabled', True):
        suffix = ':%s:%s' % (int(season), int(episode)) if season and episode else ''
        for provider in addon_registry.list_providers():
            if (provider or {}).get('enabled') is False or not _stremio_adapter.offers_streams(provider, media_type):
                continue
            ids = (_candidate_ids_matching_prefixes(candidate_ids, _stream_resource_id_prefixes(provider, media_type=media_type))
                   or list(candidate_ids or []))
            if suffix:
                ids = sorted(ids, key=lambda value: not str(value).endswith(suffix))
            for item_id in _ordered_stream_candidate_ids(ids, season=season, episode=episode)[:4]:
                if _target_key(provider, item_id) not in seen:
                    seen.add(_target_key(provider, item_id))
                    found.append((provider, item_id))
    if not found:
        for provider in _addons_for_id(media_type, canonical_id):
            if _target_key(provider, canonical_id) not in seen:
                seen.add(_target_key(provider, canonical_id))
                found.append((provider, canonical_id))
    return found


# Jellyfin and Emby servers each have their own switch
_MEDIABROWSER_SWITCH = {'jellyfin': 'emby_in_sources', 'emby': 'emby_server_in_sources'}
_PLEX_TITLE_KEYS = ('originalTitle', 'original_title', 'tvShowTitle', 'show_title', 'showname', 'show_name',
                    'seriesName', 'grandparentTitle', 'name', 'title', 'en_title', 'english_title', 'en_showname')
_EPISODE_TAIL = re.compile(r'\s+(?:[—\-]\s*)?S\d{1,3}E\d{1,4}\s*$', re.I)


def _mediabrowser_targets(meta, canonical_id, season, episode):
    found = []
    if not _emby.is_signed_in():
        return found
    title = meta.get('name') or meta.get('title') or ''
    ids = extract_ids(meta)
    for server in _emby.servers():
        kind = _emby.flavor_of(server)
        if not _get_bool_setting(_MEDIABROWSER_SWITCH.get(kind, 'emby_in_sources'), True):
            continue
        label = 'Jellyfin' if kind == 'jellyfin' else 'Emby'
        found.append(({'id': '__emby__', 'name': '%s • %s' % (label, server.get('name') or label), '_server': server,
                       '_title': title, '_ids': ids, '_season': season, '_episode': episode}, str(canonical_id)))
    return found


def _plex_search_titles(meta, ids, media_type):
    """Every name the title may carry on a Plex server: its own ones, TMDB's English ones and
    each of those without an 'S01E02' tail."""
    titles, known = [], set()

    def add(value):
        value = str(value or '').strip()
        if value and value.casefold() not in known:
            known.add(value.casefold())
            titles.append(value)
    for key in _PLEX_TITLE_KEYS:
        add(meta.get(key))
    from . import tmdb_api
    kind = 'series' if is_show(media_type) else 'movie'
    for lookup, ident in ((tmdb_api.titles_by_imdb, ids.get('imdb_id')), (tmdb_api.titles_in_english, ids.get('tmdb_id'))):
        try:
            for value in lookup(ident or '', kind):
                add(value)
        except Exception:
            pass
    for value in list(titles):
        add(_EPISODE_TAIL.sub('', str(value)))
    return titles


def _plex_targets(meta, media_type, canonical_id, season, episode):
    found = []
    if not _plex.is_signed_in():
        xbmc.log('[MegaNexus] Plex Native skipped: no account and no usable cached servers', xbmc.LOGWARNING)
        return found
    if not _get_bool_setting('plex_in_sources', True):
        xbmc.log('[MegaNexus] Plex Native sources disabled in settings', xbmc.LOGINFO)
        return found
    title = meta.get('name') or meta.get('title') or ''
    ids = extract_ids(meta)
    titles = _plex_search_titles(meta, ids, media_type)
    servers = _plex_servers_quick()
    xbmc.log('[MegaNexus] Plex Native targets: servers=%d title=%s ids=%s' % (
        len(servers), title, ','.join('%s=%s' % (key, ids[key]) for key in ('imdb_id', 'tmdb_id', 'tvdb_id')
                                      if ids.get(key)) or 'none'), xbmc.LOGINFO)
    home_server = str(meta.get('native_server_id') or '')
    for server in servers:
        on_this_server = home_server == str(server.get('id') or '')
        found.append(({'id': '__plex__', 'name': 'Plex • %s' % (server.get('name') or 'Plex'), '_server': server,
                       '_title': title, '_ids': ids, '_titles': titles, '_year': meta.get('year') or '',
                       '_season': season, '_episode': episode,
                       '_native_item_id': str(meta.get('native_item_id') or '') if on_this_server else ''},
                      str(canonical_id)))
    return found


def _source_targets(media_type, canonical_id, meta=None, season=None, episode=None):
    """Where to look for streams: the user's Plex / Jellyfin / Emby servers (fastest first),
    then the add-ons, in the order past searches earned."""
    given = meta or {}
    ids = _with_anime_ids(_complete_title_ids(extract_ids(given), media_type, meta=given, canonical_id=canonical_id,
                                                    title=given.get('name') or given.get('title') or ''), media_type)
    meta = _meta_plus_ids(given, ids) or {}
    candidates = _candidate_ids_from_meta(canonical_id, meta=meta, season=season, episode=episode,
                                          include_episode_variants=bool(season and episode))
    addons = _addon_targets(media_type, canonical_id, candidates, season, episode)
    servers = []
    for collect, label in ((lambda: _mediabrowser_targets(meta, canonical_id, season, episode), None),
                           (lambda: _plex_targets(meta, media_type, canonical_id, season, episode), 'Plex')):
        try:
            servers.extend(collect())
        except Exception as exc:
            if label:
                xbmc.log('[MegaNexus] Plex Native target discovery failed: %s' % exc, xbmc.LOGWARNING)
    try:
        xbmc.log('[MegaNexus] source targets: stremio=%d native=%d installed=%d media_type=%s canonical=%s' % (
            len(addons), len(servers), len(addon_registry.list_providers() or []),
            _stremio_adapter.stremio_type(media_type), canonical_id), xbmc.LOGINFO)
    except Exception:
        pass
    try:
        servers = _server_health.servers_fastest_first(servers)
    except Exception:
        pass
    ordered = servers + addons
    try:
        ordered = _fair_search_job_order(_recall.by_record(ordered))
        xbmc.log('[MegaNexus] adaptive source order: %s' % ', '.join(
            str((p or {}).get('name') or (p or {}).get('id') or '?') for p, _rid in ordered[:8]), xbmc.LOGDEBUG)
    except Exception:
        pass
    return ordered


_KODI_CONTENT = (('tvshows', ('series', 'show', 'shows', 'tv', 'tvshow', 'anime')), ('episodes', ('episode', 'episodes')),
                 ('seasons', ('season', 'seasons')),
                 ('videos', ('video', 'videos', 'channel', 'channels', 'live', 'all', 'mixed')))


def _kodi_content_of(media_type):
    """Kodi's content kind of a media type (films unless known otherwise)."""
    kind = str(media_type or '').strip().lower()
    return next((content for content, kinds in _KODI_CONTENT if kind in kinds), 'movies')


def _click_behaviour():
    raw = str(ADDON.getSetting('catalog_click_mode') or 'MegaNexus').strip().lower()
    compact = raw.replace(' ', '').replace('_', '').replace('-', '')
    if compact in ('tmdbhelper', 'helper', '1') or 'tmdb' in compact:
        return 'tmdbhelper'
    if raw in ('Ask every time', 'ask') or compact in ('ask', 'askeverytime', '2'):
        return 'ask'
    return 'meganexus'


def _default_playback_mode():
    raw = (ADDON.getSetting('playback_open_mode') or 'Choose from sources').strip().lower()
    if raw in ('1', 'best quality automatically', 'auto', 'autoplay') or ('best' in raw) or ('Best' in raw):
        return 'autoplay'
    return 'sources'


def _prefer_source_picker():
    return _default_playback_mode() != 'autoplay'


def _source_choice_mode():
    raw = (ADDON.getSetting('source_resolution_mode') or 'MegaNexus picker').strip().lower()
    if 'same' in raw:
        return 'same'
    if 'tmdb' in raw or 'helper' in raw:
        return 'tmdbh'
    return 'picker'


def _route_ids(media_type='movie', canonical_id='', title='', tmdb_id='', imdb_id='', tvdb_id='', season='', episode=''):
    """The title's ids for handing it on: the given ones, TMDb Helper's, the canonical id's, then
    the kept meta's, then (asked) the add-ons' meta."""
    kind = 'series' if is_show(media_type) or (_has_number(season) and _has_number(episode)) else 'movie'
    known = lambda found: found.get('tmdb_id') or found.get('imdb_id') or found.get('tvdb_id')
    ids = dict((key, str(value or '').strip()) for key, value in (('tmdb_id', tmdb_id), ('imdb_id', imdb_id),
                                                                  ('tvdb_id', tvdb_id)))
    ids = _merge_seed_ids(_merge_seed_ids(ids, _get_tmdbh_seed_ids(canonical_id or '')), extract_ids({'id': canonical_id or ''}))
    if known(ids):
        return ids
    try:
        kept = _meta_kept(kind, canonical_id)
    except Exception:
        kept = None
    if kept:
        ids = _merge_seed_ids(ids, extract_ids(kept))
        if known(ids):
            return ids
    addons = _addons_for_id(kind, canonical_id)
    if addons:
        try:
            ids = _merge_seed_ids(ids, extract_ids(_richest_meta(kind, canonical_id, addons)))
        except Exception as exc:
            xbmc.log('[MegaNexus] routing id probe failed for %s: %s' % (canonical_id, exc), xbmc.LOGWARNING)
    return ids


def _has_number(value):
    return value not in (None, '', '0', 0)


def _dispatch_meganexus_play(media_type='', canonical_id='', title='', video_id='', season='', episode='', resume_seconds='0', resume_percent='', preferred_provider_name='', tmdb_id='', imdb_id='', tvdb_id='', source_provider_id='', source_mode='', ui_seed=None):
    """Play a title the way the source setting says: through TMDb Helper, the add-on that played
    it last, the source list, or the best source straight away."""
    media_type = str(media_type or 'movie').strip().lower()
    try:
        resume = float(resume_seconds or 0.0)
    except Exception:
        resume = 0.0
    mode = _source_choice_mode()
    name = title or canonical_id
    episode_given = _has_number(season) and _has_number(episode)
    if mode == 'tmdbh':
        try:
            if helper_player_file.has_tmdbhelper():
                ids = _route_ids(media_type=media_type, canonical_id=canonical_id, title=name, season=season, episode=episode)
                url = _helper_url(media_type='tv' if season and episode else 'movie', tmdb_id=ids.get('tmdb_id', ''),
                                  imdb_id=ids.get('imdb_id', ''), tvdb_id=ids.get('tvdb_id', ''), title=name,
                                  season=str(season or ''), episode=str(episode or ''))
                if url:
                    _open_helper_url(url)
                    return
        except Exception as exc:
            xbmc.log('[MegaNexus] tmdbh-mode dispatch failed: %s' % exc, xbmc.LOGWARNING)
    best = dict(title=name, seed_ids=_ids_in_values(tmdb_id=tmdb_id, imdb_id=imdb_id, tvdb_id=tvdb_id,
                                                    canonical_id=canonical_id),
                preferred_provider_name=preferred_provider_name or '', resume_seconds=resume,
                resume_percent=resume_percent or '', source_provider_id=source_provider_id or '',
                source_mode=source_mode or '')
    listing = dict(best, ui_seed=ui_seed)
    episode_args = (canonical_id, video_id or canonical_id, int(season), int(episode)) if episode_given else ()
    if not episode_given and is_show(media_type):
        return show_meta('series', canonical_id, title=name, source_provider_id=source_provider_id or '')
    # 'same': the add-on that played it last, straight away; else the source list when preferred
    picker = not (mode == 'same' and (preferred_provider_name or source_provider_id)) and _prefer_source_picker()
    if episode_given:
        if picker:
            return episode_sources(*episode_args, media_type='series', **listing)
        return _play_best_episode_source(*episode_args, **best)
    if picker:
        return streams(media_type or 'movie', canonical_id, **listing)
    return _play_best_movie_source(canonical_id, **best)


def _has_tmdbhelper():
    try:
        return xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)')
    except Exception:
        return False


def _helper_called():
    return _helper_handoff_on()


_HELPER_SHOWS = ('series', 'anime', 'show', 'tv')


def _helper_url(media_type='movie', tmdb_id='', imdb_id='', tvdb_id='', title='', season='', episode='', force_dialog=False):
    """TMDb Helper's link for the title: play a film or an episode, a show's details; '' without anything to find it by."""
    kind = str(media_type or 'movie').strip().lower()
    if kind == 'movie':
        params = {'info': 'play', 'type': 'movie'}
    elif kind in _HELPER_SHOWS and _shown_number(season) and _shown_number(episode):
        params = {'info': 'play', 'type': 'episode', 'season': str(season), 'episode': str(episode)}
    elif kind in _HELPER_SHOWS:
        params = {'info': 'details', 'type': 'tv'}
    else:
        return ''
    if force_dialog and params['info'] == 'play':
        params['ignore_default'] = 'true'
    found = next(((key, str(value)) for key, value in (('tmdb_id', tmdb_id), ('imdb_id', imdb_id), ('tvdb_id', tvdb_id),
                                                       ('query', title)) if value), None)
    if not found:
        return ''
    params[found[0]] = found[1] if found[0] != 'query' else title
    return 'plugin://plugin.video.themoviedb.helper/?' + urlencode(params)


def _helper_play_url(meta, media_type, title=''):
    ids = extract_ids(meta)
    return _helper_url(
        media_type=media_type,
        tmdb_id=ids.get('tmdb_id') or '',
        imdb_id=ids.get('imdb_id') or '',
        tvdb_id=ids.get('tvdb_id') or '',
        title=title or meta.get('name') or meta.get('title') or '',
    )


_TMDBH_LAUNCH_LAST = {'at': 0.0, 'url': ''}
_TMDBH_LAUNCH_DEDUP_WINDOW = 5.0   # seconds


def _open_helper_url(url):
    """Open a TMDb Helper link (the same link twice within a moment opens once)."""
    url = str(url or '').strip()
    if not url:
        return False
    now = time.time()
    if _TMDBH_LAUNCH_LAST.get('url') == url and now - float(_TMDBH_LAUNCH_LAST.get('at') or 0) < _TMDBH_LAUNCH_DEDUP_WINDOW:
        xbmc.log('[MegaNexus] _open_helper_url: dedup suppressed repeat launch of %s' % url, xbmc.LOGINFO)
        return True
    _TMDBH_LAUNCH_LAST.update(url=url, at=now)
    for builtin, words in (('Container.Update(%s)', 'container update'), ('ActivateWindow(Videos,%s,return)', 'activate window')):
        try:
            xbmc.executebuiltin(builtin % url)
            return True
        except Exception as exc:
            xbmc.log('[MegaNexus] tmdbhelper %s failed: %s' % (words, exc), xbmc.LOGWARNING)
    return False


def _click_opens_helper():
    return (not _helper_called()) and _click_behaviour() == 'tmdbhelper' and _has_tmdbhelper()


_SEED_SLOTS = (('ui_poster', ('poster', 'thumb'), ('poster', 'thumb')),
               ('ui_fanart', ('fanart', 'background', 'landscape'), ('fanart', 'background', 'landscape')),
               ('ui_clearlogo', ('clearlogo', 'logo'), ('clearlogo', 'logo')))


def _seed_query(art=None, meta=None):
    """The pictures a link carries to the next screen (ui_poster / ui_fanart / ui_clearlogo; kept in
    the cache under one key when they would make the link too long)."""
    art, meta = art or {}, meta or {}
    out = {}
    for slot, from_art, from_meta in _SEED_SLOTS:
        value = next((str(v).strip() for v in [art.get(k) for k in from_art] + [meta.get(k) for k in from_meta]
                      if str(v or '').strip()), '')
        if value:
            out[slot] = value
    if not out:
        return {}
    try:
        if sum(len(str(v)) for v in out.values()) > 1100:
            return {'ui_seed_key': keyed_cache.put('ui_seed', out, ttl_hours=6)}
    except Exception:
        pass
    return out


def _route_seed_of(ui_poster='', ui_fanart='', ui_clearlogo='', ui_seed_key=''):
    seed = {}
    if ui_seed_key:
        try:
            cached = keyed_cache.get('ui_seed', ui_seed_key) or {}
            if isinstance(cached, dict):
                seed.update(cached)
        except Exception:
            pass
    if ui_poster:
        seed['ui_poster'] = ui_poster
    if ui_fanart:
        seed['ui_fanart'] = ui_fanart
    if ui_clearlogo:
        seed['ui_clearlogo'] = ui_clearlogo
    return seed


def _item_click_url(media_type='movie', canonical_id='', title='', tmdb_id='', imdb_id='', tvdb_id='', season='', episode='', video_id='', source_provider_id='', source_mode='', force_meganexus=False, ui_seed=None):
    """(link, opens a folder) of a title row: TMDb Helper when clicks open there, else an episode
    or film plays, a show opens."""
    kind = str(media_type or 'movie').strip().lower()
    look = _seed_query(ui_seed or {}, {}) if ui_seed else {}
    name = title or canonical_id
    if not force_meganexus and not source_mode and _click_opens_helper():
        ids = _route_ids(media_type=kind, canonical_id=canonical_id, title=name, tmdb_id=tmdb_id, imdb_id=imdb_id,
                         tvdb_id=tvdb_id, season=season, episode=episode)
        url = _helper_url(media_type=kind, tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                          tvdb_id=ids.get('tvdb_id') or '', title=name, season=season or '', episode=episode or '')
        if url:
            return url, True
    ids = dict(tmdb_id=tmdb_id or '', imdb_id=imdb_id or '', tvdb_id=tvdb_id or '', source_provider_id=source_provider_id or '')
    if kind in _HELPER_SHOWS and _shown_number(season) and _shown_number(episode):
        return build_url(action='play_item', media_type='series', canonical_id=canonical_id, video_id=video_id or canonical_id,
                         season=season, episode=episode, title=name, tmdb_id=tmdb_id or '', imdb_id=imdb_id or '',
                         tvdb_id=tvdb_id or '', source_provider_id=source_provider_id or '', source_mode=source_mode or '',
                         **look), False
    if is_show(kind):
        return build_url(action='item_open', media_type=kind, canonical_id=canonical_id, title=name, **dict(ids, **look)), True
    return build_url(action='play_item', media_type=kind or 'movie', canonical_id=canonical_id, title=name,
                     tmdb_id=tmdb_id or '', imdb_id=imdb_id or '', tvdb_id=tvdb_id or '',
                     source_provider_id=source_provider_id or '', source_mode=source_mode or '', **look), False


def _preferred_addon_first(targets, preferred_provider_name=''):
    """Targets of the preferred add-on (by id or name) first, the rest in their order."""
    preferred = str(preferred_provider_name or '').strip().lower()
    targets = list(targets or [])
    if not preferred:
        return targets
    mine = lambda target: preferred in (str((target[0] or {}).get('id') or '').strip().lower(),
                                        str((target[0] or {}).get('name') or '').strip().lower())
    return [t for t in targets if mine(t)] + [t for t in targets if not mine(t)]


def _sources_only(source_mode=''):
    mode = str(source_mode or '').strip().lower()
    return mode in ('only', 'same', 'same_source', 'same-source', 'source_only', 'source-only')


def _targets_by_mode(targets, source_provider_id='', source_mode=''):
    targets = list(targets or [])
    if not targets or not _sources_only(source_mode) or not source_provider_id:
        return targets, []
    sid = str(source_provider_id or '').strip()
    primary = [(p, rid) for (p, rid) in targets if str((p or {}).get('id') or '').strip() == sid]
    return primary, []


def _meganexus_player_url(media_type='movie', canonical_id='', title='', season='', episode='', video_id='', source_provider_id='', source_mode=''):
    """MegaNexus as the player of a title: an episode's sources, a show's page or a film's sources."""
    show = str(media_type or 'movie').strip().lower() in _HELPER_SHOWS
    tail = dict(source_provider_id=source_provider_id or '', source_mode=source_mode or '')
    if show and _shown_number(season) and _shown_number(episode):
        return build_url(action='episode_streams', canonical_id=canonical_id, video_id=video_id or canonical_id,
                         season=str(season), episode=str(episode), title=title or canonical_id, media_type='series', **tail)
    return build_url(action='series_meta' if show else 'streams', media_type='series' if show else 'movie',
                     canonical_id=canonical_id, title=title or canonical_id, **tail)


def _player_choices(media_type='movie', canonical_id='', title='', tmdb_id='', imdb_id='', tvdb_id='', season='', episode='', video_id='', source_provider_id=''):
    chooser_url = build_url(
        action='choose_player',
        media_type=media_type,
        canonical_id=canonical_id,
        title=title or canonical_id,
        tmdb_id=tmdb_id or '',
        imdb_id=imdb_id or '',
        tvdb_id=tvdb_id or '',
        season=season or '',
        episode=episode or '',
        video_id=video_id or '',
        source_provider_id=source_provider_id or '',
    )
    return [('Choose player…', 'RunPlugin(%s)' % chooser_url)]


def pick_player(media_type='movie', canonical_id='', title='', tmdb_id='', imdb_id='', tvdb_id='', season='', episode='', video_id='', source_provider_id=''):
    player_url = _meganexus_player_url(media_type=media_type, canonical_id=canonical_id, title=title, season=season, episode=episode, video_id=video_id, source_provider_id=source_provider_id or '')
    options = [('MegaNexus', player_url)]
    if _has_tmdbhelper():
        route_ids = _route_ids(media_type=media_type, canonical_id=canonical_id, title=title or canonical_id, tmdb_id=tmdb_id, imdb_id=imdb_id, tvdb_id=tvdb_id, season=season, episode=episode)
        tmdbh_url = _helper_url(media_type=media_type, tmdb_id=route_ids.get('tmdb_id') or '', imdb_id=route_ids.get('imdb_id') or '', tvdb_id=route_ids.get('tvdb_id') or '', title=title, season=season, episode=episode)
        if tmdbh_url:
            options.append(('TMDb Helper', tmdbh_url))
    choice = xbmcgui.Dialog().select(tr('Choose player'), [tr(label) for label, _ in options])
    if choice < 0 or choice >= len(options):
        return
    label, url = options[choice]
    if label == 'TMDb Helper':
        _open_helper_url(url)
    else:
        xbmc.executebuiltin('Container.Update(%s)' % url)


def _to_player(meta, media_type, title=''):
    if _helper_called():
        return False
    mode = _click_behaviour()
    if mode == 'meganexus':
        return False
    if mode == 'ask':
        options = ['MegaNexus']
        if _has_tmdbhelper():
            options.append('TMDb Helper')
        choice = xbmcgui.Dialog().select(tr('Choose player'), [tr(x) for x in options])
        if choice <= 0:
            return False
        mode = 'tmdbhelper'
    if mode == 'tmdbhelper' and _has_tmdbhelper():
        url = _helper_play_url(meta, media_type, title=title)
        if url:
            return _open_helper_url(url)
    return False


def _open_in_helper(media_type, canonical_id, title, tmdb_id, imdb_id, tvdb_id):
    """True when TMDb Helper took the title (it is chosen for clicks, installed, and an id is known)."""
    if not _has_tmdbhelper():
        return False
    ids = _route_ids(media_type=media_type, canonical_id=canonical_id, title=title, tmdb_id=tmdb_id, imdb_id=imdb_id,
                     tvdb_id=tvdb_id)
    if not (ids.get('tmdb_id') or ids.get('imdb_id') or ids.get('tvdb_id')):
        return False
    url = _helper_url(media_type=media_type, tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                      tvdb_id=ids.get('tvdb_id') or '', title=title)
    return bool(url and _open_helper_url(url))


def _open_in_player(media_type, canonical_id, title, source_provider_id, words):
    """(handed to another player, the title's meta) - the default player setting may send it elsewhere."""
    addons = _addons_for_id_in(media_type, canonical_id, source_provider_id=source_provider_id)
    try:
        meta = _richest_meta(media_type, canonical_id, addons, source_provider_id=source_provider_id)
    except Exception as exc:
        xbmc.log('[MegaNexus] item_open %smeta probe failed for %s: %s' % (words, canonical_id, exc), xbmc.LOGWARNING)
        meta = {'id': canonical_id, 'type': media_type, 'name': title or canonical_id}
    try:
        if _to_player(meta, media_type, title=title):
            return True, meta
    except Exception as exc:
        xbmc.log('[MegaNexus] %splayer redirect failed for %s: %s' % (words, canonical_id, exc), xbmc.LOGWARNING)
    return False, meta


def open_title(media_type, canonical_id, title='', tmdb_id='', imdb_id='', tvdb_id='', source_provider_id=''):
    """A title clicked in a list: a film plays (through TMDb Helper or another player when chosen),
    a show opens its seasons (here or in TMDb Helper)."""
    media_type = (media_type or 'movie').strip().lower()
    name = title or canonical_id
    spid = source_provider_id or ''
    if not is_show(media_type):
        if _helper_called():
            return play_item(media_type=media_type, canonical_id=canonical_id, title=name, tmdb_id=tmdb_id, imdb_id=imdb_id,
                             tvdb_id=tvdb_id, source_provider_id=spid)
        mode = _click_behaviour()
        if mode != 'meganexus':
            if mode == 'tmdbhelper' and _open_in_helper(media_type, canonical_id, name, tmdb_id, imdb_id, tvdb_id):
                return
            if _open_in_player(media_type, canonical_id, title, source_provider_id, 'movie ')[0]:
                return
        _play_note('item-open-movie', media_type=media_type, canonical_id=canonical_id, title=name)
        return play_item(media_type=media_type, canonical_id=canonical_id, title=name, source_provider_id=spid)
    if _click_behaviour() == 'meganexus':
        return show_meta(media_type, canonical_id, title=name, source_provider_id=spid)
    if _click_behaviour() == 'tmdbhelper' and _open_in_helper(media_type, canonical_id, name, tmdb_id, imdb_id, tvdb_id):
        return
    handed, meta = _open_in_player(media_type, canonical_id, title, source_provider_id, '')
    if handed:
        return
    name = title or (meta or {}).get('name') or canonical_id
    try:
        return show_meta(media_type, canonical_id, title=name, source_provider_id=spid)
    except Exception as exc:
        xbmc.log('[MegaNexus] series_meta failed for %s: %s' % (canonical_id, exc), xbmc.LOGWARNING)
        return show_meta('series', canonical_id, title=name)


def _meta_richness(meta):
    """How complete a meta is (pictures, a real plot, year, episodes, genres, rating; fixed pictures win)."""
    if not isinstance(meta, dict):
        return -1
    score = 2 * sum(1 for key in ('poster', 'background', 'fanart', 'logo', 'clearlogo') if meta.get(key))
    score += 2 * sum(1 for key in ('description', 'overview', 'plot') if meta.get(key) and len(str(meta[key])) > 60)
    score += sum(1 for present in (meta.get('releaseInfo') or meta.get('year'), meta.get('genres'),
                                   meta.get('imdbRating') or meta.get('rating')) if present)
    score += 3 if meta.get('videos') else 0
    return score + (50 if _meta_art_is_strict(meta) else 0)


def _richest_meta(media_type, canonical_id, providers, source_provider_id=''):
    """The title's meta (kept a while): from the add-on it was opened from when that answers,
    else the most complete of every add-on's answer."""
    kept = _meta_kept(media_type, canonical_id, source_provider_id=source_provider_id)
    if kept:
        return kept
    pseudo = _is_meta_pseudo_addon(source_provider_id)

    def keep(meta):
        _meta_keep(media_type, canonical_id, meta, source_provider_id=source_provider_id)
        return meta

    def ask(addon):
        answer = fetch_meta(addon, media_type, canonical_id, timeout_override=fast_timeout('meta'))
        meta = answer.get('meta') or answer.get('metas')
        meta = (meta[0] if meta else None) if isinstance(meta, list) else meta
        if not meta:
            return None
        try:
            if pseudo:
                return _meta_choice.apply_virtual(source_provider_id, media_type, meta) or meta
            return _meta_choice.apply(addon, media_type, meta) or meta
        except Exception as exc:
            xbmc.log('[MegaNexus] meta source override failed for %s: %s' % (
                (addon or {}).get('name') or (addon or {}).get('id') or source_provider_id or '', exc), xbmc.LOGDEBUG)
            return meta
    addons = _meta_from_addon_first(providers, source_provider_id=source_provider_id)
    bare = {'id': canonical_id, 'type': media_type, 'name': canonical_id}
    if not addons:
        return keep(bare)
    first = addons[0]
    if source_provider_id and not pseudo and first and str(first.get('id') or '') == str(source_provider_id):
        try:
            meta = ask(first)
            if meta:
                return keep(meta)
            if _addon_sets_pictures(first):
                seed = dict(bare, title=canonical_id)
                return keep(_meta_choice.apply(first, media_type, seed) or seed)
        except Exception as exc:
            xbmc.log('[MegaNexus] source-context meta probe failed for %s: %s' % (canonical_id, exc), xbmc.LOGDEBUG)
    best, best_score = None, -1
    for _addon, meta in all_at_once(ask, list(addons)):
        if not isinstance(meta, Exception) and meta and _meta_richness(meta) > best_score:
            best, best_score = meta, _meta_richness(meta)
    return keep(best if best is not None else bare)

def _quick_source_meta(media_type, canonical_id, providers, title='', source_provider_id=''):
    cached = _meta_kept(media_type, canonical_id, source_provider_id=source_provider_id)
    if cached:
        return cached, True
    if _needs_exact_meta(source_provider_id):
        try:
            exact = _richest_meta(media_type, canonical_id, providers, source_provider_id=source_provider_id)
            if exact:
                return exact, True
        except Exception as exc:
            xbmc.log('[MegaNexus] exact meta fetch failed for %s/%s: %s' % (media_type, canonical_id, exc), xbmc.LOGDEBUG)
    label = title or canonical_id
    fallback = {
        'id': canonical_id,
        'type': 'series' if media_type in ('series', 'anime', 'show', 'tv') else 'movie',
        'name': label,
        'title': label,
    }
    return fallback, False


# the picture size a server reports, as the label and colour of its pill (Tailwind's -600s)
_QUALITY_PILLS = ((('2160P', '4K'), '4K', 'FF0891B2'), (('1080P',), '1080P', 'FF2563EB'),
                  (('720P',), '720P', 'FF059669'), (('480P',), '480P', 'FFD97706'))


def _quality_mark(video_bits):
    said = set(str(bit).upper() for bit in video_bits or ())
    return next(((label, colour) for names, label, colour in _QUALITY_PILLS if said.intersection(names)),
                ('--', 'FF475569'))


PLEX_COLOR = 'FFE5A00D'   # Plex brand gold
EMBY_COLOR = 'FF52B54B'   # Emby brand green


_DEDUP_EXT_RE = re.compile(r'\.(?:%s)$' % '|'.join(
    'mkv mp4 avi mov wmv flv webm m4v mpg mpeg 3gp m2ts ts vob ogv divx xvid rmvb asf mka'.split()), re.I)
_DEDUP_NONALNUM_RE = re.compile(r'_|[^+\w]')     # all but letters, digits and '+'


def _size_class(value, round_pct=10):
    """The size rounded to steps of ``round_pct`` per cent: two copies of one file a few
    bytes apart land on the same step."""
    try:
        size = float(value or 0)
    except (TypeError, ValueError):
        return ''
    if size <= 0:
        return ''
    ratio = 1.0 + round_pct / 100.0
    return str(int(round(ratio ** round(math.log(size, ratio)))))


def _duplicate_refs(entry):
    """What makes two sources the same file: its name (without extension and punctuation), else
    the torrent and file, else size class with quality, codec, audio and HDR."""
    keys = set()
    name = str(entry.get('filename') or entry.get('name') or '').strip()
    bare = _DEDUP_NONALNUM_RE.sub('', _DEDUP_EXT_RE.sub('', name)).lower() if name else ''
    if len(bare) >= 8:
        keys.add('f:' + bare)
    info_hash = str(entry.get('info_hash') or '').strip().lower()
    if len(info_hash) >= 32:
        keys.add('h:%s|%s' % (info_hash, entry.get('file_idx') or 0))
    size = '' if keys else _size_class(entry.get('size_bytes'))
    if size:
        keys.add('s:' + '|'.join([size] + [str(entry.get(k) or '').lower() for k in ('quality', 'video_codec', 'audio', 'hdr')]))
    return keys


def _duplicate_preference(entry, priority):
    """Which of two same sources stays (lower wins): a media server's, then the preferred add-on order, then the bigger file."""
    addon = str(entry.get('provider_name_raw') or entry.get('addon') or '')
    lowered = addon.lower()
    order = priority.index(lowered) if lowered in priority else len(priority)
    try:
        size = -int(entry.get('size_bytes') or 0)
    except (TypeError, ValueError):
        size = 0
    return (0 if addon.startswith(('Plex • ', 'Emby • ')) else 1, order, size)


def merge_duplicate_sources(entries, mode='single', priority=None):
    """Sources that are the same file (shared duplicate keys) merged: the preferred one kept
    ('per_addon': the preferred one of each add-on); returns (kept, how many removed)."""
    entries = list(entries or [])
    if mode == 'off' or len(entries) < 2:
        return entries, 0
    priority = [str(p).lower() for p in priority or []]
    links, first_with = _Linked(), {}
    for place, entry in enumerate(entries):
        links.up.setdefault(place, place)
        for key in _duplicate_refs(entry):
            if key in first_with:
                links.join(first_with[key], place)
            else:
                first_with[key] = place
    groups = {}
    for place in range(len(entries)):
        groups.setdefault(links.head(place), []).append(place)
    rank = lambda place: _duplicate_preference(entries[place], priority)
    kept = set()
    for members in groups.values():
        if len(members) == 1 or mode != 'per_addon':
            kept.add(min(members, key=rank))
            continue
        best = {}
        for place in members:
            addon = str(entries[place].get('provider_name_raw') or '?')
            if addon not in best or rank(place) < rank(best[addon]):
                best[addon] = place
        kept.update(best.values())
    out = [entry for place, entry in enumerate(entries) if place in kept]
    removed = len(entries) - len(out)
    if removed:
        xbmc.log('[MegaNexus] source dedup: %d -> %d (%d duplicates removed, mode=%s)' % (len(entries), len(out), removed,
                                                                                         mode), xbmc.LOGINFO)
    return out, removed


def _dedup_mode():
    try:
        raw = str(ADDON.getSetting('source_dedup_mode') or '').strip().lower()
    except Exception:
        return 'off'
    if raw.startswith('single'):
        return 'single'
    if raw.startswith('one per'):
        return 'per_addon'
    return 'off'


def source_tags_line(tags, size_label='', provider=''):
    """'Add-on · BluRay · x265 · HDR · DD+ 5.1 · EN · 12 GB' - a source's tags in one line."""
    bits = [provider] if provider else []
    bits += [tags[key][0] for key in ('source', 'encode') if tags.get(key)]
    bits += list((tags.get('visual') or [])[:2])
    if tags.get('audio'):
        bits.append(tags['audio'][0] + (' ' + tags['channels'][0] if tags.get('channels') else ''))
    elif tags.get('channels'):
        bits.append(tags['channels'][0])
    bits += list((tags.get('languages') or [])[:3])
    if size_label and size_label != '--':
        bits.append(size_label)
    return ' · '.join(bits)


_DETAIL_HINTS = ('filename', 'videoSize', 'bingeGroup', 'sourceType', 'quality', 'resolution', 'codec', 'audioChannels',
                 'nativeProvider', 'serverType')


def _source_details(row, provider_name, facts=None, provider_origin=''):
    """A source's details text (the source info panel): where it comes from, its names, the
    formatter's fields, subtitles and the telling behaviorHints."""
    facts = facts or _stream_facts(row, provider_name, provider_origin=provider_origin)
    addon, site = facts.get('addon') or '', facts.get('site') or ''
    lines = [('provider', provider_name or 'Provider'),
             ('provider URL', facts.get('provider_url') or _safe_http_origin(provider_origin)), ('addon', addon),
             ('addon URL', facts.get('addon_url')), ('service', facts.get('service') or ''),
             ('indexer', facts.get('indexer') or ''), ('site', site if site != addon else '')]
    lines += [(key, _clean_stream_text(row[key])) for key in ('name', 'title', 'filename') if row.get(key)]
    formatted = facts.get('_formatter') or {}
    if formatted:
        lines += [(key, _clean_stream_text(formatted[key])) for key in ('file', 'title', 'video', 'audio', 'size', 'lang',
                                                                       'subs') if formatted.get(key)]
    elif row.get('description'):
        lines.append(('description', _clean_stream_text(row['description'])))
    if row.get('subtitles'):
        lines.append(('subtitles', _subtitle_summary(row.get('subtitles') or [])))
    text = ['%s: %s' % pair for pair in lines if pair[1]]
    hints = row.get('behaviorHints') or {}
    if isinstance(hints, dict):
        telling = dict((key, hints[key]) for key in _DETAIL_HINTS if hints.get(key) not in (None, '', [], {}))
        try:
            if telling:
                text.append('behaviorHints: %s' % json.dumps(telling, ensure_ascii=False, separators=(',', ':')))
        except Exception:
            pass
    return '\n'.join(text)


_SESSION_HINTS = (('bootstrapUrl', 'bootstrapUrl'), ('companionUrl', 'companionUrl'),
                  ('companionScrobbleUrl', 'companionScrobbleUrl'), ('companionUnscrobbleUrl', 'companionUnscrobbleUrl'),
                  ('sessionIdentifier', 'sessionIdentifier'), ('playbackSessionId', 'playbackSessionId'),
                  ('clientIdentifier', 'clientIdentifier'), ('plexDuration', 'duration_ms'), ('serverType', 'server_type'),
                  ('serverUrl', 'server_url'), ('token', 'token'), ('itemId', 'item_id'), ('deviceId', 'device_id'),
                  ('sessionId', 'session_id'), ('durationMs', 'duration_ms'))


_SERVER_SESSION_KEYS = ('rating_key', 'client_id', 'device_name', 'product', 'product_version', 'item_id', 'device_id',
                        'session_id', 'server_flavor', 'media_source_id', 'play_session_id')


def _player_session_of(ctx):
    """What the companion needs to report the playback: an add-on's companion links, else the
    media server's own session ({} when neither)."""
    hints = ctx.get('behaviorHints') if isinstance(ctx.get('behaviorHints'), dict) else {}
    session = {}
    for hint, field in _SESSION_HINTS:
        if hints.get(hint) not in (None, ''):
            session[field] = hints[hint]
    if session.get('duration_ms'):
        try:
            session['duration_ms'] = int(float(session['duration_ms']))
        except Exception:
            session['duration_ms'] = int(ctx.get('duration_ms') or 0)
    elif ctx.get('duration_ms'):
        session['duration_ms'] = int(ctx.get('duration_ms') or 0)
    session['clientIdentifier'] = session.get('clientIdentifier') or 'MegaNexus-Kodi'
    if isinstance(session.get('server_type'), str) and session['server_type']:
        session['server_type'] = session['server_type'].lower()
    session.update(deviceName='Kodi', product='MegaNexus')
    if any(session.get(k) for k in ('companionUrl', 'companionScrobbleUrl', 'companionUnscrobbleUrl')):
        return session
    if not all(ctx.get(k) for k in ('server_type', 'server_url', 'token')):
        return {}
    direct = {'server_type': ctx['server_type'], 'server_url': ctx['server_url'], 'token': ctx['token'],
              'duration_ms': int(ctx.get('duration_ms') or 0)}
    direct.update((key, ctx[key]) for key in _SERVER_SESSION_KEYS if ctx.get(key))
    return direct

# what a playback's session keeps of its context
_SESSION_CTX_COPY_KEYS = tuple('''
    playback_uid playback_created_at external_ids duration_ms server_id show_tmdb_id media_type
    canonical_id video_id title show_title year season episode imdb_id tmdb_id tvdb_id provider_id
    provider_name provider_base_url subtitles stream_url poster background clearlogo genre rating studio
    premiered duration kodi_info cast resume_seconds resume_percent meganexus_request_id
    meganexus_resume_exact next_episode switch_subtitle_path switch_subtitle_enabled
    switch_subtitle_name server_type server_url token item_id rating_key media_source_id play_session_id
    device_id session_id server_flavor'''.split())


def _session_from_playback(target, ctx, fallback_keys, include_stream_url=True):
    """The player session filled from the playback (with the source list link and the next episode)."""
    target.update((key, ctx.get(key)) for key in _SESSION_CTX_COPY_KEYS
                  if ctx.get(key) not in (None, '') and (include_stream_url or key != 'stream_url'))
    target.pop('fallback_stream_keys', None)
    try:
        picker = source_list_url_for(ctx)
        if picker:
            target['source_picker_url'] = picker
    except Exception:
        pass
    following = ctx.get('next_episode') or _next_episode_of(ctx)
    if following:
        target['next_episode'] = following
    return target


# What the item being played publishes on the Home window: our own meganexus.source.* for the
# loading and player screens, and (without the Kodi 22 safe handoff) the generic and Arctic
# Fuse names skins read for "now playing".
_SOURCE_FIELDS = ('clearlogo', 'poster', 'thumb', 'fanart', 'title', 'plot', 'year', 'genre', 'studio', 'rating')
_LOGO_NAMES = ('clearlogo', 'logo', 'tvshow.clearlogo')
_SKIN_PICTURES = (('poster', 'poster'), ('thumb', 'poster'), ('fanart', 'fanart'), ('fanart_image', 'fanart'),
                  ('landscape', 'fanart'), ('tvshow.poster', 'poster'), ('tvshow.fanart', 'fanart'),
                  ('tvshow.landscape', 'fanart'), ('studio', 'studio'), ('genre', 'genre'), ('rating', 'rating'))
_ARCTIC_NOW = ('Logo:clearlogo', 'Thumb:poster', 'Fanart:fanart', 'Title:title', 'Plot:plot', 'Year:year',
               'Studio:studio', 'Genre:genre', 'Rating:rating')
_ARCTIC_PLAYER = ('Logo:clearlogo', 'Thumb:poster', 'Fanart:fanart', 'Studio:studio', 'Genre:genre', 'Rating:rating')


def _player_picture_props(ctx):
    home = xbmcgui.Window(WINDOW_ID)
    logo = ctx.get('clearlogo') or ''
    for name in ('meganexus.clearlogo',) + _LOGO_NAMES[::2]:
        home.setProperty(name, logo)
    poster = _usable_poster(ctx.get('poster') or '', fallback=ctx.get('background') or '', imdb_id=ctx.get('imdb_id') or '')
    fanart = ctx.get('background') or poster or neutral_fanart()
    if poster:
        home.setProperty('meganexus.poster', poster)
    home.setProperty('meganexus.fanart', fanart)
    try:
        shown = {'clearlogo': logo, 'poster': poster, 'thumb': poster, 'fanart': fanart,
                 'title': ctx.get('title') or '', 'plot': ctx.get('plot') or ''}
        shown.update((field, str(ctx.get(field) or '')) for field in ('year', 'genre', 'studio', 'rating'))
        for field in _SOURCE_FIELDS:
            home.setProperty('meganexus.source.' + field, shown[field])
        home.setProperty('meganexus.source.key', _source_picture_ref(ctx))
        for name in _LOGO_NAMES:
            home.setProperty(name, logo)
        if _safe_start_on():
            for name in ('ArcticFuse.NowPlaying.Logo', 'ArcticFuse.Player.Logo'):
                home.setProperty(name, logo)
            home.setProperty('ArcticFuse.CurrentlyPlaying', 'true' if logo else '')
            return
        for name, field in _SKIN_PICTURES:
            home.setProperty(name, shown[field])
        home.setProperty('tmdb_type', _tmdb_kind_of(ctx))
        for name, keys in (('tmdb_id', ('tmdb_id',)), ('imdb_id', ('imdb_id', 'IMDBNumber')), ('tvdb_id', ('tvdb_id',))):
            if ctx.get(name):
                for key in keys:
                    home.setProperty(key, str(ctx[name]))
        for group, fields in (('NowPlaying', _ARCTIC_NOW), ('Player', _ARCTIC_PLAYER)):
            for pair in fields:
                suffix, field = pair.split(':')
                home.setProperty('ArcticFuse.%s.%s' % (group, suffix), shown[field])
        home.setProperty('ArcticFuse.CurrentlyPlaying', 'true')
        episode = ctx.get('season') and ctx.get('episode')
        label = 'S%02dE%02d' % (int(ctx.get('season') or 0), int(ctx.get('episode') or 0)) if episode else ''
        for group in ('NowPlaying', 'Player'):
            for suffix, value in (('Episode', label), ('ShowTitle', ctx.get('show_title') or shown['title'])):
                if episode:
                    home.setProperty('ArcticFuse.%s.%s' % (group, suffix), value)
                else:
                    home.clearProperty('ArcticFuse.%s.%s' % (group, suffix))
    except Exception:
        pass


_NOT_SERVER_IDS = ('tt', 'tmdb:', 'tvdb:', 'kitsu:', 'mal:', 'anilist:')


def _refresh_server_playback(ctx):
    """An Emby / Jellyfin source asked for a fresh playback (address, media source, session,
    subtitles) just before it plays; on failure the stored address is used."""
    ctx = dict(ctx or {})
    if str(ctx.get('server_type') or '').lower() != 'emby' or ctx.get('native_playback_resolved'):
        return ctx
    candidate = str(ctx.get('video_id') or '')
    item_id = str(ctx.get('item_id') or '') or (candidate if candidate and not candidate.lower().startswith(_NOT_SERVER_IDS)
                                                else '')
    url, token = str(ctx.get('server_url') or ''), str(ctx.get('token') or '')
    if not (item_id and url and token):
        return ctx
    try:
        account = _emby.account_for_url(url) or {}
        server = {'id': account.get('user_id') or 'emby', 'name': account.get('server_name') or 'Emby', 'url': url,
                  'token': token, 'user_id': account.get('user_id') or ''}
        fresh = _emby.playable_of(server, item_id, str(ctx.get('media_source_id') or ''))
        for field, key in (('stream_url', 'url'), ('media_source_id', 'media_source_id'), ('session_id', 'play_session_id')):
            if fresh.get(key):
                ctx[field] = fresh[key]
        subtitles = (fresh.get('version') or {}).get('subtitles')
        if subtitles:
            ctx['subtitles'] = list(subtitles)
        ctx['native_playback_resolved'] = True
    except Exception as exc:
        xbmc.log('[MegaNexus] Emby PlaybackInfo refresh failed; using direct fallback: %s' % exc, xbmc.LOGWARNING)
    return ctx


def _apply_meganexus_resume_item(item, info, ctx):
    """No resume point for Kodi at all (no resume dialog, no StartOffset): the film opens at
    0:00 and the companion's resume coordinator jumps to the position once picture and sound
    are open (7.0.55). Kodi on CoreELEC opened a DTS-HD film mid-way with only its DTS core,
    the receiver output failed and Kodi filled the RAM until the system killed it."""
    if not ctx.get('meganexus_request_id'):
        return
    info.pop('resumetime',None)


def _ctx_ids(ctx):
    return dict((key, ctx.get(key) or '') for key in ('imdb_id', 'tmdb_id', 'tvdb_id'))


def _prefetch_subtitles_early(ctx):
    """With 'play with subtitles' and nothing chosen yet, subtitle search starts now, not after the item is built."""
    if not ctx.get('play_with_subtitles') or ctx.get('source_switch_reuse_subtitle') or ctx.get('selected_subtitle') \
            or ctx.get('subtitles'):
        return
    try:
        _subtitle_prefetch_start(ctx.get('media_type') or 'movie', ctx.get('canonical_id') or ctx.get('video_id') or '',
                                 ids=_ctx_ids(ctx), title=ctx.get('title') or ctx.get('show_title') or '',
                                 season=ctx.get('season'), episode=ctx.get('episode'))
    except Exception as exc:
        xbmc.log('[MegaNexus] fast subtitle prefetch start failed: %s' % exc, xbmc.LOGDEBUG)


def _begin_playback_session(ctx, stream_key):
    """A fresh playback id, complete ids and pictures; the context published for the service,
    the companion session saved and the player pictures set."""
    ctx = dict(_refresh_server_playback(ctx) or {})
    try:
        import uuid
        ctx['playback_uid'] = uuid.uuid4().hex
        ctx['playback_created_at'] = int(time.time() * 1000)
    except Exception:
        ctx['playback_uid'] = '%d-%s' % (int(time.time() * 1000), str(stream_key or 'stream'))
    ctx = _with_playback_pictures(_with_playback_ids(ctx))
    xbmcgui.Window(WINDOW_ID).setProperty(PROP, json.dumps(ctx))
    _play_note('play-request', stream_key=stream_key, title=ctx.get('title') or '',
                      media_type=ctx.get('media_type') or '', canonical_id=ctx.get('canonical_id') or '',
                      provider=_ctx_provider(ctx), video_id=ctx.get('video_id') or '', fallback_count=0)
    session = _player_session_of(ctx)
    full = bool(session)
    session = session or {'stream_url': ctx.get('stream_url') or ''}
    _session_from_playback(session, ctx, [], include_stream_url=full)
    if stream_key:
        session['stream_key'] = stream_key
    save_session(session)
    _drop_next_up_cache()
    _player_picture_props(ctx)
    return ctx


def _ctx_provider(ctx):
    return ctx.get('provider_name') or ctx.get('provider_id') or ''


def _abort_playback(ctx, stream_key):
    _forget_helper_handoff()
    _forget_source_scan_props(clear_global=True)
    _play_note('play-missing-url', level=xbmc.LOGERROR, stream_key=stream_key, title=ctx.get('title') or '',
                      canonical_id=ctx.get('canonical_id') or '')
    if HANDLE >= 0:
        try:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        except Exception:
            pass
    error(tr('No playback URL'))


# list item property -> the context's id
_PLAY_ID_PROPERTIES = (('imdb', 'imdb_id'), ('imdbnumber', 'imdb_id'), ('VideoPlayer.IMDBNumber', 'imdb_id'),
                       ('tmdb', 'tmdb_id'), ('tmdb_id', 'tmdb_id'), ('tvshow.tmdb_id', 'tmdb_id'),
                       ('tvdb', 'tvdb_id'), ('tvdb_id', 'tvdb_id'), ('tvshow.tvdb_id', 'tvdb_id'))


def _fill_play_info(item, ctx, info, minimal):
    """The video information: only the label with the Kodi 22 minimal item, else the InfoTag
    (setInfo where that fails or Kodi is older)."""
    cast = info.pop('cast', None) if isinstance(info.get('cast'), list) else None
    tagged = False
    if minimal:
        xbmc.log('[MegaNexus] playback item: minimal (Kodi 22 safe) — InfoTag skipped', xbmc.LOGINFO)
        try:
            item.setLabel(str(info.get('title') or ctx.get('title') or ''))
        except Exception:
            pass
    elif _KODI_MAJOR >= 20:
        try:
            xbmc.log('[MegaNexus] playback InfoTag: applying full tag', xbmc.LOGINFO)
            tagged = _videoinfotag_apply(item, info, ids=_ctx_ids(ctx), cast=cast)
            xbmc.log('[MegaNexus] playback InfoTag: full tag applied', xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log('[MegaNexus] playback InfoTag apply failed, falling back: %s' % exc, xbmc.LOGWARNING)
    if not tagged and not minimal:
        try:
            item.setInfo('video', info)
        except Exception:
            pass
    _put_unique_ids(item, _ctx_ids(ctx), info)
    try:
        for name, key in _PLAY_ID_PROPERTIES:
            if ctx.get(key):
                item.setProperty(name, str(ctx[key]))
        item.setProperty('tmdb_type', _tmdb_kind_of(ctx))
        for key in ('season', 'episode'):
            if ctx.get(key) not in (None, ''):
                item.setProperty(key, str(ctx[key]))
    except Exception:
        pass


def _play_pictures(ctx):
    """The player pictures, with the logo / background / poster of the picture source chosen
    in Artwork when it is already cached (never waits on the network)."""
    art = _play_pictures_of(ctx)
    try:
        from .art_provider import active, pictures
        wanted = dict((kind, source) for kind, source in active().items() if kind in ('clearlogo', 'fanart', 'poster'))
        for kind, url in ((pictures(ctx, wanted, cached_only=True) if wanted else None) or {}).items():
            art[kind] = url
            if kind == 'poster':
                art['thumb'] = art['icon'] = url
            elif kind == 'fanart':
                art['landscape'] = art['banner'] = url
    except Exception:
        pass
    return art


def _tag_pictures(item, art, is_episode):
    """Kodi 20+ also reads pictures from the InfoTag; with the safe handoff only the logo."""
    if _KODI_MAJOR < 20 or _playlist_start_on_kodi22():
        return
    try:
        tag = item.getVideoInfoTag(offscreen=True)
        if _safe_start_on():
            given = dict((key, art[key]) for key in ('clearlogo', 'logo') if art.get(key))
            if is_episode and art.get('clearlogo'):
                given['tvshow.clearlogo'] = art['clearlogo']
        else:
            given = dict((key, value) for key, value in art.items() if value)
        if given and hasattr(tag, 'setArtwork'):
            tag.setArtwork(given)
    except Exception as exc:
        xbmc.log('[MegaNexus] playback InfoTag setArtwork failed: %s' % exc, xbmc.LOGWARNING)


def _tag_ids_last(item, ctx, is_episode):
    """The ids once more on the InfoTag after the pictures (setArtwork can drop them on some Kodi builds)."""
    if _KODI_MAJOR < 20 or not any(_ctx_ids(ctx).values()):
        return
    try:
        xbmc.log('[MegaNexus] playback InfoTag: re-asserting unique IDs', xbmc.LOGINFO)
        tag = item.getVideoInfoTag(offscreen=True)
        found, default = _unique_id_map(_ctx_ids(ctx), is_episode)
        tag.setUniqueIDs(found, default)
        if ctx.get('imdb_id'):
            try:
                tag.setIMDBNumber(str(ctx['imdb_id']))
            except Exception:
                pass
        xbmc.log('[MegaNexus] playback IDs → InfoTag: %s (default=%s), clearlogo=%s' % (
            ','.join('%s=%s' % (k, v[:8]) for k, v in found.items()), default,
            'yes' if ctx.get('clearlogo') else 'no'), xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] playback InfoTag setUniqueIDs re-assert failed: %s' % exc, xbmc.LOGWARNING)


def _attach_play_subtitles(item, ctx, stream_key):
    """The chosen (or best) subtitle on the item; the rest, the default track and any search
    still to run go to the post-start job."""
    tag = stream_key or 'play'
    reused = bool(ctx.get('source_switch_reuse_subtitle') and ctx.get('switch_subtitle_path'))
    forced = bool(ctx.get('play_with_subtitles')) and not reused
    request = ctx.get('meganexus_request_id')
    rows = [] if reused or request else _gather_subtitles(ctx, include_broker=forced)
    discovery = bool(not request and not reused and not forced and _setting_bool('enable_stremio_subtitle_broker', True))
    first, others = _subtitle_selected_first(rows, forced, ctx.get('selected_subtitle') or '', ctx, _first_subtitle_index)
    prepared = _subtitle_paths(first, tag, local_copy=True, later=False)
    if rows and _is_server_stream(ctx):
        # a media server's stream: every subtitle goes on the item now
        prepared.extend(_subtitle_paths(others, tag, local_copy=True, later=True))
        others = []
    paths = [row.get('path') for row in prepared if row.get('path')]
    if forced and not paths and not others:
        try:
            notify(tr('No matching subtitle was found for this add-on'))
        except Exception:
            pass
    chosen_path, chosen_index = _subtitle_to_turn_on(prepared, paths)
    if paths:
        try:
            item.setSubtitles(paths)
        except Exception:
            pass
    attach_later = bool(others and not _playlist_start_on_kodi22())
    try:
        index = int(chosen_index) if chosen_index is not None and int(chosen_index) >= 0 else -1
    except Exception:
        index = -1
    if request and ADDON.getSetting('meganexus_subtitles_on_start') == 'true':
        from .meganexus_subtitles import preferred
        ctx['meganexus_subtitle_language'] = preferred()
    if chosen_path or index >= 0 or forced or attach_later or discovery or ctx.get('meganexus_subtitle_language'):
        try:
            _publish_post_start_job(ctx, stream_key=tag, subtitle_path=chosen_path or '', subtitle_index=index,
                                    force_subtitles=forced, existing_paths=list(paths), subtitle_rows=rows,
                                    attach_rows=others if attach_later else [], discovery=discovery)
        except Exception as exc:
            xbmc.log('[MegaNexus] post-start job publish failed: %s' % exc, xbmc.LOGWARNING)


def _resume_requested(ctx):
    try:
        return float(ctx.get('resume_seconds') or 0.0) > 1.0 or 1.0 < float(ctx.get('resume_percent') or 0.0) < 95.0
    except Exception:
        return False


def _hand_to_player(item, ctx, stream_url, stream_key, use_resolved_url):
    """setResolvedUrl when Kodi asked this plug-in for the item and nothing seeks or redirects;
    otherwise the player (Kodi 22: through the video playlist)."""
    if use_resolved_url is None:
        try:
            action = dict(parse_qsl(sys.argv[2].lstrip('?'))).get('action', '')
        except Exception:
            action = ''
        use_resolved_url = (HANDLE >= 0 and action in ('play_item', 'cw_resume', 'cw_play_from_start', 'play',
                                                        'plex_play', 'emby_play') and not _resume_requested(ctx))
    playlist_way = _playlist_start_on_kodi22()
    if playlist_way or (_KODI_MAJOR >= 22 and not _safe_start_on()) \
            or str(stream_url or '').lower().startswith(('plugin://', 'magnet:')):
        use_resolved_url = False
    if ctx.get('meganexus_request_id'):
        item.setProperty('meganexus.request', ctx['meganexus_request_id'])
    if use_resolved_url:
        _play_note('play-handoff', handoff='setResolvedUrl', handle=HANDLE, stream_key=stream_key,
                          provider=_ctx_provider(ctx))
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    elif playlist_way:
        # The handoff owns playback now: no setResolvedUrl(False) here - Kodi would mark
        # the playlist item unplayable and skip it.
        xbmc.log('[MegaNexus] playback: entering Kodi22 playlist handoff (minimal_item=%s)'
                 % _bare_item_on_kodi22(), xbmc.LOGINFO)
        _play_note('play-handoff', handoff='Kodi22Playlist.play', handle=HANDLE, stream_key=stream_key,
                          provider=_ctx_provider(ctx))
        try:
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            playlist.add(stream_url, item)
            xbmc.Player().play(playlist)
        except Exception:
            xbmc.Player().play(stream_url, item)
    else:
        _play_note('play-handoff', handoff='Player.play', handle=HANDLE, stream_key=stream_key,
                          provider=_ctx_provider(ctx))
        xbmc.Player().play(stream_url, item)
    _watch_selector_cancel(ctx, stream_url)


def _start_playback(ctx, stream_key='', fallback_keys=None, entries_meta=None, use_resolved_url=None):
    """Play the chosen stream: the session and pictures published, the list item filled
    (information, ids, pictures, subtitles) and handed to Kodi."""
    ctx = dict(ctx or {})
    _prefetch_subtitles_early(ctx)
    ctx = _begin_playback_session(ctx, stream_key)
    stream_url = _url_with_title_ids(ctx.get('stream_url') or '', ctx)
    ctx['stream_url'] = stream_url or ctx.get('stream_url') or ''
    if not stream_url:
        _abort_playback(ctx, stream_key)
        return
    try:
        item = xbmcgui.ListItem(path=stream_url, offscreen=True)
    except TypeError:
        item = xbmcgui.ListItem(path=stream_url)
    is_episode = bool(ctx.get('season') or ctx.get('episode'))
    info = _play_info_of(ctx)
    _apply_meganexus_resume_item(item, info, ctx)
    _fill_play_info(item, ctx, info, _bare_item_on_kodi22())
    _publish_subtitle_ids(ctx, is_episode)
    item.setProperty('IsPlayable', 'true')
    art = _play_pictures(ctx)
    try:
        item.setArt(art)
    except Exception:
        pass
    _tag_pictures(item, art, is_episode)
    if not _bare_item_on_kodi22():
        _tag_ids_last(item, ctx, is_episode)
    try:
        item.setProperties(_player_props(ctx, art, info))
    except Exception:
        pass
    _attach_play_subtitles(item, ctx, stream_key)
    if _resume_requested(ctx):
        xbmc.log('[MegaNexus] native resume hint suppressed; companion resume coordinator owns seek', xbmc.LOGINFO)
    for dialog in ('busydialog', 'busydialognocancel'):
        try:
            xbmc.executebuiltin('Dialog.Close(%s,true)' % dialog)
        except Exception:
            pass
    if ctx.get('meganexus_request_id') and xbmcgui.Window(10000).getProperty(
            'meganexus.cancelled.' + ctx['meganexus_request_id']):
        return False
    try:
        _hand_to_player(item, ctx, stream_url, stream_key, use_resolved_url)
    except Exception as exc:
        _play_note('play-handoff-failed', level=xbmc.LOGERROR, error=exc, stream_key=stream_key,
                          title=ctx.get('title') or '', provider=_ctx_provider(ctx))
        xbmc.log('[MegaNexus] playback handoff failed: %s' % exc, xbmc.LOGERROR)
        _forget_helper_handoff()
        _forget_source_scan_props(clear_global=True)


def _next_episode_of(ctx):
    """The episode after the playing one (next in the season, else the next season's first) from
    the show's episode list in the window; None when unknown."""
    try:
        season, episode = int(ctx.get('season') or 0), int(ctx.get('episode') or 0)
    except Exception:
        return None
    canonical = ctx.get('canonical_id') or ''
    if not canonical or season <= 0 or episode <= 0 or (ctx.get('media_type') or '').lower() not in ('series', 'anime',
                                                                                                    'show', 'tv'):
        return None
    try:
        raw = xbmcgui.Window(WINDOW_ID).getProperty(SERIES_PROP_PREFIX + canonical) or ''
        videos = json.loads(raw) if raw else []
    except Exception:
        videos = []
    for want in ((season, episode + 1), (season + 1, 1)):
        for video in videos:
            try:
                if (int(video.get('season') or 0), int(video.get('episode') or 0)) != want:
                    continue
            except Exception:
                continue
            return {'canonical_id': canonical, 'video_id': video.get('id') or canonical, 'season': want[0],
                    'episode': want[1], 'title': ctx.get('show_title') or ctx.get('title') or canonical,
                    'name': video.get('name') or video.get('title') or '', 'still': video.get('thumbnail') or ''}
    return None


def _same_addon_key(entry):
    addon = str(entry.get('provider_name_raw') or entry.get('addon') or '')
    url = str(entry.get('stream_url') or '').strip()
    info_hash = str(entry.get('info_hash') or '').strip().lower()
    if url:
        return ('u', addon, url)
    return ('h', addon, info_hash, str(entry.get('file_idx') or 0)) if len(info_hash) >= 32 else None


def _merge_same_addon_rows(entries):
    """One add-on's rows that are the same address (or torrent file) once; (kept, how many removed)."""
    entries = list(entries or [])
    if len(entries) < 2:
        return entries, 0
    seen, kept = set(), []
    for entry in entries:
        key = _same_addon_key(entry)
        if key is None or key not in seen:
            kept.append(entry)
            if key is not None:
                seen.add(key)
    return kept, len(entries) - len(kept)


def _kodi_header_suffix(headers):
    if not headers:
        return ''
    pairs = []
    try:
        if isinstance(headers, dict):
            iterable = headers.items()
        elif isinstance(headers, (list, tuple)):
            iterable = headers
        else:
            iterable = []
        for key, value in iterable:
            key = str(key or '').strip()
            if not key or value in (None, ''):
                continue
            pairs.append((key, str(value)))
    except Exception:
        pairs = []
    if not pairs:
        return ''
    try:
        return urlencode(pairs)
    except Exception:
        return '&'.join('%s=%s' % (quote_plus(k), quote_plus(v)) for k, v in pairs)


def _header_pairs(value):
    if isinstance(value, dict):
        return list(value.items())
    return list(value) if isinstance(value, (list, tuple)) else []


def _row_headers(row):
    """The HTTP headers a source asks Kodi to send (request headers, headers, behaviorHints' and proxyHeaders' request)."""
    if not isinstance(row, dict):
        return {}
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    proxy = hints.get('proxyHeaders') or {}
    sources = [row.get('requestHeaders'), row.get('headers'), hints.get('requestHeaders')]
    if isinstance(proxy, dict):
        sources.append(proxy.get('request') if ('request' in proxy or 'response' in proxy) else proxy)
    out = {}
    for value in sources:
        if not value:
            continue
        try:
            for key, given in _header_pairs(value):
                key = str(key or '').strip()
                if key and given not in (None, ''):
                    out[key] = str(given)
        except Exception:
            pass
    return out


def _url_with_kodi_headers(url, row):
    url = str(url or '').strip()
    if not url:
        return ''
    if url.lower().startswith('plugin://'):
        return url
    headers = _row_headers(row)
    suffix = _kodi_header_suffix(headers)
    if not suffix:
        return url
    if '|' in url:
        base, existing = url.split('|', 1)
        if existing:
            return base + '|' + existing + '&' + suffix
        return base + '|' + suffix
    return url + '|' + suffix


_TORRENT_PLAYERS = (('plugin.video.elementum', 'plugin://plugin.video.elementum/play?uri=%s'),
                    ('plugin.video.quasar', 'plugin://plugin.video.quasar/play?uri=%s'),
                    ('plugin.video.torrest', 'plugin://plugin.video.torrest/play_magnet?magnet=%s'))


def _torrent_play_url(magnet):
    """A magnet through the first torrent player installed (Elementum, Quasar, Torrest); the magnet itself without one."""
    magnet = str(magnet or '').strip()
    if not magnet:
        return ''
    for addon_id, link in _TORRENT_PLAYERS:
        try:
            xbmcaddon.Addon(addon_id)
        except Exception:
            continue
        return link % quote_plus(magnet)
    return magnet


_TRACKER_STARTS = ('udp://', 'http://', 'https://')


def _magnet_of(row):
    """A magnet link for a torrent row (its own, else built from the info hash, trackers and file index)."""
    if not isinstance(row, dict):
        return ''
    own = str(row.get('url') or '').strip()
    if own.lower().startswith('magnet:'):
        return own
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    info_hash = re.sub(r'[^A-Fa-f0-9]', '', str(next((source.get(k) for source in (row, hints)
                                                      for k in ('infoHash', 'infohash', 'btih') if source.get(k)), '') or ''))
    if len(info_hash) not in (32, 40):
        return ''
    name = (row.get('title') or row.get('name') or row.get('filename') or hints.get('filename') or hints.get('title')
            or hints.get('name') or 'MegaNexus torrent')
    trackers = []
    for value in row.get('sources') or hints.get('sources') or []:
        text = str(value or '').strip()
        if text.lower().startswith(('tracker:', 'dht:') + _TRACKER_STARTS):
            text = re.sub(r'^(tracker:|dht:)', '', text, flags=re.I).strip()
            if text.lower().startswith(_TRACKER_STARTS):
                trackers.append(text)
    magnet = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, quote_plus(str(name or 'MegaNexus torrent')))
    magnet += ''.join('&tr=%s' % quote_plus(tracker) for tracker in trackers[:30])
    index = next((source[k] for source in (row, hints) for k in ('fileIdx', 'fileIndex') if source.get(k) not in (None, '')),
                 None)
    if index is not None:
        magnet += '&so=%s' % quote_plus(str(index))
    return magnet


_MEDIA_ENDINGS = ('.m3u8', '.mp4', '.mkv', '.webm', '.ts', '.avi', '.mov', '.mpd')


_RESOLVER_MARKS = ('/stream/', '/play/', '/resolve/', '/redirect/', 'video=', 'url=')


_NOT_MEDIA = ('/configure', '/settings', '/install', '/manifest.json')


def _external_play_url(row):
    """An externalUrl Kodi can play: an add-on / magnet link, or an http address of a media file or a resolver."""
    external = str(row.get('externalUrl') or '').strip()
    low = external.lower()
    if low.startswith('magnet:'):
        return _torrent_play_url(external)
    if low.startswith('plugin://'):
        return external
    if low.startswith(('http://', 'https://')) and not any(x in low for x in _NOT_MEDIA) and (
            low.split('?', 1)[0].endswith(_MEDIA_ENDINGS) or any(x in low for x in _RESOLVER_MARKS)):
        return _url_with_kodi_headers(external, row)
    return ''


def _row_play_url(row):
    """What Kodi plays for a source row: its url (with its headers; a magnet through the torrent
    player), a magnet built from its hash, a playable externalUrl or an NZB through the Usenet player."""
    if not isinstance(row, dict):
        return ''
    url = str(row.get('url') or '').strip()
    if url:
        return _torrent_play_url(url) if url.lower().startswith('magnet:') else _url_with_kodi_headers(url, row)
    magnet = _magnet_of(row)
    if magnet:
        return _torrent_play_url(magnet)
    external = _external_play_url(row)
    if external:
        return external
    # 7.0.43: an NZB source (nzbUrl + servers, Usenet Streamer's native mode) plays
    # through MegaNexus's local Usenet player (usenet_stream.py)
    if row.get('nzbUrl'):
        try:
            from . import usenet_stream
            return usenet_stream.register(row)
        except Exception as exc:
            xbmc.log('[MegaNexus] Usenet source not registered: %s' % type(exc).__name__, xbmc.LOGWARNING)
    return ''


# behaviorHints of a Plex / Jellyfin / Emby row -> the stream payload's field
_NATIVE_HINTS = (('server_url', 'serverUrl'), ('server_id', 'serverId'), ('token', 'token'), ('rating_key', 'ratingKey'),
                 ('item_id', 'itemId'), ('media_source_id', 'mediaSourceId'), ('part_key', 'partKey'))


def _joined(value):
    return ' / '.join(str(x) for x in value if x) if isinstance(value, (list, tuple)) else (value or '')


def _row_hints(row):
    hints = row.get('behaviorHints') or {}
    return hints if isinstance(hints, dict) else {}


def _row_info_hash(row):
    return str(row.get('infoHash') or row.get('infohash') or _row_hints(row).get('infoHash') or '')


def _apply_native_hints(payload, hints):
    """A row a media server sent through an add-on is played as that server's own."""
    payload['provider_id'] = '%s_native' % hints['nativeProvider']
    payload['server_type'] = str(hints.get('serverType') or hints['nativeProvider'])
    for field, hint in _NATIVE_HINTS:
        payload[field] = str(hints.get(hint) or '')
    payload['duration_ms'] = int(hints.get('durationMs') or payload.get('duration_ms') or 0)
    payload['imdb_id'] = _clean_imdb(hints.get('imdbId') or payload['imdb_id']) or payload['imdb_id'] or ''
    payload['tmdb_id'] = str(hints.get('tmdbId') or payload['tmdb_id'] or '')
    payload['tvdb_id'] = str(hints.get('tvdbId') or payload['tvdb_id'] or '')
    payload['external_ids'] = dict((key, payload[key] or '') for key in ('imdb_id', 'tmdb_id', 'tvdb_id'))


def _stream_payload(row, url, facts, base, resume):
    """What playing this row needs (kept in the cache; the list holds only its key)."""
    hints = _row_hints(row)
    payload = dict(base)
    payload.update({
        'source_addon': facts.get('addon') or base['provider_name'], 'source_indexer': facts.get('indexer') or '',
        'source_service': facts.get('service') or '', 'source_origin': facts.get('origin_line') or base['provider_name'],
        'provider_domain': facts.get('provider_domain') or '', 'addon_url': facts.get('addon_url') or '',
        'addon_domain': facts.get('addon_domain') or '', 'stream_url': url, 'subtitles': row.get('subtitles') or [],
        'behaviorHints': row.get('behaviorHints') or {}, 'duration_ms': int(hints.get('plexDuration') or hints.get('durationMs') or 0),
        'stream_name': row.get('name') or '', 'stream_title': row.get('title') or '',
        'stream_description': row.get('description') or '', 'formatter_tags': [],
        'badge_blob_raw': ' | '.join(_collect_stream_texts(row))[:4096], 'formatter_summary': '',
        'video_bits': facts.get('video_bits') or [], 'audio_bits': facts.get('audio_bits') or [],
        'request_headers': _row_headers(row), 'external_url': row.get('externalUrl') or '',
        'info_hash': row.get('infoHash') or row.get('infohash') or hints.get('infoHash') or '',
    })
    if hints.get('nativeProvider'):
        _apply_native_hints(payload, hints)
    payload.update(resume)
    return payload


def _stream_entry(row, url, facts, key, provider_name, origin, icon, label2, plot):
    """The row as the source list shows it."""
    video, audio, tags = facts['video_bits'], facts['audio_bits'], facts.get('tags') or {}
    kind, kind_label, kind_color = facts.get('source_type') or (('direct',) + _SOURCE_TYPE_STYLES['direct'])
    quality, highlight = _quality_mark(video)
    hints = _row_hints(row)
    addon = facts.get('addon') or provider_name
    return {
        'stream_key': key, 'stream_url': url, 'source_type': kind, 'source_type_label': kind_label,
        'source_type_color': kind_color, 'name': facts['display_name'],
        'label2': label2, 'count': '00.',
        'quality': quality, 'highlight': highlight,
        'provider': facts.get('provider_badge') or _provider_badge(row, provider_name, text_blob=facts.get('_raw_blob') or ''),
        'provider_name_raw': provider_name, 'provider_icon': icon, 'addon': addon,
        'provider_domain': facts.get('provider_domain') or '', 'provider_url': origin,
        'addon_url': facts.get('addon_url') or '', 'addon_domain': facts.get('addon_domain') or '',
        'source_site': facts['site'], 'indexer': facts.get('indexer') or '', 'service_name': facts.get('service') or '',
        'origin_line': facts.get('origin_line') or provider_name, 'size_label': facts['size'] or '--',
        'extraInfo': ' | '.join(video[:8]) if video else '--', 'extraInfo2': ' | '.join(audio[:8]) if audio else '--',
        'badges': _stream_badges(video, audio, row.get('subtitles') or []),
        'source_info': _source_details(row, provider_name, facts=facts, provider_origin=origin) + '\n\n' + plot,
        'filename': str(hints.get('filename') or ''), 'info_hash': _row_info_hash(row),
        'file_idx': (row.get('fileIdx') if row.get('fileIdx') is not None else hints.get('fileIdx')) or 0,
        'size_bytes': _extract_size(hints.get('videoSize'), row.get('size'), row.get('sizebytes')) or 0,
        'video_codec': facts.get('codec') or '', 'audio': facts.get('audio') or '', 'hdr': facts.get('hdr') or '',
        'tags': tags, 'languages': tags.get('languages') or [],
        'tag_line': source_tags_line(tags, size_label=facts.get('size') or '', provider=addon),
    }


def _resume_fields(seconds, percent):
    out = {}
    try:
        if float(seconds or 0.0) > 1.0:
            out['resume_seconds'] = float(seconds)
    except Exception:
        pass
    try:
        if 1.0 < float(percent or 0.0) < 95.0:
            out['resume_percent'] = float(percent)
    except Exception:
        pass
    return out


def _take_addon_streams(entries, data, provider, request_id, media_type, canonical_id, best_meta, art, bg, ids, title='', video_id=None, season=None, episode=None, show_title='', resume_seconds=0.0, resume_percent=0.0):
    """An add-on's stream answer added to `entries` (rows without anything playable are left out)."""
    provider_name = provider.get('name') or 'Provider'
    origin = _addon_origin(provider)
    own = provider_art(provider_name, provider.get('manifest') or {},
                       provider.get('base_url') or provider.get('manifest_url') or '')
    icon = own.get('icon') or own.get('thumb') or media_path('provider.png')
    rows = (data or {}).get('streams') or []
    rows = [rows] if isinstance(rows, dict) else (rows if isinstance(rows, (list, tuple)) else [])
    try:
        xbmc.log('[MegaNexus] Stremio raw streams: provider=%s request=%s rows=%d' % (
            provider_name, request_id, len(rows)), xbmc.LOGINFO)
    except Exception:
        pass
    title = title or best_meta.get('name') or canonical_id
    show = show_title or best_meta.get('name') or canonical_id
    info = _stream_info(best_meta, media_type=media_type, title=title, show_title=show,
                                     season=season, episode=episode)
    base = {
        'media_type': media_type, 'canonical_id': canonical_id, 'video_id': video_id or request_id,
        'provider_name': provider_name, 'provider_id': provider.get('id') or '', 'provider_origin': origin,
        'title': title, 'show_title': show, 'year': _info_of(best_meta).get('year') or 0,
        'poster': art.get('poster') or '', 'background': bg, 'clearlogo': art.get('clearlogo') or '',
        'tmdb_id': ids.get('tmdb_id') or '', 'imdb_id': ids.get('imdb_id') or '', 'tvdb_id': ids.get('tvdb_id') or '',
        'external_ids': ids, 'kodi_info': info,
        'plot': info.get('plot') or best_meta.get('description') or best_meta.get('overview') or '',
        'genre': _joined(info.get('genre')), 'studio': _joined(info.get('studio')),
        'rating': info.get('rating') or best_meta.get('imdbRating') or '', 'premiered': info.get('premiered') or '',
        'duration': info.get('duration') or '', 'cast': info.get('cast') or [],
        'provider_base_url': provider.get('base_url') or '',
    }
    if season is not None:
        base['season'] = int(season)
    if episode is not None:
        base['episode'] = int(episode)
    resume = _resume_fields(resume_seconds, resume_percent)
    before, unplayable = len(entries), 0
    try:
        for row in rows:
            url = _row_play_url(row)
            if not url:
                unplayable += 1
                if unplayable <= 3:
                    try:
                        xbmc.log('[MegaNexus] Stremio row dropped (no playable url): provider=%s name=%r external=%r keys=%s' % (
                            provider_name, (row.get('name') or row.get('title') or '')[:60],
                            str(row.get('externalUrl') or '')[:180], sorted(row.keys())[:12]), xbmc.LOGDEBUG)
                    except Exception:
                        pass
                continue
            facts = _stream_facts(row, provider_name, provider_origin=origin)
            _label, label2, plot = _stream_label(row, provider_name, facts=facts)
            key = keyed_cache.put('stream', _stream_payload(row, url, facts, base, resume))
            entries.append(_stream_entry(row, url, facts, key, provider_name, origin, icon, label2, plot))
    finally:
        if len(entries) > before:
            try:
                _store_source_list(canonical_id, season, episode, entries, poster=art.get('poster') or '')
            except Exception:
                pass
    try:
        xbmc.log('[MegaNexus] Stremio appended streams: provider=%s raw=%d kept=%d dropped_no_url=%d' % (
            provider_name, len(rows), len(entries) - before, unplayable), xbmc.LOGINFO)
    except Exception:
        pass


def _addon_counts_line(entries, max_names=4):
    """'Torrentio: 12 | Comet: 5 | +2' - how many sources each add-on gave."""
    try:
        counts = {}
        for entry in entries or []:
            name = str(entry.get('provider_name_raw') or entry.get('addon') or '?').strip().split(' • ')[0].strip() or '?'
            counts[name] = counts.get(name, 0) + 1
        ranked = sorted(counts.items(), key=lambda pair: -pair[1])
        parts = ['%s: %d' % pair for pair in ranked[:max_names]]
        if len(ranked) > max_names:
            parts.append('+%d' % (len(ranked) - max_names))
        return ' | '.join(parts)
    except Exception:
        return ''


def _addon_signature(provider):
    return _addon_text(provider)


def _addon_wait(provider):
    """How long one add-on's streams are waited for: the slow scrapers (torrent and debrid
    lookups) get the timeout setting, 10 to 25 s; the others the quick stream wait."""
    if not any(word in _addon_signature(provider) for word in ('torrentio', 'comet', 'mediafusion', 'stremthru', 'aiostream')):
        return fast_timeout('stream')
    try:
        setting = int(float(ADDON.getSetting('timeout') or '20'))
    except Exception:
        setting = 20
    return min(max(setting, 10), 25)


def _setting_bool(name, default=False):
    try:
        raw = (ADDON.getSetting(name) or ('true' if default else 'false')).strip().lower()
    except Exception:
        raw = 'true' if default else 'false'
    return raw in ('true', '1', 'yes', 'on')


def _server_client(backend):
    return _plex if backend == 'plex' else _emby


def _server_matches(client, backend, server, ids, kind, titles, deadline):
    """The server's items for the ids, else for each title while the time lasts (each item once)."""
    found, seen = [], set()

    def take(rows):
        for row in rows or []:
            key = str(row.get('rating_key') or '')
            if key and key not in seen:
                seen.add(key)
                found.append(row)
    try:
        take(client.all_by_ids(server, ids, media_type=kind, title='', limit=24))
    except Exception as exc:
        xbmc.log('[MegaNexus] %s id lookup failed: %s' % (backend, exc), xbmc.LOGWARNING)
    if found or time.time() >= deadline:
        return found
    for title in titles or []:
        if not str(title or '').strip():
            continue
        if time.time() >= deadline:
            xbmc.log('[MegaNexus] %s lookup: budget spent — stopping so the Stremio providers keep their time' % backend,
                     xbmc.LOGINFO)
            break
        try:
            take(client.all_by_ids(server, ids, media_type=kind, title=title, limit=24))
        except Exception:
            continue
    return found


def _server_sources(backend, server, ids, media_type, titles,
                        season=None, episode=None):
    """A media server's playable items for the title (for an episode: that episode of each match)."""
    from . import media_servers
    client = _server_client(backend)
    identity = media_servers.lookup_target(media_type, ids, season, episode)
    wait = _get_int_setting('server_lookup_seconds', 7, minimum=4, maximum=60)
    try:
        from .meganexus.addon_wire import provider_health_pause
        provider_health_pause(wait + 2)
    except Exception:
        pass
    matches = _server_matches(client, backend, server, identity.ids, identity.media_type, titles, time.time() + float(wait))
    xbmc.log('[MegaNexus] %s lookup: server=%s ids=%s titles=%d -> %d item(s)' % (
        backend, server.get('name') or '?', ','.join('%s=%s' % (k, v) for k, v in sorted((identity.ids or {}).items()) if v)
        or 'none', len(titles or []), len(matches)), xbmc.LOGINFO)
    if not identity.is_episode:
        return list(matches)
    items = []
    for match in matches:
        try:
            node = client.episode_node_item(server, match, season, episode)
        except Exception:
            node = None
        if node:
            try:
                items.append(client.metadata(server, node.get('rating_key')))
            except Exception:
                items.append(node)
    return items


def _mediabrowser_stream(provider, media_type):
    """The title's versions on one Jellyfin / Emby server, as source rows."""
    server = provider.get('_server') or {}
    title = provider.get('_title') or ''
    ids = provider.get('_ids') or {}
    season, number = provider.get('_season'), provider.get('_episode')
    if not (ids.get('imdb_id') or ids.get('tmdb_id') or title):
        return {}
    episode = is_show(media_type) and season and number
    items = []
    for match in _emby.all_by_ids(server, ids, media_type='series' if episode else 'movie', title=title) or []:
        if not episode:
            items.append(match)
            continue
        node = _emby.episode_node_item(server, match, season, number)
        if node:
            try:
                items.append(_emby.metadata(server, node.get('rating_key')))
            except Exception:
                items.append(node)
    name = server.get('name') or 'Emby'
    rows = [_server_source_row('EMBY', EMBY_COLOR, name, item, version, title, {
        '_url': _emby.playback_url(server, item.get('rating_key'), version.get('media_source_id') or ''),
        'nativeProvider': 'emby', 'serverType': 'emby', 'serverUrl': server.get('url') or '',
        'token': server.get('token') or '', 'itemId': str(item.get('rating_key') or ''),
        'mediaSourceId': str(version.get('media_source_id') or '')})
        for item in items for version in item.get('versions') or []]
    return {'streams': rows} if items else {}


def _server_source_row(label, colour, server_name, item, version, fallback_title, hints):
    """One version of a media-server item as a source row (the same shape an add-on answers with)."""
    filename = os.path.basename(version.get('file') or '') or (item.get('raw_title') or fallback_title)
    facts = ' '.join(x for x in (version.get('resolution'), version.get('hdr'), version.get('video_codec'),
                                 version.get('audio'), version.get('size_label')) if x)
    found = item.get('ids') or {}
    hints = dict(hints, filename=filename, videoSize=version.get('size_bytes') or 0,
                 imdbId=_clean_imdb(found.get('imdb_id')) or '', tmdbId=str(found.get('tmdb_id') or ''),
                 tvdbId=str(found.get('tvdb_id') or ''), durationMs=int(item.get('duration_ms') or 0))
    return {'name': '[COLOR %s]%s NATIVE[/COLOR]\n%s' % (colour, label, server_name), 'title': '%s\n%s' % (filename, facts),
            'url': hints.pop('_url'), 'subtitles': list(version.get('subtitles') or []), 'behaviorHints': hints}


def _plex_stream(provider, media_type):
    """The title's versions on one Plex server, as source rows."""
    server, title, ids = provider.get('_server') or {}, provider.get('_title') or '', provider.get('_ids') or {}
    other_names = list(provider.get('_titles') or [])
    known = set(str(name).casefold() for name in other_names)
    titles = ([title] if title and title.casefold() not in known else []) + other_names
    if not (title or ids.get('imdb_id') or ids.get('tmdb_id') or ids.get('tvdb_id')):
        return {}                         # nothing to find it by
    found = _server_sources('plex', server, ids, media_type, titles, season=provider.get('_season'),
                            episode=provider.get('_episode'))
    if not found:
        xbmc.log('[MegaNexus] Plex Native no match: server=%s title=%s ids=%s' % (
            server.get('name') or '?', title, ','.join('%s=%s' % (key, ids.get(key)) for key in ('imdb_id', 'tmdb_id', 'tvdb_id')
                                                      if ids.get(key)) or 'none'), xbmc.LOGWARNING)
        return {}
    name = server.get('name') or 'Plex'
    rows = []
    for hit in found:
        try:
            item = _plex.metadata(server, hit.get('rating_key'))
        except Exception as exc:
            xbmc.log('[MegaNexus] Plex Native metadata failed: server=%s key=%s error=%s' % (
                name, hit.get('rating_key') or '?', exc), xbmc.LOGWARNING)
            continue
        for version in item.get('versions') or []:
            if not version.get('part_key'):
                continue
            try:
                url = _plex.playback_url(item, part_key=version['part_key'])
            except Exception:
                continue
            rows.append(_server_source_row('PLEX', PLEX_COLOR, name, item, version, title, {
                '_url': url, 'nativeProvider': 'plex', 'serverType': 'plex',
                'serverUrl': item.get('server_url') or server.get('url') or '', 'serverId': str(server.get('id') or ''),
                'token': item.get('token') or server.get('token') or '',
                'ratingKey': str(item.get('rating_key') or hit.get('rating_key') or ''),
                'partKey': str(version.get('part_key') or '')}))
    return {'streams': rows}


def _ask_server(addon, media_type):
    """A Plex / Jellyfin / Emby server's sources ({} while it rests after failures); its health noted."""
    backend = 'plex' if addon.get('id') == '__plex__' else 'emby'
    server = addon.get('_server') or {}
    if not _server_health.should_query(backend, server):
        xbmc.log('[MegaNexus] %s server temporarily skipped by health router: %s' % (backend, server.get('name') or '?'),
                 xbmc.LOGINFO)
        return {}
    started = time.monotonic()
    try:
        answer = _plex_stream(addon, media_type) if backend == 'plex' else _mediabrowser_stream(addon, media_type)
    except Exception:
        _server_health.note_answer(backend, server, time.monotonic() - started, False, 0)
        raise
    count = len((answer or {}).get('streams') or [])
    _server_health.note_answer(backend, server, time.monotonic() - started, True, count)
    xbmc.log('[MegaNexus] %s Native source result: server=%s streams=%d' % (backend.capitalize(), server.get('name') or '?',
                                                                            count), xbmc.LOGINFO)
    return answer


def _ask_addon_streams(target, media_type):
    """One target's stream answer (an add-on's error is returned, a server's logged); every answer
    counts toward the add-on's record (speed, success, how many)."""
    addon, request_id = target
    started = time.monotonic()
    answer, ok = {}, True
    try:
        if (addon or {}).get('id') in ('__plex__', '__emby__'):
            answer = _ask_server(addon, media_type)
        else:
            try:
                answer = _stremio_adapter.fetch(addon, media_type, request_id, timeout_override=_addon_wait(addon))
            except Exception as exc:
                ok = False
                return exc
        return answer
    except Exception as exc:
        ok = False
        xbmc.log('[MegaNexus] provider source error: %s' % exc, xbmc.LOGWARNING)
        return {}
    finally:
        try:
            count = len((answer or {}).get('streams') or []) if isinstance(answer, dict) else 0
            _recall.note_addon(addon, time.monotonic() - started, success=ok, result_count=count)
        except Exception:
            pass


def _scan_workers(target_count=0):
    try:
        base = int(float(ADDON.getSetting('parallel_workers') or parallel_workers() or 4))
    except Exception:
        try:
            base = int(parallel_workers() or 4)
        except Exception:
            base = 4
    workers = max(2, base)
    if target_count:
        workers = min(workers, max(1, int(target_count)))
    return max(1, min(4, workers))


def _quick_open_wait():
    try:
        raw = float(ADDON.getSetting('streams_quick_open_seconds') or 0.4)
    except Exception:
        raw = 0.4
    return max(0.3, min(raw, 4.0))


def _source_goal():
    try:
        raw = str(ADDON.getSetting('streams_result_goal') or '1').strip()
        idx = int(float(raw))
    except Exception:
        idx = 1
    return {0: 10, 1: 20, 2: 40, 3: 0}.get(idx, 20)


def _enough_wait_seconds():
    try:
        raw = float(ADDON.getSetting('streams_enough_wait_seconds') or 8.0)
    except Exception:
        raw = 8.0
    return max(3.0, min(raw, 12.0))


def _distinct_sources(entries):
    rows = list(entries or [])
    try:
        rows, _removed = _merge_same_addon_rows(rows)
    except Exception:
        pass
    try:
        mode = _dedup_mode()
        if mode != 'off':
            order = (ADDON.getSetting('source_priority_order') or '')
            rows, _removed = merge_duplicate_sources(
                rows, mode=mode,
                priority=[part.strip().lower() for part in order.split(',') if part.strip()],
            )
    except Exception:
        pass
    return len(rows)



_SCAN_CEILING = 25.0          # a source scan never runs longer


def _addon_name(addon):
    addon = addon or {}
    return str(addon.get('name') or (addon.get('manifest') or {}).get('name') or '')


def _scan_sheet_subtitle(meta, season, episode):
    """'2019  •  Drama, Crime  •  S1E2' under the title on the progress sheet."""
    try:
        parts = [str(meta.get('year') or meta.get('releaseInfo') or '')]
        genres = meta.get('genres') or meta.get('genre') or []
        parts.append(', '.join(str(g) for g in genres[:2] if g) if isinstance(genres, list) else str(genres or ''))
        if season is not None and episode is not None:
            try:
                parts.append('S%dE%d' % (int(season), int(episode)))
            except Exception:
                pass
        return '  •  '.join(part for part in parts if part)
    except Exception:
        return ''


class _SourceScan(object):
    """Every target asked at once; their streams become source rows as they come. With
    stop_after_first the scan ends when the source goal is met or the grace after the first
    source runs out (the user's Keep searching lifts that); never past 25 s."""

    def __init__(self, targets, media_type, row_args, stop_after_first, done_targets, state):
        self.targets, self.media_type, self.row_args = targets, media_type, row_args
        self.quick, self.done_targets, self.state = stop_after_first, done_targets, state
        self.entries, self.distinct = [], 0

    def run(self, sheet=None):
        started = time.time()
        goal = _source_goal() if self.quick else 0
        first_wait = min(_SCAN_CEILING, _enough_wait_seconds()) if self.quick and goal else _SCAN_CEILING
        race = begin_race(lambda target: _ask_addon_streams(target, self.media_type), self.targets,
                          workers=_scan_workers(len(self.targets)), timeout=_SCAN_CEILING, lane='streams')
        hook = (lambda name: getattr(sheet, name)) if sheet is not None else (lambda name: None)
        answers = _iter_source_race(race, lambda: self.distinct, lambda: bool(self.entries), started, first_wait,
                                    self.quick, goal, _quick_open_wait() if self.quick else 0.0,
                                    should_stop=hook('is_stopped'), consume_continue=hook('consume_continue_search'),
                                    clear_sufficient=hook('clear_sufficient'),
                                    mark_sufficient=(lambda: sheet.mark_sufficient(auto_seconds=0)) if sheet else None)
        for turn, (target, answer) in enumerate(answers, start=1):
            if time.time() > started + _SCAN_CEILING:
                xbmc.log('[MegaNexus] source gathering hit 25s hard ceiling — %d targets processed, %d entries gathered'
                         % (turn, len(self.entries)), xbmc.LOGINFO)
                break
            if self.done_targets is not None:
                self.done_targets.append(target)
            if sheet is not None:
                if sheet.is_stopped():
                    break
                sheet.update(provider_name=_addon_name(target[0]), index=turn, status=tr('Searching for add-ons...'),
                             sub_status='%d %s' % (len(self.entries), tr('add-on')) if self.entries else '')
            if not isinstance(answer, Exception) and answer:
                self.take(target, answer, sheet)
        self.finish(race, sheet)
        return self.entries

    def take(self, target, answer, sheet):
        before = len(self.entries)
        _take_addon_streams(self.entries, answer, target[0], target[1], self.media_type, *self.row_args[0],
                            **self.row_args[1])
        if len(self.entries) > before:
            self.distinct = _distinct_sources(self.entries)
        if sheet is not None:
            sheet.add_found(len(self.entries) - before, provider_name=_addon_name(target[0]), unique_total=self.distinct)

    def finish(self, race, sheet):
        """The race is handed on (to keep filling the list) unless nobody wants it or the user cancelled."""
        cancelled = sheet is not None and sheet.is_cancelled()
        if self.state is not None:
            self.state.update(race=race, pending_targets=race.pending_items())
        if self.state is None or cancelled:
            race.cancel()
        if sheet is not None:
            if cancelled:
                self.entries[:] = []
            sheet.set_finalizing()


def _scan_sources(targets, media_type, canonical_id, best_meta, art, bg, ids, title='',
                            video_id='', season=None, episode=None, show_title='', resume_seconds=0.0,
                            resume_percent=0.0,
                            stop_after_first=False, show_loader=False,
                            processed_targets=None, scan_state=None):
    """The title's source rows from the targets (behind the progress sheet when show_loader)."""
    if not targets:
        return []
    ids = ids or {}
    try:
        from . import mdblist_api as mdblist
        mdblist.ratings_later(imdb_id=ids.get('imdb_id') or '', media_type=media_type, tmdb_id=ids.get('tmdb_id') or '')
    except Exception as exc:
        log.silent('MDBLIST_WARM', exc)
    row_args = ((canonical_id, best_meta, art, bg, ids),
                dict(title=title, video_id=video_id, season=season, episode=episode, show_title=show_title,
                     resume_seconds=resume_seconds, resume_percent=resume_percent))
    scan = _SourceScan(targets, media_type, row_args, stop_after_first, processed_targets, scan_state)
    if not show_loader:
        return scan.run()
    art = art or {}
    names = []
    for target in targets:
        try:
            name = _addon_name(target[0]).strip()
        except Exception:
            name = ''
        if name and name not in names:
            names.append(name)
    with _search_progress(title=title or show_title or best_meta.get('name') or canonical_id or tr('Add-ons'),
                          subtitle=_scan_sheet_subtitle(best_meta, season, episode),
                          fanart=bg or art.get('fanart') or '', poster=art.get('poster') or '',
                          clearlogo=art.get('clearlogo') or art.get('logo') or '',
                          media_type=(best_meta or {}).get('media_type') or (best_meta or {}).get('type') or media_type or 'movie',
                          imdb_id=ids.get('imdb_id') or '', tmdb_id=ids.get('tmdb_id') or '', provider_count=len(targets),
                          provider_names=names) as sheet:
        return scan.run(sheet)




_STREAM_REFRESH_SEM = threading.BoundedSemaphore(2)

_PICTURE_HOSTS = ('image.tmdb.org', 'images.metahub.space', 'media-amazon.com', 'm.media-amazon.com', 'img.youtube.com',
                  'i.imgur.com', 'fanart.tv', 'assets.fanart.tv', 'static.metahub.space', 'image.com', 'imgcdn', 'imageapi')


_LOGO_FILES = tuple('/%s.%s' % (name, ext) for name, exts in (('icon', ('png', 'jpg', 'jpeg', 'webp')),
                                                              ('logo', ('png', 'jpg', 'jpeg', 'webp')), ('addon', ('png', 'jpg')),
                                                              ('favicon', ('png', 'ico', 'jpg')), ('poster', ('png', 'jpg')),
                                                              ('banner', ('png', 'jpg'))) for ext in exts)


_LOGO_FOLDERS = ('/logo/', '/icon/', '/icons/', '/branding/', '/brand/', '/assets/icon')


def _poster_is_logo(url):
    """True when a 'poster' is really an add-on's logo or icon (picture hosts are trusted)."""
    if not url or not isinstance(url, str):
        return False
    low = url.lower()
    if any(host in low for host in _PICTURE_HOSTS):
        return False
    return low.endswith(_LOGO_FILES) or any(folder in low for folder in _LOGO_FOLDERS)


def _usable_poster(url, fallback='', imdb_id=''):
    imdb_id = (imdb_id or '').strip()
    if imdb_id.startswith('tt') and len(imdb_id) >= 4:
        return _metahub('poster', imdb_id)
    if url and not _poster_is_logo(url):
        return url
    if url:
        try:
            xbmc.log('[MegaNexus] rejected suspect addon-logo poster: %s' % url[:120], xbmc.LOGINFO)
        except Exception:
            pass
    return fallback or ''


def streams(media_type, canonical_id, title='', resume_seconds='0', resume_percent='', preferred_provider_name='', source_provider_id='', source_mode='', seed_ids=None, ui_seed=None):
    from .frontend_bridge import legacy_streams
    return legacy_streams(**locals())


def _video_season_num(video):
    raw = video.get('season')
    if raw is None or raw == '':
        return 1
    try:
        return int(raw)
    except Exception:
        return 1


def show_meta(media_type, canonical_id, title='', source_provider_id=''):
    from .frontend_bridge import legacy_streams
    return legacy_streams(**locals())


def _series_window(canonical_id, suffix=''):
    return xbmcgui.Window(WINDOW_ID).getProperty(SERIES_PROP_PREFIX + canonical_id + suffix)


def _window_json(canonical_id, suffix, empty):
    raw = _series_window(canonical_id, suffix)
    try:
        return json.loads(raw) if raw else empty
    except Exception:
        return empty


def season(canonical_id, season, title='', media_type=''):
    """A season's episodes (from the show's episode list the show page left in the window)."""
    videos = _window_json(canonical_id, '', [])
    show_art = _window_json(canonical_id, '.art', {})
    show = _series_window(canonical_id, '.title') or title
    media_type = media_type or _series_window(canonical_id, '.media_type') or 'series'
    builder = native_meta_art if _series_window(canonical_id, '.native_art') == '1' else enrich_meta_art
    art_kind = media_type if media_type in ('anime', 'series') else 'series'
    addon = _series_window(canonical_id, '.source_provider_id') or ''
    season = int(season)
    ids = _merge_seed_ids(extract_ids({'id': canonical_id}), _get_tmdbh_seed_ids(canonical_id))
    id_args = dict((key, ids.get(key) or '') for key in ('tmdb_id', 'imdb_id', 'tvdb_id'))
    for video in videos:
        if _video_season_num(video) != season:
            continue
        number = int(video.get('episode') or 0)
        video_id = video.get('id') or '%s:%s:%s' % (canonical_id, season, number)
        name = video.get('title') or 'S%02dE%02d' % (season, number)
        art = builder({'id': video.get('id') or canonical_id, 'name': name, 'poster': video.get('thumbnail') or '',
                       'background': video.get('thumbnail') or '', 'type': 'series'}, art_kind, fallback_art=show_art)
        path, is_folder = _item_click_url(media_type=media_type or 'series', canonical_id=canonical_id, video_id=video_id,
                                          season=season, episode=number, title=name, source_provider_id=addon,
                                          ui_seed=art, **id_args)
        menu = (_source_choice_list(media_type=media_type or 'series', canonical_id=canonical_id, title=name, season=season,
                                    episode=number, video_id=video_id, source_provider_id=addon)
                + _player_choices(media_type=media_type or 'series', canonical_id=canonical_id, title=name, season=season,
                                  episode=number, video_id=video_id))
        add_item('S%02dE%02d — %s' % (season, number, name), path, is_folder=is_folder, art=art, context_menu=menu,
                 info={'title': name, 'episode': number, 'season': season, 'tvshowtitle': show, 'mediatype': 'episode',
                       'plot': video.get('overview') or ''})
    end_dir(content='episodes')


def episode_sources(canonical_id, video_id, season, episode, title='', media_type='', resume_seconds='0', resume_percent='', preferred_provider_name='', source_provider_id='', source_mode='', seed_ids=None, ui_seed=None):
    from .frontend_bridge import legacy_streams
    return legacy_streams(**locals())

def _best_id_of(video_type, tmdb_id='', imdb_id='', tvdb_id='', title=''):
    if tmdb_id:
        return 'tmdb:%s' % tmdb_id
    if imdb_id:
        return imdb_id if str(imdb_id).startswith('tt') else 'imdb:%s' % imdb_id
    if tvdb_id:
        return 'tvdb:%s' % tvdb_id
    return title or ''


def _episode_video_id(canonical_id, season, episode):
    """(the episode's id at the add-ons, the show's name) - the first add-on that lists it; the show's id otherwise."""
    want = (int(season or 0), int(episode or 0))
    for addon in _addons_for_id('series', canonical_id):
        try:
            answer = fetch_meta(addon, 'series', canonical_id, timeout_override=fast_timeout('meta'))
            meta = answer.get('meta') or answer.get('metas')
            meta = (meta[0] if meta else None) if isinstance(meta, list) else meta
            for video in (meta or {}).get('videos') or []:
                if (int(video.get('season') or 0), int(video.get('episode') or 0)) == want:
                    return video.get('id') or canonical_id, (meta or {}).get('name') or canonical_id
        except Exception:
            continue
    return canonical_id, ''


def _plain_imdb(value):
    value = str(value or '').strip()
    if value.lower().startswith('imdb:'):
        value = value.split(':', 1)[1].strip()
    return ('tt' + value if value.isdigit() else value).lower()


def _title_words(value):
    return ' '.join(re.sub(r'[^\w]+', ' ', str(value or '').strip().casefold(), flags=re.UNICODE).split())


def _resume_from_row(row):
    """The resume point a progress row holds ({} when it is at the start or near the end)."""
    try:
        position = float(row.get('position') or 0.0)
    except Exception:
        position = 0.0
    try:
        percent = float(row.get('percent') or 0.0)
    except Exception:
        percent = 0.0
    by_percent = position <= 1.0 and 1.0 < percent < 95.0
    if position <= 1.0 and not by_percent:
        return {}
    return {'resume_seconds': position if position > 1.0 else 0, 'resume_percent': '%.2f' % percent if by_percent else '',
            'provider_name': row.get('provider_name') or '', 'poster': row.get('poster') or '',
            'fanart': row.get('background') or '', 'clearlogo': row.get('clearlogo') or '',
            'updated_at': int(row.get('updated_at') or 0), 'source': 'meganexus'}


def _row_names(row):
    """Every way a progress row's title can be named, and its TMDB / IMDb / TVDB ids."""
    canonical, video = str(row.get('canonical_id') or '').strip(), str(row.get('video_id') or '').strip()
    ids = _merge_seed_ids(extract_ids({'id': canonical}), extract_ids({'id': video}))
    tmdb, imdb, tvdb = str(ids.get('tmdb_id') or '').strip(), _plain_imdb(ids.get('imdb_id')), str(ids.get('tvdb_id') or '').strip()
    names = {canonical.lower(), video.lower()}
    if tmdb:
        names.update('tmdb:%s%s' % (kind, tmdb) for kind in ('', 'movie:', 'tv:', 'series:'))
    if imdb:
        names.update((imdb, 'imdb:' + imdb))
    if tvdb:
        names.add('tvdb:' + tvdb)
    return names, tmdb, imdb, tvdb


def _row_is_wanted(row, wanted):
    names, tmdb, imdb, tvdb = _row_names(row)
    return bool((wanted['canonical'] and wanted['canonical'] in names)
                or any(wanted[key] and value and wanted[key] == value
                       for key, value in (('tmdb_id', tmdb), ('imdb_id', imdb), ('tvdb_id', tvdb))))


def _helper_resume(media_type='movie', canonical_id='', tmdb_id='', imdb_id='', tvdb_id='', season='', episode='', title=''):
    """Our resume point for a title TMDb Helper plays: the indexed progress row, else a Continue
    Watching row with one of its ids, else the only row with its title."""
    wanted = {'canonical': str(canonical_id or '').strip().lower(), 'tmdb_id': str(tmdb_id or '').strip(),
              'imdb_id': _plain_imdb(imdb_id), 'tvdb_id': str(tvdb_id or '').strip()}
    for key, value in (('season', season), ('episode', episode)):
        try:
            wanted[key] = int(value or 0)
        except Exception:
            wanted[key] = 0
    episode_wanted = wanted['season'] > 0 and wanted['episode'] > 0
    try:
        point = _resume_from_row(progress_db.find_resume_entry(
            media_type='series' if episode_wanted else 'movie', canonical_id=canonical_id, tmdb_id=wanted['tmdb_id'],
            imdb_id=wanted['imdb_id'], tvdb_id=wanted['tvdb_id'], season=wanted['season'],
            episode=wanted['episode']) or {})
        if point:
            xbmc.log('[MegaNexus] TMDbH resume bridge matched indexed playback row', xbmc.LOGINFO)
            return point
    except Exception as exc:
        xbmc.log('[MegaNexus] TMDbH indexed resume lookup failed: %s' % exc, xbmc.LOGWARNING)
    try:
        rows = progress_db.list_continue_items(limit=500) or []
    except Exception:
        return {}
    name = _title_words(title)
    same_title = []
    for row in rows:
        try:
            if episode_wanted != bool(_continue_is_episode(row)):
                continue
            if episode_wanted and (int(row.get('season') or 0), int(row.get('episode') or 0)) != (wanted['season'],
                                                                                                   wanted['episode']):
                continue
            if not episode_wanted and str(row.get('media_type') or '').strip().lower() not in ('movie', 'movies', ''):
                continue
            if name and _title_words(row.get('title') or '') == name:
                same_title.append(row)
            point = _resume_from_row(row) if _row_is_wanted(row, wanted) else {}
            if point:
                xbmc.log('[MegaNexus] TMDbH resume bridge matched legacy CW row', xbmc.LOGINFO)
                return point
        except Exception:
            continue
    point = _resume_from_row(same_title[0]) if len(same_title) == 1 else {}
    if point:
        xbmc.log('[MegaNexus] TMDbH resume bridge matched unique legacy title', xbmc.LOGINFO)
    return point




_RESUME_ORIGINS = {'trakt': 'Trakt', 'tmdbhelper': 'TMDb Helper / Kodi', 'handoff': 'TMDb Helper'}


def _store_resume_hint(hint, media_type, canonical_id, video_id, title='', season=None, episode=None, ids=None, poster='', fanart='', clearlogo=''):
    """A resume point from Trakt / TMDb Helper kept as our progress (so Continue Watching shows it); True when kept."""
    hint = dict(hint or {})
    source = str(hint.get('source') or '').strip().lower()
    if not hint or source in ('', 'meganexus'):
        return False
    try:
        position, percent, length = (float(hint.get(key) or 0.0) for key in ('resume_seconds', 'resume_percent', 'duration'))
    except Exception:
        return False
    if length <= 0 and position > 0 and percent > 1:
        length = position * 100.0 / percent
    if percent <= 0 and length > 0:
        percent = position * 100.0 / length
    if position <= 30.0 or not 0.0 < percent < 95.0:
        return False
    ids = dict(ids or {})
    try:
        progress_db.keep_row(media_type, canonical_id, video_id, title or canonical_id,
                                _RESUME_ORIGINS.get(source, source.title()), poster or '', fanart or '', clearlogo or '',
                                season, episode, position, length, percent, '', 'unified_import',
                                ext_updated_at=int(hint.get('updated_at') or 0) or None, tmdb_id=ids.get('tmdb_id') or '',
                                imdb_id=ids.get('imdb_id') or '', tvdb_id=ids.get('tvdb_id') or '',
                                show_tmdb_id=(ids.get('tmdb_id') or '') if media_type == 'series' else '')
        return True
    except Exception as exc:
        xbmc.log('[MegaNexus] unified resume persist failed: %s' % exc, xbmc.LOGWARNING)
        return False

_SHOW_KINDS = ('episode', 'show', 'series', 'tv')


def _helper_window_ids(tmdb_id, imdb_id, tvdb_id):
    """Without ids in the call, the ones TMDb Helper shows for its focused item."""
    if tmdb_id or imdb_id or tvdb_id:
        return tmdb_id, imdb_id, tvdb_id
    try:
        home = xbmcgui.Window(10000)
        return tuple(value or (home.getProperty('TMDbHelper.ListItem.' + name) or '').strip()
                     for value, name in ((tmdb_id, 'TMDb'), (imdb_id, 'IMDb'), (tvdb_id, 'TVDb')))
    except Exception:
        return tmdb_id, imdb_id, tvdb_id


def _helper_resume_point(kind, canonical_id, ids, season, episode, title, given):
    """Where to resume: the point TMDb Helper handed over, then its live one, else whichever of
    ours and Trakt's is newer."""
    tmdb_id, imdb_id, tvdb_id = ids
    ours = _helper_resume(media_type=kind, canonical_id=canonical_id, tmdb_id=tmdb_id, imdb_id=imdb_id, tvdb_id=tvdb_id,
                          season=season, episode=episode, title=title)
    try:
        position, percent, length, stamp = given
        if float(position or 0) > 30 and float(percent or 0) < 95:
            return {'resume_seconds': float(position), 'resume_percent': float(percent or 0),
                    'duration': float(length or 0), 'updated_at': int(float(stamp or 0)), 'source': 'handoff'}
    except Exception:
        pass
    try:
        live = tmdb_helper_live.resume_hint(expected_tmdb_id=tmdb_id or None, expected_imdb_id=imdb_id or None,
                                            season=season, episode=episode) or {}
    except Exception:
        live = {}
    if live:
        return live
    try:
        synced = trakt_api.progress_of(media_type=kind, tmdb_id=tmdb_id, imdb_id=imdb_id, tvdb_id=tvdb_id, season=season,
                                   episode=episode) or {}
    except Exception:
        synced = {}
    if synced and int(synced.get('updated_at') or 0) > int((ours or {}).get('updated_at') or 0):
        return synced
    return ours or synced or {}


def _publish_helper_seed(seed_ids, canonical_id):
    try:
        home = xbmcgui.Window(WINDOW_ID)
        home.setProperty('meganexus.tmdbh_seed_ids', json.dumps(seed_ids))
        home.setProperty('meganexus.tmdbh_seed_for', canonical_id or '')
        home.setProperty('meganexus.invoked_by_tmdbh', '1')
        _note_helper_handoff(60)
    except Exception:
        pass


def _setting_on(name, truths=('true',)):
    try:
        return (ADDON.getSetting(name) or 'false').strip().lower() in truths
    except Exception:
        return False


def helper_player(video_type='movie', tmdb_id='', imdb_id='', tvdb_id='', title='', year='', showname='', season='', episode='', poster='', fanart='', resume_seconds='', resume_percent='', resume_duration='', resume_updated_at=''):
    """TMDb Helper's 'play with MegaNexus': the title's sources (or its best one straight away)."""
    kind = (video_type or 'movie').lower()
    once = 'tmdb_player|%s|%s|%s|%s|%s|%s' % (kind, tmdb_id or '', imdb_id or '', tvdb_id or '', str(season or ''),
                                              str(episode or ''))
    if _route_running(once, window_seconds=12):
        xbmc.log('[MegaNexus] tmdb_player: duplicate dispatch suppressed (%s)' % once, xbmc.LOGINFO)
        return
    name = showname or title
    tmdb_id, imdb_id, tvdb_id = _helper_window_ids(tmdb_id, imdb_id, tvdb_id)
    canonical_id = _best_id_of(kind, tmdb_id=tmdb_id, imdb_id=imdb_id, tvdb_id=tvdb_id, title=name)
    if not canonical_id:
        error('Missing IDs for TMDb Helper player')
        return end_dir()
    imdb = str(imdb_id or '').strip()
    seed_ids = {'tmdb_id': str(tmdb_id or '').strip(),
                'imdb_id': 'tt' + imdb if imdb.isdigit() else imdb,
                'tvdb_id': str(tvdb_id or '').strip()}
    show = kind in _SHOW_KINDS
    point = _helper_resume_point('series' if show else 'movie', canonical_id, (tmdb_id, imdb_id, tvdb_id), season,
                                 episode, name, (resume_seconds, resume_percent, resume_duration, resume_updated_at))
    resume_seconds, resume_percent = point.get('resume_seconds') or 0, point.get('resume_percent') or ''
    xbmc.log('[MegaNexus] unified resume source=%s pos=%.1f pct=%s' % (
        point.get('source') or point.get('provider_name') or 'none', float(resume_seconds or 0), str(resume_percent or '')),
        xbmc.LOGINFO)
    poster, fanart = poster or point.get('poster') or '', fanart or point.get('fanart') or ''
    seed_ids.update((key, value) for key, value in (('poster', poster), ('fanart', fanart)) if value)
    _publish_helper_seed(seed_ids, canonical_id)
    picker = _setting_on('tmdbh_poster_picker', ('true', '1', 'yes', 'on'))
    first = _setting_on('tmdbh_auto_play_first')
    logo = point.get('clearlogo') or ''
    common = dict(seed_ids=seed_ids, resume_seconds=resume_seconds, resume_percent=resume_percent or '',
                  preferred_provider_name=point.get('provider_name') or '')
    look = {'ui_poster': poster, 'ui_fanart': fanart, 'ui_clearlogo': logo}
    if show and not (season and episode):
        return show_meta('series', canonical_id, title=showname or title or canonical_id)
    if show:
        video_id, found_title = _episode_video_id(canonical_id, season, episode)
        label = title or found_title or showname or canonical_id
        _store_resume_hint(point, 'series', canonical_id, video_id, title=label, season=int(season or 0),
                           episode=int(episode or 0), ids=seed_ids, poster=poster, fanart=fanart, clearlogo=logo)
        if first or picker:
            return _play_best_episode_source(canonical_id, video_id, season, episode, title=label,
                                             pick_dialog=picker and not first, **common)
        return episode_sources(canonical_id, video_id, season, episode, title=label, media_type='series', ui_seed=look,
                               **common)
    _store_resume_hint(point, 'movie', canonical_id, canonical_id, title=title or canonical_id, ids=seed_ids,
                       poster=poster, fanart=fanart, clearlogo=logo)
    if first or picker:
        return _play_best_movie_source(canonical_id, title=title or canonical_id, pick_dialog=picker and not first,
                                       **common)
    return streams('movie', canonical_id, title=title or canonical_id, ui_seed=look, **common)




def _imdb_value(value):
    value = str(value or '').strip()
    if not value:
        return ''
    if value.lower().startswith('imdb:'):
        value = value.split(':', 1)[1].strip()
    if value.isdigit():
        value = 'tt%s' % value
    return value if re.match(r'^tt\d{5,10}$', value, re.I) else value


def _ids_in_values(tmdb_id='', imdb_id='', tvdb_id='', canonical_id=''):
    ids = {
        'tmdb_id': str(tmdb_id or '').strip(),
        'imdb_id': _imdb_value(imdb_id),
        'tvdb_id': str(tvdb_id or '').strip(),
    }
    ids = _merge_seed_ids(ids, extract_ids({'id': canonical_id or ''}))
    return {k: v for k, v in ids.items() if v}


def _playback_ids_of(ctx):
    """The playback's TMDB / IMDb / TVDB ids from its fields, external_ids, then an IMDb id in its video id or address."""
    ctx = ctx or {}
    ids = _ids_in_values(tmdb_id=ctx.get('tmdb_id') or '', imdb_id=ctx.get('imdb_id') or '', tvdb_id=ctx.get('tvdb_id') or '',
                         canonical_id=ctx.get('canonical_id') or '')
    external = ctx.get('external_ids') or {}
    if isinstance(external, dict):
        ids = _merge_seed_ids(ids, {'tmdb_id': external.get('tmdb_id') or external.get('tmdb') or '',
                                    'imdb_id': _imdb_value(external.get('imdb_id') or external.get('imdb') or ''),
                                    'tvdb_id': external.get('tvdb_id') or external.get('tvdb') or ''})
    for key in ('video_id', 'stream_url'):
        found = None if ids.get('imdb_id') else re.search(r'(tt\d{5,10})', str(ctx.get(key) or ''), re.I)
        if found:
            ids['imdb_id'] = found.group(1)
    return ids


def _with_playback_ids(ctx):
    """The playback with every id it can have (looked up when the IMDb id is missing), also in external_ids."""
    out = dict(ctx or {})
    ids = _playback_ids_of(out)
    name = out.get('show_title') or out.get('title') or ''
    if not ids.get('imdb_id') and (ids.get('tmdb_id') or name):
        try:
            kind = 'series' if out.get('season') or out.get('episode') or is_show(out.get('media_type')) else 'movie'
            ids = _complete_title_ids(ids, kind, meta={'id': out.get('canonical_id') or '', 'name': name, 'title': name,
                                                       'type': kind},
                                      canonical_id=out.get('canonical_id') or '', title=name)
        except Exception:
            pass
    for key in ('tmdb_id', 'imdb_id', 'tvdb_id'):
        if ids.get(key) and not out.get(key):
            out[key] = ids[key]
    if ids:
        external = dict(out.get('external_ids') or {}) if isinstance(out.get('external_ids') or {}, dict) else {}
        for short in ('imdb', 'tmdb', 'tvdb'):
            if ids.get(short + '_id'):
                external.setdefault(short, ids[short + '_id'])
                external.setdefault(short + '_id', ids[short + '_id'])
        out['external_ids'] = external
    return out


_NO_ID_MARK = ('http://', 'https://', 'ftp://', 'smb://', 'nfs://', 'dav://', 'davs://', 'file://', 'plugin://', 'magnet:',
               # 8.1.0 (issue #13): never on MegaNexus' own Kodi protocols - Kodi keeps a "|..." of an
               # unknown protocol in the file name (URL.cpp), and the fast Usenet player did not find
               # "film.mkv|ids={...}": every Usenet film failed to play
               'mnxusenet://', 'mnxart://')


def _id_number(value):
    try:
        return int(str(value))
    except Exception:
        return str(value)


def _url_with_title_ids(url, ctx):
    """'|ids={...}' (IMDb, TMDB, TVDB, season, episode) on an address that other tools read the
    title from; only when the IMDb id is known."""
    url = str(url or '').strip()
    lower = url.lower()
    if not url or lower.startswith(_NO_ID_MARK) or '|ids=' in lower or '&ids=' in lower:
        return url
    ids = _playback_ids_of(ctx)
    if not ids.get('imdb_id'):
        return url
    mark = {}
    if ids.get('tmdb_id'):
        mark['tmdb'] = _id_number(ids['tmdb_id'])
    mark['imdb'] = str(ids['imdb_id'])
    if ids.get('tvdb_id'):
        mark['tvdb'] = _id_number(ids['tvdb_id'])
    try:
        for key in ('season', 'episode'):
            if ctx.get(key) not in (None, '', '0', 0):
                mark[key] = int(ctx.get(key) or 0)
    except Exception:
        pass
    mark = 'ids=' + json.dumps(mark, separators=(',', ':'), ensure_ascii=False)
    if '|' not in url:
        return url + '|' + mark
    address, options = url.split('|', 1)
    return address + '|' + (options + '&' if options else '') + mark


_ID_SPELLINGS = (('imdb_id', 'imdb', 'imdbId'), ('tmdb_id', 'tmdb', 'tmdbId'), ('tvdb_id', 'tvdb', 'tvdbId'))


def _meta_plus_ids(meta, ids):
    """The meta with the ids in every spelling add-ons read (imdb_id, imdbId, externalIds.imdb)."""
    out = dict(meta or {})
    given = out.get('externalIds') or {}
    external = dict(given) if isinstance(given, dict) else {}
    for key, short, camel in _ID_SPELLINGS:
        value = str((ids or {}).get(key) or '').strip()
        if value:
            out.setdefault(key, value)
            out.setdefault(camel, value)
            external.setdefault(short, value)
    if external:
        out['externalIds'] = external
    return out


def _play_best_movie_source(canonical_id, title='', seed_ids=None, preferred_provider_name='', resume_seconds=0.0, resume_percent=0.0, source_provider_id='', source_mode='', pick_dialog=False):
    from .frontend_bridge import legacy_streams
    return legacy_streams(media_type='movie', **locals())


def _play_best_episode_source(canonical_id, video_id, season, episode, title='', seed_ids=None, preferred_provider_name='', resume_seconds=0.0, resume_percent=0.0, source_provider_id='', source_mode='', pick_dialog=False):
    from .frontend_bridge import legacy_streams
    return legacy_streams(media_type='series', **locals())


def _ids_in_canonical(canonical_id):
    """{'tmdb_id', 'imdb_id', 'tvdb_id'} named by a canonical id (empty strings for the rest)."""
    out = {'tmdb_id': '', 'imdb_id': '', 'tvdb_id': ''}
    cid = str(canonical_id or '').strip()
    kind, _sep, tail = cid.partition(':')
    tail = tail.strip()
    if cid.startswith('tmdb:'):
        out['tmdb_id'] = cid.split(':', 1)[1]
    elif kind == 'imdb' and tail.startswith('tt') and tail[2:].isdigit():
        out['imdb_id'] = tail
    elif kind == 'imdb' and tail.isdigit():
        out['imdb_id'] = 'tt' + tail
    elif kind == 'tvdb' and tail.isdigit():
        out['tvdb_id'] = tail
    elif cid.startswith('tt') and cid[2:].isdigit():
        out['imdb_id'] = cid
    return out


def _virtual_meta_override(target_key, media_type, seed_meta):
    try:
        from . import meta_choice as _meta_choice
        return _meta_choice.apply_virtual(target_key, media_type, seed_meta or {}) or (seed_meta or {})
    except Exception:
        return seed_meta or {}


_POV_FORMATS = ('%Y-%m-%dT%H:%M:%S.000Z', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d %H:%M:%S')


def _pov_time(value):
    """Seconds since 1970 of a POV date (a number, an ISO date or one of POV's formats); None when unreadable."""
    text = str(value or '').strip()
    if not text:
        return None
    try:
        return int(float(text))
    except Exception:
        pass
    try:
        import datetime
        moment = datetime.datetime.fromisoformat(text.replace('Z', '+00:00'))
        return int(moment.timestamp()) if moment.tzinfo else int(time.mktime(moment.timetuple()))
    except Exception:
        pass
    for pattern in _POV_FORMATS:
        try:
            return int(time.mktime(time.strptime(text, pattern)))
        except Exception:
            continue
    return None


def _pov_profile_dir():
    try:
        return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.pov/')
    except Exception:
        return ''


def _pov_option(setting_id, default=''):
    """A setting of the POV add-on (read from its settings file)."""
    try:
        import xml.etree.ElementTree as ET
        path = os.path.join(_pov_profile_dir(), 'settings.xml')
        if os.path.exists(path):
            node = next((n for n in ET.parse(path).getroot().findall('setting') if n.get('id') == setting_id), None)
            if node is not None:
                return node.get('value') or node.text or default
    except Exception:
        pass
    return default


_POV_STORES = (('POV', 'watched.db'), ('POV Trakt', 'traktcache4.db'), ('POV MDBList', 'mdblcache.db'))


def _pov_databases():
    """POV's progress databases that exist, the one its watched setting uses first."""
    base = _pov_profile_dir()
    if not base:
        return []
    chosen = {'1': 1, '2': 2}.get(str(_pov_option('watched_indicators', '0') or '0'), 0)
    order = [_POV_STORES[chosen]] + [store_ for store_ in _POV_STORES if store_ != _POV_STORES[chosen]]
    return [(label, os.path.join(base, name)) for label, name in order if os.path.exists(os.path.join(base, name))]


_POV_EVERY = 180


def _pov_due(force):
    """True when POV's progress may be read again (at most every three minutes unless forced)."""
    try:
        home = xbmcgui.Window(WINDOW_ID)
        now = int(time.time())
        if not force:
            try:
                last = int(home.getProperty('meganexus.pov_progress_import_ts') or '0')
            except Exception:
                last = 0
            if last and now - last < _POV_EVERY:
                return False
        try:
            home.setProperty('meganexus.pov_progress_import_ts', str(now))
        except Exception:
            pass
    except Exception:
        pass
    return True


def _pov_rows(path):
    import sqlite3
    conn = sqlite3.connect(path, timeout=2)
    try:
        return conn.execute("SELECT db_type, media_id, season, episode, resume_point, curr_time, last_played, title "
                            "FROM progress WHERE db_type IN ('movie','episode')").fetchall()
    finally:
        conn.close()


def _take_pov_row(row, label, seen):
    """One POV progress row kept as ours (part-way only); True when it was new."""
    kind, media_id, season, episode, percent, position, played, title = row
    tmdb_id = str(media_id or '').strip()
    try:
        percent = float(percent or 0.0)
    except Exception:
        percent = 0.0
    if not tmdb_id or not 1.0 < percent < 95.0:
        return False
    canonical = tmdb_id if tmdb_id.startswith('tmdb:') else 'tmdb:' + tmdb_id
    if kind == 'episode':
        season, episode = int(season or 0), int(episode or 0)
        if season <= 0:
            return False
        media_type, video_id = 'series', '%s:%s:%s' % (canonical, season, episode)
    else:
        media_type, video_id, season, episode = 'movie', canonical, None, None
    if (media_type, canonical, video_id) in seen:
        return False
    seen.add((media_type, canonical, video_id))
    try:
        position = float(position or 0.0)
    except Exception:
        position = 0.0
    length = max(position + 1.0, position * 100.0 / percent) if position > 1.0 else 0.0
    progress_db.keep_row(media_type, canonical, video_id, title or canonical, label, '', '', '', season, episode,
                            position, length, percent, '', 'pov_progress', ext_updated_at=_pov_time(played))
    return True


def _take_pov_progress(limit=250, force=False):
    """POV's part-way movies and episodes added to Continue Watching (newest first, at most `limit` per database)."""
    if not _pov_due(force):
        return 0
    taken, seen = 0, set()
    for label, path in _pov_databases():
        try:
            rows = _pov_rows(path)
        except Exception:
            continue
        try:
            rows.sort(key=lambda r: _pov_time(r[6]) or 0, reverse=True)
        except Exception:
            pass
        for row in rows[:int(limit or 250)]:
            try:
                taken += 1 if _take_pov_row(row, label, seen) else 0
            except Exception:
                continue
    if taken:
        xbmc.log('[MegaNexus] imported %d POV progress rows' % taken, xbmc.LOGINFO)
    return taken

def _continue_ref(row):
    mt = (row.get('media_type') or '').lower()
    return 'virtual.continue.series' if mt in ('series', 'anime', 'show', 'tv') or (row.get('season') and row.get('episode') is not None) else 'virtual.continue.movie'


def _favorite_ref(row):
    mt = (row.get('media_type') or '').lower()
    return 'virtual.favorites.series' if mt in ('series', 'anime', 'show', 'tv') else 'virtual.favorites.movie'


def _seed_from_row(row):
    name = row.get('title') or row.get('canonical_id') or ''
    return {'id': row.get('canonical_id') or '', 'name': name, 'title': name, 'poster': row.get('poster') or '',
            'background': row.get('background') or '', 'logo': row.get('clearlogo') or '',
            'clearlogo': row.get('clearlogo') or ''}


def _seed_fill(seed, found):
    """Empty poster / background / logo of the seed taken from a picture bundle."""
    for slot, names in (('poster', ('poster',)), ('background', ('fanart', 'landscape')), ('clearlogo', ('clearlogo',))):
        if not seed.get(slot):
            seed[slot] = next((found[name] for name in names if found.get(name)), '')
            if slot == 'clearlogo':
                seed['logo'] = seed['clearlogo'] or ''


def _seed_from_tmdb(seed, row, kind):
    """The row's TMDB pictures: the local TMDb Helper copy, TMDB itself when poster or backdrop is still missing."""
    ids = _ids_in_canonical(row.get('canonical_id'))
    tmdb_id, imdb_id = ids.get('tmdb_id') or '', ids.get('imdb_id') or ''
    if not (tmdb_id or imdb_id):
        return
    tmdb_kind = 'tv' if kind == 'series' else 'movie'
    try:
        stored = _tmdb_art_db.stored_pictures(tmdb_id=tmdb_id, media_type=tmdb_kind, imdb_id=imdb_id,
                                              title=row.get('title') or '') or {}
    except Exception:
        stored = {}
    _seed_fill(seed, stored)
    if seed.get('poster') and seed.get('background'):
        return
    try:
        _seed_fill(seed, _tmdb_api.art_for(tmdb_id=tmdb_id, imdb_id=imdb_id, media_type=tmdb_kind,
                                           title=row.get('title') or '') or {})
    except Exception:
        pass


def _pictures_later(row):
    """A Continue Watching row with its missing (or add-on tokenised) pictures filled and stored;
    the metadata source chosen for the section decides them when one is chosen."""
    target = _continue_ref(row)
    try:
        from . import meta_choice
        source = meta_choice.choice_for(target) or 'auto'
    except Exception:
        source = 'auto'
    if source == 'native':
        return row
    explicit = source not in ('', 'auto')
    try:
        tokenised = _poster_has_addon_token(row.get('poster')) or _poster_has_addon_token(row.get('background'))
    except Exception:
        tokenised = False
    if not explicit and not tokenised and row.get('poster') and row.get('background') and row.get('clearlogo'):
        return row
    kind = 'series' if (row.get('media_type') in ('series', 'anime', 'tv', 'show')
                        or (row.get('season') and row.get('episode') is not None)) else 'movie'
    seed = _seed_from_row(row)
    if not explicit:
        _seed_from_tmdb(seed, row, kind)
    meta = _virtual_meta_override(target, kind, seed)
    try:
        _meta_keep(kind, row.get('canonical_id') or '', meta, source_provider_id=target)
    except Exception:
        pass
    own = {} if explicit else seed
    poster = meta.get('poster') or own.get('poster') or ''
    background = meta.get('background') or meta.get('fanart') or meta.get('landscape') or own.get('background') or ''
    logo = meta.get('clearlogo') or own.get('clearlogo') or ''
    if not explicit and (not background or tokenised):
        try:
            found = _row_pictures(dict(row, poster=poster, background=background, clearlogo=logo)) or {}
            poster = poster or found.get('poster') or found.get('thumb') or ''
            background = found.get('fanart') or found.get('landscape') or background or ''
            logo = logo or found.get('clearlogo') or ''
        except Exception:
            pass
    if not (poster or background or logo):
        return row
    try:
        progress_db.update_art(row.get('media_type'), row.get('canonical_id'), row.get('video_id'), poster, background,
                                  logo)
    except Exception:
        pass
    return dict(row, poster=poster, background=background, clearlogo=logo)




def _number_or_zero(value):
    try:
        return float(value) if value not in (None, '') else 0.0
    except Exception:
        return 0.0


def _continue_play_url(row):
    """The source list for a Continue Watching row (resuming where it was, preferring the add-on that played it)."""
    position, percent = _number_or_zero(row.get('position')), _number_or_zero(row.get('percent'))
    common = {'title': row.get('title') or row.get('canonical_id') or '',
              'resume_seconds': position if position > 1.0 else 0,
              'resume_percent': '%.2f' % percent if position <= 1.0 and 1.0 < percent < 95.0 else '',
              'preferred_provider_name': row.get('provider_name') or '', 'source_provider_id': _continue_ref(row)}
    if row.get('native_server_id') and row.get('native_item_id'):
        try:
            common['ui_seed_key'] = keyed_cache.put('ui_seed', {
                'native_server_id': str(row['native_server_id']), 'native_item_id': str(row['native_item_id']),
                'ui_poster': row.get('poster') or '', 'ui_fanart': row.get('background') or '',
                'ui_clearlogo': row.get('clearlogo') or ''}, ttl_hours=24)
        except Exception:
            pass
    if _continue_is_episode(row):
        return build_url(action='episode_streams', canonical_id=row.get('canonical_id'), video_id=row.get('video_id'),
                         season=row.get('season'), episode=row.get('episode'),
                         media_type=row.get('media_type') or 'series', **common)
    return build_url(action='streams', media_type=row.get('media_type'), canonical_id=row.get('canonical_id'), **common)


def continue_resume(media_type='', canonical_id='', video_id='', season='', episode='', title='', position='0', resume_percent='', provider_name='', direct='0', source_provider_id='', ui_poster='', ui_fanart='', ui_clearlogo='', studio='', ui_seed_key=''):
    """Resume a Continue Watching row: straight from the add-on that played it ('direct'), else the usual way."""
    episode_given = _has_number(season) and _has_number(episode)
    kind = media_type or ('series' if episode_given else 'movie')
    name = title or canonical_id
    shared = dict(title=name, resume_seconds=position or '0', resume_percent=resume_percent or '',
                  preferred_provider_name=provider_name or '', source_provider_id=source_provider_id or '')
    if str(direct or '').strip().lower() in ('1', 'true', 'yes', 'on'):
        if kind in ('series', 'tv', 'show', 'anime') or episode_given:
            return _play_best_episode_source(canonical_id, video_id or canonical_id, season, episode, **shared)
        return _play_best_movie_source(canonical_id, **shared)
    seed = _route_seed_of(ui_poster=ui_poster, ui_fanart=ui_fanart, ui_clearlogo=ui_clearlogo, ui_seed_key=ui_seed_key)
    if studio:
        seed['studio'] = studio
    return _dispatch_meganexus_play(media_type=kind, canonical_id=canonical_id, title=name, video_id=video_id, season=season,
                                    episode=episode, resume_seconds=position or '0', resume_percent=resume_percent or '',
                                    preferred_provider_name=provider_name or '', source_provider_id=source_provider_id or '',
                                    ui_seed=seed or None)


def continue_from_start(media_type='', canonical_id='', video_id='', season='', episode='', title='', provider_name='', source_provider_id=''):
    return continue_resume(
        media_type=media_type,
        canonical_id=canonical_id,
        video_id=video_id,
        season=season,
        episode=episode,
        title=title,
        position='0',
        provider_name=provider_name,
        direct='0',
        source_provider_id=source_provider_id,
    )


def _continue_is_episode(row):
    try:
        return int(row.get('season') or 0) > 0 and int(row.get('episode') or 0) >= 0
    except Exception:
        return False


_CW_CODE_RE = re.compile(r'^(?:(?=[A-Z0-9]*[A-Z])[A-Z0-9]{4,}|\d{5,})$')


def _continue_title_is_code(text):
    t = str(text or '').strip()
    return (not t) or bool(_CW_CODE_RE.match(t))


def _continue_show_name(row):
    """The show's name for an episode row (its own unless it is a code, else TMDb Helper's)."""
    show = str(row.get('show_title') or '').strip()
    if show and not _continue_title_is_code(show):
        return show
    ask = dict(tmdb_id=str(row.get('show_tmdb_id') or row.get('tmdb_id') or '').strip(),
               imdb_id=str(row.get('imdb_id') or '').strip(), media_type='tv')
    if ask['tmdb_id'] or ask['imdb_id']:
        try:
            found = _tmdb_art_db.stored_meta(**ask) or {}
            name = str(found.get('title') or found.get('name') or '').strip()
            if name and not _continue_title_is_code(name):
                return name
        except Exception:
            pass
    return ''


def _continue_episode_poster(row):
    """The show's poster for an episode row (TMDb Helper's copy, else the TMDB cache; never a network call)."""
    ask = dict(tmdb_id=str(row.get('show_tmdb_id') or row.get('tmdb_id') or '').strip(),
               imdb_id=str(row.get('imdb_id') or '').strip(), media_type='tv')
    if not (ask['tmdb_id'] or ask['imdb_id']):
        return ''
    try:
        poster = (_tmdb_art_db.stored_pictures(**ask) or {}).get('poster')
        if poster:
            return poster
    except Exception:
        pass
    try:
        return (_tmdb_api.art_cached_only(**ask) or {}).get('poster') or ''
    except Exception:
        return ''


def _continue_row_look(art):
    try:
        style = (_setting('continue_art_style', 'poster') or 'poster').strip().lower()
    except Exception:
        style = 'poster'
    if style in ('landscape', 'banner', '1'):
        wide = art.get('landscape') or art.get('fanart') or art.get('poster') or ''
        if wide:
            art['thumb'] = wide
            art['icon'] = wide
            art['banner'] = wide
    else:
        if art.get('poster'):
            art['thumb'] = art['poster']
    return art


def home_xml():
    from .frontend_bridge import open_home
    return open_home()


def _continue_names(row, episode):
    """(the row's title, the show's name, the episode's own name)."""
    title = row.get('title') or ''
    if _continue_title_is_code(title):
        title = _continue_show_name(row) if episode else ''
    title = title or ('' if episode else 'Untitled')
    show = _continue_show_name(row) if episode else ''
    return title, show, title if episode and title and title != show else ''


def _continue_label(row, title, show, episode_name):
    code = 'S%02dE%02d' % (int(row.get('season') or 0), int(row.get('episode') or 0))
    if show:
        return '%s — %s' % (show, code)
    return '%s — %s' % (code, episode_name) if episode_name else code


def _continue_resume_url(row, kind, title):
    """Resume through the add-on that played it; a Plex / Jellyfin / Emby item keeps its server ids."""
    seed = ''
    if row.get('native_server_id') and row.get('native_item_id'):
        try:
            seed = keyed_cache.put('ui_seed', {'native_server_id': str(row['native_server_id']),
                                               'native_item_id': str(row['native_item_id'])}, ttl_hours=24)
        except Exception:
            seed = ''
    return build_url(action='cw_resume', media_type=kind, canonical_id=row.get('canonical_id') or '',
                     video_id=row.get('video_id') or '', season=row.get('season') or '', episode=row.get('episode') or '',
                     title=title, position=row.get('position') or 0, resume_percent=row.get('percent') or '',
                     provider_name=row.get('provider_name') or '', direct='0', source_provider_id=_continue_ref(row),
                     ui_poster=row.get('poster') or '', ui_fanart=row.get('background') or '',
                     ui_clearlogo=row.get('clearlogo') or '', studio=row.get('studio') or '', ui_seed_key=seed)


def _continue_info(row, label, show, episode_name, episode):
    percent = float(row.get('percent') or 0.0)
    position, length = float(row.get('position') or 0.0), float(row.get('duration') or 0.0)
    plot = '%.1f%% • %s' % (percent, row.get('provider_name') or '')
    info = {'title': label, 'plot': plot, 'mediatype': 'episode' if episode else 'movie', 'playcount': 0}
    if episode:
        if show:
            info['tvshowtitle'] = show
        if episode_name:
            info['plot'] = '%s\n%s' % (episode_name, plot)
        info.update(season=int(row.get('season') or 0), episode=int(row.get('episode') or 0))
    if length > 0:
        info['duration'] = int(length)
    try:
        if float(row.get('rating') or 0) > 0:
            info['rating'] = float(row['rating'])
    except Exception:
        pass
    if row.get('studio'):
        info['studio'] = row['studio']
    props = {'IsPlayable': 'true'}
    if length > 0 and position > 0:
        info.update(resumetime=position, totaltime=length)
        props.update(ResumeTime=str(int(position)), TotalTime=str(int(length)))
    if percent:
        props.update(WatchedProgress=str(int(percent)), PercentPlayed=str(int(percent)))
    return info, props


def _continue_pictures(row, episode):
    poster = _wrap_tokenized_url((_continue_episode_poster(row) if episode else '') or row.get('poster') or '')
    background = _wrap_tokenized_url(row.get('background') or '') or addon_fanart()
    logo = _wrap_tokenized_url(row.get('clearlogo') or '')
    art = {'thumb': poster, 'poster': poster, 'fanart': background, 'landscape': background or poster, 'clearlogo': logo}
    if logo:
        art.update({'logo': logo, 'tvshow.clearlogo': logo})
    _continue_row_look(art)
    return art


def _continue_menu(row, kind, title, url_title, episode, resume_url):
    canonical = row.get('canonical_id') or ''
    ids = _merge_seed_ids(extract_ids({'id': canonical}), _get_tmdbh_seed_ids(canonical))
    id_args = dict((key, ids.get(key) or '') for key in ('tmdb_id', 'imdb_id', 'tvdb_id'))
    from_start = build_url(action='cw_play_from_start', media_type=kind, canonical_id=canonical,
                           video_id=row.get('video_id') or '', season=row.get('season') or '',
                           episode=row.get('episode') or '', title=url_title,
                           provider_name=row.get('provider_name') or '', direct='1')
    details = (build_url(action='series_meta', media_type='series', canonical_id=canonical, title=title) if episode else
               build_url(action='item_open', media_type=row.get('media_type') or 'movie', canonical_id=canonical,
                         title=title, **id_args))
    ref = _continue_ref(row)
    section = 'Continue Watching • Series/Anime' if ref.endswith('series') else 'Continue Watching • Movies'
    own = dict(media_type=row.get('media_type'), canonical_id=row.get('canonical_id'), video_id=row.get('video_id'))
    return ([('Choose add-on', 'Container.Update(%s)' % _continue_play_url(row)),
             ('Resume directly', 'RunPlugin(%s)' % resume_url),
             ('Play from the beginning', 'RunPlugin(%s)' % from_start),
             ('Open show' if episode else 'Open details', 'Container.Update(%s)' % details),
             (tr('Change metadata add-on'), 'RunPlugin(%s)' % build_url(action='meta_pick_target', target_key=ref,
                                                                         title=section))]
            + _player_choices(media_type='series' if episode else (row.get('media_type') or 'movie'),
                              canonical_id=canonical, title=title, season=row.get('season') or '',
                              episode=row.get('episode') or '', video_id=row.get('video_id') or '', **id_args)
            + [('Remove from Continue Watching', 'RunPlugin(%s)' % build_url(action='cw_remove', **own)),
               ('Mark as watched', 'RunPlugin(%s)' % build_url(action='cw_mark_watched', **own))])


def continue_rows(page='0'):
    """Continue Watching: what was left part-way, newest first, with pictures filled in at once."""
    _set_render_section('continue')
    try:
        _take_pov_progress()
    except Exception:
        pass
    number, _size, page_rows, more = _page_of(progress_db.list_continue_items(limit=500), page)
    rows = [row if isinstance(filled, Exception) else filled for row, filled in all_at_once(_pictures_later, page_rows)]
    for row in rows:
        episode = _continue_is_episode(row)
        title, show, episode_name = _continue_names(row, episode)
        url_title = (show or title) if episode else title
        kind = row.get('media_type') or ('series' if episode else 'movie')
        label = _continue_label(row, title, show, episode_name) if episode else title
        resume_url = _continue_resume_url(row, kind, url_title)
        info, props = _continue_info(row, label, show, episode_name, episode)
        add_item(label, resume_url, is_folder=False, info=info, art=_continue_pictures(row, episode), properties=props,
                 context_menu=_continue_menu(row, kind, title, url_title, episode, resume_url))
    if more:
        add_item('More', build_url(action='continue', page=str(number + 1)),
                 info={'title': 'More', 'plot': 'Load more items from Continue Watching'}, art=root_art('continue'))
    only_episodes = bool(rows) and all(_continue_is_episode(row) for row in rows)
    end_dir(content='episodes' if only_episodes else 'movies', cache=False)


def continue_remove(media_type='', canonical_id='', video_id=''):
    try:
        progress_db.delete_entry(media_type, canonical_id, video_id)
        _drop_next_up_cache()
        notify(tr('Removed from Continue Watching'))
    except Exception as exc:
        error(tr('Could not remove: %s') % exc)
    xbmc.executebuiltin('Container.Refresh')


def continue_watched(media_type='', canonical_id='', video_id=''):
    try:
        progress_db.mark_watched(media_type, canonical_id, video_id)
        _drop_next_up_cache()
        notify(tr('Marked as watched'))
    except Exception as exc:
        error(tr('Could not mark item: %s') % exc)
    xbmc.executebuiltin('Container.Refresh')


def reload_addon(provider_id):
    row = addon_registry.get_provider(provider_id)
    if not row:
        error(tr('Add-on not found'))
        return
    manifest_url = row.get('manifest_url') or ''
    if not manifest_url:
        error(tr('Unknown manifest URL'))
        return
    try:
        new_manifest = manifest_ok(manifest_url)
        addon_registry.reload_manifest(provider_id, new_manifest)
        notify(tr('Updated: %s') % (row.get('name') or provider_id))
    except Exception as exc:
        error(tr('Update failed: %s') % exc)
    xbmc.executebuiltin('Container.Refresh')


_SERIES_WINDOW_PROPS = ('meganexus.fav_mirror_done', 'meganexus.fav_mirror_syncing', 'meganexus.fav_mirror_syncing_started')


def _forget_quietly(*steps):
    for step in steps:
        try:
            step()
        except Exception:
            pass


def _remove_file(path):
    if path and os.path.exists(path):
        os.remove(path)


def _clear_series_window():
    home = xbmcgui.Window(WINDOW_ID)
    for key in _SERIES_WINDOW_PROPS:
        _forget_quietly(lambda key=key: home.clearProperty(key))
    for key in list(getattr(home, 'getPropertyKeys', lambda: [])() or []):
        if key.startswith(SERIES_PROP_PREFIX):
            _forget_quietly(lambda key=key: home.clearProperty(key))


def clear_cache():
    """Clear every cache (HTTP, lists, details, searches, Next Up, source choices, playback log, window copies)."""
    removed = [0]

    def http():
        from .meganexus import addon_wire as client
        removed[0] += int(client.clear_http_cache() or 0)

    def details():
        from . import detail_cache
        detail_cache.clear_all()

    def searches():
        _searches.clear()
    _forget_quietly(http, keyed_cache.clear_all, details, searches)
    _drop_next_up_cache()
    _forget_quietly(lambda: _remove_file(_source_pref_path()), lambda: _remove_file(_playback_monitor_path()),
                    _clear_series_window)
    notify(tr('Cache cleared (%s HTTP files)') % removed[0] if removed[0] else tr('Cache cleared'))
    _forget_quietly(lambda: xbmc.executebuiltin('Container.Refresh'))
    return end_dir()


def open_addon_settings():
    try:
        ADDON.openSettings()
    except Exception:
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % ADDON.getAddonInfo('id'))


def trakt_menu():
    state = trakt_api.authorization_status()
    status = 'Connected' if state == 'connected' else 'Ready to connect via PIN'
    plot = 'Manage Trakt linking and sync via PIN only'
    add_item(tr('Trakt status: %s') % status, build_url(action='trakt_menu'), is_folder=False, info={'title': 'Trakt', 'plot': plot}, art=root_art('trakt'))
    add_item(tr('Connect Trakt via PIN'), build_url(action='trakt_auth'), is_folder=False, art=root_art('trakt'),
             info={'title': 'Connect Trakt via PIN', 'plot': 'Shows the trakt.tv/activate link and pairing code, then waits for authorization'})
    add_item(tr('Import progress from Trakt'), build_url(action='trakt_import'), is_folder=False, art=root_art('continue'))
    add_item(tr('Disconnect Trakt'), build_url(action='trakt_logout'), is_folder=False, art=root_art('add'))
    end_dir()


def trakt_auth():
    try:
        if trakt_api.device_auth():
            notify(tr('Trakt linked'))
        else:
            error(tr('The Trakt link was cancelled or timed out'))
    except Exception as exc:
        error(tr('Trakt link failed: %s') % exc)
    return trakt_menu()


def trakt_logout():
    try:
        trakt_api.logout()
    except Exception as exc:
        error(tr('Sign-out failed: %s') % exc)
    return trakt_menu()


def trakt_take():
    total = 0
    try:
        total += int(_take_pov_progress(force=True) or 0)
    except Exception:
        pass
    try:
        count = trakt_api.take_progress(limit=100)
        total += int(count or 0)
        _drop_next_up_cache()
        notify(tr('Imported %s items from Trakt/POV') % total)
    except Exception as exc:
        if total:
            _drop_next_up_cache()
            notify(tr('Imported %s items from POV') % total)
        else:
            error(tr('Trakt import failed: %s') % exc)
    return continue_rows()


# ─── Simkl  ─────────────────────────────────────────────────────────

def simkl_menu():
    state = simkl_api.authorization_status()
    if state == 'connected':
        status = tr('Connected')
    elif state == 'ready':
        status = tr('Ready to connect via PIN')
    else:
        status = tr('Needs a Client ID')
    add_item(tr('Simkl status: %s') % status, build_url(action='simkl_menu'), is_folder=False,
             info={'title': 'Simkl', 'plot': tr('Manage Simkl linking and sync: watch history and your lists')},
             art=root_art('simkl'))
    if state != 'connected':
        add_item(tr('Link Simkl via PIN'), build_url(action='simkl_auth'), is_folder=False,
                 art=root_art('simkl'),
                 info={'title': tr('Link Simkl via PIN'),
                       'plot': tr('Shows the simkl.com/pin link and code, then waits for approval')})
    if state == 'connected':
        add_item(tr('My Simkl lists'), build_url(action='simkl_lists_menu'), is_folder=True,
                 art=root_art('watchlist'),
                 info={'title': tr('My Simkl lists'),
                       'plot': tr('Watching, plan to watch, completed, on hold')})
        add_item(tr('Sync Simkl now'), build_url(action='simkl_sync_now'), is_folder=False,
                 art=root_art('simkl'),
                 info={'title': tr('Sync Simkl now'),
                       'plot': tr('Continue Watching + watch history (movies & episodes) + merging plan-to-watch into the watchlist')})
        add_item(tr('Import watch history from Simkl'), build_url(action='simkl_import'), is_folder=False,
                 art=root_art('continue'),
                 info={'title': tr('Import watch history from Simkl'),
                       'plot': tr('Marks completed movies and watched show episodes locally in MegaNexus')})
        add_item(tr('Sign out of Simkl'), build_url(action='simkl_logout'), is_folder=False, art=root_art('add'))
    end_dir()


def simkl_auth():
    try:
        if simkl_api.device_auth():
            notify(tr('Simkl linked'))
        else:
            error(tr('Simkl linking was cancelled or timed out'))
    except Exception as exc:
        error(tr('Simkl linking failed: %s') % exc)
    return simkl_menu()


def simkl_logout():
    try:
        simkl_api.logout()
        notify(tr('Signed out of Simkl'))
    except Exception as exc:
        error(tr('Sign-out failed: %s') % exc)
    return simkl_menu()


def simkl_import():
    try:
        movies, episodes = simkl_api.take_watched()
        notify(tr('Imported %s movies and %s episodes as watched from Simkl') % (int(movies or 0), int(episodes or 0)))
    except Exception as exc:
        error(tr('Simkl import failed: %s') % exc)
    return simkl_menu()


def simkl_sync_round():
    try:
        cw = simkl_api.sync_continue_watching()
        movies, episodes = simkl_api.take_watched()
        _refresh_list_copy()
        notify(tr('Simkl sync: %s continue rows, %s movies, %s episodes') % (int(cw or 0), int(movies or 0), int(episodes or 0)))
    except Exception as exc:
        error(tr('Simkl sync failed: %s') % exc)
    return simkl_menu()


def simkl_list_menu():
    shelves = (
        ('shows', 'watching', tr('Shows • Watching')),
        ('shows', 'plantowatch', tr('Shows • Plan to watch')),
        ('shows', 'completed', tr('Shows • Completed')),
        ('shows', 'hold', tr('Shows • On hold')),
        ('movies', 'plantowatch', tr('Movies • Plan to watch')),
        ('movies', 'completed', tr('Movies • Completed')),
        ('anime', 'watching', tr('Anime • Watching')),
        ('anime', 'plantowatch', tr('Anime • Plan to watch')),
    )
    for kind, status, label in shelves:
        add_item(label,
                 build_url(action='simkl_list_browse', kind=kind, status=status, title=label),
                 is_folder=True, art=root_art('watchlist'),
                 info={'title': label, 'plot': tr('Your Simkl list')})
    end_dir()


# ─── MDBList account  ───────────────────────────────────────────────

def _mdblist_account():
    """(key saved, verified, account name, error text) of the MDBList account."""
    if not mdblist.configured():
        return False, False, '', ''
    try:
        info = mdblist.fetch_user_info(strict=True) or {}
    except Exception as exc:
        return True, False, '', str(exc)
    account = info.get('user') if isinstance(info.get('user'), dict) else info
    name = str(account.get('username') or account.get('user_name') or account.get('name') or '').strip()
    return True, bool(info), name, ''


def mdblist_home():
    """MDBList: the account's state, its key, watchlist and lists."""
    saved, verified, name, problem = _mdblist_account()
    if verified:
        state = '%s%s' % (tr('Linked ✓'), ' • %s' % name if name else '')
    else:
        state = tr('The key is saved, but account verification failed') if saved and problem else tr('Needs an API Key')
    plot = tr('Your MDBList account lists and watchlist inside MegaNexus. Get the key from mdblist.com/preferences')
    add_item(tr('MDBList status: %s') % state, build_url(action='mdblist_my_lists' if verified else 'mdblist_set_key'),
             is_folder=verified, art=root_art('mdblist'),
             info={'title': 'MDBList', 'plot': '%s\n\n%s' % (plot, problem) if problem else plot})
    add_item(tr('Enter / edit the MDBList API Key'), build_url(action='mdblist_set_key'), is_folder=False,
             art=root_art('settings'),
             info={'title': tr('Enter / edit the MDBList API Key'), 'plot': tr('Get the key for free from mdblist.com/preferences')})
    if saved:
        add_item('MDBList • Watchlist', build_url(action='mdblist_watchlist_browse'), is_folder=True, art=root_art('watchlist'),
                 info={'title': 'MDBList • Watchlist', 'plot': tr('Your MDBList account watchlist')})
        add_item(tr('My MDBList lists'), build_url(action='mdblist_my_lists'), is_folder=True, art=root_art('catalogs'),
                 info={'title': tr('My MDBList lists'), 'plot': tr('Every list you created on your account')})
    end_dir()


def mdblist_key_entry():
    current = ''
    try:
        current = ADDON.getSetting('mdblist_api_key') or ''
    except Exception:
        pass
    value = xbmcgui.Dialog().input(tr('Enter the MDBList API Key'), defaultt=current)
    value = (value or '').strip()
    try:
        ADDON.setSetting('mdblist_api_key', value)
    except Exception:
        pass
    try:
        mdblist.clear_cache()
    except Exception:
        pass
    if value:
        try:
            info = mdblist.fetch_user_info(strict=True) or {}
        except Exception as exc:
            error(tr('The key was saved, but MDBList rejected validation:\n%s') % exc)
            return mdblist_home()
        if info:
            notify(tr('MDBList key saved and verified ✓'))
        else:
            error(tr('The key was saved, but MDBList returned an empty account. Check the key.'))
    else:
        notify(tr('MDBList key cleared'))
    return mdblist_home()


def _mdblist_retry_row(label, plot):
    add_item(label, build_url(action='mdblist_my_lists'), is_folder=True, art=root_art('catalogs'),
             info={'title': label, 'plot': plot})
    return end_dir(content='files', cache=False)


def mdblist_own_lists():
    """The lists on the user's MDBList account (fresh each time), each opening by its id."""
    try:
        mdblist.clear_cache()
        lists = mdblist.own_lists() or []
    except Exception as exc:
        error(tr('Could not read your MDBList lists: %s') % exc)
        return _mdblist_retry_row(tr('Try again'), str(exc))
    if not lists:
        return _mdblist_retry_row(tr('No lists on your account yet'),
                                  tr('The account was verified, but MDBList returned no lists. If you just created one, '
                                     'select this row to refresh.'))
    for entry in lists:
        name = entry.get('name') or entry.get('slug') or ''
        if not entry.get('id'):
            xbmc.log('[MegaNexus] MDBList account row skipped without list id: %r' % name, xbmc.LOGWARNING)
            continue
        marks = [mark for mark, on in ((tr('Private'), entry.get('private')), (tr('Dynamic'), entry.get('dynamic')),
                                       (str(entry.get('mediatype') or ''), entry.get('mediatype'))) if on]
        plot = entry.get('description') or tr('A list from your MDBList account')
        add_item('%s (%s)' % (name, entry.get('items') or 0),
                 build_url(action='mdblist_list_browse_id', list_id=entry['id'], title=name), is_folder=True,
                 art=root_art('catalogs'), info={'title': name, 'plot': '%s\n\n%s' % (plot, ' • '.join(marks)) if marks else plot})
    end_dir(content='files', cache=False)


def helper_install():
    if not helper_player_file.has_tmdbhelper():
        error(tr('TMDb Helper is not installed'))
        return services_menu()
    was_installed = helper_player_file.player_installed()
    if helper_player_file.install(silent=False):
        notify(tr('MegaNexus registration updated in TMDb Helper') if was_installed else tr('MegaNexus was registered in TMDb Helper'))
        try:
            xbmcgui.Dialog().ok(
                'MegaNexus • TMDb Helper',
                tr('[B]Registered successfully ✓[/B]\n\nMegaNexus now appears as a player in the TMDb Helper list when you press Play, alongside any other players you have registered.'),
            )
        except Exception:
            pass
    return services_menu()


def tmdbh_uninstall():
    if helper_player_file.uninstall(silent=False):
        notify(tr('MegaNexus was removed from TMDb Helper'))
    else:
        notify(tr('The player is not registered'))
    return services_menu()


def _play_overrides(resume_seconds, resume_percent, subtitle_path, subtitle_enabled, subtitle_name):
    """What the play link changes on the stored source: the resume point and, after a source switch, the subtitle."""
    out = {}
    try:
        if float(resume_seconds or 0.0) > 1.0:
            out['resume_seconds'] = float(resume_seconds)
    except Exception:
        pass
    try:
        if 1.0 < float(resume_percent or 0.0) < 95.0:
            out['resume_percent'] = float(resume_percent)
    except Exception:
        pass
    if subtitle_path:
        out.update(switch_subtitle_path=str(subtitle_path),
                   switch_subtitle_enabled=str(subtitle_enabled or '1').strip().lower() not in ('0', 'false', 'no', 'off'),
                   switch_subtitle_name=str(subtitle_name or ''), source_switch_reuse_subtitle=True,
                   play_with_subtitles=False, selected_subtitle='')
    return out


def play(stream_key, resume_seconds='', resume_percent='', fallback_keys=None, switch_subtitle_path='', switch_subtitle_enabled='', switch_subtitle_name=''):
    """Play a chosen source (stored under its key when the list was made)."""
    if _route_running('play|%s' % (stream_key or ''), window_seconds=4):
        xbmc.log('[MegaNexus] play: duplicate dispatch suppressed (%s)' % stream_key, xbmc.LOGINFO)
        return
    ctx = keyed_cache.get('stream', stream_key)
    if not ctx:
        error(tr('Playback data expired. Choose the source again.'))
        return end_dir()
    changes = _play_overrides(resume_seconds, resume_percent, switch_subtitle_path, switch_subtitle_enabled,
                              switch_subtitle_name)
    _start_playback(dict(ctx or {}, **changes) if changes else ctx, stream_key, fallback_keys=[])



def _ask_missing_addon(addon_id, host_hint):
    """The user's manifest for an add-on a collection needs (asked; '' when skipped)."""
    lines = [tr('This collection depends on an addon that is not installed yet:'), '[COLOR yellow]%s[/COLOR]' % addon_id, '']
    if host_hint:
        lines += [tr('It appears to be hosted on:'), '[COLOR yellow]%s[/COLOR]' % host_hint, '']
    try:
        if _collections_mod.needs_setup(addon_id):
            lines += [tr('This addon needs a Manifest URL configured for your account/library, not the public manifest.'), '']
    except Exception:
        pass
    lines.append(tr('Do you have its manifest.json URL?'))
    if not xbmcgui.Dialog().yesno(tr('Missing addon'), '\n'.join(lines), nolabel=tr('Skip'), yeslabel=tr('Paste a URL')):
        return ''
    keyboard = xbmc.Keyboard('', tr('Paste a manifest.json or collections.json URL for %s') % addon_id)
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return ''
    typed = keyboard.getText().strip()
    try:
        return _collections_mod.manifest_of_collection(typed) or typed
    except Exception:
        return typed


def _addon_manifest_finder(host_hint=''):
    """How a collection import finds an add-on it needs: the collection's own link (for add-ons
    configured per account), a known public manifest, else the user."""
    def find(addon_id, share_url):
        try:
            sibling = _collections_mod.manifest_of_collection(share_url)
            if sibling and (_collections_mod.needs_setup(addon_id) or 'plex' in str(addon_id or '').lower()):
                return sibling
        except Exception:
            pass
        try:
            known = _collections_mod.known_manifest_for_addon_id(addon_id)
            if known:
                return known
        except Exception:
            pass
        return _ask_missing_addon(addon_id, host_hint)
    return find


def _trakt_stored_poster(meta):
    """The poster a list row carries itself (its fields, else its images block)."""
    meta = meta or {}
    poster = str(meta.get('poster') or meta.get('thumbnail') or meta.get('thumb') or '').strip()
    images = meta.get('images') if isinstance(meta.get('images'), dict) else {}
    for key in ('poster', 'thumb', 'thumbnail'):
        if poster:
            break
        node = images.get(key) or {}
        poster = (str(node.get('full') or node.get('medium') or node.get('thumb') or '') if isinstance(node, dict)
                  else str(node or '')).strip()
    return poster


def _trakt_pictures(ids, media_type, title='', year='', meta=None, force_remote=False, allow_direct=True):
    """A list row's pictures: TMDb Helper's local copy, TMDB when something is missing (and allowed);
    with local posters on, the poster the list service gave."""
    ids = ids or {}
    ask = dict(tmdb_id=str(ids.get('tmdb') or ids.get('tmdb_id') or '').strip(),
               imdb_id=str(ids.get('imdb') or ids.get('imdb_id') or '').strip(),
               media_type='tv' if media_type in ('series', 'anime', 'show', 'tv') else 'movie', title=title or '',
               year=year or '')
    local = posters_prefer_local() and not force_remote
    own_poster = _trakt_stored_poster(meta) if local else ''
    try:
        stored = _tmdb_art_db.stored_pictures(**ask) or {}
    except Exception:
        stored = {}
    direct = {}
    if allow_direct and not (stored.get('fanart') and stored.get('clearlogo') and (local or stored.get('poster'))):
        try:
            direct = _tmdb_api.art_for(**ask) or {}
        except Exception:
            direct = {}
    pick = lambda *keys: next((source[k] for source in (stored, direct) for k in keys if source.get(k)), '')
    return {'poster': own_poster if local else (stored.get('poster') or direct.get('poster') or own_poster or ''),
            'fanart': stored.get('fanart') or stored.get('landscape') or direct.get('fanart') or direct.get('landscape') or '',
            'landscape': stored.get('landscape') or stored.get('fanart') or direct.get('landscape') or direct.get('fanart') or '',
            'clearlogo': pick('clearlogo')}


_FOLDER_FIELDS = ('title', 'originaltitle', 'thumbnail', 'fanart', 'art', 'plot', 'plotoutline', 'tagline', 'genre', 'year',
                  'rating', 'userrating', 'ratings', 'votes', 'runtime', 'duration', 'studio', 'mpaa', 'country', 'premiered',
                  'firstaired', 'dateadded', 'trailer', 'playcount', 'lastplayed', 'director', 'writer', 'cast', 'season',
                  'episode', 'showtitle', 'tvshowid', 'imdbnumber', 'uniqueid', 'resume', 'streamdetails')


_FOLDER_FIELDS_FEW = ('title', 'thumbnail', 'fanart', 'plot')


def _plugin_folder_files(directory, fields):
    answer = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
        'params': {'directory': directory, 'media': 'video', 'properties': list(fields)}})) or '{}')
    if answer.get('error'):
        raise ValueError(str(answer.get('error')))
    return (answer.get('result') or {}).get('files') or []


def _read_plugin_folder(directory):
    """Another add-on's folder read through Kodi (all fields, else the basic ones): its plugin:// rows."""
    directory = str(directory or '').strip()
    if not directory:
        return []
    rows = []
    try:
        try:
            files = _plugin_folder_files(directory, _FOLDER_FIELDS)
        except Exception as exc:
            xbmc.log('[MegaNexus] rich plugin directory read failed for %s: %s; falling back' % (directory, exc),
                     xbmc.LOGDEBUG)
            files = _plugin_folder_files(directory, _FOLDER_FIELDS_FEW)
        for entry in files:
            url = str(entry.get('file') or '').strip() if isinstance(entry, dict) else ''
            if not url.startswith('plugin://'):
                continue
            label = str(entry.get('label') or entry.get('title') or entry.get('label2') or url).strip()
            rows.append(dict(entry, file=url, label=label or url,
                             is_folder=str(entry.get('filetype') or '').strip().lower() == 'directory',
                             thumbnail=entry.get('thumbnail') or '', fanart=entry.get('fanart') or '',
                             plot=entry.get('plot') or ''))
    except Exception as exc:
        xbmc.log('[MegaNexus] list plugin directory failed for %s: %s' % (directory, exc), xbmc.LOGWARNING)
    return rows


def _plugin_row_query(row):
    try:
        return parse_qs((urlparse(str((row or {}).get('file') or '')).query or ''), keep_blank_values=True)
    except Exception:
        return {}


def _query_value(qs, *keys):
    for key in keys:
        vals = (qs or {}).get(key) or (qs or {}).get(key.lower()) or (qs or {}).get(key.upper())
        if isinstance(vals, (list, tuple)) and vals:
            val = str(vals[0] or '').strip()
        else:
            val = str(vals or '').strip() if vals else ''
        if val:
            return val
    return ''


def _plugin_ids(row):
    row = row or {}
    unique = row.get('uniqueid') or {}
    if not isinstance(unique, dict):
        unique = {}
    qs = _plugin_row_query(row)
    imdb = str(unique.get('imdb') or unique.get('imdb_id') or row.get('imdbnumber') or _query_value(qs, 'imdb_id', 'imdb')).strip()
    tmdb = str(unique.get('tmdb') or unique.get('tmdb_id') or _query_value(qs, 'tmdb_id', 'tmdb')).strip()
    tvdb = str(unique.get('tvdb') or unique.get('tvdb_id') or _query_value(qs, 'tvdb_id', 'tvdb')).strip()
    if imdb and imdb.isdigit():
        imdb = 'tt%s' % imdb
    return {'imdb_id': imdb, 'tmdb_id': tmdb, 'tvdb_id': tvdb}


_PLUGIN_KINDS = (('tvshow', ('tv', 'show', 'series', 'tvshow', 'tvshows')), ('episode', ('episode', 'episodes')),
                 ('season', ('season', 'seasons')), ('movie', ('movie', 'movies', 'film')))


def _plugin_media_type(row):
    """The Kodi media type of another add-on's row (its own word, its link's, else what its fields suggest)."""
    row = row or {}
    query = _plugin_row_query(row)
    given = str(row.get('mediatype') or row.get('type') or _query_value(query, 'type', 'mediatype', 'media_type') or '').strip().lower()
    action = str(_query_value(query, 'info') or '').strip().lower()
    for kind, words in _PLUGIN_KINDS:
        if given in words or (kind == 'episode' and action in ('play_episode', 'episode')):
            return kind
    if row.get('episode') not in (None, ''):
        return 'episode'
    if row.get('showtitle') or row.get('season') not in (None, ''):
        return 'tvshow'
    return 'movie'


_PLUGIN_INFO_COPY = (('genre', 'genre'), ('studio', 'studio'), ('mpaa', 'mpaa'), ('country', 'country'),
                     ('premiered', 'premiered'), ('firstaired', 'premiered'), ('trailer', 'trailer'),
                     ('director', 'director'), ('writer', 'writer'), ('cast', 'cast'), ('streamdetails', 'streamdetails'))


def _given(value):
    return value not in (None, '')


def _plugin_info(row, label=''):
    """Kodi's video information for a row read from another add-on's folder."""
    row = row or {}
    kind = _plugin_media_type(row)
    info = dict((key, row.get(key) or '') for key in ('plot', 'plotoutline', 'tagline', 'originaltitle'))
    info.update(title=row.get('title') or label or row.get('label') or '', mediatype=kind)
    if kind == 'tvshow':
        info['tvshowtitle'] = info['title']
    elif kind == 'episode':
        info['tvshowtitle'] = row.get('showtitle') or row.get('tvshowtitle') or ''
    numbers = [(key, int, row.get(key)) for key in ('year', 'playcount', 'season', 'episode')]
    numbers += [('rating', float, row.get('rating') if _given(row.get('rating')) else row.get('userrating')),
                ('votes', lambda v: int(str(v).replace(',', '')), row.get('votes')),
                ('duration', lambda v: int(float(v)), row.get('runtime') if _given(row.get('runtime')) else row.get('duration'))]
    for key, convert, value in numbers:
        if _given(value):
            try:
                info[key] = convert(value)
            except Exception:
                pass
    info.update((field, row[key]) for key, field in _PLUGIN_INFO_COPY if row.get(key) not in (None, '', [], {}))
    imdb = _plugin_ids(row).get('imdb_id')
    if imdb:
        info['imdbnumber'] = imdb
    return dict((k, v) for k, v in info.items() if v not in (None, '', [], {}))


def _plugin_picture(art, *keys):
    if not isinstance(art, dict):
        return ''
    lowered = {str(k).lower(): v for k, v in art.items()}
    for key in keys:
        val = art.get(key)
        if val:
            return str(val)
        val = lowered.get(str(key).lower())
        if val:
            return str(val)
    return ''


def _plugin_pictures(row, background=''):
    """Kodi's picture slots for another add-on's row (from its art block, thumbnail and fanart)."""
    row = row or {}
    given = row.get('art') if isinstance(row.get('art'), dict) else {}
    pick = lambda *keys: _wrap_tokenized_url(_plugin_picture(given, *keys))
    thumb = _wrap_tokenized_url(row.get('thumbnail') or _plugin_picture(given, 'thumb', 'icon'))
    poster = pick('poster', 'tvshow.poster', 'season.poster', 'thumb', 'icon') or thumb
    fanart = (_wrap_tokenized_url(row.get('fanart') or _plugin_picture(given, 'fanart', 'tvshow.fanart', 'season.fanart',
                                                                      'background')) or background or addon_fanart())
    wide = pick('landscape', 'tvshow.landscape', 'season.landscape', 'fanart') or fanart or poster
    logo = pick('clearlogo', 'logo', 'tvshow.clearlogo', 'season.clearlogo')
    poster = poster or thumb or wide or fanart
    face = thumb or poster
    out = {'poster': poster, 'tvshow.poster': pick('tvshow.poster') or poster, 'season.poster': pick('season.poster') or poster,
           'thumb': face, 'icon': face, 'thumbnail': face, 'cover': poster, 'image': poster,
           'tvshow.thumb': pick('tvshow.thumb') or face, 'fanart': fanart, 'landscape': wide,
           'banner': pick('banner', 'tvshow.banner', 'season.banner') or wide, 'clearlogo': logo, 'logo': logo,
           'tvshow.clearlogo': logo, 'clearart': pick('clearart', 'tvshow.clearart')}
    return dict((k, v) for k, v in out.items() if v)




def _kodi_builtin_arg(value):
    return json.dumps(str(value or '').strip())




def _content_of_rows(rows):
    kinds = set()
    for row in rows or []:
        mt = _plugin_media_type(row)
        if mt:
            kinds.add(mt)
    if kinds and kinds.issubset(set(['episode'])):
        return 'episodes'
    if kinds and kinds.issubset(set(['tvshow', 'season'])):
        return 'tvshows'
    return 'movies'


def _add_kodi_path_row(row, background):
    url = str(row.get('file') or '').strip()
    label = row.get('label') or row.get('title') or url or 'Item'
    art = _plugin_pictures(row, background=background)
    info = _plugin_info(row, label=label)
    cast = info.pop('cast', None) if isinstance(info.get('cast'), list) else None
    common = dict(info=info, art=art, ids=_plugin_ids(row), cast=cast)
    if row.get('is_folder'):
        add_item(label, build_url(action='kodi_route_browse', route=url, title=label,
                                  background=art.get('fanart') or background or addon_fanart() or background, page='0'),
                 is_folder=True, context_menu=[(tr('Open with original path'),
                                                'Container.Update(%s)' % _kodi_builtin_arg(url))], **common)
    else:
        add_item(label, url, is_folder=False, properties={'IsPlayable': 'true'},
                 context_menu=[(tr('Open with original path'), 'RunPlugin(%s)' % _kodi_builtin_arg(url))], **common)


def browse_kodi_path(route='', title='', background='', page='0'):
    """Another add-on's folder shown inside MegaNexus (a page at a time); Kodi opens it itself when it cannot be read."""
    route = str(route or '').strip()
    if not route.startswith('plugin://'):
        error(tr('Invalid plugin route'))
        return end_dir(content='files')
    rows = _read_plugin_folder(route)
    if not rows:
        try:
            xbmc.executebuiltin('Container.Update(%s,replace)' % _kodi_builtin_arg(route))
            return
        except Exception:
            error(tr('Path is empty or unreadable'))
            return end_dir(content='files')
    number, _size, shown, more = _page_of(rows, page)
    if background:
        xbmcgui.Window(WINDOW_ID).setProperty('fanart', background)
    for row in shown:
        _add_kodi_path_row(row, background)
    if more and not _no_pages():
        add_item(tr('More'), build_url(action='kodi_route_browse', route=route, title=title or route, background=background,
                                       page=str(number + 1)),
                 info={'title': tr('More'), 'plot': tr('Load more items from this path')}, art=root_art('catalogs'))
    end_dir(content=_content_of_rows(rows), cache=False)


_LIST_SOURCE = 'virtual.collection.trakt'        # the metadata choice list rows (Trakt, MDBList, Simkl) share


def _list_row_ids(meta):
    """(canonical id, the ids as the list service names them, our ids); no canonical id without any id."""
    service = dict(meta.get('ids')) if isinstance(meta.get('ids'), dict) else {}
    imdb = str(service.get('imdb') or meta.get('imdb_id') or '').strip()
    tmdb = str(service.get('tmdb') or meta.get('id') or '').strip()
    tvdb = str(service.get('tvdb') or meta.get('tvdb_id') or '').strip()
    service.update(imdb=imdb, tmdb=tmdb, tvdb=tvdb)
    imdb = imdb if not imdb or imdb.startswith('tt') else 'tt' + imdb
    canonical = imdb or ('tmdb:' + tmdb if tmdb else ('tvdb:' + tvdb if tvdb else ''))
    return canonical, service, {'imdb_id': imdb, 'tmdb_id': tmdb, 'tvdb_id': tvdb}


def _list_row_art(shown, found, explicit, background):
    """The row's pictures: the chosen metadata source's, else also the list service's."""
    own = {} if explicit else found
    poster = shown.get('poster') or own.get('poster') or ('' if explicit else root_art('catalogs').get('poster') or '')
    art = {'thumb': poster, 'poster': poster,
           'fanart': (shown.get('background') or shown.get('fanart') or shown.get('landscape') or own.get('fanart')
                      or own.get('landscape') or background or addon_fanart()),
           'landscape': (shown.get('landscape') or shown.get('fanart') or '') if explicit else
                        (shown.get('landscape') or own.get('landscape') or own.get('fanart') or ''),
           'clearlogo': shown.get('clearlogo') or own.get('clearlogo') or ''}
    if art['clearlogo']:
        art.update({'logo': art['clearlogo'], 'tvshow.clearlogo': art['clearlogo']})
    return art


def _add_list_row(meta, background, chosen, explicit, force_remote):
    """One list row; (its type, its backdrop) or None when it carries no id."""
    show = str(meta.get('_type') or meta.get('mediatype') or '').lower() in ('show', 'series', 'tv', 'anime')
    kind = 'series' if show else 'movie'
    canonical, service_ids, ids = _list_row_ids(meta)
    if not canonical:
        return None
    name, year = meta.get('title') or '', meta.get('release_year') or meta.get('year') or ''
    found = {} if chosen else dict(_trakt_pictures(service_ids, kind, title=name, year=year, meta=meta,
                                                   force_remote=force_remote, allow_direct=bool(force_remote)) or {})
    if not found.get('poster') and str(meta.get('poster') or '').strip():
        found['poster'] = str(meta['poster']).strip()
    if not found.get('poster') and ids['imdb_id']:
        found['poster'] = _metahub('poster', ids['imdb_id'])
    shown = _virtual_meta_override(_LIST_SOURCE, kind, {
        'id': canonical, 'name': name, 'title': name, 'year': year, 'poster': found.get('poster') or '',
        'background': found.get('fanart') or found.get('landscape') or '',
        'fanart': found.get('fanart') or found.get('landscape') or '',
        'landscape': found.get('landscape') or found.get('fanart') or '',
        'clearlogo': found.get('clearlogo') or '', 'logo': found.get('clearlogo') or ''})
    art = _list_row_art(shown, found, explicit, background)
    label = str(shown.get('name') or shown.get('title') or name).strip() or name
    info = {'plot': meta.get('overview') or meta.get('description') or ''}
    try:
        if year:
            info['year'] = int(year)
    except Exception:
        pass
    try:
        info.update(_info_of(shown) or {})
    except Exception:
        pass
    info.update(title=label, sorttitle=label, mediatype='tvshow' if show else 'movie')
    try:
        _meta_keep(kind, canonical, shown, source_provider_id=_LIST_SOURCE)
    except Exception:
        pass
    path, is_folder = _item_click_url(media_type=kind, canonical_id=canonical, title=label, source_provider_id=_LIST_SOURCE,
                                      ui_seed=art, **ids)
    menu = ([(tr('Change metadata add-on'), 'RunPlugin(%s)' % build_url(action='meta_pick_target', target_key=_LIST_SOURCE,
                                                                          title=tr('Collection • Trakt items')))]
            + _source_choice_list(media_type=kind, canonical_id=canonical, title=label, source_provider_id=_LIST_SOURCE)
            + _player_choices(media_type=kind, canonical_id=canonical, title=label, source_provider_id=_LIST_SOURCE, **ids))
    add_item(label, path, is_folder=is_folder, info=info, art=art, ids=ids, context_menu=menu)
    return kind, art['fanart']


def _show_id_rows(rows, more_url='', title='', background='', media_filter='auto', force_remote=False):
    """Rows of a Trakt / MDBList / Simkl list (titles known by their ids) as a Kodi list."""
    if not rows:
        error(tr('The list is empty or unavailable'))
        return end_dir()
    home = xbmcgui.Window(WINDOW_ID)
    if background:
        home.setProperty('fanart', background)
    explicit = _meta_source_chosen(_LIST_SOURCE)
    chosen = explicit and _target_meta_source_id(_LIST_SOURCE) not in ('tmdb_helper',)
    kinds, backdrop = set(), background or ''
    for meta in rows:
        added = _add_list_row(meta, background, chosen, explicit, force_remote)
        if added:
            kinds.add(added[0])
            backdrop = backdrop or added[1]
    if more_url and not _no_pages():
        add_item(tr('More'), more_url, info={'title': tr('More'), 'plot': tr('Load more items from the list')},
                 art=root_art('catalogs'))
    if backdrop:
        home.setProperty('fanart', backdrop)
    end_dir(content='tvshows' if kinds == {'series'} else ('movies' if kinds == {'movie'} else 'videos'))




def mdblist_list_rows(list_id, title='', background='', media_filter='auto', cursor='', force_remote=''):
    force_remote = _online_posters_only(force_remote)
    try:
        rows, next_cursor = mdblist.items_by_id(list_id, media_filter=media_filter, cursor=cursor, limit=_listing_page_size())
    except Exception as exc:
        error(tr('Failed to read MDBList list: %s') % exc)
        return end_dir()
    more_url = ''
    if next_cursor:
        more_url = build_url(action='mdblist_list_browse_id', list_id=list_id, title=title, background=background, media_filter=media_filter, cursor=next_cursor, **_online_query(force_remote))
    return _show_id_rows(rows, more_url=more_url, title=title, background=background, media_filter=media_filter, force_remote=force_remote)


def mdblist_watchlist_rows(media_filter='auto', cursor='', title='', background='', force_remote=''):
    if not mdblist.configured():
        error(tr('Enter the MDBList API Key in settings first'))
        return end_dir()
    force_remote = _online_posters_only(force_remote)
    try:
        rows, next_cursor = mdblist.watchlist_rows(media_filter=media_filter, cursor=cursor, limit=_listing_page_size())
    except Exception as exc:
        error(tr('Could not read the MDBList watchlist: %s') % exc)
        return end_dir()
    more_url = ''
    if next_cursor:
        more_url = build_url(action='mdblist_watchlist_browse', media_filter=media_filter, cursor=next_cursor, title=title, background=background, **_online_query(force_remote))
    return _show_id_rows(rows, more_url=more_url, title=title or tr('MDBList • Watchlist'), background=background, media_filter=media_filter, force_remote=force_remote)


def simkl_list_rows(kind='shows', status='watching', media_filter='auto', page='0', title='', background='', force_remote=''):
    if not simkl_api.authorized():
        error(tr('Simkl account is not linked'))
        return end_dir()
    force_remote = _online_posters_only(force_remote)
    try:
        all_rows = simkl_api.all_items(kind, status) or []
    except Exception as exc:
        error(tr('Could not read the Simkl list: %s') % exc)
        return end_dir()
    if media_filter in ('movie', 'movies'):
        all_rows = [r for r in all_rows if (r.get('_type') or '') == 'movie']
    elif media_filter in ('show', 'shows', 'series', 'tv', 'anime'):
        all_rows = [r for r in all_rows if (r.get('_type') or '') == 'show']
    page_num, _page_size_v, visible_rows, has_more = _page_of(all_rows, page)
    more_url = ''
    if has_more:
        more_url = build_url(action='simkl_list_browse', kind=kind, status=status, media_filter=media_filter, page=str(page_num + 1), title=title, background=background, **_online_query(force_remote))
    return _show_id_rows(visible_rows, more_url=more_url, title=title, background=background, media_filter=media_filter, force_remote=force_remote)



def _show_videos_kept(canonical_id, media_type='series', title=''):
    return _nextup_series_videos_cached(
        canonical_id,
        window=xbmcgui.Window(WINDOW_ID),
        prop_prefix=SERIES_PROP_PREFIX,
        provider_order_for_id=_addons_for_id,
        fetch_meta=fetch_meta,
        fast_timeout_value=fast_timeout('meta'),
        item_fallback_art=_fallback_pictures,
        resolve_meta_art=_meta_pictures,
        provider_prefers_native_art=_addon_keeps_pictures,
        media_type=media_type,
        title=title,
    )


def _next_up_rows(limit=40):
    return _nextup_items_cached_logic(
        limit=limit,
        window=xbmcgui.Window(WINDOW_ID),
        trakt_mod=trakt_api,
        playback_store_mod=progress_db,
        series_videos_loader=_show_videos_kept,
        log_prefix='[MegaNexus]',
    )


_NEXT_UP_PICTURE_WAIT = 6.0


def _next_up_row_pictures(row):
    """The row's missing poster / wide picture / logo found and stored with its progress."""
    try:
        art = _row_pictures(row)
        poster, fanart, logo = art.get('poster') or '', art.get('fanart') or '', art.get('clearlogo') or ''
        wide = _next_up_wide_picture(row, art) or fanart
        if poster and poster != _favorite_fallback_poster(row.get('media_type') or 'series'):
            row['poster'] = poster
        if wide:
            row.update(background=wide, landscape=wide, banner=wide)
        if logo:
            row['clearlogo'] = logo
        if poster or fanart or logo:
            progress_db.update_art((row.get('media_type') or 'series').lower(), row.get('canonical_id') or '',
                                      row.get('video_id') or row.get('canonical_id') or '', poster=poster,
                                      background=wide, clearlogo=logo)
    except Exception:
        pass


def _fill_next_up_pictures(rows):
    """Rows without all three pictures get them, six at a time; the list waits at most six
    seconds and late rows finish in the background."""
    missing = [row for row in rows if not (row.get('poster') and row.get('background') and row.get('clearlogo'))]
    if not missing:
        return
    try:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        pool = ThreadPoolExecutor(max_workers=6)
        try:
            jobs = [pool.submit(_next_up_row_pictures, row) for row in missing]
            ready = 0
            try:
                for _job in as_completed(jobs, timeout=_NEXT_UP_PICTURE_WAIT):
                    ready += 1
            except Exception:
                pass
            if ready < len(jobs):
                xbmc.log('[MegaNexus] inline art fill: %d/%d rows within %.0fs budget; the rest continue in the background'
                         % (ready, len(jobs), _NEXT_UP_PICTURE_WAIT), xbmc.LOGINFO)
        finally:
            pool.shutdown(wait=False)
        try:
            _nextup_invalidate_cache(xbmcgui.Window(WINDOW_ID))
        except Exception:
            pass
    except Exception as exc:
        xbmc.log('[MegaNexus] nextup inline art fill failed: %s' % exc, xbmc.LOGDEBUG)


def _add_next_up_row(row):
    show = row.get('title') or ''
    season, number = int(row.get('season') or 0), int(row.get('episode') or 0)
    if season <= 0 or number <= 0:
        return
    label = '%s — S%02dE%02d%s' % (show, season, number, (' — %s' % row['episode_title']) if row.get('episode_title') else '')
    canonical = row.get('canonical_id') or ''
    video_id = row.get('video_id') or canonical
    name = show or canonical
    ids = _merge_seed_ids(extract_ids({'id': canonical}), _get_tmdbh_seed_ids(canonical))
    id_args = dict((key, ids.get(key) or '') for key in ('tmdb_id', 'imdb_id', 'tvdb_id'))
    path, is_folder = _item_click_url(media_type='series', canonical_id=canonical, video_id=video_id, season=season,
                                      episode=number, title=name,
                                      ui_seed={'poster': row.get('poster') or '', 'fanart': row.get('background') or '',
                                               'clearlogo': row.get('clearlogo') or ''}, **id_args)
    art = _pictures_dict(row.get('poster') or '', row.get('background') or '', row.get('clearlogo') or '', 'series')
    wide = _next_up_wide_picture(row, art, ids=ids)
    if not wide:
        spare = root_art('nextup') or {}
        wide = spare.get('landscape') or spare.get('fanart') or addon_fanart() or ''
    if wide:
        art = _fill_wide_pictures(art, wide)
    kind = row.get('media_type') or 'series'
    menu = (_source_choice_list(media_type=kind, canonical_id=canonical, title=name, season=season, episode=number,
                                video_id=video_id, preferred_provider_name=row.get('provider_name') or '')
            + _player_choices(media_type=kind, canonical_id=canonical, title=name, season=season, episode=number,
                              video_id=video_id, **id_args)
            + [('Open series info', 'Container.Update(%s)' % build_url(action='series_meta', media_type='series',
                                                                       canonical_id=canonical, title=name)),
               ('Add to favorites', 'RunPlugin(%s)' % build_url(action='fav_add', media_type='series',
                                                                canonical_id=canonical, title=name,
                                                                poster=art.get('poster') or '',
                                                                background=art.get('fanart') or '',
                                                                clearlogo=art.get('clearlogo') or ''))])
    _continue_row_look(art)
    add_item(label, path, is_folder=is_folder, art=art, context_menu=menu,
             info={'title': label, 'tvshowtitle': show, 'season': season, 'episode': number, 'mediatype': 'episode',
                   'plot': row.get('plot') or '', 'playcount': 0},
             properties={} if is_folder else {'IsPlayable': 'true'})


def nextup():
    """Next Up: the next episode of every show in progress."""
    rows = _next_up_rows(limit=60)
    if not rows:
        notify(tr('No upcoming episodes yet. Watch an episode from any show and it will appear here.'))
        return end_dir(content='episodes', cache=False)
    _fill_next_up_pictures(rows)
    for row in rows:
        try:
            _add_next_up_row(row)
        except Exception as exc:
            xbmc.log('[MegaNexus] nextup row failed: %s' % exc, xbmc.LOGWARNING)
    end_dir(content='episodes', cache=False)



def _favorite_fallback_poster(media_type='movie'):
    media_type = (media_type or 'movie').lower()
    return media_path('default_series_poster.png' if media_type in ('series', 'anime', 'tv', 'show') else 'default_movie_poster.png')


def _pictures_from_helper_db(ids, media_type):
    tmdb_id = str(ids.get('tmdb_id') or '').strip()
    imdb_id = str(ids.get('imdb_id') or '').strip()
    if not tmdb_id and not imdb_id:
        return {}
    try:
        return _tmdb_art_db.stored_pictures(
            tmdb_id=tmdb_id,
            imdb_id=imdb_id,
            media_type='tv' if media_type in ('series', 'anime', 'show', 'tv') else 'movie',
        ) or {}
    except Exception:
        return {}


def _poster_has_addon_token(value):
    text = str(value or '').lower()
    if not text:
        return False
    if 'x-plex-token=' in text:
        return True
    if '/photo/:/transcode' in text or '/library/metadata/' in text:
        return True
    # Emby auth token query
    if 'api_key=' in text and ('/items/' in text or '/emby/' in text):
        return True
    return False


_PICTURE_KEYS = (('poster', ('poster',)), ('fanart', ('fanart', 'landscape')), ('clearlogo', ('clearlogo',)))


def _fill_three(have, found):
    """Empty slots of (poster, fanart, clearlogo) filled from a picture bundle."""
    found = found or {}
    return tuple(value or _wrap_tokenized_url(next((found[name] for name in names if found.get(name)), '') or '')
                 for value, (_slot, names) in zip(have, _PICTURE_KEYS))


def _canonical_seed_ids(canonical):
    lower = (canonical or '').lower()
    seed = {'id': canonical}
    if lower.startswith('tmdb:'):
        seed['tmdb_id'] = canonical.split(':', 1)[-1].strip()
    elif lower.startswith('tvdb:'):
        seed['tvdb_id'] = canonical.split(':', 1)[-1].strip()
    elif lower.startswith('tt'):
        seed['imdb_id'] = canonical.strip()
    try:
        return extract_ids(seed)
    except Exception:
        return {}


def _chosen_source_pictures(target, kind, canonical, title, year, have, ids):
    """(pictures, final): the metadata source chosen for the row's section; final when that choice
    is explicit (its pictures stand even when some are missing)."""
    try:
        source = _target_meta_source_id(target)
    except Exception:
        source = 'auto'
    if source == 'native':
        return have, False
    poster, fanart, logo = have
    seed = {'id': canonical, 'name': title, 'title': title, 'year': year, 'releaseInfo': year, 'poster': poster or '',
            'background': fanart or '', 'fanart': fanart or '', 'landscape': fanart or '', 'clearlogo': logo or '',
            'logo': logo or ''}
    seed.update((key, ids[key]) for key in ('tmdb_id', 'imdb_id', 'tvdb_id') if ids.get(key))
    try:
        picked = _virtual_meta_override(target, kind, seed) or seed
    except Exception:
        picked = seed
    chosen = tuple(_wrap_tokenized_url(next((picked[name] for name in names if picked.get(name)), '') or '')
                   for names in (('poster', 'thumb', 'thumbnail'), ('background', 'fanart', 'landscape', 'banner'),
                                 ('clearlogo', 'logo')))
    if source not in ('', 'auto'):
        return chosen, True
    return tuple(own or other for own, other in zip(have, chosen)), False


def _row_pictures(row):
    """A progress / list row's poster, wide picture and logo: its own, the section's chosen metadata
    source, then TMDb Helper's database, Trakt and TMDB until all three are found."""
    row = row or {}
    kind = (row.get('media_type') or 'movie').lower()
    canonical = row.get('canonical_id') or ''
    title = row.get('title') or canonical
    try:
        year = int(row.get('year') or 0)
    except Exception:
        year = 0
    year = str(year) if year > 0 else ''
    have = (_wrap_tokenized_url(row.get('poster') or ''),
            _wrap_tokenized_url(row.get('background') or row.get('fanart') or row.get('landscape') or ''),
            _wrap_tokenized_url(row.get('clearlogo') or row.get('logo') or ''))
    target = str(row.get('_meganexus_virtual_meta_target') or '').strip()
    if not target and all(have):
        return _pictures_dict(*(have + (kind,)))
    ids = _canonical_seed_ids(canonical)
    if target:
        have, final = _chosen_source_pictures(target, kind, canonical, title, year, have, ids)
        if final or all(have):
            return _pictures_dict(*(have + (kind,)))
    lookups = (lambda: _pictures_from_helper_db(ids, kind),
               lambda: _trakt_pictures(ids, kind, title=title, year=year, force_remote=True),
               lambda: _tmdb_api.art_for(tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                                         media_type='tv' if kind in ('series', 'anime', 'show', 'tv') else 'movie',
                                         title=title, year=year))
    for place, lookup in enumerate(lookups):
        if all(have):
            break
        if place == 0:
            found = lookup() or {}
        else:
            try:
                found = lookup() or {}
            except Exception:
                found = {}
        have = _fill_three(have, found)
    return _pictures_dict(*(have + (kind,)))



def _art_values_same(a, b):
    try:
        aa = str(a or '').strip()
        bb = str(b or '').strip()
        if not aa or not bb:
            return False
        return aa == bb
    except Exception:
        return False


def _next_up_wide_picture(row, resolved_art=None, ids=None):
    """The episode row's wide picture (never its poster): the row's own, the resolved ones, then
    TMDb Helper's database, then TMDB - asked only while nothing was found."""
    row, resolved_art = row or {}, resolved_art or {}
    poster = _wrap_tokenized_url(row.get('poster') or resolved_art.get('poster') or '')

    def first(values):
        for value in values:
            value = _wrap_tokenized_url(value or '')
            if value and not _art_values_same(value, poster):
                return value
        return ''
    found = first([row.get(key) for key in ('banner', 'landscape', 'background', 'fanart', 'backdrop')]
                  + [resolved_art.get(key) for key in ('banner', 'landscape', 'fanart')])
    if found:
        return found
    kind = (row.get('media_type') or 'series').lower()
    ids = ids or _canonical_seed_ids(str(row.get('canonical_id') or ''))
    try:
        found = first((lambda b: (b.get('landscape'), b.get('fanart')))(_pictures_from_helper_db(ids or {}, kind) or {}))
    except Exception:
        found = ''
    if found:
        return found
    try:
        year = int(row.get('year') or 0)
    except Exception:
        year = 0
    try:
        direct = _tmdb_api.art_for(tmdb_id=(ids or {}).get('tmdb_id') or '', imdb_id=(ids or {}).get('imdb_id') or '',
                                   media_type='tv' if kind in ('series', 'anime', 'show', 'tv') else 'movie',
                                   title=row.get('title') or row.get('canonical_id') or '',
                                   year=str(year) if year > 0 else '') or {}
        return first((direct.get('landscape'), direct.get('fanart')))
    except Exception:
        return ''


def _fill_wide_pictures(art, wide):
    art = dict(art or {})
    wide = _wrap_tokenized_url(wide or '')
    if not wide:
        return art
    for key in (
        'fanart', 'landscape', 'banner',
        'tvshow.fanart', 'tvshow.landscape', 'tvshow.banner',
        'episode.fanart', 'episode.landscape', 'episode.banner',
    ):
        art[key] = wide
    return art

_SHOW_PICTURE_SLOTS = (('tvshow.poster', 'poster'), ('tvshow.thumb', 'poster'), ('tvshow.fanart', 'fanart'),
                       ('tvshow.landscape', 'landscape'), ('tvshow.clearlogo', 'clearlogo'))


def _pictures_dict(poster, fanart, clearlogo, media_type='movie'):
    """Kodi's picture slots from a poster, backdrop and logo (fallbacks for the missing; a show's slots too)."""
    poster = _wrap_tokenized_url(poster or '') or _favorite_fallback_poster(media_type)
    fanart = _wrap_tokenized_url(fanart or '') or poster or addon_fanart()
    wide = fanart or poster or ''
    logo = _wrap_tokenized_url(clearlogo or '')
    art = dict(thumb=poster, poster=poster, icon=poster, thumbnail=poster, fanart=fanart, landscape=wide, banner=wide,
               clearlogo=logo, logo=logo or '', clearart=logo or '')
    if media_type in ('series', 'anime', 'show', 'tv'):
        base = dict(poster=poster, fanart=fanart, landscape=wide, clearlogo=logo or '')
        art.update((slot, base[key]) for slot, key in _SHOW_PICTURE_SLOTS)
    return art

def _favorite_pictures(row):
    """A favorite's pictures; ones it lacked are saved with it (unless a metadata source decides them)."""
    row = row or {}
    ref = _favorite_ref(row)
    art = _row_pictures(dict(row, _meganexus_virtual_meta_target=ref))
    try:
        source = _target_meta_source_id(ref)
    except Exception:
        source = 'auto'
    if source not in ('', 'auto', 'native'):
        return art
    new = dict((slot, art.get(key) or '') for slot, key in (('poster', 'poster'), ('background', 'fanart'),
                                                            ('clearlogo', 'clearlogo')) if not row.get(slot))
    if any(new.values()):
        try:
            library_titles.add((row.get('media_type') or 'movie').lower(), row.get('canonical_id') or '',
                                row.get('title') or '', poster=new.get('poster', ''), background=new.get('background', ''),
                                clearlogo=new.get('clearlogo', ''), year=int(row.get('year') or 0),
                                plot=row.get('plot') or '', source=row.get('source') or 'local')
        except Exception:
            pass
    return art


def _refresh_favorites_view():
    try:
        current = xbmc.getInfoLabel('Container.FolderPath') or ''
        if 'plugin.video.meganexus' in current and 'action=favorites' in current:
            xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def _refresh_trakt_copy():
    """Back-compat alias — the mirror now merges every linked service."""
    _refresh_list_copy()


def _refresh_list_copy():
    try:
        library_titles.refresh_list_copy(include_trakt=True)
    except Exception as exc:
        xbmc.log('[MegaNexus] watchlist mirror refresh failed: %s' % exc, xbmc.LOGDEBUG)

_FAVORITE_PICTURE_WAIT = 6.0


_SHOWS = ('series', 'anime', 'tv', 'show')


def _start_favorites_copy(home):
    """Once a session, the Trakt (and other list) favorites copy is refreshed in the background;
    the visible list refreshes when it is done."""
    if home.getProperty('meganexus.fav_mirror_done') or home.getProperty('meganexus.fav_mirror_syncing'):
        return
    def work():
        try:
            _refresh_trakt_copy()
        finally:
            try:
                home.setProperty('meganexus.fav_mirror_done', '1')
                home.clearProperty('meganexus.fav_mirror_syncing')
            except Exception:
                pass
            _refresh_favorites_view()
    try:
        home.setProperty('meganexus.fav_mirror_syncing', '1')
        if not _submit_optional(work, key='favorites-external-mirror'):
            home.clearProperty('meganexus.fav_mirror_syncing')
    except Exception:
        try:
            home.clearProperty('meganexus.fav_mirror_syncing')
        except Exception:
            pass


def _favorites_pictures(rows):
    """Each row's pictures, eight at a time; rows not done within six seconds keep their stored ones."""
    pictures = {}
    for spot, row in enumerate(rows):
        row = row or {}
        wide = row.get('background') or row.get('fanart') or ''
        pictures[spot] = {'poster': row.get('poster') or '', 'fanart': wide, 'background': wide,
                          'clearlogo': row.get('clearlogo') or '', '_seeded': True}

    def one(spot, row):
        try:
            return spot, _favorite_pictures(row)
        except Exception:
            return spot, (_favorite_pictures({}) if row else {})
    try:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        pool = ThreadPoolExecutor(max_workers=8)
        try:
            jobs = [pool.submit(one, spot, row) for spot, row in enumerate(rows)]
            ready = 0
            try:
                for job in as_completed(jobs, timeout=_FAVORITE_PICTURE_WAIT):
                    try:
                        spot, art = job.result()
                    except Exception:
                        continue
                    if art:
                        pictures[spot] = art
                    ready += 1
            except Exception:
                pass
            if ready < len(jobs):
                xbmc.log('[MegaNexus] favorites art: %d/%d rows within %.0fs budget; the rest keep their stored art this pass'
                         % (ready, len(jobs), _FAVORITE_PICTURE_WAIT), xbmc.LOGINFO)
        finally:
            pool.shutdown(wait=False)
    except Exception as exc:
        xbmc.log('[MegaNexus] favorites parallel art resolve failed, falling back to serial: %s' % exc, xbmc.LOGWARNING)
        for spot, row in enumerate(rows):
            try:
                pictures[spot] = _favorite_pictures(row)
            except Exception:
                pictures[spot] = {}
    return pictures


def _add_favorite_row(row, art):
    kind = (row.get('media_type') or 'movie').lower()
    canonical = row.get('canonical_id') or ''
    title = row.get('title') or canonical
    year = int(row.get('year') or 0)
    ids = _merge_seed_ids(extract_ids({'id': canonical}), _get_tmdbh_seed_ids(canonical))
    ref = _favorite_ref(row)
    path, is_folder = _item_click_url(media_type=kind, canonical_id=canonical, title=title, tmdb_id=ids.get('tmdb_id') or '',
                                      imdb_id=ids.get('imdb_id') or '', tvdb_id=ids.get('tvdb_id') or '',
                                      source_provider_id=ref, ui_seed=art)
    section = 'Favorites • Series/Anime' if ref.endswith('series') else 'Favorites • Movies'
    menu = ([(tr('Change metadata add-on'), 'RunPlugin(%s)' % build_url(action='meta_pick_target', target_key=ref,
                                                                          title=section))]
            + _source_choice_list(media_type=kind, canonical_id=canonical, title=title, source_provider_id=ref)
            + [('Remove from favorites', 'RunPlugin(%s)' % build_url(action='fav_remove', media_type=kind,
                                                                     canonical_id=canonical))])
    if 'trakt' in (row.get('sources') or []):
        menu.append(('Sync with Trakt now', 'RunPlugin(%s)' % build_url(action='fav_sync_trakt')))
    add_item('%s (%d)' % (title, year) if year > 0 else title, path, is_folder=is_folder, art=art, context_menu=menu,
             is_favorite=True, info={'title': title, 'year': year, 'plot': row.get('plot') or '',
                                     'mediatype': 'tvshow' if kind in _SHOWS else 'movie'})


def favorites():
    """Favorites: ours and the ones kept from Trakt / other lists, with their pictures."""
    _set_render_section('favorites')
    home = xbmcgui.Window(WINDOW_ID)
    _start_favorites_copy(home)
    rows = library_titles.list_favorites(limit=300) or []
    copying = bool(home.getProperty('meganexus.fav_mirror_syncing'))
    if not rows:
        if copying:
            add_item(tr('[COLOR grey]Loading favorites…[/COLOR]'), build_url(action='favorites'), is_folder=False,
                     info={'title': 'Favorites', 'plot': 'Preparing local favorites and the Trakt mirror.'},
                     art=root_art('favorites'))
        else:
            notify(tr('Favorites is empty. Add an item from the context menu using "Add to favorites".'))
        return end_dir(content='videos')
    kinds = set('show' if (r.get('media_type') or '').lower() in _SHOWS else (r.get('media_type') or '').lower() for r in rows)
    content = 'movies' if 'movie' in kinds and 'show' not in kinds else ('tvshows' if 'show' in kinds and 'movie' not in kinds
                                                                         else 'videos')
    if copying:
        add_item(tr('[COLOR grey]Refreshing Trakt favorites sync…[/COLOR]'), build_url(action='favorites'), is_folder=False,
                 info={'title': 'Trakt sync',
                       'plot': 'The local favorites mirror from Trakt is being refreshed in the background.'},
                 art=root_art('trakt'))
    pictures = _favorites_pictures(rows)
    for spot, row in enumerate(rows):
        try:
            _add_favorite_row(row, pictures.get(spot) or _favorite_pictures(row))
        except Exception:
            continue
    end_dir(content=content, cache=False)


def favorite_add(media_type='movie', canonical_id='', title='', poster='', background='', clearlogo='', year='0', plot=''):
    if not canonical_id:
        return
    try:
        library_titles.add(media_type or 'movie', canonical_id, title or canonical_id,
                            poster=poster or '', background=background or '',
                            clearlogo=clearlogo or '', year=int(year or 0), plot=plot or '',
                            source='local')
        notify(tr('Added to favorites'))
    except Exception as exc:
        error(tr('Could not add: %s') % exc)
    xbmc.executebuiltin('Container.Refresh')


def favorite_remove(media_type='', canonical_id=''):
    if not canonical_id:
        return
    try:
        library_titles.remove(media_type or '', canonical_id)
        notify(tr('Removed from favorites'))
    except Exception as exc:
        error(tr('Could not remove: %s') % exc)
    xbmc.executebuiltin('Container.Refresh')


def favorites_to_trakt():
    try:
        _refresh_trakt_copy()
        notify(tr('Favorites synced with Trakt'))
    except Exception as exc:
        error(tr('Sync failed: %s') % exc)
    xbmc.executebuiltin('Container.Refresh')


def _probe_addon(addon):
    """(add-on, milliseconds or None, 'ok' / 'no-url' / 'http-N' / the error's name) for its manifest."""
    url = (addon.get('manifest_url') or '').strip()
    if not url:
        return addon, None, 'no-url'
    started = time.time()
    took = lambda: int((time.time() - started) * 1000)
    try:
        from urllib.request import Request, urlopen
        with urlopen(Request(url, headers={'User-Agent': 'MegaNexus/health-probe'}), timeout=4) as answer:
            code = answer.getcode()
            answer.read(2048)
        return addon, took(), 'ok' if 200 <= code < 400 else 'http-%d' % code
    except Exception as exc:
        return addon, took(), str(exc.__class__.__name__)


def _probe_look(ms, status):
    """(colour, mark, word) of a probe result."""
    if status != 'ok':
        return 'red', '✗', tr('Failed')
    if ms is None or ms < 1000:
        return 'lime', '✓', tr('healthy')
    return ('yellow', '⚠', tr('slow')) if ms < 3000 else ('orange', '⚠', tr('very slow'))


def source_check():
    """Add-on diagnostics: every add-on's manifest asked, failures and the slowest first."""
    addons = addon_registry.list_providers()
    if not addons:
        add_item('[COLOR yellow]%s[/COLOR]' % tr('No add-ons configured'), build_url(action='add_provider'),
                 art=root_art('add'), info={'title': tr('No add-ons configured'), 'plot': tr('Add a Manifest URL first')})
        return end_dir(content='files', cache=False)
    notify(tr('Probing add-ons…'))
    results = [(addon, None, 'exception') if isinstance(answer, Exception) else answer
               for addon, answer in each_parallel(_probe_addon, addons, workers=min(8, len(addons)), timeout=6.0)]
    results.sort(key=lambda r: (0, -(r[1] or 99999)) if r[2] != 'ok' else (1, -(r[1] or 0)))
    healthy = sum(1 for _a, _ms, status in results if status == 'ok')
    slow = sum(1 for _a, ms, status in results if status == 'ok' and ms and ms >= 1000)
    add_item('[COLOR cyan]%s: %d %s · %d %s · %d %s[/COLOR]' % (tr('Summary'), healthy, tr('healthy'), slow, tr('slow'),
                                                              len(results) - healthy, tr('Failed')),
             build_url(action='diagnose_sources'), art=root_art('catalogs'), is_folder=False,
             info={'title': tr('Add-on diagnostics'), 'plot': tr('Press to re-run the probe')})
    for addon, ms, status in results:
        name, addon_id = addon.get('name') or addon.get('id') or '?', addon.get('id', '')
        colour, mark, word = _probe_look(ms, status)
        menu = [(tr('Add-on settings'), 'Container.Update(%s)' % build_url(action='provider_menu', provider_id=addon_id)),
                (tr('Remove this add-on'), 'RunPlugin(%s)' % build_url(action='provider_remove', provider_id=addon_id))]
        plot = '%s\n%s\n%s: %s' % (addon.get('manifest_url') or '', name, tr('Status'),
                                   status if status != 'ok' else tr('Responded in %d ms') % (ms or 0))
        add_item('[COLOR %s]%s  %s[/COLOR]   [COLOR grey]%s · %s[/COLOR]' % (
            colour, mark, name, word, '%d ms' % ms if ms is not None else tr('timed out')),
            build_url(action='provider_menu', provider_id=addon_id), art=root_art('catalogs'),
            info={'title': name, 'plot': plot}, context_menu=menu)
    return end_dir(content='files', cache=False)






def _fresh_call_state():
    global _PENDING_ITEMS
    if _PENDING_ITEMS:
        try:
            xbmc.log('[MegaNexus] dropping %d stale buffered item(s) from a previous '
                     'invocation (reuselanguageinvoker warm VM)' % len(_PENDING_ITEMS),
                     xbmc.LOGWARNING)
        except Exception:
            pass
    _PENDING_ITEMS = []
    global HANDLE
    try:
        from . import hub_base as _ctx_mod
        HANDLE = _ctx_mod.refresh_invocation()
    except Exception:
        try:
            HANDLE = int(sys.argv[1])
        except Exception:
            HANDLE = -1
    try:
        from . import kodi_rows as _ui_mod
        _ui_mod.HANDLE = HANDLE
    except Exception:
        pass


def run():
    _fresh_call_state()
    try:
        return _dispatch()
    except Exception as _exc:
        try:
            import traceback as _tb
            _trace = _tb.format_exc()
            xbmc.log('[MegaNexus] DISPATCHER ERROR: %s\n%s' % (_exc, _trace),
                     xbmc.LOGERROR)
        except Exception:
            _trace = str(_exc)
        try:
            _action_for_dialog = ''
            try:
                _action_for_dialog = dict(parse_qsl(sys.argv[2].lstrip('?'))).get('action', '')
            except Exception:
                pass
            xbmcgui.Dialog().textviewer(
                tr('MegaNexus — unexpected error'),
                ('Action: %s\nArgv: %s\n\nError:\n%s\n\n%s') % (
                    _action_for_dialog or '?',
                    sys.argv[2] if len(sys.argv) > 2 else '?',
                    str(_exc),
                    _trace,
                ),
            )
        except Exception:
            pass
        return


def _source_list_ref(canonical_id, season, episode):
    def _n(v):
        t = str(v).strip() if v is not None else ''
        return str(int(t)) if t.isdigit() else t
    return '%s|%s|%s' % (_n(canonical_id), _n(season), _n(episode))


def _row_subline(e):
    """A source's second line: add-on · site · size · quality."""
    addon = str(e.get('provider_name_raw') or e.get('addon') or '').strip()
    site = str(e.get('source_site') or '').strip()
    size = str(e.get('size_label') or '').strip()
    parts = [addon, site if site.lower() != addon.lower() else '', size if size != '--' else '',
             str(e.get('quality') or '').strip()]
    return ' · '.join(part for part in parts if part)


def _store_source_list(canonical_id, season, episode, entries, poster=''):
    rows = []
    for e in entries:
        k = e.get('stream_key')
        if not k:
            continue
        rows.append({'k': k,
                     'l': e.get('name') or e.get('stream_title') or '?',
                     'l2': _row_subline(e)})
    payload = {
        'item': _source_list_ref(canonical_id, season, episode),
        'poster': poster or '',
        'rows': rows,
        'ts': int(time.time()),
    }
    data = json.dumps(payload)
    xbmcgui.Window(WINDOW_ID).setProperty('meganexus.last_streams', data)
    try:
        keyed_cache.update('source_index', payload['item'], payload)
    except Exception:
        pass


_SOURCE_SWITCH_HANDOFF_PROP = 'meganexus.source_switch_handoff.v2'


def _switch_write(payload):
    try:
        xbmcgui.Window(10000).setProperty(
            _SOURCE_SWITCH_HANDOFF_PROP,
            json.dumps(dict(payload or {}), separators=(',', ':')),
        )
        return True
    except Exception:
        return False


def _switch_read():
    """The source-switch note, while it is valid (an expired one is removed)."""
    home = xbmcgui.Window(10000)
    try:
        raw = home.getProperty(_SOURCE_SWITCH_HANDOFF_PROP) or ''
        note = json.loads(raw) if raw else {}
        if not isinstance(note, dict):
            return {}
        until = float(note.get('expires_at') or 0.0)
        if until and time.time() > until:
            home.clearProperty(_SOURCE_SWITCH_HANDOFF_PROP)
            return {}
        return note
    except Exception:
        return {}


_SWITCH_WAIT = 8.0


def _switch_begin(ctx, position, duration, resume_percent):
    """Leave a note for the next playback that a source switch is under way (where, how long); its token."""
    try:
        import uuid
        token = uuid.uuid4().hex
    except Exception:
        token = '%d' % int(time.time() * 1000)
    now = time.time()
    _switch_write({'token': token, 'old_uid': str((ctx or {}).get('playback_uid') or ''), 'position': float(position or 0.0),
                   'duration': float(duration or 0.0), 'resume_percent': float(resume_percent or 0.0), 'created_at': now,
                   'expires_at': now + _SWITCH_WAIT, 'ack': False})
    return token


def _switch_wait(token, player, timeout_ms=3200):
    deadline = time.time() + max(0.5, float(timeout_ms or 0) / 1000.0)
    inactive_since = 0.0
    while time.time() < deadline:
        data = _switch_read()
        if data.get('token') == token and data.get('ack'):
            return True
        try:
            active = bool(player.isPlaying())
        except Exception:
            active = False
        if not active:
            if not inactive_since:
                inactive_since = time.time()
            if time.time() - inactive_since >= 0.75:
                return False
        else:
            inactive_since = 0.0
        xbmc.sleep(100)
    return False

def _stop_player_for_source_switch(player):
    try:
        if player.isPlaying():
            player.stop()
            xbmc.sleep(250)
    except Exception:
        pass


def _kodi_rpc(method, params=None):
    """Kodi's JSON-RPC answer ('result'), or None."""
    request = dict({'jsonrpc': '2.0', 'id': 1, 'method': method}, **({} if params is None else {'params': params}))
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps(request, separators=(',', ':'))) or '{}')
    except Exception:
        return None
    return answer.get('result') if isinstance(answer, dict) else None


def _start_other_source(stream_key, resume_seconds='', resume_percent='', fallback_keys=None, subtitle_path='', subtitle_enabled=None, subtitle_name=''):
    """Play another source through our own play route (where the old one was, keeping its subtitle)."""
    params = {'action': 'play', 'stream_key': str(stream_key or '')}
    params.update((key, str(value)) for key, value in (('resume_seconds', resume_seconds), ('resume_percent', resume_percent))
                  if _has_number(value))
    if subtitle_path:
        params.update(switch_subtitle_path=str(subtitle_path), switch_subtitle_enabled='0' if subtitle_enabled is False else '1')
        if subtitle_name:
            params['switch_subtitle_name'] = str(subtitle_name)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.meganexus/?%s)' % urlencode(params))
    return True


def _playing_position(player):
    """(playing, position, length, percent) of what plays now."""
    try:
        if not player.isPlaying():
            return False, 0.0, 0.0, 0.0
        position = float(player.getTime() or 0.0)
        try:
            length = float(player.getTotalTime() or 0.0)
        except Exception:
            length = 0.0
    except Exception:
        return False, 0.0, 0.0, 0.0
    percent = max(0.0, min(100.0, position / length * 100.0)) if length > 1.0 and position > 1.0 else 0.0
    return True, position, length, percent


def _keep_switch_point(ctx, position, length, percent, subtitle):
    """The playback session remembers where it was (and its subtitle) before the source changes."""
    try:
        from .player_session import save_session
        kept = dict(ctx, resume_seconds=float(position), source_switch_pending=True,
                    source_switch_captured_at=int(time.time()))
        if length > 1.0:
            kept.update(duration=float(length), resume_percent=float(percent))
        kept.update(subtitle or {})
        save_session(kept)
        _play_note('source-switch-captured', title=kept.get('title') or '', canonical_id=kept.get('canonical_id') or '',
                   position_seconds='%.1f' % position, duration_seconds='%.1f' % length, resume_percent='%.2f' % percent)
        return kept
    except Exception as exc:
        xbmc.log('[MegaNexus] source-switch snapshot failed: %s' % exc, xbmc.LOGWARNING)
        return ctx


def _switch_rows(ctx, playing):
    """The source list of what plays (the window's copy, else the cached one) and its poster."""
    item = _source_list_ref(ctx.get('canonical_id'), ctx.get('season'), ctx.get('episode')) \
        if ctx.get('canonical_id') or ctx.get('video_id') else None
    rows, poster = [], ''
    try:
        raw = xbmcgui.Window(WINDOW_ID).getProperty('meganexus.last_streams')
        data = json.loads(raw) if raw else {}
        listed = [r for r in data.get('rows') or [] if r.get('k')]
        if listed:
            if (item is not None and data.get('item') == item) or (item is None and playing):
                rows = listed
            poster = data.get('poster') or ''
    except Exception:
        rows, poster = [], ''
    if not rows and item is not None:
        try:
            kept = keyed_cache.get('source_index', item) or {}
            if kept.get('item') == item:
                rows = [r for r in kept.get('rows') or [] if r.get('k')]
                poster = kept.get('poster') or poster
        except Exception:
            pass
    return rows, poster or ctx.get('poster') or ''


def _choose_switch_row(rows, poster):
    try:
        items = []
        for row in rows:
            entry = xbmcgui.ListItem(row.get('l') or '?')
            try:
                entry.setLabel2(row.get('l2') or '')
                if poster:
                    entry.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
            except Exception:
                pass
            items.append(entry)
        return xbmcgui.Dialog().select(tr('Switch source'), items, useDetails=True)
    except Exception:
        return xbmcgui.Dialog().select(tr('Switch source'), [row.get('l') or '?' for row in rows])


def change_source():
    """Switch source while playing: the title's source list (the playing one first); the new one
    starts where the old one was, with the same subtitle."""
    try:
        from .player_session import load_session
        ctx = load_session() or {}
    except Exception:
        ctx = {}
    ctx = ctx if isinstance(ctx, dict) else {}
    known = bool(ctx.get('canonical_id') or ctx.get('video_id'))
    player = xbmc.Player()
    playing, position, length, percent = _playing_position(player)
    resume = str(int(position)) if position > 10.0 else ''
    resume_pct = '%.2f' % percent if 1.0 < percent < 95.0 else ''
    subtitle = _subtitle_for_switch(player) if playing else {}
    if playing and position > 1.0:
        ctx = _keep_switch_point(ctx, position, length, percent, subtitle)
    rows, poster = _switch_rows(ctx, playing)
    if rows:
        from .playing.switch_list import current_first
        rows, playing_first = current_first(rows, str(ctx.get('stream_key') or ''))
        choice = _choose_switch_row(rows, poster)
        if choice < 0:
            return
        if playing_first and choice == 0:
            notify(tr('This add-on is already playing'))
            return
        token = _switch_begin(ctx, position, length, percent)
        _stop_player_for_source_switch(player)
        _play_note('source-switch-handoff-ready', title=ctx.get('title') or '', playback_uid=ctx.get('playback_uid') or '',
                   acknowledged=bool(_switch_wait(token, player)))
        return _start_other_source(rows[choice].get('k'), resume_seconds=resume, resume_percent=resume_pct, fallback_keys=[],
                                   subtitle_path=subtitle.get('switch_subtitle_path', ''),
                                   subtitle_enabled=subtitle.get('switch_subtitle_enabled'),
                                   subtitle_name=subtitle.get('switch_subtitle_name', ''))
    if not known:
        notify('Nothing to switch - play something first')
        return
    url = source_list_url_for(ctx, resume_seconds=resume, resume_percent=resume_pct)
    if not url:
        notify('Source picker unavailable for this item')
        return
    token = _switch_begin(ctx, position, length, percent)
    _stop_player_for_source_switch(player)
    _switch_wait(token, player)
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % url)


# The plugin's routes: action -> (handler, its arguments). Arguments before '|' go by position,
# after it by keyword; 'name' is params.get(name) (None when missing), 'name=' defaults to '',
# 'name=x' to 'x', and 'arg:param' passes the route parameter `param` as argument `arg`.
# A handler is a function of this module (looked up when the route runs) or a _route_* one.
EARLY_ROUTES = dict([(action, ('first_run_wizard', '')) for action in (
    'setup_center', 'theme_select', 'integrations_menu', 'sync_accounts_menu', 'providers', 'badge_settings',
    'source_sort_menu')] + [('catalog_all', ('_route_backend_listing', ''))])
_CATALOG = 'provider_id media_type catalog_id label= page=0'
_CW_ITEM = 'media_type= canonical_id= video_id='
ROUTES = {
    'meganexus_collection': ('_route_collection', ''), 'meganexus_install': ('_route_install', ''),
    'meganexus_update_check': ('_route_update_check', ''), 'meganexus_uninstall': ('_route_uninstall', ''),
    'meganexus_play': ('_route_queued_play', ''), 'add_provider': ('add_provider', '| manifest_url='),
    'first_run_wizard': ('first_run_wizard', ''), 'provider_set_position': ('_route_provider_position', ''),
    'diagnose_sources': ('source_check', ''), 'provider_menu': ('addon_menu', 'provider_id'),
    'hub_section': ('section_rows', 'bucket=movies | raw= page=0'), 'hub_search_menu': ('search_menu', '| query='),
    'home_folder_add': ('add_section', ''), 'home_subfolder_add': ('add_sub_section', 'parent='),
    'home_subfolder_remove': ('remove_sub_section', 'bucket='),
    'catalog_pin_target_menu': ('pin_place_menu', '| provider_id= catalog_id= media_type= label='),
    'catalog_pin': ('pin_catalog', '| provider_id= catalog_id= media_type= label= bucket='),
    'catalog_unpin': ('unpin_catalog', '| provider_id= catalog_id= media_type= bucket='),
    'catalog_pin_move': ('move_pin', '| provider_id= catalog_id= media_type= bucket= direction=up'),
    'folder_filters_menu': ('folder_filter_menu', 'bucket=movies'), 'folder_toggle_view': ('switch_folder_layout', 'bucket=movies'),
    'folder_toggle_dedupe': ('switch_folder_merge', 'bucket=movies'),
    'folder_toggle_play_mode': ('switch_folder_click', 'bucket=movies'),
    'folder_refresh': ('refresh_folder', 'bucket=movies'), 'hub_search_folder': ('search_folder', 'bucket=movies'),
    'refresh_provider': ('reload_addon', 'provider_id'), 'remove_provider': ('remove_provider', 'provider_id'),
    'catalog': ('catalog', _CATALOG + ' | genre= year= force_remote='),
    'catalog_extra': ('catalog_extra', _CATALOG + ' | extra_name= extra_value= force_remote='),
    'filters_menu': ('filter_menu', 'provider_id media_type catalog_id force_remote= | return_action= return_bucket='),
    'search': ('search', 'media_type=movie provider_id | query='),
    'emby_menu': ('mediabrowser_menu', ''), 'emby_login': ('emby_login', ''), 'emby_logout': ('emby_logout', ''),
    'emby_library': ('mediabrowser_library', 'key= | title= library_type= start=0 sort='),
    'emby_sort': ('mediabrowser_sort', 'key= | title= library_type= current='), 'emby_continue': ('mediabrowser_continue', ''),
    'emby_children': ('mediabrowser_children', 'key= | title= start=0'), 'emby_play': ('mediabrowser_play', 'item_id= flavor='),
    'plex_menu': ('plex_home', ''), 'plex_login': ('plex_sign_in', ''), 'plex_logout': ('plex_logout', ''),
    'plex_refresh': ('plex_refresh', ''), 'plex_servers': ('plex_server_list', ''), 'plex_server': ('plex_server_rows', 'server_id='),
    'plex_continue': ('plex_continue_rows', 'server_id='),
    'plex_sort': ('plex_sorting', 'server_id= key= | title= library_type= sort='),
    'plex_library': ('plex_library_rows', 'server_id= key= | title= library_type= start=0 sort='),
    'plex_children': ('plex_child_rows', 'server_id= key= | title= start=0'),
    'plex_search': ('plex_find', 'query= media_type='), 'plex_play': ('plex_start', 'server_id= rating_key='),
    'streams': ('_route_streams', ''),
    'series_meta': ('show_meta', 'media_type=series canonical_id= title= | source_provider_id='),
    'item_open': ('open_title', 'media_type=movie canonical_id= title= | tmdb_id= imdb_id= tvdb_id= source_provider_id='),
    'play_item': ('play_item', '| media_type=movie canonical_id= title= video_id= season= episode= resume_seconds=0 '
                               'resume_percent= preferred_provider_name= tmdb_id= imdb_id= tvdb_id= source_provider_id= '
                               'source_mode= ui_poster= ui_fanart= ui_clearlogo= ui_seed_key='),
    'subtitle_addons': ('_kodi_subtitle_search', ''), 'switch_source': ('change_source', ''),
    'season': ('season', 'canonical_id= season=1 title= media_type='),
    'episode_streams': ('_route_episode_streams', ''),
    'continue': ('continue_rows', '| page=0'),
    'cw_resume': ('continue_resume', '| ' + _CW_ITEM + ' season= episode= title= position=0 resume_percent= provider_name= direct=0 '
                                'source_provider_id= ui_poster= ui_fanart= ui_clearlogo= studio= ui_seed_key='),
    'cw_play_from_start': ('continue_from_start', '| ' + _CW_ITEM + ' season= episode= title= provider_name= source_provider_id='),
    'cw_remove': ('continue_remove', '| ' + _CW_ITEM), 'cw_mark_watched': ('continue_watched', '| ' + _CW_ITEM),
    'kodi_route_browse': ('browse_kodi_path', '| route= title= background= page=0'),
    'trakt_menu': ('trakt_menu', ''), 'simkl_menu': ('simkl_menu', ''), 'simkl_lists_menu': ('simkl_list_menu', ''),
    'simkl_list_browse': ('simkl_list_rows', '| kind=shows status=watching media_filter=auto page=0 title= background= '
                                               'force_remote='),
    'mdblist_menu': ('mdblist_home', ''), 'mdblist_set_key': ('mdblist_key_entry', ''),
    'mdblist_my_lists': ('mdblist_own_lists', ''),
    'mdblist_watchlist_browse': ('mdblist_watchlist_rows', '| media_filter=auto cursor= title= background= force_remote='),
    'mdblist_list_browse_id': ('mdblist_list_rows', '| list_id= title= background= media_filter=auto cursor= force_remote='),
    'media_libraries_menu': ('libraries_menu', ''), 'nuvio_sync_menu': ('nuvio_cloud_menu', ''),
    'stremio_repair_library': ('stremio_repair_library', ''), 'stremio_sync_menu': ('stremio_cloud_menu', ''),
    'account_sync_now': ('_route_account_sync', ''),
    'nuvio_login': ('_route_cloud', ''), 'stremio_login': ('_route_cloud', ''),
    'nuvio_logout': ('_route_cloud', ''), 'stremio_logout': ('_route_cloud', ''),
    'meganexus_qr_login': ('_route_cloud', ''), 'stremio_qr_login': ('_route_cloud', ''),
    'nuvio_sync_import': ('nuvio_cloud_import', ''), 'open_settings': ('open_settings_action', ''),
    'badges_url': ('badges_url_action', ''), 'sync_options': ('sync_options_action', ''),
    'config_export': ('export_settings', ''), 'config_import': ('import_settings', ''),
    'meta_sources_menu': ('meta_source_menu', ''), 'meta_pick_for_provider': ('meta_choice_for_addon', '| provider_id='),
    'meta_pick_target': ('_meta_choice_for', 'target_key= title='), 'meta_reset_all': ('meta_reset_all', ''),
    'trakt_auth': ('trakt_auth', ''), 'simkl_auth': ('simkl_auth', ''), 'simkl_logout': ('simkl_logout', ''),
    'home_xml': ('home_xml', ''), 'simkl_sync_now': ('simkl_sync_round', ''), 'simkl_import': ('simkl_import', ''),
    'trakt_logout': ('trakt_logout', ''), 'trakt_import': ('trakt_take', ''),
    'choose_player': ('pick_player', '| media_type=movie canonical_id= title= tmdb_id= imdb_id= tvdb_id= season= episode= '
                                       'video_id= source_provider_id='),
    'tmdb_player': ('helper_player', '| video_type=movie tmdb_id= imdb_id= tvdb_id= title= year= showname= season= episode= '
                                   'poster= fanart= resume_seconds= resume_percent= resume_duration= '
                                   'resume_updated_at='),
    'tmdbh_install': ('helper_install', ''), 'tmdbh_uninstall': ('tmdbh_uninstall', ''),
    'apply_performance_preset': ('use_speed_setup', ''),
    'apply_recommended_preset': ('use_suggested_setup', ''),
    'play': ('_route_play', ''), 'nextup': ('nextup', ''), 'favorites': ('favorites', ''),
    'fav_add': ('favorite_add', '| media_type=movie canonical_id= title= poster= background= clearlogo= year=0 plot='),
    'fav_remove': ('favorite_remove', '| media_type= canonical_id='), 'fav_sync_trakt': ('favorites_to_trakt', ''),
}
_ROUTE_ARGUMENTS = {}


def _arguments(spec, params):
    """(positional, keyword) arguments of a route spec, from the route's parameters."""
    if spec not in _ROUTE_ARGUMENTS:
        before, _bar, after = spec.partition('|')
        _ROUTE_ARGUMENTS[spec] = ([tuple(_argument(word)) for word in before.split()],
                                  [tuple(_argument(word)) for word in after.split()])
    position, keywords = _ROUTE_ARGUMENTS[spec]
    return ([params.get(name, default) for _arg, name, default in position],
            dict((arg, params.get(name, default)) for arg, name, default in keywords))


def _argument(word):
    """'name' -> (name, name, None); 'name=x' -> (name, name, 'x'); 'arg:name=x' -> (arg, name, 'x')."""
    name, equals, default = word.partition('=')
    arg, _colon, source = name.partition(':')
    return arg, source or arg, default if equals else None


def _run_route(route, params):
    handler, spec = route
    call = globals()[handler]
    if handler.startswith('_route_'):
        return call(params)
    position, keywords = _arguments(spec, params)
    return call(*position, **keywords)


def _route_backend_listing(params):
    from .backend_listing import render
    return render(params)


def _route_collection(params):
    from .collections_home import render_native
    return render_native(params.get('collection_id', ''), params.get('media_type', ''))


def _route_install(params):
    from .frontend_bridge import open_home
    return open_home(settings=True, repair=True)


def _route_update_check(params):
    from .updater import interactive_check
    return interactive_check()


def _route_uninstall(params):
    from .meganexus_uninstall import prepare
    xbmc.executebuiltin(prepare())


def _route_queued_play(params):
    from .backend_api import play_queued
    return play_queued(params.get('key', ''))


def _route_provider_position(params):
    """Ask the add-on's new place (1..n) and move it there."""
    provider_id = params.get('provider_id', '')
    rows = addon_registry.list_providers() or []
    if len(rows) < 2:
        notify(tr('You need at least two providers to reorder'))
        return
    place = next((index for index, row in enumerate(rows) if row.get('id') == provider_id), None)
    if place is None:
        notify(tr('Provider not found'))
        return
    name = rows[place].get('name') or provider_id
    answer = xbmcgui.Dialog().numeric(0, tr('Move %s to position (1 to %d) — current: %d') % (name, len(rows), place + 1),
                                      str(place + 1))
    if not answer:
        return
    try:
        wanted = max(1, min(int(str(answer).strip()), len(rows)))
    except Exception:
        notify(tr('Invalid value'))
        return
    if wanted - 1 == place:
        notify(tr('%s is already at position %d') % (name, wanted))
        return
    addon_registry.place_addon(provider_id, wanted - 1)
    notify(tr('%s ⟵ position %d') % (name, wanted))
    xbmc.executebuiltin('Container.Refresh')


def _route_seed(params):
    """The ids and the pictures the route carries for the item being opened."""
    return dict(seed_ids=_ids_in_values(tmdb_id=params.get('tmdb_id', ''), imdb_id=params.get('imdb_id', ''),
                                               tvdb_id=params.get('tvdb_id', ''), canonical_id=params.get('canonical_id', '')),
                ui_seed=_route_seed_of(ui_poster=params.get('ui_poster', ''), ui_fanart=params.get('ui_fanart', ''),
                                            ui_clearlogo=params.get('ui_clearlogo', ''),
                                            ui_seed_key=params.get('ui_seed_key', '')))


_SOURCE_CHOICE = ('resume_seconds', '0'), ('resume_percent', ''), ('preferred_provider_name', ''), \
    ('source_provider_id', ''), ('source_mode', '')


def _route_streams(params):
    return streams(params.get('media_type', 'movie'), params.get('canonical_id', ''), params.get('title', ''),
                   **dict(dict((name, params.get(name, default)) for name, default in _SOURCE_CHOICE), **_route_seed(params)))


def _route_episode_streams(params):
    return episode_sources(params.get('canonical_id', ''), params.get('video_id', ''), params.get('season', 1),
                           params.get('episode', 1), params.get('title', ''), params.get('media_type', ''),
                           **dict(dict((name, params.get(name, default)) for name, default in _SOURCE_CHOICE),
                                  **_route_seed(params)))


def _route_account_sync(params):
    return _accounts_route_mod.sync_now(ADDON, tr, only=(params.get('service') or None))


def _route_cloud(params):
    """Nuvio / Stremio sign-in, QR sign-in and sign-out."""
    action = params.get('action')
    service = 'nuvio' if action.startswith(('nuvio', 'meganexus')) else 'stremio'
    if action.endswith('_qr_login'):
        return _cloud_qr_login(service)
    return (_cloud_logout if action.endswith('_logout') else _cloud_login)(service)


def _route_play(params):
    try:
        fallback_keys = json.loads(params.get('fallback_keys') or '[]')
    except Exception:
        fallback_keys = []
    return play(params.get('stream_key', ''), resume_seconds=params.get('resume_seconds', ''),
                resume_percent=params.get('resume_percent', ''),
                fallback_keys=fallback_keys if isinstance(fallback_keys, list) else [],
                switch_subtitle_path=params.get('switch_subtitle_path', ''),
                switch_subtitle_enabled=params.get('switch_subtitle_enabled', ''),
                switch_subtitle_name=params.get('switch_subtitle_name', ''))


def _dispatch():
    params = dict(parse_qsl(sys.argv[2].lstrip('?')))
    action = params.get('action')
    try:
        xbmc.log('[MegaNexus] dispatch action=%r argv=%r' % (action, sys.argv[2]), xbmc.LOGINFO)
    except Exception:
        pass
    if not action:
        return home()
    if action in EARLY_ROUTES:
        return _run_route(EARLY_ROUTES[action], params)
    answered = _fast_dispatch_mod.dispatch(action, params, sys.modules[__name__])
    if answered is _fast_dispatch_mod._NOT_HANDLED:
        return _run_route(ROUTES[action], params) if action in ROUTES else home()
    return answered


# the account pages (screens/accounts_page) for Nuvio and Stremio
_cloud_qr_login = lambda service: _accounts_route_mod.qr_login(service)
_cloud_login = lambda service: _accounts_route_mod.login(service, ADDON, tr)
_cloud_logout = lambda service: _accounts_route_mod.logout(service, tr)


def cloud_sync_now():
    return _accounts_route_mod.sync_now(ADDON, tr)
