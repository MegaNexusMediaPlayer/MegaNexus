# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Local airing calendar for series the user has actually started."""
from datetime import date,datetime,timedelta,timezone
import json
import os
import threading
import time
from .meganexus.paths import profile_path
from .meganexus.paths import WATCHED_PERCENT
from . import simkl_watched
from .meganexus import progress_db

_LOCK=threading.RLock()
_MEM={}

def _path():return os.path.join(profile_path(),'meganexus_airing.json')
def _read():
    try:
        path=_path();stamp=os.stat(path).st_mtime_ns
        with _LOCK:
            if _MEM.get('key')==(path,stamp):return dict(_MEM['data'])
            with open(path,encoding='utf-8') as stream:data=json.load(stream)
            if not isinstance(data,dict):return {}
            _MEM.update(key=(path,stamp),data=data)
            return dict(data)
    except (OSError,ValueError):return {}

def remember(meta,provider_id=''):
    if meta.get('type') not in ('series','tv','show','anime') or not meta.get('id'):return
    meta={k:v for k,v in meta.items() if k in ('id','type','name','title','poster','background','logo','description','videos')}
    meta['videos']=[{k:v for k,v in e.items() if k in ('id','season','episode','released','releaseDate','air_date','firstAired','overview')} for e in meta.get('videos',[]) if isinstance(e,dict)]
    with _LOCK:
        data=_read();data[str(meta['id'])]={'provider':provider_id,'saved':time.time(),'meta':meta}
        data=dict(sorted(data.items(),key=lambda pair:pair[1].get('saved',0),reverse=True)[:100])
        path=_path();os.makedirs(os.path.dirname(path),exist_ok=True)
        from .meganexus.json_files import write_json
        write_json(path,data)

def release_day(episode):
    value=episode.get('released') or episode.get('releaseDate') or episode.get('air_date') or episode.get('firstAired')
    if not value:return None
    try:
        if len(str(value))==10:return date.fromisoformat(value)
        stamp=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
        return stamp.astimezone().date()
    except (ValueError,TypeError):return None

def number(value):
    try:return int(value)
    except (ValueError,TypeError):return 0

def next_card(meta,history,entry,today=None):
    today=today or date.today();base=(number(history.get('season')),number(history.get('episode')))
    try:last_watched=datetime.fromtimestamp(float(history['updated_at'])).date()
    except (KeyError,ValueError,TypeError,OverflowError,OSError):last_watched=today
    def watched_scope(episode):
        if '%s:%s'%(episode.get('season'),episode.get('episode')) in entry.get('episodes',[]):return True
        scope=entry.get('watched') or str(episode.get('season')) in entry.get('seasons',[])
        released=release_day(episode)
        # "All aired episodes watched" must not swallow a later season release.
        return bool(scope and (not released or released<=last_watched))
    episodes=sorted((e for e in meta.get('videos',[]) if isinstance(e,dict) and e.get('id') and number(e.get('season'))>0),
                    key=lambda e:(number(e.get('season')),number(e.get('episode'))))
    eligible=[e for e in episodes if (number(e.get('season')),number(e.get('episode')))>base and not watched_scope(e)]
    tomorrow=next((e for e in eligible if release_day(e)==today+timedelta(days=1)),None)
    selected=tomorrow
    if not selected and (float(history.get('percent') or 0)>=WATCHED_PERCENT or history.get('event_type')=='watched'):
        selected=next((e for e in eligible if release_day(e) and release_day(e)<=today),None)
    if not selected:return None
    target={'media_type':'series','canonical_id':history['canonical_id'],'video_id':selected['id'],
            'season':selected['season'],'episode':selected['episode'],'resume_seconds':0}
    if tomorrow:target['details_view']=True
    return {'title':meta.get('name') or history.get('title') or '',
            'poster':meta.get('poster') or history.get('poster') or '',
            'fanart':meta.get('background') or history.get('background') or '',
            'clearlogo':meta.get('logo') or '', 'plot':selected.get('overview') or meta.get('description') or '',
            'subtitle':'S%s • E%s'%(selected['season'],selected['episode']),
            # 8.1.3: the whole line - kind, year, the episode - not "Series" alone
            'meta_line':'  |  '.join(x for x in ('Series',str(meta.get('year') or meta.get('releaseInfo') or '')[:4],
                                                    'S%s · E%s'%(selected['season'],selected['episode'])) if x),
            'target':target,'percent_value':0,
            'airing_banner':'Tomorrow • New episode' if tomorrow else 'Next episode',
            'tomorrow':'1' if tomorrow else '', 'shape':'poster','continue_card':'next'}

def stale(card,played):
    """7.0.47 (GitHub issue #11): a series' resume card for another episode than the one
    played last, and older than it - e.g. an old S01E01 progress from the cloud after
    S01E03 was watched to the end. The next episode's card takes its place; an episode
    played again later is newer and stays.

    9.0.1 (GitHub issue #28): only an EARLIER episode is out of date. Any other one was:
    S01E04 stopped half way, with S01E03 dated after it (a sync), became the "Next
    episode" S01E04 - from the start, its 22 minutes lost."""
    from .progress_model import timestamp
    if not played or card.get('continue_card')!='resume':return False
    target=card.get('target') or {}
    card_ep=(number(target.get('season')),number(target.get('episode')))
    played_ep=(number(played.get('season')),number(played.get('episode')))
    return card_ep<played_ep and timestamp(played.get('updated_at'))>timestamp(card.get('progress_updated'))


SILENCE = 900.0        # 8.1.2: s a metadata provider is left alone after it stops answering
_QUIET = {}            # provider id -> when it last failed to answer


def _resting(source):
    """This provider stopped answering a moment ago; do not queue up behind it again.

    8.1.2: four lookups at a three-second timeout is twelve seconds, and they were tried
    again on every Home paint - "next episodes 10788 ms", over and over, on a box whose
    drawing thread the rest of the interface is waiting for. When the provider answers
    nothing it will not answer the next four either; asked again in a quarter of an hour.
    Everything already known still comes from the cache, so the rows are not emptied -
    they just stop growing until it is back.
    """
    until = _QUIET.get(str(source.get('id') or ''))
    return bool(until) and time.time() < until


def _silent(source):
    _QUIET[str(source.get('id') or '')] = time.time() + SILENCE


def _answered(source):
    _QUIET.pop(str(source.get('id') or ''), None)


def augment(rows,refresh=False,stopped=lambda:False):
    from . import backend_api
    from . import continue_rules
    from . import metadata_providers
    source=backend_api.provider('metadata') or metadata_providers.first() or {};cache=_read();seen=set();history=[]
    on={p['id'] for p in metadata_providers.enabled()}   # any of them answers for its series
    removed=continue_rules.snapshot();unaired=continue_rules.show_unaired()
    for row in progress_db.list_recent_items(limit=500,media_types=('series','tv','show','anime')):
        mid=row['canonical_id']
        # GitHub issue #31: one series under two ids (IMDb, TMDB, TVDB) is one series - its latest
        # episode counts; the older id's row made a second card that came and went
        keys=progress_db.title_keys(dict(row,media_type='series'))
        if not keys&seen and row.get('episode'):
            seen|=keys
            # 6.0.35 (issue #7): only series watched in the period, not removed.
            if continue_rules.recent_enough(row.get('updated_at')) and not continue_rules.hidden('series',mid,row.get('updated_at'),removed,continue_rules.ids_of(row)):
                history.append(row)
        if len(history)>=50:break
    states=simkl_watched.snapshot();cards=[];requests=0
    last={}                                          # the episode played last, per series - under each of its ids
    for row in history:
        for found in progress_db.title_keys(dict(row,media_type='series')):last[found]=row

    def played_last(target):
        return next((last[found] for found in progress_db.title_keys(dict(target,media_type='series')) if found in last),None)
    for row in history:
        if stopped():return rows
        mid=row['canonical_id'];saved=cache.get(mid) or {};meta=saved.get('meta') or {}
        # #31: another metadata add-on's episodes stand until this one's have come (the card vanished meanwhile)
        other=saved.get('provider') not in on
        if refresh and source and requests<4 and not _resting(source) and (not meta or other or time.time()-saved.get('saved',0)>3600):
            requests+=1
            try:
                meta=backend_api.metadata('series',mid,timeout=3)
                _answered(source)
            except Exception:
                _silent(source)
        if meta:
            card=next_card(meta,row,simkl_watched.state(states,'series',mid))
            if card:cards.append(card)
    output=[dict(row) for row in rows if row.get('target')]
    upcoming=[];next_episodes=[]
    for card in cards:
        if card.get('tomorrow') and not unaired:continue  # "Show unaired next episodes" off
        keys=progress_db.title_keys(dict(card['target'],media_type='series'))
        existing=next((r for r in output if r.get('target') and keys&progress_db.title_keys(dict(r['target'],media_type=r['target'].get('media_type') or 'series'))),None)
        if existing and stale(existing,played_last(card['target'])):
            output[output.index(existing)]=card   # 7.0.47 (issue #11): the next episode, not an older one
        elif existing:
            if card.get('tomorrow'):
                existing.update(airing_banner=card['airing_banner'],tomorrow='1')
        elif card.get('tomorrow'):upcoming.append(card)
        else:next_episodes.append(card)
    # 7.0.47 (issue #11): an older episode's progress never stands for a series watched
    # further - also when no next episode replaced it (the last one was watched)
    output=[row for row in output if not (row.get('target') and stale(row,played_last(row['target'])))]
    # Resume cards retain last-played order. Airing banners must not displace
    # the film/episode just stopped; untouched upcoming titles follow resumes.
    output.extend(upcoming+next_episodes)
    return output if output or any(row.get('target') for row in rows) else rows
