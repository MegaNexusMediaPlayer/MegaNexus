# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Nuvio and Stremio accounts, straight from Kodi (api.nuvio.tv, api.strem.io).

The user signs in once in Settings; only the account's token is kept (nuvio_token.json /
stremio_token.json in the profile folder), never the password. Add-ons, progress,
collections and the library are read and written with that token; a failed call leaves
the local state as it was. Standard library only (urllib)."""
import calendar
import json
import os
import re
import time
from .paths import watched_percent
import urllib.request
import urllib.error

try:
    import xbmc
except Exception:
    xbmc = None

from .paths import profile_path, addon
from .json_files import read_json, write_json

# Nuvio's server (Supabase: its public "anon" key opens the auth and rpc doors) and Stremio's
NUVIO_URL, STREMIO_URL = 'https://api.nuvio.tv', 'https://api.strem.io'
NUVIO_ANON = '.'.join(('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9',
                       'eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzgxNTIxMzQ2LCJleHAiOjE5MzkyMDEzNDZ9',
                       'tmQaj682pwzehpqlgCDMnySOqiUvpgRbrE43T4VJpDI'))
_NUVIO_TOKEN, _STREMIO_TOKEN = (os.path.join(profile_path(), name) for name in ('nuvio_token.json', 'stremio_token.json'))
_UA = 'Mozilla/5.0 (compatible; MegaNexus Kodi)'


def _log(msg):
    if xbmc is None:
        return
    try:
        xbmc.log('[MegaNexus][sync] ' + str(msg), xbmc.LOGINFO)
    except Exception:
        pass


def _setting(key, default=''):
    try:
        return (addon().getSetting(key) or default).strip()
    except Exception:
        return default


def _setting_bool(key, default=False):
    v = _setting(key, '')
    if v == '':
        return default
    return v.lower() in ('true', '1', 'yes', 'on')


def _http(url, payload=None, headers=None, method='GET', timeout=10):
    """The JSON answer of one request ({} when empty); a refusal raises RuntimeError with the
    server's own words for it."""
    sent = dict({'Accept': 'application/json', 'User-Agent': _UA}, **(headers or {}))
    body = None
    if payload is not None:
        body, sent['Content-Type'] = json.dumps(payload).encode('utf-8'), 'application/json'
    try:
        with urllib.request.urlopen(urllib.request.Request(url, data=body, headers=sent, method=method),
                                    timeout=timeout) as reply:
            text = reply.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as refused:
        try:
            said = json.loads(refused.read().decode('utf-8', 'replace') or '{}')
        except Exception:
            said = {}
        words = [said.get(key) for key in ('error_description', 'msg', 'message', 'error')] if isinstance(said, dict) else []
        raise RuntimeError(str(next((w for w in words if w), 'HTTP %s' % refused.code)))
    return json.loads(text) if text else {}


def _json_list_of(value):
    """A list given as JSON text or as a list; [] otherwise."""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except Exception:
            return []
    return value if isinstance(value, list) else []


SIGN_IN_PAUSE = 1800            # s between two sign-ins with the kept password
_SIGN_IN_TRIED = [0.0, 0.0]     # Nuvio, Stremio


class NuvioCloud:
    @staticmethod
    def token():
        return read_json(_NUVIO_TOKEN, {}) or {}

    @staticmethod
    def save_token(data):
        d = dict(data or {})
        d.setdefault('created_at', int(time.time()))
        write_json(_NUVIO_TOKEN, d)

    @staticmethod
    def clear():
        # A deleted primary is otherwise recovered from the previous login backup.
        write_json(_NUVIO_TOKEN, {})
        NuvioCloud.remember('', '')                  # signed out: the kept sign-in goes too

    @staticmethod
    def remember(email, password):
        """8.1.5: the sign-in kept on this device - and in its backup, like every key; never
        in a log or a problem report. A session Nuvio has ended is signed in again with it."""
        try:
            settings = addon()
            if email or not password:
                settings.setSetting('nuvio_email', str(email or '').strip())
            settings.setSetting('nuvio_password', password or '')
        except Exception:
            pass
        try:
            os.remove(_NUVIO_TOKEN + '.bak')
        except FileNotFoundError:
            pass

    @staticmethod
    def is_linked():
        return bool(NuvioCloud.token().get('access_token'))

    @staticmethod
    def _grant(kind, sent):
        """A Supabase session from the auth door (``kind``: password / refresh_token)."""
        return _http('%s/auth/v1/token?grant_type=%s' % (NUVIO_URL, kind), payload=sent,
                     headers={'apikey': NUVIO_ANON}, method='POST')

    @staticmethod
    def _session(answer, before):
        """What is kept of a session the auth door gave - ``before`` fills what it left out."""
        return {'access_token': answer.get('access_token'),
                'refresh_token': answer.get('refresh_token') or before.get('refresh_token'),
                'expires_in': int(answer.get('expires_in') or 3600), 'created_at': int(time.time()),
                'user_id': (answer.get('user') or {}).get('id') or before.get('user_id'),
                'email': before.get('email')}

    @staticmethod
    def authenticate(email, password):
        """Fetch a session without committing a cancelled UI operation."""
        answer = NuvioCloud._grant('password', {'email': email, 'password': password})
        if not answer.get('access_token'):
            raise RuntimeError('login failed: no access_token')
        return NuvioCloud._session(answer, {'email': email})

    @staticmethod
    def login(email, password):
        NuvioCloud.save_token(NuvioCloud.authenticate(email, password))
        NuvioCloud.remember(email, password)
        return True

    @staticmethod
    def _sign_in_again(kept):
        """8.1.5: Nuvio no longer renews the session (its renewal was used up elsewhere, or it
        was ended): signed in again with the kept sign-in - the Nuvio profile stays. At most
        once every SIGN_IN_PAUSE, so a changed password is not tried every minute."""
        if time.time() - _SIGN_IN_TRIED[0] < SIGN_IN_PAUSE:
            return None
        settings = addon()
        email = (settings.getSetting('nuvio_email') or kept.get('email') or '').strip()
        password = settings.getSetting('nuvio_password') or ''
        if not email or not password:
            return None
        _SIGN_IN_TRIED[0] = time.time()
        try:
            fresh = NuvioCloud.authenticate(email, password)
        except Exception as exc:
            _log('meganexus sign-in again failed: %s' % exc)
            return None
        now = NuvioCloud.token()
        if now.get('access_token') != kept.get('access_token'):
            return now                               # a newer sign-in came first
        fresh.update((key, now.get(key)) for key in ('profile_index', 'profile_name'))
        fresh['uses_primary_addons'] = now.get('uses_primary_addons', False)
        NuvioCloud.save_token(fresh)
        _SIGN_IN_TRIED[0] = 0.0
        _log('meganexus: Nuvio had ended the session - signed in again')
        return NuvioCloud.token()

    @staticmethod
    def _signed_token():
        """The session, renewed a minute before it runs out (when it can be)."""
        kept = NuvioCloud.token()
        if not kept.get('access_token'):
            raise RuntimeError('not linked to Nuvio')
        ends = int(kept.get('created_at') or 0) + int(kept.get('expires_in') or 3600)
        if ends - 60 > int(time.time()) or not kept.get('refresh_token'):
            return kept
        refused = False
        try:
            answer = NuvioCloud._grant('refresh_token', {'refresh_token': kept.get('refresh_token')})
            if answer.get('access_token'):
                now = NuvioCloud.token()
                if now.get('access_token') != kept.get('access_token'):
                    return now                   # a newer login or a logout came first
                renewed = NuvioCloud._session(answer, kept)
                renewed.update((key, now.get(key)) for key in ('profile_index', 'profile_name'))
                renewed['uses_primary_addons'] = now.get('uses_primary_addons', False)
                NuvioCloud.save_token(renewed)
                return NuvioCloud.token()
        except Exception as exc:
            refused = isinstance(exc, RuntimeError)   # Nuvio said no; not a network that is down
            _log('meganexus refresh failed: %s' % exc)
        again = NuvioCloud._sign_in_again(kept)
        if again:
            return again
        if refused:
            from ..account_notice import signed_out
            signed_out('Nuvio', kept.get('refresh_token') or kept.get('access_token') or '')
        return kept

    @staticmethod
    def _rpc(fn, params, timeout=9):
        data = NuvioCloud._signed_token()
        return _http(
            NUVIO_URL + '/rest/v1/rpc/' + fn,
            payload=params or {},
            headers={'apikey': NUVIO_ANON,
                     'Authorization': 'Bearer %s' % data.get('access_token')},
            method='POST', timeout=timeout)

    @staticmethod
    def _profile_id():
        data = NuvioCloud.token()
        cached = data.get('profile_index')
        try:
            n = int(cached)
            if n > 0:
                return n
        except Exception:
            pass
        rows = NuvioCloud.profiles()
        if len(rows) != 1:
            raise ValueError('Choose your Nuvio profile in Settings > Nuvio account before importing.')
        NuvioCloud.select_profile(rows[0])
        return rows[0]['profile_index']

    @staticmethod
    def profiles():
        rows = NuvioCloud._unwrap_list(NuvioCloud._rpc('sync_pull_profiles', {}), ('profiles', 'data'))
        profiles = []
        for row in rows:
            if not isinstance(row, dict):continue
            try:index = int(row.get('profile_index', row.get('profileIndex', row.get('index'))))
            except (ValueError, TypeError):continue
            if index > 0:
                profiles.append({'profile_index':index, 'profile_name':str(row.get('name') or 'Profile %d' % index),
                                 'uses_primary_addons':row.get('uses_primary_addons') is True})
        if not profiles:raise ValueError('No Nuvio profiles were returned. Create a profile in Nuvio, then retry.')
        return profiles

    @staticmethod
    def select_profile(profile):
        data = NuvioCloud.token()
        if not data.get('access_token'):raise ValueError('Sign in to Nuvio first.')
        data.update(profile_index=int(profile['profile_index']), profile_name=profile['profile_name'])
        data['uses_primary_addons'] = profile.get('uses_primary_addons') is True
        NuvioCloud.save_token(data)

    # ── mappers: MegaNexus ⇄ Nuvio ──
    @staticmethod
    def _addon_rows_for_cloud(providers):
        out, seen = [], set()
        for p in providers or []:
            url = (p.get('manifest_url') or p.get('transportUrl') or p.get('url') or '').strip()
            if not url.lower().startswith(('http://', 'https://')):
                continue
            k = url.lower()
            if k in seen:
                continue
            seen.add(k)
            out.append({
                'url': _manifest_address(url),
                'name': str(p.get('name') or ''),
                'enabled': p.get('enabled') is not False,
                'sort_order': len(out),
            })
        return out

    @staticmethod
    def _addons_to_local(addons):
        """The add-ons' manifest links (web ones, each once) and names."""
        out, seen = [], set()
        for entry in addons or []:
            link = next((entry.get(key) for key in ('url', 'transportUrl', 'manifestUrl', 'manifest_url') if entry.get(key)), '')
            link = link.strip()
            if link.lower().startswith(('http://', 'https://')) and link.lower() not in seen:
                seen.add(link.lower())
                out.append({'manifest_url': link, 'name': str(entry.get('name') or '')})
        return out

    @staticmethod
    def _progress_to_nuvio(rows):
        from resources.lib.progress_model import to_wire
        return [value for value in (to_wire(r) for r in rows or [] if isinstance(r, dict)) if value is not None]

    @staticmethod
    def _progress_to_local(entries):
        from resources.lib.progress_model import from_wire
        return [value for value in (from_wire(e) for e in entries or []) if value is not None]

    # ── high-level sync ops ──
    @staticmethod
    def _unwrap_list(payload, keys):
        if isinstance(payload, list):
            return payload
        if isinstance(payload, dict):
            for key in keys:
                val = payload.get(key)
                if isinstance(val, list):
                    return val
                if isinstance(val, str):
                    try:
                        parsed = json.loads(val)
                        if isinstance(parsed, list):
                            return parsed
                    except Exception:
                        pass
        return []

    @staticmethod
    def _addons_in_answer(payload):
        out, seen = [], set()
        def walk(node):
            if isinstance(node, str):
                text = node.strip()
                if text.startswith(('http://', 'https://')) and 'manifest' in text.lower():
                    key = text.lower().rstrip('/')
                    if key not in seen:
                        seen.add(key); out.append({'manifest_url': text, 'name': ''})
                else:
                    try:
                        parsed = json.loads(text)
                        if isinstance(parsed, (dict, list)): walk(parsed)
                    except Exception:
                        pass
                return
            if isinstance(node, list):
                for item in node: walk(item)
                return
            if not isinstance(node, dict): return
            url = node.get('transportUrl') or node.get('manifestUrl') or node.get('manifest_url') or node.get('url')
            if url:
                walk(url)
            for key in ('addons','installedAddons','addonCollection','providers','sources','profile_data','settings','data','payload'):
                if key in node: walk(node.get(key))
        walk(payload)
        return out

    @staticmethod
    def _cloud_get(path, timeout=8):
        """Direct PostgREST table read — same access path Nuvio's own client uses."""
        data = NuvioCloud._signed_token()
        return _http(
            NUVIO_URL + path,
            headers={'apikey': NUVIO_ANON,
                     'Authorization': 'Bearer %s' % data.get('access_token')},
            method='GET', timeout=timeout)

    @staticmethod
    def cloud_addons(providers, direction='both'):
        pid = NuvioCloud._profile_id()
        merged = list(providers or [])
        if direction != 'push':
            addon_pid = 1 if NuvioCloud.token().get('uses_primary_addons') else pid
            rows = NuvioCloud._cloud_get(
                '/rest/v1/addons?profile_id=eq.%d'
                '&select=url,name,enabled,sort_order&order=sort_order.asc' % addon_pid)
            remote_local, disabled = [], 0
            for r in (rows if isinstance(rows, list) else []):
                if not isinstance(r, dict):
                    continue
                url = _manifest_address(str(r.get('url') or '').strip())
                if not url.lower().startswith(('http://', 'https://')):
                    continue
                if r.get('enabled') is False:
                    disabled += 1
                    continue
                remote_local.append({'manifest_url': url, 'name': str(r.get('name') or '')})
            _log('meganexus addons pull: %d enabled, %d disabled skipped (profile %s)'
                 % (len(remote_local), disabled, pid))
            merged = _union_by_address(merged, remote_local)
        if direction != 'pull':
            addons = NuvioCloud._addon_rows_for_cloud(merged)
            if addons:
                NuvioCloud._rpc('sync_push_addons', {
                    'p_profile_id': pid, 'p_addons': addons,
                    'p_origin_client_id': 'meganexus-kodi'})
                _log('meganexus addons push: %d rows' % len(addons))
        return merged

    @staticmethod
    def cloud_collections(collections, direction='both'):
        """Collections both ways: ours pushed whole (unless pulling), Nuvio's merged in
        (unless pushing). Nuvio answers a list of them, or one row holding them as JSON."""
        profile = NuvioCloud._profile_id()
        if direction != 'pull':
            NuvioCloud._rpc('sync_push_collections', {'p_profile_id': profile, 'p_collections_json': collections or []})
        if direction == 'push':
            return collections or []
        answer = NuvioCloud._rpc('sync_pull_collections', {'p_profile_id': profile})
        found = NuvioCloud._unwrap_list(answer, ('collections', 'items', 'data', 'collections_json'))
        if found and not (len(found) == 1 and isinstance(found[0], dict) and 'collections_json' in found[0]):
            return _union_collections(collections, found)
        holder = found[0] if found else (answer if isinstance(answer, dict) else {})
        return _union_collections(collections, _json_list_of(holder.get('collections_json')))

    _LIB_PAGE = 500

    @staticmethod
    def _library_for_cloud(rows):
        """The library as Nuvio's library rows (one per title)."""
        out, seen = [], set()
        for row in rows or []:
            title_id = str((row or {}).get('canonical_id') or '').strip()
            if not title_id or title_id in seen:
                continue
            seen.add(title_id)
            try:
                added = int(float(row.get('added_at') or 0)) * 1000
            except Exception:
                added = 0
            kind = str(row.get('media_type') or 'movie').strip().lower()
            out.append(dict(content_id=title_id, content_type='series' if kind in ('series', 'show', 'tv', 'anime') else 'movie',
                            name=row.get('title') or 'Untitled', poster=row.get('poster') or None, poster_shape='POSTER',
                            background=row.get('background') or None, description=row.get('plot') or '',
                            release_info=str(row.get('year') or ''), imdb_rating=None, genres=[], addon_base_url=None,
                            added_at=added or int(time.time() * 1000)))
        return out

    @staticmethod
    def _when(value):
        """An epoch out of whatever the account sends: seconds, milliseconds or a date."""
        text = str(value or '').strip()
        if not text:
            return 0
        if text.replace('.', '', 1).isdigit():
            number = float(text)
            return int(number / 1000 if number > 1e11 else number)
        try:
            from datetime import datetime
            return int(datetime.fromisoformat(text.replace('Z', '+00:00')).timestamp())
        except (ValueError, TypeError, OverflowError):
            return 0

    @staticmethod
    def _library_to_local(rows):
        """Nuvio's library rows as ours (canonical id, kind, names, pictures, year, when saved)."""
        out = []
        for row in rows or []:
            title_id = (row.get('content_id') or row.get('contentId') or row.get('id') or '') if isinstance(row, dict) else ''
            if not title_id:
                continue
            kind = str(row.get('content_type') or row.get('contentType') or 'movie').lower()
            year = str(row.get('release_info') or row.get('releaseInfo') or '')[:4]
            # 8.1.2: when it was saved, in whichever way the account writes it. It was dropped
            # before, so every title the account sent arrived with no date and the Calendar
            # put the whole library in the current month.
            saved = next((row.get(key) for key in ('added_at', 'addedAt', 'created_at', 'createdAt', 'saved_at', 'updated_at')
                          if row.get(key)), row.get('updated_at'))
            out.append(dict(canonical_id=str(title_id), media_type='series' if kind in ('series', 'show', 'tv') else 'movie',
                            title=row.get('name') or row.get('title') or 'Untitled', poster=row.get('poster') or '',
                            background=row.get('background') or '', plot=row.get('description') or '',
                            year=int(year) if year.isdigit() else 0, added_at=NuvioCloud._when(saved)))
        return out

    SAME_ASKED = 60    # TMDB ids asked for their IMDb id in one sync (each once, then kept)

    @staticmethod
    def _same_titles(keys):
        """{(kind, id): (kind, the title's IMDb id)} - a TMDB id by the IMDb id it has (asked once,
        kept by tmdb_api); an id with none known stays itself."""
        from resources.lib import library, tmdb_api
        out, asked = {}, 0
        for kind, cid in keys:
            found = library._same_title(kind, cid)
            if found[1] == cid and cid.startswith('tmdb:') and asked < NuvioCloud.SAME_ASKED:
                asked += 1
                try:
                    imdb = tmdb_api.imdb_of(cid.split(':', 1)[1], 'tv' if kind == 'series' else 'movie', timeout=4)
                except Exception:
                    imdb = ''
                if imdb:
                    found = (kind, imdb)
            out[(kind, cid)] = found
        return out

    @staticmethod
    def cloud_library(rows, direction='both'):
        """Sync the saved library (MegaNexus Library / favourites) with Nuvio.

        7.0.44: really two-way, deletions too. The last list both sides agreed on
        is kept (nuvio_library_state.json, per account and profile); each sync
        compares this device's list and Nuvio's with it: added on either side is
        added on the other, removed on either side is removed on the other.
        Changes go to Nuvio one by one (sync_push_library_items /
        sync_delete_library_items, as Nuvio's own apps do); before, the whole
        merged list was pushed with sync_push_library - which REPLACES Nuvio's
        list - so a title removed anywhere came back. Only this device's own and
        Nuvio's titles take part (not the Trakt / Simkl mirrors).
        """
        from resources.lib import library_titles, nuvio_progress
        pid = NuvioCloud._profile_id()
        scope = '%s|%s' % (nuvio_progress.scope(), pid)

        def key(row):
            mt = str(row.get('media_type') or 'movie').lower()
            return ('series' if mt in ('series', 'show', 'tv', 'anime') else 'movie', str(row.get('canonical_id') or '').strip())

        local = {}
        for row in library_titles.list_favorites(limit=5000) or []:
            # a title in the Library and in the Trakt mirror reads 'mixed': its sources count
            sources = set(row.get('sources') or [row.get('source') or 'local'])
            if sources & {'local', 'nuvio'} and key(row)[1]:
                local.setdefault(key(row), row)
        remote_rows, offset = [], 0
        for _page in range(20):
            page = NuvioCloud._rpc('sync_pull_library', {
                'p_profile_id': pid, 'p_limit': NuvioCloud._LIB_PAGE,
                'p_offset': offset})
            if not isinstance(page, list):
                # an error answer is not an empty Library: stop, change nothing (older
                # builds read it as empty and replaced Nuvio's list with this device's)
                raise ValueError('Nuvio did not return the Library')
            batch = page
            remote_rows.extend(batch)
            if len(batch) < NuvioCloud._LIB_PAGE:
                break
            offset += NuvioCloud._LIB_PAGE
        remote = dict((key(r), r) for r in NuvioCloud._library_to_local(remote_rows) if key(r)[1])
        same = NuvioCloud._same_titles(set(local) | set(remote))
        state = read_json(_LIB_STATE_FILE, {}) or {}
        synced = set(tuple(k) for k in state.get('synced') or []) if state.get('scope') == scope else None
        up, down = direction != 'pull', direction != 'push'
        L, R = set(local), set(remote)
        # Nothing is removed without knowing it was removed: only a title both sides
        # had at the last sync and one side no longer has goes from the other. On the
        # first sync on a device (or after an account / profile change) the two lists
        # are joined - never cut (a test build removed copies Nuvio did not list).
        if synced is None:
            to_push = (L - R) if up else set()
            to_add = (R - L) if down else set()
            to_del_remote = to_del_local = set()
        else:
            local_added, local_removed = L - synced, synced - L
            remote_added, remote_removed = R - synced, synced - R
            to_push = (local_added - R) if up else set()
            to_del_remote = (local_removed & R) if up else set()
            to_add = (remote_added - L - local_removed) if down else set()
            to_del_local = ((remote_removed & L) - local_added) if down else set()
        # 9.0.5: one title under its IMDb id here and its TMDB id there is already on both sides - it
        # was pushed (and pulled) as another title: the account held 18 titles twice ("Nuvio 71, ours 53")
        here, there = set(same[k] for k in L), set(same[k] for k in R)
        to_push = set(k for k in to_push if same[k] not in there)
        to_add = set(k for k in to_add if same[k] not in here)
        _log('meganexus library: pull %d, add here %d, remove here %d, add to Nuvio %d, remove from Nuvio %d'
             % (len(R), len(to_add), len(to_del_local), len(to_push), len(to_del_remote)))
        if to_push or to_del_remote:
            items = NuvioCloud._library_for_cloud([local[k] for k in sorted(to_push)])
            try:
                if items:
                    NuvioCloud._rpc('sync_push_library_items', {'p_profile_id': pid, 'p_items': items})
                if to_del_remote:
                    NuvioCloud._rpc('sync_delete_library_items', {'p_profile_id': pid, 'p_keys': [
                        {'content_id': cid, 'content_type': mt} for mt, cid in sorted(to_del_remote)]})
            except Exception:
                # an older Nuvio server: the whole agreed list (sync_push_library
                # replaces the remote list - correct here, it already holds both sides)
                final_remote = (R | to_push) - to_del_remote
                rows_out = [local.get(k) or remote.get(k) for k in sorted(final_remote)]
                NuvioCloud._rpc('sync_push_library', {'p_profile_id': pid, 'p_items': NuvioCloud._library_for_cloud(rows_out)})
        for mt, cid in sorted(to_add):
            row = remote[(mt, cid)]
            library_titles.add(mt, cid, row.get('title') or cid, poster=row.get('poster') or '',
                                background=row.get('background') or '', year=row.get('year') or 0,
                                plot=row.get('plot') or '', source='nuvio',
                                added_at=row.get('added_at') or 0)   # 8.1.2: when the account saved it
        for mt, cid in sorted(to_del_local):
            for source in ('local', 'nuvio'):
                library_titles.remove(mt, cid, source=source)
        final = (L | to_add) - to_del_local
        try:
            write_json(_LIB_STATE_FILE, {'scope': scope, 'synced': sorted(list(k) for k in final), 'at': int(time.time())})
        except Exception:
            pass
        merged = [local.get(k) or remote.get(k) for k in sorted(final)]
        return [dict(r, media_type=k[0], canonical_id=k[1]) for k, r in zip(sorted(final), merged)]

    @staticmethod
    def cloud_progress(rows, direction='both'):
        from resources.lib import progress_model as model, nuvio_progress
        pid = NuvioCloud._profile_id()
        account = nuvio_progress.scope()
        def rpc(method, body):
            if nuvio_progress.scope() != account:
                raise ValueError('Nuvio profile changed during progress sync.')
            result = NuvioCloud._rpc(method, body)
            if nuvio_progress.scope() != account:
                raise ValueError('Nuvio profile changed during progress sync.')
            return result
        local = [r for r in rows or [] if isinstance(r, dict)]
        remote = []
        # Pull first: uploading an older local position must not roll another device back.
        if direction != 'push':
            payload = rpc('sync_pull_watch_progress', {'p_profile_id': pid})
            if not isinstance(payload, list):
                raise ValueError('Invalid Nuvio progress response; previous local progress was kept.')
            remote = NuvioCloud._progress_to_local(payload)
        by_id = {model.identity(r): r for r in remote}
        push, deletes, acknowledged = [], [], []
        for row in local:
            other = by_id.get(model.identity(row))
            if other and model.timestamp(other.get('updated_at')) > model.timestamp(row.get('updated_at')):
                acknowledged.append(row)
                continue
            if row.get('_operation') == 'delete':
                deletes.append(model.wire_key(other or row))
                acknowledged.append(row)
                continue
            candidate=dict(row)
            if other:
                candidate.update(canonical_id=other['canonical_id'], video_id=other.get('video_id') or other['canonical_id'])
            wire = model.to_wire(candidate)
            if wire is not None:
                push.append(wire)
                acknowledged.append(row)
            elif model.percent(row) >= watched_percent():
                # A completed title with unknown runtime can remove a resume key,
                # but cannot pretend to have a measured duration.
                deletes.append(model.wire_key(other or row))
                acknowledged.append(row)
        if direction != 'pull':
            for offset in range(0, len(push), 100):
                rpc('sync_push_watch_progress', {'p_profile_id': pid, 'p_entries': push[offset:offset+100]})
            if deletes:
                rpc('sync_delete_watch_progress', {'p_profile_id': pid, 'p_keys': list(dict.fromkeys(deletes))})
            nuvio_progress.acknowledge(acknowledged, account)
        else:
            # Explicit download-only means local changes must never be uploaded later
            # merely because a delayed automatic cycle remained queued.
            nuvio_progress.acknowledge(local, account)
        removed = set(deletes) if direction != 'pull' else set()
        merged = _union_progress([r for r in local if r.get('_operation') != 'delete'], remote)
        return [row for row in merged if model.wire_key(row) not in removed]


class StremioCloud:
    LIB = 'libraryItem'

    @staticmethod
    def token():
        return read_json(_STREMIO_TOKEN, {}) or {}

    @staticmethod
    def save_token(data):
        write_json(_STREMIO_TOKEN, dict(data or {}))

    @staticmethod
    def clear():
        try:
            os.remove(_STREMIO_TOKEN)
        except FileNotFoundError:
            pass
        try:                                        # signed out: the kept sign-in goes too
            addon().setSetting('stremio_password', '')
        except Exception:
            pass

    @staticmethod
    def is_linked():
        return bool(StremioCloud.token().get('authKey'))

    @staticmethod
    def _api(method, params, again=True):
        """Stremio's API: the answer's 'result'; its 'error' raised with its message. 8.1.5: a
        session Stremio no longer knows is signed in again with the kept sign-in, once."""
        answer = _http('%s/api/%s' % (STREMIO_URL, method), payload=params or {}, method='POST')
        if not isinstance(answer, dict):
            return None
        problem = answer.get('error')
        if problem and again and (params or {}).get('authKey'):
            fresh = StremioCloud._sign_in_again()
            if fresh:
                return StremioCloud._api(method, dict(params, authKey=fresh), again=False)
            said = problem if isinstance(problem, dict) else {'message': problem}
            if said.get('code') == 1 or 'session' in str(said.get('message') or '').lower():
                from ..account_notice import signed_out
                signed_out('Stremio', params.get('authKey') or '')
        if problem:
            raise RuntimeError('Stremio %s: %s' % (method, problem.get('message') if isinstance(problem, dict) else problem))
        return answer.get('result')

    @staticmethod
    def _sign_in_again():
        """The new session key from the kept Stremio sign-in, or None (at most once per SIGN_IN_PAUSE)."""
        if time.time() - _SIGN_IN_TRIED[1] < SIGN_IN_PAUSE:
            return None
        settings = addon()
        email = (settings.getSetting('stremio_email') or StremioCloud.token().get('email') or '').strip()
        password = settings.getSetting('stremio_password') or ''
        if not email or not password:
            return None
        _SIGN_IN_TRIED[1] = time.time()
        try:
            StremioCloud.login(email, password)
        except Exception as exc:
            _log('stremio sign-in again failed: %s' % exc)
            return None
        _SIGN_IN_TRIED[1] = 0.0
        _log('stremio: the session had ended - signed in again')
        return StremioCloud.token().get('authKey')

    @staticmethod
    def login(email, password):
        found = StremioCloud._api('login', {'email': email, 'password': password}) or {}
        if not found.get('authKey'):
            raise RuntimeError('login failed: no authKey')
        StremioCloud.save_token(dict(authKey=found['authKey'], user_id=(found.get('user') or {}).get('_id'),
                                     email=email, created_at=int(time.time())))
        try:                                        # 8.1.5: kept, as Nuvio's (backup yes, logs never)
            addon().setSetting('stremio_email', str(email or '').strip())
            addon().setSetting('stremio_password', password or '')
        except Exception:
            pass
        return True

    @staticmethod
    def _auth_key():
        data = StremioCloud.token()
        if not data.get('authKey'):
            raise RuntimeError('not linked to Stremio')
        return data['authKey']

    # ── mappers ──
    @staticmethod
    def _addons_to_local(addons):
        out = []
        for a in addons or []:
            manifest = a.get('manifest') or {}
            url = a.get('transportUrl') or manifest.get('url') or ''
            if url:
                out.append({'manifest_url': url, 'name': manifest.get('name') or a.get('transportName') or ''})
        return out

    @staticmethod
    def _fetch_manifest(url):
        try:
            return _http(url, method='GET', timeout=12)
        except Exception:
            return None

    @staticmethod
    def _library_to_local(items):
        """Stremio's library items with a place in them, as local progress rows."""
        out = []
        for item in items or []:
            state = (item or {}).get('state') or {}
            if not item or item.get('removed') or not (state.get('timeOffset') or state.get('duration')):
                continue
            title_id, series = item.get('_id') or '', item.get('type') == 'series'
            length, place = float(state.get('duration') or 0) / 1000.0, float(state.get('timeOffset') or 0) / 1000.0
            imdb = title_id.startswith('tt')
            out.append(dict(imdb_id=title_id if imdb else '', tmdb_id='' if imdb else title_id, canonical_id=title_id,
                            media_type='tv' if series else 'movie', title=item.get('name') or '',
                            video_id=state.get('video_id') or title_id,
                            season=state.get('season') if series else None, episode=state.get('episode') if series else None,
                            position=place, duration=length,
                            percent=min(100.0, place / length * 100.0) if length else 0.0,
                            updated_at=int(_parse_ts(item.get('_mtime')))))
        return out

    @staticmethod
    def _progress_for_stremio(rows, existing_by_id):
        """Local progress rows as Stremio library changes (the item it has, else a new one)."""
        changes = []
        for row in rows or []:
            title_id = row.get('imdb_id') or row.get('canonical_id') or row.get('tmdb_id') or ''
            if not title_id:
                continue
            series = row.get('media_type') in ('tv', 'series') or row.get('season') is not None
            stamp = _to_iso(int(row.get('updated_at') or time.time()))
            known = existing_by_id.get(title_id)
            item = dict(known) if known else dict(
                _id=str(title_id), name=row.get('title') or '', type='series' if series else 'movie',
                poster=row.get('poster') or '', background=row.get('background') or '', logo=row.get('clearlogo') or '',
                removed=False, temp=True, _ctime=stamp)
            item['_mtime'] = stamp
            state = dict(item.get('state') or {})
            done = float(row.get('percent') or 0) >= watched_percent()
            episode_id = str(row.get('video_id') or '%s:%s:%s' % (title_id, row.get('season'), row.get('episode')))
            state.update(timeOffset=int(round(float(row.get('position') or 0) * 1000)),
                         duration=int(round(float(row.get('duration') or 0) * 1000)),
                         video_id=episode_id if series else str(title_id), lastWatched=stamp,
                         watched=stamp if done else (state.get('watched') or ''), flaggedWatched=1 if done else 0)
            if series:
                state.update(season=int(row.get('season') or 0), episode=int(row.get('episode') or 0))
            item['state'] = state
            changes.append(item)
        return changes

    # ── high-level ops ──
    @staticmethod
    def cloud_addons(providers, direction='both'):
        """The add-ons both ways: Stremio's taken in (unless pushing); then (unless pulling)
        Stremio's collection written as its protected add-ons plus ours, in our order - an
        add-on it does not have yet goes with its manifest, read now."""
        key = StremioCloud._auth_key()
        theirs = (StremioCloud._api('addonCollectionGet', {'authKey': key, 'update': True}) or {}).get('addons') or []
        merged = providers or []
        if direction != 'push':
            merged = _union_by_address(providers, StremioCloud._addons_to_local(theirs))
        if direction == 'pull':
            return merged
        address = lambda entry: entry.get('transportUrl') or (entry.get('manifest') or {}).get('url') or ''
        by_address = dict((address(entry), entry) for entry in theirs if address(entry))
        collection = [entry for entry in theirs if (entry.get('flags') or {}).get('protected')]
        seen = set(entry.get('transportUrl') or '' for entry in collection)
        for provider in merged:
            link = provider.get('manifest_url') or provider.get('transportUrl') or provider.get('url') or ''
            if not link or link in seen:
                continue
            seen.add(link)
            if link in by_address:
                collection.append(by_address[link])
                continue
            manifest = StremioCloud._fetch_manifest(link)
            if manifest and manifest.get('id'):
                collection.append({'transportUrl': link, 'transportName': manifest.get('name') or '',
                                   'manifest': manifest, 'flags': {}})
        StremioCloud._api('addonCollectionSet', {'authKey': key, 'addons': collection})
        return merged

    @staticmethod
    def cloud_progress(rows, direction='both'):
        key = StremioCloud._auth_key()
        merged = rows or []
        items = StremioCloud._api('datastoreGet', {'authKey': key, 'collection': StremioCloud.LIB, 'all': True}) or []
        by_id = {}
        for it in items:
            if it and it.get('_id'):
                by_id[it['_id']] = it
        if direction != 'push':
            merged = _union_progress(rows, StremioCloud._library_to_local(items))
        if direction != 'pull':
            changes = StremioCloud._progress_for_stremio(merged, by_id)
            changes = [_clean_stremio_row(c)[0] for c in (changes or [])]
            if changes:
                StremioCloud._api('datastorePut', {'authKey': key, 'collection': StremioCloud.LIB, 'changes': changes})
        return merged

    @staticmethod
    def mend_library():
        key = StremioCloud._auth_key()
        items = StremioCloud._api('datastoreGet', {'authKey': key, 'collection': StremioCloud.LIB, 'all': True}) or []
        fixes = []
        for it in items:
            fixed, changed = _clean_stremio_row(it)
            if changed:
                fixes.append(fixed)
        if fixes:
            StremioCloud._api('datastorePut', {'authKey': key, 'collection': StremioCloud.LIB, 'changes': fixes})
        return len(items), len(fixes)


# ── merge helpers (shared) ─────────────────────────────────────────────────
def _manifest_address(url):
    if not url:
        return url
    path, sep, query = url.partition('?')
    path = path.rstrip('/')
    if not path.endswith('/manifest.json'):
        path += '/manifest.json'
    return path + (('?' + query) if sep else '')


def _union_by_address(local, remote):
    seen = {}
    for x in local or []:
        u = (x.get('manifest_url') or x.get('transportUrl') or x.get('url') or '').lower()
        if u:
            seen[u] = x
    for x in remote or []:
        u = (x.get('manifest_url') or x.get('transportUrl') or x.get('url') or '').lower()
        if u and u not in seen:
            seen[u] = x
    return list(seen.values())


def _union_collections(local, remote):
    by_id = {}
    for c in local or []:
        by_id[c.get('id') or c.get('name')] = c
    for c in remote or []:
        k = c.get('id') or c.get('name')
        if k not in by_id:
            by_id[k] = c
    return list(by_id.values())


def _union_progress(local, remote):
    from resources.lib.progress_model import identity, timestamp
    result = {}
    for row in list(local or []) + list(remote or []):
        key = identity(row)
        previous = result.get(key)
        if previous is None or timestamp(row.get('updated_at')) > timestamp(previous.get('updated_at')):
            result[key] = row
    return list(result.values())


# the one time form Stremio's library takes back: 2024-05-01T20:15:00(.123)Z
_STREMIO_TIME = re.compile(r'\d{4}(?:-\d\d){2}T\d\d(?::\d\d){2}(?:\.\d{1,9})?Z$', re.ASCII)
_ISO_OUT = '%Y-%m-%dT%H:%M:%S.000Z'
_ISO_IN = '%Y-%m-%dT%H:%M:%S'


def _iso_is_valid(value):
    return bool(value) and _STREMIO_TIME.match(str(value)) is not None


def _parse_ts(iso):
    """Seconds since 1970 of an ISO time (its first 19 characters); now when it is none."""
    try:
        return calendar.timegm(time.strptime(str(iso)[:19], _ISO_IN)) if iso else time.time()
    except Exception:
        return time.time()


def _to_iso(epoch):
    try:
        moment = time.gmtime(int(epoch))
    except Exception:
        moment = time.gmtime()
    return time.strftime(_ISO_OUT, moment)


def _coerce_iso(value, fallback_epoch=None):
    """Any time Stremio might hold, in its strict form; ``fallback_epoch`` (now) when it is none."""
    if _iso_is_valid(value):
        return str(value)
    try:
        return _to_iso(calendar.timegm(time.strptime(str(value or '').strip().replace(' ', 'T')[:19], _ISO_IN)))
    except Exception:
        return _to_iso(time.time() if fallback_epoch is None else fallback_epoch)


def _clean_stremio_row(item):
    """A library item as Stremio takes it back: strict times (_mtime, _ctime, lastWatched),
    a lastVidReleased it would refuse left out, 'watched' a string. (item, changed)."""
    if not isinstance(item, dict):
        return item, False
    out = dict(item)
    when = _parse_ts(out.get('_mtime')) if out.get('_mtime') else time.time()
    wrong = [key for key in ('_mtime', '_ctime') if not _iso_is_valid(out.get(key))]
    for key in wrong:
        out[key] = _coerce_iso(out.get(key), fallback_epoch=when)
    state = dict(out['state']) if isinstance(out.get('state'), dict) else None
    fixed = False
    if state is not None:
        if state.get('lastWatched') and not _iso_is_valid(state['lastWatched']):
            state['lastWatched'], fixed = _coerce_iso(state['lastWatched'], fallback_epoch=when), True
        if state.get('lastVidReleased') and not _iso_is_valid(state['lastVidReleased']):
            del state['lastVidReleased']
            fixed = True
        if 'watched' in state and not isinstance(state['watched'], str):
            state['watched'], fixed = str(state['watched'] or ''), True
    changed = bool(wrong) or fixed
    if changed and state is not None:
        out['state'] = state
    return out, changed


def _local_addon_rows():
    try:
        from . import addon_registry
        rows = addon_registry.list_providers() or []
    except Exception:
        return []
    return [{'manifest_url': r.get('manifest_url', ''), 'name': r.get('name', '')}
            for r in rows if r.get('manifest_url')]


def _local_library_rows(limit=1000):
    try:
        from resources.lib import library_titles
        return library_titles.list_favorites(limit=limit) or []
    except Exception:
        return []


def _store_cloud_library(rows):
    """The account's library titles added to ours (those we have stay as they are)."""
    if not isinstance(rows, list):
        return 0
    try:
        from resources.lib import library_titles
    except Exception:
        return 0
    try:
        have = library_titles.favorite_keys()
    except Exception:
        have = set()
    added, failed = 0, []
    for row in rows:
        kind, title_id = str(row.get('media_type') or 'movie'), str(row.get('canonical_id') or '')
        if not title_id or (kind, title_id) in have:
            continue
        try:
            library_titles.add(kind, title_id, row.get('title') or title_id, poster=row.get('poster') or '',
                               background=row.get('background') or '', year=int(row.get('year') or 0),
                               plot=row.get('plot') or '', source='nuvio')
        except Exception as exc:
            failed.append('%s (%s)' % (title_id, str(exc)[:50]))
        else:
            added += 1
    note = (', %d FAILED -> %s' % (len(failed), ' | '.join(failed[:3]))) if failed else ''
    _log('library writeback: %d added%s' % (added, note))
    return added


def _gather_collections():
    try:
        from resources.lib import shared_collections as collection_sets
        return collection_sets.list_sets() or []
    except Exception:
        return []


def _gather_progress(limit=400):
    try:
        from . import progress_db
        from resources.lib import nuvio_progress
        return nuvio_progress.pending(limit=limit)
    except Exception:
        return []


def _store_cloud_addons(providers):
    if not isinstance(providers, list):
        return 0
    try:
        from . import addon_registry
        from resources.lib import shared_collections as collection_sets
    except Exception:
        return 0
    have = set((r.get('manifest_url') or '').lower() for r in (addon_registry.list_providers() or []))
    added, failed = 0, []
    for p in providers:
        url = (p.get('manifest_url') or '').lower()
        if not url or url in have:
            continue
        try:
            collection_sets.addon_known(p.get('manifest_url'))
            added += 1
            have.add(url)
        except Exception:
            failed.append('provider request failed')
    if failed:
        _log('addon writeback: %d added, %d FAILED -> %s'
             % (added, len(failed), ' | '.join(failed[:5])))
    else:
        _log('addon writeback: %d added' % added)
    return added


def _store_cloud_collections(rows):
    if not isinstance(rows, list):
        return 0
    try:
        from resources.lib import shared_collections as collection_sets
        return int(collection_sets.import_sets(rows) or 0)
    except Exception as exc:
        _log('collection writeback failed: %s' % exc)
        return 0


_PROGRESS_TEXT = ('title', 'provider_name', 'poster', 'background', 'clearlogo', 'tmdb_id', 'imdb_id', 'tvdb_id',
                  'show_tmdb_id', 'native_server_id', 'native_item_id')


def _progress_entry(row):
    """One progress row from the cloud as progress_db keeps it, or None without an id."""
    title_id = row.get('canonical_id') or row.get('imdb_id') or row.get('tmdb_id') or ''
    if not title_id:
        return None
    position, length = float(row.get('position') or 0.0), float(row.get('duration') or 0.0)
    share = float(row.get('percent') or (100 * position / float(row['duration']) if row.get('duration') else 0))
    watched = float(row.get('percent') or 0) >= watched_percent() or row.get('event_type') == 'watched'
    entry = {key: row.get(key, '') for key in _PROGRESS_TEXT}
    entry.update(media_type='series' if row.get('media_type') in ('tv', 'series', 'show', 'episode') else 'movie',
                 canonical_id=title_id, video_id=row.get('video_id') or title_id, season=row.get('season'),
                 episode=row.get('episode'), position=position, duration=length, percent=share, stream_url='',
                 event_type='watched' if watched else 'account_sync', ext_updated_at=row.get('updated_at'))
    return entry


def _store_cloud_progress(rows):
    """The cloud's progress rows kept here (not sent back); how many changed."""
    if not isinstance(rows, list):
        return 0
    try:
        from . import progress_db
    except Exception:
        return 0
    pending = []
    for row in rows:
        try:
            entry = _progress_entry(row)
        except Exception:
            continue
        if entry:
            pending.append(entry)
    if not pending:
        return 0
    changed = int(progress_db.keep_rows(pending, mark_dirty=False) or 0)
    if changed:
        from resources.lib.simkl_watched import _invalidate_view
        _invalidate_view()
    return changed


_SAID = {}       # 8.1.2: what was last said about each service, so a state is said once


def _say_once(key, text):
    """A decision, not an event: logged when it changes, not on every ask.

    active_targets() is asked about twice a second while the interface is open, and it
    logged on every call - "nuvio is linked but its sync toggle is OFF - skipping" filled
    the log with one line every two seconds, which buries everything worth reading in it.
    """
    if _SAID.get(key) == text:
        return
    _SAID[key] = text
    _log(text)


def active_targets():
    out = []
    # 7.0 beta: Stremio joins only when its "Keep in sync" is switched on.
    if StremioCloud.is_linked() and str(_setting('stremio_sync_enabled', '') or '').strip().lower() == 'true':
        out.append('stremio')
    for svc, linked in (('nuvio', NuvioCloud.is_linked()),):
        if not linked:
            continue
        raw = str(_setting('%s_sync_enabled' % svc, '') or '').strip().lower()
        if raw in ('true', '1', 'yes', 'on'):
            _say_once(svc, '%s sync is on' % svc)
            out.append(svc)
            continue
        if raw in ('false', '0', 'no', 'off'):
            _say_once(svc, '%s is linked but its sync toggle is OFF — skipping' % svc)
            continue
        try:
            addon().setSetting('%s_sync_enabled' % svc, 'true')
        except Exception:
            pass
        _say_once(svc, '%s was linked with no sync toggle — enabling it now' % svc)
        out.append(svc)
    return out


def _sync_direction(svc):
    raw = _setting('%s_sync_direction' % svc, '')
    if raw in ('', 'Follow global'):
        raw = _setting('cloud_sync_direction', 'Two-way') or 'Two-way'
    if raw in ('Upload only'):
        return 'push'
    if raw in ('Download only'):
        return 'pull'
    return 'both'


def _cloud_sections(svc):
    return {
        'addons': _setting_bool('%s_sync_addons' % svc, True),
        'collections': _setting_bool('%s_sync_collections' % svc,
                                     svc == 'nuvio'),
        'progress': _setting_bool('%s_sync_progress' % svc, True),
        'library': (svc == 'nuvio') and _setting_bool('nuvio_sync_library', True),
    }


def _fingerprint(rows):
    try:
        import hashlib
        norm = sorted(
            json.dumps(r, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
            for r in (rows or []))
        return hashlib.sha1('\u0001'.join(norm).encode('utf-8', 'replace')).hexdigest()[:16]
    except Exception:
        return ''


_FP_FILE = os.path.join(profile_path(), 'account_sync_fp.json')
_LIB_STATE_FILE = os.path.join(profile_path(), 'nuvio_library_state.json')   # 7.0.44: the last agreed Library


def _load_sync_state():
    return read_json(_FP_FILE, {}) or {}


def _save_sync_state(state):
    try:
        write_json(_FP_FILE, state)
    except Exception:
        pass


def sync_round(direction=None, targets=None, force_full=False, sections=None):
    targets = [svc for svc in (targets or active_targets()) if svc in ('nuvio', 'stremio')]
    if not targets:
        return {'ok': False, 'error': 'no linked/enabled accounts'}

    svc_dir = dict((svc, direction or _sync_direction(svc)) for svc in targets)
    svc_sections = dict((svc, dict(sections) if sections else _cloud_sections(svc))
                        for svc in targets)
    # what any of the services syncs is gathered here once
    want = dict((part, any(chosen.get(part) for chosen in svc_sections.values()))
                for part in ('addons', 'collections', 'progress', 'library'))
    gather = {'addons': _local_addon_rows, 'collections': _gather_collections,
              'progress': _gather_progress, 'library': _local_library_rows}
    addons, collections, progress, merged_library = (gather[part]() if want[part] else []
                                                     for part in ('addons', 'collections', 'progress', 'library'))
    fp_addons, fp_collections = _fingerprint(addons), _fingerprint(collections)
    # progress goes up from the durable outbox - already exactly what changed, per profile
    progress_delta_push = progress
    from resources.lib import nuvio_progress
    sync_scope = nuvio_progress.scope()
    plan = []
    for svc in targets:
        parts = [part for part in ('addons', 'collections', 'progress') if svc_sections[svc].get(part)]
        plan.append('%s[%s:%s]' % (svc, svc_dir[svc], ','.join(parts) or 'none'))
    _log('sync plan: ' + ' '.join(plan))
    report = []
    merged = {'addons': list(addons), 'collections': list(collections), 'progress': list(progress), 'library': merged_library}
    for svc in targets:
        d, sec = svc_dir[svc], svc_sections[svc]
        impl = NuvioCloud if svc == 'nuvio' else StremioCloud
        done = {'service': svc, 'ok': False, 'direction': d, 'sections': {}}
        if svc == 'stremio' and sec.get('collections'):
            done['sections']['collections'] = {
                'ok': False,
                'error': 'Stremio account stores add-ons and library progress, not folder layouts; use JSON import for collections.'}
        # each part: is it synced here, and how. Collections and add-ons only come from the
        # account (Nuvio owns the layout and the add-on set-up - local presets never go up);
        # progress goes up from the outbox, only what changed
        steps = (('collections', svc == 'nuvio' and sec.get('collections'),
                  lambda: impl.cloud_collections(merged['collections'], 'pull')),
                 ('addons', sec.get('addons'), lambda: impl.cloud_addons(merged['addons'], 'pull')),
                 ('progress', sec.get('progress'),
                  lambda: impl.cloud_progress(progress_delta_push if d in ('both', 'push') else merged['progress'], d)),
                 ('library', sec.get('library') and hasattr(impl, 'cloud_library'),
                  lambda: impl.cloud_library(merged['library'], d)))
        for part, wanted, step in steps:
            if not wanted:
                continue
            try:
                merged[part] = step()
                done['sections'][part] = {'ok': True, 'count': len(merged[part])}
                done['ok'] = True
            except Exception as exc:
                done['sections'][part] = {'ok': False, 'error': str(exc)}
                _log('%s %s sync failed: %s' % (svc, part, exc))
        report.append(done)
    merged_addons, merged_collections, merged_progress, merged_library = (
        merged[part] for part in ('addons', 'collections', 'progress', 'library'))

    if nuvio_progress.scope() != sync_scope:
        return {'ok': False, 'error': 'Profile changed; the previous response was not applied.'}
    # what was pulled from any account is kept here
    wb = {'providers': 0, 'collections': 0, 'progress': 0, 'library': 0}
    keep = (('addons', 'providers', _store_cloud_addons, merged_addons),
            ('collections', 'collections', _store_cloud_collections, merged_collections),
            ('progress', 'progress', _store_cloud_progress, merged_progress),
            ('library', 'library', _store_cloud_library, merged_library))
    for part, counted, store, rows in keep:
        if any(svc_dir[svc] != 'push' and svc_sections[svc].get(part) for svc in targets):
            wb[counted] = store(rows)

    ok = any(row.get('ok') for row in report)
    now = int(time.time())
    if ok:
        _save_sync_state({'last_ok_at': now, 'fp_addons': fp_addons, 'fp_collections': fp_collections})
    try:
        addon().setSetting('last_account_sync_at', str(now))
    except Exception:
        pass
    _log('sync result: providers +%(providers)d collections +%(collections)d progress %(progress)d library +%(library)d' % wb)
    return {'ok': ok, 'report': report, 'writeback': wb,
            'totals': dict((part, len(merged[part])) for part in ('addons', 'collections', 'progress', 'library'))}
