"""MDBList as a tracking service (7.0.12), next to Trakt and Simkl.

Uses the MDBList API key from HUB Settings > API keys (?apikey=...; the key
is never logged). Follows MDBList's own Kodi scrobbler:

* playback: POST /scrobble/start | pause | stop with {"movie": {"ids"}} or
  {"show": {"ids", "season": {"number", "episode": {"number"}}}} and the
  progress in percent; MDBList records the watch when a stop is far enough;
* watched marks: GET /sync/last_activities, then /sync/watched (cursor pages)
  only when the watched time moved; stored per key in mdblist_watched.json in
  the format of trakt_watched, merged into the one watched view
  (simkl_watched.snapshot).

MDBList allows 300 writes and 1000 reads per 5 minutes: writes are spaced
WRITE_GAP seconds apart and a 429 waits for Retry-After once.
"""
import hashlib
import json
import os
import threading
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE = 'https://api.mdblist.com'
SETTING = 'mdblist_tracking'
KEY_SETTING = 'mdblist_api_key'
WRITE_GAP = 1.1
TIMEOUT = 10
_WRITE = {'lock': threading.Lock(), 'next': 0.0}


def _addon():
    from .settings_cache import cached_addon
    return cached_addon()


def api_key():
    try:
        return (_addon().getSetting(KEY_SETTING) or '').strip()
    except Exception:
        return ''


def enabled():
    try:
        on = (_addon().getSetting(SETTING) or 'false').lower() == 'true'
    except Exception:
        on = False
    return bool(on and api_key())


def _version():
    try:
        return _addon().getAddonInfo('version') or '7'
    except Exception:
        return '7'


def request(method, path, payload=None, params=None, key=None, timeout=TIMEOUT):
    """JSON from MDBList; raises ValueError with a short reason on failure."""
    key = key or api_key()
    if not key:
        raise ValueError('Add your MDBList API key in HUB Settings > API keys.')
    query = dict(params or {})
    query['apikey'] = key
    url = '%s%s?%s' % (BASE, path, urlencode(query))
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    if method != 'GET':
        with _WRITE['lock']:
            wait = _WRITE['next'] - time.monotonic()
            _WRITE['next'] = max(_WRITE['next'], time.monotonic()) + WRITE_GAP
        if wait > 0:
            time.sleep(wait)
    for attempt in (0, 1):
        req = Request(url, data=body, method=method,
                      headers={'Content-Type': 'application/json', 'Accept': 'application/json',
                               'User-Agent': 'MegaNexus/%s' % _version()})
        try:
            with urlopen(req, timeout=timeout) as response:
                text = response.read().decode('utf-8', 'replace')
            return json.loads(text) if text.strip() else {}
        except Exception as exc:
            code = getattr(exc, 'code', None)
            if code == 429 and not attempt:
                try:
                    delay = int(exc.headers.get('Retry-After') or 5)
                except Exception:
                    delay = 5
                if delay <= 30:
                    time.sleep(delay)
                    continue
            if code in (401, 403):
                raise ValueError('MDBList did not accept the API key.')
            raise ValueError('MDBList %s' % (code or type(exc).__name__))
    raise ValueError('MDBList is busy (rate limit).')


def check(key=None):
    """True when MDBList answers with this key (Settings test)."""
    data = request('GET', '/sync/last_activities', key=key)
    return isinstance(data, dict) and 'server_time' in data


# ---- playback ---------------------------------------------------------
def _ids(ctx):
    from .trakt import _ids_payload
    return _ids_payload(ctx or {})


def _progress(ctx, position_ms):
    try:
        duration = float((ctx or {}).get('duration_ms') or 0)
    except (TypeError, ValueError):
        duration = 0
    if duration <= 0:
        return 0.0
    return max(0.0, min(100.0, float(position_ms or 0) / duration * 100.0))


def payload(ctx, position_ms=0):
    ctx = ctx or {}
    ids = _ids(ctx)
    if not ids:
        return None
    body = {'progress': round(_progress(ctx, position_ms), 2), 'app_version': _version()}
    media = str(ctx.get('media_type') or 'movie').lower()
    if media in ('series', 'show', 'tv', 'anime', 'episode') or ctx.get('season') or ctx.get('episode'):
        try:
            season, episode = int(ctx.get('season') or 0), int(ctx.get('episode') or 0)
        except (TypeError, ValueError):
            return None
        if not episode:
            return None
        body['show'] = {'ids': ids, 'season': {'number': season, 'episode': {'number': episode}}}
    else:
        body['movie'] = {'ids': ids}
    return body


def scrobble(action, ctx, position_ms=0):
    """Safe for the player: never raises. action: start | pause | stop."""
    if not enabled():
        return None
    try:
        body = payload(ctx, position_ms)
        if not body:
            return None
        if action in ('pause', 'stop') and body['progress'] <= 0.5:
            return None   # playback failed before the first frame
        return request('POST', '/scrobble/%s' % action, payload=body)
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[MegaNexus] MDBList scrobble %s skipped: %s' % (action, exc), xbmc.LOGINFO)
        except Exception:
            pass
        return None


# ---- watched marks ----------------------------------------------------
def _path():
    from .meganexus.common import profile_path
    return os.path.join(profile_path(), 'mdblist_watched.json')


def account():
    key = api_key()
    return hashlib.sha256(key.encode()).hexdigest() if key else ''


def snapshot():
    """{'account', 'updated', 'activities', 'items'} - no network."""
    if not enabled():
        return {'items': {}}
    try:
        with open(_path(), encoding='utf-8') as stream:
            data = json.load(stream)
    except (OSError, ValueError):
        return {'items': {}}
    if not isinstance(data, dict) or data.get('account') != account():
        return {'items': {}}
    return data


def forget():
    try:
        os.remove(_path())
    except OSError:
        pass


def _aliases(ids):
    from .simkl_watched import aliases
    return aliases({k: v for k, v in (ids or {}).items() if k in ('imdb', 'tmdb', 'tvdb')})


def _stamp(text):
    try:
        from .trakt import _parse_trakt_ts
        return _parse_trakt_ts(text)
    except Exception:
        return None


def parse(data):
    """/sync/watched rows -> watched items in the trakt_watched format."""
    items = {}
    for row in (data or {}).get('movies') or []:
        movie = (row or {}).get('movie') or {}
        entry = {'watched': True, 'episodes': [], 'seasons': []}
        stamp = _stamp(row.get('last_watched_at'))
        if stamp:
            entry['watched_at'] = stamp
        for mid in _aliases(movie.get('ids')):
            items['movie|' + mid] = entry
    shows = {}
    for row in (data or {}).get('episodes') or []:
        episode = (row or {}).get('episode') or {}
        show_ids = ((episode.get('show') or {}).get('ids')) or {}
        aliases = _aliases(show_ids)
        if not aliases or episode.get('number') is None:
            continue
        key = '%s:%s' % (episode.get('season'), episode.get('number'))
        entry = shows.setdefault(aliases[0], {'aliases': aliases, 'episodes': set(), 'times': {}})
        entry['episodes'].add(key)
        stamp = _stamp(row.get('last_watched_at'))
        if stamp:
            entry['times'][key] = stamp
    for show in shows.values():
        entry = {'watched': False, 'episodes': sorted(show['episodes']), 'seasons': []}
        if show['times']:
            entry['episode_watched_at'] = show['times']
        for mid in show['aliases']:
            items['series|' + mid] = entry
    return items


def _pages(path):
    merged, cursor = {}, None
    for _ in range(200):   # 200 pages of 1000 - far beyond any history
        params = {'limit': 1000}
        if cursor:
            params['cursor'] = cursor
        data = request('GET', path, params=params, timeout=20)
        if not isinstance(data, dict):
            raise ValueError('MDBList did not return the watched list.')
        for name, value in data.items():
            if isinstance(value, list):
                merged.setdefault(name, []).extend(value)
        cursor = (data.get('pagination') or {}).get('next_cursor')
        if not cursor:
            break
    return merged


def refresh(force=False, max_age=900):
    if not enabled():
        return {'items': {}}
    old = snapshot()
    now = time.time()
    if not force and now - float(old.get('updated') or 0) < max_age:
        return old
    activities = request('GET', '/sync/last_activities')
    if not isinstance(activities, dict) or 'server_time' not in activities:
        raise ValueError('MDBList did not return its activity times.')
    watched_at = json.dumps({k: v for k, v in activities.items() if 'watch' in k.lower()}, sort_keys=True)
    items = old.get('items') or {}
    changed = False
    if force or not old.get('items') or watched_at != old.get('watched_at'):
        items = parse(_pages('/sync/watched'))
        changed = True
    result = {'account': account(), 'updated': now, 'watched_at': watched_at, 'items': items}
    path = _path()
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as stream:
        json.dump(result, stream)
    os.replace(tmp, path)
    if changed:
        try:
            from .simkl_watched import _invalidate_view
            _invalidate_view()
        except Exception:
            pass
    return result
