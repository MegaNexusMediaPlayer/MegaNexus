"""One persistent weather/clock preference for every MegaNexus surface."""
import xbmc
import xbmcaddon
import xbmcgui

KEY = 'meganexus_hide_weather_clock'
PROPERTY = 'meganexus.hide_weather_clock'


def hidden():
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    return addon.getSetting(KEY) == 'true' or xbmc.getCondVisibility('Skin.HasSetting(meganexus.hideweather)')


def sync():
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    # Preserve a user's old skin setting on upgrade. Do not migrate from an
    # unrelated skin before MegaNexus has loaded its own saved preferences.
    if addon.getSetting('meganexus_weather_clock_migrated') != 'true' and xbmc.getSkinDir() == 'skin.meganexus':
        if xbmc.getCondVisibility('Skin.HasSetting(meganexus.hideweather)'):
            addon.setSetting(KEY, 'true')
        addon.setSetting('meganexus_weather_clock_migrated', 'true')
    value = hidden()
    xbmcgui.Window(10000).setProperty(PROPERTY, '1' if value else '')
    return value


def set_hidden(value):
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    addon.setSetting(KEY, 'true' if value else 'false')
    addon.setSetting('meganexus_weather_clock_migrated', 'true')
    xbmcgui.Window(10000).setProperty(PROPERTY, '1' if value else '')
    xbmc.executebuiltin(('Skin.SetBool' if value else 'Skin.Reset') + '(meganexus.hideweather)', True)
    from . import settings_cache
    settings_cache.invalidate()
