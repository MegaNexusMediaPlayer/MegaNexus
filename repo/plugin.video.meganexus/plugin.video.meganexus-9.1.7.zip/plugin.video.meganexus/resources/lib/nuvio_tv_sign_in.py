# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.7: signing in to Nuvio the way its TV app does (issues #50, #53, #55).

Nuvio refuses password sign-ins from MegaNexus ("Too many requests", on the first try too), while sessions already
signed in go on. Here the box shows a QR code and a short code; the person opens nuvio.tv/link on the phone, signs in
there with the Nuvio account and confirms; the box takes the session (cloud_sync.NuvioCloud.tv_*). No password passes
through the box.
"""
import time

import xbmc
import xbmcgui

from . import plex_link_window
from .meganexus import cloud_sync as sync

HEADING = 'Sign in to Nuvio'
WORDS = ('Scan the QR code with your phone, or open\n'
         '%s and enter the code:\n\n'
         '[B]%%s[/B]\n\n'
         'Sign in there and confirm.\n'
         'Waiting… (Back to cancel)')               # as many lines as Plex's in the same box
MOST = 900          # s: Nuvio ends the code itself ('expired'); a guard for one that never says so
FAILURES = 5        # looks in a row that got no answer: Nuvio is not reachable


def _trouble(exc):
    """What to say when this sign-in failed - in its own words (no password here); the reason goes to the log
    (cloud_sync.sign_in_trouble, no account in it)."""
    said, code = sync.sign_in_trouble(exc), getattr(exc, 'code', None)
    if code == 429 or 'too many' in str(exc).lower():
        return 'Nuvio is refusing for now (too many requests). Wait a few minutes, then try again.'
    if code in (400, 401, 403):
        return 'Nuvio did not take the sign-in (%s). Choose Sign in · QR code again for a new code.' % str(exc)[:80]
    return said


def _wait(started, window, monitor=None):
    """'approved', or how it ended: 'expired' / 'used' / 'cancelled' (Nuvio's), None (Back, or Kodi closing), or the
    exception of the last of FAILURES looks without an answer."""
    monitor = monitor or xbmc.Monitor()
    ends, failures = time.monotonic() + MOST, 0
    pause = max(2, int(started.get('poll_interval_seconds') or 3))
    while time.monotonic() < ends:
        if window.cancelled or monitor.waitForAbort(pause) or window.cancelled:
            return None
        try:
            status, pause = sync.NuvioCloud.tv_status(started)
            failures = 0
        except Exception as exc:
            failures += 1
            if failures >= FAILURES:
                return exc
            continue
        if status in ('approved', 'expired', 'used', 'cancelled'):
            return status
    return 'expired'


def sign_in():
    """True when signed in; None when the person went Back; False when it failed (said in a dialog)."""
    dialog = xbmcgui.Dialog()
    try:
        started = sync.NuvioCloud.tv_start()
    except Exception as exc:
        dialog.ok('Nuvio account', _trouble(exc))
        return False
    page = started.get('verification_uri') or sync.TV_LINK
    picture = plex_link_window.qr_png(started.get('verification_uri_complete') or page)
    window = plex_link_window.PlexLinkWindow(qr_path=picture, code=started['user_code'], heading=HEADING,
                                             text=WORDS % page.split('://', 1)[-1])
    window.show()
    try:
        outcome = _wait(started, window)
    finally:
        window.close()
    if outcome is None:
        return None
    if outcome != 'approved':
        dialog.ok('Nuvio account', _trouble(outcome) if isinstance(outcome, Exception) else
                  'The sign-in was not confirmed in time. Choose Sign in · QR code again for a new code.')
        return False
    try:
        sync.NuvioCloud.tv_finish(started)
    except Exception as exc:
        dialog.ok('Nuvio account', _trouble(exc))
        return False
    sync._log('Nuvio: signed in with the TV sign-in (nuvio.tv/link)')
    return True
