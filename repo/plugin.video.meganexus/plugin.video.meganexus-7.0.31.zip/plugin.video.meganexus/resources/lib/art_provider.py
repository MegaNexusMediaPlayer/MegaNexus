"""Artwork from the provider you choose (7.0.29, HUB Settings > Home & appearance > Artwork).

Posters, backgrounds, logos and landscape cards normally come from the
catalog (the metadata add-on). Each of them can come from TMDB or Fanart.tv
instead - with the API keys connected in Connections > API keys. A title the
provider has no picture for keeps the catalog's; nothing ever goes blank.

Lookups are cached by tmdb_direct (30 days) and fanarttv (14 days). Screens
built from the cache (``cached_only``) never touch the network; the next
fresh load fetches what is missing, a few titles at a time.
"""
from concurrent.futures import ThreadPoolExecutor

KINDS = ('poster', 'fanart', 'clearlogo', 'landscape')
LABELS = {'poster': 'Posters', 'fanart': 'Backgrounds', 'clearlogo': 'Title logos',
          'landscape': 'Landscape cards'}
SETTINGS = {'poster': 'meganexus_art_poster', 'fanart': 'meganexus_art_background',
            'clearlogo': 'meganexus_art_logo', 'landscape': 'meganexus_art_landscape'}
PROVIDERS = ('catalog', 'tmdb', 'fanart')
PROVIDER_LABELS = {'catalog': 'From the catalog', 'tmdb': 'TMDB', 'fanart': 'Fanart.tv'}
LANGUAGE = 'meganexus_art_language'
LANGUAGES = ('en', 'kodi', 'textless')
LANGUAGE_LABELS = {'en': 'English', 'kodi': "Kodi's language, then English", 'textless': 'Without text where possible'}
WORKERS = 6


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_cache import cached_addon
    return cached_addon()


def choice(kind, addon=None):
    value = (_addon(addon).getSetting(SETTINGS[kind]) or '').strip()
    return value if value in PROVIDERS else 'catalog'


def language(addon=None):
    value = (_addon(addon).getSetting(LANGUAGE) or '').strip()
    return value if value in LANGUAGES else 'en'


def connected(provider, addon=None):
    """A provider is offered when its API key is connected."""
    if provider == 'catalog':
        return True
    key = {'tmdb': 'tmdb_api_key', 'fanart': 'fanarttv_api_key'}[provider]
    return bool((_addon(addon).getSetting(key) or '').strip())


def active(addon=None):
    addon = _addon(addon)
    return {kind: choice(kind, addon) for kind in KINDS
            if choice(kind, addon) != 'catalog' and connected(choice(kind, addon), addon)}


def _tmdb_langs(addon=None):
    mode = language(addon)
    if mode == 'textless':
        return ['null', 'en']
    if mode == 'kodi':
        try:
            import xbmc
            own = (xbmc.getLanguage(xbmc.ISO_639_1) or '').lower()
        except Exception:
            own = ''
        return [x for x in (own, 'en', 'null') if x][:3] if own != 'en' else ['en', 'null']
    return ['en', 'null']


def ids(target):
    """(imdb, tmdb, tvdb, kind) of a card's target / a title's meta."""
    target = target or {}
    raw = str(target.get('canonical_id') or target.get('id') or '')
    imdb = str(target.get('imdb_id') or target.get('imdbId') or (raw if raw.startswith('tt') else '')).split(':')[0]
    tmdb = str(target.get('tmdb_id') or target.get('tmdbId') or (raw.split(':')[1] if raw.startswith('tmdb:') else ''))
    tvdb = str(target.get('tvdb_id') or '')
    kind = str(target.get('media_type') or target.get('type') or 'movie').lower()
    kind = 'series' if kind in ('series', 'show', 'tv', 'tvshow', 'anime', 'episode', 'season') else 'movie'
    return imdb, tmdb, tvdb, kind


def _tmdb(target, langs, cached_only):
    from . import tmdb_direct
    imdb, tmdb, _, kind = ids(target)
    if not (imdb or tmdb):
        return {}
    found = tmdb_direct.art_for(tmdb_id=tmdb, imdb_id=imdb, media_type=kind, langs=langs, cached_only=cached_only)
    return found


def _fanart(target, cached_only):
    from . import fanarttv
    imdb, tmdb, tvdb, kind = ids(target)
    if kind == 'series' and not tvdb:
        # Fanart.tv knows series by their TheTVDB id; TMDB's external ids give it.
        found = _tmdb(target, ['en', 'null'], cached_only)
        if found is None:
            return None
        tvdb = (found or {}).get('tvdb_id') or ''
        tmdb = tmdb or (found or {}).get('tmdb_id') or ''
        if not tvdb:
            return {}
    if not (imdb or tmdb or tvdb):
        return {}
    return fanarttv.get_art(kind, tmdb_id=tmdb, tvdb_id=tvdb, imdb_id=imdb, cached_only=cached_only, force=True)


def pictures(target, wanted, cached_only=False, addon=None):
    """{kind: url} for the wanted kinds ({kind: provider}); None = not cached yet."""
    found, missing = {}, False
    langs = _tmdb_langs(addon)
    by_provider = {}
    for kind, provider in wanted.items():
        by_provider.setdefault(provider, []).append(kind)
    for provider, kinds in by_provider.items():
        try:
            art = _tmdb(target, langs, cached_only) if provider == 'tmdb' else _fanart(target, cached_only)
        except Exception:
            art = {}
        if art is None:
            missing = True
            continue
        for kind in kinds:
            if provider == 'fanart' and kind == 'poster' and language(addon) == 'textless':
                url = art.get('poster_textless') or art.get('poster')
            elif provider == 'tmdb' and kind == 'landscape':
                url = art.get('landscape') or art.get('fanart')
            else:
                url = art.get(kind)
            if url:
                found[kind] = url
    return None if missing and not found else found


def _merge(row, art):
    row = dict(row)
    for kind, url in art.items():
        row[kind] = url
    target = row.get('target')
    if isinstance(target, dict) and isinstance(target.get('ui_seed'), dict):
        seed = dict(target['ui_seed'])
        seed.update({k: v for k, v in art.items() if k in ('poster', 'fanart', 'clearlogo')})
        row['target'] = dict(target, ui_seed=seed)
    return row


def apply(rows, cached_only=False, stopped=None, addon=None):
    """Cards with the chosen provider's pictures (the catalog's where it has none)."""
    wanted = active(addon)
    if not wanted or not rows:
        return rows
    jobs = [(index, row) for index, row in enumerate(rows)
            if isinstance(row, dict) and isinstance(row.get('target'), dict) and any(ids(row['target'])[:3])]
    if not jobs:
        return rows
    out = list(rows)

    def one(job):
        index, row = job
        if stopped and stopped():
            return index, None
        return index, pictures(row['target'], wanted, cached_only, addon)

    if cached_only or len(jobs) == 1:
        results = [one(job) for job in jobs]
    else:
        with ThreadPoolExecutor(max_workers=min(WORKERS, len(jobs)), thread_name_prefix='MegaNexusArtwork') as pool:
            results = list(pool.map(one, jobs))
    for index, art in results:
        if art:
            out[index] = _merge(out[index], art)
        elif art is None and cached_only:
            # Not fetched yet: the screen shows the catalog's picture now and
            # loads this row once more (Home: pending()).
            out[index] = dict(out[index], _art_pending=True)
    return out


def pending(rows):
    """True when a row painted from the cache still waits for the provider's pictures."""
    return any(isinstance(row, dict) and row.get('_art_pending') for row in rows or [])


def meta(title_meta, cached_only=False, addon=None):
    """A title's own meta (details, playback) with the chosen pictures."""
    wanted = active(addon)
    if not wanted or not isinstance(title_meta, dict):
        return title_meta
    art = pictures(title_meta, wanted, cached_only, addon) or {}
    if not art:
        return title_meta
    out = dict(title_meta)
    if art.get('poster'):
        out['poster'] = art['poster']
    if art.get('fanart'):
        out['background'] = out['fanart'] = art['fanart']
    if art.get('clearlogo'):
        out['logo'] = out['clearlogo'] = art['clearlogo']
    return out


def summary(addon=None):
    addon = _addon(addon)
    chosen = active(addon)
    if not chosen:
        return 'From the catalog'
    names = sorted(set(PROVIDER_LABELS[p] for p in chosen.values()))
    return ' + '.join(names)
