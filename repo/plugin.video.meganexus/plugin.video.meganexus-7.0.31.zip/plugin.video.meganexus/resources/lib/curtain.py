"""A black curtain around the TV's refresh-rate switch (7.0.29).

With Kodi's "Adjust display refresh rate" on, every TV blinks when a film
starts and again when it ends (the mode switch). Like the screensaver's
entry, MegaNexus fades to black first, lets the switch happen behind it,
then fades the picture back in. Nothing is shown when the setting is off -
there is no blink to hide then. (An HDR film's switch is handled without
black: playback.py hands over to the video at once - hdr_switches.)
"""
import json
import threading
import time

import xbmc
import xbmcgui

WHITE = 'special://home/addons/script.meganexus/resources/media/white.png'
SETTLE = 1.2      # seconds the TV takes to show the new mode


def _setting(name):
    """The setting's value, or None when this Kodi has no such setting."""
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                                                           'params': {'setting': name}})))
    except Exception:
        return None
    result = reply.get('result') if isinstance(reply, dict) else None
    return result.get('value') if isinstance(result, dict) else None


def afr_on():
    return bool(_setting('videoplayer.adjustrefreshrate'))


def hdr_switches():
    """Does an HDR video switch the display? Kodi's "Adjust display HDR mode" where
    it exists (Windows, Wayland); elsewhere the TV follows the video by itself."""
    value = _setting('winsystem.ishdrdisplay')
    return True if value is None else bool(value)


class _Black(xbmcgui.WindowDialog):
    """Back / Esc do not lift the curtain (7.0.29: the display was seen switching)."""
    def onAction(self, action):
        pass


class Curtain(object):
    def __init__(self, fade_in=600, fade_out=700):
        self.window = None
        self.fade_in = fade_in
        self.fade_out = fade_out
        try:
            self.window = _Black()
            black = xbmcgui.ControlImage(0, 0, 1280, 720, WHITE, colorDiffuse='FF000000')
            self.window.addControl(black)
            animations = [('WindowClose', 'effect=fade start=100 end=0 time=%d tween=sine easing=inout' % fade_out)]
            if fade_in:
                animations.append(('WindowOpen', 'effect=fade start=0 end=100 time=%d tween=sine easing=inout' % fade_in))
            black.setAnimations(animations)
            self.window.show()
        except Exception as exc:
            xbmc.log('[MegaNexus] Curtain unavailable: %r' % exc, xbmc.LOGWARNING)
            self.window = None

    def wait_black(self, monitor=None):
        """Until the fade-in has covered the screen."""
        (monitor or xbmc.Monitor()).waitForAbort(self.fade_in / 1000.0)

    def close(self, after=0.0, background=False):
        """Fade out after ``after`` seconds. The caller waits until the fade has ended:
        a script that finished meanwhile left the closing window behind - a dead modal
        dialog over the player that swallowed every key (7.0.29). ``background`` only
        in the long-lived service."""
        window, self.window = self.window, None
        if window is None:
            return

        def run():
            monitor = xbmc.Monitor()
            if after:
                monitor.waitForAbort(after)
            try:
                window.close()
            except Exception:
                pass
            monitor.waitForAbort(self.fade_out / 1000.0 + 0.15)   # the close animation ends while we live
        if background:
            threading.Thread(target=run, name='MegaNexusCurtain', daemon=True).start()
        else:
            run()


def for_start():
    """Before a film starts: black over the loading screen (None when AFR is off)."""
    if not afr_on():
        return None
    curtain = Curtain()
    curtain.wait_black()
    return curtain


def after_stop():
    """A film ended: black at once, the picture back once the TV has switched."""
    if not afr_on():
        return
    Curtain(fade_in=0).close(after=SETTLE + 0.6, background=True)   # from the service
