# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Small home payloads. Local shelves first; bounded catalog work on demand."""
import json
from urllib.parse import urlsplit, parse_qs

MAX_ROWS = 12            # 8.1.0: was 24 - a view with more rows is drawn a page at a time (7.0.48)
PAGE_SIZE = 16


def _api():
    from . import hub
    return hub


def placeholder(title, plot, path='', folder=True):
    return {'title': title, 'plot': plot, 'path': path, 'is_folder': folder,
            'poster': '', 'fanart': '', 'subtitle': 'Browse', 'meta_line': ''}


def media_card(meta, provider=None, media_type='movie', next_episode=False):
    if (meta or {}).get('type',media_type) in ('person','people','actor'):
        from .search_catalogs import person_card
        return person_card(meta,provider)
    p = _api()
    meta = dict(meta or {})
    from .display_text import clean
    title = clean(meta.get('name') or meta.get('title') or 'Untitled').strip()
    mid = str(meta.get('id') or meta.get('canonical_id') or '')
    media_type = meta.get('type') or meta.get('media_type') or media_type
    poster = meta.get('poster') or ''
    fanart = meta.get('background') or meta.get('fanart') or ''
    logo = meta.get('clearlogo') or meta.get('logo') or ''
    year = str(meta.get('year') or meta.get('releaseInfo') or '')[:4]
    series = media_type in ('series', 'show', 'tv', 'tvshow', 'anime')
    subtitle = year
    if next_episode:
        subtitle = 'S%s E%s' % (meta.get('season') or '', meta.get('episode') or '')
    ids = p.extract_ids(meta)
    from .trailer_support import trailer_url
    rating = rating_label(meta)
    return {
        'trailer': trailer_url(meta),
        'title': title, 'subtitle': subtitle, 'poster': poster, 'fanart': fanart,
        'clearlogo': logo, 'plot': meta.get('description') or meta.get('overview') or meta.get('plot') or '',
        # 7.0.29: the score is drawn as the service's logo + number (ratings_row), never text.
        'meta_line': '  |  '.join(x for x in ('Series' if series else 'Movie', year) if x),
        'rating': rating, 'rating_icon': rating_icon(rating), 'rating_value': rating.split(' ', 1)[-1] if rating else '',
        'target': dict(media_type=media_type, canonical_id=mid, title=title,
                       source_provider_id=(provider or {}).get('id') or '',
                       season=meta.get('season') if next_episode else '',
                       episode=meta.get('episode') if next_episode else '',
                       video_id=meta.get('video_id') if next_episode else '',
                       tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                       tvdb_id=ids.get('tvdb_id') or '',
                       ui_seed={'poster': poster, 'fanart': fanart, 'clearlogo': logo}),
        'is_folder': series and not next_episode,
        'released': str(meta.get('released') or ''),        # 7.0.32: Hide unreleased titles
        'releaseInfo': str(meta.get('releaseInfo') or meta.get('year') or ''),
    }


def rating_icon(label):
    """The logo for a rating_label() ('IMDb 7.8' -> IMDb's logo)."""
    if not label:
        return ''
    from .ratings_row import LOGOS
    return LOGOS['tmdb'] if label.startswith('TMDb') else LOGOS['imdb']


def rating_label(meta):
    """'IMDb 7.8' from the metadata add-on's own fields; '' when it supplies none
    or ratings are switched off in Settings > Appearance."""
    try:
        from .settings_snapshot import cached_addon
        if cached_addon().getSetting('meganexus_show_ratings') == 'false':
            return ''
    except Exception:
        pass
    meta = meta or {}
    for label, value in (('IMDb', meta.get('imdbRating') or meta.get('imdb_rating')),
                         ('IMDb', (meta.get('ratings') or {}).get('imdb') if isinstance(meta.get('ratings'), dict) else None),
                         ('TMDb', meta.get('tmdbRating') or meta.get('vote_average'))):
        try:
            number = float(str(value).split('/')[0].replace(',', '.'))
        except (TypeError, ValueError):
            continue
        if 0 < number <= 10:
            return '%s %.1f' % (label, number)
    return ''


def initial_shelves(bucket=''):
    """No network: display saved progress and catalogs immediately."""
    p = _api()
    shelves = []
    if bucket.startswith('group:'):
        from .collections_home import groups,tiles
        selected=next((g for g in groups() if g['id']==bucket.split(':',1)[1]),None)
        return [tiles(selected)] if selected else [{'title':'Collections','rows':[placeholder('Collection unavailable','Sync your Nuvio collections again.')]}]
    if bucket == 'collections':
        # 7.0.48: every group - Home draws a page of MAX_ROWS and the next one at the
        # bottom (home_window._turn); no "More collections" row gathering the rest
        from .collections_home import groups, tiles
        return [tiles(g) for g in groups()]
    if not bucket:
        try:
            from .settings_snapshot import cached_addon
            show_continue = cached_addon().getSetting('meganexus_home_continue') != 'false'
        except Exception:
            show_continue = True
        if show_continue:
            # 8.1.3: one row that cannot be built never keeps the whole of Home closed
            try:
                shelves.append(continue_shelf())
            except Exception:
                import traceback
                import xbmc
                xbmc.log('[MegaNexus] Continue Watching skipped: ' + traceback.format_exc(), xbmc.LOGWARNING)
        try:
            from .local_media import shelves as local_shelves
            shelves.extend(local_shelves())   # 6.0.37: Local Movies / Local Series (Home rows)
        except Exception:
            pass
        try:
            from .media_servers import shelves as server_shelves
            shelves.extend(server_shelves())  # 6.0.39 beta: Plex / Jellyfin rows (off by default)
        except Exception:
            pass
        from .collections_home import home_rows,layout,catalog_rows,groups as collection_groups
        from .default_setup import is_builtin_layout
        if layout()=='posters':
            # 7.0.48: one wall of the collections' films and series (home_posters)
            from .home_posters import shelves as poster_shelves
            try:shelves.extend(poster_shelves())
            except Exception:
                shelves.append({'title':'Collections','rows':[placeholder('Open Settings',
                    'Your collections could not load. Import them again from Nuvio.',p.build_url(action='setup_center'))]})
            return shelves
        # 7.0.30: the built-in add-on's own catalogs are poster rows, as Stremio shows them.
        if layout()=='rows' or is_builtin_layout(collection_groups()):
            try:shelves.extend(catalog_rows())
            except Exception:
                shelves.append({'title':'Collections','rows':[placeholder('Open Settings',
                    'Your catalogs could not load. Import them again from Nuvio.',p.build_url(action='setup_center'))]})
            return shelves   # 7.0.48: every row - Home draws them a page at a time
        try:shelves.extend(home_rows())
        except Exception:
            shelves.append({'title':'Collections','rows':[placeholder('Open Settings',
                'Your collections could not load. Import them again from Nuvio.',p.build_url(action='setup_center'))]})
        return shelves   # 7.0.48: every group - no "More collection groups" row

    pins = p._stored_pins() or []
    pinned = {(r.get('provider_id'), r.get('catalog_id'), r.get('media_type')): i for i, r in enumerate(pins)}
    from .backend_api import catalog_entries
    entries = catalog_entries(bucket)
    entries.sort(key=lambda e: pinned.get((e[0].get('id'), e[1].get('id'), e[1].get('type')), len(pins)))
    seen = set()
    for provider, catalog, kind in entries:
        if not p._home_bucket_visible(kind):
            continue
        # Search-only/required-genre catalogs cannot be fetched without user input.
        if any(isinstance(extra, dict) and extra.get('isRequired') for extra in catalog.get('extra') or []):
            continue
        key = (provider.get('id'), catalog.get('type'), catalog.get('id'))
        if key in seen:
            continue
        seen.add(key)
        title = str(catalog.get('name') or catalog.get('id') or 'Catalog')
        path = p.build_url(action='catalog_all', provider_id=provider.get('id'),
                           media_type=catalog.get('type') or 'movie', catalog_id=catalog.get('id'), label=title)
        shelves.append({'title': title, 'rows': [placeholder(' ', '', path)],   # 7.0.42: no loading words
                        'job': (provider, catalog), 'path': path})
        if len(shelves) >= MAX_ROWS:
            break
    if not shelves or not entries:
        if len(shelves) < MAX_ROWS:
            shelves.append({'title': 'Discover', 'rows': [placeholder('Connect your catalogs',
                'Sign in to Nuvio or add your metadata manifest in Settings > Add-ons.',
                p.build_url(action='setup_center'))]})
    return shelves[:MAX_ROWS]


def _job_rows(provider, catalog, extra, data):
    p = _api()
    mt = catalog.get('type') or 'movie'
    metas = [m for m in (data or {}).get('metas', []) if isinstance(m, dict) and m.get('id')][:PAGE_SIZE]
    # AIOMetadata owns these catalogs and their metadata. No second enrichment layer.
    return [media_card(p._meta_picture_urls(provider, m), provider, mt) for m in metas]


def _fetch_job(provider, catalog, extra, cached_only=False):
    from . import browse_cache
    if cached_only:
        return browse_cache.peek(provider, catalog, extra or {}, memory_only=cached_only == 'memory')
    return browse_cache.catalog(provider, catalog, extra or {},
                                timeout=8 if (extra or {}).get('search') else 4)


def _collection_batches(jobs, stopped=None, cached_only=False, failed=None):
    """Fetch every collection source concurrently; one failed source is not fatal.

    ``failed``: a list the sources that did not answer are appended to. One of two
    catalogs timing out used to pass silently - the collection drew the half that
    answered, counted itself loaded, and only a second visit showed the rest (by then
    the background refresh had cached it). The caller can now see that and come back
    for it while the screen is still open.
    """
    if cached_only:
        batches = []
        for provider, catalog, extra in jobs:
            # 8.1.3: 'memory' means memory - it was turned into a disk read here, so a
            # row that was only meant to look in RAM read SQLite anyway. Twelve of those
            # are the 1.8 s of "paint/seed" that held the screen on a page turn.
            data = _fetch_job(provider, catalog, extra, cached_only)
            if data is None:
                return None
            batches.append(_job_rows(provider, catalog, extra, data))
        return batches
    if len(jobs) == 1:
        provider, catalog, extra = jobs[0]
        try:
            return [_job_rows(provider, catalog, extra, _fetch_job(provider, catalog, extra))]
        except Exception:
            if failed is None:
                raise
            failed.append((provider, catalog, extra))
            raise
    from concurrent.futures import ThreadPoolExecutor
    batches, errors = [], []
    with ThreadPoolExecutor(max_workers=min(4, len(jobs)), thread_name_prefix='MegaNexusCollection') as pool:
        futures = [(job, pool.submit(_fetch_job, *job)) for job in jobs]
        for (provider, catalog, extra), future in futures:
            if stopped and stopped():
                for _, pending in futures:
                    pending.cancel()
                return []
            try:
                batches.append(_job_rows(provider, catalog, extra, future.result()))
            except Exception as exc:
                errors.append(exc)
                batches.append([])
                if failed is not None:
                    failed.append((provider, catalog, extra))
    if errors and len(errors) == len(jobs):
        raise errors[0]
    return batches


def _artwork(rows, cached_only=False, stopped=None):
    """7.0.29: posters / backgrounds / logos from the provider chosen in Artwork."""
    try:
        from .art_provider import apply
        # 8.1.3: 'memory' is handed on as it came. bool() turned it into a disk read,
        # so a row that was only allowed to look in RAM opened the picture cache once
        # per card - seventeen file opens a row, on the thread that draws.
        return apply(rows, cached_only=cached_only, stopped=stopped)
    except Exception:
        import traceback
        import xbmc
        xbmc.log('[MegaNexus] Artwork provider skipped: ' + traceback.format_exc(), xbmc.LOGWARNING)
        return rows


def _released(rows):
    """7.0.32: Hide unreleased titles (Collections & Home rows) - as NuvioTV."""
    from . import release_info
    if not release_info.hide_on():
        return rows
    return [row for row in rows if not row.get('target') or not release_info.unreleased(row)]


def browse_all():
    """7.0.48: a "Browse all" card ends a catalog row (Settings > Layout & cards, on by
    default); off, the row goes on by itself as the cursor nears its end
    (meganexus_ui/home_window.py _grow_rows)."""
    try:
        from .settings_snapshot import cached_addon
        return cached_addon().getSetting('meganexus_browse_all') != 'false'
    except Exception:
        return True


def load_catalog(shelf, stopped=None, cached_only=False, art_later=False):
    """Rows for one Home shelf. ``cached_only`` (True, or 'memory' to skip the
    disk) never touches the network and returns ``None`` unless every source
    already has a cached page. ``art_later`` (9.0.5, search): the add-ons' answer with the
    Artwork provider's pictures only from memory - the rest marked pending, for a second call."""
    if stopped and stopped():return []
    if shelf.get('local_job'):
        if cached_only:return None
        from .local_media import rows as local_rows
        return local_rows(shelf['local_job'])
    if shelf.get('server_job'):
        if cached_only:return None
        from .media_servers import load_rows
        return load_rows(*shelf['server_job'])
    if shelf.get('people_job'):
        if cached_only:return None
        from .search_catalogs import search_people
        return search_people(shelf['people_job']) or [placeholder('No actors found','Try another name.')]
    if shelf.get('collection_job'):
        missed = []
        results = _collection_batches(shelf['collection_job'], stopped, cached_only, missed)
        # What the caller comes back for: a source that did not answer this time.
        shelf['_sources_missing'] = len(missed)
        if results is None:return None
        if stopped and stopped():return []
        # Alternate films and series so both configured sources are represented.
        rows, seen = [], {}
        for index in range(PAGE_SIZE):
            for batch in results:
                if index < len(batch) and batch[index].get('target'):
                    row = batch[index]
                    if str(row.get('title') or '').strip().casefold() in ('', 'unknown'):
                        continue   # 7.0.29: nameless results (AIOMetadata's anime search)
                    target = row.get('target') or {}
                    key = (target.get('media_type'), target.get('canonical_id'))
                    if key not in seen:
                        seen[key] = dict(row)
                        rows.append(seen[key])
                    else:
                        # 7.0.21: the same title from another add-on lends the
                        # pictures the first one lacks.
                        for art in ('poster', 'fanart', 'landscape', 'clearlogo'):
                            if not seen[key].get(art) and row.get(art):
                                seen[key][art] = row[art]
        rows = _released(rows)[:PAGE_SIZE]
        if cached_only and not rows:return None
        rows = _artwork(rows, cached_only or ('memory' if art_later else False), stopped)
        if not shelf.get('no_more') and browse_all():
            rows.append(placeholder('Browse all', 'Open movies and series with the collection filters.', shelf['path']))
        return rows or [placeholder('No titles found', 'Try another name.')]
    provider, catalog = shelf['job']
    extra = shelf.get('extra') or {}
    data = _fetch_job(provider, catalog, extra, cached_only)
    if data is None and cached_only:return None
    rows = _released(_job_rows(provider, catalog, extra, data))
    if cached_only and not rows:return None
    rows = _artwork(rows, cached_only, stopped)
    # Full listing owns per-provider metadata enrichment and pagination.
    if not shelf.get('no_more') and browse_all():
        rows.append(placeholder('Browse all', 'Open the full catalog with your metadata settings and filters.', shelf['path']))
    return rows or [placeholder('No titles found', 'AIOMetadata returned no titles for this selection.')]


SEARCH_GROUPS=(('movie','Movies'),('series','Series'),('anime','Anime'),('people','With this actor or crew'))


def search_kind(catalog):
    """movie / series / anime / people for a search catalog; '' leaves it out
    (channels, events and other types are not titles to search)."""
    from . import search_catalogs
    if search_catalogs.is_people(catalog):return 'people'
    kind=str(catalog.get('type') or '').lower()
    if 'anime' in ' '.join(str(catalog.get(k) or '') for k in ('type','id','name')).lower():return 'anime'
    # 7.0.29: "tv" is Stremio's TV channels, not series - no channel in title search.
    return {'movie':'movie','series':'series'}.get(kind,'')


def search_shelves(query):
    """7.0.21: one row per kind - Movies, Series, Anime - with the results of
    every enabled metadata add-on merged (one card per title, its pictures from
    whichever add-on has them), no row per add-on and no add-on names."""
    from . import search_catalogs, tmdb_api
    from .metadata_providers import enabled
    shelves=[];p=_api()
    query=str(query or '').strip()
    if not query:return []
    from .sports import is_sports_provider, is_sports_catalog, _manifest, _types
    jobs={kind:[] for kind,_ in SEARCH_GROUPS}
    for source in enabled():
        # 6.0.35: sports stay in the Sports screen. 7.0.29: only a sport-only add-on is
        # left out - AIOMetadata also lists sport, and its film and series search went
        # missing (only people named like the query were left). Sport catalogs of a
        # mixed add-on are still skipped one by one below.
        if is_sports_provider(source) and not (_types(_manifest(source)) & {'movie','series'}):continue
        for catalog in search_catalogs.entries(source):
            kind=search_kind(catalog)
            if kind and not is_sports_catalog(catalog.get('type'),catalog.get('id'),catalog.get('name')):
                jobs[kind].append((source,catalog,{'search':query}))
    for kind,title in SEARCH_GROUPS:
        if jobs[kind]:
            shelves.append({'title':title,'collection_job':jobs[kind],'no_more':True,
                            'rows':[placeholder(' ','')]})
    if tmdb_api.api_key():
        shelves.append({'title':'Actors & crew','people_job':query,'rows':[placeholder(' ','')]})
    return shelves[:MAX_ROWS] or [{'title':'Search movies, series, actors & more','rows':[
        placeholder('Configure metadata search','Enable title and People Search catalogs in your metadata add-on, then refresh its manifest.',p.build_url(action='setup_center'),False)]}]


def time_left(seconds):
    """'32 min left' / '1 h 12 min left' - as the streaming apps say it (8.1.3)."""
    seconds=int(seconds or 0)
    if seconds<60:return ''
    return '%d h %d min left'%(seconds//3600,seconds%3600//60) if seconds>=3600 else '%d min left'%(seconds//60)


def continue_line(kind,subtitle,left=0,year=''):
    """A Continue Watching card's line: Series / Movie, the year, the episode and how
    much was seen, and the time left."""
    return '  |  '.join(x for x in ('Series' if kind=='series' else 'Movie',year,subtitle,time_left(left)) if x)


def continue_shelf():
    from . import simkl_watched, watch_nextup, continue_local
    from .progress_model import timestamp
    from .meganexus import progress_db
    from .meganexus.paths import watched_percent
    from . import continue_rules
    from .progress_model import resumable
    p=_api(); rows=[]; watched=simkl_watched.snapshot(); removed=continue_rules.snapshot()
    local=continue_local.recent()
    # Local user actions win over account imports. Completed local titles also
    # suppress their stale remote resume, without discarding the watched archive.
    recent=progress_db.list_recent_items(limit=400)   # 8.1.3: read once for both uses below
    merged={continue_local.identity(r):(r,False) for r in progress_db.list_continue_items(limit=50,recent=recent)}
    # 8.1.3: a title finished after it was last started here is done - its old local
    # resume does not come back. "Spider-Man: Novo doba" was watched to the end on the
    # 22nd and showed in Continue Watching at "0% watched" from an 11-second start on the 14th.
    finished={}
    for r in recent:
        if r.get('event_type')=='watched' or float(r.get('percent') or 0)>=watched_percent():
            key=continue_local.identity(r)
            finished[key]=max(finished.get(key,0),timestamp(r.get('updated_at')))
    for r in local:
        key=continue_local.identity(r)
        if finished.get(key,0)>=timestamp(r.get('updated_at')):continue
        remote=merged.get(key)
        if not remote or timestamp(r.get('updated_at'))>=timestamp(remote[0].get('updated_at')):
            merged[key]=(r,True)
    from .progress_model import timestamp
    def display_order(value):
        return timestamp(value[0].get('updated_at'))
    for raw,is_local in sorted(merged.values(),key=display_order,reverse=True):
        if raw.get('event_type')=='watched' or float(raw.get('percent') or 0)>=watched_percent():continue
        mt='movie' if raw.get('media_type')=='movie' else 'series'
        mid=raw.get('canonical_id') or ''
        # 7.0.24: only what can be resumed - live TV channels and sport events
        # synced from Nuvio were "Loading title…" cards (progress_model.resumable).
        if not resumable(dict(raw,media_type=mt)):continue
        # 6.0.35: removed by the user (until played again) and the period (60 days).
        if continue_rules.hidden(mt,mid,raw.get('updated_at'),removed) or not continue_rules.recent_enough(raw.get('updated_at')):continue
        entry=simkl_watched.state(watched,mt,mid)
        done=entry.get('watched') if mt=='movie' else simkl_watched.is_episode_watched(entry,raw.get('season'),raw.get('episode'))
        stamp=entry.get('watched_at') if mt=='movie' else (entry.get('episode_watched_at') or {}).get('%s:%s'%(raw.get('season'),raw.get('episode')))
        # 7.0.42: a tracker's watched mark hides the title only when it is newer than
        # this progress - also for progress from the cloud (Nuvio). Before, any watched
        # mark hid cloud progress: a film seen once and started again vanished, and so
        # did one started and left at once (its cloud copy is as new as the local one).
        if done and stamp and timestamp(stamp)>timestamp(raw.get('updated_at')):continue
        # 9.0.1: older than the resume - only a real rewatch brings it back
        from .progress_model import counts_as_rewatch
        if done and stamp and not counts_as_rewatch(raw,stamp):continue
        target=dict(media_type=mt,canonical_id=mid,video_id=raw.get('video_id') or mid,
                    season=raw.get('season'),episode=raw.get('episode'),
                    resume_seconds=raw.get('position') or 0,resume_percent=raw.get('percent') or 0)
        # 7.0.29: its other ids, so the same title under another id is one card
        for column in ('imdb_id','tmdb_id','tvdb_id'):
            if raw.get(column):target[column]=str(raw[column])
        title=raw.get('title') or 'Loading title…'
        percent=int(float(raw.get('percent') or 0))
        subtitle=('S%s · E%s  |  '%(raw.get('season'),raw.get('episode'))) if mt=='series' else ''
        # 8.1.3: every card carries its line - kind, then the episode and how much of it
        # was seen. Only cards missing a picture or a plot got one (continue_metadata),
        # so most of Continue Watching showed nothing beside the badges.
        # 8.1.3: and how long is left, as every streaming app says it ("32 min left")
        try:left=max(0,int(float(raw.get('duration') or 0)-float(raw.get('position') or 0)))
        except (TypeError,ValueError):left=0
        if not float(raw.get('duration') or 0):left=0
        meta_line=continue_line(mt,subtitle+'%s%% watched'%percent,left)
        rows.append(dict(title=title,subtitle=subtitle+'%s%% watched'%percent,meta_line=meta_line,
            poster=raw.get('poster') or '',fanart=raw.get('background') or '',
            landscape=raw.get('background') or '',clearlogo=raw.get('clearlogo') or '',
            percent_value=percent,percent=percent,target=target,is_folder=False,
            plot=raw.get('plot') or '',resume_label='',continue_card='resume',remaining_seconds=left,   # 8.1.3: no "Resume" line
            progress_key=[raw.get('media_type'),mid,raw.get('video_id') or mid],
            progress_updated=raw.get('updated_at') or '',   # 7.0.47: watch_nextup.augment - a stale episode gives way
            path=p.build_url(action='cw_resume',**{k:v for k,v in target.items() if v is not None})))
    try:rows=watch_nextup.augment(rows)
    except Exception:pass
    from .continue_metadata import dedupe
    rows=dedupe(rows)
    rows=_artwork(rows,cached_only=True)   # 7.0.29: Artwork provider - cached only, Home builds this on its GUI thread
    return {'title':'Continue Watching','continue_job':True,'rows':rows[:50] or [placeholder(
        'Your next watch starts here','Movies and episodes you start will appear here with their saved progress.',p.build_url(action='continue'))]}
