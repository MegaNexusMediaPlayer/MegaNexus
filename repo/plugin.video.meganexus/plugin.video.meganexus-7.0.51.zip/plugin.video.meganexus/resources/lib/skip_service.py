# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Read-only segment lookup and playback controls, owned by the MegaNexus service."""
import json
import math
import re
import time
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

from . import skip_segments

_BACKOFF = 0.0


def query_params(context, duration):
    params = {}
    tid = str(context.get('tmdb_id') or '')
    imdb = str(context.get('imdb_id') or context.get('canonical_id') or '')
    if tid.isdigit() and int(tid) > 0:
        params['tmdb_id'] = tid
    elif re.fullmatch(r'tt\d+', imdb):
        params['imdb_id'] = imdb
    else:
        return None
    mt = context.get('media_type') or context.get('type')
    if mt not in ('movie', 'series', 'episode', 'tv', 'show', 'tvshow', 'anime'):
        return None
    if mt != 'movie':
        try:
            season, episode = int(context['season']), int(context['episode'])
        except (KeyError, ValueError, TypeError):
            return None
        if season < 1 or episode < 1: return None
        params.update(season=season, episode=episode)
    if not math.isfinite(duration) or duration <= 0: return None
    params['duration_ms'] = int(duration * 1000)
    return params


def normalize_segments(payload, duration):
    """Never trust API timestamps enough to seek outside the current media."""
    result = []
    if not isinstance(payload, dict) or not math.isfinite(duration) or duration <= 0:
        return result
    for kind in ('intro', 'recap', 'credits', 'preview'):
        candidates = []
        raw = payload.get(kind) or []
        if not isinstance(raw, list): continue
        for segment in raw:
            if not isinstance(segment, dict): continue
            try:
                if segment.get('start_ms') is None and kind in ('credits', 'preview'): continue
                start = float(segment.get('start_ms') or 0) / 1000
                end = segment.get('end_ms')
                if end is None and kind in ('intro', 'recap'): continue
                end = float(end) / 1000 if end is not None else duration - 0.75
                confidence = float(segment.get('confidence', 0.5))
                if not all(math.isfinite(n) for n in (start, end, confidence)): continue
                if start < 0 or end <= start or end > duration or start >= duration - 1: continue
                candidates.append((confidence, start, min(end, duration - 0.75)))
            except (ValueError, TypeError, OverflowError):
                continue
        if candidates:
            _, start, end = max(candidates)
            if end > start:
                result.append({'type': kind, 'start': start, 'end': end})
    return sorted(result, key=lambda row: row['start'])


def lookup(context, duration, key=''):
    global _BACKOFF
    params = query_params(context, duration)
    if not params or time.monotonic() < _BACKOFF:
        return []
    request = Request('https://api.theintrodb.org/v3/media?' + urlencode(params),
                      headers={'Accept': 'application/json', 'User-Agent': 'MegaNexus/' + xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('version')})
    if key: request.add_header('Authorization', 'Bearer ' + key)
    try:
        with urlopen(request, timeout=4) as response:
            data = json.loads(response.read(1024 * 1024).decode('utf-8'))
        return normalize_segments(data, duration)
    except HTTPError as error:
        if error.code == 429:
            try: delay = min(3600, max(60, int(error.headers.get('Retry-After', '300'))))
            except (TypeError, ValueError): delay = 300
            _BACKOFF = time.monotonic() + delay
        return []
    except Exception:
        return []


def owns_playback(player, uid):
    if not uid or getattr(player, '_foreign_active', True): return False
    if uid != getattr(player, '_active_playback_uid', ''): return False
    if uid != (getattr(player, 'ctx', {}) or {}).get('playback_uid'): return False
    try:
        if not player.isPlayingVideo():return False
        return bool(player._last_started_file and player.getPlayingFile()==player._last_started_file)
    except Exception:
        return False


SHOW_FOR = 10   # 7.0.29: seconds a Skip pill stays, then it goes
SHOW_NEXT_FOR = 15   # 7.0.42: the next episode's picture stays a little longer
OUTRO = ('credits', 'preview', 'upnext')
# 7.0.42: what the player's own buttons offer once a pill went (skin VideoOSD.xml,
# review/make_cinema_player.py). The buttons write the command, run() carries it out.
OSD_SKIP = 'meganexus.osd.skip'
OSD_NEXT = 'meganexus.osd.next'
OSD_COMMAND = 'meganexus.osd.command'


def next_line(nxt):
    """'S2 · E5  Name' for the next episode's picture."""
    line = 'S%s · E%s' % (nxt.get('season') or '?', nxt.get('episode') or '?')
    return line + ('  ' + nxt['name'] if nxt.get('name') else '')


def next_still(nxt):
    """The next episode's own still, else the playing show's backdrop."""
    if nxt.get('still'):
        return nxt['still']
    for art in ('tvshow.fanart', 'fanart', 'thumb'):
        value = xbmc.getInfoLabel('Player.Art(%s)' % art)
        if value:
            return value
    return ''


class SkipOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(SkipOverlay, self).__init__(*args)
        self.player = kwargs['player']
        self.uid = kwargs['uid']
        self.segment = kwargs['segment']
        self.outro_skip = kwargs.get('outro_skip', True)
        self.dismissed = False
        self.command = None
        self.opened = time.monotonic()

    def onInit(self):
        kind=self.segment['type'];outro=kind in OUTRO
        self.getControl(10).setLabel('Skip outro' if outro else 'Skip '+kind)
        nxt=self.player.ctx.get('next_episode') if outro else None
        self.setProperty('meganexus.next_available','1' if nxt else '')
        if nxt:
            self.setProperty('meganexus.next.still',next_still(nxt))
            self.setProperty('meganexus.next.line',next_line(nxt))
        # 7.0.50: Skip outro switched off - at the credits only Next episode (as for "upnext")
        self.setProperty('meganexus.skip.kind','upnext' if outro and not self.outro_skip else kind)
        self.setFocusId(11 if nxt else 10)

    def shown_for(self):
        return SHOW_NEXT_FOR if self.getProperty('meganexus.next_available') else SHOW_FOR

    def onClick(self, control_id):
        if control_id in (10,11):self.command=control_id
        self.dismissed=True
        self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.dismissed = True
            self.close()


def osd_offer(home, skip, next_ready):
    """The player's Skip / Next episode buttons follow what plays right now."""
    label = ('Skip outro' if skip['type'] in OUTRO else 'Skip ' + skip['type']) if skip else ''
    if home.getProperty(OSD_SKIP) != label:
        home.setProperty(OSD_SKIP, label)
    if home.getProperty(OSD_NEXT) != next_ready:
        home.setProperty(OSD_NEXT, next_ready)


def skippable(segment, outro_skip):
    """A Skip button for this part: intro / recap always, the credits only with Skip outro on."""
    return bool(segment) and segment['type'] != 'upnext' and (outro_skip or segment['type'] not in OUTRO)


def offered(segment, outro_skip, next_ready):
    """The pill appears: a Skip button, or at the end Next episode."""
    return bool(segment) and (skippable(segment, outro_skip) or (segment['type'] in OUTRO and next_ready))


def run(player, monitor):
    addon = xbmcaddon.Addon('plugin.video.meganexus')
    home = xbmcgui.Window(10000)
    uid, segments, handled, overlay = '', [], set(), None
    try:
        while not monitor.abortRequested():
            try:
                mode = addon.getSetting('meganexus_skip_mode') or 'Button'
                outro_skip = skip_segments.outro_on(addon)
                current_uid = getattr(player, '_active_playback_uid', '')
                active = mode != 'Off' and owns_playback(player, current_uid)
                if not active:
                    uid, segments, handled = '', [], set()
                    if overlay: overlay.close(); overlay = None
                    osd_offer(home, None, '')
                else:
                    if current_uid != uid:
                        if overlay: overlay.close(); overlay = None
                        duration = player.getTotalTime()
                        if duration <= 0:
                            if monitor.waitForAbort(0.5): break
                            continue
                        uid, handled = current_uid, set()
                        ctx = dict(player.ctx)
                        segments = skip_segments.merge(lookup(ctx, duration, addon.getSetting('meganexus_introdb_key')),
                                                       skip_segments.server(ctx, duration))
                        tail = skip_segments.upnext(segments, duration, skip_segments.upnext_on(addon), bool(ctx.get('next_episode')))
                        if tail: segments.append(tail)
                    # A lookup can finish after playback changed. Recheck before touching the player.
                    if owns_playback(player, uid):
                        position = player.getTime()
                        if overlay and not overlay.dismissed and time.monotonic() - overlay.opened >= overlay.shown_for():
                            # 7.0.29: not chosen while its pill filled up - it goes, the film plays on
                            overlay.dismissed = True
                            overlay.close()
                        if overlay and overlay.dismissed:
                            if overlay.command:apply_skip(player,uid,overlay.segment,overlay.command==11)
                            handled.add((overlay.segment['type'], overlay.segment['start']))
                            overlay = None
                        segment = next((s for s in segments if s['start'] <= position < s['end']
                                        and (s['type'], s['start']) not in handled), None)
                        here = next((s for s in segments if s['start'] <= position < s['end']), None)
                        if here is None and skip_segments.chapters_on(addon):
                            # The file's own chapters: Intro / Opening / Credits / Ending.
                            found = skip_segments.chapter(xbmc.getInfoLabel('Player.ChapterName'), position, player.getTotalTime())
                            if found:
                                here = dict(found, start='chapter' + xbmc.getInfoLabel('Player.Chapter'))
                                if segment is None and (here['type'], here['start']) not in handled:
                                    segment = here
                        # 7.0.42: a pill closed by mistake - the player's buttons still offer it.
                        next_ready = bool(here and here['type'] in OUTRO and player.ctx.get('next_episode'))
                        if next_ready and player.ctx.get('meganexus_request_id'):
                            # 7.0.50: offered here - the title page does not ask again after the end
                            home.setProperty('meganexus.next.offered', str(player.ctx['meganexus_request_id']))
                        osd_offer(home, here if skippable(here, outro_skip) else None, '1' if next_ready else '')
                        if segment and not offered(segment, outro_skip, next_ready):
                            handled.add((segment['type'], segment['start']))   # credits without Skip outro or a next episode
                            segment = None
                        command = home.getProperty(OSD_COMMAND)
                        if command:
                            home.clearProperty(OSD_COMMAND)
                            if overlay: overlay.close(); overlay = None
                            if command == 'next' and next_ready:
                                apply_skip(player, uid, here, True)
                            elif command == 'skip' and skippable(here, outro_skip):
                                apply_skip(player, uid, here, False)
                            if here:
                                handled.add((here['type'], here['start']))
                            segment = None
                        if not segment or xbmc.getCondVisibility('Player.Paused') or not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                            if overlay: overlay.close(); overlay = None
                        elif mode == 'Automatic' and skippable(segment, outro_skip):
                            if owns_playback(player, uid):
                                apply_skip(player,uid,segment,False)
                                handled.add((segment['type'], segment['start']))
                        elif mode == 'Automatic':
                            pass                                     # up next is always a choice
                        elif overlay is None:
                            overlay = SkipOverlay('meganexus_skip.xml', xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), 'Default', '1080i',
                                                  player=player, uid=uid, segment=segment, outro_skip=outro_skip)
                            overlay.show()
            except Exception:
                if overlay:
                    try: overlay.close()
                    except Exception: pass
                    overlay = None
            if monitor.waitForAbort(0.5): break
    finally:
        if overlay: overlay.close()
        osd_offer(home, None, '')


def apply_skip(player,uid,segment,next_episode=False):
    if not owns_playback(player,uid):return False
    position=player.getTime()
    if segment.get('chapter'):
        if segment['type'] in ('intro','recap'):
            xbmc.executebuiltin('Action(ChapterOrBigStepForward)')   # to the next chapter
            return True
    elif not segment['start']<=position<segment['end']:return False
    outro=segment['type'] in ('credits','preview','upnext')
    if outro:
        from .companion import _save_local_progress
        player.ctx['meganexus_completed_by_user']=True
        duration=player._duration_ms()
        _save_local_progress(player.ctx,player._position_ms(),duration,finished=True)
        player._report('ended',position_ms=duration)
    if next_episode and outro and player.ctx.get('next_episode'):
        request={k:v for k,v in player.ctx['next_episode'].items() if k not in ('name','still')}
        request['media_type']='series'
        home=xbmcgui.Window(10000)
        home.setProperty('meganexus.next_episode',json.dumps(request))
        player.stop()
        if not home.getProperty('meganexus.frontend.running'):
            from . import cache_store
            key=cache_store.put('meganexus_open',dict(request,details_view='manual'))
            xbmc.executebuiltin('RunScript(script.meganexus,open,%s)'%key)
    elif segment['type']=='upnext':return True
    else:player.seekTime(segment['end'])
    return True
