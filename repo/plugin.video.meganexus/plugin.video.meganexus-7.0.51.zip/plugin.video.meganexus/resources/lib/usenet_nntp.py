# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Usenet building blocks for playing NZB sources (7.0.43): the NNTP client, yEnc,
NZB files and the RAR headers of stored (uncompressed) archives.

Stremio add-ons can give a source as `nzbUrl` + `servers` (Usenet Streamer's
native mode, Stremio v5's own Usenet player). Kodi cannot play that; usenet_stream
reads the articles with these pieces and gives Kodi an ordinary local HTTP link.
Pure Python: yEnc decodes with bytes.translate (~1 Gbit/s on a PC), far above what
a film needs. Servers are "nntps://user:password@host:563/20" (the Stremio form;
the number is the connection limit).
"""
import re
import socket
import ssl
import xml.etree.ElementTree as ET
from urllib.parse import unquote, urlparse

VIDEO_EXT = ('.mkv', '.mp4', '.m4v', '.avi', '.ts', '.m2ts', '.mov', '.wmv', '.webm', '.mpg', '.mpeg')
MAX_CONNECTIONS = 20           # per server (7.0.51: was 12); fewer when the provider refuses more (TooMany)
DEFAULT_CONNECTIONS = 16       # 7.0.51: a server without a number (was 8 - 25 Mbit/s at ~390 KB/s a connection)
_DECODE = bytes((b - 42) % 256 for b in range(256))
_FIELD = re.compile(rb'\b(\w+)=(\S+)')


class Missing(Exception):
    """The article is not on this server (430)."""


class NntpError(Exception):
    pass


class TooMany(NntpError):
    """7.0.51: the provider allows fewer connections at once - this one is not needed."""


def _too_many(code, line):
    text = line.decode('utf-8', 'ignore').lower()
    return code in (400, 481, 482, 502) and any(w in text for w in ('too many', 'connection', 'limit', 'session', 'max'))


class AuthError(NntpError):
    pass


def parse_server(value):
    """'nntps://user:pass@host:563/20' -> dict, or None."""
    value = str(value or '').strip()
    if not value:
        return None
    if '://' not in value:
        value = 'nntps://' + value
    try:
        url = urlparse(value)
        secure = url.scheme.lower() in ('nntps', 'snews', 'ssl', 'tls')
        port = url.port or (563 if secure else 119)
        path = (url.path or '').strip('/')
        connections = int(path) if path.isdigit() else DEFAULT_CONNECTIONS
    except ValueError:
        return None
    if not url.hostname:
        return None
    return {'host': url.hostname, 'port': port, 'ssl': secure, 'user': unquote(url.username or ''),
            'password': unquote(url.password or ''), 'connections': max(1, min(connections, MAX_CONNECTIONS))}


def server_label(server):
    """host:port - never the login."""
    return '%s:%s' % (server.get('host'), server.get('port'))


# --- NZB --------------------------------------------------------------------

class NzbFile(object):
    __slots__ = ('subject', 'name', 'index', 'segments', 'bytes', 'part_size', 'size', 'kind', 'head')

    def __init__(self, subject, segments):
        self.subject = subject
        self.segments = segments                     # [message-id], by number
        self.bytes = 0
        self.name = name_from_subject(subject)
        self.index = index_from_subject(subject)
        self.part_size = 0                           # decoded size of every part but the last
        self.size = 0                                # decoded file size (=ybegin size)
        self.kind = kind_of_name(self.name)
        self.head = None                             # the first part, decoded


def name_from_subject(subject):
    quoted = re.search(r'"([^"]+)"', subject or '')
    if quoted:
        return quoted.group(1).strip()
    found = re.search(r'([\w.\-\[\]() ]+\.(?:mkv|mp4|m4v|avi|ts|m2ts|mov|wmv|webm|rar|r\d{2,3}|\d{3}|par2|nfo|sfv|7z))\b', subject or '', re.I)
    return found.group(1).strip() if found else ''


def index_from_subject(subject):
    """The poster's file counter "[03/45]" / "(3/45)", else 0."""
    found = re.search(r'[\[(](\d{1,5})\s*(?:/|of)\s*\d{1,5}[\])]', subject or '')
    return int(found.group(1)) if found else 0


def kind_of_name(name):
    low = (name or '').lower()
    if low.endswith(VIDEO_EXT):
        return 'video'
    if re.search(r'\.(?:part\d+\.)?rar$|\.r\d{2,3}$|\.\d{3}$', low) and not re.search(r'\.7z\.\d{3}$', low):
        return 'rar'
    if re.search(r'\.7z(?:\.\d{3})?$', low):
        return '7z'
    if low.endswith(('.par2', '.nfo', '.sfv', '.nzb', '.srr', '.jpg', '.png', '.txt', '.srt', '.sub', '.idx')):
        return 'extra'
    return ''


def parse_nzb(data):
    """[NzbFile] in the NZB's order."""
    root = ET.fromstring(data)
    files = []
    for node in root.iter():
        if not node.tag.endswith('file'):
            continue
        parts = []
        total = 0
        for seg in node.iter():
            if not seg.tag.endswith('segment') or not (seg.text or '').strip():
                continue
            try:
                number = int(seg.get('number') or 0)
                size = int(seg.get('bytes') or 0)
            except ValueError:
                number, size = 0, 0
            total += size
            parts.append((number, seg.text.strip().strip('<>')))
        if not parts:
            continue
        parts.sort()
        nzb_file = NzbFile(node.get('subject') or '', [msgid for _, msgid in parts])
        nzb_file.bytes = total
        files.append(nzb_file)
    return files


# --- yEnc -------------------------------------------------------------------

def _fields(line):
    return {key.decode('ascii', 'ignore'): value for key, value in _FIELD.findall(line)}


def yenc_decode(body):
    """(begin offset (0-based), data, file size, file name) of one article body."""
    start = body.find(b'=ybegin ')
    if start < 0:
        raise NntpError('not yEnc')
    eol = body.find(b'\n', start)
    head = _fields(body[start:eol])
    name = body[start:eol].split(b' name=', 1)[-1].strip().decode('utf-8', 'replace') if b' name=' in body[start:eol] else ''
    pos = eol + 1
    begin = 1
    if body.startswith(b'=ypart ', pos):
        eol = body.find(b'\n', pos)
        begin = int(_fields(body[pos:eol]).get('begin', b'1'))
        pos = eol + 1
    end = body.rfind(b'\n=yend')
    data = body[pos:end + 1 if end >= 0 else len(body)].replace(b'\r', b'').replace(b'\n', b'')
    return begin - 1, unescape(data).translate(_DECODE), int(head.get('size', b'0')), name


def unescape(data):
    """yEnc escapes undone (still +42 encoded): '=' and the next byte become that byte - 64.
    7.0.51: "==" (an escaped 0xFD, some encoders) went wrong in the fast split - the careful way
    then. (Whole-buffer replaces were measured: 2.5x slower than this split.)"""
    if b'=' not in data:
        return data
    if b'==' in data:
        return _unescape_each(data)
    pieces = data.split(b'=')
    return pieces[0] + b''.join(bytes(((piece[0] - 64) % 256,)) + piece[1:] for piece in pieces[1:] if piece)


def _unescape_each(data):
    out = bytearray()
    at = 0
    while True:
        mark = data.find(b'=', at)
        if mark < 0:
            out += data[at:]
            return bytes(out)
        out += data[at:mark]
        if mark + 1 < len(data):
            out.append((data[mark + 1] - 64) % 256)
        at = mark + 2


# --- NNTP -------------------------------------------------------------------

class Connection(object):
    """One NNTP connection; BODY by message-id."""

    def __init__(self, server, timeout=20):
        raw = socket.create_connection((server['host'], server['port']), timeout=timeout)
        if server.get('ssl'):
            raw = ssl.create_default_context().wrap_socket(raw, server_hostname=server['host'])
        self.sock = raw
        self.buf = bytearray()
        code, line = self._line()
        if code not in (200, 201):
            self.close()
            raise (TooMany if _too_many(code, line) else NntpError)('greeting %d' % code)
        if server.get('user'):
            self.sock.sendall(('AUTHINFO USER %s' % server['user']).encode('utf-8') + b'\r\n')
            code, line = self._line()
            if code == 381:
                self.sock.sendall(('AUTHINFO PASS %s' % server.get('password', '')).encode('utf-8') + b'\r\n')
                code, line = self._line()
            if code != 281:
                self.close()
                if _too_many(code, line):   # 7.0.51: "too many connections" is not a wrong login
                    raise TooMany('login %d' % code)
                raise AuthError('login refused (%d)' % code)

    def _recv(self):
        chunk = self.sock.recv(262144)
        if not chunk:
            raise NntpError('connection closed')
        self.buf += chunk

    def _line(self):
        while True:
            end = self.buf.find(b'\r\n')
            if end >= 0:
                break
            self._recv()
        line = bytes(self.buf[:end])
        del self.buf[:end + 2]
        try:
            return int(line[:3]), line
        except ValueError:
            raise NntpError('bad reply')

    def _command(self, text):
        self.sock.sendall(text.encode('utf-8') + b'\r\n')
        return self._line()[0]

    def body(self, message_id):
        self.send_body(message_id)
        return self.read_body(message_id)

    def send_body(self, message_id):
        """7.0.51: the request alone - several go out before the answers are read
        (NNTP pipelining, as SABnzbd: no round trip between articles)."""
        self.sock.sendall(b'BODY <%s>\r\n' % message_id.encode('utf-8', 'ignore'))

    def read_body(self, message_id):
        """The answer to a BODY sent before, in the order they were sent."""
        code, line = self._line()
        if code in (420, 423, 430):
            raise Missing(message_id)
        if code != 222:
            raise NntpError('BODY %d' % code)
        if self.buf[:3] == b'.\r\n':
            del self.buf[:3]
            return b''
        scanned = 0
        while True:
            end = self.buf.find(b'\r\n.\r\n', max(0, scanned - 4))
            if end >= 0:
                break
            scanned = len(self.buf)
            self._recv()
        data = b'\r\n' + bytes(self.buf[:end + 2])
        del self.buf[:end + 5]
        return data.replace(b'\r\n..', b'\r\n.')[2:]

    # 7.0.45: what Spotnet needs - a group's range, its overview lines, an article's header
    def _raw(self):
        while True:
            end = self.buf.find(b'\r\n')
            if end >= 0:
                break
            self._recv()
        line = bytes(self.buf[:end])
        del self.buf[:end + 2]
        return line

    def _block(self):
        """The lines of a multi-line answer, up to the closing '.'."""
        while True:
            line = self._raw()
            if line == b'.':
                return
            yield line[1:] if line.startswith(b'..') else line

    def group(self, name):
        """(count, first, last) article numbers of a newsgroup."""
        self.sock.sendall(b'GROUP %s\r\n' % name.encode('ascii'))
        code, line = self._line()
        if code != 211:
            raise NntpError('GROUP %d' % code)
        parts = line.split()
        return int(parts[1]), int(parts[2]), int(parts[3])

    def overview(self, first, last):
        """The overview lines (number, subject, from, date, message-id, ...) of a range."""
        self.sock.sendall(b'XOVER %d-%d\r\n' % (first, last))
        code, _ = self._line()
        if code == 420:
            return []
        if code != 224:
            raise NntpError('XOVER %d' % code)
        return list(self._block())

    def head(self, message_id):
        """An article's header lines (continued lines joined)."""
        self.sock.sendall(b'HEAD <%s>\r\n' % message_id.strip('<>').encode('utf-8', 'ignore'))
        code, _ = self._line()
        if code in (420, 423, 430):
            raise Missing(message_id)
        if code != 221:
            raise NntpError('HEAD %d' % code)
        lines = []
        for line in self._block():
            if line[:1] in (b' ', b'\t') and lines:
                lines[-1] += line.strip()
            else:
                lines.append(line)
        return lines

    def raw_body(self, message_id):
        """An article's body lines as they are (not yEnc)."""
        self.sock.sendall(b'BODY <%s>\r\n' % message_id.strip('<>').encode('utf-8', 'ignore'))
        code, _ = self._line()
        if code in (420, 423, 430):
            raise Missing(message_id)
        if code != 222:
            raise NntpError('BODY %d' % code)
        return list(self._block())

    def close(self):
        try:
            self.sock.sendall(b'QUIT\r\n')
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


# --- RAR (stored) -----------------------------------------------------------

RAR4 = b'Rar!\x1a\x07\x00'
RAR5 = b'Rar!\x1a\x07\x01\x00'
MAGIC = ((RAR5, 'rar'), (RAR4, 'rar'), (b'\x1a\x45\xdf\xa3', 'video'), (b'7z\xbc\xaf\x27\x1c', '7z'), (b'PAR2\x00PKT', 'extra'))


class Unsupported(Exception):
    """Compressed, encrypted or 7z - can not be streamed."""


def sniff(head):
    for magic, kind in MAGIC:
        if head.startswith(magic):
            return kind
    if head[4:8] == b'ftyp' or head[:4] == b'RIFF' or head[:1] == b'\x47':
        return 'video'
    return ''


def _vint(data, pos):
    value, shift = 0, 0
    while True:
        byte = data[pos]
        pos += 1
        value |= (byte & 0x7f) << shift
        if not byte & 0x80:
            return value, pos
        shift += 7


def rar_volume(head):
    """What a RAR volume's first bytes say: {'volume': number or None (unknown),
    'first': bool, 'files': [{'name', 'offset', 'length', 'size', 'before', 'after'}]}.
    offset / length: where the stored file's data lies in this volume. Raises
    Unsupported for compressed / encrypted archives."""
    if head.startswith(RAR5):
        return _rar5(head)
    if head.startswith(RAR4):
        return _rar4(head)
    raise Unsupported('not a RAR volume')


def _rar4(data):
    import struct
    pos = len(RAR4)
    info = {'volume': None, 'first': True, 'files': []}
    while pos + 7 <= len(data):
        _, kind, flags, size = struct.unpack_from('<HBHH', data, pos)
        if size < 7:
            break
        add = struct.unpack_from('<I', data, pos + 7)[0] if flags & 0x8000 and kind != 0x74 else 0
        if kind == 0x73:                                   # main header
            if flags & 0x0080:
                raise Unsupported('encrypted RAR')
            if flags & 0x0001:
                info['first'] = bool(flags & 0x0100) if flags & 0x0010 else info['first']
        elif kind == 0x74:                                 # file header
            pack, unpack = struct.unpack_from('<II', data, pos + 7)
            method = data[pos + 25]
            name_size = struct.unpack_from('<H', data, pos + 26)[0]
            name_at = pos + 32
            if flags & 0x0100:
                high_pack, high_unpack = struct.unpack_from('<II', data, pos + 32)
                pack += high_pack << 32
                unpack += high_unpack << 32
                name_at += 8
            name = data[name_at:name_at + name_size].split(b'\x00')[0].decode('utf-8', 'replace')
            if flags & 0x0004:
                raise Unsupported('encrypted RAR')
            info['files'].append({'name': name, 'offset': pos + size, 'length': pack, 'size': unpack,
                                  'before': bool(flags & 0x01), 'after': bool(flags & 0x02), 'stored': method == 0x30})
            if flags & 0x01:
                info['first'] = False
            add = pack
        elif kind == 0x7b:                                 # end of archive
            break
        pos += size + add
    return info


def _rar5(data):
    pos = len(RAR5)
    info = {'volume': None, 'first': True, 'files': []}
    while pos + 6 < len(data):
        pos += 4                                           # header CRC32
        size, start = _vint(data, pos)
        kind, at = _vint(data, start)
        flags, at = _vint(data, at)
        extra = data_size = 0
        if flags & 0x01:
            extra, at = _vint(data, at)
        if flags & 0x02:
            data_size, at = _vint(data, at)
        end = start + size
        if kind == 1:                                      # main archive header
            archive, at = _vint(data, at)
            if archive & 0x02:
                info['volume'], at = _vint(data, at)
                info['first'] = info['volume'] == 0
            else:
                info['volume'] = 0 if archive & 0x01 else None
        elif kind == 4:
            raise Unsupported('encrypted RAR')
        elif kind == 2:                                    # file header
            file_flags, at = _vint(data, at)
            unpack, at = _vint(data, at)
            _, at = _vint(data, at)                        # attributes
            if file_flags & 0x02:
                at += 4
            if file_flags & 0x04:
                at += 4
            compression, at = _vint(data, at)
            _, at = _vint(data, at)                        # host OS
            name_size, at = _vint(data, at)
            name = data[at:at + name_size].decode('utf-8', 'replace')
            record = end - extra
            while extra and record < end:                  # extra records: 0x01 = encryption
                record_size, record_at = _vint(data, record)
                if _vint(data, record_at)[0] == 0x01:
                    raise Unsupported('encrypted RAR')
                record = record_at + record_size
            info['files'].append({'name': name, 'offset': end, 'length': data_size, 'size': unpack,
                                  'before': bool(flags & 0x08), 'after': bool(flags & 0x10),
                                  'stored': (compression >> 7) & 0x07 == 0})
            if flags & 0x08:
                info['first'] = False
        elif kind == 5:                                    # end of archive
            break
        pos = end + data_size
    return info
