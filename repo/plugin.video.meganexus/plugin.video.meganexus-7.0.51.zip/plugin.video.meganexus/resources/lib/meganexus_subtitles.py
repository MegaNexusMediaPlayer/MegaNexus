# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Preserve every release within its language, loading one selected file at a time."""
from . import subtitle_broker as broker
import json
import os
import re
from urllib.parse import urlsplit
import xbmc
import xbmcaddon
import xbmcgui

NAMES={'hr':'Croatian','sr':'Serbian','bs':'Bosnian','sl':'Slovenian','en':'English','de':'German','it':'Italian','fr':'French','es':'Spanish','pt':'Portuguese','und':'Unknown language'}

def language(value):
    if isinstance(value,(list,tuple)):
        return next((language(v) for v in value if language(v)!='und'),'und')
    if isinstance(value,dict):
        value=next((value[k] for k in ('lang','language','languageCode','code','name') if value.get(k)),'und')
    raw=str(value or 'und').strip().lower()
    aliases={'cro':'hr','hrv':'hr','croatian':'hr','hrvatski':'hr','ser':'sr','srp':'sr','serbian':'sr','bos':'bs','bosnian':'bs','slv':'sl','slovenian':'sl'}
    if raw in aliases:return aliases[raw]
    # Kodi owns the language registry, including names outside our common labels.
    try:
        code=xbmc.convertLanguage(raw,xbmc.ISO_639_1)
        if code:return code.lower()
        code=xbmc.convertLanguage(raw,xbmc.ISO_639_2)
        if code:return code.lower()
    except Exception:pass
    return broker._normalize_lang(raw)

def languages():
    data=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,
        'method':'Settings.GetSettings','params':{'level':'expert'}})))
    setting=next((s for s in data.get('result',{}).get('settings',[])
                  if s.get('id')=='locale.subtitlelanguage'),{})
    excluded={'none','forced_only','original','default','mediadefault',''}
    rows=[{'label':r['label'],'value':r['value']} for r in setting.get('options',[])
          if r.get('value') not in excluded]
    if not rows:raise ValueError('Kodi could not return its subtitle languages. Reopen Settings and try again.')
    return rows

def preferred():
    addon=xbmcaddon.Addon('plugin.video.meganexus')
    return addon.getSetting('meganexus_subtitle_language') or (addon.getSetting('preferred_subtitle_langs') or 'en').split(',')[0]

def language_name(value):
    try:
        name=xbmc.convertLanguage(str(value),xbmc.ENGLISH_NAME)
        if name:return name
    except Exception:pass
    return NAMES.get(language(value),str(value))

def group_rows(rows):
    groups={}
    for row in rows:
        clean=dict(row);lang=language(row.get('lang') or row.get('language'))
        clean['lang']=lang;groups.setdefault(lang,[]).append(clean)
    return groups

def external_rows(context,search=False,fresh=False,enough=None):
    # Searching with an empty seed avoids the old broker's early exit when the
    # stream already supplied a sidecar. Include both sets AFTER provider search.
    initial=[]
    for raw in context.get('subtitles') or []:
        row=broker._coerce_subtitle(raw)
        if row:
            row['sourceName']=row.get('sourceName') or context.get('provider_name') or 'Stream provider'
            initial.append(row)
    if search:
        if fresh:
            # 7.0.45: Autosync comes long after the start - the start's shared deadline had
            # passed (the add-ons got no time) and its cached, cut-short answer was used
            context=dict(context);context.pop('subtitle_deadline_mono',None)
        found=broker.search_subtitles(context,initial_subtitles=[],max_results=1000,fresh=fresh,enough=enough)
        initial=broker._dedupe(initial+found)
    for row in initial:row['lang']=language(row.get('lang'))
    return initial

def prepare_selected(row,key):
    from .playback.subtitle_files import _prepare_subtitle_files
    result=_prepare_subtitle_files([row],key,prefer_local_copy=True,defer_download=False,download_timeout=DOWNLOAD_WAIT)
    if not result or str(result[0]['path']).startswith(('http://','https://')):
        raise ValueError('The selected subtitle could not be downloaded. Try another release.')
    return result[0]['path']

def auto_apply(context,player=None):
    """Search off the playback path; one matching file, never a different video."""
    from .session_store import load_session
    player=player or xbmc.Player()
    uid=context.get('playback_uid');request=context.get('meganexus_request_id')
    wanted=language(context.get('meganexus_subtitle_language') or preferred())
    home=xbmcgui.Window(10000)
    def current():
        try:
            return bool(uid and request and player.isPlayingVideo() and
                (load_session() or {}).get('playback_uid')==uid and
                home.getProperty('meganexus.playback.started')==request and
                home.getProperty('meganexus.subtitle.manual')!=request)
        except Exception:return False
    if not current():return False
    import time
    started=time.monotonic()
    # 7.0.45: the subtitle you synced for this film, while it is in Continue Watching
    # and goes on from the same source - no search, no Autosync again
    kept=kept_for(context,wanted)
    if kept:
        return _put_on(player,kept[0],kept[1],started,started)
    # Source-native releases already match this video. Search other installed
    # addons only if the source did not supply the selected language.
    def mine(rows):return [r for r in rows if language(r.get('lang'))==wanted and not machine_made(r)]
    rows=mine(external_rows(context,search=False))
    if not rows:
        # 7.0.45: a few releases in your language are enough to start with
        rows=mine(external_rows(context,search=True,enough=lambda found:len(mine(found))>=AUTO_ENOUGH))
    found_at=time.monotonic()
    if not current():return False
    # Preserve the provider's order, including numbered releases: the first that comes
    # through is put on (Autosync is there when it does not fit). 7.0.29: a release that
    # cannot be downloaded (its server is off, or answers with an error page) gives way
    # to the next one instead of leaving the film without subtitles. 7.0.45: a server
    # that is gone is passed over at once.
    from .playback.subtitle_files import reachable_hosts
    alive=reachable_hosts([r.get('url') for r in rows[:AUTO_TRIES*2]])
    rows=[r for r in rows if alive.get(_host(r),True)]
    key=context.get('video_id') or context.get('canonical_id') or uid
    # 7.0.45: at the start the film's buffering takes the line - when no release came
    # through, the same ones are asked once more a little later, when it is free
    for attempt in range(2):
        if attempt:
            if xbmc.Monitor().waitForAbort(AUTO_RETRY) or not current():return False
        for selected in rows[:AUTO_TRIES]:
            try:path=prepare_selected(selected,key)
            except ValueError:continue
            if machine_made(selected,_first_lines(path)):continue   # 7.0.45: a machine translation's notice
            if not current():return False
            return _put_on(player,path,selected,started,found_at)
    if rows:raise ValueError('The selected subtitle could not be downloaded. Try another release.')
    return False


AUTO_TRIES=8
AUTO_ENOUGH=6      # 7.0.45: releases in your language that end the search at a film's start
AUTO_RETRY=15      # 7.0.45: seconds before the releases are asked once more
DOWNLOAD_WAIT=20   # 7.0.45: a chosen subtitle's download, off the playback path
REAL_LINES=40      # 7.0.45: a real subtitle has at least this many different lines...
REAL_SHARE=.6      # ...most of its lines differ from each other...
REAL_SPAN=.4       # ...and it runs through this much of the film (10 minutes when the length is unknown)
_AI=re.compile(r'(?<![A-Za-z])AI(?![A-Za-z])')
_PLAIN_LANG=re.compile(r'[a-z]{2,3}(?:[-_][a-z0-9]{2,4})?|[a-z]+(?: [a-z]+)?(?: \([^)]*\))?')


def _put_on(player,path,row,started,found_at):
    import time
    player.setSubtitles(path);player.showSubtitles(True)
    remember_active(path,row)
    xbmc.log('[MegaNexus][perf] Subtitle on: search %.1f s, download %.1f s'%(found_at-started,time.monotonic()-found_at),xbmc.LOGINFO)
    return True


KEPT_FILE='kept_subtitles.json'
KEPT_DIR='kept_subtitles'
KEPT_MAX=60


def _kept_paths():
    from .meganexus.common import profile_path
    base=profile_path()
    return os.path.join(base,KEPT_FILE),os.path.join(base,KEPT_DIR)


def _kept_read():
    try:
        with open(_kept_paths()[0],encoding='utf-8') as handle:data=json.load(handle)
    except (OSError,ValueError):return {}
    return data if isinstance(data,dict) else {}


def _kept_write(data):
    from .meganexus.safe_io import write_json
    path,folder=_kept_paths()
    os.makedirs(folder,exist_ok=True)
    write_json(path,data)


def _identity(context):
    """(kind, the title's ids, the episode's part of the video id)."""
    from .last_source import _aliases
    head=str(context.get('canonical_id') or '');video=str(context.get('video_id') or head)
    part=video[len(head):] if head and video.startswith(head) else ('' if video==head else '|'+video)
    kind='movie' if (context.get('media_type') or 'movie')=='movie' else 'series'
    return kind,_aliases(head,context.get('imdb_id'),context.get('tmdb_id')),part


def _in_continue(record):
    """The title is in Continue Watching at this very video, not finished, not removed."""
    from . import continue_local,continue_rules
    for entry in continue_local.recent():
        kind,ids,part=_identity(entry)
        if kind!=record.get('kind') or part!=record.get('part') or not set(ids)&set(record.get('ids') or []):continue
        if entry.get('event_type')=='watched':return False
        if continue_rules.hidden(entry.get('media_type'),entry.get('canonical_id'),entry.get('updated_at')):return False
        return continue_rules.recent_enough(entry.get('updated_at'))
    return False


def _kept_prune(data):
    """Only what is in Continue Watching stays; its files with it."""
    kept={rid:record for rid,record in data.items() if isinstance(record,dict) and _in_continue(record)}
    kept=dict(sorted(kept.items(),key=lambda pair:-float(pair[1].get('saved_at') or 0))[:KEPT_MAX])
    folder=_kept_paths()[1]
    wanted={os.path.basename(str(record.get('path') or '')) for record in kept.values()}
    try:
        for name in os.listdir(folder):
            if name not in wanted:os.remove(os.path.join(folder,name))
    except OSError:pass
    return kept


def keep_synced(context,path,row):
    """7.0.45: a synced subtitle stays with its film (or episode) while it is in Continue
    Watching - the next time it goes on from the same source, this one is put on."""
    import hashlib,shutil,time
    import xbmcvfs
    kind,ids,part=_identity(context)
    if not ids or not path:return False
    rid=hashlib.sha1(json.dumps((kind,ids[0],part)).encode()).hexdigest()[:16]
    folder=_kept_paths()[1]
    os.makedirs(folder,exist_ok=True)
    source=xbmcvfs.translatePath(path)
    stamp=int(time.time())
    target=os.path.join(folder,'%s-%d%s'%(rid,stamp,os.path.splitext(source)[1] or '.srt'))
    if os.path.abspath(source)!=os.path.abspath(target):shutil.copyfile(source,target)
    data=_kept_read()
    data[rid]={'kind':kind,'ids':ids,'part':part,'lang':language((row or {}).get('lang')),'row':row or {},
               'stream':[str(context.get('stream_title') or ''),str(context.get('stream_name') or '')],
               'provider':str(context.get('provider_id') or ''),'path':target,'saved_at':time.time()}
    _kept_write(_kept_prune(data))
    return True


def _same_source(record,context):
    title,name=record.get('stream') or ['','']
    if title or str(context.get('stream_title') or ''):return title==str(context.get('stream_title') or '')
    if name or str(context.get('stream_name') or ''):return name==str(context.get('stream_name') or '')
    return record.get('provider')==str(context.get('provider_id') or '')


def kept_for(context,wanted):
    """(path, row) of the subtitle synced for this video, when it goes on (a resume)
    from the same source in the same language - else None."""
    try:
        if not (context.get('meganexus_continue') or float(context.get('resume_seconds') or 0)>0
                or float(context.get('resume_percent') or 0)>0):return None
        data=_kept_read()
        if not data:return None
        pruned=_kept_prune(data)
        if pruned!=data:_kept_write(pruned)
        kind,ids,part=_identity(context)
        for record in pruned.values():
            if record.get('kind')==kind and record.get('part')==part and set(ids)&set(record.get('ids') or []) \
                    and record.get('lang')==wanted and _same_source(record,context) and os.path.isfile(record.get('path') or ''):
                return record['path'],record.get('row') or {}
    except Exception as exc:
        xbmc.log('[MegaNexus] kept subtitle: %s'%exc,xbmc.LOGDEBUG)
    return None


def _host(row):
    return str(urlsplit(str((row or {}).get('url') or '').split('|')[0]).netloc or '').lower()


def real_text(cues,duration=0):
    """7.0.45: a subtitle and not a stand-in. Told by its text alone - whatever the
    add-on is called: enough different lines, not the same few repeated, and running
    through the film rather than its first minutes."""
    texts=[re.sub(r'\W+','',str(c[2]).lower()) for c in cues or [] if str(c[2]).strip()]
    distinct=len(set(texts))
    if distinct<REAL_LINES or distinct<REAL_SHARE*len(texts):return False
    span=cues[-1][0]-cues[0][0]
    return span>=(REAL_SPAN*duration if duration else 600)


def machine_made(row,cues=None):
    """7.0.45: a machine translation, made on request in the background - never taken
    by itself. Told by what the add-on says of it, not by its name: marked as such,
    a 'language' that is a request rather than a language, or an 'AI' notice in its
    name or first lines."""
    row=row or {}
    if any(str(row.get(k)).lower() in ('true','1') for k in ('ai_translated','machine_translated','auto_translated')):return True
    lang=str(row.get('lang') or '').strip().lower()
    if lang and not _PLAIN_LANG.fullmatch(lang):return True
    label=' '.join(str(row.get(k) or '') for k in ('displayName','name','label','title','id'))
    if _AI.search(label):return True
    return any(_AI.search(str(c[2])) for c in (cues or [])[:2])


def _first_lines(path):
    try:
        from . import subtitle_sync as sync
        return sync.parse(_read(path))[:2]
    except Exception:
        return []


AUTOSYNC='meganexus_autosync_subtitles'   # 7.0.29: Autosync subtitle offset - on for everyone


def remember_active(path,row=None):
    """7.0.29: the downloaded subtitle on screen - what the player's Sync button retimes."""
    import json
    home=xbmcgui.Window(10000)
    home.setProperty('meganexus.subtitle.path',str(path or ''))
    home.setProperty('meganexus.subtitle.row',json.dumps(row or {},default=str))
    home.setProperty('meganexus.subtitle.syncable','1' if autosync_on() else '')


def autosync_on():
    """7.0.50: the player's Sync button stays for every MegaNexus film while the option is on -
    also with the video's own subtitle or none (it then finds one of this version)."""
    from .settings_cache import cached_addon
    return (cached_addon().getSetting(AUTOSYNC) or 'true')!='false'


def _read(path):
    import xbmcvfs
    handle=xbmcvfs.File(path)
    try:raw=bytes(handle.readBytes())
    finally:handle.close()
    for codec in ('utf-8-sig','cp1250','latin-1'):
        try:return raw.decode(codec)
        except UnicodeDecodeError:continue
    return raw.decode('utf-8','replace')


def references(context,current_row,limit=16,rows=None):
    """Other subtitles of the playing title, any language, as (row, likeness):
    the stream's own first, then releases named most like the stream. Never the
    subtitle being synced. 7.0.45: a fresh search (see external_rows), up to 16, and
    spread over languages and releases - the same release in one language twice
    tells nothing new."""
    from .subtitle_sync import similarity,release_tokens
    name=' '.join(str(context.get(k) or '') for k in ('stream_title','stream_name'))
    mine=str((current_row or {}).get('url') or '')
    own=[r for r in external_rows(context,search=False) if str(r.get('url') or '')!=mine]
    seen={str(r.get('url') or '') for r in own}|{mine}
    found=[r for r in (rows if rows is not None else external_rows(context,search=True,fresh=True)) if str(r.get('url') or '') not in seen]
    def label(r):return r.get('displayName') or r.get('name') or r.get('release') or ''
    def likeness(r):return similarity(name,label(r))
    # 7.0.45: only servers that answer (a gone add-on held 11 of 16 places), and at most
    # PER_HOST from one server - the others come from other add-ons
    from .playback.subtitle_files import reachable_hosts
    alive=reachable_hosts([r.get('url') for r in own+found])
    def host(r):return str(urlsplit(str(r.get('url') or '').split('|')[0]).netloc or '').lower()
    own=[r for r in own if alive.get(host(r),True) and not machine_made(r)]
    ranked=sorted([r for r in found if alive.get(host(r),True) and not machine_made(r)],key=likeness,reverse=True)
    picked,kinds=[],set()
    for r in ranked:                                   # first: one of each release and language
        kind=(language(r.get('lang')),frozenset(release_tokens(label(r))))
        if kind in kinds:continue
        kinds.add(kind);picked.append(r)
    rest=[r for r in ranked if r not in picked]
    room=max(0,limit-len(own))
    chosen,per=[],{}
    for r in [r for r in own][:limit]+picked+rest:
        if len(chosen)>=limit:break
        h=host(r)
        if per.get(h,0)>=PER_HOST:continue
        per[h]=per.get(h,0)+1;chosen.append(r)
    owned=[r for r in chosen if r in own]
    return [(r,1.0) for r in owned]+[(r,likeness(r)) for r in chosen if r not in owned]


PER_HOST=5   # 7.0.45: references from one subtitle server at most


def _fetch_all(rows,key,wait=14.0):
    """Download the references side by side; whatever arrived within ``wait``."""
    import threading,time
    out=[None]*len(rows)
    def one(i,row):
        try:out[i]=_read(prepare_selected(row,'%s-ref%d'%(key,i)))
        except Exception:pass
    threads=[threading.Thread(target=one,args=(i,r),name='MegaNexusSyncRef',daemon=True) for i,r in enumerate(rows)]
    for th in threads:th.start()
    until=time.monotonic()+wait
    for th in threads:th.join(max(0.0,until-time.monotonic()))
    return out


def consensus(results):
    """results: [(ratio, shift, share, matches, likeness)]. Subtitles of most releases
    are timed alike: the timing most references agree on (a release named like the
    stream counts more) is the video's. Returns (ratio, shift, share, agreeing) or None."""
    groups=[]
    for found in results:
        ratio,shift,share,_,like=found
        weight=share*(1+2*like)
        for group in groups:
            if abs(group['ratio']-ratio)<1e-3 and abs(group['shift']-shift)<.35:
                group['weight']+=weight;group['members'].append(found);break
        else:groups.append({'ratio':ratio,'shift':shift,'weight':weight,'members':[found]})
    if not groups:return None
    best=max(groups,key=lambda g:g['weight'])
    members=best['members']
    # 7.0.45: one subtitle alone decides only when it is the stream's own or very like it;
    # a second group almost as strong means the timings disagree
    sure=len(members)>=2 or members[0][4]>=.99 or (members[0][4]>=.5 and members[0][2]>=.6)
    rivals=[g for g in groups if g is not best and g['weight']>=.8*best['weight']]
    if not sure or (rivals and len(members)<3):return None
    lead=max(members,key=lambda m:(m[4],m[2]))
    shifts=sorted(m[1] for m in members if abs(m[0]-lead[0])<1e-3)
    return lead[0],shifts[len(shifts)//2],lead[2],len(members)   # the agreeing subtitles' median


CUTS=(('extended','Extended'),('directors','Director\'s Cut'),('unrated','Unrated'),('uncut','Uncut'),
      ('theatrical','Theatrical'),('remastered','Remastered'))   # 7.0.45: the film's version, from names
FIT=.85         # 7.0.45: without other subtitles: covering less of the film is a part (CD1 of 2) or another cut
REACH=240       # ... with them: a subtitle of this version ends within this many seconds of the longest that fits
CANDIDATES=8    # 7.0.45: subtitles in your language tried at once when yours does not belong to this film
SEARCH_BATCHES=4  # ... and that many rounds of them at most


def _clock(seconds):
    seconds=int(seconds or 0)
    return '%d:%02d:%02d'%(seconds//3600,seconds%3600//60,seconds%60)


def cut_of(text):
    """'extended' / 'directors' / ... from a release or file name, else ''."""
    words=set(re.findall(r'[a-z]+',str(text or '').lower()))
    if 'director' in words or 'directors' in words or 'dc' in words:return 'directors'
    return next((key for key,_ in CUTS if key in words),'')


def is_part(text):
    """'...CD1', '1of2', 'part 2' - a subtitle split in two."""
    return bool(re.search(r'(?i)(?:\bcd[ ._-]?[12]\b|\b[12][ ._-]?of[ ._-]?2\b|\bpart[ ._-]?[12]\b|\b[12]cd\b)',str(text or '')))


def version_end(subtitles,duration):
    """Where the subtitles of this version end: the longest of them that still ends
    within the film (credits run on - Return of the King Extended: 4:23 film, its
    subtitles end at 4:00, the cinema cut's at 3:12). 0 when unknown."""
    spans=[cues[-1][0] for cues in subtitles if cues and (not duration or cues[-1][0]<=duration+120)]
    return max(spans) if spans else 0


def fits(cues,duration,end=0):
    """The subtitle covers this version of the film: it runs as far as the longest
    subtitle that fits (the cinema cut's or a CD1 stop much earlier), not beyond it."""
    if not cues:return False
    from .subtitle_sync import RATIOS
    def one(span):
        if duration and span>duration+120:return False
        if end:return span>=end-REACH
        return not duration or span>=FIT*duration
    # 7.0.45: one timed for another frame rate (25 fps for a 23.976 film) ends earlier
    # or later by that much - Autosync lines it up, so it still belongs to this version
    return any(one(cues[-1][0]*ratio) for ratio in RATIOS)


def autosync(context,key='sync',duration=0,attempt=1,tried=()):
    """(new path, description[, new row]) or raises ValueError with what is wrong.
    7.0.45: when the subtitle on screen does not belong to this film - a part of a
    subtitle split in two, or made for another cut (Extended, Director's Cut) - a
    subtitle in the same language that does is looked for, checked against the
    other subtitles (any language) that fit the film, lined up and put on.
    7.0.50: the video's own subtitle tracks (their times from the Matroska index,
    mkv_subtitle_times) come first - they are timed to exactly this release. Each
    press goes further (``attempt``): 1 as before; 2 twice the other subtitles and
    piece by piece (a release with a scene added or cut); 3+ another subtitle in your
    language, twice as many tried, none of those tried before (``tried``)."""
    import hashlib,json,os,threading
    import xbmcvfs
    from . import subtitle_sync as sync
    from . import mkv_subtitle_times
    home=xbmcgui.Window(10000)
    embedded=[]
    reader=threading.Thread(target=lambda:embedded.extend(mkv_subtitle_times.references(context)),
                            name='MegaNexusSyncEmbedded',daemon=True)
    reader.start()                       # read while the add-ons are searched
    path=home.getProperty('meganexus.subtitle.path')
    # 7.0.50: no downloaded subtitle on screen (the video's own, or none) - one in your
    # language that belongs to this version is looked for, as when yours does not fit
    try:row=json.loads(home.getProperty('meganexus.subtitle.row') or '{}') if path else {}
    except ValueError:row={}
    target=sync.parse(_read(path)) if path else []
    if path and len(target)<sync.MIN_MATCHES:raise ValueError('This subtitle has too few lines to sync.')
    stream=' '.join(str(context.get(k) or '') for k in ('stream_title','stream_name'))
    cut=cut_of(stream)
    film=('%s · %s'%(_clock(duration),dict(CUTS)[cut]) if cut else _clock(duration)) if duration else ''
    wanted=language(row.get('lang') or row.get('language') or preferred())
    allrows=external_rows(context,search=True,fresh=True)
    refs=references(context,row,limit=16 if attempt<2 else 32,rows=allrows)
    texts=_fetch_all([r for r,_ in refs],key) if refs else []
    reader.join(mkv_subtitle_times.BUDGET+1)
    own=[cues for cues,_ in embedded[:2] if len(cues)>=sync.MIN_MATCHES]   # the video's own timing
    if own:xbmc.log('[MegaNexus] Autosync subtitle: the video\'s own subtitle timing (%d lines) is the reference'%len(own[0]),xbmc.LOGINFO)
    if not refs and not own:raise ValueError('The subtitle add-ons returned no other subtitle of this title to compare with.')
    if refs and not any(texts) and not own:raise ValueError('The other subtitles of this title could not be downloaded. Try again in a moment.')
    parsed=[(sync.parse(text) if text else [],like) for (_,like),text in zip(refs,texts)]
    parsed=[(cues,like) if real_text(cues,duration) and not machine_made({},cues) else ([],like) for cues,like in parsed]
    end=version_end([cues for cues,_ in parsed if len(cues)>=sync.MIN_MATCHES],duration)
    # the subtitles that cover this version of the film are the timing it is checked against
    truth=[(cues,like) for cues,like in parsed if len(cues)>=sync.MIN_MATCHES and fits(cues,duration,end)] or \
          [(cues,like) for cues,like in parsed if len(cues)>=sync.MIN_MATCHES]

    basis=[]
    def judge(cues):
        for ref in own:                  # 7.0.50: the video's own subtitles decide when they fit
            found=sync.align(cues,ref)
            if found:
                basis[:]=[ref,'video'];return found[0],found[1],found[2],1
        results=[]
        for ref,like in truth:
            found=sync.align(cues,ref)
            if found:results.append(found+(like,))
        verdict=consensus(results)
        if verdict:
            # the reference that fits that timing best: for the piece-by-piece try
            fitting=max((ref for ref,_ in truth),key=lambda ref:sync.share_of(cues,ref,verdict[0],verdict[1]),default=None)
            basis[:]=[fitting,'subtitles']
        return verdict

    def write(cues,best,source,retimed=None):
        ratio,shift=(best[0],best[1]) if best else (1.0,0.0)
        folder=os.path.dirname(xbmcvfs.translatePath(path)) if path else ''
        folder=folder or xbmcvfs.translatePath('special://temp/')
        name='synced-%s.srt'%hashlib.sha1(('%s|%s|%s|%s'%(source,ratio,shift,'pieces' if retimed else '')).encode('utf-8')).hexdigest()[:12]
        out=os.path.join(folder,name)
        with open(out,'w',encoding='utf-8') as handle:handle.write(sync.to_srt(retimed if retimed else sync.retime(cues,ratio,shift)))
        return out

    def by_pieces(cues,best):
        """7.0.50, second press on: piece by piece when it meets the reference clearly better."""
        if attempt<2 or not best or not basis or basis[0] is None:return None
        found=sync.align_pieces(cues,basis[0],best[0],best[1])
        if not found:return None
        whole=sync.share_of(cues,basis[0],best[0],best[1])
        return found[0] if found[1]>=max(sync.MIN_SHARE,whole+.08) else None

    def told(text):
        return ('%s · lined up with the video\'s own subtitles'%text) if basis and basis[1]=='video' else text

    mine_fits=(bool(path) and attempt<3 and fits(target,duration,end) and not is_part(row.get('name') or row.get('displayName') or '')
               and real_text(target,duration) and not machine_made(row,target))
    best=judge(target) if mine_fits else None
    if best:
        ratio,shift,share,agree=best
        pieces=by_pieces(target,best)
        if pieces:return write(target,best,path,pieces),told('Lined up piece by piece (a scene added or cut in this release)')
        if abs(ratio-1)<1e-4 and abs(shift)<.15:
            return path,told('Already in sync (%d subtitles agree)'%agree)+(' - press Sync again to try further' if attempt<3 else '')
        return write(target,best,path),told('%s · %d subtitles agree'%(sync.describe(ratio,shift),agree))
    # yours does not belong to this film: another one in the same language that does
    mine=str(row.get('url') or '')
    def label(r):return r.get('displayName') or r.get('name') or r.get('release') or ''
    from .subtitle_sync import similarity
    skip=set(str(u) for u in tried or ())|{mine}
    pool=[r for r in allrows if language(r.get('lang'))==wanted and str(r.get('url') or '') not in skip and not machine_made(r)]
    from .playback.subtitle_files import reachable_hosts
    alive=reachable_hosts([r.get('url') for r in pool])
    pool=[r for r in pool if alive.get(str(urlsplit(str(r.get('url') or '').split('|')[0]).netloc or '').lower(),True)]
    pool.sort(key=lambda r:(bool(cut) and cut_of(label(r))==cut,not is_part(label(r)),similarity(stream,label(r))),reverse=True)
    if not pool:
        raise ValueError('%sNo %s%s subtitle of this film was found%s.'
                         %(('Film: %s. '%film) if film else '','other ' if path else '',language_name(wanted),' - yours was kept' if path else ''))
    # 7.0.45: tried batch after batch (not just the first few) until one belongs to this
    # version - the tool finds it, you are not asked to
    picks,spare=[],None
    wide=2 if attempt>=3 else 1          # 7.0.50: the third press tries twice as many
    for first in range(0,min(len(pool),CANDIDATES*SEARCH_BATCHES*wide),CANDIDATES*wide):
        batch=pool[first:first+CANDIDATES*wide]
        for candidate,text in zip(batch,_fetch_all(batch,'%s-pick%d'%(key,first))):
            cues=sync.parse(text) if text else []
            if len(cues)<sync.MIN_MATCHES or not fits(cues,duration,end) or is_part(label(candidate)):continue
            if not real_text(cues,duration) or machine_made(candidate,cues):continue
            verdict=judge(cues)
            if verdict:picks.append((verdict[3],verdict[2],candidate,cues,verdict))
            elif spare is None:spare=(candidate,cues)
        if picks:break
    if not picks and mine_fits:
        # yours is of this version and no other did better: it stays as it is
        return path,'%sKept yours - it belongs to this version, the other subtitles gave no common timing'%(('%s · '%film) if film else '')
    if not picks and spare:
        # none could be checked against other subtitles, but this one is of this version
        candidate,cues=spare
        out=write(cues,None,str(candidate.get('url') or ''))
        return out,('%sSwitched to %s (%s) · made for this version'%(('%s · '%film) if film else '',
                                                                    label(candidate)[:60] or language_name(wanted),language_name(wanted))),candidate
    if not picks:
        raise ValueError('%sNo %s subtitle of this version (%s) was found - yours was kept.'
                         %(('Film: %s. '%film) if film else '',language_name(wanted),dict(CUTS)[cut] if cut else 'this release'))
    picks.sort(key=lambda p:(p[0],p[1]),reverse=True)
    _,_,candidate,cues,verdict=picks[0]
    judge(cues)                          # the basis of the chosen one (video / subtitles)
    pieces=by_pieces(cues,verdict)
    out=write(cues,verdict,str(candidate.get('url') or ''),pieces)
    ratio,shift,_,agree=verdict
    timing='piece by piece' if pieces else ('in sync' if abs(ratio-1)<1e-4 and abs(shift)<.15 else sync.describe(ratio,shift))
    return out,told('%sSwitched to %s (%s) · %s · %d subtitles agree'%(('%s · '%film) if film else '',label(candidate)[:60] or language_name(wanted),
                                                                       language_name(wanted),timing,agree)),candidate
