# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""When the subtitles inside the playing video show (7.0.50, for Autosync).

A Matroska video (.mkv / .webm) keeps an index (Cues) of where its frames are,
and mkvmerge indexes every subtitle frame. So the times of the video's own
subtitle tracks - timed to exactly this release - can be read from the index
with a few HTTP range requests, without playing or downloading the film. They
are the best reference Autosync has: the subtitles found online were often
timed alike for another release (the Onslaught WEB-DL ran 10 s apart from all
of them, and Autosync called them "in sync").

Best effort, within a time and byte budget: a server without range requests,
another container or a file without subtitle index entries gives nothing, and
Autosync works as before.
"""
import time
from urllib.request import Request, urlopen

PROBE = 512 * 1024             # the first request: the header, usually Info, Tracks and the SeekHead
MAX_ELEMENT = 8 * 1024 * 1024  # an Info / Tracks / Cues element read whole at most
MAX_BYTES = 24 * 1024 * 1024   # all requests together
MAX_REQUESTS = 12
FIRST_READ = 64 * 1024     # an element's first request (Info and Tracks fit; Cues often too)
BUDGET = 7.0                   # seconds for everything
MIN_CUES = 30                  # a track with fewer is not a dialogue track (forced, signs)
CUE_LONGEST = 4.0              # a line without its own duration shows until the next, this long at most
LAST_CUE = 2.0

EBML, SEGMENT, SEEK_HEAD, SEEK, SEEK_ID, SEEK_POSITION = 0x1A45DFA3, 0x18538067, 0x114D9B74, 0x4DBB, 0x53AB, 0x53AC
INFO, TIMESTAMP_SCALE, TRACKS, TRACK_ENTRY, CUES, CLUSTER = 0x1549A966, 0x2AD7B1, 0x1654AE6B, 0xAE, 0x1C53BB6B, 0x1F43B675
TRACK_NUMBER, TRACK_TYPE, CODEC_ID, LANGUAGE, LANGUAGE_BCP47, NAME, FLAG_FORCED = 0xD7, 0x83, 0x86, 0x22B59C, 0x22B59D, 0x536E, 0x55AA
CUE_POINT, CUE_TIME, CUE_TRACK_POSITIONS, CUE_TRACK, CUE_DURATION = 0xBB, 0xB3, 0xB7, 0xF7, 0xB2
SUBTITLE = 0x11
UNKNOWN = -1


class Unavailable(Exception):
    pass


def kodi_headers(headers=None):
    """The source's own headers, with Kodi's User-Agent when it names none: servers that
    play in Kodi refused Python's (403 - Onslaught's embedded subtitles were never read)."""
    out = dict(headers or {})
    if not any(k.lower() == 'user-agent' for k in out):
        try:
            import xbmc
            out['User-Agent'] = xbmc.getUserAgent() or 'Kodi'
        except Exception:
            out['User-Agent'] = 'Kodi/21.0 (MegaNexus)'
    return out


def _vint(data, pos, marker):
    """(value, length) of an EBML variable-length integer; ``marker``: keep the length bit (IDs)."""
    if pos >= len(data):
        raise Unavailable('short')
    first = data[pos]
    length = 1
    mask = 0x80
    while length <= 8 and not first & mask:
        mask >>= 1
        length += 1
    if length > 8 or pos + length > len(data):
        raise Unavailable('bad vint')
    value = first if marker else first & (mask - 1)
    for byte in data[pos + 1:pos + length]:
        value = (value << 8) | byte
    if not marker and value == (1 << (7 * length)) - 1:
        value = UNKNOWN                              # "size unknown"
    return value, length


def _elements(data, start, end):
    """(id, data start, data end) of the elements in data[start:end]; a cut-off last one ends at ``end``."""
    pos = start
    while pos < end:
        try:
            eid, n = _vint(data, pos, True)
            size, m = _vint(data, pos + n, False)
        except Unavailable:
            return
        begin = pos + n + m
        stop = end if size == UNKNOWN else min(end, begin + size)
        yield eid, begin, stop, (size == UNKNOWN or begin + size > end)
        if size == UNKNOWN or begin + size > end:
            return
        pos = begin + size


def _uint(data, start, end):
    value = 0
    for byte in data[start:end]:
        value = (value << 8) | byte
    return value


class _Reader(object):
    def __init__(self, url, headers, opener, budget):
        self.url, self.headers, self.opener = url, kodi_headers(headers), opener
        self.until = time.monotonic() + budget
        self.requests = self.bytes = 0

    def get(self, start, length):
        left = self.until - time.monotonic()
        if left <= 0 or self.requests >= MAX_REQUESTS or self.bytes + length > MAX_BYTES:
            raise Unavailable('budget')
        self.requests += 1
        headers = dict(self.headers, Range='bytes=%d-%d' % (start, start + length - 1))
        with self.opener(Request(self.url, headers=headers), timeout=max(1.0, left)) as reply:
            status = getattr(reply, 'status', None) or reply.getcode()
            if status != 206 and not (status == 200 and start == 0):
                raise Unavailable('no range requests')
            data = reply.read(length)
        self.bytes += len(data)
        return data


def _element_at(reader, position, limit):
    """The whole element starting at ``position``: (id, its bytes, data start, data end)."""
    head = reader.get(position, FIRST_READ)      # small elements come whole with their header
    eid, n = _vint(head, 0, True)
    size, m = _vint(head, n, False)
    if size == UNKNOWN or size > limit:
        raise Unavailable('too large')
    total = n + m + size
    data = head[:total] if total <= len(head) else head + reader.get(position + len(head), total - len(head))
    if len(data) < total:
        raise Unavailable('short')
    return eid, data, n + m, total


def _tracks(data, start, end):
    found = {}
    for eid, begin, stop, _ in _elements(data, start, end):
        if eid != TRACK_ENTRY:
            continue
        entry = {'language': 'eng', 'codec': '', 'name': '', 'forced': False}
        number = kind = 0
        for cid, b, s, _ in _elements(data, begin, stop):
            if cid == TRACK_NUMBER:
                number = _uint(data, b, s)
            elif cid == TRACK_TYPE:
                kind = _uint(data, b, s)
            elif cid == CODEC_ID:
                entry['codec'] = data[b:s].decode('ascii', 'replace')
            elif cid in (LANGUAGE, LANGUAGE_BCP47):
                entry['language'] = data[b:s].decode('ascii', 'replace').strip('\x00') or entry['language']
            elif cid == NAME:
                entry['name'] = data[b:s].decode('utf-8', 'replace')
            elif cid == FLAG_FORCED:
                entry['forced'] = bool(_uint(data, b, s))
        if number and kind == SUBTITLE:
            found[number] = entry
    return found


def _cues(data, start, end, wanted):
    """{track: [(start ticks, duration ticks or None)]} for the subtitle tracks."""
    times = {}
    for eid, begin, stop, _ in _elements(data, start, end):
        if eid != CUE_POINT:
            continue
        moment = None
        positions = []
        for cid, b, s, _ in _elements(data, begin, stop):
            if cid == CUE_TIME:
                moment = _uint(data, b, s)
            elif cid == CUE_TRACK_POSITIONS:
                track = duration = None
                for pid, pb, ps, _ in _elements(data, b, s):
                    if pid == CUE_TRACK:
                        track = _uint(data, pb, ps)
                    elif pid == CUE_DURATION:
                        duration = _uint(data, pb, ps)
                positions.append((track, duration))
        if moment is None:
            continue
        for track, duration in positions:
            if track in wanted:
                times.setdefault(track, []).append((moment, duration))
    return times


def read(url, headers=None, opener=urlopen, budget=BUDGET):
    """{track number: {'language', 'codec', 'name', 'forced', 'cues': [(start, end, '')]}} of
    the video's subtitle tracks with enough indexed lines; raises Unavailable."""
    url = str(url or '').split('|', 1)[0]
    if not url.startswith(('http://', 'https://')):
        raise Unavailable('not http')
    reader = _Reader(url, headers, opener, budget)
    head = reader.get(0, PROBE)
    eid, n = _vint(head, 0, True)
    if eid != EBML:
        raise Unavailable('not Matroska')
    size, m = _vint(head, n, False)
    pos = n + m + size
    eid, n = _vint(head, pos, True)
    if eid != SEGMENT:
        raise Unavailable('no Segment')
    size, m = _vint(head, pos + n, False)
    segment = pos + n + m                              # SeekPosition counts from here
    scale, tracks, cue_bytes, seeks = 1000000, None, None, {}

    def look(data, start, end, offset):
        nonlocal scale, tracks, cue_bytes
        for eid, begin, stop, cut in _elements(data, start, end):
            if eid == CLUSTER:
                return
            if eid == SEEK_HEAD and not cut:
                for sid, b, s, _ in _elements(data, begin, stop):
                    if sid != SEEK:
                        continue
                    target = where = None
                    for kid, kb, ks, _ in _elements(data, b, s):
                        if kid == SEEK_ID:
                            target = _uint(data, kb, ks)
                        elif kid == SEEK_POSITION:
                            where = _uint(data, kb, ks)
                    if target and where is not None:
                        seeks.setdefault(target, segment + where)
            elif eid == INFO and not cut:
                for iid, b, s, _ in _elements(data, begin, stop):
                    if iid == TIMESTAMP_SCALE:
                        scale = _uint(data, b, s) or scale
            elif eid == TRACKS and not cut:
                tracks = _tracks(data, begin, stop)
            elif eid == CUES and not cut:
                cue_bytes = (data, begin, stop)

    look(head, segment, len(head), 0)
    for wanted in (TRACKS, INFO, CUES):
        missing = {TRACKS: tracks is None, INFO: False, CUES: cue_bytes is None}[wanted]
        if wanted == INFO and wanted in seeks and seeks[wanted] >= len(head):
            missing = True
        if missing and wanted in seeks:
            eid, data, begin, stop = _element_at(reader, seeks[wanted], MAX_ELEMENT)
            if eid == wanted:
                look(data, 0, len(data), seeks[wanted])
        if wanted == TRACKS and not tracks:
            raise Unavailable('no subtitle tracks')
    if cue_bytes is None:
        raise Unavailable('no index')
    times = _cues(cue_bytes[0], cue_bytes[1], cue_bytes[2], set(tracks))
    out = {}
    for track, entries in times.items():
        if len(entries) < MIN_CUES:
            continue
        entries.sort()
        cues = []
        for i, (moment, duration) in enumerate(entries):
            start = moment * scale / 1e9
            if duration:
                end = start + duration * scale / 1e9
            elif i + 1 < len(entries):
                end = min(entries[i + 1][0] * scale / 1e9, start + CUE_LONGEST)
            else:
                end = start + LAST_CUE
            cues.append((start, max(end, start + .2), ''))
        out[track] = dict(tracks[track], cues=cues)
    if not out:
        raise Unavailable('no indexed subtitle lines')
    return out


def references(context, opener=urlopen, budget=BUDGET):
    """The playing video's own subtitle timings for Autosync: [(cues, label)] - the dialogue
    tracks first (forced / signs tracks last), [] when they cannot be read."""
    url = str(context.get('stream_url') or '')
    headers = context.get('request_headers') or {}
    try:
        tracks = read(url, headers, opener, budget)
    except Exception as exc:
        try:                             # 7.0.50: why, in the log (never the link)
            import xbmc
            xbmc.log('[MegaNexus] Autosync subtitle: the video\'s own subtitles not read (%s)'
                     % (str(exc)[:80] if isinstance(exc, Unavailable) else type(exc).__name__), xbmc.LOGINFO)
        except Exception:
            pass
        return []
    ranked = sorted(tracks.values(), key=lambda t: (t['forced'], -len(t['cues'])))
    return [(t['cues'], 'embedded %s%s' % (t['language'], (' · ' + t['name']) if t['name'] else '')) for t in ranked]
