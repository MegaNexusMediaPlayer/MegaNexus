# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus data/playback boundary. No skins, source races, sorting or quality filters."""
import re
_ORIGIN = 'mnx-c46c1220e062'


def provider(role, providers=None):
    from .meganexus import addon_registry
    providers = list(providers if providers is not None else addon_registry.list_providers())
    from .settings_snapshot import setting
    chosen = setting('meganexus_' + role + '_provider')
    if chosen:
        return next((p for p in providers if p.get('id') == chosen), None)
    needle = 'aiometadata' if role == 'metadata' else 'aiostreams'
    candidates = [p for p in providers if needle in re.sub(r'[^a-z0-9]', '',
        (str((p.get('manifest') or {}).get('id','')) + str((p.get('manifest') or {}).get('name','')) + str(p.get('name',''))).lower())]
    if len(candidates)==1:return candidates[0]
    resource='meta' if role=='metadata' else 'stream'
    compatible=[p for p in providers if resource in {r.get('name') if isinstance(r,dict) else r for r in (p.get('manifest') or {}).get('resources') or []}]
    return compatible[0] if len(compatible)==1 else None


def metadata(media_type, canonical_id, timeout=8, preferred=''):
    """Resolve only through enabled, compatible add-ons; never relabel another title."""
    import time
    from .meganexus.addon_wire import fetch_meta
    from . import metadata_providers
    from .resource_support import same_identity
    sources = metadata_providers.enabled(media_type, canonical_id, preferred=preferred)
    deadline = time.monotonic() + max(1, timeout)
    reasons = [] if sources else ['no switched-on metadata add-on for this ID']
    for index, source in enumerate(sources):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            reasons.append('no time left')
            break
        try:
            data = fetch_meta(source, media_type, canonical_id,
                              timeout_override=max(.25, min(4, remaining / max(1, len(sources)-index))), retry=False, rate_wait=.1)
            meta = (data or {}).get('meta')
            if not same_identity(meta, media_type, canonical_id):
                reasons.append('%s: %s' % (source.get('name') or source.get('id'),
                                           'another title (%s %s)' % ((meta or {}).get('type'), str((meta or {}).get('id') or '')[:24])
                                           if meta else 'no details'))
                continue
            from .hub import _meta_picture_urls
            from .title_details import normalize_people_art
            meta = normalize_people_art(_meta_picture_urls(source, meta), source)
            result = dict(meta, id=canonical_id, type=media_type,
                          _meganexus_metadata_provider=source['id'])
            if media_type == 'series':
                try:
                    from .watch_nextup import remember
                    remember(result, source['id'])
                except Exception:
                    pass
            return result
        except Exception as exc:
            # Configured URLs and keys must not escape into logs or UI errors.
            reasons.append('%s: %s' % (source.get('name') or source.get('id'), type(exc).__name__))
            continue
    fallback = _fallback_metadata(media_type, canonical_id, reasons)
    try:   # 7.0.31: why a title page says "Retry details" (or which stand-in answered)
        import xbmc
        xbmc.log('[MegaNexus] details %s for %s %s - %s' % ('from %s' % fallback['_meganexus_fallback'] if fallback else 'unavailable',
                 media_type, str(canonical_id)[:40], '; '.join(reasons) or 'no add-on'), xbmc.LOGINFO)
    except Exception:
        pass
    if fallback:
        return fallback
    if not sources:
        raise ValueError('Enable a metadata add-on supporting this title ID in Settings > Add-ons.')
    raise ValueError('No enabled metadata add-on returned matching details. Check the collection mapping and connection.')


def _fallback_metadata(media_type, canonical_id, reasons, timeout=5):
    """7.0.31: when the switched-on metadata add-ons give no details (an ID they
    do not know, another title, a timeout), the MegaNexus Catalog Addon - always
    installed, also when switched off - answers for the title's IMDb ID, found
    through TMDb for a tmdb: ID when a TMDb key is set; a film may also come from
    TMDb itself. The title is never guessed: the add-on must return the same IMDb
    ID, and a TMDb ID is only translated through TMDb's own external IDs."""
    from .meganexus.addon_wire import fetch_meta
    from .resource_support import same_identity
    cid = str(canonical_id or '')
    kind = 'series' if media_type in ('series', 'tv', 'show', 'tvshow', 'episode') else 'movie'
    imdb = cid.split(':')[0] if cid.startswith('tt') else ''
    tmdb = cid.split(':', 1)[1].split(':')[0] if cid.startswith('tmdb:') else ''
    try:
        from . import tmdb_api
        keyed = bool(tmdb_api.api_key())
    except Exception:
        tmdb_api, keyed = None, False
    if not imdb and tmdb and keyed:
        imdb = tmdb_api.imdb_of(tmdb, kind, timeout=4)
    if imdb:
        try:
            from . import default_setup
            from .meganexus import addon_registry
            builtin = default_setup.builtin_provider(addon_registry.list_providers()) or {
                'id': 'meganexus-catalog', 'name': default_setup.CATALOG_NAME, 'manifest': default_setup.bundled_manifest(),
                'manifest_url': default_setup.CATALOG_URL, 'base_url': default_setup.CATALOG_HOST}
            meta = (fetch_meta(builtin, kind, imdb, timeout_override=timeout, retry=False, rate_wait=.1) or {}).get('meta')
            if same_identity(meta, kind, imdb):
                return dict(meta, id=canonical_id, type=media_type, imdb_id=imdb,
                            _meganexus_metadata_provider=builtin['id'], _meganexus_fallback='MegaNexus Catalog')
            reasons.append('MegaNexus Catalog: %s' % ('another title' if meta else 'no details'))
        except Exception as exc:
            reasons.append('MegaNexus Catalog: %s' % type(exc).__name__)
    if kind == 'movie' and keyed and (tmdb or imdb):
        # Series need their episodes, which only an add-on (or the MegaNexus Catalog) lists.
        try:
            found = tmdb_api.meta_of(tmdb_id=tmdb, imdb_id=imdb, media_type='movie')
        except Exception:
            found = {}
        if found.get('name') and (not tmdb or str(found.get('tmdb_id')) == tmdb):
            return {'id': canonical_id, 'type': media_type, 'name': found['name'], 'poster': found.get('poster') or '',
                    'background': found.get('fanart') or '', 'logo': found.get('clearlogo') or '',
                    'description': found.get('description') or '', 'releaseInfo': found.get('year') or '',
                    'year': found.get('year') or '', 'genres': found.get('genres') or [],
                    'runtime': ('%d min' % found['runtime']) if found.get('runtime') else '',
                    'imdbRating': found.get('imdbRating') or '', 'imdb_id': found.get('imdb_id') or imdb,
                    'tmdb_id': found.get('tmdb_id') or tmdb, 'director': [found['director']] if found.get('director') else [],
                    'cast': [c.get('name') for c in found.get('cast') or [] if c.get('name')],
                    '_meganexus_metadata_provider': 'tmdb', '_meganexus_fallback': 'TMDb'}
        reasons.append('TMDb: no details')
    return None


STREAM_TIMEOUT = 20
STREAM_GRACE = 2.5
SLOW_TIMEOUT = 60      # 7.0.43: the open source list waits this long for slow add-ons


def _assemble(results, servers, sources, media_type):
    """The rows found so far: own servers first, then the configured add-on order
    (not arrival order), each link once, best first."""
    rows = [row for source in servers + sources for row in results.get(source['id'], [])]
    # 7.0.29: the same link once (several configurations of one add-on gave every
    # source two or three times).
    seen, unique = set(), []
    for row in rows:
        key = row.get('url') or (row.get('infoHash') and '%s:%s' % (row.get('infoHash'), row.get('fileIdx'))) or ''
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        unique.append(row)
    rows = unique
    # 7.0.12: best first by the user's stream preferences (Playback > Automatic stream choice).
    try:
        from . import stream_choice
        rows = stream_choice.order(rows, media_type)
    except Exception as exc:
        import xbmc
        xbmc.log('[MegaNexus] stream preferences not applied: %s' % exc, xbmc.LOGWARNING)
    return rows


def imdb_video_id(media_type, video_id):
    """tmdb:123 -> tt..., tmdb:123:1:2 -> tt...:1:2 (TMDb's external IDs, cached);
    '' when there is no TMDb key or no IMDb ID."""
    value = str(video_id or '')
    if not value.startswith('tmdb:'):
        return ''
    parts = value.split(':')
    try:
        from . import tmdb_api
        kind = 'series' if media_type in ('series', 'tv', 'show', 'tvshow', 'episode') else 'movie'
        imdb = tmdb_api.imdb_of(parts[1], kind, timeout=4)
    except Exception:
        imdb = ''
    return ':'.join([imdb] + parts[2:]) if imdb else ''


_ID_SAMPLES = {'imdb': 'tt0000001', 'tmdb': 'tmdb:1'}


def _id_kind(video_id):
    value = str(video_id or '')
    return 'imdb' if value.startswith('tt') else 'tmdb' if value.startswith('tmdb:') else ''


def tmdb_video_id(media_type, video_id):
    """tt... -> tmdb:123, tt...:1:2 -> tmdb:123:1:2 (TMDb's find, cached); '' when unknown."""
    value = str(video_id or '')
    if not value.startswith('tt'):
        return ''
    parts = value.split(':')
    key = ('tmdb', media_type, parts[0])
    if key not in _ALIASES:
        try:
            from . import tmdb_api
            kind = 'series' if media_type in ('series', 'tv', 'show', 'tvshow', 'episode') else 'movie'
            _ALIASES[key] = tmdb_api.id_for_imdb(parts[0], kind) or ''
        except Exception:
            return ''
    found = _ALIASES[key]
    return ':'.join(['tmdb:' + found] + parts[1:]) if found else ''


_ALIASES = {}


def _stream_sources(stream_providers, media_type, video_id):
    """(sources in the user's order, {id: ID or a function giving it}) - for every
    switched-on stream add-on that takes this title in some form."""
    import threading
    from .resource_support import supports
    kind = _id_kind(video_id)
    other = {'tmdb': 'imdb', 'imdb': 'tmdb'}.get(kind)
    lock, memo = threading.Lock(), {}

    def alias():
        with lock:                       # one lookup, shared by every add-on that needs it
            if 'id' not in memo:
                memo['id'] = (imdb_video_id if other == 'imdb' else tmdb_video_id)(media_type, video_id)
            return memo['id']

    def preferred(takes_original):
        return (lambda: alias() or video_id) if takes_original else (lambda: alias() or '')

    sources = stream_providers.enabled(media_type, video_id)
    ids = {}
    for source in sources:
        takes_other = bool(other) and supports(source, 'stream', media_type, _ID_SAMPLES[other])
        ids[source['id']] = preferred(True) if other == 'imdb' and takes_other else video_id   # IMDb first
    if other:
        try:
            entries = list(stream_providers.entries())
        except Exception:
            entries = []
        extra = [source for source, on in entries if on and source['id'] not in ids
                 and supports(source, 'stream', media_type, _ID_SAMPLES[other])]
        if extra:
            ids.update((source['id'], preferred(False)) for source in extra)
            place = {source['id']: index for index, (source, _) in enumerate(entries)}
            sources = sorted(sources + extra, key=lambda source: place.get(source['id'], len(place)))   # the user's order
    return sources, ids


def streams(media_type, video_id, complete=False, on_update=None, patience=None, on_waiting=None, on_start=None):
    """Query enabled providers independently and retain each provider's ordering.
    ``complete`` (7.0.29, the source list): wait for every add-on (up to
    STREAM_TIMEOUT, or ``patience`` seconds - 7.0.43: the open list, SLOW_TIMEOUT)
    - a choice must show them all, not only the fastest.
    ``on_update(rows)`` gets the rows found so far after every answer, so the
    source list can open with the first ones and grow; ``on_waiting(names)`` the
    add-ons still searching. 7.0.43: an add-on that answers after the wait is kept
    (late_streams) and given at once next time."""
    from concurrent.futures import ThreadPoolExecutor
    from . import stream_providers
    from .meganexus.addon_wire import get_json, build_resource_url
    # 7.0.43: every switched-on add-on is asked by the ID it takes best, read from its
    # manifest - nothing per add-on. An add-on that takes IMDb IDs gets the IMDb ID
    # (the Stremio standard every add-on understands: Usenet Streamer, for one, takes
    # tmdb: but finds no title for it and searched nothing); tmdb: only goes to the
    # add-ons that take tmdb: but not IMDb IDs. The other ID is looked up once
    # (TMDb, cached) inside the threads of the add-ons that need it - nobody waits
    # for it. 7.0.31-7.0.42 used the IMDb ID only when NO add-on took tmdb:.
    sources, ids = _stream_sources(stream_providers, media_type, video_id)
    # 6.0.39 (beta): the user's own Plex / Jellyfin servers, when switched on,
    # are searched at the same time and listed first.
    try:
        from . import media_servers
        server_jobs = media_servers.source_jobs(media_type, video_id)
    except Exception:
        server_jobs = []
    # 7.0.12: TorBox / Premiumize built in (no add-on), searched at the same time;
    # 7.0.37: Offcloud and Easynews, the IPTV lists' films and series ("IPTV VOD",
    # while IPTV is set up), and a tmdb: title by its IMDb ID for all of them.
    imdb_id = None
    try:
        from . import debrid, iptv_lists, newznab, spotnet
        from .meganexus.paths import profile_path
        from .settings_snapshot import setting
        iptv_on = setting('meganexus_iptv_configured') == 'true'
        indexers_on = newznab.active()   # 7.0.45: the user's own Newznab indexers
        spots_on = spotnet.active()      # 7.0.45: the Spotnet index built on this box
        if debrid.active() or indexers_on or spots_on or (iptv_on and iptv_lists.vod_lists(profile_path())):
            imdb_id = video_id if str(video_id).startswith('tt') else (imdb_video_id(media_type, video_id) or video_id)
            server_jobs.extend(debrid.jobs(media_type, imdb_id))
            if indexers_on:
                server_jobs.extend(newznab.jobs(media_type, imdb_id))
            if spots_on:
                server_jobs.extend(spotnet.jobs(media_type, imdb_id))
            server_jobs.extend(iptv_lists.jobs(profile_path(), media_type, imdb_id, iptv_on))
    except Exception:
        pass
    if not sources and not server_jobs:
        raise ValueError('Enable a compatible stream add-on in Settings > Add-ons > Stream add-ons.')

    from . import late_streams
    over = []                            # set when the search below stops waiting

    def fetch(source):
        asked = ids[source['id']]
        if callable(asked):
            asked = asked()
            if not asked:
                return []                # no ID this add-on takes (no TMDb key)
        kept = late_streams.get(source['id'], media_type, asked)
        if kept is not None:
            return kept                  # it answered late last time: its answer, at once
        data = get_json(build_resource_url(source, 'stream', media_type, asked),
                        ttl_seconds=0, timeout_override=max(20, patience or 0), retry=False, rate_wait=0.25)
        rows = (data or {}).get('streams')
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ValueError('Invalid stream response')
        # A provider cannot spoof provenance. Never alter its labels, hints,
        # duplicate streams, headers, or ranking; attach our own trusted origin.
        origin = {key: source.get(key) or '' for key in ('id', 'name', 'base_url')}
        origin['name'] = origin['name'] or (source.get('manifest') or {}).get('name') or source['id']
        rows = [dict(row, _meganexus_source=origin) for row in rows]
        if over and rows:
            late_streams.put(source['id'], media_type, asked, rows)
        return rows

    # Every add-on starts at once. As soon as one returns streams, the others
    # get STREAM_GRACE more seconds; stragglers are skipped (they finish in the
    # background) instead of holding "Loading video" for up to 20 seconds.
    import time
    from concurrent.futures import wait, FIRST_COMPLETED
    results, errors, slow = {}, [], []
    pool = ThreadPoolExecutor(max_workers=min(8, len(sources) + len(server_jobs)), thread_name_prefix='MegaNexusStreams')
    futures = {pool.submit(fetch, source): source for source in sources}
    servers = [{'id': '__server_%d__' % i, 'name': name} for i, (name, _) in enumerate(server_jobs)]
    futures.update({pool.submit(job): server for server, (_, job) in zip(servers, server_jobs)})
    pending = set(futures)
    deadline = time.monotonic() + (patience if complete and patience else STREAM_TIMEOUT)
    grace = None

    def waiting():
        if on_waiting is not None:
            try:
                on_waiting([futures[f].get('name') or futures[f]['id'] for f in pending if futures[f] in sources])
            except Exception:
                pass
    if on_start is not None:
        # 8.1.3: every stream add-on asked, at once - the source list shows them all
        # before any answers, so one that never does is plain to see
        try:
            on_start([(source['id'], source.get('name') or source['id']) for source in sources])
        except Exception:
            pass
    try:
        waiting()
        while pending:
            remaining = (grace or deadline) - time.monotonic()
            if remaining <= 0:
                break
            done, pending = wait(pending, timeout=remaining, return_when=FIRST_COMPLETED)
            for future in done:
                source = futures[future]
                try:
                    found = future.result()
                except Exception:
                    # Do not log configured URLs: they can contain account tokens.
                    errors.append(source.get('name') or source['id'])
                    continue
                results[source['id']] = found
                if found and on_update is not None:
                    try:
                        on_update(_assemble(results, servers, sources, media_type))
                    except Exception:
                        pass
                # 7.0.29: only a stream add-on starts the grace - the built-in TorBox /
                # Premiumize search answers in a moment and cut every add-on off.
                if found and grace is None and not complete and source in sources:
                    grace = min(deadline, time.monotonic() + STREAM_GRACE)
            waiting()
    finally:
        over.append(True)
        pool.shutdown(wait=False)
        if pending and on_waiting is not None:
            try:
                on_waiting([])
            except Exception:
                pass
    slow = [s.get('name') or s['id'] for s in (futures[f] for f in pending)]
    rows = _assemble(results, servers, sources, media_type)
    if not rows and len(errors) + len(slow) == len(sources) + len(servers):
        raise ValueError('Stream add-ons could not respond. Check their configuration and connection.')
    first = sources[0] if sources else {'id': '__servers__', 'name': 'Your servers', 'base_url': ''}
    return dict(first, _meganexus_errors=errors, _meganexus_slow=slow), rows


def _native_usenet(url):
    """8.0: a Usenet film read by the vfs.meganexus add-on (all cores) when this Kodi has it;
    a release that can not play says why here, before the player opens."""
    from . import usenet_native, usenet_nntp
    try:
        return usenet_native.prepare(url) or url
    except (usenet_nntp.NntpError, usenet_nntp.Unsupported) as exc:
        raise ValueError('Usenet: %s' % exc)
    except Exception as exc:
        import xbmc
        xbmc.log('[MegaNexus] Usenet: the native player not used (%s) - as before' % type(exc).__name__, xbmc.LOGWARNING)
        return url


def playback_context(meta, row, source, season='', episode='', video_id='', resume_seconds=0):
    from . import hub as p, title_details
    source = row.get('_meganexus_source') or source
    url = p._row_play_url(row)
    if url and row.get('nzbUrl'):
        url = _native_usenet(url)
    if not url and row.get('nzbUrl'):
        # 7.0.43: an NZB source needs a Usenet server - its own or the user's
        raise ValueError('This Usenet source needs a Usenet server: add yours in HUB Settings > Debrid & Usenet > Usenet > Usenet server, '
                         'or set its add-on to give its servers (Usenet Streamer: native mode with NNTP set up).')
    if not url:
        raise ValueError('This stream add-on result has no Kodi-playable URL. Check its provider/debrid configuration or choose another result.')
    ids = p.extract_ids(meta)
    info = p._info_of(meta)
    try:resume_seconds=max(0.0,float(resume_seconds or 0))
    except (TypeError,ValueError):resume_seconds=0.0
    return {
        'media_type': meta.get('type') or 'movie', 'canonical_id': meta['id'],
        'video_id': video_id or meta['id'], 'season': season, 'episode': episode,
        'title': meta.get('name') or meta.get('title') or meta['id'],
        'show_title': meta.get('name') or meta.get('title') or '',
        'stream_url': url, 'provider_id': source['id'], 'provider_name': source.get('name') or source['id'],
        'provider_base_url': source.get('base_url') or '', 'poster': meta.get('poster') or '',
        'background': meta.get('background') or '', 'clearlogo': meta.get('logo') or '',
        'tmdb_id': ids.get('tmdb_id') or '', 'imdb_id': ids.get('imdb_id') or '', 'tvdb_id': ids.get('tvdb_id') or '',
        'external_ids': ids, 'kodi_info': info, 'plot': info.get('plot') or '',
        'year': info.get('year') or 0, 'resume_seconds': resume_seconds,
        'meganexus_resume_exact': resume_seconds>0,
        'next_episode': title_details.next_episode(meta,video_id) if meta.get('type')=='series' else None,
        'absolute_episode': title_details.absolute(meta,season,episode) if meta.get('type')=='series' else 0,
        'subtitles': row.get('subtitles') or [], 'behaviorHints': row.get('behaviorHints') or {},
        'request_headers': p._row_headers(row),
        'stream_name': row.get('name') or '', 'stream_title': row.get('title') or '',
        # 6.0.39: a Plex / Jellyfin copy reports progress and watched to its server.
        **(_server_keys(row)),
    }


def _server_keys(row):
    if not row.get('_meganexus_server'):
        return {}
    from . import media_servers
    return media_servers.playback_keys(row)


def queue_playback(context):
    from .meganexus import keyed_cache
    from .hub_base import build_url
    key = keyed_cache.put('meganexus_play', context)
    return build_url(action='meganexus_play', key=key)


def play_queued(key):
    from .refresh_guard import release_all
    release_all()   # 7.0.29: the TV's refresh rate is chosen as playback opens
    from .meganexus import keyed_cache
    from . import hub
    context = keyed_cache.get('meganexus_play', key)
    if not isinstance(context, dict) or not context.get('stream_url'):
        raise ValueError('Playback request expired. Choose the title again.')
    import xbmcgui
    from . import debrid
    if str(context['stream_url']).startswith(debrid.SCHEME):
        # 7.0.12: TorBox / Premiumize give the link only now (the row holds the torrent).
        import xbmc
        try:
            context['stream_url'] = debrid.resolve(context['stream_url'], monitor=xbmc.Monitor())
        except Exception as exc:
            if not context.get('meganexus_quiet'):   # 8.1.3: the next source is tried without a word
                xbmcgui.Dialog().notification('Debrid', str(exc)[:120], time=6000)
            xbmc.log('[MegaNexus] Playback: the link could not be resolved (%s)' % str(exc)[:120], xbmc.LOGINFO)
            xbmcgui.Window(10000).setProperty('meganexus.playback.error', context.get('meganexus_request_id') or '')
            raise
    from . import iptv_lists
    if str(context['stream_url']).startswith(iptv_lists.SCHEME):
        # 7.0.37: an IPTV VOD row holds a token; the link is read from the list's index now.
        from .meganexus.paths import profile_path
        try:
            context['stream_url'] = iptv_lists.resolve(profile_path(), context['stream_url'])
        except Exception as exc:
            import xbmc
            if not context.get('meganexus_quiet'):   # 8.1.3: the next source is tried without a word
                xbmcgui.Dialog().notification(iptv_lists.SOURCE_NAME, str(exc)[:120], time=6000)
            xbmc.log('[MegaNexus] Playback: the link could not be resolved (%s)' % str(exc)[:120], xbmc.LOGINFO)
            xbmcgui.Window(10000).setProperty('meganexus.playback.error', context.get('meganexus_request_id') or '')
            raise
    # 8.1.5: a server that cannot be reached at all is never handed to Kodi - it tried for
    # seconds and put "Playback failed" up over the loading screen; the next source goes
    # at once instead (play_jobs is told as for any link that does not start)
    from .link_check import unreachable
    why = unreachable(context['stream_url'])
    if why:
        import xbmc
        from urllib.parse import urlsplit
        host = urlsplit(str(context['stream_url']).split('|', 1)[0]).netloc
        xbmc.log('[MegaNexus] Playback: the server of this source does not answer - %s %s' % (host, why), xbmc.LOGINFO)
        xbmcgui.Window(10000).setProperty('meganexus.playback.error', context.get('meganexus_request_id') or '')
        if not context.get('meganexus_quiet'):
            xbmcgui.Dialog().notification('Playback', 'The server of this source does not answer.', time=4000)
        return False
    xbmcgui.Window(10000).setProperty('meganexus.subtitle.context',key)
    return hub._start_playback(context, use_resolved_url=False)


def catalog_entries(bucket=''):
    from .metadata_providers import catalog_sources
    desired = {'movies': 'movie', 'series': 'series'}.get(bucket)
    result = []
    for source in catalog_sources():      # 9.0.6: also an add-on of catalogs only
        for catalog in (source.get('manifest') or {}).get('catalogs') or []:
            mt = catalog.get('type')
            if mt not in ('movie', 'series') or (desired and mt != desired):
                continue
            if bucket == 'anime' and 'anime' not in (str(catalog.get('id', '')) + str(catalog.get('name', ''))).lower():
                continue
            result.append((source, catalog, 'movies' if mt == 'movie' else 'series'))
    return result
