# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.0.4: shown by itself as a film or an episode starts in Kodi's player (Playback setting).

Top left the mode the display is in - Dolby Vision, HDR or SDR, as a badge of the chosen
badge set - and below it the age rating and IMDb's parents guide: sex & nudity, violence,
language, alcohol & drugs, frightening scenes, each with the severity most voters gave
(the way Nuvio reads it). Home properties for the skin's VideoFullScreen.xml.
"""
import json
import re
import threading
from urllib.request import Request, urlopen

import xbmc
import xbmcgui

GUIDE = 'https://api.tiffara.com/titles/%s/parentsGuide'
CERTIFICATES = 'https://api.tiffara.com/titles/%s/certificates'
TIMEOUT = 4
PREFIX = 'meganexus.pinfo.'
ROWS = 5
SHOW_FOR = 6.0                      # seconds it stays (5-7 asked)
SETTLED = 1.5                       # seconds of calm picture first (resumed, the display's mode switched)
WAIT_FOR = 30.0                     # a picture not playing on its own by then is not waited for
SETTING = 'meganexus_start_info'
HDMI_STATUS = '/sys/class/amhdmitx/amhdmitx0/hdmi_hdr_status'   # Amlogic (CoreELEC): what the HDMI sends
CATEGORIES = (('SEXUAL_CONTENT', 'Sex & nudity'), ('VIOLENCE', 'Violence'), ('PROFANITY', 'Language'),
              ('ALCOHOL_DRUGS', 'Alcohol & drugs'), ('FRIGHTENING_INTENSE_SCENES', 'Frightening scenes'))
_CACHE = {}                         # imdb id -> (rating, rows) for this run
CACHE_KEEP = 200                    # titles kept - the service runs for weeks
_RUN = [None]                       # the one thread that keeps the properties now


def imdb_of(ctx):
    value = str(ctx.get('imdb_id') or ctx.get('canonical_id') or '').split(':')[0]
    return value if re.fullmatch(r'tt\d+', value) else ''


def _get(url):
    try:
        from .skip_backups import _agent
        with urlopen(Request(url, headers={'Accept': 'application/json', 'User-Agent': _agent()}), timeout=TIMEOUT) as reply:
            return json.loads(reply.read(2 * 1024 * 1024).decode('utf-8'))
    except Exception:
        return None


def severity(category):
    """The level most voters gave, unless more said "none" - then nothing to warn about."""
    votes = {}
    for row in (category or {}).get('severityBreakdowns') or []:
        try:votes[str(row.get('severityLevel') or '').strip().lower()] = int(row.get('voteCount') or 0)
        except (TypeError, ValueError, AttributeError):continue
    none = votes.pop('none', 0)
    votes = {k: v for k, v in votes.items() if k}
    if not votes:return ''
    level, count = max(votes.items(), key=lambda item: item[1])
    return level.capitalize() if count > none else ''


def guide_rows(payload):
    found = {str(c.get('category') or '').upper(): c for c in (payload or {}).get('parentsGuide') or [] if isinstance(c, dict)}
    return [(label, severity(found[key])) for key, label in CATEGORIES if key in found and severity(found[key])]


def certificate(payload, country='US'):
    for row in (payload or {}).get('certificates') or []:
        try:
            if row['country']['code'] == country and row.get('rating'):return str(row['rating'])
        except (KeyError, TypeError):continue
    return ''


def rating_text(mpaa):
    """Kodi's MPAA field as people say it: 'Rated R' / 'US:R' -> 'R'."""
    text = str(mpaa or '').strip()
    text = re.sub(r'^(?:rated\s+|[a-z]{2}\s*:\s*)', '', text, flags=re.I).strip()
    return text[:12]


def display_mode(hdmi_status=None, hdr_type='', supported=''):
    """'Dolby Vision', 'HDR' or 'SDR': what the display gets now. Amlogic says it outright;
    elsewhere Kodi sends the film's own kind when the display takes it (its HDR types)."""
    status = str(hdmi_status or '').lower()
    if status:
        if 'dolby' in status:return 'Dolby Vision'
        return 'HDR' if 'hdr' in status or 'hlg' in status else 'SDR'
    hdr, supported = str(hdr_type or '').lower(), str(supported or '').lower()
    if not hdr or not supported:return 'SDR'
    if hdr == 'dolbyvision':return 'Dolby Vision' if 'dolby vision' in supported else 'HDR'   # else its HDR10 base
    return 'HDR'


def _hdmi_status(path=HDMI_STATUS):
    try:
        with open(path) as handle:return handle.read(200).strip()
    except OSError:return None


def mode_badge(mode):
    """The chosen badge set's picture for the mode, else '' (the skin writes the name)."""
    try:
        from . import quality_badges
        found = [b for b in quality_badges.match(mode) if b.get('group') == 'video-tech']
    except Exception:
        found = []
    return (found[0].get('kodi_image') or found[0].get('image') or '') if found else ''


def clear(home=None):
    home = home or xbmcgui.Window(10000)
    for key in ['show', 'mode', 'modeimg', 'rating', 'plot'] + ['g%d' % i for i in range(ROWS)] + ['g%ds' % i for i in range(ROWS)]:
        home.clearProperty(PREFIX + key)


def show_guide(home, rating, rows):
    home.setProperty(PREFIX + 'rating', rating)
    for i in range(ROWS):
        label, level = rows[i] if i < len(rows) else ('', '')
        home.setProperty(PREFIX + 'g%d' % i, label)
        home.setProperty(PREFIX + 'g%ds' % i, level)


def guide(imdb, mpaa):
    if imdb in _CACHE:return _CACHE[imdb]
    rating = rating_text(mpaa) or certificate(_get(CERTIFICATES % imdb))
    payload = _get(GUIDE % imdb)
    result = (rating, guide_rows(payload))
    if payload is not None:
        if len(_CACHE) >= CACHE_KEEP:_CACHE.pop(next(iter(_CACHE)))   # the oldest goes
        _CACHE[imdb] = result
    return result


def _calm(player):
    """The picture plays on its own: the resume's jump is over and nothing of the player is over it."""
    try:return (not getattr(player, '_resume_in_progress', False)
                and xbmc.getCondVisibility('Player.Playing + !Player.Caching + Player.HasVideo + !Window.IsVisible(seekbar) + !Window.IsVisible(videoosd)'))
    except Exception:return False


def described(request):
    """The plot of the playing title from what MegaNexus opened it with - Kodi's own item
    carries none (the minimal item); an episode its own overview, else the show's."""
    meta = (request or {}).get('meta') or {}
    parts = str(((request or {}).get('context') or {}).get('video_id') or '').split(':')
    episode = {}
    if len(parts) >= 3 and parts[-1].isdigit() and parts[-2].isdigit():
        episode = next((v for v in meta.get('videos') or [] if isinstance(v, dict) and str(v.get('season')) == parts[-2]
                        and str(v.get('episode') or v.get('number')) == parts[-1]), {})
    return str(episode.get('overview') or episode.get('description') or meta.get('description') or '').strip()


def _start_box(player, uid, ctx, owns, mine, home, monitor):
    """Once the picture plays on its own: the display's mode, the age rating and the guide for SHOW_FOR seconds."""
    imdb = imdb_of(ctx)
    mpaa = xbmc.getInfoLabel('VideoPlayer.mpaa')
    rating, rows = guide(imdb, mpaa) if imdb else (rating_text(mpaa), [])
    waited, calm = 0.0, 0.0
    while calm < SETTLED:
        if not (mine() and owns(player, uid)) or waited >= WAIT_FOR or monitor.waitForAbort(.25):return
        waited += .25
        calm = calm + .25 if _calm(player) else 0.0
    if not (mine() and owns(player, uid)):return
    mode = display_mode(_hdmi_status(), xbmc.getInfoLabel('VideoPlayer.HdrType'), xbmc.getInfoLabel('System.SupportedHDRTypes'))
    home.setProperty(PREFIX + 'mode', mode)
    home.setProperty(PREFIX + 'modeimg', mode_badge(mode))
    show_guide(home, rating, rows)
    home.setProperty(PREFIX + 'show', '1')
    shown = 0.0
    while shown < SHOW_FOR and mine() and owns(player, uid) and not monitor.waitForAbort(.25):
        shown += .25
    if mine():home.clearProperty(PREFIX + 'show')


def publish(player, uid, ctx, owns, mine=lambda: True, enabled=lambda: True):
    """For the playback ``uid`` (a thread): Info's plot at once, the start box when the
    setting is on."""
    home = xbmcgui.Window(10000)
    clear(home)
    try:request = json.loads(home.getProperty('meganexus.playing.request') or '{}')
    except ValueError:request = {}
    home.setProperty(PREFIX + 'plot', described(request))
    if enabled():_start_box(player, uid, ctx, owns, mine, home, xbmc.Monitor())
    # the thread ends here: the film's end clears the rest (playback_watch._forget_playing), so
    # nothing asks Kodi's player every second for a whole film


def start(player, uid, ctx):
    from .skip_service import owns_playback

    token = _RUN[0] = object()      # AV start again (another stream) - the older thread stops

    def enabled():
        from .settings_snapshot import cached_addon
        return cached_addon().getSetting(SETTING) != 'false'

    def run():
        try:publish(player, uid, dict(ctx or {}), owns_playback, lambda: _RUN[0] is token, enabled)
        except Exception as exc:xbmc.log('[MegaNexus] player info skipped: %r' % exc, xbmc.LOGDEBUG)
    threading.Thread(target=run, name='MegaNexusPlayerInfo', daemon=True).start()
