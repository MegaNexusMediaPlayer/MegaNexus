# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""When a sports event starts, in Kodi's own time (9.0.4).

Sports add-ons give the start in their releaseInfo, most of them in UTC ("30 Oct 2026 ·
19:00 UTC", "2026-10-30T19:00:00Z"). Only a time that names its zone (UTC, GMT, Z, +01:00,
UTC+1) is turned into the box's local time; one without a zone is the add-on's own (a paid
add-on that already gives the right local time) and is shown as it is.
"""
import re
from datetime import datetime, timedelta, timezone

MONTHS = {m: i for i, m in enumerate(('jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'), 1)}
_TIME = re.compile(r'(?<![\d:.])([01]?\d|2[0-3]):([0-5]\d)(?::\d{2})?\s*(am|pm)?(?![\d:])', re.I)
_ZONE = re.compile(r'(?:(?<![A-Za-z])(UTC|GMT)\s*([+-]\s*\d{1,2}(?::?\d{2})?)?(?![A-Za-z]))|(?<=\d)(Z)\b|(?<=\d)\s*([+-]\d{2}:?\d{2})\b', re.I)
_ISO_DATE = re.compile(r'(\d{4})-(\d{2})-(\d{2})')
_DOTTED = re.compile(r'(?<!\d)(\d{1,2})\.(\d{1,2})\.(\d{4})')     # 31.10.2026 - day first
_DAY_MONTH = re.compile(r'(\d{1,2})\s+([A-Za-z]{3})[a-z]*\.?,?\s*(\d{4})?')
_MONTH_DAY = re.compile(r'([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s*(\d{4})?')


def _offset(match):
    """The zone's offset from UTC, or None when the text names none."""
    if not match:
        return None
    if match.group(1):                                  # UTC / GMT, maybe +1, +01:00
        extra = (match.group(2) or '').replace(' ', '')
    else:
        extra = match.group(4) or ''                    # Z or a bare +01:00
    if not extra:
        return timedelta(0)
    sign = -1 if extra[0] == '-' else 1
    digits = extra[1:].replace(':', '')
    hours, minutes = (int(digits), 0) if len(digits) <= 2 else (int(digits[:-2]), int(digits[-2:]))
    return sign * timedelta(hours=hours, minutes=minutes)


def _date(text, today):
    found = _ISO_DATE.search(text)
    if found:
        return int(found.group(1)), int(found.group(2)), int(found.group(3))
    found = _DOTTED.search(text)
    if found:
        return int(found.group(3)), int(found.group(2)), int(found.group(1))
    for pattern, day_first in ((_DAY_MONTH, True), (_MONTH_DAY, False)):
        for found in pattern.finditer(text):
            day, month, year = (found.group(1), found.group(2), found.group(3)) if day_first else (found.group(2), found.group(1), found.group(3))
            number = MONTHS.get(month[:3].lower())
            if number:
                return int(year or today.year), number, int(day)
    return None


def start(info, today=None):
    """The start as an aware UTC datetime, or None (no time, or no zone named)."""
    text = str(info or '')
    clock = _TIME.search(text)
    zone = _offset(_ZONE.search(text))
    if not clock or zone is None:
        return None
    hour, minute = int(clock.group(1)), int(clock.group(2))
    meridiem = (clock.group(3) or '').lower()
    if meridiem == 'pm' and hour < 12:
        hour += 12
    elif meridiem == 'am' and hour == 12:
        hour = 0
    today = today or datetime.now(timezone.utc).date()
    day = _date(text, today) or (today.year, today.month, today.day)
    try:
        return datetime(day[0], day[1], day[2], hour, minute, tzinfo=timezone(zone)).astimezone(timezone.utc)
    except ValueError:
        return None


def local_text(moment, now=None, clock_format='%H:%M'):
    """'Today · 20:00', 'Tomorrow · 01:00' or 'Sat 31 Oct · 16:00' in the box's own time."""
    local = moment.astimezone()
    now = (now or datetime.now(timezone.utc)).astimezone()
    days = (local.date() - now.date()).days
    clock = local.strftime(clock_format).lstrip('0') if '%I' in clock_format else local.strftime(clock_format)
    if days == 0:
        return 'Today · ' + clock
    if days == 1:
        return 'Tomorrow · ' + clock
    if days == -1:
        return 'Yesterday · ' + clock
    return '%s · %s' % (local.strftime('%a %d %b').replace(' 0', ' '), clock)


def kickoff(info, live=False, now=None, clock_format=None):
    """The line under the event's name: 'Live now', the start in Kodi's time, or the
    add-on's own words when they name no zone."""
    if live:
        return 'Live now'
    moment = start(info)
    if moment is None:
        return str(info or '').strip()
    if clock_format is None:
        clock_format = _kodi_clock()
    return local_text(moment, now=now, clock_format=clock_format)


def _kodi_clock():
    """Kodi's own clock format (Settings > Regional), without the seconds."""
    try:
        import xbmc
        fmt = xbmc.getRegion('time') or '%H:%M:%S'
    except Exception:
        fmt = '%H:%M:%S'
    return fmt.replace(':%S', '').replace('%S', '').strip() or '%H:%M'
