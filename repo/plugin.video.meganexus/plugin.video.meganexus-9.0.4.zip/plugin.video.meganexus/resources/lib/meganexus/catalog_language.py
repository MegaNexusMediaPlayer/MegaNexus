# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.0.4: a MegaNexus Catalog row that the chosen language / region leaves empty comes in English.

The catalog filters some rows by the chosen region (Prime Video Movies / Series answer nothing
for Croatia, but twenty titles for the US). A row goes over to the English catalog only when it
is proven: the chosen catalog answered (valid JSON) with no titles, asked once more straight away
it still had none, and the English one has titles. A timeout or a network error proves nothing -
the row stays as it is. The answer is kept for a week (catalog_language.json), then proven again."""
import os
import threading
import time

from .json_files import read_json, write_json
from .paths import profile_path

KEEP_FOR = 7 * 86400
FILE = 'catalog_language.json'
_LOCK = threading.Lock()


def _builtin():
    from .. import default_setup
    return default_setup


def _path():
    return os.path.join(profile_path(), FILE)


def _key(provider, media_type, catalog_id):
    return '%s|%s|%s' % (str((provider or {}).get('manifest_url') or ''), media_type, catalog_id)


def _known():
    data = read_json(_path(), {})
    return data if isinstance(data, dict) else {}


def chosen_elsewhere(provider):
    """The MegaNexus Catalog in another language or region than English / United States."""
    setup = _builtin()
    manifest = (provider or {}).get('manifest') or {}
    url = str((provider or {}).get('manifest_url') or '')
    return manifest.get('id') == setup.CATALOG_ID and url.startswith(setup.CATALOG_HOST + '/') \
        and url.split('?', 1)[0] != setup.CATALOG_URL


def english(provider):
    """The same add-on row, pointed at the English catalog."""
    out = dict(provider or {})
    out['manifest_url'] = _builtin().CATALOG_URL
    out['base_url'] = _builtin().CATALOG_HOST
    return out


def goes_english(provider, media_type, catalog_id, now=None):
    if not chosen_elsewhere(provider):
        return False
    with _LOCK:
        at = _known().get(_key(provider, media_type, catalog_id))
    return bool(at) and (now or time.time()) - float(at) < KEEP_FOR


def _empty(answer):
    return isinstance(answer, dict) and isinstance(answer.get('metas'), list) and not answer['metas']


def _first_page(extra):
    extra = extra or {}
    return not any(extra.get(name) not in (None, '', 0, '0') for name in ('skip', 'search', 'genre'))


def proven(provider, media_type, catalog_id, extra, answer, ask_again, ask_english):
    """The English answer when the row is proven empty only through the language (else None).
    ``ask_again()`` / ``ask_english()`` fetch the chosen catalog anew and the English one;
    any error they raise means nothing is proven."""
    if not (chosen_elsewhere(provider) and _first_page(extra) and _empty(answer)):
        return None
    try:
        if not _empty(ask_again()):
            return None
        theirs = ask_english()
    except Exception:
        return None
    if not (isinstance(theirs, dict) and isinstance(theirs.get('metas'), list) and theirs['metas']):
        return None
    with _LOCK:
        data = _known()
        data = dict((key, at) for key, at in data.items() if time.time() - float(at or 0) < KEEP_FOR)
        data[_key(provider, media_type, catalog_id)] = time.time()
        try:
            write_json(_path(), data)
        except Exception:
            pass
    return theirs
