# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Talking to Stremio add-ons: their manifest, catalogs, details, streams and subtitles.

Resource addresses are built as Stremio builds them - from the configured manifest
address, its path and query kept (some add-ons carry their configuration there).
Answers come from `net.responses` while they are fresh, or stale-but-recent while a
background refresh runs; streams are kept in memory only and skip add-ons `net.health`
has rested. The network layer is in meganexus/net."""
from urllib.parse import quote, urlparse, urlunparse

from . import catalog_language
from .paths import addon
from .net import resting as health, lanes, options, responses, transport
from .net.lanes import JobRace, each_parallel, all_at_once, begin_race  # noqa: F401
from .net.options import (  # noqa: F401
    catalog_ttl, fast_timeout, gzip_enabled, meta_ttl, parallel_workers, stream_ttl, timeout_seconds,
)

HTTP_CACHE_DIR = responses.FOLDER
MANIFEST_LIFE = 300
SUBTITLES_LIFE = 300
STREAM_RATE_WAIT = 0.25
MANIFEST_NEEDS = ('id', 'version', 'resources', 'types')
_ensure_pool = transport.pool                       # art_cache shares the kept connections
provider_health_pause = health.pause
purge_meta_cache = responses.forget_details
clear_http_cache = responses.clear


def _headers():
    version = addon().getAddonInfo('version') or '8.1.0'
    headers = {'Accept': 'application/json', 'User-Agent': 'MegaNexus/%s (Kodi)' % version}
    if options.gzip_enabled():
        headers['Accept-Encoding'] = 'gzip'
    return headers


def get_json(url, ttl_seconds=0, timeout_override=None, memory_only=False, retry=True, rate_wait=2.0):
    """An add-on's JSON answer. `ttl_seconds` > 0 keeps it (disk too unless memory_only); a
    kept answer up to twice that old is returned at once and refreshed in the background."""
    found = responses.fresh(url, ttl_seconds, memory_only=memory_only)
    if found is not None:
        return found
    headers = _headers()
    timeout = options.timeout_seconds() if timeout_override in (None, '') else max(1, int(float(timeout_override)))
    if ttl_seconds > 0 and not memory_only:
        old, _ = responses.stale(url, ttl_seconds * 2)
        if old is not None:
            responses.refresher.later(url, lambda: _fetch_again(url, headers, timeout))
            responses.memory.put(url, old)
            return old
    text = transport.get_text(url, headers, timeout, retry=retry, rate_wait=rate_wait)
    data = transport.read_json(text)
    if ttl_seconds > 0:
        responses.keep(url, data, memory_only=memory_only, size=len(text))
    return data


def _fetch_again(url, headers, timeout):
    from urllib.request import Request
    with transport.open_with_retry(Request(url, headers=headers), timeout=timeout) as response:
        return transport.read_json(transport.unpack(response))


def manifest_ok(manifest_url):
    """The add-on's manifest when it is one (id, version and non-empty resources / types)."""
    data = get_json(manifest_url, ttl_seconds=MANIFEST_LIFE)
    if not isinstance(data, dict):
        raise ValueError('Invalid manifest: not a JSON object')
    missing = [key for key in MANIFEST_NEEDS if key not in data]
    if missing:
        raise ValueError('Invalid manifest: missing %s' % ', '.join(missing))
    for key in ('resources', 'types'):
        if not isinstance(data.get(key), list) or not data[key]:
            raise ValueError('Invalid manifest: %s must be a non-empty list' % key)
    return data


def _base(provider):
    """(the add-on's base address, the manifest's query) as the user configured it."""
    manifest_url = str((provider or {}).get('manifest_url') or '').strip()
    if manifest_url and '/manifest.json' in manifest_url:
        try:
            parts = urlparse(manifest_url)
            path = parts.path.rsplit('/manifest.json', 1)[0]
            return urlunparse((parts.scheme, parts.netloc, path, '', '', '')).rstrip('/'), parts.query or ''
        except Exception:
            return manifest_url.rsplit('/manifest.json', 1)[0].rstrip('/'), ''
    return str(provider.get('base_url') or '').rstrip('/'), ''


def build_resource_url(provider, resource, media_type, item_id, extra=None):
    """<base>/<resource>/<type>/<id>[/<extra>].json[?<manifest query>] - episode ids keep their
    colons for streams and catalogs (tt1:1:2), as stream proxies expect."""
    base, query = _base(provider)
    url = '%s/%s/%s/%s' % (base, resource, media_type,
                           quote(str(item_id), safe=':' if resource in ('stream', 'catalog') else ''))
    pairs = ['%s=%s' % (quote(str(key), safe=''), quote(str(value), safe=''))
             for key, value in (extra or {}).items() if value is not None and value != '']
    if pairs:
        url += '/' + '&'.join(pairs)
    return url + '.json' + ('?' + query if query else '')


def fetch_catalog(provider, media_type, catalog_id, extra=None, timeout_override=None, retry=True, rate_wait=2.0):
    """A catalog page; a MegaNexus Catalog row the chosen language leaves empty comes in English
    (catalog_language: only once that is proven)."""
    if catalog_language.goes_english(provider, media_type, catalog_id):
        provider = catalog_language.english(provider)

    def ask(where):
        return get_json(build_resource_url(where, 'catalog', media_type, catalog_id, extra=extra or {}),
                        ttl_seconds=options.catalog_ttl(), timeout_override=timeout_override, retry=retry,
                        rate_wait=rate_wait)

    def ask_again():
        url = build_resource_url(provider, 'catalog', media_type, catalog_id, extra=extra or {})
        timeout = options.timeout_seconds() if timeout_override in (None, '') else max(1, int(float(timeout_override)))
        return transport.read_json(transport.get_text(url, _headers(), timeout, retry=False))

    answer = ask(provider)
    theirs = catalog_language.proven(provider, media_type, catalog_id, extra, answer, ask_again,
                                     lambda: ask(catalog_language.english(provider)))
    return answer if theirs is None else theirs


def fetch_meta(provider, media_type, item_id, timeout_override=None, retry=True, rate_wait=2.0):
    return get_json(build_resource_url(provider, 'meta', media_type, item_id), ttl_seconds=options.meta_ttl(),
                    timeout_override=timeout_override, retry=retry, rate_wait=rate_wait)


def fetch_streams(provider, media_type, video_id, timeout_override=None):
    """An add-on's streams (memory only, one try); an add-on resting after failures answers
    nothing at once, and every failure counts toward its rest."""
    addon_id = (provider or {}).get('id') or (provider or {}).get('base_url') or ''
    if addon_id and health.resting(addon_id):
        return {'streams': []}
    try:
        answer = get_json(build_resource_url(provider, 'stream', media_type, video_id),
                          ttl_seconds=options.stream_ttl(), timeout_override=timeout_override, memory_only=True,
                          retry=False, rate_wait=STREAM_RATE_WAIT)
    except Exception:
        if addon_id:
            health.failed(addon_id)
        raise
    if addon_id:
        health.answered(addon_id)
    return answer


def fetch_subtitles(provider, media_type, item_id, timeout_seconds=None, extra=None):
    """8.1.5: ``extra`` - videoHash / videoSize of the playing file, as Stremio sends them."""
    return get_json(build_resource_url(provider, 'subtitles', media_type, item_id, extra=extra), ttl_seconds=SUBTITLES_LIFE,
                    timeout_override=timeout_seconds, retry=False, rate_wait=STREAM_RATE_WAIT)


def offers(provider, resource_name, media_type=None, item_id=None):
    """The add-on's manifest offers this resource (for this type and id prefix when it says)."""
    for resource in (provider.get('manifest') or {}).get('resources', []):
        if resource == resource_name:
            return True
        if not isinstance(resource, dict) or resource.get('name') != resource_name:
            continue
        types = resource.get('types') or []
        if media_type and types and media_type not in types:
            continue
        prefixes = resource.get('idPrefixes') or []
        if item_id and prefixes and not any(str(item_id).lower().startswith(str(p).lower()) for p in prefixes):
            continue
        return True
    return False


def stop_background():
    """The background refresh and every lane pool end with the script (Kodi waits for
    every thread of a finished script); queued work is cancelled, the next call makes them again."""
    responses.refresher.stop()
    lanes.stop()
