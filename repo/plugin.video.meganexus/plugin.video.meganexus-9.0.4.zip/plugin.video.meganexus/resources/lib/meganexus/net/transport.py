# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""One GET to an add-on: kept-alive connections, the per-host limiter, one retry.

urllib3's pool keeps a TLS connection per host (a new handshake costs 150-300 ms);
it is built on the first request, never on import (the import alone cost up to
200 ms on ARM boxes). Without urllib3 the standard library does the same work, only
without keep-alive. A request is tried twice when the network or the server (5xx)
failed, never for a 4xx; a 429 slows its host down."""
import gzip
import io
import json
import socket
import threading
import time
from urllib.error import HTTPError, URLError

RETRY_PAUSE = 0.25


def closing():
    """8.1.5: Kodi is closing - no second try: Kodi waits for every thread of a script
    and kills the script after 5 s; a retry after a timeout was the second wait."""
    try:
        import xbmc
        return xbmc.Monitor().abortRequested()
    except Exception:
        return False
POOL_HOSTS, POOL_PER_HOST = 20, 4
CONNECT_MAX = 10
_pool = {'manager': None, 'tried': False, 'urllib3': None}
_pool_lock = threading.Lock()

try:   # a faster JSON reader when the system has one; the standard one otherwise
    import orjson as _orjson  # type: ignore[import-not-found]

    def read_json(raw):
        if isinstance(raw, bytes):
            return _orjson.loads(raw.lstrip(b'\xef\xbb\xbf').strip())
        return _orjson.loads(raw.lstrip('﻿').strip().encode('utf-8'))
except Exception:
    def read_json(raw):
        try:
            return json.loads(raw)
        except Exception:   # a byte order mark or trailing space, once
            text = raw.decode('utf-8', 'replace') if isinstance(raw, bytes) else raw
            return json.loads(text.strip().lstrip('﻿'))


def pool():
    """urllib3's PoolManager, made once (None when urllib3 is missing)."""
    if _pool['tried']:
        return _pool['manager']
    with _pool_lock:
        if not _pool['tried']:
            try:
                import urllib3
                try:
                    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
                except Exception:
                    pass
                _pool['manager'] = urllib3.PoolManager(num_pools=POOL_HOSTS, maxsize=POOL_PER_HOST, retries=False,
                                                       timeout=urllib3.Timeout(connect=10, read=30))
                _pool['urllib3'] = urllib3
            except Exception:
                _pool['manager'] = None
            _pool['tried'] = True
    return _pool['manager']


# ---------------------------------------------------------------------------------
# how often one host is asked
# ---------------------------------------------------------------------------------
# (burst, tokens per second): a screen may ask a host several times at once, then has
# to keep to its rate. The services every MegaNexus screen leans on are allowed more
# than a stranger; a 429 replaces a host's allowance with a slower one (slow_down).
DEFAULT_PACE = (10, 5.0)
HOST_PACE = dict((host, (burst, rate)) for host, burst, rate in (
    ('api.themoviedb.org', 40, 30.0), ('api.trakt.tv', 12, 4.0), ('catalog.nuvio.tv', 20, 10.0),
    ('webservice.fanart.tv', 8, 3.0), ('discover.provider.plex.tv', 6, 2.0)))
_LONGEST_NAP = 0.25     # never hold a thread longer than this in one go
_BUCKETS = {}
_PACE_LOCK = threading.Lock()


def _note(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] ' + text, xbmc.LOGWARNING)
    except Exception:
        pass


def host_of(url):
    try:
        from urllib.parse import urlparse
        return (urlparse(url).hostname or '').lower()
    except Exception:
        return ''


def _bucket(host):
    """[tokens, when they were counted, burst, per second] for one host, made on demand."""
    with _PACE_LOCK:
        held = _BUCKETS.get(host)
        if held is None:
            burst, rate = HOST_PACE.get(host) or DEFAULT_PACE
            held = _BUCKETS[host] = [float(burst), time.monotonic(), float(burst), float(rate)]
        return held


def wait_turn(url, max_wait=2.0):
    """One turn at a host, waiting up to max_wait for it. False = it was not worth waiting.

    Only the network layer calls this. A GUI callback must not: it can sleep.
    """
    host = host_of(url)
    if not host:
        return True
    bucket = _bucket(host)
    give_up_at = time.monotonic() + max_wait
    while True:
        with _PACE_LOCK:
            tokens, counted, burst, rate = bucket
            now = time.monotonic()
            if now > counted:
                tokens = min(burst, tokens + (now - counted) * rate)
                bucket[0], bucket[1] = tokens, now
            if tokens >= 1.0:
                bucket[0] = tokens - 1.0
                return True
            due_in = (1.0 - tokens) / rate
        if time.monotonic() + due_in > give_up_at:
            _note('gave up waiting for a turn at %s' % host)
            return False
        time.sleep(min(due_in, _LONGEST_NAP))


def slow_down(url, capacity=4, rate=1.0):
    """What a 429 means: this host gets a slower allowance, now and for the rest of the run."""
    host = host_of(url)
    if not host:
        return
    with _PACE_LOCK:
        HOST_PACE[host] = (capacity, float(rate))
        _BUCKETS[host] = [float(capacity), time.monotonic(), float(capacity), float(rate)]


def unpack(response):
    """A urllib response's body as text (gunzipped when the server sent gzip)."""
    body = response.read()
    if 'gzip' in (response.headers.get('Content-Encoding') or '').lower():
        try:
            body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
        except Exception:
            pass
    return body.decode('utf-8', 'replace')


def open_with_retry(request, timeout, retry=True, rate_wait=2.0):
    """urllib's urlopen, a second try after network trouble or a 5xx."""
    address = request.full_url if hasattr(request, 'full_url') else request.get_full_url()
    wait_turn(address, max_wait=max(0.0, float(rate_wait or 0.0)))
    from urllib.request import urlopen
    failure = None
    for attempt in ((0, 1) if retry else (0,)):
        try:
            return urlopen(request, timeout=timeout)
        except HTTPError as exc:
            failure = exc
            if exc.code == 429:
                slow_down(address, 4, 1.0)
            if exc.code < 500:
                raise
        except (URLError, socket.timeout) as exc:
            failure = exc
        if retry and attempt == 0:
            if closing():
                break
            time.sleep(RETRY_PAUSE)
    raise failure


def get_text(url, headers, timeout, retry=True, rate_wait=2.0):
    """The body of one GET as text."""
    manager = pool()
    if manager is None:
        from urllib.request import Request
        with open_with_retry(Request(url, headers=headers), timeout=timeout, retry=retry,
                             rate_wait=rate_wait) as response:
            return unpack(response)
    wait_turn(url, max_wait=max(0.0, float(rate_wait or 0.0)))
    timing = _pool['urllib3'].Timeout(connect=min(CONNECT_MAX, timeout), read=timeout)
    failure = None
    for attempt in ((0, 1) if retry else (0,)):
        try:
            response = manager.request('GET', url, headers=headers, timeout=timing, redirect=True, retries=False,
                                       decode_content=True, preload_content=True)
            if 500 <= response.status < 600 and retry and attempt == 0 and not closing():
                failure = Exception('upstream %d' % response.status)
                time.sleep(RETRY_PAUSE)
                continue
            if response.status >= 400:
                raise Exception('HTTP %d for %s' % (response.status, url))
            return response.data.decode('utf-8', 'replace')
        except Exception as exc:
            failure = exc
            if retry and attempt == 0 and not closing():
                time.sleep(RETRY_PAUSE)
                continue
            raise
    if failure:
        raise failure
