# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Music app's tracks in Kodi's queue (9.0.6): plugin://plugin.video.meganexus/?action=music_play&q=<key>.

Kodi asks for each as it comes to play it; its address is found just before - the first by the app
while its ring turns by the profile, each next one while the one before plays (ahead()) - so Kodi,
which stands still while it waits for an address, never waits for the search.
The track itself waits in Window(Home) property meganexus.music.q.<key> (the app puts it there);
the address is never written into the queue or the log. A track no source can play is passed:
Kodi goes on to the next one.
"""
import json
import time
from urllib.parse import parse_qs

QUEUED = 'meganexus.music.q.'
MISSED = 'meganexus.music.missed'     # songs in a row no source could play
GIVE_UP = 3                           # ... then the queue stops (it never runs through every song)
PLAYING = 'meganexus.music.playing'   # the song that plays (its id)
STARTED = 'meganexus.music.started'   # 9.0.7: when a song of ours last started (music_watch.Gone counts from it)
KEYS = 'meganexus.music.keys'         # the queue's songs, in order (the app puts them there)
LOADING = 'meganexus.music.loading'   # the app is finding the first song's address (the ring by the profile)
FROM = 'meganexus.music.from'         # where the song plays from, in words (Now playing, the small player)
PICTURE = 'meganexus.music.picture'   # the song's own picture (YouTube's add-on puts its video's still on the item)
QUEUE_MAX = 200
ROUND = 'meganexus.music.round'       # a playlist's songs: at its end it starts again (ahead())
LOOK_AHEAD = 3                        # songs ahead() tries for the next one that can play


def path(key):
    return 'plugin://plugin.video.meganexus/?action=music_play&q=%s' % key


def resolve(handle, query):
    import xbmc
    import xbmcgui
    import xbmcplugin
    from . import music
    key = (parse_qs(query.lstrip('?')).get('q') or [''])[0]
    try:
        track = json.loads(xbmcgui.Window(10000).getProperty(QUEUED + key) or '{}')
        # found while the one before played (ahead()): Kodi does not wait for it - its screen stood still meanwhile
        if track.get('missing'):
            raise music.MusicError(track['missing'])            # known already (ahead()): passed at once
        url, source = (track['ready'], track.get('ready_from', '')) if track.get('ready') else music.playable(track)
    except (ValueError, KeyError, music.MusicError) as exc:
        xbmc.log('[MegaNexus] Music: a track could not play - %s' % music.safe(exc), xbmc.LOGWARNING)
        home = xbmcgui.Window(10000)
        missed = int(home.getProperty(MISSED) or 0) + 1
        home.setProperty(MISSED, str(missed))
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        if missed == 1:
            xbmcgui.Dialog().notification('Music', music.safe(exc) or 'This track cannot play.', time=3500)
        elif missed >= GIVE_UP:
            home.clearProperty(MISSED)
            xbmc.executebuiltin('PlayerControl(Stop)')
            xbmcgui.Dialog().notification('Music', 'Your music sources do not have these songs.', time=4500)
        return
    home = xbmcgui.Window(10000)
    home.clearProperty(MISSED)
    home.setProperty(PLAYING, str(track.get('id') or ''))     # the song's card has the play mark (make_music_home.py)
    home.setProperty(STARTED, repr(time.time()))             # ... and it is a new start, even of the same song
    home.setProperty(FROM, music.origin(source))
    home.setProperty(PICTURE, track.get('picture') or '')
    start = float(track.get('start') or 0)          # where it waits to go on from (a film took the player - resume())
    if url.startswith('plugin://plugin.video.youtube/'):
        steady_song()
    try:
        from . import refresh_guard
        refresh_guard.suspend('music')        # a song is no film: no TV mode switch as it starts (the hold lapses)
    except Exception:
        pass
    if start and url.startswith('plugin://plugin.video.youtube/'):
        url += '&seek=%d' % int(start)              # YouTube's add-on goes there itself once its stream runs
    item = xbmcgui.ListItem(label=track.get('title') or '', path=url)
    if start and not url.startswith('plugin://'):
        item.setProperty('StartOffset', '%.1f' % start)
    if start:
        home.setProperty(QUEUED + key, json.dumps({k: v for k, v in track.items() if k != 'start'}))
    tag = item.getMusicInfoTag()
    tag.setTitle(track.get('title') or '')
    tag.setArtist(track.get('artist') or '')
    tag.setAlbum(track.get('album') or '')
    if track.get('seconds'):
        tag.setDuration(int(track['seconds']))
    item.setArt({'thumb': track.get('picture') or '', 'fanart': track.get('picture') or ''})
    item.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, item)
    # 9.0.7: kept as heard once Kodi has the address - Kodi's screen stands still until then, and the history (as many
    # as 500 songs) was read and written before it
    try:
        music.played(track)                                     # Recently played, your artists, For you
    except OSError:
        pass
    ahead(key)


def steady_song():
    """Songs from YouTube as one whole stream (the add-on's "steady playback", Settings > YouTube), switched on
    for good with the first one - said once: with MPEG-DASH YouTube's add-on 7.4.4 has YouTube refuse the rest
    of the sound after about a minute (its issues #1481, #1483); on the Fire TV Cube the sound fell behind, the
    player sought round and round and the box froze (2026-11-03). Only for good: the add-on keeps its settings
    in a running interpreter, a switch for one song only never reached it."""
    import xbmcgui
    from . import youtube
    if youtube.steady() is False and youtube.steady(True):
        xbmcgui.Dialog().notification('Music', 'YouTube songs play as one whole stream: Steady playback is on '
                                      '(Settings > YouTube)', time=6000)


def queue_item(track):
    """(address, item) for Kodi's music queue: the song waits in Window(Home) by its key and its address
    is found as it comes to play (resolve)."""
    import uuid
    import xbmcgui
    key = uuid.uuid4().hex[:12]
    home = xbmcgui.Window(10000)
    home.setProperty(QUEUED + key, json.dumps(track))
    keys = json.loads(home.getProperty(KEYS) or '[]') + [key]
    home.setProperty(KEYS, json.dumps(keys[-QUEUE_MAX * 2:]))
    item = xbmcgui.ListItem(label=track.get('title') or '', path=path(key))
    tag = item.getMusicInfoTag()
    tag.setTitle(track.get('title') or '')
    tag.setArtist(track.get('artist') or '')
    tag.setAlbum(track.get('album') or '')
    if track.get('seconds'):
        tag.setDuration(int(track['seconds']))
    item.setArt({'thumb': track.get('picture') or ''})
    item.setProperty('IsPlayable', 'true')
    return path(key), item


def go_on_from(address, seconds):
    """The queue's song at ``address`` starts at ``seconds`` when it plays next (a film took the player:
    music_watch kept its place). Its player goes there itself - no seek after it started, which a
    stream still opening misses (the song then began again from the start). False: not one of ours."""
    import xbmcgui
    key = (parse_qs(address.partition('?')[2]).get('q') or [''])[0]
    home = xbmcgui.Window(10000)
    try:
        track = json.loads(home.getProperty(QUEUED + key) or '{}') if key else {}
    except ValueError:
        track = {}
    if not track:
        return False
    track['start'] = max(0.0, float(seconds or 0))
    home.setProperty(QUEUED + key, json.dumps(track))
    return True


def ahead(key):
    """While this song plays: the next one's address, found now (the queue goes on without a wait) - and,
    the queue at its end, more songs like it (the music never stops, as on music services)."""
    import xbmc
    import xbmcgui
    from . import music
    home = xbmcgui.Window(10000)
    try:
        keys = json.loads(home.getProperty(KEYS) or '[]')
        at = keys.index(key)
        # (Repeat and Shuffle are Kodi's own ways round the queue: nothing is added then). At the end: a
        # playlist goes round, anything else goes on with songs like the last one (its artist, one like them)
        if at == len(keys) - 1 and not xbmc.getCondVisibility('Playlist.IsRepeat | Playlist.IsRepeatOne | Playlist.IsRandom'):
            playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
            again = json.loads(home.getProperty(ROUND) or '[]')
            for song in again or music.more_like(json.loads(home.getProperty(QUEUED + key) or '{}')):
                playlist.add(*queue_item({k: v for k, v in song.items() if k not in ('ready', 'ready_from', 'missing')}))
            keys = json.loads(home.getProperty(KEYS) or '[]')
        # the next song ready - one no source has is marked so (Kodi passes it at once: its search again, as it
        # came to play, held the Cube's screen 8 s) and the one after it is made ready instead
        for following in keys[at + 1:at + 1 + LOOK_AHEAD]:
            track = json.loads(home.getProperty(QUEUED + following) or '{}')
            if not track or track.get('ready'):
                break
            if track.get('missing'):
                continue
            try:
                track['ready'], track['ready_from'] = music.playable(track)
            except music.MusicError as exc:
                track['missing'] = music.safe(exc) or 'This track cannot play.'
                home.setProperty(QUEUED + following, json.dumps(track))
                continue
            home.setProperty(QUEUED + following, json.dumps(track))
            break
    except (ValueError, IndexError, KeyError):
        pass                                  # it is asked for as it comes to play, as before
