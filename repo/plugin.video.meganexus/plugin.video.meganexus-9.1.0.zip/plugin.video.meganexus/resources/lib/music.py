# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Music for the HUB's Music app (9.0.6): the person's music sources and the device's own music.

A source is an Eclipse music add-on (eclipsemusic.app/docs) - a server that answers JSON:
manifest.json, /search, /stream/{id} and, when it has them, /album, /artist, /playlist and
/catalog. MegaNexus only asks it questions; nothing of it runs here. The person adds a source by
the address of its manifest; an address may carry a token (https://host/{token}/manifest.json),
so it is kept as a secret and never written to the log (safe()). A source's own settings
(select, toggle, text, number) go with every question as query parameters.

Answers are read leniently (title or name, duration or durationMs, artworkURL, image or cover),
each at most MAX_BYTES, within TIMEOUT, and kept in memory for KEEP seconds. A track's stream is
asked for only when it plays (its address may expire); a stream that needs a key (encrypted) is
not played, and HLS / DASH streams are not played yet - a clear word instead.

The device's own music is Kodi's music library (local()): albums, artists and songs Kodi has
scanned from the folders added to it, with its pictures and tags.
"""
import json
import os
import re
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import Request, urlopen

SOURCES = 'music_sources.json'
TIMEOUT = 8
MAX_BYTES = 2 * 1024 * 1024
KEEP = 600            # s an answer is reused
MEMORY = 64           # answers held at once
CATALOG_PAGE = 100    # a catalog row's page; fewer items: its end
AGENT = 'MegaNexus-Music/1.0 (Kodi)'
KINDS = ('tracks', 'albums', 'artists', 'playlists')

_lock = threading.Lock()
_memory = OrderedDict()


class MusicError(Exception):
    """What the person is told (a source that did not answer, a stream that cannot play)."""


# ---- the person's sources (kept in the profile; their addresses are secrets) ----------------------
def _file():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), SOURCES)


def sources():
    try:
        with open(_file(), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [s for s in saved if isinstance(s, dict) and s.get('base')] if isinstance(saved, list) else []


def _save(items):
    path = _file()
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(items, handle, ensure_ascii=False)
    os.replace(path + '.part', path)


def base_of(address):
    """The source's base: its manifest address without /manifest.json (it keeps any token). An install
    link that carries the manifest's address (eclipse://…?url=https%3A…manifest.json) gives that one."""
    from urllib.parse import unquote
    address = str(address or '').strip()
    inside = re.search(r'https?://\S+?/manifest\.json', unquote(address)) if not re.match(r'https?://', address) else None
    address = inside.group(0) if inside else address
    if not re.match(r'https?://', address):
        raise MusicError('A source is added by the address of its manifest (https://…/manifest.json).')
    return re.sub(r'/manifest\.json(\?.*)?$', '', address.rstrip('/'))


def safe(text):
    """Any source address in ``text`` without its path (where tokens live) - for logs and screens."""
    return re.sub(r'(https?://[^/\s]+)/[^\s]*', r'\1/…', str(text or ''))


def add(address):
    """Ask the source for its manifest; kept (last in the order) when it is a music source."""
    base = base_of(address)
    manifest = _get_json(base + '/manifest.json')
    if not isinstance(manifest, dict) or not manifest.get('id') or not manifest.get('name'):
        raise MusicError('That address did not answer as a music source.')
    resources = [str(r) for r in manifest.get('resources') or ()]
    if 'search' not in resources and 'catalog' not in resources:
        raise MusicError('%s has no search and no catalogs.' % manifest['name'])
    items = [s for s in sources() if s['manifest'].get('id') != manifest['id']]
    defaults = {str(s.get('key')): s.get('default') for s in manifest.get('settings') or () if isinstance(s, dict) and s.get('key')}
    items.append({'base': base, 'manifest': manifest, 'settings': {k: v for k, v in defaults.items() if v is not None}, 'on': True})
    _save(items)
    forget()
    return items[-1]


def remove(source_id):
    _save([s for s in sources() if s['manifest'].get('id') != source_id])
    forget()


def move(source_id, step):
    """Earlier (step -1) or later in the order - the first that has a track plays it."""
    items = sources()
    at = next((i for i, s in enumerate(items) if s['manifest'].get('id') == source_id), None)
    if at is None or not 0 <= at + step < len(items):
        return items
    items[at], items[at + step] = items[at + step], items[at]
    _save(items)
    return items


def configure(source_id, key, value):
    items = sources()
    for item in items:
        if item['manifest'].get('id') == source_id:
            item.setdefault('settings', {})[key] = value
    _save(items)
    forget()


def switch(source_id, on):
    items = sources()
    for item in items:
        if item['manifest'].get('id') == source_id:
            item['on'] = bool(on)
    _save(items)
    forget()


def _active():
    return [s for s in sources() if s.get('on', True)]


def client_only(source):
    """A source whose songs only Eclipse's own app can play (its manifest: playback client-resolved)."""
    return str(source['manifest'].get('playback') or '').lower() == 'client-resolved'


def _playing_sources():
    return [s for s in _active() if not client_only(s)]


def can_play():
    """Whether any source can play here (a catalogue's songs play only from one) - your debrid cloud and
    YouTube too."""
    from . import music_cloud
    return bool(_playing_sources() or music_cloud.services() or youtube_on())


# ---- YouTube: the very same recording, played by Kodi's YouTube add-on -------------------------------
YOUTUBE_SETTING = 'meganexus_music_youtube'
# as a video: the add-on's sound-only way (audio_only) gets "Please sign in" from YouTube (7.4.4), its video way plays
YOUTUBE_PLAY = 'plugin://plugin.video.youtube/play/?video_id=%s&incognito=true'


def youtube_on(addon=None):
    """Songs from YouTube when no source of yours has them: on unless turned off, with Kodi's YouTube add-on."""
    import xbmc
    import xbmcaddon
    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
        return False
    return (addon or xbmcaddon.Addon('plugin.video.meganexus')).getSetting(YOUTUBE_SETTING) != 'false'


def _minutes(text):
    parts = [int(p) for p in str(text or '').split(':') if p.isdigit()]
    seconds = 0
    for part in parts:
        seconds = seconds * 60 + part
    return seconds


# another version of a song (in a video's title, not in the song's): never the song itself, whoever put it up
VERSION = re.compile(r'\b(live|uzivo|acoustic|unplugged|remix|cover|instrumental|karaoke|speed ?up|sped ?up|slowed|'
                     r'reverb|8d|nightcore|bass ?boosted)\b')
# what others put up around a song: its words, their reaction - the artist's own lyric video is the song
OTHERS = re.compile(r'\b(lyrics?|tekst|text|reaction|reakcija|tiktok)\b')


def _words(text):
    return ' '.join(re.sub(r'[^\w]+', ' ', _fold(text)).split())


def _notes(title):
    """A title's notes in brackets: "Training Season (Live from the Royal Albert Hall)"."""
    return [a or b for a, b in re.findall(r'\((.*?)\)|\[(.*?)\]', title or '')]


def _names(artist, text):
    """``text`` names the artist: their whole name, or one of its words of four letters or more ("M. P. Thompson"
    for Marko Perković Thompson) - as a word."""
    plain, name = _plain(text), _plain(artist)
    if re.search(r'\b%s\b' % re.escape(name), plain):
        return True
    return any(re.search(r'\b%s\b' % re.escape(word), plain) for word in name.split() if len(word) >= 4)


def on_youtube(track):
    """The song's own upload on YouTube - by the artist's channel (its name naming them, or its "- Topic" one), or
    by a channel YouTube has verified (the label's: "Jala Brat & Buba Corelli feat. Elena - Shalala" on IMPERIA)
    whose title starts with the artist and is not someone's lyric video; never another version of it (live,
    sped up, a remix... unless the song is that one) - the same title and length (same()): its address for the
    YouTube add-on; '' when there is none. Never a song only nearly the one."""
    from . import youtube
    artist = (track.get('artist') or '').split(',')[0].strip()
    if not artist or not track.get('title'):
        return ''
    # 9.0.7: the answer's first page first - the song is nearly always on it; the page after it only when it is not
    # (both were asked for every song: a second's wait more on the Cube before it started)
    for pages in (1, youtube.SEARCH_PAGES):
        try:
            found = youtube.search('%s %s' % (artist, track['title']), pages=pages)
        except Exception:
            return ''
        video = next((v for v in found if _the_song(track, artist, v)), None)
        if video:
            return YOUTUBE_PLAY % video['id']
    return ''


def _the_song(track, artist, video):
    """``video`` is the song itself (on_youtube's rules)."""
    # a 4K upload comes as a stream whose sound Kodi never gets (the Cube, 2026-11-03: IMPERIA's, Dua Lipa's
    # live one - the picture ran, silent): a song is its sound. (9.0.8: the YouTube add-on's audio_only is no way
    # round it - with it the add-on 7.4.4 gives Kodi nothing it can play, every song was passed: the PC, 2026-11-04)
    if video.get('live') or video.get('uhd'):
        return False
    channel = re.sub(r'\s+-\s+Topic$', '', video.get('channel') or '')
    title = full = video.get('title') or ''
    who, dash, rest = (re.split(r'(\s+[-–]\s+)', title, maxsplit=1) + ['', ''])[:3]
    credited = bool(dash) and _names(artist, who)
    if credited:
        title = rest                    # "Shakira, Burna Boy - Dai Dai (Official Audio)": the song's own name
    other = {'title': title, 'artist': artist, 'seconds': _minutes(video.get('length'))}   # the channel is checked below
    own = _names(artist, channel)       # "devito anonymo", "Marko Perković Thompson", its "- Topic"
    # a label's own upload: YouTube's tick by the channel, the title is the song as released (its notes too)
    label = credited and video.get('verified') and not OTHERS.search(_fold(full))
    other_version = set(VERSION.findall(_fold(full))) - set(VERSION.findall(_fold(track['title'])))
    # the song is a version ("Live from the Royal Albert Hall"): that one, never another live
    other_version = other_version or any(_words(note) not in _words(full) for note in _notes(track['title']) if VERSION.search(_fold(note)))
    return bool((own or label) and not other_version and same(dict(track, isrc=''), other) and other['seconds'])


def _source(source_id):
    found = next((s for s in sources() if s['manifest'].get('id') == source_id), None)
    if found is None:
        raise MusicError('That music source is no longer added.')
    return found


# ---- asking a source ---------------------------------------------------------------------
def forget():
    with _lock:
        _memory.clear()


def _get_json(url, headers=None):
    request = Request(url, headers=dict({'User-Agent': AGENT, 'Accept': 'application/json'}, **(headers or {})))
    try:
        with urlopen(request, timeout=TIMEOUT) as response:
            body = response.read(MAX_BYTES + 1)
    except Exception as exc:
        code = getattr(exc, 'code', None)
        if code == 404:
            return None
        raise MusicError('%s did not answer (%s).' % (safe(url), code or type(exc).__name__))
    if len(body) > MAX_BYTES:
        raise MusicError('%s answered too much.' % safe(url))
    try:
        return json.loads(body.decode('utf-8'))
    except ValueError:
        raise MusicError('%s did not answer in JSON.' % safe(url))


def _ask(source, path, **params):
    """GET base/path with the source's settings and ``params``; kept in memory for a while."""
    query = dict((source.get('settings') or {}), **{k: v for k, v in params.items() if v is not None})
    query = {k: ('true' if v is True else 'false' if v is False else v) for k, v in query.items()}
    url = source['base'] + path + ('?' + urlencode(query) if query else '')
    now = time.monotonic()
    with _lock:
        held = _memory.get(url)
        if held and held[0] > now:
            _memory.move_to_end(url)
            return held[1]
    answer = _get_json(url)
    with _lock:
        _memory[url] = (now + KEEP, answer)
        while len(_memory) > MEMORY:
            _memory.popitem(last=False)
    return answer


# ---- reading the answers (leniently) -------------------------------------------------------
def _text(obj, *keys):
    for key in keys:
        value = obj.get(key)
        if isinstance(value, (str, int, float)) and str(value).strip():
            return str(value).strip()
    return ''


def _seconds(obj):
    for key, scale in (('duration', 1), ('durationMs', 1000), ('duration_ms', 1000)):
        try:
            value = float(obj.get(key) or 0)
        except (TypeError, ValueError):
            continue
        if value > 0:
            return int(value / scale)
    return 0


def _picture(obj):
    return _text(obj, 'artworkURL', 'artwork', 'image', 'cover', 'thumbnail', 'icon')


def item(obj, source_id, kind=None):
    """One track, album, artist or playlist as the app keeps it (None for nothing usable)."""
    if not isinstance(obj, dict) or not _text(obj, 'id'):
        return None
    kind = kind or str(obj.get('type') or 'track')
    kind = kind[:-1] if kind.endswith('s') else kind
    title = _text(obj, 'title', 'name')
    if not title:
        return None
    found = {'kind': kind, 'source': source_id, 'id': _text(obj, 'id'), 'title': title,
             'artist': _text(obj, 'artist', 'creator', 'artists'), 'album': _text(obj, 'album'),
             'picture': _picture(obj), 'year': _text(obj, 'year'), 'isrc': _text(obj, 'isrc'),
             'seconds': _seconds(obj), 'stream': _text(obj, 'streamURL', 'streamUrl'),
             'count': int(obj.get('trackCount') or 0) if str(obj.get('trackCount') or '').isdigit() else 0,
             'about': _text(obj, 'description', 'bio')}
    if kind == 'artist':
        found['artist'] = ', '.join(g for g in obj.get('genres') or () if isinstance(g, str))
    return found


def _items(values, source_id, kind=None):
    return [i for i in (item(v, source_id, kind) for v in values or ()) if i]


# ---- what the app asks for -----------------------------------------------------------------
def search(query, stopped=None):
    """Every source with search, asked at once; their answers together, the sources' order kept."""
    asking = [s for s in _active() if 'search' in (s['manifest'].get('resources') or ())]
    found = {kind: [] for kind in KINDS}
    if not asking:
        return found

    def one(source):
        try:
            return _ask(source, '/search', q=query) or {}
        except MusicError:
            return {}
    with ThreadPoolExecutor(max_workers=min(4, len(asking)), thread_name_prefix='MegaNexusMusic') as pool:
        answers = list(pool.map(one, asking))
    for source, answer in zip(asking, answers):
        if stopped and stopped():
            break
        for kind in KINDS:
            found[kind] += _items((answer or {}).get(kind) if isinstance(answer, dict) else None, source['manifest']['id'], kind)
    return found


def catalogs():
    """Every source's catalog rows: (source id, catalog id, name, kind)."""
    rows = []
    for source in _active():
        for catalog in source['manifest'].get('catalogs') or ():
            if isinstance(catalog, dict) and catalog.get('id'):
                rows.append((source['manifest']['id'], str(catalog['id']), _text(catalog, 'name', 'title') or str(catalog['id']),
                             str(catalog.get('type') or '')))
    return rows


def catalog(source_id, catalog_id, skip=0, kind=''):
    """A catalog row: every item is of the row's kind (one that says it is another is left out)."""
    answer = _ask(_source(source_id), '/catalog/%s' % quote(catalog_id, safe=''), skip=skip) or {}
    values = answer.get('items') if isinstance(answer, dict) else answer
    if kind:
        values = [v for v in values or () if isinstance(v, dict) and str(v.get('type') or kind).rstrip('s') == kind.rstrip('s')]
    return _items(values, source_id, kind or None)


def details(source_id, kind, item_id):
    """An album's, artist's or playlist's page: (its item, its tracks, its albums)."""
    if source_id == DEEZER:
        return deezer_details(kind, item_id)
    if source_id in ('apple', 'spotify'):
        from . import music_meta
        return (music_meta.apple_details if source_id == 'apple' else music_meta.spotify_details)(kind, item_id)
    answer = _ask(_source(source_id), '/%s/%s' % (kind, quote(item_id, safe=''))) or {}
    if not isinstance(answer, dict):
        raise MusicError('That page is not there any more.')
    tracks = _items(answer.get('tracks') or answer.get('topTracks'), source_id, 'track')
    head = item(dict(answer, id=answer.get('id') or item_id), source_id, kind) or {'kind': kind, 'id': item_id, 'title': '', 'source': source_id}
    for track in tracks:
        track['picture'] = track['picture'] or head.get('picture', '')
        track['album'] = track['album'] or (head['title'] if kind == 'album' else '')
    return head, tracks, _items(answer.get('albums'), source_id, 'album')


def stream(source_id, track_id, known=''):
    """A track's address to play now (asked for only when it plays - it may expire)."""
    if known:
        return known
    source = _source(source_id)
    if client_only(source):
        raise MusicError('%s plays its songs only in Eclipse\'s own app.' % source['manifest'].get('name', 'This source'))
    answer = _ask(source, '/stream/%s' % quote(track_id, safe='')) or {}
    if not isinstance(answer, dict) or not answer.get('url'):
        raise MusicError('The source has no stream for this track.')
    if answer.get('encrypted'):
        raise MusicError('This track is protected - MegaNexus does not play protected music.')
    if str(answer.get('manifest') or 'none').lower() in ('hls', 'dash'):
        raise MusicError('This track comes as %s - not played yet.' % str(answer['manifest']).upper())
    return str(answer['url'])


# ---- the device's own music (Kodi's music library) -------------------------------------------
def _rpc(method, params):
    import xbmc
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    except (TypeError, ValueError):
        return {}
    return reply.get('result') or {}


def _local_picture(art):
    art = art or {}
    return art.get('thumb') or art.get('album.thumb') or art.get('fanart') or ''


def local(kind, **filters):
    """Kodi's music library: 'albums' (newest first), 'artists', 'songs' (of an album or artist)."""
    if kind == 'albums':
        result = _rpc('AudioLibrary.GetAlbums', {'properties': ['title', 'artist', 'year', 'art'],
                                                 'sort': {'method': 'dateadded', 'order': 'descending'}, 'limits': {'end': 200}})
        return [{'kind': 'album', 'source': 'local', 'id': str(a['albumid']), 'title': a.get('title') or '',
                 'artist': ', '.join(a.get('artist') or ()), 'picture': _local_picture(a.get('art')), 'year': str(a.get('year') or ''),
                 'album': '', 'isrc': '', 'seconds': 0, 'stream': '', 'count': 0, 'about': ''} for a in result.get('albums') or ()]
    if kind == 'artists':
        result = _rpc('AudioLibrary.GetArtists', {'properties': ['art'], 'albumartistsonly': True, 'limits': {'end': 200}})
        return [{'kind': 'artist', 'source': 'local', 'id': str(a['artistid']), 'title': a.get('artist') or a.get('label') or '',
                 'artist': '', 'picture': _local_picture(a.get('art')), 'year': '', 'album': '', 'isrc': '', 'seconds': 0,
                 'stream': '', 'count': 0, 'about': ''} for a in result.get('artists') or ()]
    params = {'properties': ['title', 'artist', 'album', 'duration', 'file', 'art', 'track'],
              'sort': {'method': 'track'}, 'limits': {'end': 500}}
    if filters.get('album'):
        params['filter'] = {'albumid': int(filters['album'])}
    elif filters.get('artist'):
        params['filter'] = {'artistid': int(filters['artist'])}
    result = _rpc('AudioLibrary.GetSongs', params)
    return [{'kind': 'track', 'source': 'local', 'id': str(s['songid']), 'title': s.get('title') or s.get('label') or '',
             'artist': ', '.join(s.get('artist') or ()), 'album': s.get('album') or '', 'picture': _local_picture(s.get('art')),
             'year': '', 'isrc': '', 'seconds': int(s.get('duration') or 0), 'stream': s.get('file') or '', 'count': 0,
             'about': ''} for s in result.get('songs') or ()]


def host(source):
    """The source's host alone - what Settings shows of its address."""
    return urlsplit(source.get('base') or '').netloc


# ---- playing: the address asked for as the track starts --------------------------------------
def _fold(text):
    """Lower case, without accents (Aleksić = Aleksic)."""
    import unicodedata
    text = unicodedata.normalize('NFKD', str(text or '').lower().replace('đ', 'd'))
    return ''.join(c for c in text if not unicodedata.combining(c))


def _plain(text):
    """Words to compare: lower case, without accents, notes in brackets or "feat."."""
    return re.sub(r'[^\w]+', ' ', re.sub(r'\(.*?\)|\[.*?\]|feat\..*$', '', _fold(text))).strip()


def same(track, other):
    """The same recording - never "nearly": the same ISRC, or the same title and artist and a
    length within 3 s (when both are known)."""
    if track.get('isrc') and other.get('isrc'):
        return track['isrc'].upper() == other['isrc'].upper()
    if _plain(track.get('title')) != _plain(other.get('title')) or not _plain(other.get('title')):
        return False
    if _plain(track.get('artist')).split(' ')[:1] != _plain(other.get('artist')).split(' ')[:1]:
        return False
    return not (track.get('seconds') and other.get('seconds')) or abs(track['seconds'] - other['seconds']) <= 3


ORDER = 'meganexus_music_order'
PLACES = (('sources', 'Your music sources'), ('cloud', 'Your debrid cloud'), ('youtube', 'YouTube'))
ORIGINS = {'local': 'Your folders', 'youtube': 'YouTube', 'torbox': 'TorBox', 'realdebrid': 'Real-Debrid'}


def order(addon=None, value=None):
    """Where a song is looked for, first to last (Settings > Music, as the films' sources): your music
    sources (in their own order), your debrid cloud, YouTube. ``value``: a new order."""
    import xbmcaddon
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    known = [key for key, _ in PLACES]
    if value is not None:
        addon.setSetting(ORDER, ','.join(v for v in value if v in known))
    chosen = [v for v in (addon.getSetting(ORDER) or '').split(',') if v in known]
    return list(dict.fromkeys(chosen + known))


def origin(source):
    """Where a song plays from, in words (Now playing, the small player): YouTube, TorBox, a source's name."""
    if source in ORIGINS:
        return ORIGINS[source]
    found = next((s for s in sources() if s['manifest'].get('id') == source), None)
    return found['manifest'].get('name', '') if found else ''


def _from_sources(track):
    """The very same recording from one of your sources (their order) - by its ISRC where a source can,
    else a search whose answer must be the same recording (same())."""
    for source in _playing_sources():
        source_id = source['manifest'].get('id')
        if source_id == track.get('source'):
            continue
        resources = source['manifest'].get('resources') or ()
        try:
            found = None
            if track.get('isrc') and 'isrc' in resources:
                answer = _ask(source, '/resolve-isrc', isrc=track['isrc']) or {}
                found = answer.get('trackId') or answer.get('id') if isinstance(answer, dict) else None
                found = {'id': found} if found else None
            if found is None and 'search' in resources:
                answer = _ask(source, '/search', q='%s %s' % (track.get('artist', ''), track['title'])) or {}
                found = next((t for t in _items(answer.get('tracks'), source_id, 'track') if same(track, t)), None)
            if found:
                return stream(source_id, found['id'], found.get('stream')), source_id
        except MusicError:
            continue
    return None


def _from_cloud(track):
    from . import music_cloud
    found = music_cloud.find(track) if music_cloud.services() else None
    return (music_cloud.link(found['id']), found['id'].split(':', 1)[0]) if found else None


def _from_youtube(track):
    found = on_youtube(track) if youtube_on() else ''
    return (found, 'youtube') if found else None


def playable(track):
    """(address, where it plays from): the track's own source first, then the places of order() - a
    catalogue's song only ever as the very same recording. Raises MusicError with the first reason when
    none can."""
    if track.get('source') == 'local':
        return track['stream'], 'local'
    from . import music_cloud
    if track.get('source') == 'youtube' and track.get('stream'):
        return track['stream'], 'youtube'                    # a YouTube playlist's song: that very video
    if track.get('source') == music_cloud.SOURCE:
        if 'waiting' in track:
            raise MusicError('TorBox is still downloading this album (%d%%) - it plays once it is in your cloud.' % track['waiting'])
        return music_cloud.link(track['id']), track['id'].split(':', 1)[0]
    problem = None
    if track.get('source') in (DEEZER, 'apple', 'spotify', 'import'):
        # a catalogue (or a playlist brought in) only knows the song: a source plays it - found by its ISRC, or the very same recording
        problem = MusicError('None of your music sources has this song.' if can_play() else
                             'Add a music source to play this song (Settings > Music).')
        # 9.0.7: its ISRC only when a source of yours is asked (_from_sources) - the cloud and YouTube match by title and
        # length: without a source it was a question more before every song, and one Deezer did not answer stopped it
        if not track.get('isrc') and track['source'] == DEEZER and _playing_sources():
            track = dict(track, isrc=_text(_deezer('/track/%s' % quote(track['id'], safe='')) or {}, 'isrc'))
        elif not track.get('isrc') and track['source'] == 'spotify' and _playing_sources():
            from . import music_meta
            track = dict(track, isrc=music_meta.spotify_isrc(track['id']))
    else:
        try:
            return stream(track['source'], track['id'], track.get('stream')), track['source']
        except MusicError as exc:
            problem = exc
    for place in order():
        found = {'sources': _from_sources, 'cloud': _from_cloud, 'youtube': _from_youtube}[place](track)
        if found:
            return found
    raise problem


# ---- the person's own folders (Local music) ----------------------------------------------------
FOLDERS = 'music_folders.json'
AUDIO = ('.mp3', '.flac', '.m4a', '.aac', '.ogg', '.oga', '.opus', '.wav', '.wma', '.ape', '.alac', '.aiff')
COVERS = ('cover.jpg', 'folder.jpg', 'front.jpg', 'cover.png', 'folder.png', 'album.jpg')
MAX_FILES, MAX_DEPTH = 5000, 6
_scanned = {'at': 0.0, 'albums': [], 'tracks': {}}
SCAN_KEEP = 300       # s a scan of the folders is reused (in memory)
_scanning = threading.Lock()    # 9.0.7: one scan at a time - the app's two folder rows each walked every folder


def folders():
    try:
        from .meganexus.paths import profile_path
        with open(os.path.join(profile_path(), FOLDERS), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [f for f in saved if isinstance(f, str)] if isinstance(saved, list) else []


def set_folders(paths):
    from .meganexus.paths import profile_path
    path = os.path.join(profile_path(), FOLDERS)
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(list(dict.fromkeys(paths)), handle, ensure_ascii=False)
    os.replace(path + '.part', path)
    _scanned['at'] = 0.0


def _join(folder, name):
    return folder + name if folder.endswith(('/', '\\')) else folder + '/' + name


def _song_name(file_name):
    """'03 - Artist - Title.mp3' -> (artist or '', 'Title')."""
    stem = re.sub(r'\.[^.]+$', '', file_name)
    stem = re.sub(r'^\s*(?:disc\s*\d+\s*)?\d{1,3}\s*[-._)]\s*', '', stem, flags=re.I).strip()
    if ' - ' in stem:
        artist, title = stem.split(' - ', 1)
        return artist.strip(), title.strip()
    return '', stem


def scan(fresh=False):
    """The folders' music as albums - a folder with audio files is an album (its cover, its
    tracks); the artist from 'Artist - Title' file names or the folder above it."""
    if not fresh and _scanned['albums'] and time.monotonic() - _scanned['at'] < SCAN_KEEP:
        return _scanned['albums'], _scanned['tracks']
    with _scanning:
        if not fresh and _scanned['albums'] and time.monotonic() - _scanned['at'] < SCAN_KEEP:
            return _scanned['albums'], _scanned['tracks']        # scanned meanwhile, for the row that asked first
        return _scan()


def _scan():
    import xbmcvfs
    albums, tracks, seen = [], {}, [0]

    def walk(folder, depth, parent):
        if depth > MAX_DEPTH or seen[0] > MAX_FILES:
            return
        try:
            dirs, files = xbmcvfs.listdir(folder)
        except Exception:
            return
        audio = sorted(f for f in files if f.lower().endswith(AUDIO))
        seen[0] += len(audio)
        if audio:
            name = folder.rstrip('/\\').replace('\\', '/').rsplit('/', 1)[-1]
            cover = next((_join(folder, f) for f in files if f.lower() in COVERS), '')
            songs = []
            for number, file_name in enumerate(audio, 1):
                artist, title = _song_name(file_name)
                songs.append({'kind': 'track', 'source': 'local', 'id': _join(folder, file_name), 'title': title,
                              'artist': artist or parent, 'album': name, 'picture': cover, 'year': '', 'isrc': '',
                              'seconds': 0, 'stream': _join(folder, file_name), 'count': 0, 'about': '', 'number': number})
            tracks[folder] = songs
            albums.append({'kind': 'album', 'source': 'local', 'id': folder, 'title': name, 'artist': parent,
                           'picture': cover, 'year': '', 'isrc': '', 'seconds': 0, 'stream': '', 'count': len(songs), 'about': ''})
        here = folder.rstrip('/\\').replace('\\', '/').rsplit('/', 1)[-1]
        for sub in sorted(dirs):
            walk(_join(folder, sub), depth + 1, here)

    for root in folders():
        walk(root, 0, '')
    _scanned.update(at=time.monotonic(), albums=albums, tracks=tracks)
    return albums, tracks


# ---- what was played: Recently played, your artists, For you --------------------------------------
HISTORY, HISTORY_MAX = 'music_history.json', 500


def _history_path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), HISTORY)


def history():
    try:
        with open(_history_path(), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [h for h in saved if isinstance(h, dict) and isinstance(h.get('song'), dict)] if isinstance(saved, list) else []


def played(track):
    """A song that started to play (music_play) - newest first."""
    song = {k: track.get(k) for k in ('kind', 'source', 'id', 'title', 'artist', 'album', 'picture', 'seconds', 'isrc', 'year')}
    if song.get('source') == 'local':
        song['stream'] = track.get('stream')
    items = [{'song': song, 'at': int(time.time())}] + history()[:HISTORY_MAX - 1]
    path = _history_path()
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(items, handle, ensure_ascii=False)
    os.replace(path + '.part', path)


FOLLOW = 'music_follow.json'
# the first time's choice: in each part of the world the best known artists of all time - those Deezer's own
# public playlists of its kinds of music hold the most (ex-yu rock, narodna, zabavna...) - and today's most
# played, from Apple's public charts of its countries. No key, no list of ours: a part's (name, countries,
# searches); a country or a search that does not answer is left out.
REGIONS = (('United States', ('us',),
            ('classic rock', 'heavy metal', 'hard rock', 'pop hits', 'hip hop classics', 'rnb classics', 'country hits',
             'alternative rock', 'punk rock', 'edm hits', 'jazz classics', '80s hits')),
           ('World', ('us', 'gb', 'de', 'br', 'mx', 'jp', 'in', 'id', 'au', 'ca'),
            ('greatest hits of all time', 'rock classics', 'metal classics', 'pop classics', 'hip hop classics',
             'dance classics', 'latin hits', 'reggae classics', 'rnb classics', 'edm hits')),
           ('Europe', ('gb', 'de', 'fr', 'it', 'es', 'nl', 'pl', 'se', 'at'),
            ('eurovision hits', 'europop', 'britpop', 'italian classics', 'french classics', 'german classics',
             'spanish hits', 'european metal', 'eurodance 90s', 'nordic rock')),
           ('Asia', ('jp', 'kr', 'in', 'id', 'ph', 'th', 'tw'),
            ('k-pop hits', 'j-pop hits', 'j-rock', 'bollywood hits', 'c-pop', 'anime songs', 'thai pop')),
           ('Balkan', ('rs', 'hr', 'ba', 'si', 'me', 'mk'),
            ('ex yu rock', 'ex yu hitovi', 'narodna muzika', 'zabavna muzika', 'hrvatska glazba', 'srpska muzika',
             'balkan pop', 'dalmatinske pjesme', 'sevdah', 'ex yu punk', 'turbo folk 90')))
CLASSICS_SHARE = 2                    # of every three artists of a part, two from its kinds of music, one from today's charts
REGION_SIZE = 45
APPLE_CHART = 'https://rss.marketingtools.apple.com/api/v2/%s/music/most-played/100/songs.json'
_TOGETHER = re.compile(r'\s+(?:&|x|X|feat\.?|ft\.?|with)\s+|,\s*')


def _follow_path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), FOLLOW)


def follows():
    """The artists this profile follows (Deezer's - their pages open), the newest first."""
    try:
        with open(_follow_path(), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [a for a in saved if isinstance(a, dict) and a.get('id')] if isinstance(saved, list) else []


def follow(artist, on=True):
    items = [a for a in follows() if a['id'] != artist['id']]
    if on:
        items.insert(0, {k: artist.get(k) for k in ('kind', 'source', 'id', 'title', 'artist', 'picture')})
    path = _follow_path()
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(items, handle, ensure_ascii=False)
    os.replace(path + '.part', path)


def following(artist):
    return any(a['id'] == artist.get('id') for a in follows()) if artist.get('source') == DEEZER else False


def region_names(stores):
    """The artists the most played in these countries, the best first: a song high in a chart counts more;
    the artists of a song together (Jala Brat & Buba Corelli) each on their own."""
    def chart(store):
        try:
            return _get_cached(APPLE_CHART % store)
        except MusicError:
            return None                                   # a country that does not answer is left out
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix='MegaNexusMusic') as pool:
        charts = list(pool.map(chart, stores))
    score = {}
    for chart in charts:
        songs = ((chart or {}).get('feed') or {}).get('results') if isinstance(chart, dict) else None
        for place, song in enumerate(songs or []):
            for name in _TOGETHER.split(str(song.get('artistName') or '')):
                name = name.strip()
                if name:
                    score[name] = score.get(name, 0) + 100 - place
    return [name for name, _ in sorted(score.items(), key=lambda pair: -pair[1])]


def region_classics(searches):
    """The artists Deezer's public playlists of these kinds of music hold the most - in turns, one kind after
    the other (metal, rock, pop, hip hop... each its best known first), so no kind fills the list alone."""
    def ranked(search):
        try:
            lists = [p.get('id') for p in _data(_deezer('/search/playlist', q=search, limit=2)) if p.get('id')]
        except MusicError:
            return []
        score, artists = {}, {}
        for playlist in lists:
            try:
                songs = _data(_deezer('/playlist/%s/tracks' % playlist, limit=100))
            except MusicError:
                continue
            for track in songs:
                artist = track.get('artist') or {}
                if artist.get('id'):
                    score[artist['id']] = score.get(artist['id'], 0) + 1
                    artists[artist['id']] = artist
        return [a for a in (_dz(artists[i], 'artist') for i in sorted(score, key=lambda i: -score[i])) if a]
    with ThreadPoolExecutor(max_workers=8, thread_name_prefix='MegaNexusMusic') as pool:
        kinds = [k for k in pool.map(ranked, searches) if k]
    out, seen = [], set()
    while any(kinds):
        for kind in kinds:
            while kind:
                artist = kind.pop(0)
                if artist['id'] not in seen:
                    seen.add(artist['id'])
                    out.append(artist)
                    break
    return out


def region_artists(index):
    """REGIONS[index]'s REGION_SIZE artists as Deezer has them (their page, their picture): of every three, two
    best known of all time, one most played today."""
    _, stores, searches = REGIONS[index]
    classics = region_classics(searches)
    names = region_names(stores)[:REGION_SIZE]
    with ThreadPoolExecutor(max_workers=8, thread_name_prefix='MegaNexusMusic') as pool:
        today = [a for a in pool.map(deezer_artist, names) if a]
    out, seen = [], set()
    while (classics or today) and len(out) < REGION_SIZE:
        for source in [classics] * CLASSICS_SHARE + [today]:
            while source:
                artist = source.pop(0)
                if artist['id'] not in seen:
                    seen.add(artist['id'])
                    out.append(artist)
                    break
    return out[:REGION_SIZE]


def deezer_artist(name):
    """Deezer's artist of exactly this name (their page, their songs), or None."""
    return next((a for a in _dzs(_deezer('/search/artist', q=name, limit=5), 'artist') if _plain(a['title']) == _plain(name)), None)


def more_like(track, count=25):
    """Songs to go on with when the queue ends (as music services do): Deezer's mix of the song's artist - or,
    with none, the artist's own best songs, then an artist like them; what was heard lately left out."""
    artist = deezer_artist((track.get('artist') or '').split(',')[0].strip())
    if not artist:
        return []
    heard = {(s.get('title') or '').lower() for s in recent(100)} | {(track.get('title') or '').lower()}
    fresh = lambda answer: [s for s in _dzs(answer, 'track') if s['title'].lower() not in heard]
    songs = fresh(_deezer('/artist/%s/radio' % artist['id'], limit=count)) or fresh(_deezer('/artist/%s/top' % artist['id'], limit=count))
    if not songs:
        for like in _dzs(_deezer('/artist/%s/related' % artist['id'], limit=3), 'artist'):
            songs = fresh(_deezer('/artist/%s/top' % like['id'], limit=count))
            if songs:
                break
    return songs


def recent(count=40):
    """The songs played lately, each once, newest first."""
    seen, out = set(), []
    for item in history():
        key = (item['song'].get('source'), item['song'].get('id'))
        if key not in seen:
            seen.add(key)
            out.append(item['song'])
    return out[:count]


def _together(fn, items):
    """fn(item) for each item at once (Deezer answers each in about 100 ms; one after another they added up)."""
    with ThreadPoolExecutor(max_workers=6, thread_name_prefix='MegaNexusMusic') as pool:
        return list(pool.map(fn, items))


_tops = {'key': None, 'found': []}


def top_artists(count=12):
    """Your artists: the ones you follow, then the ones you play most (as Deezer's - their pages open) - found
    once while neither changes (four of Home's rows ask for them at once)."""
    key = (tuple(a['id'] for a in follows()), len(history()), count)
    with _lock:
        if _tops['key'] == key:
            return list(_tops['found'])
    found = _top_artists(count)
    with _lock:
        _tops.update(key=key, found=found)
    return list(found)


def _top_artists(count):
    found = list(follows())
    counts = OrderedDict()
    for item in history():
        name = (item['song'].get('artist') or '').split(',')[0].strip()
        if name:
            counts[name] = counts.get(name, 0) + 1
    known = {_plain(a['title']) for a in found}
    names = [n for n in sorted(counts, key=lambda n: -counts[n]) if _plain(n) not in known][:max(0, count - len(found))]
    found += [hit for hit in _together(deezer_artist, names) if hit]
    return found[:count]


def for_you(count=50):
    """A mix of your artists' songs and of the artists like them (Deezer's), what you heard lately left out."""
    heard = {(s.get('title') or '').lower() for s in recent(200)}
    yours = top_artists(6)
    like = [r for related in _together(lambda a: _dzs(_deezer('/artist/%s/related' % a['id'], limit=3), 'artist'), yours[:3]) for r in related]
    mix = [[s for s in songs if s['title'].lower() not in heard]
           for songs in _together(lambda a: _dzs(_deezer('/artist/%s/top' % a['id'], limit=8), 'track'), yours + like)]
    out, seen = [], set()
    for n in range(8):
        for songs in mix:
            if n < len(songs) and songs[n]['id'] not in seen:
                seen.add(songs[n]['id'])
                out.append(songs[n])
    return out[:count]


def like_them():
    """Artists like the ones you follow and play, that you do not follow yet."""
    yours = top_artists(6)
    mine = {a['id'] for a in yours}
    out = []
    for related in _together(lambda a: _dzs(_deezer('/artist/%s/related' % a['id'], limit=10), 'artist'), yours[:4]):
        out += [r for r in related if r['id'] not in mine]
        mine |= {r['id'] for r in related}
    return out[:40]


def new_from_yours():
    """Your artists' latest albums and singles, the newest first."""
    yours = top_artists(8)
    found = [dict(album, artist=album['artist'] or artist['title']) for artist, albums in
             zip(yours, _together(lambda a: _dzs(_deezer('/artist/%s/albums' % a['id'], limit=6), 'album'), yours)) for album in albums]
    return sorted(found, key=lambda a: a['year'], reverse=True)[:40]


# ---- the person's library (tracks, albums, artists, playlists they saved) ----------------------
LIBRARY = 'music_library.json'


def _library_path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), LIBRARY)


def library():
    try:
        with open(_library_path(), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [i for i in saved if isinstance(i, dict) and i.get('id')] if isinstance(saved, list) else []


def _key(entry):
    return (entry.get('source'), entry.get('kind'), entry.get('id'))


def saved(entry):
    return any(_key(i) == _key(entry) for i in library())


def keep(entry, on=True):
    """Save ``entry`` in the library (newest first) or take it out."""
    items = [i for i in library() if _key(i) != _key(entry)]
    if on:
        items.insert(0, {k: v for k, v in entry.items() if k != 'stream' or entry.get('source') == 'local'})
    path = _library_path()
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(items, handle, ensure_ascii=False)
    os.replace(path + '.part', path)


# ---- Deezer's public catalogue: charts, search, albums, artists, playlists - and your profile -----
# What the app shows without a source (and the pictures for your own music). Deezer only says what
# a song is - a source plays it (playable(): by its ISRC, or a search for the very same recording).
DEEZER = 'deezer'
DEEZER_API = 'https://api.deezer.com'
PROFILE = 'meganexus_music_deezer_profile'     # the person's Deezer profile (its number) - public data only
PICTURES = DEEZER_API + '/search/%s?%s'
_pictures = {}


def _deezer(path, **params):
    """Deezer's answer to GET path (kept in memory for a while); None when it has nothing."""
    return _get_cached(DEEZER_API + path + ('?' + urlencode(params) if params else ''))


_asking = {}      # url: the question on its way (a second asker waits for its answer, not asks again)


def _get_cached(url, headers=None):
    """A catalogue's answer to GET url, kept in memory for a while (None: it has nothing). Asked once even
    when several rows want it at the same time (an artist's four rows: their page once)."""
    with _lock:
        held = _memory.get(url)
        if held and held[0] > time.monotonic():
            return held[1]
        waiting = _asking.get(url)
        if waiting is None:
            _asking[url] = threading.Event()
    if waiting is not None:
        waiting.wait(TIMEOUT * 2)
        with _lock:
            held = _memory.get(url)
        if held:
            return held[1]
    try:
        return _ask_now(url, headers)
    finally:
        with _lock:
            done = _asking.pop(url, None)
        if done is not None:
            done.set()


def _ask_now(url, headers):
    now = time.monotonic()
    answer = _get_json(url, headers)
    if isinstance(answer, dict) and answer.get('error'):
        answer = None
    with _lock:
        _memory[url] = (now + KEEP, answer)
        while len(_memory) > MEMORY:
            _memory.popitem(last=False)
    return answer


def _data(answer):
    if isinstance(answer, dict):
        answer = answer.get('data')
    return [v for v in answer or () if isinstance(v, dict)]


def _dz(obj, kind, album=None):
    """One of Deezer's songs, albums, artists or playlists as the app keeps it."""
    if not obj.get('id'):
        return None
    album = album or obj.get('album') or {}
    artist = (obj.get('artist') or {}).get('name') or ''
    found = {'kind': kind, 'source': DEEZER, 'id': str(obj['id']), 'title': obj.get('title') or obj.get('name') or '',
             'artist': artist, 'album': '', 'picture': '', 'year': '', 'isrc': obj.get('isrc') or '', 'seconds': 0,
             'stream': '', 'count': 0, 'about': ''}
    # 'picture' big (the top's artwork), 'thumb' at a card's size: a row of 1000 px covers held Kodi's drawing up
    art = album if kind == 'track' else obj
    prefix = 'cover' if kind in ('track', 'album') else 'picture'
    found.update(picture=art.get(prefix + '_xl') or art.get(prefix + '_big') or '', thumb=art.get(prefix + '_medium') or '')
    if kind == 'track':
        found.update(album=album.get('title') or '', seconds=int(obj.get('duration') or 0))
    elif kind == 'album':
        found.update(year=(obj.get('release_date') or '')[:4], count=int(obj.get('nb_tracks') or 0), record=obj.get('record_type') or 'album')
    elif kind == 'artist':
        fans = int(obj.get('nb_fan') or 0)
        found.update(artist='%s fans' % format(fans, ',') if fans else '')
    else:
        found.update(count=int(obj.get('nb_tracks') or 0), artist=((obj.get('user') or obj.get('creator') or {}).get('name') or ''),
                     about=obj.get('description') or '')
    return found if found['title'] else None


def _dzs(values, kind):
    return [i for i in (_dz(v, kind) for v in _data(values)) if i]


def deezer_home():
    """Deezer's charts where the person is: [(title, entries)]. 9.0.7: the chart and the editors' albums asked at
    once - every chart row waited for both, one after the other."""
    with ThreadPoolExecutor(max_workers=2, thread_name_prefix='MegaNexusMusic') as pool:
        answer, picked = pool.map(lambda ask: ask(), (lambda: _deezer('/chart/0', limit=40), lambda: _deezer('/editorial/0/selection')))
    answer = answer or {}
    picked = _dzs(picked, 'album')        # the chart's albums are often only one or two
    return [('Top songs', _dzs(answer.get('tracks'), 'track')), ('Albums', _dzs(answer.get('albums'), 'album') + picked),
            ('Top artists', _dzs(answer.get('artists'), 'artist')), ('Top playlists', _dzs(answer.get('playlists'), 'playlist'))]


def deezer_search(query):
    kinds = (('', 'track'), ('/album', 'album'), ('/artist', 'artist'), ('/playlist', 'playlist'))
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix='MegaNexusMusic') as pool:
        answers = list(pool.map(lambda k: _deezer('/search' + k[0], q=query, limit=40), kinds))
    return {kind + 's': _dzs(answer, kind) for (_, kind), answer in zip(kinds, answers)}


def deezer_details(kind, item_id):
    """(its item, its songs, its albums) - an artist's also has their related artists (head['related'])."""
    path = '/%s/%s' % (kind, quote(item_id, safe=''))
    answer = _deezer(path)
    if not isinstance(answer, dict):
        raise MusicError('That page is not there any more.')
    head = _dz(answer, kind) or {'kind': kind, 'id': item_id, 'title': '', 'source': DEEZER}
    if kind == 'artist':
        with ThreadPoolExecutor(max_workers=3, thread_name_prefix='MegaNexusMusic') as pool:
            top, albums, related = pool.map(lambda p: _deezer(path + p[0], limit=p[1]), (('/top', 50), ('/albums', 100), ('/related', 20)))
        head['related'] = _dzs(related, 'artist')
        albums = sorted(_dzs(albums, 'album'), key=lambda a: a['year'], reverse=True)    # the newest first
        for album in albums:
            album['artist'] = album['artist'] or head['title']
        return head, _dzs(top, 'track'), albums
    if kind == 'album':
        head['about'] = ', '.join(g.get('name', '') for g in _data(answer.get('genres')))
        tracks = [_dz(t, 'track', album=answer) for t in _data(answer.get('tracks'))]
    else:
        tracks = _dzs(answer.get('tracks'), 'track')
    return head, [t for t in tracks if t], []


# ---- which catalogue the app shows and searches: Deezer's, Apple Music's or Spotify's ----------
CATALOGUE = 'meganexus_music_catalog'
CATALOGUES = (('deezer', 'Deezer'), ('apple', 'Apple Music'), ('spotify', 'Spotify'))


def catalogues(addon=None, value=None):
    """The catalogues in their order (Settings > Music): the first that can answer is the app's - Spotify only
    with your own Spotify app. ``value``: a new order."""
    import xbmcaddon
    from . import music_meta
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    known = [key for key, _ in CATALOGUES]
    if value is not None:
        if value and value[0] == music_meta.SPOTIFY and not music_meta.spotify_app(addon):
            raise MusicError('Spotify needs your own Spotify app first: API keys > Spotify (its client ID and secret).')
        addon.setSetting(CATALOGUE, ','.join(v for v in value if v in known))
        forget()
    chosen = [v for v in (addon.getSetting(CATALOGUE) or DEEZER).split(',') if v in known]
    return [c for c in dict.fromkeys(chosen + known) if c != music_meta.SPOTIFY or music_meta.spotify_app(addon)]


def catalogue(addon=None, value=None):
    """The catalogue in use: the first of catalogues(); ``value`` puts one first."""
    if value is not None:
        catalogues(addon, [value] + [c for c in catalogues(addon) if c != value])
    return catalogues(addon)[0]


def _first(ask):
    """ask(catalogue) of the first catalogue that answers (the next when one does not)."""
    problem = None
    for name in catalogues():
        try:
            return name, ask(name)
        except MusicError as exc:
            problem = problem or exc
    raise problem or MusicError('No catalogue answered.')


CHART_ROWS = {'deezer': ('Top songs', 'Albums', 'Top artists', 'Top playlists'), 'apple': ('Top songs', 'Top albums'),
              'spotify': ('New releases',)}     # the names of charts()' rows, before they are asked for


def charts():
    """The catalogue's own rows for Home: [(title, entries)] - CHART_ROWS[catalogue()] of them."""
    from . import music_meta
    return _first(lambda name: {music_meta.APPLE: music_meta.apple_home, music_meta.SPOTIFY: music_meta.spotify_home}.get(name, deezer_home)())[1]


def lookup(query):
    """The catalogue's search: {'tracks', 'albums', 'artists', 'playlists'} - the next catalogue when one does not answer."""
    from . import music_meta
    return _first(lambda name: {music_meta.APPLE: music_meta.apple_search, music_meta.SPOTIFY: music_meta.spotify_search}.get(name, deezer_search)(query))[1]


def discography(albums):
    """An artist's albums by kind: (albums, singles and EPs) - each as its catalogue says it is."""
    singles = [a for a in albums if a.get('record') in ('single', 'ep')]
    return [a for a in albums if a not in singles], singles


def deezer_profile(addon=None, value=None):
    """The person's Deezer profile number - set from its address (deezer.com/profile/123) or number."""
    import xbmcaddon
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    if value is None:
        return addon.getSetting(PROFILE) or ''
    found = re.search(r'(?:profile/|user/|^)(\d{3,})\b', str(value).strip())
    if value and not found:
        raise MusicError('That is not a Deezer profile (deezer.com/profile/…).')
    number = found.group(1) if found else ''
    if number and not isinstance(_deezer('/user/%s' % number), dict):
        raise MusicError('Deezer has no profile %s.' % number)
    addon.setSetting(PROFILE, number)
    return number


def deezer_mine(number):
    """The profile's public music: [(title, entries)] - its favourite songs, albums, artists and playlists."""
    who = _deezer('/user/%s' % number) or {}
    name = who.get('name') or 'Deezer'
    parts = (('/tracks', 'track', 'Favourite songs'), ('/albums', 'album', 'Favourite albums'),
             ('/artists', 'artist', 'Favourite artists'), ('/playlists', 'playlist', 'Playlists'))
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix='MegaNexusMusic') as pool:
        answers = list(pool.map(lambda p: _deezer('/user/%s%s' % (number, p[0]), limit=100), parts))
    return [('%s · %s' % (name, title), _dzs(answer, kind)) for (_, kind, title), answer in zip(parts, answers)]


def picture(entry):
    """An album's cover or an artist's photo for an entry without one - the first Deezer match whose
    name is the same (never a nearly one); '' when there is none. Kept in memory."""
    kind = entry.get('kind')
    if kind not in ('album', 'artist') or not entry.get('title'):
        return ''
    key = (kind, _plain(entry['title']), _plain(entry.get('artist')))
    if key in _pictures:
        return _pictures[key]
    query = entry['title'] if kind == 'artist' else '%s %s' % (entry.get('artist') or '', entry['title'])
    found = ''
    try:
        answer = _get_json(PICTURES % (kind, urlencode({'q': query.strip(), 'limit': 5}))) or {}
        for hit in answer.get('data') or ():
            name = hit.get('name') if kind == 'artist' else hit.get('title')
            if _plain(name) != _plain(entry['title']):
                continue
            if kind == 'album' and entry.get('artist') and _plain((hit.get('artist') or {}).get('name')).split(' ')[:1] != _plain(entry['artist']).split(' ')[:1]:
                continue
            found = hit.get('picture_xl' if kind == 'artist' else 'cover_xl') or ''
            break
    except MusicError:
        return ''
    _pictures[key] = found
    return found


def artists(albums):
    """The artists of your folders' albums (an artist page: their albums - their discography)."""
    names = OrderedDict()
    for album in albums:
        if album.get('artist'):
            names.setdefault(album['artist'], album)
    return [{'kind': 'artist', 'source': 'local', 'id': 'artist:' + name, 'title': name, 'artist': '', 'picture': '',
             'year': '', 'isrc': '', 'seconds': 0, 'stream': '', 'count': 0, 'about': ''} for name in names]
