# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Local airing calendar for series the user has actually started."""
from datetime import date,datetime,timedelta,timezone
import json
import os
import threading
import time
from .meganexus.paths import profile_path
from .meganexus.paths import WATCHED_PERCENT
from . import simkl_watched
from .meganexus import progress_db

_LOCK=threading.RLock()
_MEM={}

def _path():return os.path.join(profile_path(),'meganexus_airing.json')
def _read():
    try:
        path=_path();stamp=os.stat(path).st_mtime_ns
        with _LOCK:
            if _MEM.get('key')==(path,stamp):return dict(_MEM['data'])
            with open(path,encoding='utf-8') as stream:data=json.load(stream)
            if not isinstance(data,dict):return {}
            _MEM.update(key=(path,stamp),data=data)
            return dict(data)
    except (OSError,ValueError):return {}

KEPT_FOR = 3600        # 9.0.7: s a series' kept episodes stand before augment asks again (and remember writes again)


def _same(kept,meta):
    try:return json.dumps(kept,sort_keys=True,ensure_ascii=False)==json.dumps(meta,sort_keys=True,ensure_ascii=False)
    except (TypeError,ValueError):return False


def remember(meta,provider_id=''):
    """A series' episodes kept for its Next episode card (backend_api.metadata, every series).

    9.0.7: the same answer again within KEPT_FOR is not written again. Every title page of a
    series and every Continue Watching card it completed wrote the whole file anew - on the Cube
    2.4 MB: 76 ms to read it, 303 ms to write it out (indented), a copy beside it and an fsync,
    under the lock every other one waited on - for an answer the file already held. A changed
    answer, another add-on's, or one older than KEPT_FOR (augment asks again then, and the time
    it was kept must move on) is written as before."""
    if meta.get('type') not in ('series','tv','show','anime') or not meta.get('id'):return
    meta={k:v for k,v in meta.items() if k in ('id','type','name','title','poster','background','logo','description','videos')}
    meta['videos']=[{k:v for k,v in e.items() if k in ('id','season','episode','released','releaseDate','air_date','firstAired','overview')} for e in meta.get('videos',[]) if isinstance(e,dict)]
    with _LOCK:
        data=_read();kept=data.get(str(meta['id'])) or {}
        if kept.get('provider')==provider_id and time.time()-float(kept.get('saved') or 0)<KEPT_FOR and _same(kept.get('meta'),meta):
            return
        data[str(meta['id'])]={'provider':provider_id,'saved':time.time(),'meta':meta}
        data=dict(sorted(data.items(),key=lambda pair:pair[1].get('saved',0),reverse=True)[:100])
        path=_path();os.makedirs(os.path.dirname(path),exist_ok=True)
        from .meganexus.json_files import write_json
        write_json(path,data)

def release_day(episode):
    value=episode.get('released') or episode.get('releaseDate') or episode.get('air_date') or episode.get('firstAired')
    if not value:return None
    try:
        if len(str(value))==10:return date.fromisoformat(value)
        stamp=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
        return stamp.astimezone().date()
    except (ValueError,TypeError):return None

def number(value):
    try:return int(value)
    except (ValueError,TypeError):return 0

NEW_SEASON_AHEAD = 7  # 9.0.9: days ahead a new season's first episode gets its card (the Nuvio apps' window)
NEWS_FOR = 60         # 9.0.9: days an episode out since the show was last watched stands at its own day


def _midnight(day):
    return time.mktime(day.timetuple())


def coming(episode,season,today):
    """9.0.9: an episode not out yet that has its card (with "Show unaired next episodes"), as in the
    Nuvio apps: the same season's next on any day it has, a new season's first within
    NEW_SEASON_AHEAD days. Only tomorrow's came - Chicago P.D.'s next one, two days ahead, had no
    card here and one in Nuvio. No day known: none."""
    day=release_day(episode)
    if not day or day<=today:return False
    return number(episode.get('season'))==season or (day-today).days<=NEW_SEASON_AHEAD


def coming_banner(day,today):
    """'Tomorrow • New episode', 'Friday • New episode' (this week), '14 Nov • New episode'."""
    from .release_info import WEEKDAYS,short_date
    days=(day-today).days
    when='Tomorrow' if days==1 else WEEKDAYS[day.weekday()].capitalize() if days<7 else short_date(day,today)
    return when+' • New episode'


def next_card(meta,history,entry,today=None):
    from .progress_model import timestamp
    today=today or date.today();base=(number(history.get('season')),number(history.get('episode')))
    seen_at=timestamp(history.get('updated_at'))
    try:last_watched=datetime.fromtimestamp(seen_at).date() if seen_at else today
    except (ValueError,TypeError,OverflowError,OSError):last_watched=today
    def watched_scope(episode):
        if '%s:%s'%(episode.get('season'),episode.get('episode')) in entry.get('episodes',[]):return True
        scope=entry.get('watched') or str(episode.get('season')) in entry.get('seasons',[])
        released=release_day(episode)
        # "All aired episodes watched" must not swallow a later season release.
        return bool(scope and (not released or released<=last_watched))
    episodes=sorted((e for e in meta.get('videos',[]) if isinstance(e,dict) and e.get('id') and number(e.get('season'))>0),
                    key=lambda e:(number(e.get('season')),number(e.get('episode'))))
    eligible=[e for e in episodes if (number(e.get('season')),number(e.get('episode')))>base and not watched_scope(e)]
    if float(history.get('percent') or 0)>=WATCHED_PERCENT or history.get('event_type')=='watched':
        # 9.0.9: the first episode with a day after the one watched - out, or coming. Tomorrow's
        # went before one already out: S1E5 "Tomorrow" while S1E4 waited unwatched.
        selected=next((e for e in eligible if release_day(e)),None)
        if selected and not (release_day(selected)<=today or coming(selected,base[0],today)):selected=None
    else:
        # half seen: only the banner on its resume card, for an episode out tomorrow (as before)
        selected=next((e for e in eligible if release_day(e)==today+timedelta(days=1)),None)
    if not selected:return None
    out=release_day(selected);ahead=out>today
    target={'media_type':'series','canonical_id':history['canonical_id'],'video_id':selected['id'],
            'season':selected['season'],'episode':selected['episode'],'resume_seconds':0}
    if ahead:target['details_view']=True
    # 9.0.9: where the card stands in Continue Watching (augment) - as in the Nuvio apps, by when the
    # show was last watched; an episode out since then (in the last NEWS_FOR days) by its own day
    news=not ahead and _midnight(out)>seen_at and (today-out).days<NEWS_FOR
    return {'title':meta.get('name') or history.get('title') or '',
            'poster':meta.get('poster') or history.get('poster') or '',
            'fanart':meta.get('background') or history.get('background') or '',
            'clearlogo':meta.get('logo') or '', 'plot':selected.get('overview') or meta.get('description') or '',
            'subtitle':'S%s • E%s'%(selected['season'],selected['episode']),
            # 8.1.3: the whole line - kind, year, the episode - not "Series" alone
            'meta_line':'  |  '.join(x for x in ('Series',str(meta.get('year') or meta.get('releaseInfo') or '')[:4],
                                                    'S%s · E%s'%(selected['season'],selected['episode'])) if x),
            'target':target,'percent_value':0,
            'airing_banner':coming_banner(out,today) if ahead else 'Next episode',
            # 'tomorrow': not out yet (9.0.9: any day coming lets through; the name is from tomorrow's only)
            'tomorrow':'1' if ahead else '', 'shape':'poster','continue_card':'next',
            'sort_time':_midnight(out) if news else seen_at}

def stale(card,played):
    """7.0.47 (GitHub issue #11): a series' resume card for another episode than the one
    played last, and older than it - e.g. an old S01E01 progress from the cloud after
    S01E03 was watched to the end. The next episode's card takes its place; an episode
    played again later is newer and stays.

    9.0.1 (GitHub issue #28): only an EARLIER episode is out of date. Any other one was:
    S01E04 stopped half way, with S01E03 dated after it (a sync), became the "Next
    episode" S01E04 - from the start, its 22 minutes lost."""
    from .progress_model import timestamp
    if not played or card.get('continue_card')!='resume':return False
    target=card.get('target') or {}
    card_ep=(number(target.get('season')),number(target.get('episode')))
    played_ep=(number(played.get('season')),number(played.get('episode')))
    return card_ep<played_ep and timestamp(played.get('updated_at'))>timestamp(card.get('progress_updated'))


SILENCE = 900.0        # 8.1.2: s a metadata provider is left alone after it stops answering
_QUIET = {}            # provider id -> when it last failed to answer


def _resting(source):
    """This provider stopped answering a moment ago; do not queue up behind it again.

    8.1.2: four lookups at a three-second timeout is twelve seconds, and they were tried
    again on every Home paint - "next episodes 10788 ms", over and over, on a box whose
    drawing thread the rest of the interface is waiting for. When the provider answers
    nothing it will not answer the next four either; asked again in a quarter of an hour.
    Everything already known still comes from the cache, so the rows are not emptied -
    they just stop growing until it is back.
    """
    until = _QUIET.get(str(source.get('id') or ''))
    return bool(until) and time.time() < until


def _silent(source):
    _QUIET[str(source.get('id') or '')] = time.time() + SILENCE


def _answered(source):
    _QUIET.pop(str(source.get('id') or ''), None)


AT_ONCE = 4            # 8.1.2: series asked for at most per paint; 9.0.7: all at the same time
ASK_TIMEOUT = 3        # s one series' details may take (backend_api.metadata's whole budget)


def _ask_all(due, ask, source, stopped):
    """{series id: its details} for the series due - 9.0.7: asked at the same time.

    One after another they were the "next episodes 7492 ms" of the Cube (9602 ms with no add-on
    failing at all): each series waited for the one before it - its add-on's answer, then the
    rewrite of meganexus_airing.json. Asked together, the wait is the slowest one, and never more
    than AT_ONCE requests are out. The rest (_silent) follows their answers together: any series
    answered is an add-on that answers; every one failing is one that does not."""
    if not due or stopped():
        return {}
    from concurrent.futures import ThreadPoolExecutor
    found, failed = {}, 0
    with ThreadPoolExecutor(max_workers=len(due), thread_name_prefix='MegaNexusNextUp') as pool:
        jobs = [(mid, pool.submit(ask, mid)) for mid in due]
        for mid, job in jobs:
            try:
                found[mid] = job.result()
            except Exception:
                failed += 1
    if found:
        _answered(source)
    elif failed:
        _silent(source)
    return found


def augment(rows,refresh=False,stopped=lambda:False):
    from . import backend_api
    from . import continue_rules
    from . import metadata_providers
    # 9.0.7: the add-on asked is metadata_providers.first() - the one you chose while it is on, else
    # the first one on - as for every title page; backend_api.provider() went by an add-on's name
    # and kept a chosen one that was switched off, which then took the rest for the one asked
    source=metadata_providers.first() or {};cache=_read();seen=set();history=[]
    on={p['id'] for p in metadata_providers.enabled()}   # any of them answers for its series
    removed=continue_rules.snapshot();unaired=continue_rules.show_unaired()
    for row in progress_db.list_recent_items(limit=500,media_types=('series','tv','show','anime')):
        mid=row['canonical_id']
        # GitHub issue #31: one series under two ids (IMDb, TMDB, TVDB) is one series - its latest
        # episode counts; the older id's row made a second card that came and went
        keys=progress_db.title_keys(dict(row,media_type='series'))
        if not keys&seen and row.get('episode'):
            seen|=keys
            # 6.0.35 (issue #7): only series watched in the period, not removed.
            if continue_rules.recent_enough(row.get('updated_at')) and not continue_rules.hidden('series',mid,row.get('updated_at'),removed,continue_rules.ids_of(row)):
                history.append(row)
        if len(history)>=50:break
    states=simkl_watched.snapshot();cards=[];due=[]
    last={}                                          # the episode played last, per series - under each of its ids
    for row in history:
        for found in progress_db.title_keys(dict(row,media_type='series')):last[found]=row

    def played_last(target):
        return next((last[found] for found in progress_db.title_keys(dict(target,media_type='series')) if found in last),None)
    for row in history:
        mid=row['canonical_id'];saved=cache.get(mid) or {};meta=saved.get('meta') or {}
        # #31: another metadata add-on's episodes stand until this one's have come (the card vanished meanwhile)
        other=saved.get('provider') not in on
        if refresh and source and len(due)<AT_ONCE and not _resting(source) and (not meta or other or time.time()-saved.get('saved',0)>KEPT_FOR):
            due.append(mid)
    # 9.0.7: the ones due asked together (_ask_all); a series not answered keeps its kept episodes
    fresh=_ask_all(due,lambda mid:backend_api.metadata('series',mid,timeout=ASK_TIMEOUT),source,stopped)
    for row in history:
        if stopped():return rows
        mid=row['canonical_id'];meta=fresh.get(mid) or (cache.get(mid) or {}).get('meta') or {}
        if meta:
            card=next_card(meta,row,simkl_watched.state(states,'series',mid))
            if card:cards.append(card)
    output=[dict(row) for row in rows if row.get('target')]
    upcoming=[];next_episodes=[]
    for card in cards:
        if card.get('tomorrow') and not unaired:continue  # "Show unaired next episodes" off
        keys=progress_db.title_keys(dict(card['target'],media_type='series'))
        existing=next((r for r in output if r.get('target') and keys&progress_db.title_keys(dict(r['target'],media_type=r['target'].get('media_type') or 'series'))),None)
        if existing and stale(existing,played_last(card['target'])):
            output[output.index(existing)]=card   # 7.0.47 (issue #11): the next episode, not an older one
        elif existing:
            if card.get('tomorrow'):
                existing.update(airing_banner=card['airing_banner'],tomorrow='1')
        elif card.get('tomorrow'):upcoming.append(card)
        else:next_episodes.append(card)
    # 7.0.47 (issue #11): an older episode's progress never stands for a series watched
    # further - also when no next episode replaced it (the last one was watched)
    output=[row for row in output if not (row.get('target') and stale(row,played_last(row['target'])))]
    output.extend(upcoming+next_episodes)
    # 9.0.9: one order for every card, as in the Nuvio apps - newest first (placed). The next episodes
    # came after every resume, at the end of the row however fresh. An airing banner still never
    # displaces the film/episode just stopped: that one is the newest.
    output.sort(key=placed,reverse=True)
    return output if output or any(row.get('target') for row in rows) else rows


def placed(card):
    """When a card's title was last watched: a resume's stop; a next episode's sort_time (next_card)."""
    from .progress_model import timestamp
    return timestamp(card.get('sort_time') if card.get('continue_card')=='next' else card.get('progress_updated'))
