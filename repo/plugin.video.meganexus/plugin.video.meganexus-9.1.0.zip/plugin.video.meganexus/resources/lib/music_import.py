# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Playlists brought in from elsewhere (9.0.6): your playlists of Spotify, Deezer or YouTube by their
link, or of any service by a file - CSV (Spotify's whole library through Exportify, TuneMyMusic, Soundiiz:
title, artist, album, length, ISRC) or M3U. Kept for this profile (music_playlists.json) and shown on the
Music app's Home; their songs play as a catalogue's do - from your sources, your cloud or YouTube, the
very same recording (by its ISRC when the list has it) - and a YouTube playlist's songs are its videos.
"""
import csv
import io
import json
import os
import re
import uuid
from urllib.parse import parse_qs, urlsplit

from . import music

SOURCE = 'import'
FILE = 'music_playlists.json'
MAX_SONGS = 2000


def _path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), FILE)


def playlists():
    """[playlist] - each with its songs ('tracks'), the newest first."""
    try:
        with open(_path(), encoding='utf-8') as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return []
    return [p for p in saved if isinstance(p, dict) and p.get('id')] if isinstance(saved, list) else []


def _save(items):
    path = _path()
    with open(path + '.part', 'w', encoding='utf-8') as handle:
        json.dump(items, handle, ensure_ascii=False)
    os.replace(path + '.part', path)


def songs(playlist_id):
    return next((p.get('tracks') or [] for p in playlists() if p['id'] == playlist_id), [])


def remove(playlist_id):
    _save([p for p in playlists() if p['id'] != playlist_id])


def keep(title, tracks, origin):
    """The playlist kept (the newest first); returns it without its songs."""
    tracks = [t for t in tracks if t.get('title')][:MAX_SONGS]
    if not tracks:
        raise music.MusicError('That playlist has no songs that can be read.')
    entry = {'kind': 'playlist', 'source': SOURCE, 'id': uuid.uuid4().hex[:12], 'title': title or 'Playlist', 'artist': origin,
             'picture': next((t['picture'] for t in tracks if t.get('picture')), ''), 'year': '', 'isrc': '', 'seconds': 0,
             'stream': '', 'count': len(tracks), 'about': '%d songs from %s' % (len(tracks), origin)}
    _save([dict(entry, tracks=tracks)] + playlists())
    return entry


def _song(title, artist, album='', seconds=0, isrc='', picture=''):
    return {'kind': 'track', 'source': SOURCE, 'id': uuid.uuid4().hex[:12], 'title': title.strip(), 'artist': artist.strip(),
            'album': album.strip(), 'picture': picture, 'year': '', 'isrc': isrc.strip().upper(), 'seconds': int(seconds or 0),
            'stream': '', 'count': 0, 'about': ''}


# ---- by its link ---------------------------------------------------------------------------------------
def from_link(link):
    """A playlist of Spotify (with your Spotify app), Deezer or YouTube by its link - kept."""
    link = str(link or '').strip()
    found = re.search(r'(?:open\.spotify\.com/(?:[\w-]+/)?playlist/|spotify:playlist:)(\w+)', link)
    if found:
        from . import music_meta
        head, tracks, _ = music_meta.spotify_details('playlist', found.group(1))
        return keep(head['title'], tracks, 'Spotify')
    if 'link.deezer.com' in link or 'deezer.page.link' in link:
        from urllib.request import Request, urlopen
        try:
            with urlopen(Request(link, headers={'User-Agent': music.AGENT}), timeout=music.TIMEOUT) as answer:
                link = answer.geturl()                      # Deezer's share link leads to the playlist's own
        except Exception:
            raise music.MusicError('That Deezer link did not open.')
    found = re.search(r'deezer\.com/(?:[a-z]{2}/)?playlist/(\d+)', link)
    if found:
        head, tracks, _ = music.deezer_details('playlist', found.group(1))
        return keep(head['title'], tracks, 'Deezer')
    found = (parse_qs(urlsplit(link).query).get('list') or [''])[0] if 'youtube.com' in link or 'youtu.be' in link else ''
    if found:
        return keep(*_youtube(found), 'YouTube')
    if 'music.apple.com' in link:
        raise music.MusicError('Apple Music lets no one else read its playlists - export it as a CSV file '
                               '(TuneMyMusic or Soundiiz) and import the file.')
    raise music.MusicError('That is not a playlist link of Spotify, Deezer or YouTube.')


def _youtube(list_id):
    """A YouTube playlist: (its name, its videos as songs - each plays as itself)."""
    from . import youtube
    answer = youtube._ask('browse', {'browseId': 'VL' + list_id})
    name = ((answer or {}).get('metadata') or {}).get('playlistMetadataRenderer', {}).get('title') or 'YouTube playlist'
    tracks = []
    for video in youtube._pages('browse', answer, 20):
        title = video.get('title') or ''
        if re.search(r'\s+[-–]\s+', title):                 # "Artist - Song (Official Video)"
            artist, rest = re.split(r'\s+[-–]\s+', title, maxsplit=1)
        else:                                                # the artist's own channel ("Artist - Topic")
            artist, rest = re.sub(r'\s+-\s+Topic$', '', video.get('channel') or ''), title
        song = _song(re.sub(r'\s*[\(\[][^\)\]]*(?:official|video|audio|lyric)[^\)\]]*[\)\]]', '', rest, flags=re.I), artist,
                     seconds=music._minutes(video.get('length')), picture=video.get('picture') or '')
        tracks.append(dict(song, source='youtube', id=video['id'], stream=music.YOUTUBE_PLAY % video['id']))
    return name, tracks


# ---- by a file -------------------------------------------------------------------------------------------
_COLUMNS = {'title': ('track name', 'track', 'title', 'song', 'name', 'track title'),
            'artist': ('artist name(s)', 'artist name', 'artist', 'artists'),
            'album': ('album name', 'album'),
            'ms': ('duration (ms)', 'track duration (ms)', 'duration_ms'),
            'isrc': ('isrc',)}


def from_file(path):
    """A CSV (a header row naming its columns - Exportify's, TuneMyMusic's, Soundiiz's) or an M3U - kept."""
    import xbmcvfs
    handle = xbmcvfs.File(path)
    try:
        text = handle.read()
    finally:
        handle.close()
    name = re.sub(r'\.[^.]+$', '', path.replace('\\', '/').rsplit('/', 1)[-1]) or 'Playlist'
    if path.lower().endswith(('.m3u', '.m3u8')) or text.lstrip().startswith('#EXTM3U'):
        return keep(name, _m3u(text), 'a file')
    return keep(name, _csv(text), 'a file')


def _csv(text):
    rows = list(csv.reader(io.StringIO(text.lstrip('﻿'))))
    if len(rows) < 2:
        return []
    header = [h.strip().lower() for h in rows[0]]
    at = {key: next((header.index(n) for n in names if n in header), None) for key, names in _COLUMNS.items()}
    if at['title'] is None or at['artist'] is None:
        raise music.MusicError('The file has no title and artist columns.')
    cell = lambda row, key: row[at[key]] if at[key] is not None and at[key] < len(row) else ''
    out = []
    for row in rows[1:]:
        ms = cell(row, 'ms')
        out.append(_song(cell(row, 'title'), cell(row, 'artist').split(';')[0].split(',')[0], cell(row, 'album'),
                         int(ms) // 1000 if ms.isdigit() else 0, cell(row, 'isrc')))
    return out


def _m3u(text):
    out = []
    for line in text.splitlines():
        found = re.match(r'#EXTINF:(-?\d+)[^,]*,(.*)$', line.strip())
        if found and ' - ' in found.group(2):
            artist, title = found.group(2).split(' - ', 1)
            out.append(_song(title, artist, seconds=max(0, int(found.group(1)))))
    return out
