# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Music app's other catalogues (9.0.6): Apple Music's and Spotify's - what music there is, its
pictures and pages; the songs play from the person's sources (music.playable), as Deezer's do.

* Apple Music: Apple's public iTunes search and lookup and its charts (no key), in the person's
  country's store.
* Spotify: Spotify's Web API with the person's own Spotify app (a free developer app: its client
  ID and secret, API keys > Spotify) - search, albums, artists, playlists and new releases.
"""
import base64
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

from . import music

APPLE, SPOTIFY = 'apple', 'spotify'
ITUNES = 'https://itunes.apple.com'
CHARTS = 'https://rss.marketingtools.apple.com/api/v2/%s/music/most-played/50/%s.json'
SPOTIFY_API = 'https://api.spotify.com/v1'
SPOTIFY_TOKEN = 'https://accounts.spotify.com/api/token'
SPOTIFY_KEY = 'meganexus_spotify_app'      # API keys > Spotify: client ID:client secret
_token = {'value': '', 'until': 0.0, 'app': ''}
_token_lock = threading.Lock()


def _entry(kind, source, item_id, title, artist='', picture='', **more):
    found = {'kind': kind, 'source': source, 'id': str(item_id), 'title': title or '', 'artist': artist or '', 'album': '',
             'picture': picture or '', 'year': '', 'isrc': '', 'seconds': 0, 'stream': '', 'count': 0, 'about': ''}
    found.update(more)
    return found if found['title'] and found['id'] else None


def _country():
    """The person's country, as Deezer sees it (the stores and charts are per country)."""
    try:
        return str((music._deezer('/infos') or {}).get('country_iso') or 'us').lower()
    except music.MusicError:
        return 'us'


# ---- Apple Music --------------------------------------------------------------------------------
def _art(url, size=600):
    return str(url or '').replace('100x100bb', '%dx%dbb' % (size, size)).replace('60x60bb', '%dx%dbb' % (size, size))


def _apple_get(path, **params):
    return music._get_cached('%s%s?%s' % (ITUNES, path, urlencode(dict(params, country=params.pop('country', None) or _country()))))


def _apple_lookup(item_id, entity, limit):
    """A lookup's results - from the US store when the person's country's has only the item itself
    (its songs are not sold there)."""
    found = (_apple_get('/lookup', id=item_id, entity=entity, limit=limit) or {}).get('results') or []
    if len(found) < 2:
        found = (_apple_get('/lookup', id=item_id, entity=entity, limit=limit, country='us') or {}).get('results') or found
    return found


def _apple(obj):
    kind = obj.get('wrapperType') or obj.get('kind')
    if kind == 'track' or obj.get('kind') == 'song' or kind == 'songs':
        return _entry('track', APPLE, obj.get('trackId') or obj.get('id'), obj.get('trackName') or obj.get('name'),
                      obj.get('artistName'), _art(obj.get('artworkUrl100')), album=obj.get('collectionName') or '',
                      thumb=_art(obj.get('artworkUrl100'), 300),
                      seconds=int(obj.get('trackTimeMillis') or 0) // 1000, year=str(obj.get('releaseDate') or '')[:4])
    if kind == 'collection' or kind == 'albums':
        name = obj.get('collectionName') or obj.get('name') or ''
        return _entry('album', APPLE, obj.get('collectionId') or obj.get('id'), name, obj.get('artistName'), _art(obj.get('artworkUrl100')),
                      thumb=_art(obj.get('artworkUrl100'), 300),
                      year=str(obj.get('releaseDate') or '')[:4], count=int(obj.get('trackCount') or 0),
                      record='single' if name.endswith((' - Single', ' - EP')) else 'album')
    if kind == 'artist':
        return _entry('artist', APPLE, obj.get('artistId'), obj.get('artistName'), obj.get('primaryGenreName') or '')
    return None


def _apples(values):
    return [e for e in (_apple(v) for v in values or () if isinstance(v, dict)) if e]


def apple_home():
    country = _country()

    def chart(kind):
        try:
            return music._get_cached(CHARTS % (country, kind)) or {}
        except music.MusicError:
            return music._get_cached(CHARTS % ('us', kind)) or {}
    # 9.0.7: both charts asked at once - each chart row waited for both answers, one after the other (a second each)
    kinds = (('Top songs', 'songs'), ('Top albums', 'albums'))
    with ThreadPoolExecutor(max_workers=len(kinds), thread_name_prefix='MegaNexusMusic') as pool:
        answers = list(pool.map(chart, [kind for _, kind in kinds]))
    return [(title, [dict(e, kind='track' if kind == 'songs' else 'album') for e in
                     (_apple(dict(v, kind=kind)) for v in (answer.get('feed') or {}).get('results') or ()) if e])
            for (title, kind), answer in zip(kinds, answers)]


def apple_search(query):
    kinds = (('song', 'tracks'), ('album', 'albums'), ('musicArtist', 'artists'))
    with ThreadPoolExecutor(max_workers=3, thread_name_prefix='MegaNexusMusic') as pool:
        answers = list(pool.map(lambda k: _apple_get('/search', term=query, media='music', entity=k[0], limit=40), kinds))
    found = {key: _apples((answer or {}).get('results')) for (_, key), answer in zip(kinds, answers)}
    found['playlists'] = []
    return found


def apple_details(kind, item_id):
    if kind == 'album':
        results = _apple_lookup(item_id, 'song', 200)
        head = next((e for e in _apples(results) if e['kind'] == 'album'), None)
        if head is None:
            raise music.MusicError('That page is not there any more.')
        tracks = [dict(t, picture=t['picture'] or head['picture']) for t in _apples(results) if t['kind'] == 'track']
        return head, tracks, []
    with ThreadPoolExecutor(max_workers=2, thread_name_prefix='MegaNexusMusic') as pool:
        songs, albums = pool.map(lambda e: _apple_lookup(item_id, *e), (('song', 50), ('album', 100)))
    head = next((e for e in _apples(songs) if e['kind'] == 'artist'), None)
    if head is None:
        raise music.MusicError('That page is not there any more.')
    head['picture'] = music.picture(head)        # Apple's catalogue has no artists' photos
    return head, [e for e in _apples(songs) if e['kind'] == 'track'], sorted((e for e in _apples(albums) if e['kind'] == 'album'),
                                                                          key=lambda a: a['year'], reverse=True)


# ---- Spotify ----------------------------------------------------------------------------------
def spotify_app(addon=None):
    import xbmcaddon
    value = ((addon or xbmcaddon.Addon('plugin.video.meganexus')).getSetting(SPOTIFY_KEY) or '').strip()
    return value if ':' in value else ''


def _spotify_token(app):
    """A client-credentials token of the person's Spotify app (kept until it is nearly due)."""
    with _token_lock:
        if _token['app'] == app and _token['until'] > time.monotonic():
            return _token['value']
        login = base64.b64encode(app.strip().encode('utf-8')).decode('ascii')
        request = Request(SPOTIFY_TOKEN, data=b'grant_type=client_credentials',
                          headers={'Authorization': 'Basic ' + login, 'Content-Type': 'application/x-www-form-urlencoded',
                                   'User-Agent': music.AGENT})
        try:
            with urlopen(request, timeout=music.TIMEOUT) as response:
                import json
                answer = json.loads(response.read(65536).decode('utf-8'))
        except Exception as exc:
            raise music.MusicError('Spotify did not accept your app (%s) - check its client ID and secret.'
                                   % (getattr(exc, 'code', None) or type(exc).__name__))
        _token.update(value=answer.get('access_token') or '', until=time.monotonic() + int(answer.get('expires_in') or 3600) - 120, app=app)
        return _token['value']


def check_spotify(app):
    """Raises MusicError when Spotify does not take the app (API keys checks it on saving)."""
    _spotify_token(app)


def _spotify_get(path, **params):
    app = spotify_app()
    if not app:
        raise music.MusicError('Spotify needs your Spotify app - API keys > Spotify.')
    params.setdefault('market', _country().upper())
    return music._get_cached(SPOTIFY_API + path + '?' + urlencode(params),
                             headers={'Authorization': 'Bearer ' + _spotify_token(app)})


def _picture(images, card=False):
    """The biggest of Spotify's pictures - or (``card``) the smallest one still a card's size."""
    images = [i for i in images or () if isinstance(i, dict) and i.get('url')]
    if card:
        fit = [i for i in images if (i.get('width') or 0) >= 250]
        images = [min(fit, key=lambda i: i.get('width') or 0)] if fit else images
    return max(images, key=lambda i: i.get('width') or 0)['url'] if images else ''


def _spotify(obj, kind=None, album=None):
    found = _spotify_entry(obj, kind, album)
    if found:
        found['thumb'] = _picture((album or obj.get('album') or {}).get('images') if found['kind'] == 'track' else obj.get('images'), card=True)
    return found


def _spotify_entry(obj, kind=None, album=None):
    if not isinstance(obj, dict) or not obj.get('id'):
        return None
    kind = kind or obj.get('type')
    artists = ', '.join(a.get('name', '') for a in obj.get('artists') or () if isinstance(a, dict))
    if kind == 'track':
        album = album or obj.get('album') or {}
        return _entry('track', SPOTIFY, obj['id'], obj.get('name'), artists, _picture(album.get('images')),
                      album=album.get('name') or '', seconds=int(obj.get('duration_ms') or 0) // 1000,
                      isrc=(obj.get('external_ids') or {}).get('isrc') or '')
    if kind == 'album':
        return _entry('album', SPOTIFY, obj['id'], obj.get('name'), artists, _picture(obj.get('images')),
                      year=str(obj.get('release_date') or '')[:4], count=int(obj.get('total_tracks') or 0),
                      record=obj.get('album_type') or 'album')
    if kind == 'artist':
        return _entry('artist', SPOTIFY, obj['id'], obj.get('name'), ', '.join((obj.get('genres') or [])[:2]), _picture(obj.get('images')))
    if kind == 'playlist':
        return _entry('playlist', SPOTIFY, obj['id'], obj.get('name'), (obj.get('owner') or {}).get('display_name') or '',
                      _picture(obj.get('images')), count=int((obj.get('tracks') or {}).get('total') or 0),
                      about=obj.get('description') or '')
    return None


def _spotifies(values, kind=None):
    return [e for e in (_spotify(v, kind) for v in values or ()) if e]


def spotify_home():
    answer = _spotify_get('/browse/new-releases', limit=50) or {}
    return [('New releases', _spotifies((answer.get('albums') or {}).get('items'), 'album'))]


def spotify_search(query):
    answer = _spotify_get('/search', q=query, type='track,album,artist,playlist', limit=20) or {}
    return {kind + 's': _spotifies((answer.get(kind + 's') or {}).get('items'), kind) for kind in ('track', 'album', 'artist', 'playlist')}


def spotify_details(kind, item_id):
    path = '/%ss/%s' % (kind, quote(item_id, safe=''))
    if kind == 'artist':
        with ThreadPoolExecutor(max_workers=3, thread_name_prefix='MegaNexusMusic') as pool:
            head, top, albums = pool.map(lambda p: _spotify_get(path + p[0], **p[1]) or {},
                                         (('', {}), ('/top-tracks', {}), ('/albums', {'include_groups': 'album,single', 'limit': 50})))
        found = _spotify(head, 'artist')
        if found is None:
            raise music.MusicError('That page is not there any more.')
        return found, _spotifies(top.get('tracks'), 'track'), _spotifies(albums.get('items'), 'album')
    answer = _spotify_get(path) or {}
    head = _spotify(answer, kind)
    if head is None:
        raise music.MusicError('That page is not there any more.')
    items = (answer.get('tracks') or {}).get('items') or []
    if kind == 'album':
        tracks = [_spotify(t, 'track', album=answer) for t in items]
    else:
        tracks = [_spotify(t.get('track') or t.get('item'), 'track') for t in items if isinstance(t, dict)]
    return head, [t for t in tracks if t], []


def spotify_isrc(track_id):
    return ((_spotify_get('/tracks/%s' % quote(track_id, safe='')) or {}).get('external_ids') or {}).get('isrc') or ''
