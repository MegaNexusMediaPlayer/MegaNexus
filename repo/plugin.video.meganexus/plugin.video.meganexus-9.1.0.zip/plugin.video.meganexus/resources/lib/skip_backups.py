# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""8.1.5: the second sources behind the first ones.

SkipDB (skipdb.tv) - open, crowdsourced intro / recap / outro / preview times, no key:
asked for the parts TheIntroDB does not know. TVmaze (tvmaze.com) - free, no key: the
next episode when the title's own metadata (TMDB through the metadata add-on) does not
name one. Both only read; both are asked once per playback, in the service.
"""
import json
import math
import re
import time
from datetime import date
from urllib.parse import urlencode
from urllib.request import Request, urlopen

SKIPDB = 'https://api.skipdb.tv/api/segments'
TVMAZE = 'https://api.tvmaze.com'
TIMEOUT = 4
SURE = 0.5                          # SkipDB's confidence below this is not used
_KINDS = {'intro': 'intro', 'recap': 'recap', 'outro': 'credits', 'preview': 'preview'}
_BACKOFF = {'skipdb': 0.0, 'tvmaze': 0.0}
_SHOWS = {}                         # imdb id -> TVmaze episodes (this run)
SHOWS_KEPT = 8                      # 9.0.8: the shows kept - the service runs for days


def _agent():
    try:
        import xbmcaddon
        return 'MegaNexus/' + xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('version')
    except Exception:
        return 'MegaNexus'


def _get(url, service):
    if time.monotonic() < _BACKOFF[service]:
        return None
    try:
        with urlopen(Request(url, headers={'Accept': 'application/json', 'User-Agent': _agent()}),
                     timeout=TIMEOUT) as reply:
            return json.loads(reply.read(4 * 1024 * 1024).decode('utf-8'))
    except Exception as exc:
        if getattr(exc, 'code', None) == 429:
            _BACKOFF[service] = time.monotonic() + 300
        return None


def _imdb(context):
    value = str(context.get('imdb_id') or context.get('canonical_id') or '').split(':')[0]
    return value if re.fullmatch(r'tt\d+', value) else ''


def _episode(context):
    try:
        season, episode = int(context.get('season')), int(context.get('episode'))
    except (TypeError, ValueError):
        return None
    return (season, episode) if season >= 1 and episode >= 1 else None


def skipdb(context, duration):
    """SkipDB's parts of this title as skip segments (seconds), or []."""
    imdb = _imdb(context)
    if not imdb or not math.isfinite(duration) or duration <= 0:
        return []
    params = {'imdb_id': imdb, 'duration': int(duration)}
    movie = (context.get('media_type') or context.get('type')) == 'movie'
    if not movie:
        found = _episode(context)
        if not found:
            return []
        params.update(season=found[0], episode=found[1])
    data = _get(SKIPDB + '?' + urlencode(params), 'skipdb')
    parts = (data or {}).get('segments') if isinstance(data, dict) else None
    out = []
    for name, kind in _KINDS.items():
        part = (parts or {}).get(name) if isinstance(parts, dict) else None
        if not isinstance(part, dict):
            continue
        try:
            start = float(part.get('start_ms')) / 1000
            end = float(part.get('end_ms')) / 1000 if part.get('end_ms') is not None else duration - 0.75
            sure = float(part.get('confidence', SURE))
        except (TypeError, ValueError):
            continue
        if sure < SURE or not (math.isfinite(start) and math.isfinite(end)):
            continue
        end = min(end, duration - 0.75)
        if 0 <= start < end and start < duration - 1:
            out.append({'type': kind, 'start': start, 'end': end, 'source': 'SkipDB'})
    return sorted(out, key=lambda row: row['start'])


def tvmaze_next(context, today=None):
    """The next aired episode after this one, from TVmaze ({season, episode, name, still,
    video_id, ...} as title_details.next_episode gives it), or None."""
    imdb = _imdb(context)
    found = _episode(context)
    if not imdb or not found:
        return None
    episodes = _SHOWS.get(imdb)
    if episodes is None:
        show = _get(TVMAZE + '/lookup/shows?' + urlencode({'imdb': imdb}), 'tvmaze')
        show_id = show.get('id') if isinstance(show, dict) else None
        episodes = _get('%s/shows/%s/episodes' % (TVMAZE, show_id), 'tvmaze') if show_id else None
        if not isinstance(episodes, list):
            return None
        # 9.0.8: only what the next episode is told from, for the last SHOWS_KEPT shows - every show's
        # whole answer (each episode's summary, links and pictures) stayed in the service until Kodi closed
        episodes = [{'season': e.get('season'), 'number': e.get('number'), 'airdate': e.get('airdate'),
                     'name': e.get('name'), 'image': {'original': (e.get('image') or {}).get('original')}}
                    for e in episodes if isinstance(e, dict)]
        _SHOWS[imdb] = episodes
        while len(_SHOWS) > SHOWS_KEPT:
            _SHOWS.pop(next(iter(_SHOWS)))
    today = (today or date.today()).isoformat()
    rows = sorted((e for e in episodes if isinstance(e, dict) and e.get('season') and e.get('number')),
                  key=lambda e: (int(e['season']), int(e['number'])))
    after = [e for e in rows if (int(e['season']), int(e['number'])) > found]
    if not after:
        return None
    nxt = after[0]
    if not nxt.get('airdate') or str(nxt['airdate']) > today:
        return None                        # not out yet
    canonical = str(context.get('canonical_id') or imdb).split(':')[0]
    season, number = int(nxt['season']), int(nxt['number'])
    return dict(media_type='series', canonical_id=canonical, video_id='%s:%d:%d' % (canonical, season, number),
                season=season, episode=number, title=str(context.get('show_title') or context.get('title') or ''),
                name=str(nxt.get('name') or ''), still=((nxt.get('image') or {}).get('original') or ''))
