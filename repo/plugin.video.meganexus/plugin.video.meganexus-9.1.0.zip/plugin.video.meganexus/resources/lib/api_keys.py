# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The users' own API keys (7.0): one list for HUB Settings and the phone
setup page. Keys are stored in MegaNexus settings, never sent back to the
phone (only whether one is set) and never written to the log."""
from collections import OrderedDict

KEYS = OrderedDict([
    ('tmdb', {'setting': 'tmdb_api_key', 'name': 'TMDb',
              'purpose': 'TMDB collections (networks, companies, lists) and actor search',
              'url': 'https://www.themoviedb.org/settings/api', 'min': 16}),
    ('mdblist', {'setting': 'mdblist_api_key', 'name': 'MDBList',
                 'purpose': 'MDBList lists and ratings',
                 'url': 'https://mdblist.com/preferences/', 'min': 10}),
    ('fanarttv', {'setting': 'fanarttv_api_key', 'name': 'Fanart.tv',
                  'purpose': 'more and newer logos and backgrounds (personal key)',
                  'url': 'https://fanart.tv/get-an-api-key/', 'min': 16}),
    ('introdb', {'setting': 'meganexus_introdb_key', 'name': 'TheIntroDB',
                 'purpose': 'skip intro / recap / credits timings',
                 'url': 'https://theintrodb.org/', 'min': 8}),
    # 7.0.12: a debrid service built in - streams without a stream add-on.
    ('torbox', {'group': 'debrid', 'setting': 'torbox_api_key', 'name': 'TorBox',
                'purpose': 'streams straight from your TorBox account (no add-on needed)',
                'url': 'https://torbox.app/settings', 'min': 20}),
    ('premiumize', {'group': 'debrid', 'setting': 'premiumize_api_key', 'name': 'Premiumize',
                    'purpose': 'streams straight from your Premiumize account (no add-on needed)',
                    'url': 'https://www.premiumize.me/account', 'min': 10}),
    # 7.0.37: Offcloud (torrents, like TorBox) and Easynews (Usenet; its login).
    ('offcloud', {'group': 'debrid', 'setting': 'offcloud_api_key', 'name': 'Offcloud',
                  'purpose': 'streams straight from your Offcloud account (no add-on needed)',
                  'url': 'https://offcloud.com/#/account', 'min': 10}),
    # 8.1.3: AI subtitles - Gemini's free key translates the film's subtitles in the player
    ('gemini', {'group': '', 'setting': 'gemini_api_key', 'name': 'Gemini',
                'purpose': 'AI subtitles: translates subtitles into your language (free key)',
                'url': 'https://aistudio.google.com/apikey', 'min': 20}),
    # 8.1.5: a second free Gemini key (another Google account) - the two translate side by side
    ('gemini2', {'group': '', 'setting': 'gemini_api_key_2', 'name': 'Gemini (second key)',
                 'purpose': 'optional - with it AI subtitles translate twice as fast (a key of another Google account)',
                 'url': 'https://aistudio.google.com/apikey', 'min': 20}),
    # 8.1.3: Real-Debrid and AllDebrid, the same way
    ('realdebrid', {'group': 'debrid', 'setting': 'realdebrid_api_key', 'name': 'Real-Debrid',
                    'purpose': 'streams straight from your Real-Debrid account (no add-on needed)',
                    'url': 'https://real-debrid.com/apitoken', 'min': 20}),
    ('alldebrid', {'group': 'debrid', 'setting': 'alldebrid_api_key', 'name': 'AllDebrid',
                   'purpose': 'streams straight from your AllDebrid account (no add-on needed)',
                   'url': 'https://alldebrid.com/apikeys/', 'min': 10}),
    ('easynews', {'group': 'usenet', 'setting': 'easynews_login', 'name': 'Easynews',
                  'purpose': 'Usenet streams from Easynews - enter it as username:password',
                  'url': 'https://account.easynews.com/', 'min': 3, 'pair': True}),
    # 7.0.43: the user's Usenet provider for NZB sources (usenet_stream.py); the port
    # and SSL are found on saving. Stored as nntps://user:password@host:port/connections.
    ('usenet', {'group': 'usenet', 'setting': 'usenet_server', 'name': 'Usenet server',
                'purpose': 'your Usenet provider, plays NZB sources - enter username:password@news.provider.com',
                'url': 'https://www.reddit.com/r/usenet/wiki/providers/', 'min': 3, 'server': True,
                'placeholder': 'username:password@news.provider.com'}),
    # 7.0.45: the user's own Newznab indexers, searched from this box (newznab.py).
    ('newznab', {'group': 'usenet', 'setting': 'newznab_indexers', 'name': 'Newznab indexers',
                 'purpose': 'your Usenet indexers searched from this box - the indexer\'s name and API key (nzbgeek KEY, drunkenslug KEY), or its address and key; several separated by commas',
                 'url': 'https://hampelmen.github.io/nzb-sources/', 'min': 3, 'indexers': True,
                 'placeholder': 'nzbgeek YOURAPIKEY, drunkenslug YOURAPIKEY'}),
    # 7.0.45: your own Prowlarr's torrent indexers for TorBox / Premiumize / Offcloud (prowlarr.py)
    ('prowlarr', {'group': 'debrid', 'setting': 'prowlarr_server', 'name': 'Prowlarr',
                  'purpose': 'your own Prowlarr server\'s torrent indexers for TorBox, Premiumize and Offcloud - its address and API key',
                  'url': 'https://prowlarr.com/', 'min': 3, 'prowlarr': True,
                  'placeholder': 'http://192.168.1.10:9696 YOURAPIKEY'}),
    # 9.0.6: the Music app's Spotify catalogue - the person's own free Spotify app (music_meta.py)
    ('spotify', {'group': '', 'setting': 'meganexus_spotify_app', 'name': 'Spotify',
                 'purpose': 'Music app: Spotify\'s catalogue - your free Spotify app (Dashboard > Create app): its Client ID, a colon, then its other key',
                 'url': 'https://developer.spotify.com/dashboard', 'min': 3, 'spotify': True, 'placeholder': 'ClientID:ClientKey'}),
])
GROUPS = (('usenet', 'Usenet'), ('debrid', 'Debrid'), ('', 'Other keys'))   # 7.0.45: the phone page's sections


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_snapshot import cached_addon
    return cached_addon()


def status(addon=None):
    """[{'id', 'name', 'purpose', 'url', 'set'}] - no key values."""
    addon = _addon(addon)
    return [{'id': key, 'name': row['name'], 'purpose': row['purpose'], 'url': row['url'], 'placeholder': row.get('placeholder', ''),
             'group': row.get('group', ''),
             'set': bool((addon.getSetting(row['setting']) or '').strip())} for key, row in KEYS.items()]


HIDDEN = ('usenet', 'newznab', 'prowlarr', 'spotify')   # logins and addresses: never shown, not even in part


def shown(key, whole=False, addon=None):
    """8.1.5: the key as this device's own screen shows it - its first and last four
    characters (which one is set, without it whole on screen), or ``whole``. For the Kodi
    screen only: never sent to the phone (that page gets status()) and never logged."""
    if key not in KEYS or key in HIDDEN:
        return ''
    value = (_addon(addon).getSetting(KEYS[key]['setting']) or '').strip()
    if whole or not value:
        return value
    return '%s\u2026%s' % (value[:4], value[-4:]) if len(value) > 12 else '\u2022' * len(value)


def usenet_value(value):
    """'user:password@news.provider.com[:port]' -> the stored server address (port
    and SSL found by connecting). Raises ValueError with what to fix."""
    from . import usenet_stream
    text = value.split('://', 1)[-1].strip().rstrip('/')
    login, at, place = text.rpartition('@')
    user, _, password = login.partition(':')
    host, _, port = place.partition(':')
    if not at or not user or not password or not host:
        raise ValueError('Enter the Usenet server as username:password@news.provider.com.')
    found, reason = usenet_stream.detect(host.strip(), user, password, 10, int(port) if port.strip().isdigit() else None)
    if reason:
        raise ValueError('Usenet server: %s.' % reason)
    return found


def save(key, value, addon=None):
    """Store (or with an empty value, remove) one key."""
    if key not in KEYS:
        raise ValueError('Unknown API key.')
    row = KEYS[key]
    value = str(value or '').strip()
    if row.get('prowlarr'):
        from . import prowlarr
        prowlarr.save_value(value, _addon(addon))   # checked with the server, then kept
        return {}
    if row.get('indexers'):
        from . import newznab
        newznab.save_value(value, _addon(addon))   # checked with each indexer, then kept
        return {}
    if value and row.get('spotify'):
        from . import music, music_meta
        if ':' not in value or not all(part.strip() for part in value.split(':', 1)):
            raise ValueError('Enter your Spotify app as its Client ID, a colon, then its other key.')
        try:
            music_meta.check_spotify(value)
        except music.MusicError as exc:
            raise ValueError(str(exc))
    elif value and row.get('server'):
        value = usenet_value(value)
    elif value and row.get('pair') and (':' not in value or not all(part.strip() for part in value.split(':', 1))):
        raise ValueError('Enter the %s login as username:password.' % row['name'])
    if value and not row.get('pair') and not row.get('server') and not row.get('spotify') and (len(value) < row['min'] or any(ch.isspace() for ch in value)):
        raise ValueError('That does not look like a %s API key. Copy it again from %s.' % (row['name'], row['url']))
    addon = _addon(addon)
    addon.setSetting(row['setting'], value)
    try:
        from . import settings_snapshot
        settings_snapshot.invalidate()
    except Exception:
        pass
    return {}
