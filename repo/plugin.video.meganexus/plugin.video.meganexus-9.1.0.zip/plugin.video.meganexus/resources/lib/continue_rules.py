# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Continue Watching rules shared by the resume and next-episode cards (6.0.35).

* Remove (GitHub issue #5): hides a title from Continue Watching without
  touching its progress or watched state. It comes back by itself once the
  title is played again (a newer progress time than the removal).
* Period (issue #7): only titles watched in the last N days, like the Nuvio
  apps (default 60 days; 0 = no limit).
* Unaired next episodes (issue #7): "airs tomorrow" cards can be switched
  off. Like in the Nuvio apps this is a setting of this device. 9.0.9: as in
  the Nuvio apps, the days ahead - the same season's next on its day, a new
  season's first within a week (watch_nextup.coming).
"""
import json
import os
import threading
import time

PERIOD_SETTING = 'meganexus_cw_days'
PERIODS = ('30', '60', '90', '0')
PERIOD_DEFAULT = '60'
PERIOD_LABELS = {'30': '30 days', '60': '60 days', '90': '90 days', '0': 'No limit'}
UNAIRED_SETTING = 'meganexus_cw_unaired'
_LOCK = threading.RLock()
_MEM = {}


def _addon(addon=None):
    if addon is not None:
        return addon
    from . import settings_snapshot
    return settings_snapshot.cached_addon()


def period_days(addon=None):
    try:
        value = _addon(addon).getSetting(PERIOD_SETTING)
    except Exception:
        value = ''
    return int(value if value in PERIODS else PERIOD_DEFAULT)


def show_unaired(addon=None):
    try:
        return _addon(addon).getSetting(UNAIRED_SETTING) != 'false'
    except Exception:
        return True


def recent_enough(updated_at, addon=None, now=None):
    days = period_days(addon)
    if not days:
        return True
    from .progress_model import timestamp
    return timestamp(updated_at) >= (now or time.time()) - days * 86400


def key(media_type, canonical_id):
    kind = 'movie' if media_type == 'movie' else 'series'
    return '%s|%s' % (kind, canonical_id or '')


def _path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), 'continue_hidden.json')


def _read():
    path = _path()
    try:
        stamp = os.stat(path).st_mtime_ns
    except OSError:
        return {}
    with _LOCK:
        if _MEM.get('stamp') == (path, stamp):
            return dict(_MEM['data'])
        try:
            with open(path, encoding='utf-8') as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return {}
        data = data if isinstance(data, dict) else {}
        _MEM.update(stamp=(path, stamp), data=data)
        return dict(data)


def _keys(media_type, canonical_id, others=()):
    """The title's keys: its own id and its other ids (IMDb / TMDB / TVDB, progress_db.title_keys) -
    GitHub issue #31: one series saved under two ids came back under the one not removed."""
    keys = [key(media_type, canonical_id)] if canonical_id else []
    for other in others or ():
        value = str(other or '').strip()
        if value and value not in ('0', 'None') and key(media_type, value) not in keys:
            keys.append(key(media_type, value))
    return keys


def hide(media_type, canonical_id, now=None, others=()):
    """Remove a title from Continue Watching until it is played again (under any of its ids)."""
    from .meganexus.json_files import write_json
    with _LOCK:
        data = _read()
        stamp = float(now or time.time())
        for name in _keys(media_type, canonical_id, others):
            data[name] = stamp
        # Bounded: the oldest removals go first.
        data = dict(sorted(data.items(), key=lambda pair: pair[1], reverse=True)[:500])
        path = _path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        write_json(path, data)
        _MEM.clear()


def played(media_type, canonical_id, others=()):
    """7.0.42: a removed title that starts playing is back at once - "until it is
    played again" waited for saved progress, which a start of a few seconds
    never makes, so a quick start and Back left it hidden. 9.0.6: back under
    all its ids - those removed with it (the same removal time) too."""
    from .meganexus.json_files import write_json
    with _LOCK:
        data = _read()
        names = [name for name in _keys(media_type, canonical_id, others) if name in data]
        if not names:
            return False
        data = dict(data)
        times = {data[name] for name in names}
        kind = key(media_type, '')
        for name in list(data):
            if name in names or (name.startswith(kind) and data[name] in times):
                data.pop(name, None)
        write_json(_path(), data)
        _MEM.clear()
    return True


def hidden(media_type, canonical_id, updated_at, data=None, others=()):
    """True while the title was removed (under any of its ids) after its latest progress."""
    data = _read() if data is None else data
    removed = max([float(data[name]) for name in _keys(media_type, canonical_id, others) if data.get(name)] or [0])
    if not removed:
        return False
    from .progress_model import timestamp
    return timestamp(updated_at) <= removed


def ids_of(row):
    """A progress row's or a card's other ids, for hide / hidden / played."""
    from .meganexus.progress_db import title_keys
    own = str(row.get('canonical_id') or '')
    return sorted(value for _, value in title_keys(row) if value != own)


def snapshot():
    return _read()
