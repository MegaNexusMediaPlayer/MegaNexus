# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Phone setup: a local web page served by Kodi itself (6.0.22).

The TV shows a QR code with ``http://<lan-ip>:<port>/?k=<key>``. The phone,
on the same Wi-Fi, opens that page directly from this Kodi device - there is
no external server. The page edits accounts, add-ons, collections and display
options through the same backend functions the TV settings use. "Save" applies
everything, stops the service and lets the caller open MegaNexus. The service
runs only while its TV window is open (closed by Save, Back or idle timeout).

Security: every API call needs the one-time key from the QR code (compared in
constant time); a page opened without it gets nothing. Personalized manifest
URLs are never sent to the phone. Passwords exist only in RAM for the sign-in
request. Traffic is plain HTTP inside the local network.
"""
import hmac
import json
import os
import re
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

import xbmcaddon

ADDON_ID = 'plugin.video.meganexus'
IDLE_TIMEOUT = 15 * 60          # seconds without a phone request
MAX_BODY = 64 * 1024
SAVE_MAX = 1024 * 1024        # 7.0.31: Save sends every collection (600 were over 64 KB: "Bad request")
BACKUP_MAX = 120 * 1024 * 1024  # a settings backup with the local library (7.0); 7.0.47: profiles and pictures too
# 6.0.37: one fixed port, so a firewall on the device (Linux PCs with ufw
# default-deny, for example) can allow it once; a random port was blocked on
# every attempt. Falls back to any free port when something else uses it.
PORT = 8765
PAGE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'phone_setup', 'index.html')
DISPLAY_KEYS = {
    # page field: (setting id, kind)
    'card_shape': ('meganexus_card_shape', ('poster', 'landscape')),
    'show_ratings': ('meganexus_show_ratings', 'bool_default_on'),
    'auto_trailers': ('meganexus_auto_trailers', 'bool'),
    'continue_row': ('meganexus_home_continue', 'bool_default_on'),
    'home_layout': ('meganexus_home_layout', ('collections', 'rows', 'posters')),   # 6.0.35; 7.0.48 posters
    # 7.0.48: the "Browse all" card at a row's end, the posters wall's order and kind (home_posters)
    'browse_all': ('meganexus_browse_all', 'bool_default_on'),
    'posters_sort': ('meganexus_posters_sort', ('newest', 'oldest', 'title', 'collections')),
    'posters_show': ('meganexus_posters_show', ('all', 'movie', 'series')),
}


def _log(text):
    """7.0.42: why the phone setup did what it did (never a key or a link)."""
    try:
        import xbmc
        xbmc.log('[MegaNexus] Phone setup: ' + text, xbmc.LOGINFO)
    except Exception:
        pass


def lan_ip():
    """LAN address of this device (a UDP connect sends no packet)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('10.255.255.255', 1))
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return '127.0.0.1'


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


# ---------------------------------------------------------------- state ----

def _source_label(source, providers):
    from .collections_home import matching_catalog
    kind = 'Series' if source.get('type') == 'series' else 'Movies'
    from .collection_sources import is_virtual, label
    if is_virtual(source):
        return label(source)
    match = matching_catalog(source, providers)
    if not match:
        return '%s (%s) · not installed' % (source.get('catalogId'), kind)
    provider, catalog = match
    genre = source.get('genre') if source.get('genre') not in (None, '', 'None') else ''
    return '%s · %s (%s%s)' % (provider.get('name') or provider['id'], catalog.get('name') or catalog.get('id'),
                               kind, ', ' + genre if genre else '')


def _bool(addon, key, default_on):
    value = addon.getSetting(key)
    return value != 'false' if default_on else value == 'true'


def state():
    """Everything the phone page shows. No manifest URLs, tokens or passwords."""
    from . import metadata_providers, stream_providers, subtitle_providers, sport_providers, collection_profile, default_setup, home_source
    from .meganexus import addon_registry
    from .meganexus import cloud_sync as sync
    addon = _addon()
    try:default_setup.replace_cinemeta()   # 9.0.4: the page never lists Cinemeta beside the MegaNexus Catalog
    except (ValueError, OSError):pass
    providers = addon_registry.list_providers()
    token = sync.NuvioCloud.token()
    from .collections_home import poster_groups
    poster_ids = poster_groups(addon)
    display = {}
    for field, (key, kind) in DISPLAY_KEYS.items():
        if isinstance(kind, tuple):
            display[field] = addon.getSetting(key) if addon.getSetting(key) in kind else kind[0]
        else:
            display[field] = _bool(addon, key, kind == 'bool_default_on')
    kind = addon.getSetting('meganexus_screensaver_type') or 'image'
    from . import theme
    display['theme'] = theme.current(addon)
    display['screensaver'] = 'animated' if kind == 'animated' else ('custom' if kind in ('video', 'slideshow') or addon.getSetting('meganexus_screensaver_art') else 'image')
    return {
        'nuvio': {'linked': bool(token.get('access_token')), 'profile': token.get('profile_name') or '',
                  'email': token.get('email') or ''},
        'metadata': [{'id': p['id'], 'name': p.get('name') or p['id'], 'enabled': bool(on),
                      'builtin': (p.get('manifest') or {}).get('id') == default_setup.CATALOG_ID}
                     for p, on in metadata_providers.entries(providers)],
        # 9.0.4: the MegaNexus Catalog Addon's language and region, the add-on's own lists
        'catalog': dict(default_setup.chosen(addon), **default_setup.options()),
        'free': {'done': any((p.get('manifest') or {}).get('id') == FREE_STREAMS_ID for p in providers),   # Quick setup · Free streams
                 'page': FREE_STREAMS_PAGE},
        'streams': [{'id': p['id'], 'name': p.get('name') or p['id'], 'enabled': bool(on)}
                    for p, on in stream_providers.entries(providers)],
        # 7.0.20: subtitle and sport add-ons switched on their own, as on the TV.
        'subtitles': [{'id': p['id'], 'name': p.get('name') or p['id'], 'enabled': bool(on)}
                      for p, on in subtitle_providers.entries(providers)],
        'sport': [{'id': p['id'], 'name': p.get('name') or p['id'], 'enabled': bool(on)}
                  for p, on in sport_providers.entries(providers)],
        'providers': [{'id': p['id'], 'name': p.get('name') or p['id']} for p in providers],
        # 9.0.6: where Home's one set of collections comes from (home_source)
        'home_source': {'current': home_source.current(),
                        'choices': [{'key': key, 'name': name, 'detail': detail} for key, name, detail in home_source.choices(providers)]},
        'groups': [{'id': g['id'], 'title': g['title'], 'hidden': bool(g.get('hidden')),
                    'posters': g['id'] in poster_ids,     # 9.0.9: shown as poster rows (collections_home)
                    'folders': [{'id': f['id'], 'title': f['title'], 'hidden': bool(f.get('hidden')),
                                 'hideTitle': bool(f.get('hideTitle')),
                                 'sources': [{'label': _source_label(s, providers), 'enabled': s.get('enabled') is not False}
                                             for s in f['sources']]}
                                for f in g['folders']]}
                   for g in collection_profile.load()],
        'display': display,
        'home_rows': _home_rows_state(),         # 9.0.8: Watchlist / Next episodes - on or off, who fills them, where
        'tracking': _tracking_status(),
        'ratings': _ratings_status(),
        'tmdb_key': bool(addon.getSetting('tmdb_api_key')),
        'jellyfin': _jellyfin_status(),
        'emby': _server_status('emby'),
        'api_keys': _api_keys_status(),
        'stremio': _stremio_status(),
        'saver': _saver_state(),
        'badges': _badges_state(),
        'setup_links': _setup_links(providers),
        'aio': _aio_state(providers),
        'opensubtitles': _opensubtitles_state(providers),
        'ai_subtitles': _ai_state(),             # 8.1.3: on / off and whether the key is set - never the key
        'help': _help(),
        'profiles': _profiles_state(),
        'apps': _apps_state(),                   # 9.0.6: the HUB apps - YouTube and Music (no source addresses)
    }


def _apps_state():
    """The HUB apps' settings: YouTube's, and Music's sources (name and host only - an address may
    carry a token) and folders."""
    from . import music, youtube
    from xbmc import getCondVisibility
    return {'youtube': {'autoplay': _addon().getSetting(youtube.AUTONEXT) == 'true',
                        'steady': youtube.steady() if getCondVisibility('System.HasAddon(plugin.video.youtube)') else None,
                        'locked': youtube.dash_trouble(),   # 9.0.8: an Amlogic box: Steady stays on
                        'channels': [{'id': c['id'], 'name': c.get('name') or c['id']} for c in youtube.my_channels()]},
            'music': {'sources': [{'id': s['manifest'].get('id'), 'name': s['manifest'].get('name', ''), 'host': music.host(s),
                                   'on': s.get('on', True)} for s in music.sources()],
                      'folders': music.folders(), 'deezer': music.deezer_profile(),
                      'catalogue': music.catalogue(), 'catalogues': [list(c) for c in music.CATALOGUES]}}


def _apps_action(path, body):
    from . import music, youtube
    if path == '/api/youtube/set':
        if body.get('key') == 'autoplay':
            _addon().setSetting(youtube.AUTONEXT, 'true' if body.get('on') else 'false')
        elif body.get('key') == 'steady':
            # 9.0.8: as Settings > YouTube - MPEG-DASH (4K) is your own choice, kept; never on an Amlogic box
            if not body.get('on') and youtube.dash_trouble():
                raise ValueError('On this box (Amlogic) MPEG-DASH froze Kodi - Steady playback stays on here.')
            _addon().setSetting(youtube.DASH_CHOSEN, 'false' if body.get('on') else 'true')
            youtube.steady(bool(body.get('on')))
    elif path == '/api/youtube/channel/remove':
        youtube.remove_channel(str(body.get('id') or ''))
    elif path == '/api/music/add':
        try:
            added = music.add(body.get('url'))
        except music.MusicError as exc:
            raise ValueError(music.safe(exc))
        return {'name': added['manifest'].get('name', '')}
    elif path == '/api/music/remove':
        music.remove(str(body.get('id') or ''))
    elif path == '/api/music/switch':
        music.switch(str(body.get('id') or ''), bool(body.get('on')))
    elif path == '/api/music/deezer':
        try:
            music.deezer_profile(value=str(body.get('profile') or ''))
        except music.MusicError as exc:
            raise ValueError(music.safe(exc))
    elif path == '/api/music/import':
        from . import music_import
        try:
            added = music_import.from_link(str(body.get('url') or ''))
        except music.MusicError as exc:
            raise ValueError(music.safe(exc))
        return {'name': added['title'], 'count': added['count']}
    elif path == '/api/music/catalogue':
        try:
            music.catalogue(value=str(body.get('id') or ''))
        except music.MusicError as exc:
            raise ValueError(music.safe(exc))
    elif path == '/api/music/folder':
        folder = str(body.get('path') or '').strip()
        kept = [f for f in music.folders() if f != folder]
        music.set_folders(kept + [folder] if body.get('add') and folder else kept)
    return {}


def _profiles_state():
    """7.0.45: the Profiles tab - names, PIN or not, a picture or not (never the PIN)."""
    try:
        from . import user_profiles
        now = user_profiles.active()
        return {'max': user_profiles.MAX_PROFILES,
                'rows': [{'id': row['id'], 'name': row['name'], 'primary': bool(row.get('primary')),
                          'pin': bool(row.get('pin')), 'picture': bool(row.get('picture')), 'active': row['id'] == now,
                          'initials': user_profiles.initials(row['name'])} for row in user_profiles.profiles()]}
    except Exception:
        return {'max': 0, 'rows': []}


def _profile_add(body):
    from . import user_profiles
    user_profiles.add(body.get('name'))
    return {'profiles': _profiles_state()}


def _profile_remove(body):
    from . import user_profiles
    user_profiles.remove(str(body.get('id') or ''))
    return {'profiles': _profiles_state()}


def _profile_save(body):
    import base64
    from . import user_profiles
    pid = str(body.get('id') or '')
    if not user_profiles.get(pid):
        raise ValueError('This profile is gone.')
    if body.get('name'):
        user_profiles.rename(pid, body.get('name'))
    if body.get('clear_pin'):
        user_profiles.set_pin(pid, '')
    elif body.get('pin'):
        user_profiles.set_pin(pid, body.get('pin'))
    picture = str(body.get('picture') or '')
    if picture:
        try:
            payload = base64.b64decode(picture.split(',', 1)[-1], validate=True)
        except ValueError:
            raise ValueError('The picture could not be read.')
        user_profiles.set_picture(pid, payload)
    return {'profiles': _profiles_state()}


# 7.0.42: the Start tab - each add-on's own configure page. The user makes the
# link there and pastes it back here (add_manifest); its settings stay theirs.
SETUP_LINKS = (
    # role, name, setup page, manifest id ('' = recognised by its name), what it does
    ('metadata', 'AIOMetadata', 'https://aiometadata.viren070.me/configure', 'com.aio.metadata',
     'Titles, posters, logos and details from TMDB, TVDB, TVMaze, MyAnimeList, IMDb and Fanart.tv - you choose the source.'),
    ('streams', 'AIOStreams', 'https://aiostreams.viren070.me/stremio/configure', 'aiostreams.viren070.com',
     'Your stream add-ons and debrid services behind one link, filtered and sorted the way you set it.'),
    ('streams', 'PenguPlay', 'https://pengu.uk/configure', 'com.penguplay',
     'Films and series with provider and quality filters.'),
    ('subtitles', 'SubDL', 'https://stremio.subdl.com/configure', '',
     'Subtitles from SubDL. Its page asks for your free SubDL API key and languages.'),
    ('subtitles', 'SubSource', 'https://subsource.strem.top/configure', 'community.subsource.subtitles',
     'Subtitles from SubSource.net in the languages you choose.'),
    ('subtitles', 'OpenSubtitles v3+', 'https://opensubtitles.stremio.homes/configure', 'community.opensubtitles.v3.plus',
     'OpenSubtitles with up to 10 chosen languages and more subtitle formats.'),
)


def _squash(text):
    return re.sub(r'[^a-z0-9]', '', str(text or '').lower())


def _setup_links(providers):
    """The Start tab's add-ons, each marked when it is installed already."""
    ids = {(p.get('manifest') or {}).get('id') for p in providers}
    names = [_squash(p.get('name')) for p in providers]
    return [{'role': role, 'name': name, 'url': url, 'note': note,
             'installed': manifest in ids if manifest else any(_squash(name) in n for n in names)}
            for role, name, url, manifest, note in SETUP_LINKS]


def _aio_state(providers):
    """7.0.52: the quick setup (MegaNexus Streams + Metadata) and every AIO add-on's configure page."""
    from . import aio_setup
    try:
        done = bool(aio_setup.load_state().get('streams'))
        return {'done': done, 'links': aio_setup.configure_links(providers)}
    except Exception:
        return {'done': False, 'links': []}


def aio_quick_setup(body):
    from . import aio_setup
    form = dict(body or {})
    form.setdefault('language', aio_setup.kodi_language())
    try:
        return aio_setup.run(form)
    except aio_setup.SetupError:
        raise
    except Exception as exc:
        _log('quick setup failed: %s' % type(exc).__name__)
        raise ValueError('The quick setup stopped (%s). Nothing of yours was changed - try again.' % type(exc).__name__)


FREE_STREAMS_PAGE = 'https://pengu.uk/configure'   # PenguPlay's own page (SETUP_LINKS): its sign-in and install link
FREE_STREAMS_ID = 'com.penguplay'


def free_quick_setup(url, fetch=None):
    """9.0.4: Quick setup · Free streams - MegaNexus with PenguPlay: the MegaNexus Catalog (TMDB) for titles and
    catalogs, PenguPlay for streams, both ON. PenguPlay needs its own sign-in: ``url`` is the install link its page
    makes. Beside the user's own add-ons."""
    from . import default_setup, metadata_providers, stream_providers
    from .meganexus import addon_registry, addon_wire
    url = str(url or '').strip()
    if not re.match(r'^https://pengu\.uk/.+/manifest\.json$', url):
        raise ValueError('Paste the install link from the PenguPlay page (it ends in /manifest.json).')
    try:
        manifest = (fetch or addon_wire.get_json)(url, ttl_seconds=0, timeout_override=20, retry=False, rate_wait=.25)
    except Exception as exc:
        _log('free quick setup: PenguPlay did not answer (%s)' % type(exc).__name__)
        raise ValueError('PenguPlay did not answer this link - check that you are signed in on its page, then copy it again.')
    if not isinstance(manifest, dict) or manifest.get('id') != FREE_STREAMS_ID:
        raise ValueError('That is not a PenguPlay link. Copy the install link from the PenguPlay page.')
    try:
        catalog = default_setup.install_builtin(enable=True)
    except Exception as exc:
        _log('free quick setup: the MegaNexus Catalog did not answer (%s)' % type(exc).__name__)
        raise ValueError('The MegaNexus Catalog did not answer. Nothing of yours was changed - try again.')
    _addon().setSetting(default_setup.BUILTIN_AUTO, '')      # chosen here: never switched back by itself
    streams = addon_registry.add_provider(manifest.get('name') or 'PenguPlay', url, manifest)
    stream_providers.set_enabled(streams['id'], True)
    if not any(p['id'] == catalog['id'] for p in metadata_providers.enabled()):
        metadata_providers.set_enabled(catalog['id'], True)
    return {'streams': streams.get('name') or 'PenguPlay', 'metadata': default_setup.CATALOG_NAME}


def _help():
    """The user guide of HUB Settings > Help & diagnostics, for the Help tab."""
    from .help_topics import TOPICS
    return [{'id': key, 'title': title, 'text': text} for key, title, text in TOPICS]


def _opensubtitles_state(providers):
    from . import subtitle_providers
    found = next((p for p, on in subtitle_providers.entries(providers)
                  if (p.get('manifest') or {}).get('id') == subtitle_providers.OPENSUBTITLES_ID), None)
    return {'installed': found is not None,
            'on': bool(found) and found['id'] in subtitle_providers.enabled_ids(providers)}


def opensubtitles_on():
    from . import subtitle_providers
    name = subtitle_providers.opensubtitles_on()
    return {'name': name}


def _saver():
    from . import phone_saver
    return phone_saver


def _badges_state():
    from . import quality_badges
    return quality_badges.status()


def _badges_save(body):
    from . import quality_badges
    if 'pack' in body:return quality_badges.save_pack(body['pack'],body.get('name'))
    return quality_badges.save(body.get('urls'))


def _ai_state():
    try:
        from . import ai_subtitles
        return {'on': ai_subtitles.enabled(), 'key': ai_subtitles.configured()}
    except Exception:
        return {'on': False, 'key': False}


def _ai_toggle(body):
    """8.1.3: the player's AI subtitles button, from the phone (the same switch as on the TV)."""
    from . import ai_subtitles
    from .settings_snapshot import cached_addon, invalidate
    cached_addon().setSetting(ai_subtitles.SWITCH, 'true' if body.get('on') else 'false')
    invalidate()
    ai_subtitles.publish()
    return _ai_state()


def _badges_toggle(body):
    from . import quality_badges
    return quality_badges.toggle(bool(body.get('on')))


def _badges_set(body):
    from . import quality_badges
    return quality_badges.choose(str(body.get('id') or ''))


def _badges_preview(body):
    from . import quality_badges
    return quality_badges.status(str(body.get('text') or quality_badges.EXAMPLE)[:2048])


def _saver_state():
    """The Screensaver tab (7.0.25); empty where MegaNexus's interface is not loaded."""
    try:
        from . import phone_saver
        return phone_saver.ambient_state()
    except ImportError:
        return {}


def _api_keys_status():
    try:
        from . import api_keys
        return api_keys.status()
    except Exception:
        return []


def _stremio_status():
    try:
        from . import stremio_account
        return {'connected': stremio_account.linked(), 'status': stremio_account.status(),
                'sync': stremio_account.keep_in_sync()}
    except Exception:
        return {'connected': False}


def api_key_save(key, value):
    from . import api_keys
    return api_keys.save(key, value)


def stremio_sign_in(email, password):
    """Stremio (7.0 beta): sign in and import its add-ons and Continue Watching."""
    from . import stremio_account
    stremio_account.sign_in(email, password)
    report = stremio_account.import_now()
    return {'providers': report.get('providers', 0), 'progress': report.get('progress', 0),
            'errors': report.get('errors', [])}


def stremio_import():
    from . import stremio_account
    report = stremio_account.import_now()
    return {'providers': report.get('providers', 0), 'progress': report.get('progress', 0),
            'errors': report.get('errors', [])}


def stremio_sign_out():
    from . import stremio_account
    stremio_account.sign_out()
    return {}


def stremio_keep_in_sync(on):
    from . import stremio_account
    stremio_account.set_keep_in_sync(bool(on))
    return {}


def backup_export(private=True):
    """9.0.0: ``private`` False - without sign-ins, API keys, passwords and user names, as
    on the TV (Backup without sign-ins); the phone only had the whole one."""
    from . import settings_backup
    return {'backup': settings_backup.export_data(private=private), 'filename': settings_backup.filename(private)}


def backup_import(data):
    from . import settings_backup
    report = settings_backup.import_data(data)
    return {'report': report}


def _server_status(kind):
    """Server name and user only - never the address or token (7.0.29: Jellyfin and Emby separate)."""
    try:
        from . import mediabrowser, media_servers
        if not mediabrowser.is_signed_in(kind):
            return {'connected': False, 'kind': media_servers.label(kind)}
        auth = mediabrowser.account(kind)
        return {'connected': True, 'server': auth.get('server_name') or '', 'user': auth.get('username') or '',
                'kind': media_servers.label(kind)}
    except Exception:
        return {'connected': False}


def _jellyfin_status():
    return _server_status('jellyfin')


def server_sign_in(kind, url, username, password):
    """Jellyfin or Emby with username and password; the address must be that kind."""
    from . import mediabrowser, media_servers, settings_snapshot
    if kind not in (media_servers.JELLYFIN, media_servers.EMBY):
        raise ValueError('Unknown server kind.')
    if not str(url or '').strip() or not str(username or '').strip():
        raise ValueError('Enter the server address and the username.')
    try:
        mediabrowser.sign_in(url, username, password or '', flavor=kind)
    except mediabrowser.ServerError as exc:
        raise ValueError(str(exc) or 'Sign-in failed.')
    media_servers.switch_on(kind, _addon())
    settings_snapshot.invalidate()
    return {}


def server_sign_out(kind):
    from . import mediabrowser, media_servers, settings_snapshot
    if kind not in (media_servers.JELLYFIN, media_servers.EMBY):
        raise ValueError('Unknown server kind.')
    mediabrowser.sign_out(kind)
    _addon().setSetting(media_servers.ENABLED[kind], 'false')
    settings_snapshot.invalidate()
    return {}


def jellyfin_sign_in(url, username, password):
    return server_sign_in('jellyfin', url, username, password)


def jellyfin_sign_out():
    return server_sign_out('jellyfin')


def _tracking_status():
    try:
        from . import tracking_link
        return tracking_link.status()
    except Exception:
        return {}


def _ratings_status():
    """7.0.29: which MDBList ratings the title details show (logos + scores)."""
    try:
        from . import ratings_row, mdblist_api
        return {'configured': bool(mdblist_api.configured()),
                'services': [{'id': s, 'label': label, 'on': on} for s, label, on in ratings_row.choices()]}
    except Exception:
        return {'configured': False, 'services': []}


def ratings_set(body):
    from . import ratings_row
    ratings_row.set_enabled(str(body.get('service') or ''), bool(body.get('on')))
    return _ratings_status()


def mdblist_connect(body):
    from . import mdblist_tracking,api_keys
    from .settings_snapshot import cached_addon
    if body.get('on'):
        key=str(body.get('key') or mdblist_tracking.api_key()).strip()
        if not key:raise ValueError('Add your MDBList API key first.')
        # Validate before replacing a working key or enabling tracking.
        mdblist_tracking.request('GET','/sync/last_activities',key=key)
        if body.get('key'):api_keys.save('mdblist',key)
    cached_addon().setSetting(mdblist_tracking.SETTING,'true' if body.get('on') else 'false')
    return _tracking_status()


def wetrakr_key(body):
    """8.1.2: the WeTrakr app key from the phone - since 9.0.1 only for an own app: MegaNexus's
    is built in (wetrakr_api.DEFAULT_CLIENT_ID) and Connect links the account with a code."""
    from . import wetrakr_api
    from .settings_snapshot import cached_addon, invalidate
    key = str(body.get('key') or '').strip()
    if not key:
        raise ValueError('Paste the WeTrakr app key (wetrakr.com - Settings - API).')
    cached_addon().setSetting(wetrakr_api.KEY_SETTING, key)
    invalidate()
    return _tracking_status()


def tracking_check():
    from .tracking_connections import check_connections
    return check_connections()


def tmdb_key(value):
    """The user's own TMDb key (v3 key or v4 token) for TMDB collection sources."""
    value = str(value or '').strip()
    if not value or len(value) < 16 or any(ch.isspace() for ch in value):
        raise ValueError('Paste the TMDb API key or read access token from themoviedb.org > Settings > API.')
    _addon().setSetting('tmdb_api_key', value)
    from . import settings_snapshot
    settings_snapshot.invalidate()
    return {}


def tracking_start(service):
    from . import tracking_link
    return tracking_link.start(service)


def tracking_disconnect(service):
    from . import tracking_link
    return tracking_link.disconnect(service)


# --------------------------------------------------------------- actions ----

def add_manifest(url):
    from urllib.parse import urlsplit as split
    from .meganexus.addon_wire import manifest_ok
    from .meganexus import addon_registry
    from . import metadata_providers, stream_providers
    value = (url or '').strip()
    if value.startswith('stremio://'):
        value = 'https://' + value[len('stremio://'):]
    parsed = split(value)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc or not parsed.path.endswith('/manifest.json'):
        raise ValueError('Enter a complete http(s) …/manifest.json link, including your add-on configuration.')
    try:
        manifest = manifest_ok(value)
    except Exception:
        # The URL may contain credentials: never echo or log it.
        raise ValueError('This manifest could not be checked. Verify the link and the connection.')
    before = {p['id'] for p in addon_registry.list_providers()}
    addon_registry.add_provider(manifest.get('name') or manifest['id'], value, manifest)
    added = [p for p in addon_registry.list_providers() if p['id'] not in before]
    # Same rule as the TV pages: a newly added add-on starts ON in its lists.
    for provider in added:
        if any(p['id'] == provider['id'] for p in metadata_providers.candidates()):
            metadata_providers.set_enabled(provider['id'], True)
        if any(p['id'] == provider['id'] for p in stream_providers.candidates()):
            stream_providers.set_enabled(provider['id'], True)
    return {'added': [p.get('name') or p['id'] for p in added]}


def remove_provider(provider_id):
    from .meganexus import addon_registry
    from . import settings_snapshot
    if not addon_registry.get_provider(provider_id):
        raise ValueError('This add-on is no longer installed.')
    addon_registry.remove_provider(provider_id)
    addon = _addon()
    for role in ('metadata', 'streams'):
        if addon.getSetting('meganexus_' + role + '_provider') == provider_id:
            addon.setSetting('meganexus_' + role + '_provider', '')
    settings_snapshot.invalidate()
    return {}


def nuvio_sign_in(email, password):
    from .meganexus import cloud_sync as sync
    if not email or not password:
        raise ValueError('Enter your Nuvio email and password.')
    try:
        token = sync.NuvioCloud.authenticate(email.strip(), password)
    except Exception:
        raise ValueError('Sign-in failed. Check the email and password.')
    sync.NuvioCloud.save_token(token)
    sync.NuvioCloud.remember(email, password)    # 8.1.5: signed in again by itself when Nuvio ends the session
    _addon().setSetting('nuvio_sync_enabled', 'true')
    result = nuvio_profiles()
    if len(result['profiles']) == 1:
        # One profile: connect = import add-ons, collections and progress now.
        result['imported'] = first_import()
    return result


def nuvio_profiles():
    from .meganexus import cloud_sync as sync
    try:
        rows = sync.NuvioCloud.profiles() or []
    except Exception:
        raise ValueError('Nuvio profiles could not be loaded. Check the connection.')
    if len(rows) == 1:
        sync.NuvioCloud.select_profile(rows[0])
    return {'profiles': [{'index': r.get('profile_index'), 'name': r.get('profile_name') or 'Profile'} for r in rows]}


def nuvio_select_profile(index):
    from .meganexus import cloud_sync as sync
    rows = sync.NuvioCloud.profiles() or []
    match = next((r for r in rows if str(r.get('profile_index')) == str(index)), None)
    if not match:
        raise ValueError('That Nuvio profile was not found.')
    sync.NuvioCloud.select_profile(match)
    return {'imported': first_import()}


def first_import():
    """After connecting: add-ons, progress and - unless Home already shows the
    user's own layout - the profile's collections with their metadata ON."""
    from . import nuvio_import as importer
    return nuvio_import(collections=not importer.layout_is_users_own())


def nuvio_sign_out():
    from .meganexus import cloud_sync as sync
    sync.NuvioCloud.clear()
    _addon().setSetting('nuvio_sync_enabled', 'false')
    return {}


def nuvio_import(collections):
    """Import add-ons (and optionally the collection layout) from the Nuvio profile."""
    from .meganexus import cloud_sync as sync
    from . import nuvio_import as importer, settings_snapshot
    if not sync.NuvioCloud.is_linked():
        raise ValueError('Sign in to Nuvio first.')
    result = importer.fetch(collections=collections)
    report = importer.apply(result)
    layout = report.get('collections') or 0
    settings_snapshot.invalidate()
    return {'providers': report['providers'], 'collections': layout,
            'metadata_on': report.get('metadata_on') or [],
            'errors': list(dict.fromkeys(report['errors']))[:3]}


def _apply_switches(module, rows, on_change=None):
    current = {p['id']: (p, on) for p, on in module.entries()}
    for row in rows or []:
        pid = row.get('id') if isinstance(row, dict) else None
        if pid in current and bool(row.get('enabled')) != current[pid][1]:
            module.set_enabled(pid, bool(row.get('enabled')))
            if on_change:
                on_change(current[pid][0], bool(row.get('enabled')))


def _manual_builtin(provider, on):
    """Same rule as the TV Metadata page: a hand-made choice for the built-in catalog
    add-on is kept (never switched back automatically)."""
    from . import default_setup
    if (provider.get('manifest') or {}).get('id') == default_setup.CATALOG_ID:
        _addon().setSetting(default_setup.BUILTIN_AUTO, '' if on else 'off')


def _apply_catalog(choice):
    """9.0.4: another language or region for the MegaNexus Catalog Addon."""
    from . import default_setup
    if not isinstance(choice, dict):
        return
    lists, now = default_setup.options(), default_setup.chosen(_addon())
    language, region = choice.get('language'), choice.get('region')
    if language in dict(lists['languages']) and region in dict(lists['regions']) and (language, region) != (now['language'], now['region']):
        default_setup.choose(language, region)


def home_source_use(key):
    """The phone's Collections: Home shows yours, the MegaNexus Catalog or one add-on's catalogs."""
    from . import home_source, settings_snapshot
    cards = home_source.use(str(key or ''))
    settings_snapshot.invalidate()
    return {'cards': cards}


def _apply_groups(rows):
    """Order, visibility, titles and catalog switches. Unknown IDs are ignored;
    collections the page did not send keep their place at the end. 9.0.9: and each row shown as cards
    or poster rows (a setting of this device - never in the collections Nuvio is sent)."""
    from . import collection_profile, collections_home
    groups = collection_profile.load()
    if not groups or not isinstance(rows, list):
        return False
    by_id = {g['id']: g for g in groups}
    addon = _addon()
    for row in rows:
        if isinstance(row, dict) and row.get('id') in by_id and 'posters' in row:
            collections_home.show_as_posters(row['id'], bool(row.get('posters')), addon)
    ordered, before = [], json.dumps(groups, sort_keys=True)
    for row in rows:
        group = by_id.pop(row.get('id'), None) if isinstance(row, dict) else None
        if group is None:
            continue
        group['hidden'] = bool(row.get('hidden'))
        folders = {f['id']: f for f in group['folders']}
        new_folders = []
        for item in row.get('folders') or []:
            folder = folders.pop(item.get('id'), None) if isinstance(item, dict) else None
            if folder is None:
                continue
            title = str(item.get('title') or '').strip()
            if title:
                folder['title'] = title[:80]
            folder['hidden'] = bool(item.get('hidden'))
            folder['hideTitle'] = bool(item.get('hideTitle'))
            switches = item.get('sources')
            if isinstance(switches, list) and len(switches) == len(folder['sources']):
                for source, on in zip(folder['sources'], switches):
                    source['enabled'] = bool(on)
            new_folders.append(folder)
        new_folders.extend(folders.values())
        group['folders'] = new_folders
        ordered.append(group)
    ordered.extend(by_id.values())
    if json.dumps(ordered, sort_keys=True) == before:
        return False
    collection_profile.save(ordered)
    return True


def _home_rows_state():
    """9.0.8: Home's Watchlist and Next episodes rows (tracking_rows) - on or off (off until switched on),
    "Rows from" with only the services that can fill them now, and where they stand: [[id, place]], the
    place counting the collection groups above it. No sign-in of any service is sent."""
    from . import tracking_rows
    addon = _addon()
    try:
        return {'rows': [{'id': name, 'name': tracking_rows.TITLES[name], 'on': tracking_rows.shown(name, addon),
                          'from': tracking_rows.picked(name, addon),
                          'choices': [{'key': key, 'name': label} for key, label in tracking_rows.sources(name, addon)]}
                         for name in tracking_rows.ROWS],
                'order': [[name, place] for name, place in tracking_rows.order(addon)]}
    except Exception as exc:
        _log('Home rows not read: %s' % exc)
        return {'rows': [], 'order': []}


def _apply_home_rows(value):
    """9.0.8: the phone's Watchlist / Next episodes as the page has them (tracking_rows.apply); a row
    switched on gets its first answer asked at once."""
    from . import tracking_rows
    if not isinstance(value, dict):
        return
    addon = _addon()
    for name in tracking_rows.apply(value.get('rows'), value.get('order'), addon):
        tracking_rows.prefill(name, addon)


def _apply_display(values):
    addon = _addon()
    if not isinstance(values, dict):
        return
    for field, (key, kind) in DISPLAY_KEYS.items():
        if field not in values:
            continue
        value = values[field]
        if isinstance(kind, tuple):
            if value in kind:
                addon.setSetting(key, value)
        else:
            addon.setSetting(key, 'true' if value else 'false')
    from . import theme
    if values.get('theme') in theme.THEMES and values['theme'] != theme.current(addon):
        theme.apply(values['theme'], addon, kodi=False)   # 7.0.45: Kodi's colours after the QR screen (it closed it)
    saver = values.get('screensaver')
    if saver in ('image', 'animated'):
        addon.setSetting('meganexus_screensaver_type', saver)
        addon.setSetting('meganexus_screensaver_art', '')
        addon.setSetting('meganexus_screensaver_video', '')


def save(payload):
    from . import settings_snapshot
    if not isinstance(payload, dict):
        raise ValueError('Nothing to save.')
    from . import metadata_providers, stream_providers, subtitle_providers, sport_providers
    _apply_switches(metadata_providers, payload.get('metadata'), _manual_builtin)
    _apply_catalog(payload.get('catalog'))
    _apply_switches(stream_providers, payload.get('streams'))
    _apply_switches(subtitle_providers, payload.get('subtitles'))
    _apply_switches(sport_providers, payload.get('sport'))
    _apply_groups(payload.get('groups'))
    _apply_home_rows(payload.get('home_rows'))   # 9.0.8: after the groups - their places count those
    _apply_display(payload.get('display'))
    settings_snapshot.invalidate()
    return {}


# --------------------------------------------------------------- server ----

REPORT_PAGE = os.path.join(os.path.dirname(PAGE), 'report.html')
TYPE_PAGE = os.path.join(os.path.dirname(PAGE), 'type.html')
RATE_PAGE = os.path.join(os.path.dirname(PAGE), 'rate.html')   # 7.0.45: rate a title on Trakt
PROFILE_PAGE = os.path.join(os.path.dirname(PAGE), 'profile.html')   # 7.0.45: a profile's name, picture and PIN


def _report(body):
    from . import problem_report
    result = problem_report.send(body)
    SetupService.last_report = result
    return result


class SetupService:
    """Local HTTP service. ``events`` are read by the TV window."""
    last_report = None

    def __init__(self, host=None, port=None, page=None, only=None):
        # 7.0.29: another phone page on the same service (Report a problem): its page
        # and the only API paths it may call.
        self.page_path = page or PAGE
        self.only = set(only) if only is not None else None
        self.typing = {}       # 7.0.29 keyboard: {'heading', 'text', 'hidden'}; the phone's text in 'typed'
        self.typed = None
        self.rating = {}       # 7.0.45 rate page: the title rated (rate_title.target); what was done in 'rated'
        self.profile = ''      # 7.0.45 profile page: the profile's id
        self.rated = None
        self.key = secrets.token_urlsafe(18)
        self.host = host or lan_ip()
        self.lock = threading.Lock()
        self.connected = False
        self.saved = False
        self.status = ''
        self.last_seen = time.monotonic()
        service = self

        class PhoneRequest(BaseHTTPRequestHandler):
            server_version = 'MegaNexusSetup'
            sys_version = ''

            def log_message(self, *args):
                pass  # URLs carry the key; never log requests

            def _send(self, code, body, ctype='application/json; charset=utf-8', cache='no-store'):
                data = body if isinstance(body, bytes) else body.encode('utf-8')
                self.send_response(code)
                self.send_header('Content-Type', ctype)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', cache)
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Referrer-Policy', 'no-referrer')
                self.end_headers()
                self.wfile.write(data)

            def _send_file(self, path):
                import re as _re
                size = os.path.getsize(path)
                start, end = 0, size - 1
                found = _re.match(r'bytes=(\d*)-(\d*)$', self.headers.get('Range') or '')
                if found and (found.group(1) or found.group(2)):
                    if found.group(1):
                        start = int(found.group(1))
                        end = min(int(found.group(2)), size - 1) if found.group(2) else size - 1
                    else:
                        start = max(0, size - int(found.group(2)))
                    if start > end:
                        self.send_response(416);self.send_header('Content-Range', 'bytes */%d' % size);self.end_headers()
                        return
                    self.send_response(206);self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, size))
                else:
                    self.send_response(200)
                ctype = ('video/mp4' if path.lower().endswith(('.mp4', '.m4v', '.mov')) else
                         'video/webm' if path.lower().endswith('.webm') else 'video/x-matroska')
                self.send_header('Content-Type', ctype)
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Length', str(end - start + 1))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                with open(path, 'rb') as handle:
                    handle.seek(start)
                    left = end - start + 1
                    while left > 0:
                        chunk = handle.read(min(262144, left))
                        if not chunk:
                            break
                        try:
                            self.wfile.write(chunk)
                        except (BrokenPipeError, ConnectionResetError):
                            break
                        left -= len(chunk)

            def _json(self, code, value):
                self._send(code, json.dumps(value, ensure_ascii=False))

            def _authorized(self, query_key=''):
                given = self.headers.get('X-Setup-Key') or query_key or ''
                return hmac.compare_digest(given.encode('utf-8'), service.key.encode('utf-8'))

            def do_GET(self):
                parts = urlsplit(self.path)
                query = parse_qs(parts.query)
                if parts.path == '/logo.png':
                    return self._send(200, service.logo(), 'image/png', 'max-age=3600')
                if parts.path == '/':
                    if not self._authorized((query.get('k') or [''])[0]):
                        _log('a page from an older QR code was opened (each QR code works while it is on the TV)')
                        return self._send(403, service.locked_page(), 'text/html; charset=utf-8')
                    service.touch(connected=True)
                    return self._send(200, service.page(), 'text/html; charset=utf-8')
                if parts.path == '/api/saver/video':
                    # 7.0.29: the video back to the phone, which makes its sharp frame (Range: Safari).
                    if not self._authorized((query.get('k') or [''])[0]):
                        return self._json(403, {'ok': False})
                    from . import phone_saver
                    path = phone_saver._video_path()
                    if not path:
                        return self._json(404, {'ok': False})
                    return self._send_file(path)
                if parts.path == '/api/saver/asset':
                    # 7.0.42: the screensaver's own pictures and fonts for the phone's preview.
                    if not self._authorized((query.get('k') or [''])[0]):
                        return self._json(403, {'ok': False})
                    from . import phone_saver
                    path, kind = phone_saver.asset_file((query.get('p') or [''])[0])
                    if not path:
                        return self._json(404, {'ok': False})
                    with open(path, 'rb') as f:
                        return self._send(200, f.read(), kind, 'private, max-age=86400')
                if parts.path == '/api/saver/picture':
                    # 7.0.25: a picture of the Screensaver tab (<img> sends no header: key in the URL).
                    if not self._authorized((query.get('k') or [''])[0]):
                        return self._json(403, {'ok': False})
                    from . import phone_saver
                    path = phone_saver.picture_file((query.get('id') or [''])[0])
                    if not path:
                        return self._json(404, {'ok': False})
                    with open(path, 'rb') as f:
                        return self._send(200, f.read(), 'image/jpeg', 'private, max-age=86400')
                if parts.path == '/api/type' and service.only is not None and '/api/type' in service.only:
                    # 7.0.29: the keyboard's heading and text for "Write with phone".
                    if not self._authorized():
                        return self._json(403, {'ok': False, 'error': 'Scan the QR code on your TV again.'})
                    service.touch(connected=True)
                    return self._json(200, dict(service.typing, ok=True))
                if parts.path == '/api/rate' and service.only is not None and '/api/rate' in service.only:
                    # 7.0.45: the title the phone rates
                    if not self._authorized():
                        return self._json(403, {'ok': False, 'error': 'Scan the QR code on your TV again.'})
                    service.touch(connected=True)
                    from .rate_title import kind_label, services
                    return self._json(200, {'ok': True, 'title': service.rating.get('title') or '',
                                            'kind': kind_label(service.rating.get('kind')), 'services': dict(services())})
                if parts.path == '/api/profile' and service.only is not None and '/api/profile' in service.only:
                    # 7.0.45: the profile the phone sets up
                    if not self._authorized():
                        return self._json(403, {'ok': False, 'error': 'Scan the QR code on your TV again.'})
                    service.touch(connected=True)
                    from .user_profiles import get
                    row = get(service.profile) or {}
                    return self._json(200, {'ok': True, 'name': row.get('name') or '', 'pin': bool(row.get('pin')),
                                            'picture': bool(row.get('picture'))})
                if parts.path == '/api/profiles/picture':
                    # 7.0.45: a profile's picture on the Profiles tab (<img>: the key in the URL)
                    if not self._authorized((query.get('k') or [''])[0]):
                        return self._json(403, {'ok': False})
                    from .user_profiles import get
                    path = (get((query.get('id') or [''])[0]) or {}).get('picture') or ''
                    if not path or not os.path.isfile(path):
                        return self._json(404, {'ok': False})
                    with open(path, 'rb') as f:
                        return self._send(200, f.read(), 'image/png' if path.endswith('.png') else 'image/jpeg', 'no-store')
                if parts.path == '/api/ping':
                    # 7.0.42: the open page says it is still there (every minute while it shows)
                    if not self._authorized():
                        return self._json(403, {'ok': False, 'error': 'Scan the QR code on your TV again.'})
                    service.touch(connected=True)
                    return self._json(200, {'ok': True})
                if parts.path == '/api/state':
                    if not self._authorized():
                        return self._json(403, {'ok': False, 'error': 'Scan the QR code on your TV again.'})
                    service.touch(connected=True)
                    return service.respond(self, state)
                return self._json(404, {'ok': False})

            def _upload(self):
                """7.0.25: one piece of a picture / video from the phone (raw bytes, in order)."""
                from . import phone_saver
                from urllib.parse import unquote
                try:
                    length = int(self.headers.get('Content-Length') or 0)
                    if not 0 < length <= phone_saver.CHUNK_MAX:
                        raise ValueError
                    offset = int(self.headers.get('X-Upload-Offset') or -1)
                    total = int(self.headers.get('X-Upload-Total') or 0)
                except ValueError:
                    return self._json(400, {'ok': False, 'error': 'Bad request.'})
                data = self.rfile.read(length)
                service.touch(connected=True)
                return service.respond(self, lambda: phone_saver.receive(
                    self.headers.get('X-Upload-Kind') or '', self.headers.get('X-Upload-Id') or '', offset, total,
                    unquote(self.headers.get('X-Upload-Name') or '')[:200], data,
                    video_token=self.headers.get('X-Upload-Video') or ''))

            def do_POST(self):
                parts = urlsplit(self.path)
                if not self._authorized():
                    return self._json(403, {'ok': False, 'error': 'Scan the QR code on your TV again.'})
                if service.only is not None and parts.path not in service.only:
                    return self._json(404, {'ok': False})
                if parts.path == '/api/saver/upload':
                    return self._upload()
                try:
                    length = int(self.headers.get('Content-Length') or 0)
                    limit=BACKUP_MAX if parts.path=='/api/backup/import' else SAVE_MAX if parts.path in ('/api/badges/save','/api/save','/api/profile','/api/profiles/save') else MAX_BODY
                    if length > limit:
                        raise ValueError
                    body = json.loads(self.rfile.read(length).decode('utf-8') or '{}')
                    if not isinstance(body, dict):
                        raise ValueError
                except (ValueError, UnicodeDecodeError):
                    return self._json(400, {'ok': False, 'error': 'Bad request.'})
                service.touch(connected=True)
                actions = {
                    '/api/addons/add': lambda: add_manifest(body.get('url')),
                    '/api/addons/remove': lambda: remove_provider(body.get('id')),
                    '/api/aio/setup': lambda: aio_quick_setup(body),
                    '/api/free/setup': lambda: free_quick_setup(body.get('url')),
                    '/api/subtitles/opensubtitles': opensubtitles_on,
                    '/api/subtitles/ai': lambda: _ai_toggle(body),
                    '/api/nuvio/login': lambda: nuvio_sign_in(body.get('email') or '', body.get('password') or ''),
                    '/api/nuvio/profiles': nuvio_profiles,
                    '/api/nuvio/profile': lambda: nuvio_select_profile(body.get('index')),
                    '/api/nuvio/logout': nuvio_sign_out,
                    '/api/nuvio/import': lambda: nuvio_import(bool(body.get('collections'))),
                    '/api/collections/source': lambda: home_source_use(body.get('key')),
                    '/api/save': lambda: save(body),
                    '/api/tracking/start': lambda: tracking_start(body.get('service')),
                    '/api/tmdb/key': lambda: tmdb_key(body.get('key')),
                    '/api/keys/set': lambda: api_key_save(body.get('key'), body.get('value')),
                    '/api/badges/save': lambda: _badges_save(body),
                    '/api/badges/toggle': lambda: _badges_toggle(body),
                    '/api/badges/preview': lambda: _badges_preview(body),
                    '/api/badges/set': lambda: _badges_set(body),
                    '/api/tracking/mdblist': lambda: mdblist_connect(body),
                    '/api/tracking/wetrakr': lambda: wetrakr_key(body),
                    '/api/ratings/set': lambda: ratings_set(body),
                    '/api/tracking/check': tracking_check,
                    '/api/stremio/login': lambda: stremio_sign_in(body.get('email') or '', body.get('password') or ''),
                    '/api/stremio/logout': stremio_sign_out,
                    '/api/stremio/import': stremio_import,
                    '/api/stremio/sync': lambda: stremio_keep_in_sync(body.get('on')),
                    '/api/backup/export': lambda: backup_export(body.get('private') is not False),
                    '/api/backup/import': lambda: backup_import(body.get('backup')),
                    '/api/jellyfin/signin': lambda: jellyfin_sign_in(body.get('url'), body.get('username'), body.get('password')),
                    '/api/jellyfin/disconnect': jellyfin_sign_out,
                    '/api/emby/signin': lambda: server_sign_in('emby', body.get('url'), body.get('username'), body.get('password')),
                    '/api/emby/disconnect': lambda: server_sign_out('emby'),
                    '/api/tracking/disconnect': lambda: tracking_disconnect(body.get('service')),
                    # 7.0.25: the Screensaver tab.
                    '/api/saver/scene': lambda: _saver().save_scene(body.get('scene')),
                    '/api/saver/media': lambda: _saver().set_media(body.get('kind'), body.get('picture') or ''),
                    '/api/saver/delete': lambda: _saver().delete(body.get('item')),
                    '/api/saver/cancel': lambda: _saver().cancel(body.get('id')),
                    '/api/saver/preview': lambda: _saver().preview(),
                    '/api/saver/wallpaper': lambda: _saver().set_wallpaper(bool(body.get('on'))),
                    # 7.0.29: Help & diagnostics > Report a problem.
                    '/api/report': lambda: _report(body),
                    # 7.0.29: the keyboard's "Write with phone".
                    '/api/type': lambda: service.receive_text(body.get('text')),
                    # 7.0.45: rate a title (and review it) on Trakt
                    '/api/rate': lambda: service.receive_rating(body),
                    # 7.0.45: a profile's name, picture and PIN
                    '/api/profile': lambda: service.receive_profile(body),
                    # 7.0.45: the main page's Profiles tab
                    '/api/profiles/add': lambda: _profile_add(body),
                    '/api/profiles/save': lambda: _profile_save(body),
                    '/api/profiles/remove': lambda: _profile_remove(body),
                }
                # 9.0.6: the Apps tab - YouTube and Music
                for path in ('/api/youtube/set', '/api/youtube/channel/remove', '/api/music/add', '/api/music/remove',
                             '/api/music/switch', '/api/music/folder', '/api/music/deezer',
                             '/api/music/catalogue', '/api/music/import'):
                    actions[path] = lambda path=path: _apps_action(path, body)
                action = actions.get(parts.path)
                if action is None:
                    return self._json(404, {'ok': False})
                done = service.respond(self, action)
                if done and parts.path in ('/api/save', '/api/report', '/api/type', '/api/rate', '/api/profile'):
                    service.finish()

        try:
            self.server = ThreadingHTTPServer((self.host, PORT if port is None else port), PhoneRequest)
        except OSError:
            if port is not None:
                raise
            self.server = ThreadingHTTPServer((self.host, 0), PhoneRequest)   # fixed port busy
            _log('port %d is busy - this QR code uses port %d' % (PORT, self.server.server_address[1]))
        self.server.daemon_threads = True
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, name='MegaNexusPhoneSetup', daemon=True)

    # -- helpers used by the handler
    def respond(self, handler, action):
        try:
            result = action() or {}
        except ValueError as exc:
            handler._json(200, {'ok': False, 'error': str(exc)})
            return False
        except Exception as exc:
            # 7.0.45: what went wrong is in the log (the kind of error - never a key or password)
            _log('a phone request failed: %s' % type(exc).__name__)
            handler._json(200, {'ok': False, 'error': 'This change could not be completed. Try again.'})
            return False
        result = dict(result);result['ok'] = True
        handler._json(200, result)
        return True

    def receive_text(self, text):
        if not isinstance(text, str) or len(text) > 4000:
            raise ValueError('The text is too long.')
        self.typed = text.replace('\r', '').replace('\n', ' ')   # the keyboard is one line
        return {}

    def receive_rating(self, body):
        from .rate_title import send_to
        self.rated = send_to(self.rating, body.get('rating'), body.get('text') or '', bool(body.get('spoiler')),
                             to_trakt=body.get('trakt', True) is not False, to_tmdb=bool(body.get('tmdb')))
        return self.rated

    def receive_profile(self, body):
        import base64
        from . import user_profiles
        pid = self.profile
        if body.get('name'):
            user_profiles.rename(pid, body.get('name'))
        if body.get('clear_pin'):
            user_profiles.set_pin(pid, '')
        elif body.get('pin'):
            user_profiles.set_pin(pid, body.get('pin'))
        picture = str(body.get('picture') or '')
        if picture:
            try:
                payload = base64.b64decode(picture.split(',', 1)[-1], validate=True)
            except ValueError:
                raise ValueError('The picture could not be read.')
            user_profiles.set_picture(pid, payload)
        return {}

    def touch(self, connected=False):
        with self.lock:
            self.last_seen = time.monotonic()
            if connected:
                self.connected = True

    def finish(self):
        with self.lock:
            self.saved = True

    def page(self):
        with open(self.page_path, 'rb') as f:
            return f.read()

    def locked_page(self):
        return ('<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">'
                '<body style="background:#040F22;color:#DBECFF;font-family:sans-serif;padding:32px">'
                '<h2>MegaNexus</h2><p>Open this page by scanning the QR code shown on your TV.</p></body>')

    def logo(self):
        try:
            path = os.path.join(xbmcaddon.Addon('script.meganexus').getAddonInfo('path'), 'resources', 'media', 'meganexus_wordmark.png')
            with open(path, 'rb') as f:
                return f.read()
        except Exception:
            return b''

    # -- public
    @property
    def url(self):
        return 'http://%s:%d/?k=%s' % (self.host, self.port, self.key)

    @property
    def address(self):
        return 'http://%s:%d' % (self.host, self.port)

    def start(self):
        try:
            from . import phone_saver
            phone_saver.clean_partial()   # 7.0.25: uploads the phone never finished
        except Exception:
            pass
        self.thread.start()
        return self

    def idle(self):
        with self.lock:
            return time.monotonic() - self.last_seen > IDLE_TIMEOUT

    def stop(self):
        try:
            if self.thread.is_alive():
                self.server.shutdown()  # waits for serve_forever; never call from a handler
        finally:
            self.server.server_close()
