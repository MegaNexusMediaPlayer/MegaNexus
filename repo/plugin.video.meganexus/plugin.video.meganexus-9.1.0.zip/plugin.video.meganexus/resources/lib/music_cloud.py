# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Your debrid cloud's music (9.0.6): the audio already in your TorBox or Real-Debrid account, with the
keys of API keys > Debrid - no add-on. A torrent with audio files in it is an album (its name "Artist -
Album (Year) [FLAC]" read for the artist), its audio files the songs; one with a video in it is a film,
not an album. A song's link is asked for only
as it plays (debrid links expire). Nothing is searched for or added to the account here: only what is
in it is listed - an album still being downloaded into it too, with how far it is (played, it says so).
"""
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote

from . import debrid, music

SOURCE = 'cloud'
SERVICES = ('torbox', 'realdebrid')
AUDIO = re.compile(r'\.(?:flac|mp3|m4a|aac|ogg|oga|opus|wav|alac|aiff?|wma|ape|dsf)$', re.I)
KEEP = 600            # s the listing is reused
RD_PAGE, RD_MOST = 100, 300
_lock = threading.Lock()
_reading = threading.Lock()     # 9.0.7: one listing at a time - the app's two cloud rows each read every torrent
_held = {'at': 0.0, 'albums': [], 'tracks': {}, 'keys': ()}


def services():
    """The debrid services with a key whose cloud can be read here."""
    return [s for s in SERVICES if debrid.api_key(s)]


def _album_words(name):
    """'Daft Punk - Discovery (2001) [FLAC 24-96]' -> ('Daft Punk', 'Discovery', '2001')."""
    clean = re.sub(r'[\[(][^\])]*(?:flac|mp3|320|24.?bit|16.?bit|web|cd|vinyl|khz|kbps|deluxe edition)[^\])]*[\])]', '', name, flags=re.I)
    year = re.search(r'\b(19|20)\d{2}\b', clean)
    clean = re.sub(r'[\[(]\s*(19|20)\d{2}\s*[\])]', '', clean)
    clean = re.sub(r'[._]+', ' ', clean).strip(' -')
    artist, _, album = clean.partition(' - ')
    return (artist.strip(), album.strip(), year.group(0) if year else '') if album else ('', clean.strip(), year.group(0) if year else '')


def _song(file_name, number, album, artist, track_id):
    base = file_name.replace('\\', '/').rsplit('/', 1)[-1]
    who, title = music._song_name(base)
    return {'kind': 'track', 'source': SOURCE, 'id': track_id, 'title': title, 'artist': who or artist, 'album': album['title'],
            'picture': album['picture'], 'year': album['year'], 'isrc': '', 'seconds': 0, 'stream': '', 'count': 0,
            'about': '', 'number': number}


def _album(service, item_id, name, count):
    artist, title, year = _album_words(name)
    return {'kind': 'album', 'source': SOURCE, 'id': '%s:%s' % (service, item_id), 'title': title or name, 'artist': artist,
            'picture': '', 'year': year, 'isrc': '', 'seconds': 0, 'stream': '', 'count': count,
            'about': debrid.SERVICES[service]['name']}


def _torbox():
    auth = {'Authorization': 'Bearer ' + debrid.api_key('torbox')}
    listing = (debrid._http(debrid.TORBOX + '/torrents/mylist', params={'bypass_cache': 'true'}, headers=auth) or {}).get('data') or []
    found = []
    for torrent in listing if isinstance(listing, list) else []:
        names = [f.get('name') or '' for f in torrent.get('files') or ()]
        files = sorted((f for f in torrent.get('files') or () if AUDIO.search(f.get('name') or '')), key=lambda f: f.get('name') or '')
        if files and not any(debrid.VIDEO.search(n) for n in names):      # a film's sound tracks are no album
            album = _album('torbox', torrent['id'], torrent.get('name') or '', len(files))
            if not (torrent.get('download_finished') or torrent.get('download_present')):
                # still coming into your cloud: shown, and said so when it is played
                album['waiting'] = int(float(torrent.get('progress') or 0) * 100)
                album['about'] = 'TorBox is downloading it · %d%%' % album['waiting']
            found.append((album, [dict(_song(f.get('name') or '', n, album, album['artist'], '%s:%s' % (album['id'], f.get('id'))),
                                       **({'waiting': album['waiting']} if 'waiting' in album else {}))
                                  for n, f in enumerate(files, 1)]))
    return found


def _realdebrid():
    auth = {'Authorization': 'Bearer ' + debrid.api_key('realdebrid')}
    torrents = []
    for page in range(1, RD_MOST // RD_PAGE + 1):
        part = debrid._http(debrid.REALDEBRID + '/torrents', params={'limit': RD_PAGE, 'page': page}, headers=auth) or []
        torrents += [t for t in part if isinstance(t, dict) and t.get('status') == 'downloaded'] if isinstance(part, list) else []
        if not isinstance(part, list) or len(part) < RD_PAGE:
            break

    def one(torrent):
        try:
            info = debrid._http(debrid.REALDEBRID + '/torrents/info/' + quote(str(torrent['id'])), headers=auth) or {}
        except ValueError:
            return None
        chosen = [f for f in info.get('files') or () if isinstance(f, dict) and f.get('selected')]
        links = info.get('links') or []
        # the links stand for the chosen files, in their order
        songs = [(f, n) for n, f in enumerate(chosen) if AUDIO.search(f.get('path') or '') and n < len(links)]
        if not songs or any(debrid.VIDEO.search(f.get('path') or '') for f in chosen):
            return None
        album = _album('realdebrid', torrent['id'], torrent.get('filename') or '', len(songs))
        return album, [_song(f.get('path') or '', k, album, album['artist'], '%s:%d' % (album['id'], n))
                       for k, (f, n) in enumerate(sorted(songs, key=lambda s: s[0].get('path') or ''), 1)]
    with ThreadPoolExecutor(max_workers=6, thread_name_prefix='MegaNexusMusic') as pool:
        return [a for a in pool.map(one, torrents) if a]


def library(fresh=False):
    """(albums, {album id: songs}) of every cloud with a key - kept for a while."""
    keys = tuple(services())
    with _lock:
        if not fresh and _held['keys'] == keys and time.monotonic() - _held['at'] < KEEP:
            return _held['albums'], _held['tracks']
    with _reading:
        return _read(keys, fresh)


def _read(keys, fresh):
    with _lock:
        if not fresh and _held['keys'] == keys and time.monotonic() - _held['at'] < KEEP:
            return _held['albums'], _held['tracks']          # read meanwhile, by the row that asked first
    albums, tracks = [], {}
    for service, read in (('torbox', _torbox), ('realdebrid', _realdebrid)):
        if service not in keys:
            continue
        try:
            for album, songs in read():
                albums.append(album)
                tracks[album['id']] = songs
        except ValueError as exc:
            import xbmc
            xbmc.log('[MegaNexus] Music: the %s cloud did not answer (%s)' % (debrid.SERVICES[service]['name'], exc), xbmc.LOGWARNING)
    with _lock:
        _held.update(at=time.monotonic(), albums=albums, tracks=tracks, keys=keys)
    return albums, tracks


def known():
    """The cloud's albums as last looked at (while kept), or None when not looked at yet - nothing is asked."""
    with _lock:
        fresh = _held['keys'] == tuple(services()) and time.monotonic() - _held['at'] < KEEP
        return list(_held['albums']) if fresh else None


def link(track_id):
    """The song's link to play now (asked for as it plays - debrid links expire)."""
    service, item_id, file_id = (track_id.split(':', 2) + ['', ''])[:3]
    try:
        if service == 'torbox':
            answer = (debrid._http(debrid.TORBOX + '/torrents/requestdl', params={'token': debrid.api_key('torbox'), 'torrent_id': item_id,
                                                                                  'file_id': file_id}) or {}).get('data')
        elif service == 'realdebrid':
            auth = {'Authorization': 'Bearer ' + debrid.api_key('realdebrid')}
            links = (debrid._http(debrid.REALDEBRID + '/torrents/info/' + quote(item_id), headers=auth) or {}).get('links') or []
            at = int(file_id) if file_id.isdigit() else -1
            if not 0 <= at < len(links):
                raise music.MusicError('That song is no longer in your Real-Debrid cloud.')
            answer = (debrid._http(debrid.REALDEBRID + '/unrestrict/link', method='POST', fields={'link': links[at]}, headers=auth) or {}).get('download')
        else:
            raise music.MusicError('That song is no longer in your cloud.')
    except ValueError as exc:
        raise music.MusicError('%s: %s' % (debrid.SERVICES.get(service, {}).get('name', 'Debrid'), exc))
    if not isinstance(answer, str) or not answer.startswith('http'):
        raise music.MusicError('Your debrid cloud gave no link for this song.')
    return answer


def find(track):
    """The same recording in your cloud, ready to play (music.same: never a nearly one), or None."""
    _, songs = library()
    return next((s for album in songs.values() for s in album if 'waiting' not in s and music.same(track, s)), None)
