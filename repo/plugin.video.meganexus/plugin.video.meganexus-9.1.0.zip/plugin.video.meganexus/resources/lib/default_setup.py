# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Out-of-the-box setup: the MegaNexus Catalog Addon's metadata and catalogs plus default collections.

MegaNexus never blocks on setup. Rules (checked on every MegaNexus entry, cheap):

* Collections the user imported, chose or edited always win (``auto`` layout
  mode cleared by any non-automatic save).
* Otherwise, when an added add-on offers movie/series catalogs, Home is laid
  out from those catalogs; when none does, from the built-in catalog add-on.
* The built-in catalog add-on is always installed. It is switched ON for metadata
  only while the user has no other metadata add-on. If it was switched on
  automatically, adding another metadata add-on switches it OFF again. When the
  user already has their own add-ons, it is added OFF. It always stays in the
  Metadata add-ons list to be switched on or off by hand.

9.0.4: the built-in add-on is Nuvio's TMDB catalog add-on (catalog.nuvio.tv), named
"MegaNexus Catalog Addon", in place of Cinemeta: titles, plots and catalogs in the
language and region chosen in Settings (English, United States at first). Its own
configure page makes one manifest per choice - the plain /manifest.json for
en-US / US, else /{"language":..,"region":..}/manifest.json - and so does MegaNexus.
An installed Cinemeta becomes it (same switches); Cinemeta's automatic Home becomes
its catalogs, poster rows as before.
"""
import hashlib
import json
import os
from urllib.parse import quote

CATALOG_HOST = 'https://catalog.nuvio.tv'
CATALOG_URL = CATALOG_HOST + '/manifest.json'      # English, United States
CATALOG_ID = 'com.nuvio.tmdb.catalogs'
CATALOG_NAME = 'MegaNexus Catalog Addon'          # also addon_registry.SINGLE
CATALOG_GROUP = 'meganexus.catalogs'
LANGUAGE, REGION = 'meganexus_catalog_language', 'meganexus_catalog_region'
DEFAULTS = {'language': 'en-US', 'region': 'US'}
CINEMETA_ID = 'com.linvo.cinemeta'                 # what it replaces (9.0.4)
OLD_GROUPS = ({'cinemeta.catalogs'}, {'cinemeta.discover', 'collections.genres'})   # Cinemeta's automatic Homes

AUTO_LAYOUT = 'meganexus_auto_layout'          # '', 'builtin' ('cinemeta' before 9.0.4) or 'catalogs'
AUTO_LAYOUT_KEY = 'meganexus_auto_layout_key'  # providers the catalog layout was built from
BUILTIN_AUTO = 'meganexus_cinemeta_auto'       # 'true' while it was switched on automatically, 'off' when switched off by hand
MAX_AUTO_FOLDERS = 30


def _resource(name):
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), name)
    with open(path, encoding='utf-8') as stream:
        return json.load(stream)


def options():
    """{'languages': [[code, name]...], 'regions': [...]} - the configure page's own lists."""
    return _resource('catalog_options.json')


def chosen(addon=None):
    """{'language': .., 'region': ..} from Settings, a value the add-on does not offer as its default."""
    if addon is None:
        from .settings_snapshot import cached_addon
        addon = cached_addon()
    lists = options()
    language = addon.getSetting(LANGUAGE)
    region = addon.getSetting(REGION)
    return {'language': language if language in {c for c, _ in lists['languages']} else DEFAULTS['language'],
            'region': region if region in {c for c, _ in lists['regions']} else DEFAULTS['region']}


def catalog_url(choice):
    """The manifest for a language and region, as the add-on's configure page makes it."""
    if choice == DEFAULTS:
        return CATALOG_URL
    segment = quote(json.dumps({'language': choice['language'], 'region': choice['region']}, separators=(',', ':')), safe='')
    return '%s/%s/manifest.json' % (CATALOG_HOST, segment)


def choice_of(url):
    """The language and region a manifest link of the add-on stands for (None: not one of its links)."""
    url = str(url or '')
    if not url.startswith(CATALOG_HOST + '/'):
        return None
    segment = url[len(CATALOG_HOST) + 1:].rsplit('/manifest.json', 1)[0]
    if not segment or segment == 'manifest.json':
        return dict(DEFAULTS)
    try:
        from urllib.parse import unquote
        value = json.loads(unquote(segment))
        return {'language': str(value['language']), 'region': str(value['region'])}
    except (ValueError, KeyError, TypeError):
        return None


def builtin_collections(year=None, manifest=None):
    """Home from the built-in add-on's own catalogs (no account, no setup): one collection
    per catalog that needs no input, its movies and series together."""
    manifest = manifest or bundled_manifest()
    folders, index = [], {}
    for catalog in manifest.get('catalogs') or []:
        if not _usable(catalog):
            continue
        key = catalog['id']
        if key not in index:
            index[key] = {'id': 'catalog.' + key, 'title': str(catalog.get('name') or key), 'sources': []}
            folders.append(index[key])
        index[key]['sources'].append({'addonId': CATALOG_ID, 'catalogId': key, 'type': catalog['type'],
                                      'genre': 'None', 'extra': {}})
    return [{'id': CATALOG_GROUP, 'title': 'MegaNexus Catalog', 'folders': folders}]


def builtin_provider(providers):
    return next((p for p in providers if (p.get('manifest') or {}).get('id') == CATALOG_ID), None)


def bundled_manifest():
    """Snapshot of the add-on's manifest shipped with MegaNexus (works offline)."""
    return _resource('catalog_manifest.json')


def _manifest(url, timeout):
    from .meganexus import addon_wire
    try:
        manifest = addon_wire.get_json(url, ttl_seconds=3600, timeout_override=timeout, retry=False, rate_wait=.25)
    except Exception:
        manifest = bundled_manifest()       # offline: the same catalogs, refreshed next time
    if not isinstance(manifest, dict) or manifest.get('id') != CATALOG_ID:
        raise ValueError('The MegaNexus Catalog Addon did not return its manifest.')
    return manifest


def _point(row, url, manifest):
    """One provider row becomes the built-in add-on at ``url`` - its id (and so its
    switches and place) kept."""
    from .meganexus import addon_registry
    rows = addon_registry.list_providers()
    for entry in rows:
        if entry.get('id') == row['id']:
            entry.update({'name': CATALOG_NAME, 'manifest_url': url, 'base_url': url.rsplit('/manifest.json', 1)[0], 'manifest': manifest})
            row = entry
    addon_registry.store_addons_text(rows)
    return row


def replace_cinemeta(timeout=8):
    """9.0.4: an installed Cinemeta becomes the built-in add-on (once; nothing when there is none).
    Before anything adds the built-in one - Settings opened from the HUB come before Home's entry:
    a new one there, and Cinemeta removed at the entry, lost Cinemeta's switch and place."""
    from .meganexus import addon_registry
    providers = addon_registry.list_providers()
    old = next((p for p in providers if (p.get('manifest') or {}).get('id') == CINEMETA_ID), None)
    if old is None:
        return False
    if builtin_provider(providers) is not None:
        addon_registry.remove_provider(old['id'])
        return True
    url = catalog_url(chosen())
    _point(old, url, _manifest(url, timeout))
    return True


def choose(language, region, timeout=8):
    """Settings: another language or region - the built-in add-on's manifest for it."""
    from .settings_snapshot import cached_addon, invalidate
    addon = cached_addon()
    addon.setSetting(LANGUAGE, language)
    addon.setSetting(REGION, region)
    invalidate()
    from .meganexus import addon_registry
    provider = builtin_provider(addon_registry.list_providers())
    if provider is None:
        return install_builtin(timeout=timeout, enable=False)
    url = catalog_url(chosen(addon))
    return provider if provider.get('manifest_url') == url else _point(provider, url, _manifest(url, timeout))


def install_builtin(timeout=8, enable=True):
    """Add the built-in add-on (if missing) and switch it ON for metadata. Returns the provider.

    The live manifest is preferred; offline, the bundled snapshot is used and
    refreshed the next time the manifest is fetched."""
    from .meganexus import addon_registry
    from . import metadata_providers
    replace_cinemeta(timeout)
    provider = builtin_provider(addon_registry.list_providers())
    added = provider is None
    if added:
        url = catalog_url(chosen())
        provider = addon_registry.add_provider(CATALOG_NAME, url, _manifest(url, timeout))
    if enable and not any(p['id'] == provider['id'] for p in metadata_providers.enabled()):
        metadata_providers.set_enabled(provider['id'], True)
    elif not enable and added:
        # Installed for later use: an untouched switch list would show it ON.
        metadata_providers.set_enabled(provider['id'], False)
    return provider


def _usable(catalog):
    """A catalog Home can load without user input (no required filter/search)."""
    if catalog.get('type') not in ('movie', 'series') or not catalog.get('id'):
        return False
    if catalog.get('extraRequired'):
        return False
    return not any(isinstance(e, dict) and e.get('isRequired') for e in catalog.get('extra') or [])


def catalog_providers(providers):
    """Added add-ons (other than the built-in one) that offer usable movie/series catalogs."""
    from .sports import is_sports_provider
    # 6.0.35 (GitHub issue #8): sports add-ons have their own Sports screen.
    return [p for p in providers
            if (p.get('manifest') or {}).get('id') != CATALOG_ID and not is_sports_provider(p)
            and any(_usable(c) for c in (p.get('manifest') or {}).get('catalogs') or [])]


def catalog_collections(providers):
    """Home layout from the user's own add-ons: one row per add-on, one card per
    catalog (movies and series of the same catalog share a card)."""
    groups = []
    for provider in providers:
        manifest = provider.get('manifest') or {}
        folders, index = [], {}
        for catalog in manifest.get('catalogs') or []:
            if not _usable(catalog):
                continue
            key = catalog['id']
            if key not in index:
                if len(folders) >= MAX_AUTO_FOLDERS:
                    continue
                index[key] = {'id': 'auto.%s.%s' % (provider['id'], key),
                              'title': str(catalog.get('name') or key), 'sources': []}
                folders.append(index[key])
            index[key]['sources'].append({'addonId': manifest.get('id') or '', 'providerId': provider['id'],
                                          'catalogId': key, 'type': catalog['type'], 'genre': 'None'})
        if folders:
            groups.append({'id': 'auto.' + provider['id'],
                           'title': str(provider.get('name') or manifest.get('name') or 'Catalogs'),
                           'folders': folders})
    return groups


def is_builtin_layout(groups):
    """The automatic layout of the built-in add-on - or of Cinemeta before 9.0.4."""
    ids = {g.get('id') for g in groups or []}
    folders = [f.get('id', '') for g in groups or [] for f in g.get('folders') or []]
    return bool(folders) and (ids == {CATALOG_GROUP} and all(f.startswith('catalog.') for f in folders)
                              or ids in OLD_GROUPS and all(f.startswith('cinemeta.') for f in folders))


def is_old_builtin_layout(groups):
    return is_builtin_layout(groups) and {g.get('id') for g in groups} != {CATALOG_GROUP}


def providers_key(providers):
    value = [(p.get('id'), (p.get('manifest') or {}).get('id'),
              [(c.get('id'), c.get('type')) for c in (p.get('manifest') or {}).get('catalogs') or []])
             for p in providers]
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode('utf-8')).hexdigest()[:16]


def add_builtin_off():
    return install_builtin(enable=False)


def apply_defaults(addon, providers, groups, save, install=install_builtin, add=add_builtin_off):
    """Decide the automatic layout and the built-in add-on's switch. Returns what changed."""
    from . import metadata_providers
    changed = []
    mode = addon.getSetting(AUTO_LAYOUT)
    if mode == 'cinemeta' or not mode and groups and is_builtin_layout(groups):
        mode = 'builtin'   # Cinemeta's (made before the mode existed, or named so before 9.0.4)
    own = catalog_providers(providers)
    # Metadata: the built-in add-on only while nothing else is there.
    others = [p for p in metadata_providers.candidates(providers) if (p.get('manifest') or {}).get('id') != CATALOG_ID]
    builtin = builtin_provider(providers)
    found = choice_of((builtin or {}).get('manifest_url'))
    if found and found != chosen(addon):
        # chosen elsewhere (a Nuvio import, the add-on's own link pasted): Settings say so
        addon.setSetting(LANGUAGE, found['language'])
        addon.setSetting(REGION, found['region'])
    if not others:
        if builtin is None or not any(p['id'] == builtin['id'] for p in metadata_providers.enabled(providers=providers)):
            if builtin is None or addon.getSetting(BUILTIN_AUTO) != 'off':
                try:
                    install()
                    addon.setSetting(BUILTIN_AUTO, 'true')
                    changed.append('builtin-on')
                except Exception:
                    pass
    elif builtin is None:
        # Own metadata add-ons exist: the built-in one is still installed, but OFF.
        try:
            add()
            changed.append('builtin-added-off')
        except Exception:
            pass
    elif addon.getSetting(BUILTIN_AUTO) == 'true':
        try:
            metadata_providers.set_enabled(builtin['id'], False)
        except ValueError:
            pass
        addon.setSetting(BUILTIN_AUTO, '')
        changed.append('builtin-off')
    # Layout: user-owned collections are never replaced - known by their own mark beside them (#32), or
    # (made before 9.0.6) by the setting saying nothing
    from . import collection_profile
    if groups and (collection_profile.users_own() or not mode):
        return changed
    if own:
        key = providers_key(own)
        if mode != 'catalogs' or addon.getSetting(AUTO_LAYOUT_KEY) != key or not groups:
            save(catalog_collections(own), auto=True)
            collection_profile.mark_automatic()
            addon.setSetting(AUTO_LAYOUT, 'catalogs')
            addon.setSetting(AUTO_LAYOUT_KEY, key)
            changed.append('layout-catalogs')
    elif mode != 'builtin' or not groups or is_old_builtin_layout(groups):
        save(builtin_collections(manifest=(builtin or {}).get('manifest')), auto=True)
        collection_profile.mark_automatic()
        addon.setSetting(AUTO_LAYOUT, 'builtin')
        changed.append('layout-builtin')
    return changed
