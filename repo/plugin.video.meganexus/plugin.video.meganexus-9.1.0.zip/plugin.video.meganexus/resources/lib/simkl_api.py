# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Local resume is immediate; an account-scoped queue syncs paused progress."""
import json
import re
import os
import time
import tempfile
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

from .meganexus.paths import profile_path
from .meganexus import progress_db
from .texts import tr

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    try:
        from settings_snapshot import cached_addon as _cached_addon
    except Exception:
        _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

API, TOKEN_PATH = 'https://api.simkl.com', os.path.join(profile_path(), 'simkl_token.json')
# Public MegaNexus AUTH V1 registration, app #8268945. No secret is embedded.
DEFAULT_CLIENT_ID = 'b22385a5a145d47e2713d73e3a843f6d73e0e9c45ccea961613060a72499b0a7'
# Existing tokens keep their issuing app until a replacement PIN is approved.
LEGACY_CLIENT_ID = '7c5c3e3c74fa28dd639ca8b09da8f5e48d46ee7c3ea86d284c56bee4a0a09643'
PIN_URL_FALLBACK = 'https://simkl.com/pin'

_PUBLIC_CACHE, _PUBLIC_CACHE_TTL = {}, 300      # public lookups, five minutes
_MARKED_THIS_SESSION = set()

# Simkl's lists: a film is only planned, done or dropped; a show can also be on or on hold
STATUSES_MOVIES = ('plantowatch', 'completed', 'dropped')
STATUSES_SHOWS = ('watching', 'plantowatch', 'hold', 'completed', 'dropped')
KINDS = ('movies', 'shows', 'anime')


def _setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


def enabled():
    return (_setting('enable_simkl', 'true') or 'true').lower() == 'true'


def client_id():
    configured=_setting('simkl_client_id', '').strip()
    return (DEFAULT_CLIENT_ID if configured==LEGACY_CLIENT_ID else configured or DEFAULT_CLIENT_ID).strip()


def token_client_id(data=None):
    data=token_data() if data is None else data
    return str(data.get('client_id') or _setting('simkl_client_id','').strip() or LEGACY_CLIENT_ID)


def needs_app_relink():
    data=token_data()
    return bool(data.get('access_token') and token_client_id(data)==LEGACY_CLIENT_ID)


def credentials_configured():
    return bool(client_id())


def mark_watched_enabled():
    return (_setting('simkl_mark_watched', 'true') or 'true').lower() == 'true'


def watched_at_percent():
    try:
        value = float(_setting('simkl_watched_threshold', '85') or 85)
    except Exception:
        value = 85.0
    return max(50.0, min(99.0, value))


def ensure_enabled():
    try:
        if not enabled():
            ADDON.setSetting('enable_simkl', 'true')
    except Exception:
        pass


def _read_json(path, default):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return default


def _write_json(path, value):
    temporary = None
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(path), delete=False) as handle:
            temporary = handle.name
            json.dump(value, handle)
        try: os.chmod(temporary, 0o600)
        except OSError: pass
        os.replace(temporary, path)
        return True
    except Exception:
        return False
    finally:
        if temporary and os.path.exists(temporary):
            try: os.remove(temporary)
            except OSError: pass


def token_data():
    return _read_json(TOKEN_PATH, {})


def save_token(data):
    data=dict(data or {})
    if data.get('access_token'):data.setdefault('client_id',client_id())
    return _write_json(TOKEN_PATH, data)


def clear_token():
    try:
        if os.path.exists(TOKEN_PATH):
            os.remove(TOKEN_PATH)
    except Exception:
        pass


def authorized():
    return bool((token_data() or {}).get('access_token'))


def authorization_status():
    if authorized():
        return 'connected'
    return 'ready' if credentials_configured() else 'needs_api'


def _headers(auth=False):
    """Simkl wants its API key on every call; a signed call carries the token and the key of
    the app it was issued to."""
    sent = {'Content-Type': 'application/json', 'simkl-api-key': client_id(),
            'User-Agent': 'MegaNexus/%s (Kodi)' % (ADDON.getAddonInfo('version') or '8.1.0')}
    if auth:
        signed = token_data() or {}
        if not signed.get('access_token'):
            raise RuntimeError(tr('Simkl account is not linked'))
        sent.update({'Authorization': 'Bearer %s' % signed['access_token'], 'simkl-api-key': token_client_id(signed)})
    return sent


def _request(path, payload=None, method='GET', auth=False, timeout=20):
    """Simkl's JSON answer ({} for an empty body); the app's id, name and version go in the query."""
    sent = _headers(auth=auth)
    parts = urllib.parse.urlsplit(API + path)
    query = dict(urllib.parse.parse_qsl(parts.query, keep_blank_values=True),
                 client_id=sent['simkl-api-key'], **{'app-name': 'meganexus-hub',
                                                    'app-version': ADDON.getAddonInfo('version') or '8.1.0'})
    asked = urllib.request.Request(urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(query))),
                                   data=json.dumps(payload).encode('utf-8') if payload is not None else None,
                                   headers=sent, method=method)
    try:
        with urllib.request.urlopen(asked, timeout=timeout) as answer:
            body = answer.read().decode('utf-8', 'ignore')
    except urllib.error.HTTPError as exc:
        if auth and exc.code == 401 and enabled():   # 9.0.0: the sign-in was withdrawn on Simkl
            from .account_notice import signed_out
            signed_out('Simkl', (token_data() or {}).get('access_token') or '')
        raise
    return json.loads(body) if body else {}


def _cached_request(path, auth=True, timeout=20):
    """A GET kept _PUBLIC_CACHE_TTL seconds (lists are read several times while one screen opens)."""
    kept = _PUBLIC_CACHE.get(path)
    if kept and time.time() - kept[0] <= _PUBLIC_CACHE_TTL:
        return kept[1]
    answer = _request(path, method='GET', auth=auth, timeout=timeout)
    _PUBLIC_CACHE[path] = (time.time(), answer)
    return answer


def invalidate_cache(prefix=''):
    for path in [path for path in _PUBLIC_CACHE if path.startswith(prefix)]:
        _PUBLIC_CACHE.pop(path, None)


def _pin_prompt_text(verify_url, user_code, remaining=None):
    """PIN first: Kodi's progress textbox only has room for a few lines.

    Keep this compact; progress updates can reset the skin's text autoscroll.
    Never put the actual pairing code below instructions or blank spacer lines.
    """
    lines = [
        '[B]PIN: %s[/B]' % user_code,
        'Open on your phone: %s' % verify_url,
    ]
    if remaining is not None:
        lines.append('Enter the PIN and approve. Time remaining: %ss' % max(0,int(remaining)))
    else:
        lines.append('Enter the PIN and approve the connection.')
    return '\n'.join(lines)


def _pin_code():
    try:
        return _request('/oauth/pin?client_id=%s' % urllib.parse.quote(client_id()), method='GET', auth=False) or {}
    except urllib.error.HTTPError as exc:
        try:
            detail = exc.read().decode('utf-8', 'ignore')
        except Exception:
            detail = ''
        raise RuntimeError(tr('Simkl code request failed (%s): %s') % (exc.code, detail[:200]))
    except Exception as exc:
        raise RuntimeError(tr('Could not reach Simkl: %s') % exc)


def device_auth():
    """Link Simkl with a PIN: the code is shown (dialog, notification, then a progress dialog
    counting down) while Simkl is asked every few seconds whether the user entered it. True
    once linked; False when cancelled or expired."""
    ensure_enabled()
    if not credentials_configured():
        raise RuntimeError(tr('Enter a Simkl Client ID in settings first (from simkl.com/settings/developer)'))
    pin = _pin_code()
    code = str(pin.get('user_code') or '').strip()
    if not code:
        raise RuntimeError(tr('Simkl did not return a valid pairing code'))
    address = str(pin.get('verification_url') or PIN_URL_FALLBACK)
    every, lasts = max(5, int(pin.get('interval') or 5)), max(60, int(pin.get('expires_in') or 900))
    title = tr('MegaNexus • Link Simkl')
    try:
        xbmcgui.Dialog().ok(title, tr(_pin_prompt_text(address, code)))
    except Exception as exc:
        xbmc.log('[MegaNexus] simkl Dialog.ok fallback: %s' % exc, xbmc.LOGWARNING)
    xbmc.executebuiltin('Notification(MegaNexus,Simkl code: %s,10000)' % code)
    waiting = xbmcgui.DialogProgress()
    waiting.create(title, tr(_pin_prompt_text(address, code, remaining=lasts)))
    check = '/oauth/pin/%s?client_id=%s' % (urllib.parse.quote(code), urllib.parse.quote(client_id()))
    began = time.time()
    try:
        while not waiting.iscanceled() and time.time() - began < lasts:
            spent = time.time() - began
            waiting.update(int(max(0, min(100, spent / float(lasts) * 100))),
                           tr(_pin_prompt_text(address, code, remaining=int(lasts - spent))))
            try:
                answer = _request(check, method='GET', auth=False)
                if isinstance(answer, dict) and answer.get('access_token'):
                    save_token({'access_token': answer['access_token'], 'created_at': int(time.time())})
                    waiting.close()
                    xbmcgui.Dialog().notification('MegaNexus', tr('Simkl linked successfully'), xbmcgui.NOTIFICATION_INFO, 3000)
                    invalidate_cache()
                    return True
            except urllib.error.HTTPError as exc:
                if exc.code == 429:                      # asked too often: wait twice as long
                    every = max(every, 5) * 2
                elif exc.code not in (400, 404):         # 400 / 404: not entered yet
                    xbmc.log('[MegaNexus] simkl poll http %s' % exc.code, xbmc.LOGWARNING)
            except Exception as exc:
                xbmc.log('[MegaNexus] simkl poll transient error: %s' % exc, xbmc.LOGWARNING)
            xbmc.sleep(every * 1000)
    finally:
        try:
            waiting.close()
        except Exception:
            pass
    return False


def logout():
    clear_token()
    invalidate_cache()
    _MARKED_THIS_SESSION.clear()
    return True


# ─── ids / payload helpers ──────────────────────────────────────────────────

def _ids_from_ctx(ctx):
    """{imdb, tmdb, tvdb} of an item, as Simkl writes them (IMDb with its tt)."""
    ctx = ctx or {}
    ids = dict((name, str(ctx.get(name + '_id') or '').strip()) for name in ('imdb', 'tmdb', 'tvdb'))
    if ids['imdb'] and not ids['imdb'].startswith('tt'):
        ids['imdb'] = 'tt' + ids['imdb']
    return dict((name, value) for name, value in ids.items() if value)


def add_to_library(ctx):
    """Save a whole title to Simkl Plan to Watch; never mark episodes watched."""
    if not authorized():raise ValueError('Connect Simkl in HUB Settings first.')
    ids = _ids_from_ctx(ctx)
    if not ids:raise ValueError('This title has no IMDb, TMDb or TVDb ID for Simkl.')
    kind = 'shows' if ctx.get('media_type') in ('series','tv','show','tvshow','anime','episode') else 'movies'
    item = {'ids':ids, 'title':ctx.get('title') or '', 'to':'plantowatch'}
    response = _request('/sync/add-to-list', payload={kind:[item]}, method='POST', auth=True, timeout=8)
    if not isinstance(response, dict) or response.get('error') or any((response.get('not_found') or {}).values()):
        raise ValueError('Simkl could not match this title. Nothing was confirmed as saved.')
    added = response.get('added') or {}
    if not isinstance(added, dict) or not any(
            (isinstance(added.get(k), list) and bool(added[k])) or
            (isinstance(added.get(k), (int,float)) and added[k]>0) for k in (kind,'anime')):
        raise ValueError('Simkl did not confirm saving this title. Check your Plan to Watch list and retry.')
    invalidate_cache('/sync/all-items')
    return True


# ─── lists ──────────────────────────────────────────────────────────────────

def _node_from_row(row, kind):
    """The title inside a list row ('movie' for films, 'show' for shows and anime)."""
    return (row.get('movie' if kind == 'movies' else 'show') or {}) if isinstance(row, dict) else {}


def clean_items(data, kind):
    """A /sync/all-items answer as list rows (titles without any id left out)."""
    if not isinstance(data, dict):
        return []
    rows = data.get(kind)
    if rows is None and kind == 'anime':
        rows = data.get('anime') or data.get('shows')
    found = []
    for row in rows or []:
        title = _node_from_row(row, kind)
        ids = dict((name, str((title.get('ids') or {}).get(name) or '').strip()) for name in ('imdb', 'tmdb', 'tvdb')) \
            if title else {}
        if not any(ids.values()):
            continue
        year = title.get('year') or ''
        found.append(dict({
            '_type': 'movie' if kind == 'movies' else 'show', 'title': title.get('title') or '', 'year': year,
            'release_year': year, 'overview': title.get('overview') or '', 'ids': ids,
            '_status': str(row.get('status') or ''), 'poster': poster_url(title.get('poster')),
            'watched_episodes_count': int(row.get('watched_episodes_count') or 0),
            'total_episodes_count': int(row.get('total_episodes_count') or 0)},
            **dict((field, str(row.get(field) or '')) for field in (
                'last_watched', 'next_to_watch', 'last_watched_at', 'added_to_watchlist_at'))))
    return found


_FAIL_LOG_MEMO = {}


def all_items(kind='shows', status='watching'):
    """One of the user's lists (watching, plan to watch, …); [] when unavailable - the same
    failure is logged as a warning once an hour."""
    if not enabled():
        return []
    kind = kind if kind in KINDS else 'shows'
    allowed = STATUSES_MOVIES if kind == 'movies' else STATUSES_SHOWS
    status = status if status in allowed else allowed[0]
    try:
        answer = _cached_request('/sync/all-items/%s/%s?extended=full' % (kind, status), auth=True)
    except Exception as exc:
        mark = '%s|%s|%s' % (kind, status, str(exc)[:60])
        again = time.time() - float(_FAIL_LOG_MEMO.get(mark) or 0.0) <= 3600
        if not again:
            _FAIL_LOG_MEMO[mark] = time.time()
        xbmc.log('[MegaNexus] simkl all_items(%s,%s) failed%s: %s' % (kind, status, ' (repeat)' if again else '', exc),
                 xbmc.LOGDEBUG if again else xbmc.LOGWARNING)
        return []
    return clean_items(answer, kind)


def poster_url(slug):
    slug = str(slug or '').strip()
    return ('https://simkl.in/posters/%s_m.jpg' % slug) if slug else ''


_EP_MARKER_RE = re.compile(r's\s*(\d+)\s*e\s*(\d+)', re.I)


def parse_episode_marker(value):
    """'S02E05' / 's2e5' -> (2, 5); None for anything else."""
    found = _EP_MARKER_RE.search(str(value or ''))
    return (int(found.group(1)), int(found.group(2))) if found else None


def _canonical_for(ids):
    """Our item id: tt…, else tmdb:…, else tvdb:…."""
    imdb, tmdb, tvdb = (str(ids.get(name) or '').strip() for name in ('imdb', 'tmdb', 'tvdb'))
    if imdb:
        return imdb if imdb.startswith('tt') else 'tt' + imdb
    return 'tmdb:' + tmdb if tmdb else 'tvdb:' + tvdb if tvdb else ''


def take_watched(limit=1000):
    """(films, episodes) marked watched locally: completed films, and for shows / anime every
    episode of the season up to the last one watched."""
    if not (enabled() and authorized()):
        raise RuntimeError(tr('Simkl account is not linked'))
    from .meganexus import progress_db
    films = episodes = 0
    finished = all_items('movies', 'completed')[:max(1, int(limit))]
    try:   # 9.0.1: marks an earlier import dated itself get Simkl's real date first
        progress_db.correct_bulk_stamps({key: _epoch(row.get('last_watched_at')) for row in finished
                                         for key in (_canonical_for(row.get('ids') or {}),
                                                     str((row.get('ids') or {}).get('imdb') or '').lower()) if key})
    except Exception as exc:
        xbmc.log('[MegaNexus] simkl: watched dates not corrected: %s' % exc, xbmc.LOGWARNING)
    for row in finished:
        item = _canonical_for(row.get('ids') or {})
        if item:
            try:
                progress_db.mark_watched('movie', item, item, mark_dirty=False, at=_epoch(row.get('last_watched_at')))
                films += 1
            except Exception as exc:
                xbmc.log('[MegaNexus] simkl movie import failed for %s: %s' % (item, exc), xbmc.LOGDEBUG)
    for kind in ('shows', 'anime'):
        for status in ('watching', 'completed', 'hold'):
            for row in all_items(kind, status):
                item, last = _canonical_for(row.get('ids') or {}), parse_episode_marker(row.get('last_watched'))
                if not (item and last):
                    continue
                for number in range(1, last[1] + 1):
                    try:
                        progress_db.mark_watched('series', item, '%s:%s:%s' % (item, last[0], number), mark_dirty=False,
                                                 at=_epoch(row.get('last_watched_at')))
                        episodes += 1
                    except Exception:
                        pass
    return films, episodes


def sync_continue_watching(limit=50):
    """Import actual paused playback, never fabricate a next episode at zero."""
    return sync_playback_progress(limit)


def watchlist_copy_rows(limit=200):
    """Plan to Watch of films, shows and anime as Library mirror rows."""
    if not (enabled() and authorized()):
        return []
    rows = []
    for kind, media_type in (('movies', 'movie'), ('shows', 'series'), ('anime', 'series')):
        for row in all_items(kind, 'plantowatch')[:limit]:
            item = _canonical_for(row.get('ids') or {})
            if item:
                rows.append({'media_type': media_type, 'canonical_id': item, 'title': row.get('title') or '',
                             'poster': row.get('poster') or '', 'background': '', 'clearlogo': '',
                             'year': row.get('year') or 0, 'plot': row.get('overview') or '',
                             'added_at': _epoch(row.get('added_to_watchlist_at'))})
    return rows


def _epoch(value):
    from datetime import datetime
    try:
        return int(datetime.fromisoformat(str(value).replace('Z', '+00:00')).timestamp()) if value else 0
    except (ValueError, TypeError, OverflowError):
        return 0

# True playback progress (Simkl Scrobble API). All HTTP runs on the service
# reporter/idle worker; the durable, account-scoped queue survives restarts.
import hashlib
import threading
_SCROBBLE_LOCK = threading.Lock()
_SCROBBLE_RETRY_AT = 0.0


def _progress_account():
    token = (token_data() or {}).get('access_token') or ''
    return hashlib.sha256(token.encode('utf-8')).hexdigest() if token else ''


def progress_payload(ctx, position_ms):
    ids = _ids_from_ctx(ctx)
    duration = float(ctx.get('duration_ms') or 0)
    if not ids or duration <= 0:
        return None
    percent = 100 if ctx.get('meganexus_completed_by_user') else round(max(0, min(100, float(position_ms or 0) * 100 / duration)), 2)
    title = {'ids': ids, 'title': ctx.get('show_title') or ctx.get('title') or ''}
    data = {'progress': percent}
    if ctx.get('media_type') in ('series', 'show', 'tv', 'anime', 'episode'):
        try: season, episode = int(ctx.get('season')), int(ctx.get('episode'))
        except (ValueError, TypeError): return None
        if season < 0 or episode < 1: return None
        data['anime' if ctx.get('media_type') == 'anime' else 'show'] = title
        data['episode'] = {'season': season, 'number': episode}
    else:
        data['movie'] = title
    return data


def queue_progress(ctx, position_ms, event='pause'):
    if not enabled(): return False
    account = _progress_account()
    payload = progress_payload(ctx, position_ms)
    if not account or not payload: return False
    # Simkl's stop threshold is 80%. Pause preserves 80–94.99% as resumable.
    from .meganexus.paths import SIMKL_WATCHED_PERCENT
    action = 'stop' if payload['progress'] >= SIMKL_WATCHED_PERCENT and mark_watched_enabled() else 'pause'
    if event == 'start' and payload['progress'] < 95: action = 'start'
    from . import continue_local
    key = continue_local.identity(ctx)
    # Each completed episode must survive starting the next episode offline.
    if payload.get('episode'):
        key += '|%s:%s' % (payload['episode']['season'],payload['episode']['number'])
    conn = continue_local.connect()
    try:
        conn.execute('INSERT OR REPLACE INTO meganexus_simkl_outbox VALUES (?, ?, ?, ?)',
                     (account, key, time.time(), json.dumps({'action': action, 'body': payload})))
        conn.execute('DELETE FROM meganexus_simkl_outbox WHERE account=? AND identity NOT IN (SELECT identity FROM meganexus_simkl_outbox WHERE account=? ORDER BY updated DESC LIMIT 50)', (account, account))
        conn.commit()
    finally: conn.close()
    return True


def flush_progress():
    global _SCROBBLE_RETRY_AT
    if not enabled() or time.monotonic() < _SCROBBLE_RETRY_AT: return 0
    account = _progress_account()
    if not account or not _SCROBBLE_LOCK.acquire(False): return 0
    count = 0
    try:
        from . import continue_local
        conn = continue_local.connect()
        try: rows = conn.execute('SELECT identity, updated, payload FROM meganexus_simkl_outbox WHERE account=? ORDER BY updated LIMIT 5', (account,)).fetchall()
        finally: conn.close()
        for key, stamp, raw in rows:
            if _progress_account() != account: break
            data = json.loads(raw)
            try:
                _request('/scrobble/' + data['action'], data['body'], method='POST', auth=True, timeout=6)
            except urllib.error.HTTPError as exc:
                # 9.0.7: 404 - "Requested item ID does not exist" (Simkl's scrobble reference) - is as
                # final as 409: Simkl will never take it. It was kept and asked again first every
                # minute, so every playback queued behind it waited until 50 newer ones pushed it out.
                if exc.code not in (404, 409):
                    try:delay=max(60,min(3600,float(exc.headers.get('Retry-After') or 60)))
                    except (ValueError,TypeError,AttributeError):delay=60
                    _SCROBBLE_RETRY_AT = time.monotonic() + delay
                    break
            except Exception:
                _SCROBBLE_RETRY_AT = time.monotonic() + 60
                break
            conn = continue_local.connect()
            try:
                # Never delete a newer event saved during the request.
                conn.execute('DELETE FROM meganexus_simkl_outbox WHERE account=? AND identity=? AND updated=?', (account, key, stamp))
                conn.commit()
            finally: conn.close()
            count += 1
        return count
    finally: _SCROBBLE_LOCK.release()


def sync_playback_progress(limit=50):
    if not (enabled() and authorized()): return 0
    from . import trakt_api
    account = _progress_account()
    data = _request('/sync/playback?limit=%d&hide_watched=true' % min(50, max(1, int(limit))), auth=True, timeout=8)
    if not isinstance(data, list) or account != _progress_account(): return 0
    rows = []
    for entry in data:
        if not isinstance(entry,dict):continue
        node = entry.get('movie') or entry.get('show') or entry.get('anime') or {}
        ids = node.get('ids') or {}; mid = _canonical_for(ids)
        try: percent = float(entry.get('progress') or 0)
        except (TypeError, ValueError): continue
        stamp = trakt_api._parse_trakt_ts(entry.get('paused_at'))
        if not mid or not 0 < percent < 95 or not stamp: continue
        episode = entry.get('episode') or {}
        series = bool(episode)
        season = episode.get('tvdb_season', episode.get('season'))
        number = episode.get('tvdb_number', episode.get('number', episode.get('episode')))
        if series and (season is None or number is None): continue
        rows.append(dict(media_type='series' if series else 'movie',canonical_id=mid,
            video_id='%s:%s:%s' % (mid, season, number) if series else mid,
            title=node.get('title') or 'Loading title…',provider_name='Simkl',
            poster=poster_url(node.get('poster')) if node.get('poster') else '',
            season=season,episode=number,position=0,duration=0,percent=percent,
            event_type='progress',ext_updated_at=stamp,imdb_id=ids.get('imdb') or '',
            tmdb_id=ids.get('tmdb') or '',tvdb_id=ids.get('tvdb') or ''))
    if account != _progress_account():return 0
    changed = progress_db.keep_rows(rows, mark_dirty=False)
    if changed:
        from .simkl_watched import _invalidate_view
        _invalidate_view()
    return changed
