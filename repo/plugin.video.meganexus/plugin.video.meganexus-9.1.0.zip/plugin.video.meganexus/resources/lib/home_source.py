# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Where Home's collections come from (9.0.6) - one set on Home, chosen on the phone (Collections) or the
TV (HUB Settings > Collections & Home rows > Home shows):

* Your collections - imported from Nuvio or a JSON file, or made here;
* the MegaNexus Catalog - the built-in add-on's own catalogs;
* one add-on's catalogs - any add-on with movie or series catalogs (AIOMetadata, BingeCat, ...).

Then the rows and cards of that set are shown, hidden and ordered as before (the phone's Collections,
the TV's Home rows and cards). Switching away from your collections keeps them aside (OWN_BACKUP), and
"Your collections" brings them back. A set chosen here is yours: no automatic layout replaces it.
"""
import json

OWN_BACKUP = 'collections-own-backup.json'   # 7.0.42: your collections while another set shows
OWN, BUILTIN, ADDON = 'own', 'builtin', 'addon:'


def _kept_path():
    from . import collection_profile
    return collection_profile.profile_file().with_name(OWN_BACKUP)


def kept():
    """Your collections kept aside ([] when none)."""
    try:
        data = json.loads(_kept_path().read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []
    return data if isinstance(data, list) else []


def current(groups=None):
    """What Home shows now: OWN, BUILTIN, ADDON + the add-on's id, or '' (nothing yet)."""
    from . import collection_profile, default_setup
    groups = collection_profile.load() if groups is None else groups
    if not groups:
        return ''
    if default_setup.is_builtin_layout(groups):
        return BUILTIN
    if len(groups) == 1 and str(groups[0].get('id') or '').startswith('auto.'):
        return ADDON + groups[0]['id'][len('auto.'):]
    return OWN


SHOWN_CARDS = 30         # an add-on's cards shown at first; the rest are there, hidden, to switch on


def _offered(catalog):
    """A movie or series catalog Home can load: nothing it requires, or only a genre it lists "None" for
    (Nuvio's word for no filter - AIOMetadata requires a genre on every catalog and offers "None")."""
    from .sports import is_sports_catalog
    if catalog.get('type') not in ('movie', 'series') or not catalog.get('id') or catalog.get('extraRequired'):
        return False
    if is_sports_catalog(catalog.get('type'), catalog.get('id'), catalog.get('name')):
        return False
    for extra in catalog.get('extra') or []:
        if isinstance(extra, dict) and extra.get('isRequired'):
            if extra.get('name') != 'genre' or 'None' not in (extra.get('options') or []):
                return False
    return True


def addon_groups(provider):
    """One add-on's catalogs as Home's one set: a card per catalog (its movies and series together),
    the first SHOWN_CARDS shown."""
    from . import default_setup
    manifest = (provider or {}).get('manifest') or {}
    if not provider or manifest.get('id') == default_setup.CATALOG_ID:
        return []
    cards, index = [], {}
    for catalog in manifest.get('catalogs') or []:
        if not _offered(catalog):
            continue
        key = catalog['id']
        if key not in index:
            index[key] = {'id': 'auto.%s.%s' % (provider['id'], key), 'title': str(catalog.get('name') or key),
                          'sources': [], 'hidden': len(cards) >= SHOWN_CARDS}
            cards.append(index[key])
        index[key]['sources'].append({'addonId': manifest.get('id') or '', 'providerId': provider['id'],
                                      'catalogId': key, 'type': catalog['type'], 'genre': 'None'})
    if not cards:
        return []
    return [{'id': 'auto.' + provider['id'], 'title': str(provider.get('name') or manifest.get('name') or 'Catalogs'),
             'folders': cards}]


def choices(providers=None):
    """[(key, name, detail)] - the sets Home can show, yours first when you have one."""
    from . import collection_profile
    from .meganexus import addon_registry
    providers = addon_registry.list_providers() if providers is None else providers
    groups = collection_profile.load()
    own = groups if current(groups) == OWN else kept()
    out = []
    if own:
        cards = sum(len(g.get('folders') or []) for g in own)
        out.append((OWN, 'Your collections', '%d card%s · imported or made by you' % (cards, '' if cards == 1 else 's')))
    out.append((BUILTIN, 'MegaNexus Catalog', 'Built-in · trending, popular and more'))
    for provider in providers:
        groups = addon_groups(provider)
        if groups:
            count = len(groups[0]['folders'])
            out.append((ADDON + provider['id'], str(provider.get('name') or provider['id']),
                        '%d catalog%s of this add-on' % (count, '' if count == 1 else 's')))
    return out


def use(key, providers=None, install=None):
    """Home shows the set ``key`` (choices()). Returns its number of cards; 0 when it shows already.
    ValueError when there is no such set. ``install``: the built-in add-on's setup (offline: its
    bundled catalogs are used)."""
    from . import collection_profile, default_setup
    from .meganexus import addon_registry
    providers = addon_registry.list_providers() if providers is None else providers
    now = current()
    if key == now:
        return 0
    if key == OWN:
        groups = kept()
        if not groups:
            raise ValueError('You have no collections of your own yet: import them from Nuvio or a JSON file, '
                             'or create one from your catalogs.')
    elif key == BUILTIN:
        try:
            (install or default_setup.install_builtin)()
        except Exception:
            pass                     # offline: the bundled catalogs, they load when it answers
        builtin = default_setup.builtin_provider(addon_registry.list_providers())
        groups = default_setup.builtin_collections(manifest=(builtin or {}).get('manifest'))
    elif key.startswith(ADDON):
        groups = addon_groups(next((p for p in providers if p.get('id') == key[len(ADDON):]), None))
        if not groups:
            raise ValueError('This add-on has no movie or series catalogs Home can show.')
    else:
        raise ValueError('Choose where Home\'s collections come from.')
    if now == OWN:
        from .meganexus.json_files import write_json
        write_json(str(_kept_path()), collection_profile.load())      # yours, kept aside
    return collection_profile.save(groups)            # your choice: no automatic layout replaces it
