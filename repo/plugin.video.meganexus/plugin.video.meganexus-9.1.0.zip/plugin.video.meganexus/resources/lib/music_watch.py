# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Music app's song beside the rest of Kodi (9.0.6), watched by the MegaNexus service:

* a trailer or a YouTube video starting takes Kodi's one player - the song is not lost: where it was
  (the queue's place, the second) is kept (RESUME) and the music waits, paused, by the profile; the
  small player's Play goes on from there (meganexus_ui/music.py resume()). 9.0.8: a film, an episode,
  an IPTV channel or a Live Sport stream ends the music instead (end()) - a song from YouTube is a
  video nobody sees, and one coming back after them switched the TV's mode again;
* one song into the next as on music services: the last seconds go softly down, the next song starts a
  moment before the end and comes softly up (Kodi's own crossfade is for its audio player only - a song
  from YouTube plays as a video); a volume you set meanwhile is yours and the fade gives way;
* the screensaver comes while a song plays - Kodi starts none while a video plays, and a song from
  YouTube comes as one - once Kodi has been left alone for its screensaver time; the song plays on.
"""
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

from .music_play import FROM, KEYS, LOADING, MISSED, PICTURE, PLAYING, QUEUED, ROUND, STARTED

CHECK = 1.0          # s between two looks
SOFT = .2            # ... while a song fades out or in
FADE_OUT = 8.0       # s: the song's end goes down over these
EARLY = 1.0          # s before its end the next song is started (its quiet last second)
FADE_IN = 3.0        # s: the next song comes up over these
SHORT = 30.0         # s: a song shorter than this is not faded
OPENING = 15.0       # s the next song may take to open; then your volume is given back as it is
GONE = OPENING       # s another playback holds the player before the last song's mark goes (Gone)
NEXT = ('next', None)
KEPT = 'special://profile/addon_data/plugin.video.meganexus/music_volume.json'   # your volume while it fades
RESUME = 'meganexus.music.resume'     # {pos, time, title, artist}: the song another playback took the player from
# 9.0.7: an IPTV channel is never our song - it has a MusicPlayer.Title too (its programme): with the mark of a song
# still set, the channel was taken for it (its programme's last seconds faded down, Next and the screensaver
# came over the channel) and a channel taking the player never left the song waiting
SONG = ('!String.IsEmpty(Window(Home).Property(meganexus.music.playing)) + !String.IsEmpty(MusicPlayer.Title) + Player.HasMedia'
        ' + !PVR.IsPlayingTV + !PVR.IsPlayingRadio')
SAVER = (SONG + ' + Player.HasVideo + Player.Playing + !System.ScreenSaverActive + !Window.IsActive(fullscreenvideo)'
         ' + String.IsEmpty(Window(10000).Property(meganexus.saver.active))')   # not already up


def _minutes():
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                                                           'params': {'setting': 'screensaver.time'}})))
        return float((reply.get('result') or {}).get('value') or 0)
    except (TypeError, ValueError):
        return 0.0


def due(idle, minutes, playing):
    """Whether the screensaver is due now: a song plays and Kodi has been idle for its screensaver time."""
    return bool(playing and minutes and idle >= minutes * 60)


def where():
    """The song that plays now: its place in the queue, its second, its words (None: no song plays)."""
    if not xbmc.getCondVisibility(SONG):
        return None
    try:
        player = xbmc.Player()
        return {'pos': xbmc.PlayList(xbmc.PLAYLIST_MUSIC).getposition(), 'time': player.getTime(),
                'total': player.getTotalTime(), 'paused': xbmc.getCondVisibility('Player.Paused'),
                'title': xbmc.getInfoLabel('MusicPlayer.Title'), 'artist': xbmc.getInfoLabel('MusicPlayer.Artist')}
    except Exception:
        return None


BACK_JUMPS, JUMP_WINDOW = 2, 8.0    # a song that leaps back this often within this many seconds is stuck (the Cube froze 5 s in)


class Stuck:
    """A song the player keeps throwing back - YouTube refusing its stream and the player seeking round and round
    (on the Fire TV Cube that froze the whole box, 2026-11-03): it goes, the next one comes."""

    def __init__(self):
        self.song, self.time, self.jumps = None, 0.0, []

    def step(self, now, clock):
        if now is None or now['paused']:
            self.song = None
            return False
        song = (now['pos'], now['title'])
        if song != self.song:
            self.song, self.time, self.jumps = song, now['time'], []
            return False
        if now['time'] < self.time - 2:
            self.jumps = [t for t in self.jumps if clock - t < JUMP_WINDOW] + [clock]
        self.time = now['time']
        if len(self.jumps) < BACK_JUMPS:
            return False
        xbmc.log('[MegaNexus] Music: the song keeps jumping back (its stream refused) - the next one', xbmc.LOGWARNING)
        self.song, self.jumps = None, []
        if ahead():
            next_song()
        else:
            xbmc.executebuiltin('PlayerControl(Stop)')
        return True


def step(last, home, now):
    """One look (``now``: where()): the song's place kept while it plays; another playback in its place -
    the song waits (RESUME); nothing plays any more - nothing waits. Returns the place to keep."""
    if now is not None:
        for name in (RESUME, RESUME + '.title', RESUME + '.artist'):
            home.clearProperty(name)
        return now
    if not xbmc.getCondVisibility('Player.HasMedia'):
        return None
    # 9.0.8: asked again while the song waits - a film still opening is not yet known as one (its item comes
    # with its start), and a film after a trailer that paused the song ends it as well
    if (last is not None or home.getProperty(RESUME)) and ends_music(home):
        end(home)
        return None
    if last is not None:
        home.setProperty(RESUME, json.dumps(last))       # a trailer, a video took the player
        home.setProperty(RESUME + '.title', last.get('title') or '')
        home.setProperty(RESUME + '.artist', last.get('artist') or '')
        home.clearProperty('meganexus.music.playing')
        xbmc.log('[MegaNexus] Music: paused for another playback - it goes on from %d s' % int(last['time']), xbmc.LOGINFO)
    return None


LIVE = 'PVR.IsPlayingTV | PVR.IsPlayingRadio'    # an IPTV channel


def ends_music(home):
    """9.0.8: what took the player ends the music rather than pausing it: an IPTV channel, a Live Sport stream
    (its hold of the TV's mode, refresh_guard 'sports') or a MegaNexus film or episode (the playing item is the
    request play_jobs started, as foreground_guard tells). A trailer, the YouTube app's video, Kodi's own
    video: the song waits as before."""
    if xbmc.getCondVisibility(LIVE):
        return True
    try:
        from . import foreground_guard, refresh_guard
        return 'sports' in refresh_guard._holders(home) or foreground_guard._ours(xbmc.Player(), home)
    except Exception:
        return False


def end(home):
    """9.0.8: the music is over - its queue and marks go (as the app's stop_music(), without stopping the
    player: the film or the channel has it now), nothing waits to go on. Kodi's music queue is emptied through
    JSON-RPC (Python let go)."""
    for key in json.loads(home.getProperty(KEYS) or '[]'):
        home.clearProperty(QUEUED + key)
    for name in (KEYS, PLAYING, MISSED, FROM, PICTURE, ROUND, RESUME, RESUME + '.title', RESUME + '.artist'):
        home.clearProperty(name)
    xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Playlist.Clear', 'params': {'playlistid': 0}}))
    xbmc.log('[MegaNexus] Music: ended - a film or a channel took the player', xbmc.LOGINFO)


class Gone:
    """9.0.7: the mark of the song that played (PLAYING) goes once another playback has held the player for GONE
    seconds without a song of ours. Only stop_music() and a playback taking our song's place (step()) took it
    away: a song stopped by the remote, a queue at its end or given up left it set for good, and the next IPTV
    channel or anything else with a MusicPlayer.Title counted as our song - the music by the profile and its one
    dot video window over the channel. Never while nothing plays (a song may be opening) or a song is being
    found (LOADING); GONE counts from the last look our song played or its last start (STARTED) - a song still
    opening while a film has the player keeps its mark."""

    def __init__(self):
        self.mark, self.since = None, 0.0

    def step(self, home, now, clock):
        mark = (home.getProperty(PLAYING), home.getProperty(STARTED))
        if now is not None or not mark[0] or home.getProperty(LOADING) or mark != self.mark:
            self.mark, self.since = mark, clock
            return False
        if clock - self.since < GONE or not xbmc.getCondVisibility('Player.HasMedia'):
            return False
        home.clearProperty(PLAYING)
        self.mark = None
        xbmc.log('[MegaNexus] Music: another playback holds the player - the last song is no longer marked as playing', xbmc.LOGINFO)
        return True


def _volume():
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Application.GetProperties',
                                                           'params': {'properties': ['volume']}})))
        return int((reply.get('result') or {}).get('volume'))
    except (TypeError, ValueError):
        return None


def _set_volume(value):
    xbmc.executebuiltin('SetVolume(%d)' % value)       # (no volume bar on the screen)


def next_song():
    """The queue's next song, asked without waiting: the player's own "play next" call waits for Kodi's main thread while it
    holds Python - with the main thread in Python too (a screen's own code), Kodi 21 stood still for good (the
    Fire TV Cube, 2026-11-03: this thread in Player::playnext, the main thread waiting for Python)."""
    xbmc.executebuiltin('PlayerControl(Next)')


def _song(now):
    return (now.get('pos'), now.get('title'))


class Fade:
    """The soft way from one song into the next (step() at each look). Your own volume is kept on disk while
    it is low, so even Kodi closing in the middle never leaves it low (back())."""

    def __init__(self):
        self.yours = None     # your volume, given back after the fade
        self.set = None       # the volume the fade set last
        self.song = None      # the song that fades out
        self.rise = None      # when the next song began to come up
        self.went = 0.0       # when it was started

    def busy(self):
        return self.yours is not None

    def _to(self, value):
        value = max(0, min(self.yours, int(round(value))))
        if value != self.set:
            _set_volume(value)
            self.set = value

    def _done(self, give_back=True):
        if give_back and self.yours is not None and self.set != self.yours:
            _set_volume(self.yours)
        self.yours = self.set = self.song = self.rise = None
        try:
            xbmcvfs.delete(KEPT)
        except Exception:
            pass

    def step(self, now, ahead):
        """``now``: where() - the song that plays (None: none); ``ahead``: another song follows it."""
        if self.busy():
            volume = _volume()
            if volume is not None and volume != self.set:
                return self._done(give_back=False)          # you set the volume: it is yours
            if now is None:
                # the next song opens (the volume stays low a moment); anything else - a film - has it back
                opening = self.song == NEXT and xbmc.getCondVisibility('Player.HasMedia') and time.monotonic() - self.went < OPENING
                return None if opening else self._done()
            if _song(now) == self.song:
                if now['paused']:
                    return None
                left = now['total'] - now['time']
                if left > FADE_OUT + 1:
                    return self._done()                     # you went back in the song
                self._to(self.yours * max(0.0, left - EARLY) / (FADE_OUT - EARLY))
                if left <= EARLY and ahead:
                    self.song, self.went = NEXT, time.monotonic()   # the next one, a moment early
                    next_song()
                return None
            if now['time'] < .3 or now['paused']:
                return None                                 # the next song has not begun yet
            self.rise = self.rise or time.monotonic()
            share = (time.monotonic() - self.rise) / FADE_IN
            if share >= 1:
                return self._done()
            self._to(self.yours * share)
            return None
        if now is None or now['paused'] or now['total'] < SHORT:
            return None
        if now['total'] - now['time'] <= FADE_OUT and now['total'] - now['time'] > EARLY:
            yours = _volume()
            if yours:
                self.yours, self.set, self.song = yours, yours, _song(now)
                _keep(yours)
        return None


def _keep(volume):
    try:
        folder = os.path.dirname(xbmcvfs.translatePath(KEPT))
        os.makedirs(folder, exist_ok=True)
        with open(xbmcvfs.translatePath(KEPT), 'w') as handle:
            json.dump({'volume': volume}, handle)
    except OSError:
        pass


def back():
    """Kodi was closed while a song faded: your volume, given back (the service's start)."""
    try:
        with open(xbmcvfs.translatePath(KEPT)) as handle:
            volume = int(json.load(handle)['volume'])
    except (OSError, ValueError, KeyError, TypeError):
        return
    _set_volume(volume)
    xbmcvfs.delete(KEPT)


def ahead():
    """Whether another song follows the one that plays (Repeat one: the same song again - no early start)."""
    if xbmc.getCondVisibility('Playlist.IsRepeatOne'):
        return False
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    return playlist.getposition() < playlist.size() - 1 or xbmc.getCondVisibility('Playlist.IsRepeat | Playlist.IsRandom')


def run(monitor):
    home, last, minutes, read = xbmcgui.Window(10000), None, 0.0, 0
    fade, clock, stuck, gone = Fade(), 0.0, Stuck(), Gone()
    back()
    while not monitor.waitForAbort(SOFT):
        try:
            now = where()
            if fade.busy() or (now and not now['paused'] and now['total'] - now['time'] <= FADE_OUT + 1):
                fade.step(now, ahead())
            clock += SOFT
            if clock < CHECK:
                continue
            clock = 0.0
            last = step(last, home, now)
            stuck.step(now, time.monotonic())
            gone.step(home, now, time.monotonic())
            read = (read + 1) % 30
            if not read:
                minutes = _minutes()
            if due(xbmc.getGlobalIdleTime(), minutes, xbmc.getCondVisibility(SAVER)):
                # Kodi starts its screensaver and stops it again half a second later while a video plays (the
                # Cube, 2026-11-03: every second, never seen) - so the MegaNexus screensaver opens as a screen
                # of its own, until a key, as its "Show on TV" does
                xbmc.log('[MegaNexus] Music: the screensaver, over the song that plays on', xbmc.LOGINFO)
                xbmc.executebuiltin('RunScript(script.meganexus,saverpreview)')
        except Exception as exc:
            xbmc.log('[MegaNexus] Music watch skipped: %r' % exc, xbmc.LOGWARNING)
