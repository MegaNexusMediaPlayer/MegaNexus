# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Home's Watchlist and Next episodes rows (9.0.8).

A user: "the watchlist is buried in the Library section ... Continue Watching only shows things
that have been started" - Trakt's "next episodes" (season 3 out after season 2 was finished)
showed nowhere. Two Home rows, OFF until switched on (HUB Settings > Collections & Home rows >
Home rows, or the phone's Collections tab); switched on, a row comes right under Continue
Watching, and is then moved or hidden like the rows around it:

* Watchlist - one tracking service's watchlist (Trakt, Simkl, MDBList, WeTrakr: the copy the
  Library keeps of them, library_titles.refresh_list_copy) or the whole Library ("All (as
  Library)", library.everything) - the Library's own cards.
* Next episodes - one card per show: the next episode not watched yet that is out (a new
  season's first too), from Trakt (its Up Next), Simkl (its "next to watch" of the shows you
  watch) or MegaNexus history (the shows played here or synced in, without Continue Watching's
  period; the metadata add-ons' episode lists, as Continue Watching's next episode). A show
  Continue Watching shows is never here as well (under any of its ids, GitHub #31), nor one
  removed from Continue Watching; an episode out tomorrow only with "Show unaired next episodes".
  A card plays as Continue Watching's next-episode card does.

"Rows from" (FROM) offers only what can fill the row now - a connected service, All (as
Library), MegaNexus history; "Automatic" is Trakt when it is connected, else All (as Library) /
MegaNexus history. A service no longer connected is Automatic's again, never an empty row.

Where a row stands (ORDER, e.g. "watchlist:0,next_episodes:2"): after that many of your
collections' Home rows - 0 is right under Continue Watching, before Local and the media
servers' rows; at one place in the order given. Your collections' file is never touched for it
(GitHub #32: your own layout is never rebuilt).

Speed: Home is built from the cards kept in home_tracking_rows.json (one small file, no
network). The row's load - a Home worker - works them out again from the local stores; a
service due again (FRESH) is asked on a thread of its own behind Home, and its cards follow
into the row where they stand (home_window._set_rows: nothing moves under the cursor). A row
whose kept cards are none is not drawn (as Local's rows); a row just switched on, or given
another source, is drawn at once with empty cards until its first answer.
"""
import hashlib
import json
import os
import threading
import time

WATCHLIST, NEXT = 'watchlist', 'next_episodes'
ROWS = (WATCHLIST, NEXT)          # their order under Continue Watching until moved
TITLES = {WATCHLIST: 'Watchlist', NEXT: 'Next episodes'}
SHOW = {WATCHLIST: 'meganexus_home_watchlist', NEXT: 'meganexus_home_next_episodes'}    # off by default
FROM = {WATCHLIST: 'meganexus_watchlist_from', NEXT: 'meganexus_next_episodes_from'}
ORDER = 'meganexus_home_rows_order'
AUTO, ALL, HISTORY = 'auto', 'all', 'history'
SERVICES = ('trakt', 'simkl', 'mdblist', 'wetrakr')
NAMES = {AUTO: 'Automatic', ALL: 'All (as Library)', 'trakt': 'Trakt', 'simkl': 'Simkl', 'mdblist': 'MDBList',
         'wetrakr': 'WeTrakr', HISTORY: 'MegaNexus history'}
# the Library copies these two services' lists only while their switch is on (library_titles.refresh_list_copy)
COPIED = {'simkl': 'watchlist_merge_simkl', 'mdblist': 'watchlist_merge_mdblist'}
NEXT_FROM = ('trakt', 'simkl')    # the services that say which episode is next
SERIES_TYPES = ('series', 'tv', 'show', 'anime')
CARDS = 40                # a row's cards at most
SHOWS = 40                # MegaNexus history: the shows looked at, watched last first
UP_NEXT_SHOWS = 30        # Trakt: the shows asked (one request each)
HISTORY_READ = 1500       # MegaNexus history: the playbacks read to find those shows
FRESH = 1800              # s a service's answer stands before it is asked again (the service's watchlist copy: 30 min too)
RETRY = 300               # s before a service that gave no answer is asked again
EPISODES_LIFE = 86400     # s a show's kept episode list stands here (Continue Watching asks its own shows hourly)
ASK_EPISODES = 12         # shows whose episode list is asked for in one refresh (watch_nextup.AT_ONCE at a time)
FILE = 'home_tracking_rows.json'          # per profile (user_profiles.FILES); a cache: no backup
MIRROR_MARK = 'meganexus.mirror.last'     # Window(Home): when the watchlist copy was made (hub_service sets it too)
_LOCK = threading.RLock()
_MEM = {}
_RUNNING = {}             # job -> the callbacks waiting for its answer
_TRIED = {}               # job -> when it last gave no answer
_STOP = threading.Event()


def _log(text, level=None):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Home rows: ' + text, xbmc.LOGWARNING if level is None else level)
    except Exception:
        pass


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_snapshot import cached_addon
    return cached_addon()


def stop():
    """script_exit: a question still running behind Home ends at its next step (Kodi waits for every
    thread of a script that ends)."""
    _STOP.set()


# ---- the settings ------------------------------------------------------------------------------

def shown(row, addon=None):
    """Switched on for Home - off until the user switches it on."""
    try:
        return _addon(addon).getSetting(SHOW[row]) == 'true'
    except Exception:
        return False


def _connected():
    """The tracking services signed in now (no network: their kept sign-ins), in the Library's order."""
    try:
        from . import library
        return [tid for tid, _ in library.connected_trackers()]
    except Exception:
        return []


def _automatic(row, connected):
    return 'trakt' if 'trakt' in connected else (ALL if row == WATCHLIST else HISTORY)


def sources(row, addon=None, connected=None):
    """[(key, name)] "Rows from" offers - only what can fill the row now: a connected service (for the
    Watchlist one whose list the Library copies), All (as Library) / MegaNexus history; Automatic
    first, named by what it is now."""
    addon = _addon(addon)
    connected = _connected() if connected is None else connected
    if row == WATCHLIST:
        found = [s for s in connected if s in SERVICES and (s not in COPIED or
                 (addon.getSetting(COPIED[s]) or 'true').strip().lower() == 'true')] + [ALL]
    else:
        found = [s for s in NEXT_FROM if s in connected] + [HISTORY]
    return [(AUTO, 'Automatic · ' + NAMES[_automatic(row, connected)])] + [(key, NAMES[key]) for key in found]


def picked(row, addon=None, connected=None):
    """The choice as it stands: the one made while it can still fill the row, else AUTO."""
    addon = _addon(addon)
    value = (addon.getSetting(FROM[row]) or AUTO).strip().lower()
    return value if value != AUTO and value in [k for k, _ in sources(row, addon, connected)] else AUTO


def chosen(row, addon=None):
    """The source the row is made from now (AUTO resolved)."""
    connected = _connected()
    value = picked(row, addon, connected)
    return _automatic(row, connected) if value == AUTO else value


def source_name(row, addon=None):
    """'Trakt', 'Automatic · Trakt' - what "Rows from" says."""
    addon = _addon(addon)
    value = picked(row, addon)
    return dict(sources(row, addon)).get(value, NAMES[AUTO])


def choose(row, key, addon=None):
    """"Rows from" set to ``key`` (one of sources())."""
    addon = _addon(addon)
    if key not in [k for k, _ in sources(row, addon)]:
        raise ValueError('That service cannot fill this row now - connect it first (HUB Settings > Accounts).')
    addon.setSetting(FROM[row], '' if key == AUTO else key)


def order(addon=None):
    """[(row, place)] of both rows - the place: how many of the collections' groups come before it."""
    raw = str(_addon(addon).getSetting(ORDER) or '')
    out, seen = [], set()
    for part in raw.split(','):
        name, _, place = part.strip().partition(':')
        if name in ROWS and name not in seen:
            try:
                number = max(0, int(place))
            except ValueError:
                number = 0
            out.append((name, number))
            seen.add(name)
    return out + [(name, 0) for name in ROWS if name not in seen]


def _write_order(entries, addon=None):
    _addon(addon).setSetting(ORDER, ','.join('%s:%d' % (name, int(place)) for name, place in entries))


def switch(row, on, addon=None):
    """On or off for Home. Switched on it goes right under Continue Watching (the first at place 0)."""
    addon = _addon(addon)
    addon.setSetting(SHOW[row], 'true' if on else 'false')
    if on:
        _write_order([(row, 0)] + [(name, place) for name, place in order(addon) if name != row], addon)


def merged(group_ids, entries, on):
    """The Home rows editors' list in Home's order: ('row', name) / ('group', id) - a row that is on
    stands after the first ``place`` groups (in ``entries`` order at one place)."""
    tokens = []
    rows = [(name, place) for name, place in entries if name in on]
    for index in range(len(group_ids) + 1):
        tokens += [('row', name) for name, place in rows if min(place, len(group_ids)) == index]
        if index < len(group_ids):
            tokens.append(('group', group_ids[index]))
    return tokens


def split(tokens):
    """[(row, place)] from a merged list - the place counts the groups above it."""
    out, groups = [], 0
    for kind, value in tokens:
        if kind == 'group':
            groups += 1
        else:
            out.append((value, groups))
    return out


def move(row, step, group_ids, addon=None):
    """One step up (-1) or down (+1) among the Home rows - past the other row or a group of your
    collections. False when it is off or at an end."""
    addon = _addon(addon)
    entries = order(addon)
    on = [name for name in ROWS if shown(name, addon)]
    tokens = merged(list(group_ids), entries, on)
    if ('row', row) not in tokens:
        return False
    here = tokens.index(('row', row))
    there = here + step
    if not 0 <= there < len(tokens):
        return False
    tokens[here], tokens[there] = tokens[there], tokens[here]
    _write_order(split(tokens) + [(name, place) for name, place in entries if name not in on], addon)
    return True


def move_group(group_id, step, group_ids, addon=None):
    """9.0.9: a group of your collections one step up (-1) or down (+1) among the Home rows, on the TV as
    on the phone - past the next group, or past a Watchlist / Next episodes row standing there (that
    row's place moves the other way). The groups' new order ([id]); None at an end."""
    addon = _addon(addon)
    entries = order(addon)
    on = [name for name in ROWS if shown(name, addon)]
    tokens = merged(list(group_ids), entries, on)
    if ('group', group_id) not in tokens:
        return None
    here = tokens.index(('group', group_id))
    there = here + step
    if not 0 <= there < len(tokens):
        return None
    tokens[here], tokens[there] = tokens[there], tokens[here]
    _write_order(split(tokens) + [(name, place) for name, place in entries if name not in on], addon)
    return [value for kind, value in tokens if kind == 'group']


def where(row, groups, addon=None):
    """Where the row stands, in words: 'under Continue Watching', 'after Movies' (``groups``: the
    collections' groups as collection_profile.load gives them)."""
    addon = _addon(addon)
    if not shown(row, addon):
        return 'not on Home'
    place = min(dict(order(addon)).get(row, 0), len(groups))
    if not place:
        return 'under Continue Watching'
    return 'after ' + str(groups[place - 1].get('title') or 'your collections')


def apply(rows, entries, addon=None):
    """The phone's Home rows: ``rows`` [{id, on, from}], ``entries`` [[id, place]] as the page has them
    (it put a row switched on right under Continue Watching itself). What is not known is left out.
    Returns the rows switched on now."""
    addon = _addon(addon)
    started = []
    for item in rows if isinstance(rows, list) else []:
        name = item.get('id') if isinstance(item, dict) else None
        if name not in ROWS:
            continue
        on = bool(item.get('on'))
        if on and not shown(name, addon):
            started.append(name)
        addon.setSetting(SHOW[name], 'true' if on else 'false')
        key = str(item.get('from') or AUTO)
        if key in [k for k, _ in sources(name, addon)]:
            addon.setSetting(FROM[name], '' if key == AUTO else key)
    if isinstance(entries, list):
        kept = []
        for entry in entries:
            try:
                name, place = entry[0], max(0, int(entry[1]))
            except (TypeError, ValueError, IndexError, KeyError):
                continue
            if name in ROWS and name not in [n for n, _ in kept]:
                kept.append((name, place))
        if kept:
            _write_order(kept + [(name, place) for name, place in order(addon) if name not in [n for n, _ in kept]], addon)
    return started


# ---- what is kept ------------------------------------------------------------------------------

def _path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), FILE)


def _read():
    """The kept file (read-only: _keep writes a new one); re-read when it changed."""
    path = _path()
    try:
        stamp = os.stat(path).st_mtime_ns
    except OSError:
        return {}
    with _LOCK:
        if _MEM.get('key') == (path, stamp):
            return _MEM['data']
        try:
            with open(path, encoding='utf-8') as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            data = {}
        data = data if isinstance(data, dict) else {}
        _MEM.update(key=(path, stamp), data=data)
        return data


def _keep(section, key, value):
    from .meganexus.json_files import write_json
    with _LOCK:
        data = dict(_read())
        part = dict(data.get(section) or {})
        part[key] = value
        data[section] = part
        try:
            write_json(_path(), data)
        except Exception as exc:
            _log('not kept: %s' % exc)
        _MEM.clear()


def _account(service):
    """Whose answer it is - never the sign-in itself: another account's kept answer is not shown.
    Trakt: its user (kept beside the sign-in once trakt_watched asked for it); Simkl: its sign-in's
    hash, as simkl_watched keeps its own."""
    try:
        if service == 'trakt':
            from . import trakt_api
            user = str(trakt_api.token_data().get('meganexus_user') or '')
            return hashlib.sha256(user.encode('utf-8')).hexdigest() if user else ''
        if service == 'simkl':
            from . import simkl_watched
            return simkl_watched._account()
    except Exception:
        pass
    return ''


def _same(kept, now):
    """One account - or one of them unknown (Trakt's user is learned later)."""
    return not (kept and now and kept != now)


def _key(row, source):
    return '%s|%s' % (row, source)


def _kept_cards(row, source):
    """The row's cards as last worked out ([] for none), or None when never for this source and account."""
    entry = (_read().get('cards') or {}).get(_key(row, source))
    if not isinstance(entry, dict) or not isinstance(entry.get('rows'), list):
        return None
    if source in SERVICES and not _same(entry.get('account') or '', _account(source)):
        return None
    return entry['rows']


def _job(row, source):
    """What is asked for this row: the Library's copy of the watchlists, or the service itself."""
    return 'mirror' if row == WATCHLIST else source


def _asked(job):
    """When the job last gave its answer (0: never, or another account's)."""
    raw = (_read().get('raw') or {}).get(job) or {}
    when = float(raw.get('at') or 0) if _same(raw.get('account') or '', _account(job)) else 0.0
    if job == 'mirror':
        try:
            import xbmcgui
            when = max(when, float(xbmcgui.Window(10000).getProperty(MIRROR_MARK) or 0))
        except Exception:
            pass
    return when


def _raw_rows(service):
    """The kept answer of Trakt / Simkl for this account, or None when it never answered here."""
    raw = (_read().get('raw') or {}).get(service)
    if not isinstance(raw, dict) or not isinstance(raw.get('rows'), list):
        return None
    if not _same(raw.get('account') or '', _account(service)):
        return None
    return raw['rows']


# ---- the cards ---------------------------------------------------------------------------------

def loading():
    """An empty card while the row's first answer comes (as a catalog row's)."""
    from .home_data import placeholder
    return placeholder(' ', '')


def nothing(row, source=''):
    """The one card of a row with nothing in it (drawn only until Home is built again)."""
    from .home_data import placeholder
    name = NAMES.get(source or '', '')
    if row == WATCHLIST:
        if source in SERVICES:
            return placeholder('Your %s watchlist is empty' % name, 'Titles you add to your %s watchlist show here.' % name)
        return placeholder('Your Library is empty', 'Long-press a title anywhere in MegaNexus and choose Add to Library.')
    return placeholder("You're all caught up", 'The next episode of each show you watch shows here once it is out.')


def unanswered(row, source):
    from .home_data import placeholder
    if row == WATCHLIST:
        return placeholder('Watchlist not loaded yet', 'Your services did not answer. It is asked again in a few minutes.')
    return placeholder('%s did not answer' % NAMES.get(source, 'The service'), 'It is asked again in a few minutes.')


def _title_card(card):
    """A Library card (library._card) as a Home card - opens the title's page."""
    from . import library
    target = dict(card.get('target') or {})
    kind = 'movie' if target.get('media_type') == 'movie' else 'series'
    cid = str(target.get('canonical_id') or '')
    title = str(card.get('title') or cid)
    year = str(card.get('year') or '') if card.get('year') else ''
    target.update(media_type=kind, canonical_id=cid, title=title)
    if cid.startswith('tt'):
        target['imdb_id'] = cid.split(':')[0]
    elif cid.startswith('tmdb:'):
        target['tmdb_id'] = cid.split(':', 1)[1]
    return {'title': title, 'subtitle': year, 'poster': card.get('poster') or '', 'fanart': card.get('fanart') or '',
            'landscape': card.get('landscape') or card.get('fanart') or '', 'clearlogo': card.get('clearlogo') or '',
            'plot': card.get('plot') or '',
            'meta_line': '  |  '.join(x for x in ('Series' if kind == 'series' else 'Movie', year,
                                                    library.added_label(card.get('added_at'))) if x),
            'target': target, 'is_folder': False}


def episode_card(raw, tomorrow=False):
    """A Next episodes card - Continue Watching's next-episode card (watch_nextup.next_card): it plays the
    episode (its video id), or opens the title's page for one out tomorrow."""
    season, number = int(raw.get('season') or 0), int(raw.get('episode') or 0)
    cid = str(raw.get('canonical_id') or '')
    title = str(raw.get('title') or cid)
    year = str(raw.get('year') or '')[:4] if raw.get('year') else ''
    target = {'media_type': 'series', 'canonical_id': cid, 'video_id': raw.get('video_id') or '%s:%s:%s' % (cid, season, number),
              'season': season, 'episode': number, 'resume_seconds': 0, 'title': title}
    for column in ('imdb_id', 'tmdb_id', 'tvdb_id'):
        value = str(raw.get(column) or '').strip()
        if value and value not in ('0', 'None'):
            target[column] = value
    if tomorrow:
        target['details_view'] = True
    episode = 'S%s · E%s' % (season, number)
    poster = raw.get('poster') or ''
    if not poster:
        try:
            from . import library
            poster = library._poster({'canonical_id': cid, 'media_type': 'series'})
        except Exception:
            poster = ''
    return {'title': title, 'subtitle': 'S%s • E%s' % (season, number),
            'meta_line': '  |  '.join(x for x in ('Series', year, episode, str(raw.get('episode_title') or '')) if x),
            'poster': poster, 'fanart': raw.get('background') or '', 'landscape': raw.get('background') or '',
            'clearlogo': raw.get('clearlogo') or '', 'plot': raw.get('plot') or '',
            'target': target, 'percent_value': 0, 'is_folder': False,
            'airing_banner': 'Tomorrow • New episode' if tomorrow else 'Next episode', 'tomorrow': '1' if tomorrow else '',
            'shape': 'poster', 'continue_card': 'next', 'last_watched_at': int(raw.get('last_watched_at') or 0)}


def card_keys(card, deep=False):
    """Every id the card's title goes by (GitHub #31): its own, its IMDb / TMDB / TVDB ids, and for a
    series its name - as Continue Watching makes one card of one title (continue_metadata.dedupe).
    ``deep``: also the IMDb id kept for a TMDB id (a file read: never while drawing)."""
    from .meganexus import progress_db
    from .continue_metadata import metadata_identity, _missing_title
    target = card.get('target') or {}
    kind = 'movie' if target.get('media_type') == 'movie' else 'series'
    keys = progress_db.title_keys(dict(target, media_type=kind))
    mt, cid = metadata_identity(dict(target, media_type=kind))
    if cid:
        keys.add((kind, cid))
    title = str(card.get('title') or '').strip().casefold()
    if kind == 'series' and title and not _missing_title(title) and not title.startswith('saved '):
        keys.add((kind, 'title:' + title))
    if deep:
        try:
            from .continue_metadata import _keys
            keys |= _keys(card, network=False)
        except Exception:
            pass
    keys.discard((kind, ''))
    return keys


def continue_keys(rows, deep=False):
    """The titles Continue Watching shows (``rows``: its cards). ``deep``: with every id their
    playbacks are saved under too (one read of the playback store - a worker's)."""
    keys = set()
    for row in rows or ():
        if isinstance(row, dict) and row.get('target'):
            keys |= card_keys(row, deep)
    if deep and keys:
        try:
            from .meganexus import progress_db
            for played in progress_db.list_recent_items(limit=400):
                found = progress_db.title_keys(played)
                if found & keys:
                    keys |= found
        except Exception:
            pass
    return keys


def covered(entry, season, episode, out, last_day):
    """Watched: marked one by one, or under a whole-show or season mark that cannot be older than it - the episode
    was out (``out``) by the day the show was last watched (``last_day``; watch_nextup.next_card's rule: "all aired
    episodes watched" never covers a season out after it)."""
    if '%s:%s' % (season, episode) in (entry.get('episodes') or []):
        return True
    scope = entry.get('watched') or str(season) in (entry.get('seasons') or [])
    return bool(scope and (not out or (last_day and out <= last_day)))


def _last_day(entry, card):
    """The day the show was last watched: its card's, or its newest episode watched mark (any service's)."""
    from datetime import datetime
    stamps = [card.get('last_watched_at') or 0] + list((entry.get('episode_watched_at') or {}).values())
    try:
        newest = max(float(stamp or 0) for stamp in stamps)
        return datetime.fromtimestamp(newest).date() if newest > 0 else None
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def still_next(cards):
    """Next episodes cards that still stand: one per show, not removed from Continue Watching (under
    any of the show's ids), the episode not marked watched since."""
    from . import continue_rules, simkl_watched, watch_nextup
    removed = continue_rules.snapshot()
    states = simkl_watched.snapshot()
    kept = watch_nextup._read()
    out, seen = [], set()
    for card in cards or ():
        target = card.get('target') or {}
        cid = str(target.get('canonical_id') or '')
        keys = card_keys(card)
        if not cid or keys & seen:
            continue
        others = sorted(value for _, value in keys if value != cid and not value.startswith('title:'))
        if continue_rules.hidden('series', cid, card.get('last_watched_at') or 0, removed, others):
            continue
        # 9.0.8: a whole-show mark counts too (Monster: watched to the end on Trakt, Simkl's next was S3E3 - the season
        # out a year before it was watched: the card stood); a season out after the show was last watched still shows
        entry = simkl_watched.state(states, 'series', cid)
        if covered(entry, target.get('season'), target.get('episode'), _release(kept, cid, target), _last_day(entry, card)):
            continue
        seen |= keys
        out.append(card)
    return out


def visible(row, cards, continue_rows=(), deep=False):
    """The cards to draw: for Next episodes the ones that still stand and whose show Continue Watching
    does not show. Copies: the kept ones stay as kept, whatever a screen does with its cards."""
    if row != NEXT:
        return [dict(card) for card in cards or []]
    shown_there = continue_keys(continue_rows, deep)
    return [dict(card) for card in still_next(cards) if not card_keys(card) & shown_there]


def _watchlist(source):
    """The Watchlist's cards: the whole Library, or the titles of one service's watchlist (the
    Library's copy); newest first."""
    from . import library
    if source == ALL:
        cards = library.everything()
    else:
        from . import library_titles
        origins = library._origins()
        cards, seen = [], set()
        for item in library_titles.list_favorites(limit=5000, source=library.TRACKING) or []:
            if source not in library.places_of(item, library.TRACKING, origins):
                continue
            card = library._card(item)
            card['year'] = int(item.get('year') or 0)
            same = library._same_title(card['target']['media_type'], item.get('canonical_id'))
            if same in seen:
                continue
            seen.add(same)
            cards.append(card)
        cards.sort(key=lambda card: int(card.get('added_at') or 0), reverse=True)
    return [_title_card(card) for card in cards[:CARDS]]


def _mirror_known(source):
    """The Library's copy holds this service's list: it was made, or holds a title of it."""
    if source == ALL or _asked('mirror'):
        return True
    try:
        from . import library
        return any(source in (value if isinstance(value, list) else [value]) for value in library._origins().values())
    except Exception:
        return False


def following(meta, last, entry, today=None, unaired=True):
    """(episode, out tomorrow) after the one played last - the season's next, else the next season's
    first - when it is out (``unaired``: or out tomorrow); None otherwise. ``entry``: the show's
    watched marks (simkl_watched), counted as Continue Watching's next episode counts them."""
    from datetime import date, datetime, timedelta
    from .watch_nextup import release_day, number
    from .progress_model import timestamp
    today = today or date.today()
    base = (number(last.get('season')), number(last.get('episode')))
    try:
        last_watched = datetime.fromtimestamp(timestamp(last.get('updated_at'))).date()
    except (TypeError, ValueError, OverflowError, OSError):
        last_watched = today

    def seen(episode):
        return covered(entry, episode.get('season'), episode.get('episode'), release_day(episode), last_watched)
    episodes = sorted((e for e in meta.get('videos') or [] if isinstance(e, dict) and e.get('id') and number(e.get('season')) > 0),
                      key=lambda e: (number(e.get('season')), number(e.get('episode'))))
    ahead = [e for e in episodes if (number(e.get('season')), number(e.get('episode'))) > base and not seen(e)]
    if not ahead:
        return None
    out = release_day(ahead[0])
    if out and out <= today:
        return ahead[0], False
    if unaired and out and out == today + timedelta(days=1):
        return ahead[0], True
    return None


def _history_shows():
    """[playback] - the latest playback of each show (one per show under all its ids), watched last
    first; not removed from Continue Watching."""
    from .meganexus import progress_db
    from . import continue_rules
    removed = continue_rules.snapshot()
    shows, seen = [], set()
    for row in progress_db.list_recent_items(limit=HISTORY_READ, media_types=SERIES_TYPES, include_watched=True):
        keys = progress_db.title_keys(dict(row, media_type='series'))
        if keys & seen or not row.get('episode') or not row.get('canonical_id'):
            continue
        seen |= keys
        if continue_rules.hidden('series', row['canonical_id'], row.get('updated_at'), removed, continue_rules.ids_of(row)):
            continue
        shows.append(row)
        if len(shows) >= SHOWS:
            break
    return shows


def _history(today=None):
    """MegaNexus history's next episodes: each show whose latest episode was watched to the end gets
    the episode after it from its kept episode list (watch_nextup's, as Continue Watching's)."""
    from . import watch_nextup, simkl_watched, continue_rules
    from .meganexus.paths import watched_percent
    from .progress_model import timestamp
    kept = watch_nextup._read()
    states = simkl_watched.snapshot()
    unaired = continue_rules.show_unaired()
    done = watched_percent()
    cards = []
    for last in _history_shows():
        if float(last.get('percent') or 0) < done and str(last.get('event_type') or '') != 'watched':
            continue                         # half seen: Continue Watching's resume, not the next one
        mid = last['canonical_id']
        meta = (kept.get(mid) or {}).get('meta') or {}
        if not meta.get('videos'):
            continue
        found = following(meta, last, simkl_watched.state(states, 'series', mid), today, unaired)
        if not found:
            continue
        episode, tomorrow = found
        cards.append(episode_card({
            'canonical_id': mid, 'video_id': episode.get('id'), 'title': meta.get('name') or last.get('title') or mid,
            'year': str(meta.get('year') or meta.get('releaseInfo') or '')[:4], 'season': episode.get('season'),
            'episode': episode.get('episode'), 'episode_title': episode.get('title') or episode.get('name') or '',
            'plot': episode.get('overview') or meta.get('description') or '',
            'poster': meta.get('poster') or last.get('poster') or '', 'background': meta.get('background') or last.get('background') or '',
            'clearlogo': meta.get('logo') or last.get('clearlogo') or '', 'last_watched_at': timestamp(last.get('updated_at')),
            'imdb_id': last.get('imdb_id'), 'tmdb_id': last.get('tmdb_id'), 'tvdb_id': last.get('tvdb_id')}, tomorrow))
    return cards


def _release(kept, cid, target):
    """The day an episode came out, from the show's kept episode list (watch_nextup); None unknown."""
    from .watch_nextup import release_day, number
    meta = (kept.get(str(cid or '')) or {}).get('meta') or {}
    place = (number(target.get('season')), number(target.get('episode')))
    episode = next((e for e in meta.get('videos') or [] if isinstance(e, dict)
                    and (number(e.get('season')), number(e.get('episode'))) == place), None)
    return release_day(episode) if episode else None


def _out(card, kept, today, unaired):
    """A service's next episode against its kept episode list: as it is (True), out tomorrow
    ('tomorrow'), or not out yet (None). Not in the list: as the service says."""
    from datetime import date, timedelta
    target = card.get('target') or {}
    day = _release(kept, target.get('canonical_id'), target)
    today = today or date.today()
    if not day or day <= today:
        return True
    return 'tomorrow' if unaired and day == today + timedelta(days=1) else None


def _service_next(service, today=None):
    """Trakt's / Simkl's next episodes as cards (None when the service never answered here)."""
    rows = _raw_rows(service)
    if rows is None:
        return None
    from . import watch_nextup, continue_rules
    kept = watch_nextup._read()
    unaired = continue_rules.show_unaired()
    cards = []
    for raw in rows:
        if not isinstance(raw, dict) or not raw.get('canonical_id'):
            continue
        card = episode_card(raw)
        out = _out(card, kept, today, unaired)
        if out is None:
            continue
        cards.append(episode_card(raw, tomorrow=True) if out == 'tomorrow' else card)
    return cards


def _artwork(cards, stopped):
    from .home_data import _artwork
    return _artwork(cards, stopped=stopped)


DESCRIBE_AT_ONCE = 4      # 9.0.8: cards asked for their description at the same time
DESCRIBE_TIMEOUT = 4      # s one asking may take
FILLED = ('plot', 'poster', 'fanart', 'clearlogo')


def _card_id(card):
    target = card.get('target') or {}
    return (str(target.get('media_type') or ''), str(target.get('canonical_id') or ''),
            str(target.get('season') or ''), str(target.get('episode') or ''))


def _described_from(meta, target):
    """The card's description from its title's details: an episode's own, else the show's (or the film's)."""
    from .watch_nextup import number
    place = (number(target.get('season')), number(target.get('episode')))
    if place[1]:
        episode = next((e for e in meta.get('videos') or [] if isinstance(e, dict)
                        and (number(e.get('season')), number(e.get('episode'))) == place), None) or {}
        text = episode.get('overview') or episode.get('description')
        if text:
            return text
    return meta.get('description') or meta.get('overview') or ''


def _fill(card, meta, target):
    card['plot'] = card.get('plot') or _described_from(meta, target)
    card['poster'] = card.get('poster') or meta.get('poster') or ''
    card['fanart'] = card.get('fanart') or meta.get('background') or ''
    card['clearlogo'] = card.get('clearlogo') or meta.get('logo') or meta.get('clearlogo') or ''


def _described(cards, kept, stopped):
    """9.0.8: every card with its description, as Continue Watching's (Home shows it above the row): the one it
    had before (kept), else the show's kept episode list (watch_nextup), else its metadata add-on, a few at a time.
    The Watchlist and Simkl's next episodes came without any; nothing a card has is replaced, its line kept."""
    from . import watch_nextup, backend_api
    from .continue_metadata import metadata_identity
    before = {_card_id(card): card for card in kept or () if isinstance(card, dict) and card.get('plot')}
    shows = watch_nextup._read()
    out, asked = [], []
    for card in cards:
        card = dict(card)
        old = before.get(_card_id(card))
        if old:
            for key in FILLED:
                card[key] = card.get(key) or old.get(key) or ''
        target = card.get('target') or {}
        if not card.get('plot'):
            meta = (shows.get(str(target.get('canonical_id') or '')) or {}).get('meta') or {}
            if meta:
                _fill(card, meta, target)
        if not card.get('plot'):
            asked.append(len(out))
        out.append(card)
    if not asked or stopped():
        return out

    def ask(index):
        if stopped():
            return index, {}
        target = out[index].get('target') or {}
        kind, lookup = metadata_identity(target)
        try:
            return index, (backend_api.metadata(kind, lookup, timeout=DESCRIBE_TIMEOUT) or {}) if lookup else {}
        except Exception:
            return index, {}       # one that does not answer keeps its card as it is
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=DESCRIBE_AT_ONCE) as pool:
        for index, meta in pool.map(ask, asked):
            if meta:
                _fill(out[index], meta, out[index].get('target') or {})
    return out


def compute(row, source, stopped=None):
    """The row's cards from the local stores and the kept answers (no network but the Artwork
    provider's pictures and, once per card, its description); kept for the next Home. None while there is nothing to work from yet (a
    service never asked, the watchlist copy never made)."""
    stopped = stopped or (lambda: False)
    if row == WATCHLIST:
        if not _mirror_known(source):
            return None
        cards = _watchlist(source)
    elif source == HISTORY:
        cards = _history()
    else:
        cards = _service_next(source)
        if cards is None:
            return None
    if row == NEXT:
        cards = still_next(sorted(cards, key=lambda card: int(card.get('last_watched_at') or 0), reverse=True))
    cards = _described(cards[:CARDS], _kept_cards(row, source), stopped) if cards else []
    cards = _artwork(cards, stopped) if cards else []
    if stopped():
        return None
    if cards != _kept_cards(row, source):
        _keep('cards', _key(row, source), {'account': _account(source) if source in SERVICES else '',
                                           'at': int(time.time()), 'rows': cards})
    return cards


# ---- asked behind Home ----------------------------------------------------------------------------

def due(row, source, now=None):
    """Its service is to be asked now: never answered for this source, or FRESH is over; not again within
    RETRY of no answer."""
    now = now or time.time()
    job = _job(row, source)
    if now - _TRIED.get(job, 0) < RETRY:
        return False
    if row == WATCHLIST and source == ALL and not _connected():
        return False                 # the Library alone: nothing to ask
    if _kept_cards(row, source) is None:
        return True
    return now - _asked(job) >= FRESH


def _simkl_watching(stopped):
    """Simkl's shows and anime you watch, with its next episode to watch ("next_to_watch"); None when
    Simkl did not answer."""
    from . import simkl_api
    if not (simkl_api.enabled() and simkl_api.authorized()):
        return None
    rows = []
    for kind in ('shows', 'anime'):
        if stopped():
            return None
        try:
            answer = simkl_api._cached_request('/sync/all-items/%s/watching?extended=full' % kind, auth=True)
        except Exception:
            return None
        for item in simkl_api.clean_items(answer, kind):
            place = simkl_api.parse_episode_marker(item.get('next_to_watch'))
            ids = item.get('ids') or {}
            cid = simkl_api._canonical_for(ids)
            if not place or not cid:
                continue
            imdb = str(ids.get('imdb') or '').strip()
            year = str(item.get('year') or '')
            rows.append({'media_type': 'series', 'canonical_id': cid, 'video_id': '%s:%s:%s' % (cid, place[0], place[1]),
                         'title': item.get('title') or '', 'year': int(year) if year.isdigit() else 0,
                         'season': place[0], 'episode': place[1], 'plot': item.get('overview') or '',
                         'poster': item.get('poster') or '', 'background': '', 'clearlogo': '',
                         'last_watched_at': simkl_api._epoch(item.get('last_watched_at')),
                         'imdb_id': (imdb if imdb.startswith('tt') else 'tt' + imdb) if imdb else '',
                         'tmdb_id': str(ids.get('tmdb') or ''), 'tvdb_id': str(ids.get('tvdb') or '')})
    return rows


def _ask_episodes(stopped):
    """MegaNexus history: the episode lists of the shows whose kept one is missing or old, ASK_EPISODES
    at most (watch_nextup.AT_ONCE at a time, through watch_nextup's own rules for an add-on that
    stopped answering). True when every one asked was answered (or none was due)."""
    from . import watch_nextup, metadata_providers, backend_api
    source = metadata_providers.first() or {}
    if not source or watch_nextup._resting(source):
        return not source
    on = {p['id'] for p in metadata_providers.enabled()}
    kept = watch_nextup._read()
    now = time.time()
    due_shows = []
    for last in _history_shows():
        saved = kept.get(last['canonical_id']) or {}
        if not saved.get('meta') or saved.get('provider') not in on or now - float(saved.get('saved') or 0) > EPISODES_LIFE:
            due_shows.append(last['canonical_id'])
        if len(due_shows) >= ASK_EPISODES:
            break
    answered = True
    for start in range(0, len(due_shows), watch_nextup.AT_ONCE):
        if stopped():
            return False
        batch = due_shows[start:start + watch_nextup.AT_ONCE]
        found = watch_nextup._ask_all(batch, lambda mid: backend_api.metadata('series', mid, timeout=watch_nextup.ASK_TIMEOUT),
                                      source, stopped)
        answered = answered and len(found) == len(batch)
        if watch_nextup._resting(source):
            break
    return answered


def refresh(row, source, stopped=None):
    """Ask the row's service (network: never on the GUI thread). True when it answered."""
    stopped = stopped or (lambda: False)
    job = _job(row, source)
    if row == WATCHLIST:
        from . import library
        library.refresh_tracking()                 # the Library's copy of every connected watchlist
        now = time.time()
        _keep('raw', 'mirror', {'at': now})
        try:
            import xbmcgui
            xbmcgui.Window(10000).setProperty(MIRROR_MARK, str(int(now)))   # the service need not make it again
        except Exception:
            pass
        return True
    if source == HISTORY:
        _ask_episodes(stopped)
        if stopped():
            return False
        _keep('raw', 'history', {'at': time.time()})
        return True
    if source == 'trakt':
        from . import trakt_api
        answer = trakt_api.up_next(UP_NEXT_SHOWS, stopped)
        if answer is None:
            return False
        rows, missed = answer
        # a show whose own question failed keeps what Trakt said of it before
        before = {raw.get('canonical_id'): raw for raw in _raw_rows('trakt') or [] if isinstance(raw, dict)}
        rows = list(rows) + [before[item] for item in missed if item in before]
    elif source == 'simkl':
        rows = _simkl_watching(stopped)
        if rows is None:
            return False
    else:
        return False
    if stopped():
        return False
    _keep('raw', job, {'account': _account(source), 'at': time.time(), 'rows': rows})
    return True


def behind(row, source, then=None):
    """Ask the row's service on a thread of its own, then ``then()`` (also for a caller that came while
    it was already being asked). False when nothing was started or joined."""
    job = _job(row, source)
    with _LOCK:
        if _STOP.is_set():
            return False
        if job in _RUNNING:
            if then is not None:
                _RUNNING[job].append(then)
            return True
        _RUNNING[job] = [then] if then is not None else []

    def work():
        answered = False
        try:
            import xbmc
            monitor = xbmc.Monitor()
            answered = refresh(row, source, stopped=lambda: _STOP.is_set() or monitor.abortRequested())
        except Exception as exc:
            _log('%s from %s not asked: %s' % (row, source, exc))
        with _LOCK:
            waiting = _RUNNING.pop(job, [])
            if not answered:
                _TRIED[job] = time.time()
        for callback in waiting:
            if _STOP.is_set():
                break
            try:
                callback()
            except Exception as exc:
                _log('%s not drawn again: %s' % (row, exc))
    threading.Thread(target=work, name='MegaNexusHomeRows', daemon=True).start()
    return True


def prefill(row, addon=None):
    """A row just switched on (or given another source): its first answer asked now, so it is there
    when Home is drawn again."""
    try:
        source = chosen(row, addon)
        if _kept_cards(row, source) is None and due(row, source):
            return behind(row, source, lambda: compute(row, source, _STOP.is_set))
    except Exception as exc:
        _log('%s not filled: %s' % (row, exc))
    return False


# ---- Home ----------------------------------------------------------------------------------------

def shelves(continue_rows=(), addon=None):
    """[(shelf, place)] of the rows switched on, as kept - no network (Home's build, on its thread).
    A row never filled for its source comes with empty cards (its load fills it); one whose kept cards
    are none is not drawn."""
    addon = _addon(addon)
    on = [row for row in ROWS if shown(row, addon)]
    if not on:
        return []
    out = []
    for row, place in order(addon):
        if row not in on:
            continue
        try:
            source = chosen(row, addon)
            kept = _kept_cards(row, source)
            if kept is None:
                cards = [loading()]
            else:
                cards = visible(row, kept, continue_rows)
                if not cards:
                    continue
            out.append(({'title': TITLES[row], 'tracking_job': row, 'tracking_from': source, 'rows': cards}, place))
        except Exception as exc:
            _log('%s skipped: %s' % (row, exc))
    return out


def placed(shelves_, tracked, top, lead, group_ids=None):
    """Home's rows with ``tracked`` ([(shelf, place)]) put in: place 0 at ``top`` (right under Continue
    Watching), place n after the rows of the first n groups of your collections (``group_ids`` in the
    file's order - read only when a row stands further down), or at ``lead`` (after Local and the media
    servers' rows) when none of those groups has a row on Home."""
    if not tracked:
        return shelves_
    if group_ids is None and any(place for _, place in tracked):
        try:
            from .collection_profile import group_ids as ids
            group_ids = ids()
        except Exception:
            group_ids = []
    at = {}
    for shelf, place in tracked:
        if place <= 0:
            index = top
        else:
            wanted = set((group_ids or [])[:place])
            hits = [i for i, other in enumerate(shelves_) if other.get('home_group') in wanted]
            index = hits[-1] + 1 if hits else lead
        at.setdefault(max(0, min(index, len(shelves_))), []).append(shelf)
    out = []
    for index in range(len(shelves_) + 1):
        out.extend(at.get(index, ()))
        if index < len(shelves_):
            out.append(shelves_[index])
    return out


def load(row, continue_rows=(), stopped=None, later=None):
    """A Home worker's: the row's cards worked out again (compute) without what Continue Watching shows
    - None while there is nothing to work from yet. When its service is due it is asked behind
    (behind), and ``later()`` follows its answer (the worker's own row loads again)."""
    stopped = stopped or (lambda: False)
    try:
        source = chosen(row)
    except Exception as exc:
        _log('%s: no source: %s' % (row, exc))
        return None
    try:
        cards = compute(row, source, stopped)
    except Exception as exc:
        _log('%s from %s not worked out: %s' % (row, source, exc))
        cards = None
    started = False
    if later is not None:
        try:
            if due(row, source):
                started = behind(row, source, later)
        except Exception as exc:
            _log('%s from %s not asked: %s' % (row, source, exc))
    if cards is None:
        if not started and time.time() - _TRIED.get(_job(row, source), 0) < RETRY:
            return [unanswered(row, source)]          # its question failed a moment ago: said, never left blank
        return None
    return visible(row, cards, continue_rows, deep=True)
