# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import os
import urllib.error
import urllib.parse
import urllib.request
import threading
import time
import queue

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .player_session import clear_session, load_session, save_session
from . import trakt_api, simkl_api, mdblist_tracking
from .meganexus import progress_db
from .texts import tr

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    try:
        from settings_snapshot import cached_addon as _cached_addon
    except Exception:
        _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

_SOURCE_SWITCH_HANDOFF_PROP = 'meganexus.source_switch_handoff.v2'

_FOREIGN_FILE_MARKERS = (
    'plugin.video.themoviedb.helper',
    'dummy.mp4',
)


def _switch_read():
    """The source-switch note while it is valid (an expired one is removed)."""
    home = xbmcgui.Window(10000)
    try:
        raw = home.getProperty(_SOURCE_SWITCH_HANDOFF_PROP) or ''
        note = json.loads(raw) if raw else {}
        if not isinstance(note, dict):
            return {}
        if float(note.get('expires_at') or 0.0) and time.time() > float(note['expires_at']):
            home.clearProperty(_SOURCE_SWITCH_HANDOFF_PROP)
            return {}
        return note
    except Exception:
        return {}


def _switch_ack(data):
    """Answer the switch note: the new playback took over (False without a valid note)."""
    try:
        note = dict(data or {})
        if not note.get('token'):
            return False
        note.update(ack=True, ack_at=time.time())
        xbmcgui.Window(10000).setProperty(_SOURCE_SWITCH_HANDOFF_PROP, json.dumps(note, separators=(',', ':')))
        return True
    except Exception:
        return False


def _monitor_path():
    try:
        import xbmcvfs
        return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/playback_monitor.log')
    except Exception:
        try:
            return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/playback_monitor.log')
        except Exception:
            return ''


# 7.0.14: lines Kodi writes when a video decoder cannot show a stream.
import re as _re
_DECODER_FAILED = _re.compile(r'no supported pixel formats|send packet failed|Unable to open codec|'
                              r'Error opening video codec|OpenVideoStream.*(?:failed|error)|'
                              r'MediaCodec.*(?:configure|start).*(?:fail|error)|CDVDVideoCodec\w*::Open.*fail', _re.I)
_LOG_READ_MAX = 1024 * 1024
# 8.1.4: the picture of a live channel stands still while its sound goes on. A TV
# stream that changes its programme table as it opens makes Kodi open the hardware
# decoder twice within milliseconds; on CoreELEC (Amlogic) the second one then gives no
# picture any more and Kodi writes this, again every ten seconds, until the channel is
# opened anew. Once it may sort itself out - the second time, ten seconds on, it has not.
_LIVE_FROZEN = 'OutputPicture - timeout waiting for buffer'
LIVE_FROZEN_AGAIN = 8.0       # s between the first line and the one that says it lasts
LIVE_RESTARTS = 2             # restarts of one channel within LIVE_RESTART_WINDOW
LIVE_RESTART_WINDOW = 120.0
# 7.0.24: Dolby Vision diagnostics (dv_diagnostics) for the diagnostics window.
DV_PROPERTY = 'meganexus.dv.'
DV_KEYS = ('active', 'profile', 'source_el', 'structure', 'rpu', 'changes', 'fel_path',
           'el_decoder', 'sync', 'status', 'status_note', 'level')
DV_DEEP_AFTER = 8        # seconds of playback before the one-time frame-pairing check


def _log_file():
    try:
        import xbmcvfs
        return os.path.join(xbmcvfs.translatePath('special://logpath'), 'kodi.log')
    except Exception:
        return ''


def _log_size():
    try:
        return os.path.getsize(_log_file())
    except OSError:
        return None


def _log_since(offset):
    """(new log text, new offset) - at most _LOG_READ_MAX at a time."""
    path = _log_file()
    try:
        size = os.path.getsize(path)
        if size < offset:      # the log was rotated
            offset = 0
        with open(path, 'rb') as stream:
            stream.seek(offset)
            data = stream.read(min(_LOG_READ_MAX, size - offset))
        return data.decode('utf-8', 'replace'), offset + len(data)
    except (OSError, ValueError):
        return '', offset


def _log_safe(value):
    """7.0.13: links in the monitor log lose their query (debrid CDN tokens, keys)."""
    text = str(value)
    if text.startswith(('http://', 'https://')) and '?' in text:
        return text.split('?', 1)[0] + '?…'
    return text


def _monitor(event, level=xbmc.LOGINFO, **payload):
    """A playback event in Kodi's log and the playback log."""
    from . import play_log
    play_log.write(play_log.record(event, payload, _log_safe), level, _monitor_path())


def _timeout():
    try:
        return max(3, int(ADDON.getSetting('timeout') or '20'))
    except Exception:
        return 20


def _interval_seconds():
    try:
        return max(2, int(ADDON.getSetting('companion_interval') or '5'))
    except Exception:
        return 5


def companion_enabled():
    try:
        return (ADDON.getSetting('enable_companion_sync') or 'true').lower() == 'true'
    except Exception:
        return True


def _json_post(url, payload, headers=None):
    body = json.dumps(payload or {}).encode('utf-8')
    asking = urllib.request.Request(url, data=body, method='POST',
                                    headers=dict(headers or {}, **{'Content-Type': 'application/json', 'Accept': 'application/json'}))
    with urllib.request.urlopen(asking, timeout=_timeout()) as answer:
        return answer.read().decode('utf-8', 'ignore')


def _json_get(url, headers=None):
    asking = urllib.request.Request(url, headers=dict(headers or {}, **{'Accept': 'application/json'}), method='GET')
    with urllib.request.urlopen(asking, timeout=_timeout()) as answer:
        return json.loads(answer.read().decode('utf-8', 'ignore'))


def _absolute_url(base, maybe_url):
    """A '/path' made whole with the base address's scheme and host (full addresses stay)."""
    value = str(maybe_url or '').strip()
    if not value or value.startswith(('http://', 'https://')) or not (value.startswith('/') and base):
        return value
    parts = urllib.parse.urlparse(base)
    return '%s://%s%s' % (parts.scheme, parts.netloc, value) if parts.scheme and parts.netloc else value


def _session_owner_is(ctx):
    """Whether the saved playback session is this playback's (by its id, else stream key, else
    address; True when that cannot be told)."""
    try:
        saved = load_session() or {}
    except Exception:
        return True
    ctx = ctx or {}
    for key in ('playback_uid', 'stream_key', 'stream_url'):
        mine, theirs = ctx.get(key) or '', saved.get(key) or ''
        if mine and theirs:
            return mine == theirs
    return True


def _curtain_after_stop():
    """7.0.29: a film ended - black while the TV switches back, then the screen fades in."""
    try:
        from .curtain import after_stop
        after_stop()
    except Exception:
        pass


def _forget_playing(request_id):
    """7.0.29: the player's badges and Sources button belong to this playback only.
    A playback switched to another source keeps the new one's (its own request id)."""
    home = xbmcgui.Window(10000)
    if home.getProperty('meganexus.playing.request_id') != str(request_id):
        return
    for key in ('meganexus.playing.request', 'meganexus.playing.source', 'meganexus.playing.request_id',
                'meganexus.subtitle.path', 'meganexus.subtitle.row', 'meganexus.subtitle.name', 'meganexus.subtitle.syncable',
                'meganexus.ai.ready'):
        home.clearProperty(key)
    for index in range(8):
        home.clearProperty('meganexus.playing.badge%d' % index)
    try:   # 9.0.4: the start box's and Info's data go with the film
        from .player_info import clear
        clear(home)
    except Exception:
        pass

_EVENTS = ('started', 'progress', 'paused', 'stopped', 'ended')
_STATE_OF = {'started': 'playing', 'progress': 'playing', 'paused': 'paused', 'stopped': 'stopped'}
_SCROBBLE_STEP = {'started': 'start', 'progress': 'start', 'paused': 'pause', 'stopped': 'pause', 'ended': 'stop'}


class PlaybackReporter(object):
    """Tells one service where the playback is: each event (started, progress, paused,
    stopped, ended - all called as reporter.<event>(ctx, position_ms)) comes to its ``tell``."""

    def tell(self, event, ctx, position_ms):
        raise NotImplementedError


def _event_call(event):
    def call(self, ctx, position_ms=0):
        return self.tell(event, ctx, position_ms)
    call.__name__ = event
    return call


for _event in _EVENTS:
    setattr(PlaybackReporter, _event, _event_call(_event))


class AddonCompanion(PlaybackReporter):
    def _headers(self, ctx):
        """The X-Plex headers an add-on's companion expects."""
        headers = {}
        if ctx.get('clientIdentifier') or ctx.get('client_id'):
            headers['X-Plex-Client-Identifier'] = ctx.get('clientIdentifier') or ctx.get('client_id')
        headers.update({'X-Plex-Product': ctx.get('product') or 'MegaNexus', 'X-Plex-Platform': 'Kodi',
                        'X-Plex-Device': 'Kodi', 'X-Plex-Device-Name': ctx.get('deviceName') or 'Kodi'})
        if ctx.get('token'):
            headers['X-Plex-Token'] = ctx['token']
        return headers

    def _first_report(self, ctx):
        """Ask the companion once where to report (timeline, scrobble...), how often and how long the media is."""
        if ctx.get('_bootstrapped'):
            return
        url = ctx.get('bootstrapUrl') or (str(ctx['companionUrl']).replace('/companion/timeline/', '/companion/bootstrap/')
                                          if ctx.get('companionUrl') else '')
        if url:
            try:
                answer = _json_get(url, headers=self._headers(ctx))
                if isinstance(answer, dict):
                    self._take_bootstrap(ctx, url, answer)
            except Exception as exc:
                xbmc.log('[MegaNexus] companion bootstrap error: %s' % exc, xbmc.LOGWARNING)
        ctx['_bootstrapped'] = True

    @staticmethod
    def _take_bootstrap(ctx, url, answer):
        for theirs, ours in _BOOTSTRAP_FIELDS:
            value = _absolute_url(url, answer.get(theirs))
            if value:
                ctx[ours] = value
        try:
            if answer.get('intervalMs') and not ctx.get('intervalSeconds'):
                ctx['intervalSeconds'] = max(2, int(float(answer['intervalMs']) / 1000.0))
        except Exception:
            pass
        try:
            if answer.get('duration') and not ctx.get('duration_ms'):
                ctx['duration_ms'] = int(answer['duration'])
        except Exception:
            pass

    def _payload(self, ctx, position_ms, state, mark_watched=None):
        at = int(position_ms or 0)
        session = ctx.get('sessionIdentifier') or ''
        payload = {'state': state, 'time': at, 'duration': int(ctx.get('duration_ms') or 0), 'playbackTime': at,
                   'sessionIdentifier': session, 'playbackSessionId': ctx.get('playbackSessionId') or session,
                   'deviceName': ctx.get('deviceName') or 'Kodi', 'device': 'Kodi', 'platform': 'Kodi',
                   'product': ctx.get('product') or 'MegaNexus'}
        if mark_watched is not None:
            payload['markWatched'] = bool(mark_watched)
        return payload

    def _post(self, ctx, key, position_ms, state, mark_watched=None):
        self._first_report(ctx)
        if not ctx.get(key):
            return None
        return _json_post(ctx[key], self._payload(ctx, position_ms, state, mark_watched), headers=self._headers(ctx))

    def tell(self, event, ctx, position_ms):
        if event != 'ended':
            return self._post(ctx, 'companionUrl', position_ms, _STATE_OF[event])
        where = 'companionScrobbleUrl' if ctx.get('companionScrobbleUrl') else 'companionUrl'
        return self._post(ctx, where, position_ms or int(ctx.get('duration_ms') or 0), 'stopped', mark_watched=True)


class PlexTimeline(PlaybackReporter):
    def _headers(self, ctx):
        device = ctx.get('device_name', 'Kodi')
        return {'X-Plex-Product': ctx.get('product', 'MegaNexus'), 'X-Plex-Version': ctx.get('product_version', '2.6.0'),
                'X-Plex-Client-Identifier': ctx['client_id'], 'X-Plex-Provides': 'player', 'X-Plex-Device-Name': device,
                'X-Plex-Platform': 'Kodi', 'X-Plex-Model': 'Kodi', 'X-Plex-Device': device}

    def _get(self, ctx, path, params):
        query = urllib.parse.urlencode(dict(params, **{'X-Plex-Token': ctx['token']}))
        asking = urllib.request.Request(ctx['server_url'].rstrip('/') + path + '?' + query, headers=self._headers(ctx), method='GET')
        with urllib.request.urlopen(asking, timeout=_timeout()) as answer:
            return answer.read()

    def _timeline(self, ctx, position_ms, state):
        item = '/library/metadata/%s' % ctx['rating_key']
        return self._get(ctx, '/:/timeline', {'duration': int(ctx.get('duration_ms', 0)), 'guid': 'com.plexapp.plugins.library',
                                              'key': item, 'containerKey': item, 'ratingKey': str(ctx['rating_key']),
                                              'state': state, 'time': int(position_ms)})

    def _scrobble(self, ctx):
        return self._get(ctx, '/:/scrobble', {'key': str(ctx['rating_key']), 'identifier': 'com.plexapp.plugins.library'})

    def tell(self, event, ctx, position_ms):
        if event != 'ended':
            return self._timeline(ctx, position_ms, _STATE_OF[event])
        self._timeline(ctx, position_ms or int(ctx.get('duration_ms', 0)), 'stopped')
        return self._scrobble(ctx)                  # played to the end: watched on the server


class MediaBrowserReporter(PlaybackReporter):
    """Jellyfin / Emby playback reports. 6.0.39: Jellyfin 12 accepts only the
    standard Authorization header (mediabrowser builds it per server flavor)."""
    def _flavor(self, ctx):
        from . import mediabrowser
        return ctx.get('server_flavor') or mediabrowser.flavor_of(mediabrowser.account())

    def _headers(self, ctx):
        from . import mediabrowser
        return mediabrowser.headers(ctx['token'], self._flavor(ctx))

    def _post(self, ctx, path, payload):
        from . import mediabrowser
        url = ctx['server_url'].rstrip('/') + ('/emby' if self._flavor(ctx) == mediabrowser.EMBY else '') + path
        asking = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=self._headers(ctx), method='POST')
        with urllib.request.urlopen(asking, timeout=_timeout()) as answer:
            return answer.read()

    def _payload(self, ctx, position_ms, paused=False):
        payload = {'ItemId': ctx['item_id'], 'PositionTicks': int(position_ms) * 10000, 'IsPaused': paused,
                   'PlayMethod': 'DirectStream', 'CanSeek': True,
                   'SessionId': ctx.get('session_id') or ctx.get('device_id') or 'meganexus'}
        payload.update((theirs, ctx[ours]) for theirs, ours in (('PlaySessionId', 'play_session_id'),
                                                                 ('MediaSourceId', 'media_source_id')) if ctx.get(ours))
        return payload

    # event -> (where it goes, its EventName, paused)
    _SESSIONS = {'started': ('/Sessions/Playing', '', False),
                 'progress': ('/Sessions/Playing/Progress', 'TimeUpdate', False),
                 'paused': ('/Sessions/Playing/Progress', 'Pause', True),
                 'stopped': ('/Sessions/Playing/Stopped', 'Stop', False),
                 'ended': ('/Sessions/Playing/Stopped', 'Stop', False)}

    def tell(self, event, ctx, position_ms):
        where, name, paused = self._SESSIONS[event]
        if event == 'ended':
            position_ms = position_ms or int(ctx.get('duration_ms', 0))
        payload = self._payload(ctx, position_ms, paused=paused)
        if name:
            payload['EventName'] = name
        return self._post(ctx, where, payload)


class TraktScrobbler(PlaybackReporter):
    def tell(self, event, ctx, position_ms):
        return trakt_api.scrobble(_SCROBBLE_STEP[event], ctx, position_ms)


class SimklProgress(PlaybackReporter):
    """The local journal has already queued the newest position: every event only sends
    it (a late event must never put back an older one)."""

    def tell(self, event, ctx, position_ms):
        return simkl_api.flush_progress()


class MDBListReporter(PlaybackReporter):
    """MDBList tracking (7.0.12): the same scrobble steps as Trakt."""

    def tell(self, event, ctx, position_ms):
        return mdblist_tracking.scrobble(_SCROBBLE_STEP[event], ctx, position_ms)


class WeTrakrReporter(PlaybackReporter):
    """9.0.1: WeTrakr, as agreed with them - start, pause and stop only, never the progress
    ticks; going on after a pause, the jump to the resume point and a seek are a start again
    (how WeTrakr is told the place moved). /scrobble/stop marks the end (80 %) watched itself;
    a stop that did not reach them is still a watched mark."""
    _held = False
    _told = None     # (position, clock) of the last start

    def _jumped(self, position_ms):
        if not self._told:
            return False
        position, clock = self._told
        return abs(position_ms - position - (time.time() - clock) * 1000) > 30000

    def tell(self, event, ctx, position_ms):
        from . import wetrakr_api
        if event == 'progress' and not self._held and not self._jumped(position_ms):
            return None
        self._held = event == 'paused'
        self._told = (position_ms, time.time()) if event in ('started', 'progress') else None
        share = trakt_api._progress(ctx, position_ms)
        season, episode = ctx.get('season'), ctx.get('episode')
        if event != 'started' and share <= 0.5:
            return None
        step = {'started': 'start', 'progress': 'start', 'paused': 'pause'}.get(event, 'stop')
        sent = wetrakr_api.scrobble(ctx, share, season, episode, action=step)
        if event in ('stopped', 'ended') and share >= trakt_api.FINISHED and not sent:
            # the stop did not reach them: the end is still a watched mark
            series = wetrakr_api._is_series(ctx) and season is not None and episode is not None
            return wetrakr_api.mark(ctx, 'episode' if series else 'title', season, episode)
        return sent


class ReporterGroup(PlaybackReporter):
    def __init__(self, reporters):
        self.reporters = [r for r in (reporters or []) if r]

    def _call(self, method_name, ctx, position_ms=0):
        """Tell every reporter (one failing never stops the others; the first failure is logged)."""
        answers = []
        for reporter in self.reporters:
            call = getattr(reporter, method_name)
            try:
                answers.append(call(ctx, position_ms))
            except TypeError:
                answers.append(call(ctx))
            except Exception as exc:
                if not getattr(self, '_report_err_logged', False):
                    self._report_err_logged = True
                    xbmc.log('[MegaNexus] reporter %s error (repeats suppressed): %s' % (method_name, exc), xbmc.LOGWARNING)
        return answers

    def tell(self, event, ctx, position_ms):
        return self._call(event, ctx, position_ms)


def _server_reporter(ctx):
    """The media server / add-on companion that wants to hear about this playback (None without one)."""
    if ctx.get('companionUrl') or ctx.get('companionScrobbleUrl'):
        return AddonCompanion()
    if ctx.get('server_url') and ctx.get('token'):
        if ctx.get('server_type') == 'plex' and ctx.get('rating_key'):
            return PlexTimeline()
        if ctx.get('server_type') == 'emby' and ctx.get('item_id'):
            return MediaBrowserReporter()
    return None


def reporter_for(ctx):
    """Who is told about the playback: its server or companion, and (with an id) Trakt, Simkl and
    MDBList when they are on; one reporter, several in one, or None."""
    if not ctx:
        return None
    reporters = [r for r in (_server_reporter(ctx),) if r]
    if any(ctx.get(k) for k in ('imdb_id', 'tmdb_id', 'tvdb_id')):
        if trakt_api.enabled() and trakt_api.scrobble_enabled():
            reporters.append(TraktScrobbler())
        # Partial progress is independent of the optional watched-history setting.
        if simkl_api.enabled() and simkl_api.authorized():
            reporters.append(SimklProgress())
        if mdblist_tracking.enabled():
            reporters.append(MDBListReporter())
        try:
            from . import wetrakr_api
            if wetrakr_api.enabled() and wetrakr_api.authorized():
                reporters.append(WeTrakrReporter())
        except Exception:
            pass
    if not reporters:
        return None
    return reporters[0] if len(reporters) == 1 else ReporterGroup(reporters)


_BOOTSTRAP_FIELDS = (('timelineUrl', 'companionUrl'), ('scrobbleUrl', 'companionScrobbleUrl'),
                     ('unscrobbleUrl', 'companionUnscrobbleUrl'), ('sessionIdentifier', 'sessionIdentifier'),
                     ('playbackSessionId', 'playbackSessionId'), ('clientIdentifier', 'clientIdentifier'))


_FRESH_PLAYBACK = {'_fallback_chain': [], '_had_error': False, '_progress_seen_ms': 0, '_own_trigger': False,
                   '_last_position_ms': 0, '_last_duration_ms': 0, '_fallback_pending': False, '_started_reported': False,
                   '_started_probe_pending': False, '_resume_applied': False, '_resume_in_progress': False,
                   '_subtitle_restored': False}


_COMPANION_LINKS = ('bootstrapUrl', 'companionUrl', 'companionScrobbleUrl', 'companionUnscrobbleUrl')


RESUME_LAND = 8.0     # 9.0.0: s a jump to the resume point is given to land


def should_mark_watched(position_ms, duration_ms, threshold=None):
    """6.0.35: as the Nuvio apps. 8.1.2: and the share is a setting (GitHub #23) -
    ninety per cent of a long episode still has five minutes to run."""
    try:
        if threshold is None:
            from .meganexus.paths import watched_percent
            threshold = watched_percent() / 100.0
        return duration_ms > 0 and (float(position_ms) / float(duration_ms)) >= threshold
    except Exception:
        return False


def _safe_int(value, default=0):
    try:
        return int(value or 0)
    except Exception:
        return default


def _safe_float(value, default=0.0):
    try:
        return float(value or 0.0)
    except Exception:
        return default


def _watched_percent_here(position_ms, duration_ms):
    try:
        if duration_ms and duration_ms > 0:
            return max(0.0, min(100.0, (float(position_ms) / float(duration_ms)) * 100.0))
    except Exception:
        pass
    return 0.0


def _progress_ids(ctx, episode):
    """The playback's TMDB / IMDb / TVDB ids (its own, else its external_ids) and the show's TMDB id."""
    external = ctx.get('external_ids') if isinstance(ctx.get('external_ids'), dict) else {}
    ids = dict((short + '_id', str(ctx.get(short + '_id') or external.get(short + '_id') or external.get(short) or '').strip())
               for short in ('tmdb', 'imdb', 'tvdb'))
    ids['show_tmdb_id'] = str(ctx.get('show_tmdb_id') or (ids['tmdb_id'] if episode else '')).strip()
    return ids


def _store_progress_here(ctx, position_ms=0, duration_ms=0, finished=False):
    """Keep where the playback is (or that it was watched) in our progress store and the local
    Continue Watching journal; Next Up and the Continue rows refresh."""
    if not isinstance(ctx, dict) or not ctx or not ctx.get('canonical_id'):
        return
    canonical = ctx['canonical_id']
    kind = (ctx.get('media_type') or '').lower()
    episode = kind in ('series', 'anime', 'show', 'tv') or (ctx.get('season') not in (None, '', 0, '0')
                                                            and ctx.get('episode') not in (None, '', 0, '0'))
    kind = kind or ('series' if episode else 'movie')
    length, position = _safe_float(duration_ms, 0.0) / 1000.0, _safe_float(position_ms, 0.0) / 1000.0
    finished = finished or bool(ctx.get('meganexus_completed_by_user')) or should_mark_watched(position_ms, duration_ms)
    try:
        from . import continue_local
        continue_local.save(ctx, position, length, finished)
    except Exception as exc:
        xbmc.log('[MegaNexus] local continue journal failed: %s' % exc, xbmc.LOGWARNING)
    try:
        # 8.1.2: it was played, so playback speaks for itself - a mark set by hand
        # ("not watched") is dropped, the way a newer progress time brings a title back
        # into Continue Watching after it was removed there.
        from . import watched_local
        watched_local.played(kind, canonical, _safe_int(ctx.get('season'), 0) if episode else None,
                             _safe_int(ctx.get('episode'), 0) if episode else None)
    except Exception as exc:
        xbmc.log('[MegaNexus] local watched mark: %s' % exc, xbmc.LOGWARNING)
    try:
        progress_db.keep_row(kind, canonical, ctx.get('video_id') or canonical, ctx.get('show_title') or ctx.get('title') or canonical,
                                ctx.get('provider_name') or 'MegaNexus', ctx.get('poster') or '', ctx.get('background') or '',
                                ctx.get('clearlogo') or '', _safe_int(ctx.get('season'), 0) if episode else None,
                                _safe_int(ctx.get('episode'), 0) if episode else None, position, length,
                                100.0 if finished else _watched_percent_here(position_ms, duration_ms),
                                ctx.get('stream_url') or '', 'watched' if finished else 'progress',
                                native_server_id=str(ctx.get('server_id') or '').strip(),
                                native_item_id=str(ctx.get('rating_key') or ctx.get('item_id') or '').strip(),
                                **_progress_ids(ctx, episode))
    except Exception as exc:
        xbmc.log('[MegaNexus] local progress save failed: %s' % exc, xbmc.LOGWARNING)
        return
    _drop_next_up_cache()
    if finished or position_ms >= 1000:
        _refresh_continue_rows()


def _drop_next_up_cache():
    try:
        win = xbmcgui.Window(10000)
        for key in ('meganexus.nextup_cache', 'meganexus.nextup_cache_ts'):
            try:
                win.clearProperty(key)
            except Exception:
                pass
    except Exception:
        pass


_CW_REFRESH_PATHS = (
    'plugin.video.meganexus/?',     # root home page (CW row + nextup row)
    'plugin.video.meganexus/',      # any MegaNexus container
    'action=continue',           # full Continue Watching list
    'action=favorites',          # favorites screen
    'action=nextup',             # next-up list
    'action=home',               # explicit home action
)


def _refresh_continue_rows():
    """Tell the Home rows progress changed; refresh the list when one of our progress lists is open."""
    try:
        home = xbmcgui.Window(10000)
        home.setProperty('meganexus.cw_dirty', '1')
        for key in ('meganexus.cw_dirty_ts', 'meganexus.progress.revision'):
            home.setProperty(key, str(time.time_ns()))
    except Exception:
        pass
    try:
        folder = xbmc.getInfoLabel('Container.FolderPath') or ''
    except Exception:
        return
    if 'plugin.video.meganexus' in folder and any(token in folder for token in _CW_REFRESH_PATHS):
        try:
            xbmc.executebuiltin('Container.Refresh')
        except Exception:
            pass


def _clear_tmdbh_handoff_flag():
    try:
        for win_id in (12005, 10000):
            try:
                win = xbmcgui.Window(win_id)
            except Exception:
                continue
            for key in ('meganexus.invoked_by_tmdbh', 'meganexus.tmdbh_seed_ids', 'meganexus.tmdbh_seed_for', 'meganexus.tmdbh_handoff_until'):
                try:
                    win.clearProperty(key)
                except Exception:
                    pass
    except Exception:
        pass


def _show_player_pictures(ctx):
    """The playing title's pictures and texts on the home window (the player skin reads them)."""
    if not isinstance(ctx, dict) or not ctx:
        return
    try:
        logo, poster = ctx.get('clearlogo') or '', ctx.get('poster') or ''
        backdrop = ctx.get('background') or poster or ''
        values = {'clearlogo': logo, 'poster': poster, 'thumb': poster, 'fanart': backdrop, 'title': ctx.get('title') or '',
                  'plot': ctx.get('plot') or '', 'year': str(ctx.get('year') or '')}
        pairs = [('meganexus.source.' + key, values[key]) for key in ('clearlogo', 'poster', 'thumb', 'fanart', 'title', 'plot', 'year')]
        pairs += [(key, logo) for key in ('clearlogo', 'logo', 'tvshow.clearlogo')] + [('poster', poster), ('thumb', poster)]
        pairs += [('fanart', backdrop), ('fanart_image', backdrop)]
        home = xbmcgui.Window(10000)
        for key, value in pairs:
            try:
                home.setProperty(key, value)
            except Exception:
                pass
    except Exception:
        pass


_OWN_PLAY_ROUTES = ('streams', 'episode_streams', 'item_open', 'series_meta', 'play_item', 'cw_resume', 'cw_play_from_start', 'play')


def _is_own_path(path):
    """True for a MegaNexus link that opens sources or plays."""
    value = str(path or '').strip()
    return value.startswith('plugin://plugin.video.meganexus/') and any('action=%s' % route in value for route in _OWN_PLAY_ROUTES)


_PLAYER_STATE = {'ctx': {}, 'reporter': None, '_report_thread': None, '_play_start_time': 0.0, '_had_error': False,
                 '_progress_seen_ms': 0, '_next_episode': None, '_started_reported': False, '_started_probe_pending': False,
                 '_resume_applied': False, '_resume_in_progress': False, '_resume_generation': 0,
                 '_subtitle_restore_generation': 0, '_subtitle_restored': False, '_progress_heartbeat_token': 0,
                 '_active_playback_uid': '', '_last_started_file': '', '_last_started_at': 0.0, '_last_position_ms': 0,
                 '_last_duration_ms': 0, '_own_trigger': False, '_foreign_active': False, '_artwork_published_uid': '',
                 '_fallback_pending': False}


_SUBTITLE_DIALOGS = ('Window.IsActive(subtitlesearch)', 'Window.IsActive(subtitles)', 'Dialog.IsActive(subtitlesearch)')


def _same_file(left, right):
    """Whether two subtitle paths name the same file (special:// paths resolved, case and slashes ignored)."""
    try:
        flat = lambda path: str(xbmcvfs.translatePath(path) or path).replace('\\', '/').lower()
        return bool(flat(left) and flat(right) and flat(left) == flat(right))
    except Exception:
        return str(left or '') == str(right or '')


def _dialog_on_top():
    """Whether a dialog (above all the subtitle search) is open over the player."""
    try:
        return int(xbmcgui.getCurrentWindowDialogId() or 0) > 0
    except Exception:
        pass
    for condition in _SUBTITLE_DIALOGS:
        try:
            if xbmc.getCondVisibility(condition):
                return True
        except Exception:
            pass
    return False


class PlaybackWatcher(xbmc.Player):
    def __init__(self):
        super().__init__()
        for name, value in _PLAYER_STATE.items():
            setattr(self, name, dict(value) if isinstance(value, dict) else value)
        self._fallback_chain = []
        self._report_queue = queue.Queue(maxsize=64)
        self._report_lock = threading.Lock()
        self._progress_heartbeat_stop = threading.Event()

    def _reread_playback(self):
        """Take the new playback's session: its links made whole, who to report to, fresh state."""
        self.ctx = load_session() or {}
        base = self.ctx.get('provider_base_url') or self.ctx.get('server_url') or ''
        for key in _COMPANION_LINKS:
            if self.ctx.get(key):
                self.ctx[key] = _absolute_url(base, self.ctx[key])
        self.reporter = reporter_for(self.ctx)
        for name, value in _FRESH_PLAYBACK.items():
            setattr(self, name, list(value) if isinstance(value, list) else value)
        self.ctx.pop('fallback_stream_keys', None)
        self._next_episode = self.ctx.get('next_episode') or None
        # anything still running for the playback before (resume, subtitles, the beat) stops
        for counter in ('_resume_generation', '_subtitle_restore_generation', '_progress_heartbeat_token'):
            setattr(self, counter, getattr(self, counter) + 1)
        try:
            self._progress_heartbeat_stop.set()
        except Exception:
            pass
        self._active_playback_uid = str(self.ctx.get('playback_uid') or '')
        self._last_started_file = self._now_playing_path()
        self._last_started_at = self._play_start_time = time.time()

    def _other_addon_playing(self, reason, playing_file=''):
        self._foreign_active = True
        self._stop_progress_beat()
        try:
            xbmc.log('[MegaNexus] companion idle: foreign playback (%s)%s'
                     % (reason, (' file=%s' % playing_file) if playing_file else ''),
                     xbmc.LOGDEBUG)
        except Exception:
            pass

    def _show_pictures_later(self, ctx):
        """Put the playback's pictures on the home window in the background (once per playback)."""
        if not isinstance(ctx, dict) or not ctx:
            return
        uid = str(ctx.get('playback_uid') or '') or 'file:%s' % (ctx.get('url') or ctx.get('title') or '')
        if uid == self._artwork_published_uid:
            return
        self._artwork_published_uid = uid
        snapshot = dict(ctx)
        try:
            threading.Thread(target=lambda: _show_player_pictures(snapshot), name='MegaNexusArtPublish', daemon=True).start()
        except RuntimeError:
            _show_player_pictures(snapshot)

    def _place_ms(self):
        """Where the playback is (ms); the last known place while the player cannot tell."""
        try:
            if self._player_busy_for_clock():
                at = int(self.getTime() * 1000)
                if at >= 0:
                    self._last_position_ms = at
                    return at
        except Exception:
            pass
        return int(self._last_position_ms or 0)

    def _length_ms(self):
        """How long the media is (ms); the last known length, else the playback's."""
        try:
            if self._player_busy_for_clock():
                length = int(self.getTotalTime() * 1000)
                if length > 0:
                    self._last_duration_ms = length
                    return length
        except Exception:
            pass
        return int(self._last_duration_ms or self.ctx.get('duration_ms', 0) or 0)

    def _player_busy_for_clock(self):
        try:
            return bool(self.isPlaying() or self.isPlayingVideo())
        except Exception:
            return False

    def _now_playing_path(self):
        try:
            return self.getPlayingFile() or ''
        except Exception:
            return ''

    def _player_busy(self, require_real_media=False):
        playing_file = self._now_playing_path()
        # Kodi may retain the plugin path after AV starts (adaptive streams).
        # A live video clock is authoritative, not the unresolved list path.
        try:
            if self.isPlayingVideo():
                return True
        except Exception:
            pass
        if playing_file and not _is_own_path(playing_file):
            return True
        try:
            if xbmc.getCondVisibility('Player.HasVideo'):
                if not require_real_media:
                    return True
                return self._place_ms() > 0
        except Exception:
            pass
        return False

    def _keep_subtitle_after_switch(self):
        """After a source switch, the subtitle the old source showed is put on the new one once
        playback has settled (in the background, abandoned when another playback starts)."""
        if self._subtitle_restored:
            return
        path = str(self.ctx.get('switch_subtitle_path') or '').strip()
        if not path:
            self._subtitle_restored = True
            return
        self._subtitle_restore_generation += 1
        job = (self._subtitle_restore_generation, str(self._active_playback_uid or self.ctx.get('playback_uid') or ''))
        try:
            enabled = bool(self.ctx.get('switch_subtitle_enabled', True))
            threading.Thread(target=lambda: self._restore_switch_subtitle(job, path, enabled),
                             name='MegaNexusSubtitleRestore', daemon=True).start()
        except Exception as exc:
            xbmc.log('[MegaNexus] subtitle restore thread failed: %s' % exc, xbmc.LOGWARNING)

    def _restore_still_wanted(self, job):
        generation, uid = job
        # 9.0.7: never on a film being left (foreground_guard.stop_film)
        from .foreground_guard import being_left
        return generation == self._subtitle_restore_generation and not (uid and uid != str(self._active_playback_uid or '')) \
            and not being_left(self.ctx.get('meganexus_request_id'))

    def _wait_until_settled(self, job):
        """Wait (up to 90 s) until real media plays, no resume seek runs and no dialog is open for a
        moment; False when given up, no longer wanted or Kodi stops (9.0.7: xbmc.sleep did not
        hear Kodi stop the service - this kept it up to 90 s past Kodi's 5)."""
        calm = 0
        monitor = xbmc.Monitor()
        for _tick in range(360):
            if not self._restore_still_wanted(job):
                return False
            if self._player_busy(require_real_media=True) and not self._resume_in_progress and not _dialog_on_top():
                calm += 1
                if calm >= 5:
                    return True
            else:
                calm = 0
            if monitor.waitForAbort(.25):
                return False
        return False

    def _put_subtitle(self, job, path, enabled):
        """Set the subtitle (three tries) and check Kodi took it; True when it did."""
        for attempt in range(1, 4):
            if not self._restore_still_wanted(job):
                return None
            if _dialog_on_top():
                xbmc.sleep(500)
                continue
            try:
                self.setSubtitles(path)
                xbmc.sleep(450)
                self.showSubtitles(bool(enabled))
            except Exception as exc:
                _monitor('subtitle-restore-failed', level=xbmc.LOGWARNING, error=exc, path=path, playback_uid=job[1],
                         attempt=attempt)
                xbmc.sleep(600)
                continue
            try:
                showing = str(self.getSubtitles() or '').strip()
            except Exception:
                showing = ''
            if not showing or _same_file(showing, path):
                return True
            xbmc.sleep(700)
        return False

    def _restore_switch_subtitle(self, job, path, enabled):
        uid = job[1]
        try:
            if not self._wait_until_settled(job):
                return
            if not path.startswith(('http://', 'https://')):
                try:
                    if not xbmcvfs.exists(path):
                        _monitor('subtitle-restore-missing', level=xbmc.LOGWARNING, path=path, playback_uid=uid)
                        return
                except Exception:
                    pass
            done = self._put_subtitle(job, path, enabled)
            if done is None:
                return
            if not done:
                _monitor('subtitle-restore-unverified', level=xbmc.LOGWARNING, path=path, playback_uid=uid)
                return
            self._subtitle_restored = True
            self.ctx.update(switch_subtitle_restored=True, source_switch_reuse_subtitle=False)
            try:
                save_session(self.ctx)
            except Exception:
                pass
            _monitor('subtitle-restored-after-switch', path=path, enabled=enabled, playback_uid=uid)
        except Exception as exc:
            _monitor('subtitle-restore-error', level=xbmc.LOGWARNING, error=exc, playback_uid=uid)

    def _watch_start(self):
        if self._started_probe_pending or self._started_reported:
            return
        self._start_progress_beat()

    def _fallback_later(self, reason='', delay_ms=3200):
        """Automatic source fallback is intentionally disabled in an earlier version."""
        self._fallback_pending = False
        return False

    def _report(self, method_name, position_ms=None):
        if not companion_enabled():
            return
        if not self.reporter:
            return
        # Network trackers must never delay the local playback clock or Stop.
        # Capture this session object; a later video replaces self.ctx entirely.
        event=(self.reporter,self.ctx,method_name,
               self._place_ms() if position_ms is None else position_ms)
        try:self._report_queue.put_nowait(event)
        except queue.Full:
            xbmc.log('[MegaNexus] Tracker queue is full; local progress remains saved.',xbmc.LOGWARNING)
            return
        with self._report_lock:
            if self._report_thread is None or not self._report_thread.is_alive():
                self._report_thread=threading.Thread(target=self._drain_reports,
                    name='MegaNexusTrackerReports',daemon=True)
                self._report_thread.start()

    def _drain_reports(self):
        while True:
            try:event=self._report_queue.get(timeout=1)
            except queue.Empty:
                with self._report_lock:
                    if self._report_queue.empty():
                        self._report_thread=None
                        return
                continue
            try:self._send_report(*event)
            finally:self._report_queue.task_done()

    @staticmethod
    def _send_report(reporter,ctx,method_name,position_ms):
        try:
            getattr(reporter, method_name)(ctx, position_ms)
        except TypeError:
            try:getattr(reporter, method_name)(ctx)
            except Exception:pass
        except urllib.error.HTTPError as exc:
            xbmc.log('[MegaNexus] companion %s HTTP %s' % (method_name, exc.code), xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log('[MegaNexus] companion %s error: %s' % (method_name, exc), xbmc.LOGWARNING)

    def _seek_to_resume_later(self):
        """Jump to the resume point once the playback is ready (in the background; once per playback)."""
        if self._resume_applied or self._resume_in_progress:
            return
        seconds, percent, exact, least = self._resume_plan()
        if seconds < least and not 1.0 < percent < 95.0:
            self._resume_applied = True
            return
        self._resume_in_progress = True
        self._resume_generation += 1
        try:
            generation = self._resume_generation
            threading.Thread(target=lambda: self._resume_when_ready(generation, seconds, percent, exact, least),
                             name='MegaNexusResumeCoordinator', daemon=True).start()
        except Exception:
            self._resume_in_progress = False
            self._resume_applied = True

    def _resume_plan(self):
        """(seconds, percent, exact, the least worth seeking to) of the resume point the playback asks for."""
        numbers = []
        for key in ('resume_seconds', 'resume_percent'):
            try:
                numbers.append(float(self.ctx.get(key) or 0.0))
            except Exception:
                numbers.append(0.0)
        exact = bool(self.ctx.get('meganexus_resume_exact'))
        # 7.0.59: a MegaNexus film no longer gets its position from Kodi (StartOffset - the DTS-HD fix,
        # 7.0.56), so this jump is the only one: it honours what MegaNexus resumes, from 5 s, as
        # StartOffset did (a film stopped at 0:15 went back to 0:00)
        least = 0.001 if exact else (1.0 if self.ctx.get('source_switch_pending') else
                                     (5.0 if self.ctx.get('meganexus_request_id') else 30.0))
        return numbers[0], numbers[1], exact, least

    def _settled_length(self, generation, exact):
        """The media's length once Kodi reports the same one twice (15 s at most); 0.0 when it never settles."""
        settled, seen = 0.0, 0
        monitor = xbmc.Monitor()
        for _tick in range(75):
            if generation != self._resume_generation:
                return None
            if monitor.waitForAbort(.2):          # 9.0.7: Kodi stopping the service is heard
                return None
            if not self._player_busy(require_real_media=True):
                continue
            # 7.0.55: not before Kodi opened the sound - a DTS-HD film opened mid-way (StartOffset)
            # read only its DTS core, the receiver output failed and Kodi filled all the RAM (Cube,
            # killed four times); opened at 0:00 it reads DTS-HD, then the jump is safe
            if not getattr(self, '_av_ready', True):
                continue
            try:
                length = float(self.getTotalTime() or 0.0)
            except Exception:
                length = 0.0
            if length > (0.0 if exact else 60.0):
                if abs(length - settled) < 1.0:
                    seen += 1
                else:
                    settled, seen = length, 1
                if seen >= 2:
                    break
        return settled

    def _playing_at(self):
        try:
            return float(self.getTime() or 0.0)
        except Exception:
            return 0.0

    def _resume_when_ready(self, generation, seconds, percent, exact, least):
        monitor = xbmc.Monitor()
        try:
            length = self._settled_length(generation, exact)
            if length is None or generation != self._resume_generation or not self._player_busy(require_real_media=True):
                return
            target = seconds
            if target < least and 1.0 < percent < 95.0 and length > 60.0:
                target = length * percent / 100.0
            if length > 0.0:
                target = min(target, max(0.0, length - (0.5 if exact else 90.0)))
            if target < least:
                return
            close_enough = max(0.0, target - 0.5) if exact else max(min(15.0, target * 0.5), target - 8.0)
            now = self._playing_at()
            if now >= close_enough:
                _monitor('resume-already-applied', title=self.ctx.get('title') or '', target_seconds='%.1f' % target,
                         current_seconds='%.1f' % now)
                return
            # 9.0.0: one jump, then patience. A 4K / Dolby Vision film on a TV box takes 2-4 s
            # to land, and the TV re-adjusts its mode on every jump: the second jump that came
            # after 1.2 s cut the first one off and made the screen blink once more. Another
            # jump only when the first has not moved the film at all.
            for attempt, patience in ((1, RESUME_LAND), (2, RESUME_LAND / 2)):
                if generation != self._resume_generation:
                    return
                before = self._playing_at()
                try:
                    self.seekTime(target)
                except Exception:
                    continue
                until = time.monotonic() + patience
                while time.monotonic() < until:
                    if monitor.waitForAbort(.25) or generation != self._resume_generation:
                        return
                    now = self._playing_at()
                    if now >= close_enough:
                        _monitor('resume-applied', title=self.ctx.get('title') or '', target_seconds='%.1f' % target,
                                 current_seconds='%.1f' % now, attempt=attempt)
                        return
                if self._playing_at() > before + 30:
                    break                       # it moved, only not as far: no second jump
            _monitor('resume-failed', level=xbmc.LOGWARNING, title=self.ctx.get('title') or '', target_seconds='%.1f' % target,
                     resume_percent='%.2f' % percent)
        except Exception as exc:
            _monitor('resume-error', level=xbmc.LOGWARNING, error=exc, title=self.ctx.get('title') or '')
        finally:
            if generation == self._resume_generation:
                self._resume_in_progress = False
                self._resume_applied = True

    def _start_progress_beat(self):
        """Watch the playback in the background: report its start, then keep its progress every 15 s
        and tell the services every minute until it stops."""
        try:
            self._progress_heartbeat_stop.set()
        except Exception:
            pass
        self._progress_heartbeat_token += 1
        beat = (self._progress_heartbeat_token, threading.Event(), str(self._active_playback_uid or self.ctx.get('playback_uid') or ''))
        self._progress_heartbeat_stop = beat[1]
        self._started_probe_pending = True
        try:
            threading.Thread(target=lambda: self._follow_playback(*beat), name='MegaNexusPlaybackLifecycle', daemon=True).start()
        except Exception as exc:
            self._started_probe_pending = False
            xbmc.log('[MegaNexus] progress heartbeat failed: %s' % exc, xbmc.LOGWARNING)

    def _start_facts(self):
        return dict(title=self.ctx.get('title') or '', canonical_id=self.ctx.get('canonical_id') or '',
                    provider=self.ctx.get('provider_name') or self.ctx.get('provider_id') or '',
                    playing_file=self._now_playing_path())

    def _wait_for_start(self, token, stop, uid):
        """True once real media plays (reported once); None when this watch was replaced; False after 60 s."""
        monitor = xbmc.Monitor()
        for _tick in range(240):
            if stop.is_set() or token != self._progress_heartbeat_token or (uid and uid != str(self._active_playback_uid or '')) \
                    or monitor.abortRequested():      # 9.0.7: Kodi stopping the service is heard
                return None
            if self._player_busy(require_real_media=True):
                if not self._started_reported:
                    self._started_reported = True
                    _monitor('playback-started', **self._start_facts())
                    self._report('started')
                return True
            if stop.wait(0.25):
                return None
        return False

    def _follow_playback(self, token, stop, uid):
        try:
            started = self._wait_for_start(token, stop, uid)
            if started is False:
                _monitor('playback-start-timeout', level=xbmc.LOGWARNING, **self._start_facts())
            if not started:
                return
            saved, reported = 0.0, time.monotonic()
            # 7.0.16: also ends when Kodi exits - a player that never reported
            # its stop (a stream without picture) kept this loop, and with it
            # Kodi, alive after Exit.
            monitor = xbmc.Monitor()
            while token == self._progress_heartbeat_token and not stop.wait(1.0) and not monitor.abortRequested():
                # Temporary buffering/decoder reconfiguration is not Stop.
                if not self._player_busy(require_real_media=True) or self._resume_in_progress:
                    continue
                position, length = self._place_ms(), self._length_ms()
                self._progress_seen_ms = max(self._progress_seen_ms, int(position or 0))
                if length > 0:
                    self.ctx['duration_ms'] = int(length)
                now = time.monotonic()
                if position >= 3000 and (not saved or now - saved >= 15):
                    _store_progress_here(self.ctx, position, length, finished=False)
                    saved = now
                if now - reported >= 60:
                    self._report('progress', position_ms=position)
                    reported = now
        finally:
            if token == self._progress_heartbeat_token:
                self._started_probe_pending = False

    def _stop_progress_beat(self):
        self._progress_heartbeat_token += 1
        self._started_probe_pending = False
        try:
            self._progress_heartbeat_stop.set()
        except Exception:
            pass

    def _pause_or_go_on(self, quiet, event, report):
        """Pause / resume: progress kept and reported (not while the resume jump runs)."""
        if self._foreign_active or not self.ctx:
            return
        if self._resume_in_progress:
            _monitor('playback-%s-during-resume-suppressed' % quiet, title=self.ctx.get('title') or '')
            return
        self._show_pictures_later(self.ctx)
        _monitor('playback-%s' % event, title=self.ctx.get('title') or '', position_ms=self._place_ms())
        position = self._place_ms()
        self._progress_seen_ms = max(self._progress_seen_ms, int(position or 0))
        _store_progress_here(self.ctx, position, self._length_ms(), finished=False)
        self._report(report, position_ms=position)

    def _after_start_later(self):
        uid = str(self._active_playback_uid or self.ctx.get('playback_uid') or '')
        if not uid:
            return
        try:
            from .playing import after_start
            job = after_start.claim_job(uid)
        except Exception as exc:
            try:
                xbmc.log('[MegaNexus] post-start job pickup failed: %s' % exc,
                         xbmc.LOGWARNING)
            except Exception:
                pass
            return
        if not job:
            return

        def _runner():
            try:
                after_start.do_job(job, monitor=_monitor)
            except Exception as exc:
                _monitor('play-post-start-error', level=xbmc.LOGWARNING,
                         error=exc, title=self.ctx.get('title') or '')

        try:
            threading.Thread(target=_runner, name='MegaNexusPostStart',
                             daemon=True).start()
        except RuntimeError as exc:
            try:
                xbmc.log('[MegaNexus] post-start worker unavailable: %s' % exc,
                         xbmc.LOGWARNING)
            except Exception:
                pass

    def onPlayBackStarted(self):
        """A video started: another add-on's / the screensaver's is left alone; ours (once, even when
        Kodi reports it twice) gets its pictures, resume point, subtitle, start report and progress watch."""
        self._av_ready = False           # 7.0.55: the resume jump waits for picture AND sound (onAVStarted)
        self._log_offset = _log_size()   # 7.0.14: decoder errors are read from here on
        self._start_live_freeze_watch(self._now_playing_path(), self._log_offset)
        try:
            from .dv_diagnostics import uptime_us
            start = uptime_us()
            self._dv_since = (start - 2000000) if start else 0   # kernel log from this video on
        except Exception:
            self._dv_since = 0
        if xbmcgui.Window(10000).getProperty('meganexus.saver.cancelled'):
            from .saver_state import stop_cancelled_preview
            if stop_cancelled_preview(self):
                self._other_addon_playing('cancelled-screensaver')
                return
        try:
            pending = load_session() or {}
        except Exception:
            pending = {}
        pending_uid = str(pending.get('playback_uid') or '')
        playing = self._now_playing_path()
        reason = self._not_ours(pending_uid, playing)
        if reason:
            self._other_addon_playing(reason, *([playing] if reason == 'tmdbh-dummy' else []))
            return
        self._foreign_active = False
        # 7.0.17: watch for decoder failures from the opening of the file - a
        # stream the device cannot decode may never reach A/V start at all.
        self._start_picture_watchdog(playing)
        same = (pending_uid == self._active_playback_uid if pending_uid else
                bool(self.ctx and playing and playing == self._last_started_file))
        if same and time.time() - float(self._last_started_at or 0.0) < 12.0:
            _monitor('playback-started-duplicate-suppressed', title=self.ctx.get('title') or pending.get('title') or '',
                     playback_uid=pending_uid, playing_file=playing)
            self._show_pictures_later(self.ctx or pending)
            self._watch_start()
            return
        self._reread_playback()
        _clear_tmdbh_handoff_flag()
        for step in (lambda: self._show_pictures_later(self.ctx), self._seek_to_resume_later, self._keep_subtitle_after_switch,
                     self._after_start_later, self._start_progress_beat):
            step()

    def _not_ours(self, pending_uid, playing):
        """Why a starting video is not a MegaNexus playback ('' when it is ours)."""
        if xbmcgui.Window(10000).getProperty('meganexus.preview.active'):
            return 'home-preview'
        if not pending_uid and not self._active_playback_uid:
            return 'no-session'
        low = (playing or '').lower()
        return 'tmdbh-dummy' if low and all(mark in low for mark in _FOREIGN_FILE_MARKERS) else ''

    def _start_dv_diagnostics(self):
        """7.0.24: one light worker per video while the diagnostics window is on."""
        thread = getattr(self, '_dv_thread', None)
        if thread is not None and thread.is_alive():
            return
        self._dv_thread = threading.Thread(target=self._dv_loop, name='MegaNexusDVDiag', daemon=True)
        self._dv_thread.start()

    def _dv_loop(self):
        """Dolby Vision rows of the diagnostics window, once a second while it is
        on: Kodi's labels every time; the Kodi and kernel logs, the EL decoder
        and the frame-pairing check once per video (dv_diagnostics)."""
        from . import dv_diagnostics as dv
        monitor = xbmc.Monitor()
        home = xbmcgui.Window(10000)
        playing = self._now_playing_path()
        started = time.monotonic()
        cache = {}
        try:
            while not monitor.waitForAbort(1.0):
                if not xbmc.getCondVisibility('Player.HasVideo') or self._now_playing_path() != playing:
                    break
                if not xbmc.getCondVisibility('Skin.HasSetting(meganexus.stats)'):
                    continue
                try:
                    values = self._dv_rows(dv, cache, started, monitor)
                except Exception:
                    values = {}
                for key in DV_KEYS:
                    home.setProperty(DV_PROPERTY + key, values.get(key, ''))
        finally:
            for key in DV_KEYS:
                home.clearProperty(DV_PROPERTY + key)

    def _dv_rows(self, dv, cache, started, monitor):
        hdr_type = xbmc.getInfoLabel('VideoPlayer.HdrType')
        if hdr_type != 'dolbyvision':
            return dv.rows(dv.build(hdr_type=hdr_type))
        if 'platform' not in cache:
            cache['platform'] = dv.platform(xbmc.getInfoLabel('System.BuildVersion'),
                                            android=xbmc.getCondVisibility('System.Platform.Android'))
        plat = cache['platform']
        detail = xbmc.getInfoLabel('VideoPlayer.HdrDetail') if plat['kodi'] >= 22 else ''
        if not plat['coreelec']:
            # Generic Kodi: its labels only, no CoreELEC sysfs assumptions.
            return dv.rows(dv.build(hdr_type=hdr_type, hdr_detail=detail), deep_available=False,
                           dv_output=plat.get('dv_output', True))
        if 'log' not in cache:
            offset = getattr(self, '_log_offset', None)
            cache['log'] = _log_since(offset)[0] if offset is not None else ''
        sidedata = dv.parse_sidedata(xbmc.getInfoLabel('Player.Process(video.sidedata)')) if plat['kodi'] >= 22 else None
        if 'fel_requested' not in cache:
            cache['fel_requested'] = dv.fel_path_requested(dv.kmsg_records(getattr(self, '_dv_since', 0)))
        model = dv.build(hdr_type=hdr_type, hdr_detail=detail, log_text=cache['log'], sidedata=sidedata,
                         coreelec=True, fel_requested=cache['fel_requested'], el_decoder=dv.vfm_el_decoder(),
                         deep=cache.get('deep'), status_api=dv.read_status_api())
        if (model['source_el'] == 'FEL' and 'deep' not in cache and model['bypass'] is False and
                time.monotonic() - started >= DV_DEEP_AFTER):
            cache['deep'] = dv.deep_verify(wait=monitor.waitForAbort)
            cache['deep_available'] = cache['deep'] is not None
            model = dv.build(hdr_type=hdr_type, hdr_detail=detail, log_text=cache['log'], sidedata=sidedata,
                             coreelec=True, fel_requested=cache['fel_requested'], el_decoder=dv.vfm_el_decoder(),
                             deep=cache['deep'], status_api=dv.read_status_api())
        return dv.rows(model, deep_available=cache.get('deep_available', True))

    def onAVStarted(self):
        self._av_ready = True
        try:
            if xbmc.getCondVisibility('Player.HasVideo'):
                self._start_dv_diagnostics()
        except Exception:
            pass
        if xbmcgui.Window(10000).getProperty('meganexus.saver.cancelled'):
            from .saver_state import stop_cancelled_preview
            if stop_cancelled_preview(self):
                self._other_addon_playing('cancelled-screensaver')
                return
        # Started can precede actual A/V by many seconds on remote providers.
        # Recover even when the initial probe timed out or the service attached late.
        pending = load_session() or {}
        if not pending.get('playback_uid'):
            return
        if xbmcgui.Window(10000).getProperty('meganexus.preview.active'):
            return
        if self._foreign_active or self._active_playback_uid != pending.get('playback_uid'):
            self.onPlayBackStarted()
        if not self._foreign_active and not self._started_probe_pending:
            self._start_progress_beat()
        if not self._foreign_active:
            self._last_started_file=self._now_playing_path() or self._last_started_file
            xbmcgui.Window(10000).setProperty('meganexus.playback.started', pending.get('meganexus_request_id') or '')
            try:
                # 7.0.42: removed from Continue Watching - back as soon as it plays again
                from . import continue_rules
                kind = 'movie' if str(pending.get('media_type') or '').lower() == 'movie' else 'series'
                if pending.get('canonical_id') and continue_rules.played(kind, pending['canonical_id'], continue_rules.ids_of(pending)):
                    xbmcgui.Window(10000).setProperty('meganexus.progress.revision', 'played-%s' % time.time())
            except Exception as exc:
                xbmc.log('[MegaNexus] Continue Watching return skipped: %s' % exc, xbmc.LOGWARNING)
            self._after_start_later()
            self._start_picture_watchdog(self._last_started_file)
            try:
                # 9.0.4: the start box (display mode, age rating, parents guide) and Info's plot
                from . import player_info
                player_info.start(self, self._active_playback_uid, self.ctx)
            except Exception as exc:
                xbmc.log('[MegaNexus] player info not started: %s' % exc, xbmc.LOGWARNING)

    def _start_live_freeze_watch(self, playing, offset):
        """8.1.4: a live channel (pvr://) whose picture stands still is opened again."""
        if offset is None or not str(playing or '').startswith('pvr://'):
            return
        if getattr(self, '_live_watch', (None,))[0] == playing:
            return
        mark = (playing, object())
        self._live_watch = mark

        def watch():
            try:
                self._live_freeze_watch(playing, offset)
            except Exception as exc:
                xbmc.log('[MegaNexus] live picture check stopped: %r' % exc, xbmc.LOGDEBUG)
            finally:
                if getattr(self, '_live_watch', None) is mark:
                    self._live_watch = (None,)
        threading.Thread(target=watch, name='MegaNexusLivePicture', daemon=True).start()

    def _live_freeze_watch(self, playing, offset):
        monitor = xbmc.Monitor()
        first = None
        while not monitor.waitForAbort(1.0):
            if self._now_playing_path() != playing or not xbmc.getCondVisibility('Player.HasMedia'):
                return
            text, offset = _log_since(offset)
            if _LIVE_FROZEN not in text:
                continue
            now = time.monotonic()
            if first is None or now - first > 30:
                first = now                  # once may pass - it did on the Cube this morning
                continue
            if now - first < LIVE_FROZEN_AGAIN:
                continue
            restarts = [at for at in getattr(self, '_live_restarts', {}).get(playing, []) if now - at < LIVE_RESTART_WINDOW]
            if len(restarts) >= LIVE_RESTARTS:
                _monitor('live-picture-frozen-gave-up', level=xbmc.LOGWARNING, playing_file=playing)
                return
            self._live_restarts = dict(getattr(self, '_live_restarts', {}), **{playing: restarts + [now]})
            _monitor('live-picture-frozen-reopened', level=xbmc.LOGWARNING, playing_file=playing, attempt=len(restarts) + 1)
            windowed = not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
            self._live_watch = (None,)           # the new start gets a check of its own
            try:
                self.play(playing, windowed=windowed)   # the channel anew: a fresh decoder
            except Exception:
                pass
            return                           # the new start is watched by its own onPlayBackStarted

    def _start_picture_watchdog(self, playing):
        if not playing or getattr(self, '_picture_watch', None) == playing:
            return
        self._picture_watch = playing

        def watch():
            try:
                self._picture_watchdog(playing)
            finally:
                if getattr(self, '_picture_watch', None) == playing:
                    self._picture_watch = None   # the same file played again is watched again
        threading.Thread(target=watch, name='MegaNexusPictureCheck', daemon=True).start()

    def _picture_watchdog(self, playing):
        """7.0.14: a version the device cannot decode (e.g. 4K HDR 10-bit HEVC
        without a fitting hardware decoder) starts its sound but never a
        picture, and the hidden player then blocks trailers ("stop the current
        video"). Kodi says so in its log; only then - and only while there is
        still no picture - the video is stopped with the reason. No error, no
        stop: a slow connection may take as long as it needs."""
        monitor = xbmc.Monitor()
        offset = getattr(self, '_log_offset', None)
        if offset is None:
            return
        first_error = 0.0
        while not monitor.waitForAbort(.5):
            if self._now_playing_path() != playing or not xbmc.getCondVisibility('Player.HasMedia'):
                return
            if xbmc.getCondVisibility('Player.HasVideo'):
                return   # the picture is there
            text, offset = _log_since(offset)
            if not first_error and _DECODER_FAILED.search(text):
                first_error = time.monotonic()
            # A decoder may recover by itself (fallback to software): one second more.
            if first_error and time.monotonic() - first_error >= 1.0:
                break
        else:
            return
        _monitor('no-picture-stopped', level=xbmc.LOGWARNING, title=self.ctx.get('title') if isinstance(getattr(self, 'ctx', None), dict) else '')
        request = ''
        try:
            # The loading screen waiting for this start closes at once (no 60 s wait).
            request = (load_session() or {}).get('meganexus_request_id') or ''
            if request:
                xbmcgui.Window(10000).setProperty('meganexus.playback.error', request)
        except Exception:
            pass
        try:
            # 9.0.7: never self.stop() from this thread - it keeps Python's lock while Kodi's
            # main thread closes the video (foreground_guard.stop_film)
            from .foreground_guard import stop_film
            stop_film(request)
        except Exception:
            pass
        xbmcgui.Dialog().ok('Playback', 'This version cannot be shown on this device (its video format, often 4K HDR '
                                        '10-bit, is not supported here). Choose another source, or set HUB Settings > '
                                        'Playback > Automatic stream choice > Highest resolution to Up to 1080p.')

    def onPlayBackPaused(self):
        self._pause_or_go_on('pause', 'paused', 'paused')

    def onPlayBackResumed(self):
        self._pause_or_go_on('resume', 'resumed', 'progress')

    def onPlayBackError(self):
        if self._foreign_active:
            return
        _clear_tmdbh_handoff_flag()
        self._had_error = True
        _monitor('playback-error', level=xbmc.LOGWARNING, title=self.ctx.get('title') or '', canonical_id=self.ctx.get('canonical_id') or '', provider=self.ctx.get('provider_name') or self.ctx.get('provider_id') or '')
        if self._fallback_chain:
            xbmc.log('[MegaNexus] onPlayBackError — scheduling fallback grace', xbmc.LOGWARNING)
            self._fallback_later('playback-error', delay_ms=3200)
        else:
            xbmc.log('[MegaNexus] onPlayBackError — no fallback configured', xbmc.LOGWARNING)

    def _try_fallback(self):
        self._fallback_chain = []
        return False

    def onPlayBackStopped(self):
        """Playback stopped: a stop caused by a source switch is ignored; else the progress is kept
        (or marked watched), a failed start falls back to the next source, the services are told."""
        self._stop_progress_beat()
        self._resume_generation += 1
        self._resume_in_progress = False
        if self._foreign_active:
            self._foreign_active = False
            return
        _clear_tmdbh_handoff_flag()
        if self._stop_was_switch():
            self._forget_playback(all_of_it=False)
            return
        position = int(self._last_position_ms or self._progress_seen_ms or 0)
        length = int(self._last_duration_ms or self.ctx.get('duration_ms', 0) or 0)
        self._progress_seen_ms = max(self._progress_seen_ms, int(position or 0))
        watched = bool(self.ctx.get('meganexus_completed_by_user')) or should_mark_watched(position, length)
        if self._fell_back_after_stop(position, length):
            return
        self._keep_stop_progress(position, length, watched)
        if self.ctx.get('meganexus_request_id'):
            xbmcgui.Window(10000).setProperty('meganexus.playback.finished', str(self.ctx['meganexus_request_id']))
            _forget_playing(self.ctx['meganexus_request_id'])
            _curtain_after_stop()
        self._report_stop(position, length, watched)
        try:
            _monitor('stop-reopen-sources-suppressed', title=self.ctx.get('title') or '',
                     position_seconds='%.1f' % (float(position or 0) / 1000.0))
        except Exception:
            pass
        if _session_owner_is(self.ctx):
            clear_session()
        self._forget_playback(all_of_it=True)

    def _stop_was_switch(self):
        """True when this stop is the old source giving way to a switched one (its point noted, the switch acknowledged)."""
        session = load_session() or {}
        note = _switch_read()
        mine = str(self.ctx.get('playback_uid') or '')
        old_uid = str(note.get('old_uid') or '')
        from_note = bool(note.get('token') and (not old_uid or old_uid == mine))
        pending = bool(session.get('source_switch_pending')) and bool(mine and mine == str(session.get('playback_uid') or ''))
        if not (from_note or pending):
            return False
        try:
            position = int(float(session.get('resume_seconds') or 0.0) * 1000)
        except Exception:
            position = int(self._last_position_ms or self._progress_seen_ms or 0)
        try:
            length = int(float(session.get('duration') or 0.0) * 1000)
        except Exception:
            length = int(self._last_duration_ms or self.ctx.get('duration_ms', 0) or 0)
        self._progress_seen_ms = max(self._progress_seen_ms, position)
        if from_note:
            _switch_ack(note)
        _monitor('source-switch-old-stop-suppressed', title=self.ctx.get('title') or '',
                 playback_uid=self.ctx.get('playback_uid') or '', position_ms=position, duration_ms=length)
        return True

    def _fell_back_after_stop(self, position, length):
        """A playback that failed early (an error, under a minute, under 30 s seen) moves on to the
        next source; True when it did."""
        spent = time.time() - (self._play_start_time or 0)
        failed = bool(self._had_error) and spent < 60.0 and self._progress_seen_ms < 30000
        if failed and self._fallback_chain:
            _monitor('stopped-probably-failed', level=xbmc.LOGWARNING, title=self.ctx.get('title') or '',
                     elapsed='%.2f' % spent, position_ms=position, duration_ms=length,
                     progress_seen_ms=self._progress_seen_ms, had_error=self._had_error,
                     fallback_count=len(self._fallback_chain or []))
            self._fallback_later('stopped-early', delay_ms=3200)
            return True
        if self._had_error and not failed:
            _monitor('stopped-error-but-user-progress', title=self.ctx.get('title') or '', elapsed='%.2f' % spent,
                     progress_seen_ms=self._progress_seen_ms, position_ms=position, note='auto-fallback suppressed')
        return False

    def _keep_stop_progress(self, position, length, watched):
        if watched:
            _monitor('playback-ended', title=self.ctx.get('title') or '', position_ms=length or position, duration_ms=length,
                     watched=True)
            _store_progress_here(self.ctx, length or position, length or position, finished=True)
        elif position >= 1000:
            _monitor('playback-stopped', title=self.ctx.get('title') or '', position_ms=position, duration_ms=length,
                     watched=False)
            _store_progress_here(self.ctx, position, length, finished=False)
        elif length and not self._had_error:
            # 7.0.42: started and left within a second - still in Continue Watching
            try:
                from . import continue_local
                continue_local.started(self.ctx, length / 1000.0)
            except Exception as exc:
                xbmc.log('[MegaNexus] Continue Watching entry skipped: %s' % exc, xbmc.LOGWARNING)

    def _report_stop(self, position, length, watched):
        """Tell the services: ended (watched) or stopped, and unscrobble an unfinished one."""
        if not self.reporter:
            return
        if watched:
            self._report('ended', position_ms=length or position)
            return
        self._report('stopped', position_ms=position)
        if self.ctx.get('companionUnscrobbleUrl'):
            try:
                self.reporter._post(self.ctx, 'companionUnscrobbleUrl', position, 'stopped', mark_watched=False)
            except Exception as exc:
                xbmc.log('[MegaNexus] companion unscrobble error: %s' % exc, xbmc.LOGWARNING)

    def _forget_playback(self, all_of_it):
        self.ctx, self.reporter, self._fallback_chain, self._next_episode = {}, None, [], None
        if all_of_it:
            self._active_playback_uid, self._fallback_pending = '', False

    def onPlayBackEnded(self):
        """Played to the end: watched, the services told, the session closed; the next episode
        offered (not for a playback the frontend requested). 8.1.5: Kodi says "ended" also when
        the stream's server stops answering (eof) - before the watched share that is a stop at
        the last place, not watched and no Next episode."""
        position = int(self._last_position_ms or self._progress_seen_ms or 0)
        length = int(self._last_duration_ms or self.ctx.get('duration_ms', 0) or 0)
        if (position and length and not self._foreign_active and not self.ctx.get('meganexus_completed_by_user')
                and not should_mark_watched(position, length)):
            xbmc.log('[MegaNexus] Playback: the stream broke off at %d of %d s - kept as stopped there'
                     % (position // 1000, length // 1000), xbmc.LOGINFO)
            self.onPlayBackStopped()
            return
        self._stop_progress_beat()
        self._resume_generation += 1
        self._active_playback_uid, self._fallback_pending, self._resume_in_progress = '', False, False
        if self._foreign_active:
            self._foreign_active = False
            return
        _clear_tmdbh_handoff_flag()
        length = self._length_ms()
        _store_progress_here(self.ctx, length or self._place_ms(), length, finished=True)
        request = self.ctx.get('meganexus_request_id')
        if request:
            xbmcgui.Window(10000).setProperty('meganexus.playback.finished', str(request))
            _forget_playing(request)
            _curtain_after_stop()
        self._report('ended', position_ms=length)
        upcoming = self._next_episode
        if _session_owner_is(self.ctx):
            clear_session()
        self.ctx, self.reporter, self._fallback_chain, self._next_episode = {}, None, [], None
        self._started_reported = self._started_probe_pending = False
        if upcoming and not request:
            self._next_episode_now(upcoming)

    def _next_episode_now(self, next_ep):
        """Offer the next episode with a countdown (Auto next on); it plays unless cancelled."""
        try:
            if (ADDON.getSetting('auto_next_episode') or 'true').lower() != 'true':
                return
        except Exception:
            pass
        try:
            wait = max(3, int(ADDON.getSetting('auto_next_prompt_seconds') or '20'))
        except Exception:
            wait = 20
        title, season, episode = next_ep.get('title') or '', int(next_ep.get('season') or 0), int(next_ep.get('episode') or 0)
        dialog = xbmcgui.DialogProgress()
        # 9.0.7: this runs in the service's own player callback - Kodi stopping the service
        # (an update, Exit) waited for the whole countdown, then started the episode
        monitor = xbmc.Monitor()
        try:
            dialog.create('MegaNexus', tr('Next episode: %s — S%02dE%02d') % (title, season, episode))
            began = time.time()
            while not dialog.iscanceled() and time.time() - began < wait and not monitor.abortRequested():
                spent = time.time() - began
                dialog.update(int(max(0, min(100, spent / float(wait) * 100))),
                              tr('Next episode: %s — S%02dE%02d\nStarting in: %ss') % (title, season, episode, int(wait - spent)))
                monitor.waitForAbort(.25)
        finally:
            try:
                dialog.close()
            except Exception:
                pass
        if dialog.iscanceled() or monitor.abortRequested():
            return
        query = urllib.parse.urlencode({'action': 'play_item', 'media_type': 'series', 'canonical_id': next_ep.get('canonical_id') or '',
                                        'video_id': next_ep.get('video_id') or '', 'season': str(season), 'episode': str(episode),
                                        'title': next_ep.get('title') or ''})
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.meganexus/?%s)' % query)


class SyncRetryLoop(object):
    def __init__(self, player):
        self.player = player

    def run(self):
        """Background loop: retries saved Simkl progress while nothing plays (9.0.7: the steps of
        the Back that reopened the sources did nothing any more - removed)."""
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            # Heartbeat owns progress reports; this loop only retries saved sync.
            if not self.player.isPlayingVideo():
                try:
                    simkl_api.flush_progress()
                except Exception:
                    pass
            if monitor.waitForAbort(_interval_seconds()):
                break
