# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Library's sections (9.1.1): what each place offers, as rows of cards under its tile ("više opcija
ubaciti što nude tracking servisi kao watch next, my catalogs").

    sections(place, cached_only=True) -> [{'id', 'title', 'cards'}]   in the order they are shown
    refresh(place, force=False)       -> True when anything changed  (network: a background thread)

A card has the Library's shape (library._card: title, poster, fanart, landscape, clearlogo, plot, services,
added_at, target, and year); ``services`` are the places the title is in the Library at, worked out when
asked (a recommendation is in none). A Next episodes card's target plays that episode, as on Home.

* meganexus - Movies, Series, Anime, On this device: the Library itself (library.everything); which of
  them are anime is worked out behind (refresh: the list of anime ids is a file read per title).
* nuvio - Movies, Series: the Nuvio account's library as the cloud sync keeps it.
* trakt - Watchlist (the Library's copy of it), Next episodes (Home's, tracking_rows: Trakt's Up Next), the
  user's own lists, Recommended, Recently watched.
* simkl - Watching, Plan to watch, On hold, Completed, Dropped (read again only when /sync/activities
  says something changed).
* mdblist - Watchlist, the user's own lists.
* wetrakr - Favorites (the Library's copy), Watching, Planning, Waiting, On hold, Watched (its tracking
  lists, pulled as WeTrakr asked: only after /sync/last_activities changed, one request after another).
* anilist / mal - Watching, Plan to watch, Paused, Completed (anime_lists.section_rows).

What is read is kept per place in the profile's library_sections/ folder (each profile its own,
user_profiles.FOLDERS; a cache: no backup), for the account it was read for. sections() never asks the
network; a section not read yet is there with no cards. refresh() asks a place again only after FRESH.
"""
import hashlib
import os
import threading
import time

PLACES = ('meganexus', 'nuvio', 'trakt', 'simkl', 'mdblist', 'wetrakr', 'anilist', 'mal')
FOLDER = 'library_sections'
CARDS = 60                # cards of one section at most
PLOT = 300                # characters of a story kept (the files stay small)
FRESH = {'meganexus': 600, 'trakt': 1800, 'simkl': 1800, 'mdblist': 3 * 3600, 'wetrakr': 1800,
         'anilist': 1800, 'mal': 1800}
# 9.1.1: anime in sections of their own ("Simkl's anime separately") - the same thirteen lists asked
SIMKL = (('watching', 'Watching', (('shows', 'watching'),)),
         ('planned', 'Plan to watch', (('movies', 'plantowatch'), ('shows', 'plantowatch'))),
         ('hold', 'On hold', (('shows', 'hold'),)),
         ('anime-watching', 'Anime · Watching', (('anime', 'watching'),)),
         ('anime-planned', 'Anime · Plan to watch', (('anime', 'plantowatch'),)),
         ('anime-hold', 'Anime · On hold', (('anime', 'hold'),)),
         ('completed', 'Completed', (('movies', 'completed'), ('shows', 'completed'), ('anime', 'completed'))),
         ('dropped', 'Dropped', (('movies', 'dropped'), ('shows', 'dropped'), ('anime', 'dropped'))))
# 9.1.1: Trakt's sections after the user's lists (read by _read_trakt)
TRAKT_MORE = (('recommended', 'Recommended'), ('history', 'Recently watched'), ('collection', 'Collection'),
              ('popular', 'Popular on Trakt'), ('anticipated', 'Most anticipated'))
# 9.1.1: MDBList - the watchlist's films and series, MDBList's official Trending list, the user's lists, the liked ones
MDBLIST = (('watchlist-movies', 'Watchlist · Movies'), ('watchlist-series', 'Watchlist · Series'),
           ('trending', 'Trending on MDBList'))
MDBLIST_LISTS, MDBLIST_LIKED = 10, 5
WETRAKR = (('watching', 'Watching'), ('planning', 'Planning'), ('waiting', 'Waiting'), ('hold', 'On hold'),
           ('watched', 'Watched'))
_LOCKS = dict((place, threading.Lock()) for place in PLACES)
_INDEX = {}               # the Library's places of every title, a few seconds (one screen asks several places)
INDEX_LIFE = 5.0


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Library sections: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


# ---- kept per place ---------------------------------------------------------------------------------

def _path(place):
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), FOLDER, '%s.json' % place)


def _read(place):
    from .meganexus.json_files import read_json
    data = read_json(_path(place), {})
    return data if isinstance(data, dict) else {}


def _write(place, data):
    from .meganexus.json_files import write_json
    os.makedirs(os.path.dirname(_path(place)), exist_ok=True)
    write_json(_path(place), data)


def _hash(text):
    return hashlib.sha256(str(text).encode('utf-8')).hexdigest() if text else ''


def _account(place):
    """Whose answer it is - a digest, never the sign-in itself ('' unknown: then any is taken as the same)."""
    try:
        if place in ('trakt', 'simkl'):
            from . import tracking_rows
            return tracking_rows._account(place)
        if place == 'mdblist':
            from . import mdblist_tracking
            return mdblist_tracking.account()
        if place in ('anilist', 'mal'):
            from . import anime_lists
            signed = anime_lists.BY_ID[place].token()
            return _hash(signed.get('user_id') or signed.get('user') or '')
    except Exception:
        pass
    return ''


def _kept(place):
    """The place's kept read, or {} when it was another account's."""
    data = _read(place)
    now = _account(place)
    return {} if (data.get('account') and now and data['account'] != now) else data


def _connected(place):
    if place == 'meganexus':
        return True
    from . import library
    if place == 'nuvio':
        return library._nuvio_linked()
    connected = dict((tid, check) for tid, _name, check, _rows in library.TRACKERS).get(place)
    try:
        return bool(connected and connected())
    except Exception:
        return False


# ---- cards ------------------------------------------------------------------------------------------

def _year(value):
    text = str(value or '')[:4]
    return int(text) if text.isdigit() else 0


def _card(row):
    """A mirror-like row (media_type, canonical_id, title, poster, background, clearlogo, year, plot, added_at)
    as a Library card; None without an id."""
    from . import library
    if not row or not row.get('canonical_id'):
        return None
    card = library._card(dict(row, plot=str(row.get('plot') or '')[:PLOT]))
    card['year'] = _year(row.get('year'))
    return card


def _cards(rows):
    out, seen = [], set()
    for card in (_card(row) for row in rows or []):
        key = card and (card['target']['media_type'], card['target']['canonical_id'])
        if card and key not in seen:
            seen.add(key)
            out.append(card)
    return out[:CARDS]


def _trakt_row(media, node, when):
    """A Trakt film or show (trakt_api._titles) as a row - IMDb id first, else tmdb:; its own pictures."""
    from . import trakt_lists
    ids = node.get('ids') or {}
    imdb = str(ids.get('imdb') or '')
    cid = imdb if imdb.startswith('tt') else ('tmdb:%s' % ids['tmdb'] if ids.get('tmdb') else '')
    if not cid:
        return None
    images = node.get('images') or {}
    return {'media_type': media, 'canonical_id': cid, 'title': node.get('title') or cid,
            'poster': trakt_lists._poster(node, images), 'background': trakt_lists._background(images), 'clearlogo': '',
            'year': node.get('year') or 0, 'plot': node.get('overview') or '', 'added_at': int(when or 0)}


def _simkl_row(item, kind):
    from . import simkl_api
    cid = simkl_api._canonical_for(item.get('ids') or {})
    if not cid:
        return None
    return {'media_type': 'movie' if kind == 'movies' else 'series', 'canonical_id': cid, 'title': item.get('title') or cid,
            'poster': item.get('poster') or '', 'background': '', 'clearlogo': '', 'year': item.get('year') or 0,
            'plot': item.get('overview') or '',
            'added_at': simkl_api._epoch(item.get('last_watched_at') or item.get('added_to_watchlist_at'))}


def _from_home(card):
    """A Home Next episodes card (tracking_rows.episode_card) in the Library's shape - it plays its episode."""
    return {'title': card.get('title') or '', 'poster': card.get('poster') or '', 'fanart': card.get('fanart') or '',
            'landscape': card.get('landscape') or '', 'clearlogo': card.get('clearlogo') or '',
            'plot': str(card.get('plot') or '')[:PLOT], 'services': [], 'added_at': int(card.get('last_watched_at') or 0),
            'target': dict(card.get('target') or {}), 'subtitle': card.get('subtitle') or '', 'year': 0}


def _mirror(service):
    """The Library's copy of a service's watchlist (library_titles.refresh_list_copy), newest first."""
    from . import library, library_titles
    origins = library._origins()
    rows = library_titles.list_favorites(limit=5000, source=library.TRACKING) or []
    return [row for row in rows if service in library.places_of(row, library.TRACKING, origins)]


def _everything():
    """(cards, {title key: places}) of the Library now - kept INDEX_LIFE seconds."""
    kept = dict(_INDEX)      # one copy: a refresh behind the screen may clear the index between two reads of it
    if kept.get('at', 0) + INDEX_LIFE > time.monotonic():
        return kept['cards'], kept['places']
    from . import library
    cards = library.everything()
    places = {}
    for card in cards:
        target = card['target']
        places[library._same_title(target['media_type'], target['canonical_id'])] = list(card.get('services') or [])
    _INDEX.update(at=time.monotonic(), cards=cards, places=places)
    return cards, places


def _placed(cards):
    """The cards with the places their titles are in the Library at now (a copy each)."""
    from . import library
    _all, places = _everything()
    out = []
    for card in cards:
        target = card.get('target') or {}
        found = places.get(library._same_title(target.get('media_type'), target.get('canonical_id')), [])
        out.append(dict(card, services=list(found)))
    return out


def _section(sid, title, cards):
    return {'id': sid, 'title': title, 'cards': list(cards)}


# ---- what each place shows --------------------------------------------------------------------------

def _meganexus(kept):
    from . import library
    cards, _places = _everything()
    anime = set(kept.get('anime') or [])
    key = lambda card: '%s|%s' % (card['target']['media_type'], card['target']['canonical_id'])
    cards = [dict(c) for c in cards]            # the screen's own copies: the kept index is shared
    return [_section('movies', 'Movies', [c for c in cards if c['target']['media_type'] == 'movie']),
            _section('series', 'Series', [c for c in cards if c['target']['media_type'] == 'series']),
            _section('anime', 'Anime', [c for c in cards if key(c) in anime]),
            _section('device', 'On this device', [c for c in cards if library.LOCAL in (c.get('services') or [])])]


def _nuvio():
    from . import library
    cards = [dict(c) for c in _everything()[0] if library.NUVIO in (c.get('services') or [])]
    return [_section('movies', 'Movies', [c for c in cards if c['target']['media_type'] == 'movie']),
            _section('series', 'Series', [c for c in cards if c['target']['media_type'] == 'series'])]


def _trakt_next():
    from . import tracking_rows
    try:
        return [_from_home(card) for card in tracking_rows._service_next('trakt') or []][:CARDS]
    except Exception:
        return []


def _kept_sections(kept, order=None):
    """The kept sections, in ``order`` (ids) when given, the others after them."""
    found = [s for s in kept.get('sections') or [] if isinstance(s, dict) and s.get('id')]
    if order:
        found.sort(key=lambda s: order.index(s['id']) if s['id'] in order else len(order))
    return [_section(s['id'], s.get('title') or '', _placed(s.get('cards') or [])) for s in found]


def sections(place, cached_only=True):
    """[{'id', 'title', 'cards'}] of one place, in the order shown; [] for a place not connected. No network
    (``cached_only=False``: the place is read first, here)."""
    if place not in PLACES or not _connected(place):
        return []
    if not cached_only:
        refresh(place)
    kept = _kept(place)
    if place == 'meganexus':
        return _meganexus(kept)
    if place == 'nuvio':
        return _nuvio()
    if place == 'trakt':
        mine = _kept_sections(kept)
        lists = [s for s in mine if s['id'].startswith('list:')]
        other = dict((s['id'], s) for s in mine if not s['id'].startswith('list:'))
        return ([_section('watchlist', 'Watchlist', _placed(_cards(_mirror('trakt')))),
                 _section('next', 'Next episodes', _placed(_trakt_next()))] + lists +
                [other.get(sid) or _section(sid, title, []) for sid, title in TRAKT_MORE])
    if place == 'wetrakr':
        return [_section('favorites', 'Favorites', _placed(_cards(_mirror('wetrakr'))))] + \
            _with_unread(_kept_sections(kept), [(sid, title) for sid, title in WETRAKR])
    if place == 'simkl':
        return _with_unread(_kept_sections(kept), [(sid, title) for sid, title, _asked in SIMKL])
    if place == 'mdblist':
        mine = _kept_sections(kept)
        fixed = [sid for sid, _title in MDBLIST]
        return _with_unread([s for s in mine if s['id'] in fixed], list(MDBLIST)) + \
            [s for s in mine if s['id'].startswith('list:')] + [s for s in mine if s['id'].startswith('liked:')]
    from . import anime_lists
    return _with_unread(_kept_sections(kept), [('airing', 'Airing now')] +
                        [(sid, title) for sid, title, _states in anime_lists.SECTIONS])


def _with_unread(found, wanted):
    """``wanted`` (id, title) in its order - the kept section, else an empty one not read yet."""
    have = dict((s['id'], s) for s in found)
    return [have.get(sid) or _section(sid, title, []) for sid, title in wanted]


# ---- reading a place again (network) ----------------------------------------------------------------

def _read_trakt(kept_before):
    """Its lists, recommendations and history; a part Trakt did not answer keeps what was read of it before."""
    from . import trakt_api, tracking_rows
    if time.time() - tracking_rows._asked('trakt') >= tracking_rows.FRESH:
        tracking_rows.refresh(tracking_rows.NEXT, 'trakt')      # Home's Next episodes (Trakt's Up Next), kept there
    before = dict((s.get('id'), s) for s in kept_before.get('sections') or [] if isinstance(s, dict))

    def part(sid, title, read):
        try:
            return _section(sid, title, _cards(_trakt_row(*found) for found in read()))
        except Exception as exc:
            _log('Trakt %s not read (%s)' % (sid, getattr(exc, 'code', '') or type(exc).__name__))
            return before.get(sid)
    try:
        lists = trakt_api.own_lists()
    except Exception as exc:
        _log('Trakt lists not read (%s)' % (getattr(exc, 'code', '') or type(exc).__name__))
        lists = [{'id': sid[5:], 'name': s.get('title') or ''} for sid, s in before.items() if str(sid).startswith('list:')]
    found = [part('list:%s' % listed['id'], listed['name'] or 'List', lambda listed=listed: trakt_api.list_titles(listed['id']))
             for listed in lists]
    read = {'recommended': trakt_api.recommendations, 'history': trakt_api.recently_watched, 'collection': trakt_api.collection,
            'popular': lambda: trakt_api.public_titles('popular'), 'anticipated': lambda: trakt_api.public_titles('anticipated')}
    found += [part(sid, title, read[sid]) for sid, title in TRAKT_MORE]
    return {'sections': [section for section in found if section]}


def _read_simkl(kept_before):
    """Simkl's lists - read again only when its activities changed, or when a section was not read in full last
    time (a list not answered keeps what it had, and the activities are kept only with every list answered: one
    failed read had kept empty sections until something changed on the account) or is new here."""
    from . import simkl_api
    activities = simkl_api._request('/sync/activities', auth=True)
    before = dict((s.get('id'), s) for s in kept_before.get('sections') or [] if isinstance(s, dict))
    if before and activities and activities == kept_before.get('activities') and set(before) == set(sid for sid, _t, _a in SIMKL):
        return {'sections': kept_before['sections'], 'activities': activities}     # nothing changed there
    found, whole = [], True
    for sid, title, asked in SIMKL:
        rows = []
        try:
            for kind, status in asked:
                rows += [_simkl_row(item, kind) for item in simkl_api.all_items(kind, status, strict=True)]
        except Exception as exc:
            _log('Simkl %s not read (%s)' % (sid, getattr(exc, 'code', '') or type(exc).__name__))
            whole = False
            if before.get(sid):
                found.append(before[sid])
            continue
        rows = sorted((row for row in rows if row), key=lambda row: -int(row.get('added_at') or 0))
        found.append(_section(sid, title, _cards(rows)))
    return {'sections': found, 'activities': activities if whole else None}


def _read_mdblist(kept_before):
    """Its watchlist (films, series), its official Trending list, the user's lists and the liked ones - a part MDBList
    did not answer keeps what was read of it before."""
    from . import mdblist_api
    before = dict((s.get('id'), s) for s in kept_before.get('sections') or [] if isinstance(s, dict))

    def part(sid, title, read):
        try:
            return _section(sid, title, _cards(read()))
        except Exception as exc:
            _log('MDBList %s not read (%s)' % (sid, getattr(exc, 'status', '') or type(exc).__name__))
            return before.get(sid)
    try:
        items, _cursor = mdblist_api.watchlist_rows(limit=CARDS * 2)            # one request for both kinds
        watchlist = [row for row in (mdblist_api._copy_row(item) for item in items or []) if row]
    except Exception as exc:
        _log('MDBList watchlist not read (%s)' % (getattr(exc, 'status', '') or type(exc).__name__))
        watchlist = None
    found = [part(sid, title, lambda kind=kind: [r for r in watchlist if r['media_type'] == kind]) if watchlist is not None
             else before.get(sid) for (sid, title), kind in zip(MDBLIST[:2], ('movie', 'series'))]
    found.append(part('trending', 'Trending on MDBList', lambda: mdblist_api.official_copy_rows('trending', CARDS)))
    for prefix, lists in (('list', lambda: mdblist_api.own_lists()[:MDBLIST_LISTS]), ('liked', lambda: mdblist_api.liked_lists(MDBLIST_LIKED))):
        try:
            listed = lists()
        except Exception as exc:
            _log('MDBList %s lists not read (%s)' % (prefix, type(exc).__name__))
            listed = [{'id': sid.split(':', 1)[1], 'name': s.get('title') or ''} for sid, s in before.items() if str(sid).startswith(prefix + ':')]
        for row in listed:
            if row.get('id'):
                found.append(part('%s:%s' % (prefix, row['id']), row.get('name') or 'List',
                                  lambda row=row: mdblist_api.list_copy_rows(row['id'], CARDS)))
    return {'sections': [section for section in found if section]}


def _read_wetrakr(_kept_before):
    from . import wetrakr_api
    lists = wetrakr_api.tracking_copy_rows()
    rows = lambda status: sorted(lists.get(status) or [], key=lambda row: -int(row.get('added_at') or 0))
    return {'sections': [_section(sid, title, _cards(rows(sid))) for sid, title in WETRAKR]}


def _read_anime(place):
    from . import anime_lists
    return {'sections': [_section(sid, title, _cards(rows)) for sid, title, rows in anime_lists.section_rows(place)]}


def _read_meganexus(_kept_before):
    """Which of the Library's titles are anime (no network but the list of anime ids' own first download)."""
    from . import library
    cards, _places = _everything()
    return {'anime': sorted('%s|%s' % (c['target']['media_type'], c['target']['canonical_id'])
                            for c in cards if library.is_anime(c))}


READERS = {'meganexus': _read_meganexus, 'trakt': _read_trakt, 'simkl': _read_simkl, 'mdblist': _read_mdblist,
           'wetrakr': _read_wetrakr, 'anilist': lambda kept: _read_anime('anilist'), 'mal': lambda kept: _read_anime('mal')}


def _content(data):
    return dict((key, value) for key, value in (data or {}).items() if key not in ('at', 'account'))


def refresh(place, force=False):
    """Read one place again and keep it (network: never on the GUI thread). Not before FRESH has passed since
    it was last read for this account (``force``: now); one reading of a place at a time. True when what it
    shows changed."""
    reader = READERS.get(place)
    if not reader or not _connected(place):
        return False
    lock = _LOCKS[place]
    if not lock.acquire(False):
        return False                                   # being read already
    try:
        kept = _kept(place)
        if not force and kept and time.time() - float(kept.get('at') or 0) < FRESH[place]:
            return False
        try:
            fresh = reader(kept)
        except Exception as exc:
            _log('%s not read (%s)' % (place, getattr(exc, 'code', '') or type(exc).__name__))
            return False
        changed = _content(fresh) != _content(kept)
        _write(place, dict(fresh, at=int(time.time()), account=_account(place)))
        if changed:
            _INDEX.clear()
        return changed
    finally:
        lock.release()
