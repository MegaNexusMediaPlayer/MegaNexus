# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Remember successfully started sources for a bounded Continue Watching reuse.

Stored only in the existing local cache. Profile/account/provider changes give
a different hashed key; playback tokens and old resume positions are not saved.
"""
import hashlib
import json
import time
from . import cache_store
from .settings_cache import cached_addon

SETTING='meganexus_reuse_last_link_hours'
KIND='meganexus_last_source'
HOURS=('0','12','24')
LABELS={'0':'Off','12':'12 hours','24':'24 hours'}
SERVER_KEYS=('server_type','server_url','token','rating_key','item_id','duration_ms',
             'media_source_id','play_session_id','device_id','session_id','server_flavor',
             'client_id','device_name','product','product_version')


def hours(addon=None):
    value=(addon or cached_addon()).getSetting(SETTING) or '12'
    return int(value) if value in HOURS else 12


def _scope():
    from . import stream_providers
    from .meganexus.common import profile_path
    from .meganexus.nuvio_stremio_sync import Nuvio
    token=Nuvio.token() or {}
    account=(token.get('user_id') or token.get('email'),token.get('profile_index')) if token.get('access_token') else None
    # 7.0.31: an AIOStreams link copied again (only its encrypted part changes) is the
    # same add-on - its new link made every remembered source ask for a source again.
    from .meganexus.store import instance_key
    providers=sorted((p.get('id'),instance_key(p.get('manifest_url')) or p.get('base_url')) for p in stream_providers.enabled())
    addon=cached_addon()
    debrid=[addon.getSetting(k) for k in ('torbox_api_key','torbox_enabled','premiumize_api_key','premiumize_enabled',
                                     'offcloud_api_key','offcloud_enabled','easynews_login','easynews_enabled','usenet_server','newznab_indexers','prowlarr_server')]
    servers=[addon.getSetting(k) for k in ('plex_auth_json','jellyfin_auth_json','emby_auth_json')]   # 7.0.29: Jellyfin and Emby separate
    try:
        from .user_profiles import active as who   # 7.0.45: each profile's own last links
        person=who()
    except Exception:
        person=''
    values=(profile_path(),account,providers,debrid,servers,
            [addon.getSetting(k) for k in ('meganexus_plex_enabled','meganexus_jellyfin_enabled','meganexus_emby_enabled')])
    if person and person!='main':values=values+(person,)   # the first profile keeps the links it had
    return hashlib.sha256(json.dumps(values,sort_keys=True,default=str).encode()).hexdigest()


def _key(context,scope=None):
    media=context.get('media_type') or 'movie'
    title=context.get('canonical_id') or ''
    video=context.get('video_id') or title
    if not title or not video:return ''
    identity=(scope or _scope(),media,title,video,str(context.get('season') or ''),str(context.get('episode') or ''))
    return hashlib.sha256(json.dumps(identity).encode()).hexdigest()


def _aliases(canonical='',imdb='',tmdb=''):
    """7.0.45: the forms one title goes by - a card opens it as tmdb:120, Continue
    Watching as tt0120737; the link chosen under one is found under the other."""
    found=[]
    for value in (canonical,'tt%s'%str(imdb)[2:] if str(imdb).startswith('tt') else '',
                  'tmdb:%s'%str(tmdb).split(':')[-1] if str(tmdb).split(':')[-1].isdigit() else ''):
        value=str(value or '').strip()
        if value and value not in found:found.append(value)
    return found


def _alias_keys(context,aliases,scope=None):
    media=context.get('media_type') or 'movie'
    scope=scope or _scope()
    season,episode=str(context.get('season') or ''),str(context.get('episode') or '')
    # the episode part of the video id (tt1:1:2 / tmdb:5:1:2 -> ':1:2'), whatever the title's form
    video,head=str(context.get('video_id') or ''),str(context.get('canonical_id') or '')
    tail=video[len(head):] if head and video.startswith(head) else '|'+video
    return [hashlib.sha256(json.dumps((scope,media,'title',alias,tail,season,episode)).encode()).hexdigest() for alias in aliases]


def remember(context):
    """Call only after matching AVStarted, never after merely queueing a URL."""
    if not hours() or not context.get('stream_url') or context.get('_last_source_reused'):return
    if context.get('_last_source_scope') and context['_last_source_scope']!=_scope():return
    key=_key(context)
    if not key:return
    row={'url':context['stream_url'],'name':context.get('stream_name') or '',
         'title':context.get('stream_title') or '', 'requestHeaders':context.get('request_headers') or {},
         'behaviorHints':context.get('behaviorHints') or {},'subtitles':context.get('subtitles') or [],
         '_meganexus_source':{'id':context.get('provider_id') or '',
             'name':context.get('provider_name') or '', 'base_url':context.get('provider_base_url') or ''}}
    if context.get('server_type'):row['_meganexus_server']={k:context[k] for k in SERVER_KEYS if k in context}
    value={'selected_at':time.time(),'row':row}
    if len(json.dumps(value).encode())>65536:return
    scope=_scope()
    value['keys']=[key]+_alias_keys(context,_aliases(context.get('canonical_id'),context.get('imdb_id'),context.get('tmdb_id')),scope)
    for each in value['keys']:
        cache_store.update(KIND,each,value)


def tag(context):
    context['_last_source_scope']=_scope()
    return context


def context(meta,current):
    """Return a fresh playback context, or let the normal source search run."""
    if current.get('force_manual') or current.get('play_from_start'):return None
    if not current.get('meganexus_continue') and not current.get('resume_seconds') and not current.get('resume_percent'):return None
    limit=hours()
    if not limit:return None
    target=dict(current,media_type=meta.get('type') or 'movie',canonical_id=meta['id'],video_id=current.get('video_id') or meta['id'])
    key=_key(target)
    if not key:return None
    try:
        from .art import extract_ids
        ids=extract_ids(meta) or {}
    except Exception:
        ids={}
    tmdb=ids.get('tmdb_id') or meta.get('tmdb_id') or meta.get('moviedb_id') or current.get('tmdb_id')
    aliases=_aliases(meta['id'],ids.get('imdb_id') or meta.get('imdb_id') or current.get('imdb_id'),tmdb)
    scope=_scope()
    keys=[key]+_alias_keys(target,aliases,scope)
    # links kept before 7.0.45: under the id the title was opened with, its episode's id alike
    video=str(target['video_id']);head=str(target['canonical_id'])
    for alias in aliases[1:]:
        old=_key(dict(target,canonical_id=alias,video_id=alias+video[len(head):] if video.startswith(head) else alias),scope)
        if old:keys.append(old)
    found=[(k,cache_store.get(KIND,k)) for k in keys]
    found=[(k,v) for k,v in found if isinstance(v,dict) and v.get('row')]
    if not found:return None
    key,saved=max(found,key=lambda item:float(item[1].get('selected_at') or 0))
    try:
        age=time.time()-float(saved.get('selected_at',0))
        if not 0<=age<limit*3600:return None
        row=saved['row']
        if not isinstance(row,dict) or not row.get('url'):return None
        from . import backend_api
        result=backend_api.playback_context(meta,row,row['_meganexus_source'],
             current.get('season',''),current.get('episode',''),target['video_id'],current.get('resume_seconds') or 0)
        result.update(resume_percent=current.get('resume_percent') or 0,
                      _last_source_reused=True,_last_source_key=key,
                      _last_source_keys=list(dict.fromkeys([k for k,_ in found]+list(saved.get('keys') or []))),
                      _last_source_selected_at=saved['selected_at'])
        return result
    except (ValueError,TypeError,KeyError):return None


def forget(context):
    for key in context.get('_last_source_keys') or [context.get('_last_source_key')]:
        if not key:continue
        saved=cache_store.get(KIND,key)
        if isinstance(saved,dict) and saved.get('selected_at')==context.get('_last_source_selected_at'):
            cache_store.update(KIND,key,{})
