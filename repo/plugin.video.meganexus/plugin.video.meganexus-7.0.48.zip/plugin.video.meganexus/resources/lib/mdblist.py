# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import re
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon

# --- meganexus-401-patch ---
try:
    from .settings_cache import cached_addon as _dh_cached_addon
except Exception:
    try:
        from settings_cache import cached_addon as _dh_cached_addon
    except Exception:
        _dh_cached_addon = None
ADDON = _dh_cached_addon() if _dh_cached_addon else xbmcaddon.Addon('plugin.video.meganexus')
API = 'https://api.mdblist.com'
_URL_RE = re.compile(r'^/lists/(?P<username>[^/]+)/(?P<slug>[^/?#]+)')
_CACHE = {}
_CACHE_TTL = 300
_CACHE_BYTES = 8 * 1024 * 1024     # 7.0.37: list pages kept in memory, by their JSON size
_CACHE_USED = [0]


def _remember(key, data, has_more, size):
    """Keep an answer for _CACHE_TTL: expired and oldest answers go first, so
    the cache never grows past _CACHE_BYTES (it only checked the age before)."""
    now = _time.time()
    old = _CACHE.pop(key, None)
    if old is not None:
        _CACHE_USED[0] -= old[3]
    for stale in [k for k, v in _CACHE.items() if now - v[0] > _CACHE_TTL]:
        _CACHE_USED[0] -= _CACHE.pop(stale)[3]
    if size > _CACHE_BYTES // 2:
        return
    while _CACHE and _CACHE_USED[0] + size > _CACHE_BYTES:
        _CACHE_USED[0] -= _CACHE.pop(next(iter(_CACHE)))[3]
    _CACHE[key] = (now, data, has_more, size)
    _CACHE_USED[0] += size


class MDBListError(Exception):
    """Typed API failure so the UI never mistakes an error for an empty list."""

    def __init__(self, message, status=0, code='', details=''):
        super().__init__(str(message or 'MDBList request failed'))
        self.status = int(status or 0)
        self.code = str(code or '')
        self.details = str(details or '')


def _error_message(status=0, details=''):
    status = int(status or 0)
    detail = str(details or '').strip()
    if status == 401:
        return 'The MDBList API key is invalid or expired.'
    if status == 403:
        return 'MDBList denied access to this account.'
    if status == 429:
        return 'MDBList rate limit reached. Wait a moment and refresh.'
    if status >= 500:
        return 'MDBList is temporarily unavailable (HTTP %d).' % status
    if status:
        return 'MDBList request failed (HTTP %d)%s' % (
            status, (': %s' % detail[:160]) if detail else '.')
    return detail or 'Could not connect to MDBList.'


def _response_error_detail(body):
    body = str(body or '').strip()
    if not body:
        return ''
    try:
        data = json.loads(body)
    except Exception:
        return body[:240]
    if isinstance(data, dict):
        return str(data.get('message') or data.get('error') or data.get('detail') or '')[:240]
    return body[:240]


def clear_cache():
    _CACHE.clear()
    _CACHE_USED[0] = 0


def _setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


def _headers():
    return {
        'Accept': 'application/json',
        'User-Agent': 'MegaNexus/%s (Kodi)' % (ADDON.getAddonInfo('version') or '3.8.9'),
    }


def _request(path, params=None, timeout=20):
    import time as _time
    params = dict(params or {})
    api_key = (_setting('mdblist_api_key', '') or '').strip()
    if api_key and 'apikey' not in params:
        params['apikey'] = api_key
    url = API + path
    if params:
        url += '?' + urllib.parse.urlencode(params)
    cache_key = url
    cached = _CACHE.get(cache_key)
    if cached and (_time.time() - cached[0]) <= _CACHE_TTL:
        return cached[1], cached[2]
    req = urllib.request.Request(url, headers=_headers(), method='GET')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            _note_quota(resp.headers)
            body = resp.read().decode('utf-8', 'ignore')
            try:
                data = json.loads(body) if body else {}
            except Exception as exc:
                raise MDBListError('MDBList returned invalid JSON.',
                                   status=getattr(resp, 'status', 0),
                                   code='invalid_json', details=str(exc))
            has_more = str(resp.headers.get('X-Has-More') or '').strip().lower() == 'true'
            next_cursor = str(resp.headers.get('X-Next-Cursor') or '').strip()
            # MDBList's cursor can arrive in a header even when the JSON body
            # uses the legacy top-level shape. Preserve it without changing
            # the public (data, has_more) return contract used by callers.
            if isinstance(data, dict) and (next_cursor or has_more):
                data = dict(data)
                data['_meganexus_meta'] = {
                    'next_cursor': next_cursor,
                    'has_more': has_more,
                }
            _remember(cache_key, data, has_more, len(body))
            return data, has_more
    except MDBListError:
        raise
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode('utf-8', 'ignore')
        except Exception:
            body = ''
        detail = _response_error_detail(body)
        raise MDBListError(_error_message(exc.code, detail), status=exc.code,
                           code='http_error', details=detail)
    except urllib.error.URLError as exc:
        detail = str(getattr(exc, 'reason', '') or exc)
        raise MDBListError(_error_message(0, 'Could not connect to MDBList: %s' % detail),
                           code='network_error', details=detail)
    except Exception as exc:
        raise MDBListError(_error_message(0, 'Could not connect to MDBList: %s' % exc),
                           code='network_error', details=str(exc))


def api_key():
    return (_setting('mdblist_api_key', '') or '').strip()


def configured():
    return bool(api_key())


def authorization_status():
    return 'connected' if configured() else 'needs_api'


def fetch_user_info(strict=False):
    """GET /user — account limits/profile. Empty dict when the key is bad."""
    if not configured():
        return {}
    try:
        data, _ = _request('/user')
    except Exception:
        if strict:
            raise
        return {}
    return data if isinstance(data, dict) else {}


def fetch_my_lists():
    """GET /lists/user — the account's own lists.

    Normalized rows: {'id', 'name', 'slug', 'user_name', 'items',
    'mediatype'} — enough for the my-lists folder and the authenticated
    numeric-id item route.
    """
    if not configured():
        return []

    def _list_payload(value):
        if isinstance(value, list):
            return value
        if isinstance(value, dict):
            for key in ('lists', 'results', 'data'):
                candidate = value.get(key)
                if isinstance(candidate, list):
                    return candidate
                if isinstance(candidate, dict):
                    nested = candidate.get('lists') or candidate.get('results')
                    if isinstance(nested, list):
                        return nested
        return []

    # Current MDBList contract: /lists/user is a top-level array. Do NOT pass
    # unified=true here: MDBList then replaces the required numeric `id` with
    # an `ids` array for movie/show twins. The menu opens each private list by
    # numeric id, so non-unified rows are the correct foundation.
    data, _ = _request('/lists/user', params={'sort': 'ranked'})
    list_rows = _list_payload(data)

    # A few deployed API revisions returned an empty /lists/user payload while
    # the account-scoped path still contained the lists. Only pay for this
    # compatibility fallback when the primary response is genuinely empty.
    if not list_rows:
        info = fetch_user_info(strict=True) or {}
        account = info.get('user') if isinstance(info.get('user'), dict) else info
        identities = []
        for key in ('id', 'user_id', 'userid', 'username', 'user_name', 'name'):
            value = str((account or {}).get(key) or '').strip()
            if value and value not in identities:
                identities.append(value)
        for identity in identities[:2]:
            try:
                fallback, _ = _request(
                    '/lists/user/%s' % urllib.parse.quote(identity),
                    params={'sort': 'ranked'})
            except MDBListError as exc:
                if exc.status in (400, 404, 405):
                    continue
                raise
            list_rows = _list_payload(fallback)
            if list_rows:
                break

    data = list_rows
    if isinstance(data, dict):
        data = data.get('lists') or data.get('results') or data.get('data') or []
    rows = []
    for row in (data if isinstance(data, list) else []):
        if not isinstance(row, dict):
            continue
        try:
            item_count = int(row.get('items') or row.get('item_count') or row.get('count') or 0)
        except Exception:
            item_count = 0
        rows.append({
            'id': str(row.get('id') or ''),
            'name': row.get('name') or row.get('slug') or '',
            'slug': str(row.get('slug') or ''),
            'user_name': str(row.get('user_name') or row.get('username') or ''),
            'items': item_count,
            'mediatype': str(row.get('mediatype') or ''),
            'description': row.get('description') or '',
            'private': bool(row.get('private') or row.get('is_private')),
            'dynamic': bool(row.get('dynamic') or row.get('is_dynamic')),
            'updated_at': str(row.get('last_updated_at') or row.get('updated_at') or
                              row.get('updated') or ''),
        })
    return rows


def _offset_cursor(value):
    value = str(value or '').strip()
    if not value.startswith('offset:'):
        return None
    try:
        return max(0, int(value.split(':', 1)[1]))
    except Exception:
        return None


def _apply_page_cursor(params, cursor):
    offset = _offset_cursor(cursor)
    if offset is not None:
        params['offset'] = offset
    elif cursor:
        params['cursor'] = cursor


def _normalize_items_response(data, has_more, mf, current_cursor='', limit=100):
    """Shared shape for list-items and watchlist-items responses."""
    def _true(value):
        if isinstance(value, str):
            return value.strip().lower() in ('1', 'true', 'yes', 'on')
        return bool(value)

    rows = []
    next_cursor = ''
    pagination = {}
    if isinstance(data, dict):
        pagination = data.get('pagination') if isinstance(data.get('pagination'), dict) else {}
        response_meta = data.get('_meganexus_meta') if isinstance(data.get('_meganexus_meta'), dict) else {}
        next_cursor = str(
            pagination.get('next_cursor') or data.get('next_cursor') or
            response_meta.get('next_cursor') or ''
        ).strip()
        has_more = any(_true(value) for value in (
            has_more, pagination.get('has_more'), response_meta.get('has_more')))
        for row in (data.get('movies') or []):
            if isinstance(row, dict):
                item = dict(row)
                item.setdefault('_type', 'movie')
                rows.append(item)
        for row in (data.get('shows') or []):
            if isinstance(row, dict):
                item = dict(row)
                item.setdefault('_type', 'show')
                rows.append(item)
    elif isinstance(data, list):
        for row in data:
            if isinstance(row, dict):
                item = dict(row)
                raw_type = str(
                    item.get('_type') or item.get('mediatype') or
                    item.get('media_type') or item.get('type') or '').lower()
                if raw_type in ('movie', 'movies'):
                    item['_type'] = 'movie'
                elif raw_type in ('show', 'shows', 'series', 'tv', 'tvshow', 'anime'):
                    item['_type'] = 'show'
                else:
                    item.setdefault('_type', 'movie' if mf in ('movie', 'movies') else 'show')
                rows.append(item)
    raw_count = len(rows)
    if not has_more and isinstance(pagination, dict):
        try:
            total = int(pagination.get('total') or pagination.get('total_items') or 0)
            page_offset = int(pagination.get('offset') or _offset_cursor(current_cursor) or 0)
            has_more = bool(total and (page_offset + raw_count) < total)
        except Exception:
            pass
    if not next_cursor and has_more:
        # List-items endpoints historically page with offset + X-Has-More,
        # while newer MDBList endpoints expose next_cursor. Encode the offset
        # as an opaque route cursor so the Kodi UI can support both contracts.
        base_offset = _offset_cursor(current_cursor)
        if base_offset is None:
            try:
                base_offset = int(pagination.get('offset') or 0) if isinstance(data, dict) else 0
            except Exception:
                base_offset = 0
        # Advance by the unfiltered response count. If a mixed page contains
        # 70 movies and 30 shows, filtering to shows must still move offset 100.
        step = raw_count or max(1, int(limit or 100))
        next_cursor = 'offset:%d' % (base_offset + step)

    # v4.4.1: some MDBList responses (unified mode, future revisions) nest
    # identifiers under `ids` as a dict or even an ARRAY of dicts. Flatten
    # them into the imdb_id/tvdb_id/id fields the renderer reads, so a shape
    # change can never again render a whole list empty.
    for item in rows:
        nested = item.get('ids')
        candidates = []
        if isinstance(nested, dict):
            candidates = [nested]
        elif isinstance(nested, list):
            candidates = [c for c in nested if isinstance(c, dict)]
        for cand in candidates:
            if not item.get('imdb_id') and cand.get('imdb'):
                item['imdb_id'] = cand.get('imdb')
            if not item.get('tvdb_id') and cand.get('tvdb'):
                item['tvdb_id'] = cand.get('tvdb')
            if not item.get('id') and cand.get('tmdb'):
                item['id'] = cand.get('tmdb')
        if candidates and not isinstance(nested, dict):
            item.pop('ids', None)

    mf = str(mf or 'auto').strip().lower()
    if mf in ('movie', 'movies'):
        rows = [row for row in rows if row.get('_type') == 'movie']
    elif mf in ('show', 'shows', 'series', 'tv', 'tvshow', 'anime'):
        rows = [row for row in rows if row.get('_type') == 'show']
    if not rows and data:
        try:
            shape = list(data.keys())[:6] if isinstance(data, dict) else 'list[%d]' % len(data)
            first = data
            if isinstance(data, dict):
                for key in ('movies', 'shows'):
                    if data.get(key):
                        first = data[key]
                        break
            first_keys = list(first[0].keys())[:10] if isinstance(first, list) and first and isinstance(first[0], dict) else '-'
            xbmc.log('[MegaNexus] MDBList items normalized to 0 rows (mf=%s) shape=%r first_row_keys=%r'
                     % (mf, shape, first_keys), xbmc.LOGWARNING)
        except Exception:
            pass
    return rows, next_cursor


def _items_path_suffix(mf):
    if mf in ('movie', 'movies'):
        return '/items/movie', False
    if mf in ('show', 'shows', 'series', 'tv', 'anime'):
        return '/items/show', False
    # v4.4.1: auto no longer requests unified (see fetch_items_by_id).
    return '/items', False


def fetch_items_by_id(list_id, media_filter='auto', cursor='', limit=100):
    """Items of one of the account's lists by numeric id (GET /lists/{id}/items)."""
    list_id = str(list_id or '').strip()
    if not list_id:
        return [], ''
    mf = str(media_filter or 'auto').strip().lower()
    # Numeric/private list endpoint has one path only: /lists/{id}/items.
    # Media-specific suffixes belong to the deprecated username/slug routes.
    # v4.4.1: NO unified=true here. Unified responses replace the flat
    # imdb_id/tvdb_id fields with an `ids` ARRAY for movie/show twins —
    # the renderer's id extraction gets nothing and every private list
    # opened empty ('list is empty'). Non-unified keeps the classic
    # movies/shows buckets with flat ids: exactly what the renderer eats.
    params = {'limit': int(limit or 100)}
    offset = _offset_cursor(cursor)
    if offset is None and str(cursor or '').isdigit():
        offset = int(cursor)
    if offset is not None:
        params['offset'] = offset
    data, has_more = _request(
        '/lists/%s/items' % urllib.parse.quote(list_id), params=params)
    return _normalize_items_response(data, has_more, mf, current_cursor=cursor, limit=limit)


def fetch_watchlist_items(media_filter='auto', cursor='', limit=100):
    """The account watchlist (GET /watchlist/items). Same row shape as lists."""
    if not configured():
        return [], ''
    mf = str(media_filter or 'auto').strip().lower()
    suffix, unified = _items_path_suffix(mf)
    params = {'limit': int(limit or 100)}
    _apply_page_cursor(params, cursor)
    if unified:
        params['unified'] = 'true'
    data, has_more = _request('/watchlist%s' % suffix, params=params)
    return _normalize_items_response(data, has_more, mf, current_cursor=cursor, limit=limit)


def parse_list_url(url):
    url = (url or '').strip()
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception:
        return None
    host = (parsed.netloc or '').lower()
    if 'mdblist.com' not in host:
        return None
    match = _URL_RE.match(parsed.path or '')
    if not match:
        return None
    username = urllib.parse.unquote(match.group('username') or '').strip()
    slug = urllib.parse.unquote(match.group('slug') or '').strip()
    if not username or not slug:
        return None
    return {
        'username': username,
        'slug': slug,
        'url': 'https://mdblist.com/lists/%s/%s' % (
            urllib.parse.quote(username), urllib.parse.quote(slug)
        ),
    }


def fetch_list(username, slug):
    data, _ = _request('/lists/%s/%s' % (
        urllib.parse.quote(str(username or '').strip()),
        urllib.parse.quote(str(slug or '').strip()),
    ))
    if isinstance(data, list) and data:
        return data
    if isinstance(data, dict):
        return [data]
    return []


def fetch_items(username, slug, media_filter='auto', cursor='', limit=100):
    username = str(username or '').strip()
    slug = str(slug or '').strip()
    mf = str(media_filter or 'auto').strip().lower()
    params = {'limit': int(limit or 100)}
    _apply_page_cursor(params, cursor)
    if mf in ('movie', 'movies'):
        path = '/lists/%s/%s/items/movie' % (urllib.parse.quote(username), urllib.parse.quote(slug))
    elif mf in ('show', 'shows', 'series', 'tv', 'anime'):
        path = '/lists/%s/%s/items/show' % (urllib.parse.quote(username), urllib.parse.quote(slug))
    else:
        path = '/lists/%s/%s/items' % (urllib.parse.quote(username), urllib.parse.quote(slug))
        params['unified'] = 'true'
    data, has_more = _request(path, params=params)
    return _normalize_items_response(data, has_more, mf, current_cursor=cursor, limit=limit)


# ── v4.6.3: aggregated ratings — contract verified against TMDb Helper ───
# Source of truth: jurialmunkey/plugin.video.themoviedb.helper @ HEAD
#   lib/api/mdblist/api.py            → get_details(provider='tmdb', …)
#   lib/…/concrete_classes/ratings.py → get_ratings(trakt_type, tmdb_id)
# Verified facts (the old VERIFY-LIVE doubt on the show path is resolved):
#   * Path shape is /{provider}/{movie|show}/{id}. TMDb Helper queries by
#     TMDB id ('tmdb' provider); 'show' IS the correct TV segment. We prefer
#     the tmdb path too (v4.5.0 defers IMDb resolution, so tmdb_id is the id
#     we reliably hold when the picker opens) and keep /imdb as fallback.
#   * Raw scales in the response (per TMDb Helper's normalizers):
#       imdb /10 · trakt /100 · tomatoes|tomatoesaudience|metacritic /100 ·
#       letterboxd /5 (5-star) · myanimelist /10 ·
#       MDBList's own score = TOP-LEVEL 'score' (/100), NOT an array row.
_RATINGS_CACHE = {}
_RATINGS_TTL = 24 * 3600           # 7.0.30: a day, also on disk (ratings move slowly)
_RATINGS_FILE = 'mdblist-ratings.json'
_RATINGS_LOADED = []
BATCH_SIZE = 200                   # MDBList's Media Info Batch takes up to 200 ids
PRELOAD_SHARE = .6                 # the opening screen may use 60 % of the day's requests ...
_QUOTA = {}                        # ... the rest stays for titles opened while browsing

_RATING_SOURCE_MAP = {
    'imdb': 'imdb',
    'metacritic': 'metacritic',
    'trakt': 'trakt',
    'tmdb': 'tmdb',                 # 7.0.29: /100, as Nuvio reads it
    'tomatoes': 'rt_crit',
    'tomatoesaudience': 'rt_aud',
    'popcorn': 'rt_aud',            # MDBList's name for the RT audience score
    'audience': 'rt_aud',
    'letterboxd': 'letterboxd',
    'myanimelist': 'mal',
    'mal': 'mal',
    'score_average': 'mdblist',
}


def _ratings_kind(media_type):
    return 'show' if str(media_type or '').lower() in (
        'series', 'show', 'tv', 'anime', 'tvshow') else 'movie'


def _ratings_cache_keys(kind, imdb_id='', tmdb_id=''):
    """One title may be warmed by tmdb id and read back by imdb id (or the
    reverse), so every store/read uses BOTH keys."""
    keys = []
    tmdb_id = str(tmdb_id or '').strip()
    imdb_id = str(imdb_id or '').strip()
    if tmdb_id:
        keys.append('%s:tmdb:%s' % (kind, tmdb_id))
    if imdb_id:
        if not imdb_id.startswith('tt'):
            imdb_id = 'tt%s' % imdb_id
        keys.append('%s:%s' % (kind, imdb_id))
    return keys


def _ratings_path():
    import os
    from .meganexus.common import profile_path
    return os.path.join(profile_path(), _RATINGS_FILE)


def _read_ratings_file():
    try:
        with open(_ratings_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _load_ratings():
    """7.0.30: ratings kept on disk for a day - shared by the interface and the
    service, and there again after a restart."""
    if _RATINGS_LOADED:
        return
    _RATINGS_LOADED.append(True)
    import time as _time
    now = _time.time()
    for key, (stamp, values) in _read_ratings_file().items():
        if now - stamp <= _RATINGS_TTL and stamp > _RATINGS_CACHE.get(key, (0,))[0]:
            _RATINGS_CACHE[key] = (stamp, values)


def clear_ratings():
    """Forget every stored rating (memory and the day's file)."""
    import os
    _RATINGS_CACHE.clear()
    _RATINGS_LOADED[:] = [True]
    try:
        os.remove(_ratings_path())
    except OSError:
        pass


def _save_ratings():
    import os
    import time as _time
    now = _time.time()
    merged = {key: tuple(value) for key, value in _read_ratings_file().items()}
    for key, value in list(_RATINGS_CACHE.items()):
        if value[1] and value[0] > merged.get(key, (0,))[0]:
            merged[key] = value
    merged = {key: list(value) for key, value in merged.items() if now - value[0] <= _RATINGS_TTL}
    path = _ratings_path()
    try:
        with open(path + '.part', 'w', encoding='utf-8') as handle:
            json.dump(merged, handle, separators=(',', ':'))
        os.replace(path + '.part', path)
    except OSError:
        pass


def cached_ratings(imdb_id='', media_type='movie', tmdb_id=''):
    """Return a fresh ratings hit (memory, then the day's file) without an API request."""
    kind = _ratings_kind(media_type)
    _load_ratings()
    import time as _time
    for cache_key in _ratings_cache_keys(kind, imdb_id=imdb_id, tmdb_id=tmdb_id):
        hit = _RATINGS_CACHE.get(cache_key)
        if hit and (_time.time() - hit[0]) <= _RATINGS_TTL:
            return dict(hit[1])
    return {}


def _parse_ratings(data):
    """MDBList's answer for one title -> {service: display value}."""
    out = {}
    data = data or {}
    for row in data.get('ratings') or []:
        source = str(row.get('source') or '').strip().lower()
        key = _RATING_SOURCE_MAP.get(source)
        value = row.get('value')
        if not key or value in (None, '', 0) or key in out:
            continue
        if key in ('rt_crit', 'rt_aud', 'metacritic', 'mdblist', 'tmdb'):
            out[key] = str(int(float(value)))       # raw 0-100
        elif key == 'trakt':
            # v4.6.3: MDBList serves trakt on /100 (TMDb Helper stores it
            # unconverted in its /100 store) — "75.0" was the old render.
            out[key] = '%.1f' % (float(value) / 10.0)
        else:
            out[key] = '%.1f' % float(value)        # imdb/mal /10, letterboxd /5
    # MDBList's own score lives at the TOP LEVEL of the payload (the
    # array row was a lucky accident on some titles — chip often missing).
    # Certified fresh / verified hot come as MDBList keywords (as in Nuvio).
    names = set()
    for keyword in data.get('keywords') or []:
        name = keyword.get('name') if isinstance(keyword, dict) else keyword
        if isinstance(name, str):
            names.add(name.rsplit('.', 1)[-1].strip().lower())
    if out.get('rt_crit') and 'certified-fresh' in names:
        out['rt_crit_certified'] = '1'
    if out.get('rt_aud') and 'certified-hot' in names:
        out['rt_aud_certified'] = '1'
    for score_key in ('score', 'score_average'):
        value = data.get(score_key)
        if value not in (None, '', 0):
            out['mdblist'] = str(int(float(value)))
            break
    return out


def fetch_ratings(imdb_id='', media_type='movie', timeout=6, tmdb_id=''):
    """Aggregated ratings for one title, normalized to display strings.

    Display scales match what TMDb Helper itself renders, so an MDBList
    overlay value is indistinguishable from a TMDb Helper-provided one:
      imdb/trakt/mal → 0-10 one-decimal · letterboxd → 0-5 one-decimal ·
      rt/metacritic/mdblist → 0-100 integer.
    Returns {} when unconfigured or on any failure — callers overlay these on
    top of whatever TMDb Helper already published, never the other way round.
    """
    kind = _ratings_kind(media_type)
    tmdb_id = str(tmdb_id or '').strip()
    imdb_id = str(imdb_id or '').strip()
    if imdb_id and not imdb_id.startswith('tt'):
        imdb_id = 'tt%s' % imdb_id
    if not configured() or not (tmdb_id or imdb_id):
        return {}
    hit = cached_ratings(imdb_id=imdb_id, media_type=media_type, tmdb_id=tmdb_id)
    if hit:
        return hit
    import time as _time
    out = {}
    try:
        if tmdb_id:
            path = '/tmdb/%s/%s' % (kind, tmdb_id)      # TMDb Helper's own path
        else:
            path = '/imdb/%s/%s' % (kind, imdb_id)
        data, _ = _request(path, params={'append_to_response': 'keyword'}, timeout=timeout)
        out = _parse_ratings(data)
    except Exception as exc:
        xbmc.log('[MegaNexus] mdblist fetch_ratings(%s/%s) failed: %s'
                 % (tmdb_id or imdb_id, kind, exc), xbmc.LOGDEBUG)
        out = {}
    stamp = (_time.time(), dict(out))
    for cache_key in _ratings_cache_keys(kind, imdb_id=imdb_id, tmdb_id=tmdb_id):
        _RATINGS_CACHE[cache_key] = stamp
    if out:
        _save_ratings()
    return out


def warm_ratings_async(imdb_id='', media_type='movie', tmdb_id=''):
    """v4.6.3: background cache warm-up.

    The v4.2.2 design ("reuse a warm MDBList result while the source picker
    opens; never fetch in the hot path") shipped without anything that ever
    WARMED the cache — fetch_ratings had zero network callers, so the
    Letterboxd / MDBList / MAL chips (which have no TMDb Helper alias) never
    rendered at all. The source scan now queues this once in MegaNexus's bounded
    optional-work lane while the providers are being queried anyway.
    """
    if not configured() or not (str(tmdb_id or '').strip() or str(imdb_id or '').strip()):
        return
    def _job():
        try:
            fetch_ratings(imdb_id=imdb_id, media_type=media_type, tmdb_id=tmdb_id)
        except Exception:
            pass
    try:
        from .runtime_tasks import submit_optional
        submit_optional(
            _job,
            key='mdblist-rating:%s:%s:%s' % (
                str(media_type or ''), str(tmdb_id or ''), str(imdb_id or '')),
        )
    except Exception as exc:
        xbmc.log('[MegaNexus] mdblist warm task failed: %s' % exc, xbmc.LOGDEBUG)


def _post(path, payload, timeout=20):
    """POST with the key; notes the day's request quota from MDBList's headers."""
    api_key_value = api_key()
    url = API + path + ('?' + urllib.parse.urlencode({'apikey': api_key_value}) if api_key_value else '')
    headers = dict(_headers(), **{'Content-Type': 'application/json'})
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            _note_quota(resp.headers)
            body = resp.read().decode('utf-8', 'ignore')
            return json.loads(body) if body else []
    except urllib.error.HTTPError as exc:
        _note_quota(exc.headers)
        raise MDBListError(_error_message(exc.code), status=exc.code, code='http_error')


def _note_quota(headers):
    try:
        limit = int(headers.get('X-RateLimit-Limit'))
        left = int(headers.get('X-RateLimit-Remaining'))
    except (TypeError, ValueError, AttributeError):
        return
    _QUOTA.update(limit=limit, left=left)


def preload_allowed():
    """The opening screen may ask while more than 40 % of the day's requests are left."""
    if not _QUOTA:
        return True
    return _QUOTA['left'] > _QUOTA['limit'] * (1 - PRELOAD_SHARE)


def preload_ratings(titles, stopped=lambda: False):
    """7.0.30: ratings of many titles at once (Media Info Batch, 200 per request)
    behind the opening screen, so every card shows its ratings at once. Titles
    already known today are skipped; it stops at PRELOAD_SHARE of the day's
    requests. ``titles``: (media type, imdb id, tmdb id). Returns titles stored."""
    if not configured():
        return 0
    import time as _time
    groups = {}
    for media_type, imdb_id, tmdb_id in titles:
        kind = _ratings_kind(media_type)
        imdb_id, tmdb_id = str(imdb_id or '').strip(), str(tmdb_id or '').strip()
        if imdb_id and not imdb_id.startswith('tt'):
            imdb_id = ''
        if not (imdb_id or tmdb_id) or cached_ratings(imdb_id=imdb_id, media_type=kind, tmdb_id=tmdb_id):
            continue
        provider, value = ('imdb', imdb_id) if imdb_id else ('tmdb', tmdb_id)
        groups.setdefault((kind, provider), [])
        if value not in groups[(kind, provider)]:
            groups[(kind, provider)].append(value)
    stored = 0
    for (kind, provider), ids in groups.items():
        for start in range(0, len(ids), BATCH_SIZE):
            if stopped() or not preload_allowed():
                if stored:
                    _save_ratings()
                return stored
            try:
                answer = _post('/%s/%s' % (provider, kind), {'ids': ids[start:start + BATCH_SIZE], 'append_to_response': ['keyword']})
            except Exception as exc:
                xbmc.log('[MegaNexus] mdblist ratings preload stopped: %s' % exc, xbmc.LOGINFO)
                if stored:
                    _save_ratings()
                return stored
            now = _time.time()
            for item in answer if isinstance(answer, list) else []:
                if not isinstance(item, dict):
                    continue
                try:
                    out = _parse_ratings(item)
                except (TypeError, ValueError):
                    continue
                found = item.get('ids') or {}
                if not out:
                    continue
                for cache_key in _ratings_cache_keys(kind, imdb_id=found.get('imdb') or '', tmdb_id=found.get('tmdb') or ''):
                    _RATINGS_CACHE[cache_key] = (now, dict(out))
                stored += 1
    if stored:
        _save_ratings()
    return stored


_METAHUB_POSTER = 'https://images.metahub.space/poster/large/%s/img'


def watchlist_mirror_rows(limit=200):
    """Account watchlist shaped for favorites_store mirror rows (v4.2.0)."""
    out = []
    try:
        rows, _cursor = fetch_watchlist_items(limit=limit)
    except Exception as exc:
        xbmc.log('[MegaNexus] mdblist watchlist mirror failed: %s' % exc, xbmc.LOGDEBUG)
        return out
    for row in rows or []:
        ids = row.get('ids') or {}
        imdb = str(ids.get('imdb') or ids.get('imdb_id') or
                   row.get('imdb_id') or row.get('imdb') or '').strip()
        tmdb = str(ids.get('tmdb') or ids.get('tmdb_id') or
                   row.get('tmdb_id') or row.get('tmdb') or
                   row.get('id') or '').strip()
        canonical = (imdb if imdb.startswith('tt') else ('tt%s' % imdb)) if imdb else ('tmdb:%s' % tmdb if tmdb else '')
        if not canonical:
            continue
        out.append({
            'media_type': 'series' if str(row.get('_type') or '') == 'show' else 'movie',
            'canonical_id': canonical,
            'title': row.get('title') or '',
            'poster': (row.get('poster') or row.get('poster_url') or
                       ((_METAHUB_POSTER % canonical) if canonical.startswith('tt') else '')),
            'background': row.get('backdrop') or row.get('background') or '',
            'clearlogo': row.get('clearlogo') or '',
            'year': row.get('release_year') or row.get('year') or 0,
            'plot': row.get('overview') or '',
        })
    return out
