# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""How a source reads in the source list - formatters (7.0.44).

Every add-on writes its sources its own way (AIOStreams by its formatter,
Torrentio with its icons...). MegaNexus reads the facts out of any row - the
resolution, release type, codec, Dolby Vision / HDR, audio, size, the add-on,
the debrid service and whether it is cached, seeders, the release group, the
file name - and writes them by the chosen formatter: two lines per source.

The formatters are MegaNexus's own templates (in the spirit of the styles
people share for AIOStreams - Torrentio-like, debrid-like, drive-like, minimal,
prism - not copies of them). Template syntax, also for "Your own":
  {field}           the fact, or nothing
  [ ... ]           a group, written only when every {field} inside has a value
  \\[ \\]             brackets of the text itself
  |                 between lines: the first is the title, two more under it
Fields: see FIELDS. Kodi's font has no emoji; symbols like ◈ ▣ ♬ ♯ ✦ ⇄ ⚡ ⚙ ❖ ★ it has.
"""
import re

SETTING = 'meganexus_source_format'          # a formatter id, 'addon' or 'custom'
CUSTOM = 'meganexus_source_format_custom'     # the user's own template

FORMATS = (
    # id, name, template - lines separated by |: the first is the source's title, up
    # to two more under it. 7.0.44: the AIOStreams styles (Torrentio, TorBox, GDrive,
    # Light GDrive, Minimalistic GDrive, Prism, Tamtaro) laid out the same way under
    # our names, their emoji as symbols Kodi's font has (it has no emoji).
    ('cinema', 'Cinema (default)', '{res}[ · {codec}][ · {size}] · {addon}|[{filename}]'),
    ('swarm', 'Swarm', '[\\[{service}{cached_plus}\\] ]{addon} {res}[ {visual}]|[{filename}]|'
                       '[◈ {size}  ][⇄ {seeders}  ][⚙ {indexer}  ][⚑ {languages}]'),
    ('instant', 'Instant', '{addon}[ ({ready_word} {service})][ ({res})]|Quality: {quality_or}[  ·  Size: {size}][  ·  Source: {indexer}]|'
                           'Name: {filename_or}[  ·  Languages: {languages}]'),
    ('drive', 'Drive', '[\\[{service}{cached_bolt}\\] ]{addon} {res}|[▶ {quality}  ][▣ {codec}  ][❖ {group}  ][✦ {visual}  ][♬ {audio}  ][♯ {channels}]|'
                       '[◈ {size}  ][⇄ {seeders}  ][⚙ {indexer}  ][⚑ {languages}  ][➤ {filename}]'),
    ('drivelight', 'Drive Light', '[\\[{service}{cached_bolt}\\] ]{addon} {res}|[▶ {quality}  ][▣ {codec}  ][❖ {group}]|'
                                  '[✦ {visual}  ][♬ {audio}  ][♯ {channels}  ][◈ {size}  ][⚑ {languages}]'),
    ('driveminimal', 'Drive Minimal', '{res_minimal}[ {cached_ticket}][  {quality_upper}]|[✦ {visual}  ][♬ {audio}  ][◈ {size}]|[⚑ {languages}]'),
    ('prism', 'Prism', '{res_prism}|[▶ {quality}  ][✦ {visual}  ][▣ {codec}  ][♬ {audio}  ][♯ {channels}  ][◈ {size}  ][⇄ {seeders}]|'
                       '[❖ {group}  ][⚙ {indexer}  ][{ready_word} ][({service}) ]● {addon}'),
    ('orbit', 'Orbit', '{res}[ {cached_bolt}][  〈{quality}〉]|[▣ {codec}  ][✦ {visual}  ][♬ {audio}][  ♯ {channels}]|'
                       '[◈ {size}  ][⇄ {seeders}  ][\\[{service}\\] ]{addon}[ · {group}][ · {indexer}]'),
)
NAMES = dict((key, name) for key, name, _ in FORMATS)
NAMES.update({'addon': "The add-on's own text", 'custom': 'Your own'})
TEMPLATES = dict((key, template) for key, _, template in FORMATS)

_QUALITY = (('REMUX', r'\b(?:bd|uhd)?[ ._-]?remux\b'), ('BluRay', r'\bblu[ ._-]?ray\b|\bbdrip\b|\bbrrip\b'),
            ('WEB-DL', r'\bweb[ ._-]?dl\b|\bwebdl\b'), ('WEBRip', r'\bweb[ ._-]?rip\b'), ('WEB', r'\bweb\b'),
            ('HDTV', r'\bhdtv\b'), ('DVD', r'\bdvd(?:rip)?\b'), ('CAM', r'\b(?:hd)?cam\b|\btelesync\b|\bhdts\b'))
_CODEC = (('AV1', r'\bav1\b'), ('HEVC', r'\bhevc\b|\b[xh][ ._]?265\b'), ('AVC', r'\bavc\b|\b[xh][ ._]?264\b'),
          ('MPEG-2', r'\bmpeg[ ._-]?2\b'), ('VC-1', r'\bvc[ ._-]?1\b'))
_AUDIO = (('TrueHD Atmos', r'\btruehd\b.*\batmos\b|\batmos\b.*\btruehd\b'), ('DTS:X', r'\bdts[ ._:-]?x\b'),
          ('DTS-HD MA', r'\bdts[ ._-]?hd[ ._-]?ma\b|\bdts[ ._-]?ma\b'), ('Atmos', r'\batmos\b'), ('TrueHD', r'\btruehd\b'),
          ('DTS-HD', r'\bdts[ ._-]?hd\b'), ('DD+', r'\bddp|\bdd\+|\be[ ._-]?ac[ ._-]?3\b'), ('DTS', r'\bdts\b'),
          ('DD', r'\bdd(?:5[ .]?1)?\b|\bac[ ._-]?3\b'), ('FLAC', r'\bflac\b'), ('AAC', r'\baac\b'), ('Opus', r'\bopus\b'))
_CHANNELS = (('7.1', r'\b7[ .]1\b'), ('5.1', r'\b5[ .]1\b'), ('2.0', r'\b2[ .]0\b'))
_LANGS = (('EN', r'\beng(?:lish)?\b'), ('HR', r'\b(?:hrv|croatian|hrvatski)\b'), ('DE', r'\b(?:ger(?:man)?|deu(?:tsch)?)\b'),
          ('FR', r'\b(?:fre(?:nch)?|fra(?:ncais)?|vff|truefrench)\b'), ('ES', r'\b(?:spa(?:nish)?|esp|castellano|latino)\b'),
          ('IT', r'\b(?:ita(?:lian)?)\b'), ('RU', r'\b(?:rus(?:sian)?)\b'), ('PT', r'\b(?:por(?:tuguese)?|pt[ ._-]?br)\b'),
          ('MULTI', r'\bmulti\b'), ('DUAL', r'\bdual(?:[ ._-]?audio)?\b'))
_SERVICES = (('RD', r'\breal[ ._-]?debrid\b|\[rd[+ \]]|\brd\b'), ('TB', r'\btorbox\b|\[tb[+ \]]|\btb\b'),
             ('AD', r'\balldebrid\b|\[ad[+ \]]'), ('PM', r'\bpremiumize\b|\[pm[+ \]]'), ('DL', r'\bdebrid[ ._-]?link\b|\[dl[+ \]]'),
             ('OC', r'\boffcloud\b|\[oc[+ \]]'), ('EN', r'\beasynews\b|\[en[+ \]]'), ('ED', r'\beasydebrid\b|\[ed[+ \]]'),
             ('PP', r'\bpikpak\b|\[pp[+ \]]'), ('NZB', r'\bnzb\b|\busenet\b'))
_SEEDERS = re.compile(r'(?:👤|👥|⇄|seeders?:?|\bS:)\s*(\d+)', re.I)
_INDEXER = re.compile(r'(?:⚙️?|🔍|\bindexer:?|\bsource:)\s*([A-Za-z0-9][\w .\-]{1,24}?)(?:\s{2,}|\s*[|\n]|$)', re.I)
_FIELD = re.compile(r'\{(\w+)\}')


def _first(text, table):
    return next((label for label, pattern in table if re.search(pattern, text, re.I)), '')


def facts(row, meta=None):
    """The source's facts as short texts ('' when unknown)."""
    from . import stream_choice
    text = stream_choice._text(row)
    traits = stream_choice.traits(row)
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    names = stream_choice.release_names(row)
    filename = str(hints.get('filename') or (names[0] if names else '') or '').strip()
    groups = stream_choice.groups_of([filename]) if filename else []
    size = traits['size']
    visual = 'DV HDR' if traits['dv'] and re.search(r'\bhdr', text, re.I) else ('DV' if traits['dv'] else
              ('HDR10+' if re.search(r'hdr10\+', text, re.I) else ('HDR' if traits['hdr'] else '')))
    cached = traits['cached']
    service = _first(text, _SERVICES)
    seeders = _SEEDERS.search(text)
    origin = row.get('_meganexus_source') or {}
    meta = meta or {}
    languages = [label for label, pattern in _LANGS if re.search(pattern, filename or text, re.I)]
    indexer = _INDEXER.search(text)
    res = {4: '4K', 3: '1080p', 2: '720p', 1: 'SD'}.get(traits['res'], '')
    quality = _first(text, _QUALITY)
    return {
        'res': res,
        # the styles' own spellings
        'res_prism': {'4K': '★ 4K UHD', '1080p': '✦ FHD', '720p': '◇ HD', 'SD': '○ Low quality'}.get(res, '○ Unknown'),
        'res_minimal': {'4K': '✦ 4K', '1080p': '◉ 1080p', '720p': '○ 720p', 'SD': '○ SD'}.get(res, 'N/A'),
        'quality_upper': quality.upper(), 'quality_or': quality or 'Unknown', 'filename_or': filename or 'Unknown',
        'cached_plus': ('+' if cached else ' download') if service else '',
        'cached_bolt': ('⚡' if cached else '↓') if cached is not None else '',
        'cached_ticket': '⚡' if cached else ('↓' if cached is False else ''),
        'ready_word': 'Ready' if cached else ('Not ready' if cached is False else ''),
        'indexer': indexer.group(1).strip() if indexer else '',
        'quality': quality, 'codec': _first(text, _CODEC), 'visual': visual,
        'audio': _first(text, _AUDIO), 'channels': _first(text, _CHANNELS),
        'size': ('%.2f GB' % (size / 1e9)) if size >= 1e9 else ('%d MB' % (size / 1e6) if size else ''),
        'addon': str(origin.get('name') or '').strip(),
        'service': service, 'cached': ('+' if cached else ' download' if cached is False else '') if service else '',
        'seeders': seeders.group(1) if seeders else '', 'group': groups[0] if groups else '',
        'languages': ' '.join(languages[:4]), 'filename': filename,
        'title': str(meta.get('title') or meta.get('name') or ''), 'year': str(meta.get('year') or ''),
        'episode': str(meta.get('episode_label') or ''),
    }


def render(template, values):
    """Fill {field}s; [groups] vanish when a field inside is empty; \\[ and \\] are
    brackets of the text itself ([TB+])."""
    template = str(template).replace('\\[', '\x01').replace('\\]', '\x02')

    def fill(part):
        return _FIELD.sub(lambda m: str(values.get(m.group(1), '')), part)

    def groups(text):
        out, i = [], 0
        while i < len(text):
            if text[i] == '[':
                depth, j = 1, i + 1
                while j < len(text) and depth:
                    depth += {'[': 1, ']': -1}.get(text[j], 0)
                    j += 1
                inner = text[i + 1:j - 1]
                needed = _FIELD.findall(inner)
                if needed and all(str(values.get(name, '')).strip() for name in needed):
                    out.append(groups(inner))
                i = j
            else:
                out.append(text[i])
                i += 1
        return fill(''.join(out))
    text = re.sub(r' {3,}', '   ', groups(template)).strip(' ·')
    return text.replace('\x01', '[').replace('\x02', ']')


def chosen(addon=None):
    """(formatter id, template or None for the add-on's own text)."""
    try:
        if addon is None:
            from .settings_cache import cached_addon
            addon = cached_addon()
        key = (addon.getSetting(SETTING) or 'cinema').strip()
        if key == 'custom':
            template = (addon.getSetting(CUSTOM) or '').strip()
            return (key, template) if template else ('cinema', TEMPLATES['cinema'])
    except Exception:
        key = 'cinema'
    if key == 'addon':
        return key, None
    return (key, TEMPLATES.get(key) or TEMPLATES['cinema'])


def lines(row, template, meta=None):
    """(first line, the lines under it joined by [CR] - Kodi shows two) of a source."""
    parts = [part.strip(' ·') for part in render(template, facts(row, meta)).split('|')]
    rest = [part for part in parts[1:] if part][:2]
    return parts[0], '[CR]'.join(rest)


def check(template):
    """'' when a template of "Your own" can be used, else why not."""
    template = str(template or '').strip()
    if not template:
        return 'empty'
    plain = template.replace('\\[', '').replace('\\]', '')
    if plain.count('[') != plain.count(']'):
        return 'a [ without its ] (or the other way round)'
    unknown = sorted(set(_FIELD.findall(template)) - set(FIELDS))
    return ('unknown field: %s' % ', '.join(unknown)) if unknown else ''


FIELDS = ('res', 'quality', 'codec', 'visual', 'audio', 'channels', 'size', 'addon', 'service', 'cached',
          'seeders', 'group', 'languages', 'filename', 'title', 'year', 'episode', 'indexer',
          'res_prism', 'res_minimal', 'quality_upper', 'quality_or', 'filename_or', 'cached_plus', 'cached_bolt',
          'cached_ticket', 'ready_word')
