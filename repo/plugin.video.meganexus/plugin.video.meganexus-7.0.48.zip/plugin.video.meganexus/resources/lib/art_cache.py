# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Bounded image-byte cache. Kodi retains ownership of decoded GUI textures.

7.0.21: /anim serves a collection's focused-card animation as a small GIF.
Kodi plays only GIF (not animated WebP, which Nuvio collections use) and
keeps every frame as a texture: the original 1000 px, 130-frame animations
would take ~300 MB. Each animation is converted once to ANIM_WIDTH px by the
public image service images.weserv.org (wsrv.nl; it receives only the
picture's public link) and kept in special://temp/meganexus-anim: Kodi reads
pictures there directly; from any other place it stores a still copy in its
texture cache and swaps it in, which stopped the animation after a moment.

Only presentation URLs pass through this cache; provider/playback metadata never
stores loopback URLs. Twelve HTTP workers on a keep-alive pool cap concurrent upstream downloads
(7.0.10: was six; Kodi asks for 30 posters at once while it prepares collections).
"""
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs, quote, unquote
from urllib.request import Request, urlopen
import hashlib
import os
import threading
import time
_ORIGIN = 'mnx-a59681f63859'

# ram256 (6.0.27 default): ~800 posters take ~90 MiB, so a full Home of ~130
# catalogs fits. ram200/ram150 are kept only so older settings still resolve.
LIMITS = {'ram128':128*1024*1024, 'ram256':256*1024*1024, 'ram512':512*1024*1024, 'disk246':246*1024*1024, 'disk512':512*1024*1024}
MAX_IMAGE = 8*1024*1024
ANIM_WIDTH = 320
ANIM_MAX = 4*1024*1024
ANIM_DISK = 48*1024*1024
ANIM_SERVICE = 'https://wsrv.nl/?url=%s&w=%d&n=-1&output=gif'
ANIM_FOLDER = 'special://temp/meganexus-anim/'
_BASE = ('',0)
_SERVICE = None


def image_type(data):
    if data.startswith(b'\xff\xd8\xff'):return 'image/jpeg'
    if data.startswith(b'\x89PNG\r\n\x1a\n'):return 'image/png'
    if data[:6] in (b'GIF87a',b'GIF89a'):return 'image/gif'
    if data[:4]==b'RIFF' and data[8:12]==b'WEBP':return 'image/webp'
    return ''


def _pool():
    """Shared keep-alive pool: posters come from a few CDNs, so reusing TLS
    connections removes a handshake from nearly every image. None = urllib."""
    try:
        from .meganexus.client import _ensure_pool
        return _ensure_pool()
    except Exception:
        return None


def fetch(url):
    if urlsplit(url).scheme not in ('http','https'):raise ValueError('Not a remote image')
    headers={'User-Agent':'MegaNexus/7.0'}
    pool=_pool()
    if pool is not None:
        response=pool.request('GET',url,headers=headers,timeout=5.0,retries=False,redirect=True,preload_content=False)
        try:
            if response.status>=400:raise ValueError('Image HTTP %d'%response.status)
            size=int(response.headers.get('Content-Length') or 0)
            if size>MAX_IMAGE:raise ValueError('Image too large')
            data=response.read(MAX_IMAGE+1)
        finally:
            response.release_conn()
    else:
        with urlopen(Request(url,headers=headers),timeout=5) as response:
            size=int(response.headers.get('Content-Length') or 0)
            if size>MAX_IMAGE:raise ValueError('Image too large')
            data=response.read(MAX_IMAGE+1)
    if len(data)>MAX_IMAGE or not image_type(data):raise ValueError('Unsupported image')
    return data


class Cache:
    def __init__(self,folder,mode='disk246',limits=None,fetcher=fetch):
        self.folder=Path(folder);self.limits=limits or LIMITS;self.fetcher=fetcher
        self.lock=threading.RLock();self.memory=OrderedDict();self.disk=OrderedDict()
        self.bytes=0;self.mode='off';self.generation=0;self.pending={};self.misses=OrderedDict()
        self.anim_folder=self.folder/'anim'
        self.folder.mkdir(parents=True,exist_ok=True)
        files=[]
        for path in self.folder.glob('*.img'):
            try:files.append((path.stat().st_mtime,path.name,path.stat().st_size))
            except OSError:pass
        for _,name,size in sorted(files):self.disk[name]=size
        for path in self.folder.glob('*.part'):
            try:path.unlink()
            except OSError:pass
        self.configure(mode)

    def configure(self,mode):
        with self.lock:
            mode=mode if mode in self.limits else 'off'
            if mode==self.mode:return
            self.generation+=1;self.memory.clear();self.mode=mode;self.misses.clear()
            self.bytes=sum(self.disk.values()) if mode.startswith('disk') else 0
            self._evict()

    def _evict(self):
        budget=self.limits.get(self.mode,0)
        if self.mode.startswith('disk'):
            while self.disk and self.bytes>budget:
                name,size=self.disk.popitem(last=False)
                try:(self.folder/name).unlink()
                except FileNotFoundError:pass
                self.bytes-=size
        elif self.mode.startswith('ram'):
            while self.memory and self.bytes>budget:
                _,data=self.memory.popitem(last=False);self.bytes-=len(data)

    def _read(self,key):
        if self.mode.startswith('ram'):
            data=self.memory.get(key)
            if data is not None:self.memory.move_to_end(key)
            return data
        if self.mode.startswith('disk') and key in self.disk:
            try:data=(self.folder/key).read_bytes()
            except OSError:
                self.bytes-=self.disk.pop(key);return None
            if not image_type(data):
                self.bytes-=self.disk.pop(key)
                try:(self.folder/key).unlink()
                except OSError:pass
                return None
            self.disk.move_to_end(key)
            # Persist recency without rewriting the image on every read.
            try:
                if time.time()-(self.folder/key).stat().st_mtime>60:os.utime(self.folder/key,None)
            except OSError:pass
            return data
        return None

    def get(self,url):
        key=hashlib.sha256(url.encode()).hexdigest()+'.img'
        with self.lock:
            data=self._read(key)
            if data is not None:return data
            if self.misses.get(key,0)>time.monotonic():raise ValueError('Image temporarily unavailable')
            event=self.pending.get(key)
            if event is None:
                event=threading.Event();self.pending[key]=event;owner=True
            else:owner=False
            generation=self.generation
        if not owner:
            if not event.wait(7):raise ValueError('Image busy')
            with self.lock:data=self._read(key)
            if data is None:raise ValueError('Image unavailable')
            return data
        try:
            data=self.fetcher(url)
            if len(data)>MAX_IMAGE or not image_type(data):raise ValueError('Unsupported image')
            with self.lock:
                if generation==self.generation and len(data)<=self.limits.get(self.mode,0):
                    if self.mode.startswith('ram'):self.memory[key]=data
                    elif self.mode.startswith('disk'):
                        temporary=self.folder/(key+'.part');temporary.write_bytes(data);os.replace(temporary,self.folder/key)
                        self.disk[key]=len(data)
                    self.bytes+=len(data);self._evict()
            return data
        except Exception:
            with self.lock:
                self.misses[key]=time.monotonic()+30
                while len(self.misses)>128:self.misses.popitem(last=False)
            raise
        finally:
            with self.lock:self.pending.pop(key,None);event.set()

    def animation(self,url):
        """The focused-card animation of url as a small GIF, converted once and
        kept on disk (7.0.21)."""
        folder=self.anim_folder
        path=folder/animation_name(url)
        try:return path.read_bytes()
        except OSError:pass
        key='anim:'+path.name
        with self.lock:
            if self.misses.get(key,0)>time.monotonic():raise ValueError('Animation temporarily unavailable')
            event=self.pending.get(key)
            if event is None:
                event=threading.Event();self.pending[key]=event;owner=True
            else:owner=False
        if not owner:
            if not event.wait(15):raise ValueError('Animation busy')
            return path.read_bytes()
        try:
            data=self.fetcher(ANIM_SERVICE%(quote(url,safe=''),ANIM_WIDTH))
            if not data.startswith((b'GIF87a',b'GIF89a')) or len(data)>ANIM_MAX:raise ValueError('Not a small GIF')
            folder.mkdir(parents=True,exist_ok=True)
            temporary=folder/(path.name+'.part');temporary.write_bytes(data);os.replace(temporary,path)
            self._trim_animations(folder)
            return data
        except Exception:
            with self.lock:self.misses[key]=time.monotonic()+600
            raise
        finally:
            with self.lock:self.pending.pop(key,None);event.set()

    @staticmethod
    def _trim_animations(folder):
        files=[]
        for path in folder.glob('*.gif'):
            try:files.append((path.stat().st_mtime,path.stat().st_size,path))
            except OSError:pass
        total=sum(size for _,size,_ in files)
        for _,size,path in sorted(files):
            if total<=ANIM_DISK:break
            try:path.unlink();total-=size
            except OSError:pass

    def clear(self):
        with self.lock:
            self.generation+=1;self.memory.clear();self.misses.clear()
            for key in list(self.disk):
                try:(self.folder/key).unlink()
                except FileNotFoundError:pass
            self.disk.clear();self.bytes=0

    def stats(self):
        with self.lock:return self.mode,self.bytes,len(self.memory if self.mode.startswith('ram') else self.disk)


class DaemonPool:
    """7.0.29: image requests on daemon threads. A ThreadPoolExecutor's workers
    are joined when Python exits: one stuck on a slow image download kept
    Kodi from closing (it hung after "Unloaded skin")."""
    def __init__(self,workers,name):
        import queue
        self.jobs=queue.Queue();self.closed=False
        for index in range(workers):
            threading.Thread(target=self._work,name='%s_%d'%(name,index),daemon=True).start()
    def _work(self):
        while True:
            job=self.jobs.get()
            if job is None:return
            try:job[0](*job[1])
            except Exception:pass
    def submit(self,fn,*args):
        if not self.closed:self.jobs.put((fn,args))
    def shutdown(self,wait=False):
        self.closed=True
        try:
            while True:self.jobs.get_nowait()
        except Exception:pass
        for _ in range(64):self.jobs.put(None)


class Server(HTTPServer):
    allow_reuse_address=True
    request_queue_size=16
    def __init__(self,address,cache):
        # Kodi loads a screen of posters, fanart and logos at once. Queue them
        # instead of dropping the ninth connection, which left blank cards.
        self.cache=cache;self.pool=DaemonPool(12,'MegaNexusArt')
        self.slots=threading.BoundedSemaphore(48)
        super().__init__(address,Handler)
    def process_request(self,request,address):
        if not self.slots.acquire(False):
            self.shutdown_request(request);return
        self.pool.submit(self._serve,request,address)
    def _serve(self,request,address):
        try:
            request.settimeout(8);self.finish_request(request,address)
        except Exception:pass
        finally:self.shutdown_request(request);self.slots.release()
    def server_close(self):
        super().server_close();self.pool.shutdown(wait=False)


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass  # Image URLs may contain provider credentials.
    def do_GET(self):self._get(False)
    def do_HEAD(self):self._get(True)
    def _get(self,head):
        try:
            parsed=urlsplit(self.path)
            if parsed.path not in ('/image','/anim'):self.send_error(404);return
            target=parse_qs(parsed.query).get('url',[''])[0]
            if len(target)>8192 or urlsplit(target).scheme not in ('http','https'):self.send_error(400);return
            data=self.server.cache.animation(target) if parsed.path=='/anim' else self.server.cache.get(target)
            self.send_response(200);self.send_header('Content-Type',image_type(data))
            self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','public, max-age=86400');self.end_headers()
            if not head:self.wfile.write(data)
        except Exception:
            # Uncached/offline failures stay short; Kodi can retry later.
            try:self.send_error(502)
            except Exception:pass


def selected_mode(addon):
    """The preset in use (7.0.3: RAM 128 / 256 default / 512 MiB). Earlier
    names are stored once as their nearest preset; disk/off choices stay."""
    from . import ram_profile
    stored = addon.getSetting('meganexus_art_cache') or ''
    mode = ram_profile.chosen(addon)
    if mode != stored:
        addon.setSetting('meganexus_art_cache', mode)
    return mode


PORT_TRIES = 30      # 7.0.48: the last port asked again this many times ...
PORT_WAIT = .5       # ... this many seconds apart before another one is taken


class Service:
    def __init__(self):
        self.events=threading.Event();self.stopped=threading.Event();self.clear_requested=False
        self.server=None;self.worker=threading.Thread(target=self.run,name='MegaNexusArtCache',daemon=True)
        self.worker.start()
    def notify(self,method):
        if method.endswith('artcache.clear'):self.clear_requested=True
        self.events.set()
    def run(self):
        import xbmc,xbmcaddon,xbmcgui
        from .meganexus.common import profile_path
        home=xbmcgui.Window(10000);root=Path(profile_path())/'art-cache'
        try:
            cache=Cache(root,selected_mode(xbmcaddon.Addon('plugin.video.meganexus')))
            import xbmcvfs
            cache.anim_folder=Path(xbmcvfs.translatePath(ANIM_FOLDER))
            portfile=root/'port'
            try:port=int(portfile.read_text())
            except (ValueError,OSError):port=0
            monitor=xbmc.Monitor()
            # 7.0.48: the port is in every poster link Kodi keeps; a Kodi still closing held
            # it for a moment and a new port made every kept poster unknown (a whole
            # One-time setup again) - the last port is asked for a while first
            for attempt in range(PORT_TRIES if port else 0):
                try:self.server=Server(('127.0.0.1',port),cache);break
                except OSError:
                    if monitor.waitForAbort(PORT_WAIT):break
            if self.server is None:
                self.server=Server(('127.0.0.1',0),cache)
                if port:xbmc.log('[MegaNexus] Image cache: port %d stayed busy, now %d - Kodi stores the posters again'
                                 %(port,self.server.server_port),xbmc.LOGWARNING)
            portfile.write_text(str(self.server.server_port))
            thread=threading.Thread(target=self.server.serve_forever,name='MegaNexusArtHTTP',daemon=True);thread.start()
            while not self.stopped.is_set() and not monitor.abortRequested():
                mode=selected_mode(xbmcaddon.Addon('plugin.video.meganexus'))
                cache.configure(mode)
                if self.clear_requested:self.clear_requested=False;cache.clear()
                home.setProperty('meganexus.art_cache.base',('http://127.0.0.1:%d'%self.server.server_port) if mode in LIMITS else '')
                _,size,count=cache.stats()
                home.setProperty('meganexus.art_cache.usage','%.1f MB · %d images'%(size/1024/1024,count))
                self.events.wait(1);self.events.clear()
        except Exception:
            xbmc.log('[MegaNexus] Image cache unavailable; using provider images directly',xbmc.LOGWARNING)
        finally:
            home.clearProperty('meganexus.art_cache.base')
            if self.server:self.server.shutdown();self.server.server_close()
    def stop(self):
        self.stopped.set();self.events.set()
        self.worker.join(2.)   # the server closes before Kodi tears Python down


def start():
    global _SERVICE
    if _SERVICE is None:_SERVICE=Service()


def notify(method):
    if _SERVICE:_SERVICE.notify(method)


def stop():
    if _SERVICE:_SERVICE.stop()


def raster(value):
    """7.0.45: TMDB keeps many logos as SVG, which Kodi cannot draw (the proxy
    answered 502 and the title's name showed instead); TMDB gives the same
    picture as PNG under the same name."""
    if value.startswith('https://image.tmdb.org/t/p/') and value.lower().endswith('.svg'):
        return value[:-4]+'.png'
    return value


def url(value):
    global _BASE
    value=raster(str(value or ''))
    if not value.startswith(('http://','https://')) or '|' in value:return value
    now=time.monotonic()
    if now>=_BASE[1]:
        import xbmcgui
        _BASE=(xbmcgui.Window(10000).getProperty('meganexus.art_cache.base'),now+1)
    base=_BASE[0]
    if not base or value.startswith(base+'/'):return value
    return base+'/image?url='+quote(value,safe='')


def art(values):return {key:url(value) for key,value in values.items()}


# 7.0.30: a card's picture (poster, landscape tile, episode still) is kept by Kodi
# at card size through its own image:// transform. It stored every poster at
# 486x720 (imageres) and shrank it on each frame for a 192x288 card - about six
# times the pixels to decode, upload and hold (GPU memory is system RAM on
# Android / CoreELEC boxes). The box keeps a margin over the focused (zoomed)
# card: a poster becomes 280x420, a 16:9 tile 384x216. Only when Kodi draws its
# interface at up to 1200 px high (1080p, also on a 4K TV); larger interfaces
# keep full pictures. Kodi 22 no longer reads the size from the link (it stores
# its full imageres copy), so there the links stay as they were. Big pictures
# (backgrounds, logos, details) never change.
CARD_BOX = (384, 420)
CARD_GUI_HEIGHT = 1200
CARD_KODI = 21            # the last Kodi that stores a picture at the size in its link
_GUI = [False, 0.]


def gui_height(screenmode, current=0, video=False):
    """The height Kodi draws its interface at: Settings > Display's resolution
    (videoscreen.screenmode "SWWWWWHHHHHRRR.RRRRRmode", e.g. 0019200108060.00000pstd),
    not the output of the moment - with "Adjust display refresh rate" the
    output is 2160 px only while a 4K video plays. 7.0.37: 7.0.30-7.0.36 read
    System.ScreenHeight and, after a 4K film, kept full-size posters for a
    minute (new links, Home repaints of 6-9 s on a Fire TV Cube)."""
    mode=str(screenmode or '')
    if len(mode)>=11 and mode[:11].isdigit():
        return int(mode[6:11])
    return 0 if video else int(current or 0)     # DESKTOP: the output, but never during a video


def card_size():
    now=time.monotonic()
    if now>=_GUI[1]:
        try:
            import json as _json
            import xbmc
            try:
                reply=_json.loads(xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Settings.GetSettingValue","params":{"setting":"videoscreen.screenmode"}}') or '{}')
                mode=(reply.get('result') or {}).get('value')
            except Exception:
                mode=''
            video=xbmc.getCondVisibility('Player.HasVideo')
            height=gui_height(mode,xbmc.getInfoLabel('System.ScreenHeight') or 0,video)
            kodi=int((xbmc.getInfoLabel('System.BuildVersion') or '0').split('.')[0])
        except (ImportError, ValueError, RuntimeError):
            height=kodi=0
        if not height and _GUI[1]:
            _GUI[1]=now+5;return _GUI[0]      # unknown during a video: keep the last answer
        small=0<height<=CARD_GUI_HEIGHT and 0<kodi<=CARD_KODI
        if small!=_GUI[0] or not _GUI[1]:
            try:xbmc.log('[MegaNexus][perf] Card pictures at card size: %s (interface %d px high, Kodi %d)'%('yes' if small else 'no',height,kodi),xbmc.LOGINFO)
            except Exception:pass
        _GUI[0]=small;_GUI[1]=now+600       # a settings change: within 10 minutes
    return _GUI[0]


def card(value):
    """The picture of a card, at card size (see CARD_BOX)."""
    value=url(value)
    if not value.startswith(('http://','https://')) or '|' in value or not card_size():return value
    return 'image://%s/transform?width=%d&height=%d'%(quote(value,safe=''),CARD_BOX[0],CARD_BOX[1])


def uncard(value):
    """The picture link inside a card() link."""
    value=str(value or '')
    if value.startswith('image://') and '/transform?' in value:
        return unquote(value[8:value.rindex('/transform?')])
    return value


def animation_name(value):
    return hashlib.sha256(str(value).encode()).hexdigest()+'.gif'


def animation(value):
    """The focused-card animation for Kodi (7.0.21): the converted GIF in
    ANIM_FOLDER (prepared through animation_source() first); a local GIF is
    used as it is. Empty when there is nothing Kodi can play."""
    value=str(value or '')
    if not value.startswith(('http://','https://')):
        return value if value.lower().endswith('.gif') else ''
    if '|' in value:return ''
    return ANIM_FOLDER+animation_name(value)


def gif_seconds(data):
    """Playing time of one pass of a GIF: the frame delays of its graphic
    control blocks (0 when unknown)."""
    total,at=0,data.find(b'\x21\xf9\x04')
    while at>=0 and at+6<=len(data):
        total+=int.from_bytes(data[at+4:at+6],'little') or 10   # 0 plays as 10 ms
        at=data.find(b'\x21\xf9\x04',at+6)
    return total/100.0


def animation_source(value):
    """The proxy link that converts and stores animation(value); '' when there
    is nothing to prepare (a local GIF, no image proxy)."""
    value=str(value or '')
    if not value.startswith(('http://','https://')) or '|' in value:return ''
    url(value)            # refreshes the cached proxy address
    base=_BASE[0]
    return base+'/anim?url='+quote(value,safe='') if base else ''
