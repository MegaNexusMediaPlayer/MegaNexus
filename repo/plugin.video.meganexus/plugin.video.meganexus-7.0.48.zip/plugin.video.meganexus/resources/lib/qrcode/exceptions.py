class DataOverflowError(Exception):
    pass
