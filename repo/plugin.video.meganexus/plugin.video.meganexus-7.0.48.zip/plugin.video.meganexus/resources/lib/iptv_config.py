# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A dedicated IPTV Simple instance; other playlists and credentials are preserved."""
from pathlib import Path
import os
import time
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit,urlencode
from .legacy_names import PREV_IPTV_NAME

def valid_url(value):
    p=urlsplit(value.strip())
    if p.scheme not in ('http','https') or not p.netloc or any(c in value for c in ('\r','\n')):
        raise ValueError('Enter a complete HTTP or HTTPS URL.')
    return value.strip()

def xtream_urls(server,username,password):
    server=valid_url(server).rstrip('/')
    if urlsplit(server).query or urlsplit(server).fragment:raise ValueError('Enter the server address and port, without a query.')
    if not username or not password:raise ValueError('Username and password are required.')
    query=urlencode({'username':username,'password':password})
    return server+'/get.php?'+query+'&type=m3u_plus&output=ts',server+'/xmltv.php?'+query

INSTANCE_NAME='MegaNexus IPTV'


def feature_values(timeshift=True,catchup=True):
    """7.0.29: IPTV Simple's pause / rewind of live TV (timeshift, through
    inputstream.ffmpegdirect) and catch-up of past programmes - the latter only
    works for channels whose playlist offers an archive (catchup attributes)."""
    on=lambda v:'true' if v else 'false'
    return {'timeshiftEnabled':on(timeshift),'timeshiftEnabledAll':'true','timeshiftEnabledHttp':'true',
            'timeshiftEnabledUdp':'true','catchupEnabled':on(catchup),'catchupDays':'7'}


def apply_features(profile,instance_id,timeshift=True,catchup=True):
    """Switch timeshift / catch-up in our existing instance, keeping everything else."""
    path=Path(profile)/('instance-settings-%d.xml'%int(instance_id))
    if not path.exists():return False
    tree=ET.parse(path);root=tree.getroot()
    for key,value in feature_values(timeshift,catchup).items():
        node=root.find("setting[@id='%s']"%key)
        if node is None:node=ET.SubElement(root,'setting',id=key)
        node.attrib.pop('default',None);node.text=value
    temp=path.with_suffix('.tmp');tree.write(temp,encoding='utf-8',xml_declaration=True)
    os.replace(temp,path)
    try:os.chmod(path,0o600)
    except OSError:pass
    return True


def write_instance(profile,m3u,epg,instance_id=None,timeshift=True,catchup=True,name=INSTANCE_NAME,fresh=False):
    """``fresh`` (7.0.37, another IPTV list): a new instance number, never one in use."""
    m3u=valid_url(m3u);epg=valid_url(epg) if epg else ''
    profile=Path(profile);profile.mkdir(parents=True,exist_ok=True)
    iid=int(instance_id or 90100)
    while (profile/f'instance-settings-{iid}.xml').exists():
        if fresh:
            iid+=1;continue
        old=ET.parse(profile/f'instance-settings-{iid}.xml').getroot()
        label=old.find("setting[@id='kodi_addon_instance_name']")
        if label is not None and label.text in (INSTANCE_NAME,PREV_IPTV_NAME):break   # reuse ours, also from before 7.0
        iid+=1
    path=profile/f'instance-settings-{iid}.xml'
    values={'kodi_addon_instance_name':name,'kodi_addon_instance_enabled':'true',
            'm3uPathType':'1','m3uUrl':m3u,'m3uCache':'true','epgPathType':'1','epgUrl':epg,
            'epgCache':'true','m3uRefreshMode':'2','m3uRefreshHour':'4','numberByOrder':'false'}
    values.update(feature_values(timeshift,catchup))
    root=ET.Element('settings',version='2')
    for key,value in values.items():ET.SubElement(root,'setting',id=key).text=value
    temp=path.with_suffix('.tmp');ET.ElementTree(root).write(temp,encoding='utf-8',xml_declaration=True)
    if path.exists():
        backup=profile/'meganexus-backups';backup.mkdir(exist_ok=True)
        (backup/(str(time.time_ns())+'.xml')).write_bytes(path.read_bytes())
    os.replace(temp,path)
    try:os.chmod(path,0o600)
    except OSError:pass
    return iid


def our_instance(profile,instance_id):
    """True when MegaNexus' own IPTV Simple instance is on disk."""
    try:return (Path(profile)/('instance-settings-%d.xml'%int(instance_id))).exists()
    except (TypeError,ValueError):return False


def ensure_client_enabled(rpc,tries=5,wait=None):
    """7.0.29: IPTV Simple is switched off while its instance file is rewritten and
    on again after; a Kodi exit (or a refused call) in between left Live TV off for
    good - no channels at start any more. Switch it on again, checking that it is."""
    import time as _time
    wait=wait or _time.sleep
    for attempt in range(tries):
        try:
            details=rpc('Addons.GetAddonDetails',{'addonid':'pvr.iptvsimple','properties':['enabled']}) or {}
            addon=(details.get('result') or details).get('addon') or {}
            if addon.get('enabled'):return True
            rpc('Addons.SetAddonEnabled',{'addonid':'pvr.iptvsimple','enabled':True})
        except Exception:pass
        if attempt<tries-1:wait(.5)
    return False
