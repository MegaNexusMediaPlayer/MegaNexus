# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The numbers of the diagnostics overlay (7.0.42), every STEP seconds.

The overlay (skin Custom_1111_MegaNexusStats.xml) showed Kodi's own labels; the
frame rate one changes every frame, so Kodi redrew the whole screen all the
time while the overlay was on - over half a CPU core on a Fire TV Cube with
nothing happening. The service now writes CPU, memory, frame rate and the
internet in use (down / up, from /proc/net/dev; not on every platform) into
Window(Home) properties, only while the overlay is switched on.
"""
import time

STEP = 2.0
PREFIX = 'meganexus.stats.'


def net_bytes(path='/proc/net/dev'):
    """(received, sent) bytes of every interface but loopback, or None."""
    try:
        with open(path) as handle:
            lines = handle.readlines()[2:]
    except OSError:
        return None
    down = up = 0
    for line in lines:
        name, _, data = line.partition(':')
        if name.strip() == 'lo' or not data:
            continue
        fields = data.split()
        if len(fields) >= 9:
            down += int(fields[0])
            up += int(fields[8])
    return down, up


def rate(bits_per_second):
    if bits_per_second >= 1e6:
        return '%.1f Mbit/s' % (bits_per_second / 1e6)
    return '%.0f kbit/s' % (bits_per_second / 1e3)


def net_line(before, after, seconds):
    if not before or not after or seconds <= 0:
        return 'not available here'
    down = max(0, after[0] - before[0]) * 8 / seconds
    up = max(0, after[1] - before[1]) * 8 / seconds
    return '↓ %s  ·  ↑ %s' % (rate(down), rate(up))


def max_line(measured, now=None):
    """7.0.42: the network's top speed, from the hourly measurement (net_speed)."""
    down, up = measured.get('mbps'), measured.get('up')
    if not down:
        return 'measured within 2 minutes of start'
    at = time.strftime('%H:%M', time.localtime(float(measured.get('at') or 0))) if measured.get('at') else ''
    return '↓ %.1f Mbit/s  ·  ↑ %s%s' % (float(down), '%.1f Mbit/s' % float(up) if up else '-', '  (%s)' % at if at else '')


def run(monitor, shown, label, window, folder=''):
    """Service loop; ``shown()`` - the overlay is on, ``label(name)`` - a Kodi info label."""
    last, at = None, 0.
    while not monitor.waitForAbort(STEP):
        try:
            if not shown():
                last = None
                continue
            now, sample = time.monotonic(), net_bytes()
            temp = label('System.CPUTemperature')
            window.setProperty(PREFIX + 'cpu', label('System.CPUUsage') + ('   ·   ' + temp if temp else ''))
            window.setProperty(PREFIX + 'memory', '%s  ·  %s of %s' % (label('System.Memory(used.percent)'),
                                                                    label('System.Memory(used)'), label('System.Memory(total)')))
            window.setProperty(PREFIX + 'fps', label('System.FPS') + ' fps')
            window.setProperty(PREFIX + 'net', net_line(last, sample, now - at) if last else 'measuring…')
            if folder:
                from . import net_speed
                window.setProperty(PREFIX + 'netmax', max_line(net_speed.last(folder)))
            last, at = sample, now
        except Exception:
            pass
