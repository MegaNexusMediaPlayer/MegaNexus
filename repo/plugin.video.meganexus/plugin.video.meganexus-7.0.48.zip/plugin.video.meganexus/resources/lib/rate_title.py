# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Rate a film, a series or an episode - and write a review - on Trakt and TMDB (7.0.45).

Typed on the phone (phone_setup's rate page), sent with your sign-ins: the rating to
Trakt and / or your TMDB account (tmdb_account), the review to Trakt only - TMDB
takes no reviews from apps.
"""
MIN_WORDS = 5     # Trakt takes a comment of at least five words


def services():
    """Where a rating can go here: [('trakt', signed in), ('tmdb', signed in)]."""
    from . import trakt, tmdb_account
    return [('trakt', bool(trakt.authorized())), ('tmdb', tmdb_account.connected())]


def send_to(item, rating=0, text='', spoiler=False, to_trakt=True, to_tmdb=False):
    """The phone's Send: the rating to the chosen services, the review to Trakt."""
    if not to_trakt and not to_tmdb:
        raise ValueError('Choose Trakt or TMDB.')
    if text and str(text).strip() and not to_trakt:
        raise ValueError('TMDB takes no reviews from apps - choose Trakt for the review, or leave it empty.')
    done = []
    if to_trakt:
        done.append(send(item, rating, text, spoiler)['done'])
    if to_tmdb:
        from . import tmdb_account
        if not rating:
            raise ValueError('Choose a rating for TMDB.' + (' Sent to Trakt.' if done else ''))
        try:
            tmdb_account.rate(item, rating)
        except ValueError as exc:
            raise ValueError(str(exc) + (' ' + done[0] + '.' if done else ''))
        done.append('Rated %d/10 on TMDB' % int(rating))
    return {'done': ' · '.join(done)}


def kind_label(kind):
    return {'movie': 'movie', 'series': 'show', 'episode': 'episode'}.get(kind, 'title')


def target(meta, episode=None):
    """What is rated: {'kind', 'title', 'imdb', 'tmdb', 'season', 'episode'}."""
    from .reviews import title_ids
    imdb, tmdb = title_ids(meta)
    series = (meta.get('type') or '') == 'series'
    found = {'kind': 'episode' if episode else 'series' if series else 'movie',
             'title': str(meta.get('name') or meta.get('title') or ''), 'imdb': imdb, 'tmdb': tmdb}
    if episode:
        found.update(season=int(episode.get('season') or 1), episode=int(episode.get('episode') or 0),
                     title='%s · S%s E%s' % (found['title'], episode.get('season') or 1, episode.get('episode')))
    return found


def _ids(item):
    ids = {}
    if str(item.get('imdb') or '').startswith('tt'):
        ids['imdb'] = item['imdb']
    if str(item.get('tmdb') or '').isdigit():
        ids['tmdb'] = int(item['tmdb'])
    if not ids:
        raise ValueError('This title has no IMDb or TMDB id Trakt knows.')
    return ids


def _trakt_id(trakt, item, one):
    """Trakt's own id of a film / show, found by its IMDb or TMDB id."""
    for source, value in (('imdb', item.get('imdb')), ('tmdb', item.get('tmdb'))):
        if not value or (source == 'imdb' and not str(value).startswith('tt')):
            continue
        try:
            found = trakt._request('/search/%s/%s?type=%s' % (source, value, one), timeout=15) or []
        except Exception as exc:
            raise ValueError(_trakt_error(exc, 'review'))
        ident = next((((row.get(one) or {}).get('ids') or {}).get('trakt') for row in found if isinstance(row, dict)), None)
        if ident:
            return ident
    raise ValueError('Trakt does not know this %s.' % kind_label('series' if one == 'show' else 'movie'))


def _show_ident(trakt, item):
    if str(item.get('imdb') or '').startswith('tt'):
        return item['imdb']
    found = trakt._request('/search/tmdb/%s?type=show' % item.get('tmdb'), timeout=15) or []
    ident = next((str((row.get('show') or {}).get('ids', {}).get('trakt') or '') for row in found if isinstance(row, dict)), '')
    if not ident:
        raise ValueError('Trakt does not know this show.')
    return ident


TRAKT_SAYS = {401: 'Trakt did not accept the sign-in - sign in to Trakt again on the TV.',
              403: 'Trakt did not accept the sign-in - sign in to Trakt again on the TV.',
              409: 'Trakt already has this.', 420: 'Your Trakt account reached its limit (a Trakt VIP limit).',
              423: 'Your Trakt account is locked.', 429: 'Trakt is busy - try again in a minute.'}
TRAKT_REASONS = {'comment_too_short': 'Trakt wants a review of at least 5 words.',
                 'comment_not_english': 'Trakt takes reviews in English only.'}


def _trakt_error(exc, what):
    """What Trakt answered, said plainly (never the sign-in)."""
    import json
    code = getattr(exc, 'code', None)
    reason = ''
    try:
        reason = str(json.loads((exc.read() or b'{}').decode('utf-8', 'replace')).get('error') or '')
    except Exception:
        pass
    try:
        import xbmc
        xbmc.log('[MegaNexus] Trakt %s: %s %s %s' % (what, type(exc).__name__, code or '', reason), xbmc.LOGWARNING)
    except Exception:
        pass
    if reason in TRAKT_REASONS:
        return TRAKT_REASONS[reason]
    if code in TRAKT_SAYS:
        return TRAKT_SAYS[code]
    if code == 422:
        return 'Trakt did not take the %s (%s).' % (what, reason.replace('_', ' ') or 'not valid')
    if code and code >= 500:
        return 'Trakt is not answering right now - try again later.'
    if code:
        return 'Trakt did not take the %s (error %s).' % (what, code)
    return 'Trakt could not be reached (%s) - check the connection.' % type(exc).__name__


def send(item, rating=0, text='', spoiler=False):
    """Rating (1-10, 0 = none) and/or a review to Trakt. Returns what was done."""
    from . import trakt
    if not trakt.authorized():
        raise ValueError('Sign in to Trakt on the TV first: HUB Settings > Accounts & tracking > Trakt.')
    try:
        rating = int(rating or 0)
    except (TypeError, ValueError):
        rating = 0
    if not 0 <= rating <= 10:
        raise ValueError('Choose a rating from 1 to 10.')
    text = ' '.join(str(text or '').split()) if '\n' not in str(text or '') else str(text).strip()
    if text and len(text.split()) < MIN_WORDS:
        raise ValueError('Write at least %d words - or leave the review empty to send only the rating.' % MIN_WORDS)
    if len(text) > 20000:
        raise ValueError('The review is too long.')
    if not rating and not text:
        raise ValueError('Choose a rating or write a review.')
    kind = item.get('kind')
    if kind == 'episode':
        show = _show_ident(trakt, item)
        found = trakt._request('/shows/%s/seasons/%d/episodes/%d' % (show, item['season'], item['episode']), timeout=15) or {}
        ids = {key: value for key, value in (found.get('ids') or {}).items() if key in ('trakt', 'tvdb', 'imdb', 'tmdb') and value}
        if not ids:
            raise ValueError('Trakt does not know this episode.')
        rated, said = {'episodes': [{'rating': rating, 'ids': ids}]}, {'episode': {'ids': {'trakt': ids.get('trakt')}}}
    else:
        ids = _ids(item)
        group, one = ('shows', 'show') if kind == 'series' else ('movies', 'movie')
        rated, said = {group: [{'rating': rating, 'ids': ids}]}, None
        if text:
            # a review is taken only with Trakt's own id (IMDb / TMDB ids: "invalid_request_body")
            said = {one: {'ids': {'trakt': _trakt_id(trakt, item, one)}}}
    done = []
    if rating:
        try:
            trakt._request('/sync/ratings', rated, 'POST', auth=True, timeout=30)
        except Exception as exc:
            raise ValueError(_trakt_error(exc, 'rating'))
        done.append('rated %d/10' % rating)
    if text:
        try:
            trakt._request('/comments', dict(said, comment=text, spoiler=bool(spoiler)), 'POST', auth=True, timeout=30)
        except Exception as exc:
            raise ValueError(_trakt_error(exc, 'review') + (' Your rating was sent.' if rating else ''))
        done.append('review posted')
    return {'done': ' and '.join(done).capitalize() + ' on Trakt'}
