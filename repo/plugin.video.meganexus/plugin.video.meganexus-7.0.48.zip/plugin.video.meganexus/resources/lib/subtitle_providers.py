# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Subtitle switches per add-on (7.0.17), like the stream and metadata ones.

An add-on that publishes a "subtitles" resource (OpenSubtitles, an all-in-one
add-on such as AIOStreams...) can be switched on or off as a subtitle source on
its own, whatever else it serves. Until the user changes one, every subtitle
add-on is on - as before 7.0.17 - and add-ons added later start on too.
"""
from . import addon_switches

SETTING = 'meganexus_subtitle_providers'


def candidates(providers=None):
    from .meganexus import store
    providers = store.list_providers() if providers is None else providers
    return [p for p in providers if p.get('id') and any(
        (r.get('name') if isinstance(r, dict) else r) == 'subtitles'
        for r in (p.get('manifest') or {}).get('resources') or [])]


def entries(providers=None):
    return addon_switches.entries(SETTING, candidates(providers))


def enabled_ids(providers=None):
    return {p['id'] for p, on in entries(providers) if on}


def set_enabled(provider_id, on):
    addon_switches.set_enabled(SETTING, entries(), provider_id, on, 'This add-on does not offer subtitles.')


# 7.0.42: OpenSubtitles v3 - Stremio's own subtitle add-on, every language, no account.
OPENSUBTITLES_ID = 'org.stremio.opensubtitlesv3'
OPENSUBTITLES_URL = 'https://opensubtitles-v3.strem.io/manifest.json'
WOKEN = 'meganexus_opensubtitles_woken'    # the one-time switch-on below happened


def _opensubtitles(providers=None):
    return next((p for p in candidates(providers) if (p.get('manifest') or {}).get('id') == OPENSUBTITLES_ID), None)


def opensubtitles_on():
    """OpenSubtitles v3 ON as a subtitle source: switched on when it is installed,
    installed (from Stremio's own address) when it is not."""
    from .meganexus import store
    found = _opensubtitles()
    if found is None:
        from .meganexus.client import validate_manifest
        try:
            manifest = validate_manifest(OPENSUBTITLES_URL)
        except Exception:
            raise ValueError('OpenSubtitles could not be reached. Check the connection and try again.')
        store.add_provider(manifest.get('name') or manifest['id'], OPENSUBTITLES_URL, manifest)
        found = _opensubtitles()
        if found is None:
            raise ValueError('OpenSubtitles could not be added.')
    if found['id'] not in enabled_ids():
        set_enabled(found['id'], True)
    return found.get('name') or 'OpenSubtitles v3'


def wake_installed(addon):
    """Once per device: an installed OpenSubtitles v3 that is OFF comes back ON
    (7.0.42). Later the user's own switch is kept."""
    if addon.getSetting(WOKEN) == 'true':
        return False
    addon.setSetting(WOKEN, 'true')
    found = _opensubtitles()
    if found is None or found['id'] in enabled_ids():
        return False
    set_enabled(found['id'], True)
    return True
