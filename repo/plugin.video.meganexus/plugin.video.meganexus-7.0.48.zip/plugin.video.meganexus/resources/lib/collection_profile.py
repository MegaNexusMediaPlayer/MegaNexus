# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Ordered Nuvio collection profiles and validated per-catalog metadata bindings."""
import json
import os
from pathlib import Path
import xbmcaddon

ADDON_ID='plugin.video.meganexus'

def profile_file():
    import xbmcvfs
    return Path(xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile')))/'meganexus_collections.json'

def _sports_name(identifier,name):
    return identifier.rsplit('.',1)[-1].lower()=='sports' or name.strip().lower()=='sports'

# 7.0.42: a collection's card shape as its source gives it - Nuvio's tileShape,
# a Fusion export's imageAspect. Never guessed from a name (Home did that, and a
# "Themes" collection of posters came out landscape).
SHAPES = {'poster': 'poster', 'portrait': 'poster', '2:3': 'poster', 'vertical': 'poster',
          'square': 'poster',             # MegaNexus draws posters and landscape cards only: the nearer one
          'landscape': 'landscape', 'wide': 'landscape', 'banner': 'landscape', '16:9': 'landscape', '16x9': 'landscape'}


def shape_of(folder):
    """'poster' / 'landscape' as the collection's source says, or '' when it says nothing."""
    for key in ('shape', 'tileShape', 'tile_shape', 'imageAspect', 'image_aspect'):
        value = str(folder.get(key) or '').strip().lower()
        if value in SHAPES:
            return SHAPES[value]
    return ''


def normalize(data):
    if isinstance(data,dict): data=data.get('collections') or data.get('groups') or data.get('data') or []
    if not isinstance(data,list): raise ValueError('Choose a Nuvio collections JSON export.')
    groups=[]
    for g in data:
        if not isinstance(g,dict):continue
        gid=str(g.get('id') or g.get('title') or g.get('name') or '')
        name=str(g.get('title') or g.get('name') or 'Collections')
        # Sports stay out of the MegaNexus Home (their own Sport screen, 6.0.35);
        # World collections are ordinary movie/series catalogs and are kept.
        if _sports_name(gid,name):continue
        folders=[]
        for f in g.get('folders') or g.get('entries') or []:
            if not isinstance(f,dict):continue
            fid=str(f.get('id') or '')
            fname=str(f.get('title') or f.get('name') or '')
            if _sports_name(fid,fname):continue
            payload=f.get('payload') or (f.get('dataSource') or {}).get('payload') or {}
            sources=f.get('catalogSources') or f.get('sources') or payload.get('sources') or ([payload] if payload.get('catalogId') else [])
            clean=[]
            for s in sources:
                if not isinstance(s,dict):continue
                if str(s.get('provider') or '').lower() in ('trakt','tmdb'):
                    # 6.0.37: Nuvio collections with Trakt lists and TMDB sources.
                    from .collection_sources import normalize as external_source
                    listed=external_source(s)
                    if listed:clean.append(listed)
                    continue
                extra=s.get('extra') or {}
                if not isinstance(extra,dict) or any(not isinstance(k,str) or isinstance(v,(dict,list)) for k,v in extra.items()):
                    raise ValueError('Collection filters must be an object of text values.')
                cid=s.get('catalogId') or s.get('catalog_id')
                if cid:clean.append({'addonId':s.get('addonId') or s.get('addon_id') or '',
                    'providerId':s.get('providerId') or s.get('provider_id') or '',
                    'catalogId':cid,'type':s.get('type') or s.get('catalogType') or 'movie',
                    'genre':s.get('genre') or '', 'extra':s.get('extra') or {},
                    'enabled':s.get('enabled') is not False})
            if not clean:continue
            entry={'id':str(f.get('id') or gid+'.'+str(len(folders))),
                'title':f.get('title') or f.get('name') or 'Collection','sources':clean,
                'cover':f.get('cover') or f.get('coverImageUrl') or f.get('background') or f.get('backgroundImageURL') or '',
                'backdrop':f.get('backdrop') or f.get('heroBackdropUrl') or '',
                # 7.0.42: Nuvio's "focus GIF" switch is kept: off means no animation
                'animation':'' if f.get('focusGifEnabled') is False else (f.get('animation') or f.get('focusGifUrl') or ''),
                'hideTitle':bool(f.get('hideTitle')), 'hidden':bool(f.get('hidden'))}
            # 7.0.44: a collection's own name logo (the field names collection packs use),
            # shown as the logo above the rows instead of its name
            logo=next((str(f.get(k)).strip() for k in ('logo','clearlogo','clearLogoUrl','clearLogoURL','titleLogoUrl','titleLogoURL',
                                                        'titleLogo','logoUrl','logoURL','heroLogoUrl') if str(f.get(k) or '').strip()),'')
            if logo:entry['logo']=logo
            if shape_of(f):entry['shape']=shape_of(f)
            folders.append(entry)
        if folders:groups.append({'id':gid,'title':name,'folders':folders,'hidden':bool(g.get('hidden')),
                                  'hideTitle':bool(g.get('hideTitle'))})
    return groups

def save(data, validation=None, auto=False):
    """Save the Home layout. Nothing is network-checked or blocked here (6.0.15):
    an unavailable catalog just stays empty on Home. ``validation`` - a report
    from Settings > Collections > Recheck - is stored for reference only.
    Any save that is not ``auto`` makes the layout the user's own, so automatic
    Cinemeta/catalog layouts never replace it."""
    groups = normalize(data)
    if not groups:
        raise ValueError('This export has no supported movie or series collections.')
    path = profile_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    from .meganexus.safe_io import write_json
    write_json(str(path), groups)
    if isinstance(validation, dict):
        write_json(str(path.with_suffix('.verified.json')), validation)
    _LOADED.clear()  # Coarse file timestamps must not hide a same-size rewrite.
    if not auto:
        try:
            xbmcaddon.Addon(ADDON_ID).setSetting('meganexus_auto_layout', '')
        except Exception:
            pass
    return sum(len(g['folders']) for g in groups)


LOGOS_DONE = 'meganexus_collection_logos'   # 7.0.44: '2' once Nuvio's name logos were filled in and checked


def check_logos(reachable):
    """7.0.44: name logos that do not load (a pack names files it never published:
    404 / 403) are taken away again - with one the name was hidden and the top
    stayed empty. ``reachable(url)``: does the picture load. Returns how many went."""
    groups = load()
    gone = 0
    seen = {}
    for group in groups or []:
        for folder in group.get('folders') or []:
            logo = folder.get('logo')
            if not logo:
                continue
            if logo not in seen:
                seen[logo] = bool(reachable(logo))
            if not seen[logo]:
                folder.pop('logo', None)
                gone += 1
    if gone:
        save(groups, auto=True)
    return gone


def fill_logos(raw):
    """7.0.44: the name logos (titleLogoUrl...) of the collections in ``raw`` (Nuvio's
    collections) written into the saved ones that lack them - matched by id, else by
    name; nothing else changes (order, covers, switches, whose layout it is). Imports
    before 7.0.44 dropped them. Returns how many were added."""
    try:
        fresh = normalize(raw)
    except Exception:
        return 0
    by_id, by_name = {}, {}
    for group in fresh:
        for folder in group['folders']:
            if folder.get('logo'):
                by_id[folder['id']] = folder['logo']
                by_name[str(folder.get('title') or '').strip().lower()] = folder['logo']
    if not by_id:
        return 0
    groups = load()
    added = 0
    for group in groups or []:
        for folder in group.get('folders') or []:
            if folder.get('logo'):
                continue
            logo = by_id.get(folder.get('id')) or by_name.get(str(folder.get('title') or '').strip().lower())
            if logo:
                folder['logo'] = logo
                added += 1
    if added:
        save(groups, auto=True)          # auto: whose layout it is stays as it was
    return added


_LOADED={}


def _ready():
    path=profile_file()
    try:
        stat=path.stat()
        memo=(str(path),stat.st_mtime_ns,stat.st_size)
    except OSError:
        return False
    if _LOADED.get('key')!=memo:
        try:groups=normalize(json.loads(path.read_text(encoding='utf-8-sig')))
        except (ValueError,OSError):return False
        # 7.0.31: each collection on its own too - folder() copies only the one asked for.
        folders={f['id']:json.dumps(f,ensure_ascii=False) for g in groups for f in g.get('folders') or [] if f.get('id')}
        _LOADED.clear();_LOADED.update(key=memo,text=json.dumps(groups,ensure_ascii=False),folders=folders)
    return True


def load():
    """Normalized profile; parsed once per file change. Each call gets a fresh copy."""
    if not _ready():return []
    return json.loads(_LOADED['text'])


def folder(collection_id):
    """One collection (a fresh copy), without copying the whole profile: 600
    collections of 1.3 MB were parsed once per collection - 47 s of the opening
    check on a CoreELEC box."""
    if not _ready():return None
    text=_LOADED['folders'].get(collection_id)
    return json.loads(text) if text else None


def mapping_report():
    from .collections_home import matching_catalog
    from .meganexus import store
    providers=store.list_providers();matched=missing=0
    for group in load():
        for folder in group['folders']:
            for source in folder['sources']:
                if matching_catalog(source,providers):matched+=1
                else:missing+=1
    return matched,missing

def fill_shapes():
    """7.0.42, once: collections imported before the card shape was kept get it from
    Nuvio - only the shape (and the focus-GIF switch); names, order, hidden rows and
    catalogs stay as the user has them. Network: the service, never a GUI callback."""
    groups=load()
    if not groups or all(f.get('shape') for g in groups for f in g['folders']):return 0
    from .meganexus import nuvio_stremio_sync as sync
    if not sync.Nuvio.is_linked():return 0
    remote=sync.Nuvio.sync_collections([],direction='pull') or []
    if isinstance(remote,dict):remote=remote.get('collections') or remote.get('groups') or []
    found={}
    for g in remote if isinstance(remote,list) else []:
        for f in (g.get('folders') or g.get('entries') or []) if isinstance(g,dict) else []:
            if isinstance(f,dict) and f.get('id'):found[str(f['id'])]=f
    changed=0
    for g in groups:
        for f in g['folders']:
            source=found.get(f['id'])
            if source is None or f.get('shape'):continue
            if shape_of(source):
                f['shape']=shape_of(source);changed+=1
            if source.get('focusGifEnabled') is False and f.get('animation'):
                f['animation']='';changed+=1
    if changed:
        from .meganexus.safe_io import write_json
        write_json(str(profile_file()),groups)
        _LOADED.clear()
    return changed


def sync_from_nuvio():
    from .meganexus import nuvio_stremio_sync as sync
    if not sync.Nuvio.is_linked():raise ValueError('Sign in to Nuvio in Settings > Account first.')
    # Never upload local presets over somebody's Nuvio profile.
    remote=sync.Nuvio.sync_collections([],direction='pull')
    return save(remote)
