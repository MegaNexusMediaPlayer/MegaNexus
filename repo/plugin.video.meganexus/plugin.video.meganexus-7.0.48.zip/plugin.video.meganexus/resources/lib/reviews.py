# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Reviews of a film or series under its Cast & crew (7.0.45).

From the services that are switched on: Trakt (its comments and reviews, public -
no sign-in) when Trakt is on, TMDB (its reviews) when a TMDB key is set. Simkl
and IMDb have no review API. Each review keeps its source, author, rating, likes
and whether it gives the story away; the best come first (a review over a short
comment, then the most liked), at most LIMIT. Kept a day (CACHE_TTL).
"""
import re
import threading
import time

SETTING = 'meganexus_reviews'
SOURCE_SETTINGS = {'Trakt': 'meganexus_reviews_trakt', 'TMDB': 'meganexus_reviews_tmdb'}
LIMIT = 10
CACHE_TTL = 24 * 3600
KIND = 'meganexus_reviews'
TIMEOUT = 12
_TAGS = re.compile(r'<[^>]+>')
_MARKS = re.compile(r'\[(?:/?spoiler|/?b|/?i)\]', re.I)
_LOCK = threading.Lock()


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_cache import cached_addon
    return cached_addon()


def enabled(addon=None):
    return (_addon(addon).getSetting(SETTING) or 'true') != 'false'


def source_on(name, addon=None):
    """The source is chosen in Settings (both are, at first)."""
    return (_addon(addon).getSetting(SOURCE_SETTINGS[name]) or 'true') != 'false'


def available(addon=None):
    """The sources that can give reviews here: Trakt when it is on, TMDB with a key."""
    found = []
    try:
        from . import trakt
        if trakt.enabled():
            found.append('Trakt')
    except Exception:
        pass
    try:
        from . import tmdb_direct
        if (tmdb_direct._setting('tmdb_api_key', '') or '').strip():
            found.append('TMDB')
    except Exception:
        pass
    return found


def sources(addon=None):
    """The review sources that can give reviews and are chosen, in order."""
    return [name for name in available(addon) if source_on(name, addon)]


def clean(text):
    """Plain text from a review's HTML / BBCode / Markdown marks."""
    text = _MARKS.sub('', _TAGS.sub('', str(text or '')))
    text = re.sub(r'(?m)^\s*#+\s*', '', text).replace('**', '').replace('__', '')
    text = text.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'")
    return re.sub(r'\n{3,}', '\n\n', re.sub(r'[ \t]+', ' ', text)).strip()


def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def trakt_reviews(kind, imdb='', tmdb=''):
    from . import trakt
    path = 'shows' if kind == 'series' else 'movies'
    ident = imdb if str(imdb).startswith('tt') else ''
    if not ident and str(tmdb).isdigit():
        found = trakt._request('/search/tmdb/%s?type=%s' % (tmdb, 'show' if kind == 'series' else 'movie'), timeout=TIMEOUT) or []
        ident = next((str(((row.get('show') or row.get('movie') or {}).get('ids') or {}).get('trakt') or '')
                      for row in found if isinstance(row, dict)), '')
    if not ident:
        return []
    rows = trakt._request('/%s/%s/comments/likes?limit=%d' % (path, ident, LIMIT * 3), timeout=TIMEOUT) or []
    out = []
    for row in rows if isinstance(rows, list) else []:
        text = clean(row.get('comment'))
        if not text:
            continue
        rating = _number((row.get('user_stats') or {}).get('rating') or row.get('user_rating'))
        out.append({'source': 'Trakt', 'author': str((row.get('user') or {}).get('username') or 'Trakt user'),
                    'rating': rating, 'likes': int(row.get('likes') or 0), 'spoiler': bool(row.get('spoiler')),
                    'review': bool(row.get('review')), 'text': text, 'date': str(row.get('created_at') or '')[:10]})
    return out


def tmdb_reviews(kind, tmdb='', imdb=''):
    from . import tmdb_direct
    if not str(tmdb).isdigit() and str(imdb).startswith('tt'):
        # a title known by its IMDb id only (most series): TMDB finds its own id
        tmdb = tmdb_direct._resolve_tmdb_from_imdb(imdb, 'tv' if kind == 'series' else 'movie')
    if not str(tmdb).isdigit():
        return []
    data = tmdb_direct._request('/%s/%s/reviews' % ('tv' if kind == 'series' else 'movie', tmdb),
                                {'language': 'en-US', 'page': 1}, timeout=TIMEOUT) or {}
    out = []
    for row in data.get('results') or []:
        text = clean(row.get('content'))
        if not text:
            continue
        details = row.get('author_details') or {}
        out.append({'source': 'TMDB', 'author': str(row.get('author') or details.get('username') or 'TMDB user'),
                    'rating': _number(details.get('rating')), 'likes': 0, 'spoiler': False, 'review': True,
                    'text': text, 'date': str(row.get('created_at') or '')[:10]})
    return out


def ranked(rows):
    """A review before a short comment, then the most liked, then the longest; the
    sources take turns so one does not fill the row."""
    def order(row):
        return (not row.get('review') and len(row['text']) < 400, -row.get('likes', 0), -len(row['text']))
    by_source = {}
    for row in sorted(rows, key=order):
        by_source.setdefault(row['source'], []).append(row)
    out = []
    while any(by_source.values()) and len(out) < LIMIT:
        for name in list(by_source):
            if by_source[name] and len(out) < LIMIT:
                out.append(by_source[name].pop(0))
    return out


def title_ids(meta):
    from .art import extract_ids
    try:
        ids = extract_ids(meta) or {}
    except Exception:
        ids = {}
    tmdb = str(ids.get('tmdb_id') or meta.get('tmdb_id') or meta.get('moviedb_id') or '').split(':')[-1]
    imdb = str(ids.get('imdb_id') or meta.get('imdb_id') or '')
    return imdb, tmdb


def for_title(meta, addon=None):
    """The title's reviews from the switched-on sources ([] when off or none)."""
    if not enabled(addon):
        return []
    kind = 'series' if (meta.get('type') or '') == 'series' else 'movie'
    imdb, tmdb = title_ids(meta)
    names = sources(addon)
    if not names or not (imdb or tmdb):
        return []
    from . import cache_store
    key = '2|%s|%s|%s|%s' % (kind, imdb, tmdb, ','.join(names))   # 2: TMDB by the IMDb id too
    kept = cache_store.get(KIND, key)
    if isinstance(kept, dict) and time.time() - float(kept.get('at') or 0) < CACHE_TTL:
        return kept.get('rows') or []
    rows, jobs = [], []
    if 'Trakt' in names:
        jobs.append(lambda: trakt_reviews(kind, imdb, tmdb))
    if 'TMDB' in names:
        jobs.append(lambda: tmdb_reviews(kind, tmdb, imdb))

    def run(job):
        try:
            found = job()
        except Exception as exc:
            try:
                import xbmc
                xbmc.log('[MegaNexus] reviews: %s' % type(exc).__name__, xbmc.LOGINFO)
            except Exception:
                pass
            return
        with _LOCK:
            rows.extend(found)
    threads = [threading.Thread(target=run, args=(job,), daemon=True) for job in jobs]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(TIMEOUT + 2)
    rows = ranked(rows)
    cache_store.update(KIND, key, {'at': time.time(), 'rows': rows})
    return rows
