# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Spotnet: an index of films and series built on this box (7.0.45).

Spotnet is an index that lives on Usenet itself: every "spot" is an article in
free.pt whose header carries the release's name, kind, size and a reference to
its NZB (posted on Usenet too). With only the user's Usenet provider, MegaNexus
reads the newest spots' overview lines (XOVER: a few hundred bytes each), keeps
the films and series in a small database in the profile (spotnet.db) and finds a
title's releases there by its name, year, season and episode. Only when a spot is
played is its full header read (the NZB's article ids) and its NZB put together -
the Usenet player then streams it like any other NZB. No account, no API key, no
server in between. One more source next to the indexers, Easynews and add-ons;
switched on and off on its own (HUB Settings > Usenet > Spotnet).

The format follows Spotweb (BSD-3-Clause), written anew here: the overview's From
field is "poster <key@CATKEYSUBCATS.SIZE.RANDOM.DATE...SIGNATURE>", the subject
"title | tag"; a spot of key 7 proves itself by a message id whose SHA-1 starts
with 0000 (the hashcash spammers do not pay for) - other spots are left out.
"""
import hashlib
import os
import re
import sqlite3
import threading
import time
import zlib
import xml.etree.ElementTree as ET

GROUP = 'free.pt'
SETTING = 'spotnet_enabled'
DB = 'spotnet.db'
FIRST_ARTICLES = 100000        # the first build reads this many of the newest spots (about a month)
CHUNK = 4000                   # overview lines asked at once
KEEP_DAYS = 120                # spots older than this leave the database
EVERY = 6 * 3600               # the index is brought up to date this often (when nothing plays)
MAX_ROWS = 40
_LOCK = threading.RLock()
_WORDS = re.compile(r'[a-z0-9]+')
_YEAR = re.compile(r'(?<!\d)(19[3-9]\d|20[0-4]\d)(?!\d)')
_EPISODE = re.compile(r's(\d{1,2})[ ._-]*e(\d{1,3})', re.I)
_SEASON_PACK = re.compile(r'\b(?:s(\d{1,2})(?![ ._-]*e\d)|season[ ._-]*(\d{1,2}))\b', re.I)
_RESOLUTION = re.compile(r'(?<!\d)(2160|1080|720|480)[pi]', re.I)
EROTIC = {'d23', 'd24', 'd25', 'd26'} | {'d%d' % n for n in range(72, 90)}


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Spotnet: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_cache import cached_addon
    return cached_addon()


def _path(name=DB):
    from .meganexus.common import profile_path
    return os.path.join(profile_path(), name)


def enabled(addon=None):
    try:
        return _addon(addon).getSetting(SETTING) == 'true'
    except Exception:
        return False


def _servers(addon=None):
    from . import usenet_nntp as nntp, usenet_stream
    return [s for s in (nntp.parse_server(v) for v in usenet_stream.own_servers(addon)) if s]


def active(addon=None):
    """Switched on, a Usenet server to read and play with, and an index built."""
    return enabled(addon) and bool(_servers(addon)) and status()[0] > 0


# --- the overview line --------------------------------------------------------

def _text(raw):
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError:
        return raw.decode('latin-1')


def normal(text):
    return ' '.join(_WORDS.findall(str(text or '').lower().replace('&', ' and ')))


def hashcash(message_id):
    """Spotnet's proof of work: the SHA-1 of "<message-id>" starts with 0000."""
    return hashlib.sha1(('<%s>' % message_id.strip('<>')).encode('utf-8', 'ignore')).hexdigest().startswith('0000')


def parse(line):
    """One overview line -> {'msgid', 'title', 'kind', 'size', 'stamp', 'subcats', 'poster'} or None
    (not a film or series, not proven, or not a spot)."""
    fields = line.split(b'\t')
    if len(fields) < 5:
        return None
    subject, sender, date, message_id = (_text(f).strip() for f in fields[1:5])
    at = sender.find('<')
    if at < 0 or '@' not in sender[at:]:
        return None
    header = sender[at + 1:].rstrip('>').split('@', 1)[1]
    parts = header.split('.')
    if len(parts) < 6 or len(parts[0]) < 2 or not parts[0][:2].isdigit():
        return None
    category, key = int(parts[0][0]) - 1, int(parts[0][1])
    if category != 0 or key != 7 or not hashcash(message_id):
        return None
    subcats = ['%s%d' % (m[0], int(m[1:])) for m in re.findall(r'[a-dz]\d+', parts[0][2:].lower())]
    kind = None
    if 'z1' in subcats:
        kind = 'series'
    elif 'z0' in subcats:
        kind = 'movie'
    elif not any(s.startswith('z') for s in subcats):
        if EROTIC & set(subcats) or {'a5', 'a11', 'a12', 'a13'} & set(subcats):
            return None
        kind = 'series' if ({'b4', 'd11'} & set(subcats) or _EPISODE.search(subject)) else 'movie'
    if kind is None or EROTIC & set(subcats):
        return None
    title = subject.split('|', 1)[0].strip()
    if not title:
        return None
    try:
        size = int(parts[1])
    except ValueError:
        size = 0
    try:
        from email.utils import parsedate_to_datetime
        stamp = int(parsedate_to_datetime(date).timestamp())
    except Exception:
        stamp = int(time.time())
    return {'msgid': message_id.strip('<>'), 'title': title, 'kind': kind, 'size': size, 'stamp': min(stamp, int(time.time())),
            'subcats': ''.join(subcats), 'poster': sender[:at].strip().strip('"')}


# --- the database ---------------------------------------------------------------

def _connect(path=None):
    conn = sqlite3.connect(path or _path(), timeout=10)
    conn.execute('CREATE TABLE IF NOT EXISTS spots (msgid TEXT PRIMARY KEY, title TEXT, norm TEXT, kind TEXT, '
                 'size INTEGER, stamp INTEGER, subcats TEXT, poster TEXT)')
    conn.execute('CREATE INDEX IF NOT EXISTS spots_kind ON spots (kind, stamp)')
    conn.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)')
    return conn


def _meta(conn, key, default=''):
    row = conn.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return row[0] if row else default


def status(path=None):
    """(spots kept, last update time or 0)."""
    try:
        if not os.path.isfile(path or _path()):
            return 0, 0
        with _LOCK:
            conn = _connect(path)
            try:
                count = conn.execute('SELECT COUNT(*) FROM spots').fetchone()[0]
                return count, float(_meta(conn, 'updated', '0') or 0)
            finally:
                conn.close()
    except Exception:
        return 0, 0


def sync(servers=None, stop=None, progress=None, path=None, first=FIRST_ARTICLES):
    """Read the spots posted since the last time (the newest `first` the first time).
    Returns how many films and series were added."""
    from . import usenet_nntp as nntp
    servers = servers if servers is not None else _servers()
    if not servers:
        raise nntp.NntpError('no Usenet server')
    stop = stop or (lambda: False)
    connection = nntp.Connection(servers[0])
    added = 0
    with _LOCK:
        conn = _connect(path)
    try:
        _, low, high = connection.group(GROUP)
        last = int(_meta(conn, 'last', '0') or 0)
        start = max(low, last + 1, high - first + 1)
        total = max(0, high - start + 1)
        done = 0
        for begin in range(start, high + 1, CHUNK):
            if stop():
                break
            end = min(high, begin + CHUNK - 1)
            spots = [s for s in (parse(line) for line in connection.overview(begin, end)) if s]
            with _LOCK:
                conn.executemany('INSERT OR IGNORE INTO spots VALUES (?,?,?,?,?,?,?,?)',
                                 [(s['msgid'], s['title'], normal(s['title']), s['kind'], s['size'], s['stamp'], s['subcats'], s['poster'])
                                  for s in spots])
                conn.execute('INSERT OR REPLACE INTO meta VALUES (?,?)', ('last', str(end)))
                conn.commit()
            added += len(spots)
            done += end - begin + 1
            if progress:
                progress(done, total, added)
        with _LOCK:
            conn.execute('DELETE FROM spots WHERE stamp < ?', (int(time.time()) - KEEP_DAYS * 86400,))
            conn.execute('INSERT OR REPLACE INTO meta VALUES (?,?)', ('updated', str(time.time())))
            conn.commit()
    finally:
        connection.close()
        conn.close()
    _log('%d films and series added' % added)
    return added


# --- finding a title --------------------------------------------------------------

def _size_label(size):
    return ('%.2f GB' % (size / 1e9)) if size >= 1e9 else (('%.0f MB' % (size / 1e6)) if size else '')


def search(kind, name, year='', season=None, episode=None, path=None):
    """The title's spots, newest first: every word of its name, its year (films) or its episode."""
    words = normal(name).split()
    if not words:
        return []
    longest = max(words, key=len)
    with _LOCK:
        conn = _connect(path)
        try:
            found = conn.execute('SELECT msgid, title, norm, size, stamp, subcats FROM spots WHERE kind=? AND norm LIKE ? '
                                 'ORDER BY stamp DESC LIMIT 400', (kind, '%' + longest + '%')).fetchall()
        finally:
            conn.close()
    rows = []
    for msgid, title, norm, size, stamp, subcats in found:
        have = norm.split()
        if any(w not in have for w in words):
            continue
        if kind == 'movie':
            years = _YEAR.findall(title)
            if year and years and str(year) not in years:
                continue
        else:
            hit = _EPISODE.search(title)
            if hit:
                if (int(hit.group(1)), int(hit.group(2))) != (int(season), int(episode)):
                    continue
            else:
                pack = _SEASON_PACK.search(title)
                if not pack or int(pack.group(1) or pack.group(2)) != int(season):
                    continue
        rows.append({'msgid': msgid, 'title': title, 'size': size, 'stamp': stamp, 'subcats': subcats})
        if len(rows) >= MAX_ROWS:
            break
    return rows


def rows_of(found):
    """Stremio-shaped NZB rows; the NZB is put together when one is played (spotnet:<message-id>)."""
    out = []
    for spot in found:
        resolution = _RESOLUTION.search(spot['title'])
        label = resolution.group(0).lower() if resolution else 'Usenet'
        detail = [spot['title']] + (['💾 ' + _size_label(spot['size'])] if spot['size'] else [])
        out.append({'name': '[SPOT] Spotnet\n%s' % label, 'title': '\n'.join(detail),
                    'nzbUrl': 'spotnet:%s' % spot['msgid'], 'type': 'usenet',
                    'behaviorHints': {'videoSize': spot['size'] or None, 'filename': spot['title'],
                                      'bingeGroup': 'spotnet-%s' % label}})
    return out


def jobs(media_type, video_id, addon=None):
    """[(name, fn)] next to the indexers - or [] while switched off or not built."""
    if not active(addon):
        return []
    from .debrid import _video_ref, title_of
    ref = _video_ref(media_type, video_id)
    if not ref:
        return []
    kind, stremio_id, season, episode = ref

    def job():
        name, year = title_of(kind, stremio_id.split(':')[0])
        found = search(kind, name, year, season, episode) if name else []
        origin = {'id': 'spotnet', 'name': 'Spotnet', 'base_url': ''}
        return [dict(row, _meganexus_source=origin) for row in rows_of(found)]
    return [('Spotnet', job)]


# --- the NZB, when a spot is played ------------------------------------------------

def unspecial(data):
    return data.replace(b'=C', b'\n').replace(b'=B', b'\r').replace(b'=A', b'\0').replace(b'=D', b'=')


def nzb(message_id, servers):
    """Read the spot's full header (its XML), then its NZB from Usenet."""
    from . import usenet_nntp as nntp
    last = None
    for server in servers:
        connection = None
        try:
            connection = nntp.Connection(server)
            header = connection.head(message_id)
            xml = b''.join(line[7:] for line in header if line[:6].lower() == b'x-xml:')
            if not xml:
                raise nntp.NntpError('not a Spotnet spot')
            if len(xml) > 50 * 1024:
                raise nntp.NntpError('the spot is too large')
            text = _text(xml).replace('spot.net></Segment>', 'spot.net</Segment>')
            root = ET.fromstring(text)
            holder = root.find('.//NZB')              # the image has segments of its own
            segments = [s.text.strip() for s in holder.findall('Segment') if s.text] if holder is not None else []
            if not segments:
                raise nntp.NntpError('the spot has no NZB')
            data = b''.join(b''.join(connection.raw_body(seg)) for seg in segments)
            data = unspecial(data)
            try:
                return zlib.decompress(data, -15)
            except zlib.error:
                return data
        except nntp.AuthError:
            raise
        except Exception as exc:
            last = exc
        finally:
            if connection is not None:
                connection.close()
    raise last if isinstance(last, Exception) else nntp.NntpError('no Usenet server')


# --- kept up to date ------------------------------------------------------------------

def run(monitor):
    """The service's loop: every EVERY hours, when switched on and nothing plays, the
    newest spots are read (a minute or two after Kodi starts at the earliest)."""
    if monitor.waitForAbort(120):
        return
    while not monitor.abortRequested():
        try:
            import xbmc
            count, updated = status()
            if enabled() and _servers() and count and time.time() - updated >= EVERY and not xbmc.Player().isPlaying():
                sync(stop=lambda: monitor.abortRequested() or xbmc.Player().isPlaying())
        except Exception as exc:
            _log('not updated: %s' % type(exc).__name__)
        if monitor.waitForAbort(600):
            return
