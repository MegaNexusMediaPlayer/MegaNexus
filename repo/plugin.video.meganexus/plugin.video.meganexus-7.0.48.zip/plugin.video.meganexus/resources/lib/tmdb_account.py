# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Your TMDB account, for ratings (7.0.45).

The TMDB key MegaNexus has reads; a rating is your account's. Signing in: the TV
shows TMDB's approval page as a QR code, you approve MegaNexus once on the phone
(themoviedb.org), the TV finishes by itself. Kept per profile (tmdb_session.json,
one of user_profiles.FILES). TMDB takes no reviews from apps - only ratings.
"""
import json
import os
import urllib.parse
import urllib.request

APPROVE = 'https://www.themoviedb.org/authenticate/%s'
TIMEOUT = 15


def _path():
    from .meganexus.common import profile_path
    return os.path.join(profile_path(), 'tmdb_session.json')


def session():
    from .meganexus.safe_io import read_json
    return read_json(_path(), {}) or {}


def connected():
    return bool(session().get('session_id'))


def disconnect():
    try:
        os.remove(_path())
    except OSError:
        pass
    try:
        os.remove(_path() + '.bak')
    except OSError:
        pass


def _call(path, params=None, body=None, method=None):
    from . import tmdb_direct
    key = tmdb_direct._api_key()
    if not key:
        raise ValueError('Add a TMDB key first: Connections > API keys.')
    query = dict(params or {})
    headers = {'Accept': 'application/json', 'Content-Type': 'application/json;charset=utf-8',
               'User-Agent': 'MegaNexus/7 (Kodi)'}
    if key.startswith('eyJ') and len(key) > 60:
        headers['Authorization'] = 'Bearer ' + key
    else:
        query['api_key'] = key
    url = tmdb_direct.API_BASE + path + ('?' + urllib.parse.urlencode(query) if query else '')
    data = json.dumps(body).encode('utf-8') if body is not None else None
    request = urllib.request.Request(url, data=data, headers=headers, method=method or ('POST' if data else 'GET'))
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        text = response.read().decode('utf-8', 'replace')
    return json.loads(text) if text else {}


def start():
    """A new request token and the page where it is approved: (token, url)."""
    token = (_call('/authentication/token/new') or {}).get('request_token')
    if not token:
        raise ValueError('TMDB gave no sign-in code - try again.')
    return token, APPROVE % token


def finish(token):
    """True once the token was approved on the phone (the session is kept); False while not yet."""
    from .meganexus.safe_io import write_json
    try:
        found = _call('/authentication/session/new', body={'request_token': token}) or {}
    except Exception as exc:
        if getattr(exc, 'code', None) in (401, 403):
            return False   # not approved yet
        raise
    sid = found.get('session_id')
    if not sid:
        return False
    account = {}
    try:
        account = _call('/account', {'session_id': sid}) or {}
    except Exception:
        pass
    write_json(_path(), {'session_id': sid, 'account_id': account.get('id'), 'username': account.get('username') or ''})
    return True


def rate(item, rating):
    """The rating (1-10) of a film, show or episode on TMDB."""
    from . import tmdb_direct
    sid = session().get('session_id')
    if not sid:
        raise ValueError('Sign in to TMDB first: HUB Settings > Accounts & tracking > TMDB account.')
    kind = item.get('kind')
    tmdb = str(item.get('tmdb') or '').split(':')[-1]
    if not tmdb.isdigit() and str(item.get('imdb') or '').startswith('tt'):
        tmdb = tmdb_direct._resolve_tmdb_from_imdb(item['imdb'], 'movie' if kind == 'movie' else 'tv')
    if not str(tmdb).isdigit():
        raise ValueError('TMDB does not know this title.')
    if kind == 'episode':
        path = '/tv/%s/season/%d/episode/%d/rating' % (tmdb, int(item['season']), int(item['episode']))
    else:
        path = '/%s/%s/rating' % ('movie' if kind == 'movie' else 'tv', tmdb)
    try:
        _call(path, {'session_id': sid}, {'value': float(rating)})
    except Exception as exc:
        code = getattr(exc, 'code', None)
        if code == 401:
            disconnect()
            raise ValueError('TMDB did not accept the sign-in - sign in to TMDB again on the TV.')
        raise ValueError('TMDB did not take the rating (%s).' % (code or type(exc).__name__))
