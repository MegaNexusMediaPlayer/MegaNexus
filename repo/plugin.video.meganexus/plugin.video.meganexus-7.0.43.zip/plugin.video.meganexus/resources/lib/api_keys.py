# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The users' own API keys (7.0): one list for HUB Settings and the phone
setup page. Keys are stored in MegaNexus settings, never sent back to the
phone (only whether one is set) and never written to the log."""
from collections import OrderedDict

KEYS = OrderedDict([
    ('tmdb', {'setting': 'tmdb_api_key', 'name': 'TMDb',
              'purpose': 'TMDB collections (networks, companies, lists) and actor search',
              'url': 'https://www.themoviedb.org/settings/api', 'min': 16}),
    ('mdblist', {'setting': 'mdblist_api_key', 'name': 'MDBList',
                 'purpose': 'MDBList lists and ratings',
                 'url': 'https://mdblist.com/preferences/', 'min': 10}),
    ('fanarttv', {'setting': 'fanarttv_api_key', 'name': 'Fanart.tv',
                  'purpose': 'more and newer logos and backgrounds (personal key)',
                  'url': 'https://fanart.tv/get-an-api-key/', 'min': 16}),
    ('introdb', {'setting': 'meganexus_introdb_key', 'name': 'TheIntroDB',
                 'purpose': 'skip intro / recap / credits timings',
                 'url': 'https://theintrodb.org/', 'min': 8}),
    # 7.0.12: a debrid service built in - streams without a stream add-on.
    ('torbox', {'setting': 'torbox_api_key', 'name': 'TorBox',
                'purpose': 'streams straight from your TorBox account (no add-on needed)',
                'url': 'https://torbox.app/settings', 'min': 20}),
    ('premiumize', {'setting': 'premiumize_api_key', 'name': 'Premiumize',
                    'purpose': 'streams straight from your Premiumize account (no add-on needed)',
                    'url': 'https://www.premiumize.me/account', 'min': 10}),
    # 7.0.37: Offcloud (torrents, like TorBox) and Easynews (Usenet; its login).
    ('offcloud', {'setting': 'offcloud_api_key', 'name': 'Offcloud',
                  'purpose': 'streams straight from your Offcloud account (no add-on needed)',
                  'url': 'https://offcloud.com/#/account', 'min': 10}),
    ('easynews', {'setting': 'easynews_login', 'name': 'Easynews',
                  'purpose': 'Usenet streams from Easynews - enter it as username:password',
                  'url': 'https://account.easynews.com/', 'min': 3, 'pair': True}),
    # 7.0.43: the user's Usenet provider for NZB sources (usenet_stream.py); the port
    # and SSL are found on saving. Stored as nntps://user:password@host:port/connections.
    ('usenet', {'setting': 'usenet_server', 'name': 'Usenet server',
                'purpose': 'your Usenet provider, plays NZB sources - enter username:password@news.provider.com',
                'url': 'https://www.reddit.com/r/usenet/wiki/providers/', 'min': 3, 'server': True,
                'placeholder': 'username:password@news.provider.com'}),
])


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_cache import cached_addon
    return cached_addon()


def status(addon=None):
    """[{'id', 'name', 'purpose', 'url', 'set'}] - no key values."""
    addon = _addon(addon)
    return [{'id': key, 'name': row['name'], 'purpose': row['purpose'], 'url': row['url'], 'placeholder': row.get('placeholder', ''),
             'set': bool((addon.getSetting(row['setting']) or '').strip())} for key, row in KEYS.items()]


def usenet_value(value):
    """'user:password@news.provider.com[:port]' -> the stored server address (port
    and SSL found by connecting). Raises ValueError with what to fix."""
    from . import usenet_stream
    text = value.split('://', 1)[-1].strip().rstrip('/')
    login, at, place = text.rpartition('@')
    user, _, password = login.partition(':')
    host, _, port = place.partition(':')
    if not at or not user or not password or not host:
        raise ValueError('Enter the Usenet server as username:password@news.provider.com.')
    found, reason = usenet_stream.detect(host.strip(), user, password, 10, int(port) if port.strip().isdigit() else None)
    if reason:
        raise ValueError('Usenet server: %s.' % reason)
    return found


def save(key, value, addon=None):
    """Store (or with an empty value, remove) one key."""
    if key not in KEYS:
        raise ValueError('Unknown API key.')
    row = KEYS[key]
    value = str(value or '').strip()
    if value and row.get('server'):
        value = usenet_value(value)
    elif value and row.get('pair') and (':' not in value or not all(part.strip() for part in value.split(':', 1))):
        raise ValueError('Enter the %s login as username:password.' % row['name'])
    if value and not row.get('pair') and not row.get('server') and (len(value) < row['min'] or any(ch.isspace() for ch in value)):
        raise ValueError('That does not look like a %s API key. Copy it again from %s.' % (row['name'], row['url']))
    addon = _addon(addon)
    addon.setSetting(row['setting'], value)
    try:
        from . import settings_cache
        settings_cache.invalidate()
    except Exception:
        pass
    return {}
