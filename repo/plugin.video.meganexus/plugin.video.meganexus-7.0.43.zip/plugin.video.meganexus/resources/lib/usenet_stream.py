# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Plays NZB sources in Kodi (7.0.43).

A stream add-on can give a source as `nzbUrl` + `servers` (Usenet Streamer's
native mode; what Stremio v5 plays with its own Usenet client). Kodi cannot, so:

* register(row) - from any MegaNexus process - keeps the NZB link and the servers
  in the profile (usenet/<token>.json, never in a URL or the log) and gives Kodi
  http://127.0.0.1:<port>/usenet/<token>/<name>;
* the service runs this local server (start / stop). On the first request it reads
  the NZB, finds the film - a plain video file, or a film stored (not compressed)
  in RAR volumes, also with obfuscated names - and answers Kodi's range requests
  from the articles, several connections at once, reading ahead of the player.

The servers are the source's own (`servers`) and the user's Usenet server (HUB
Settings > Connections > Debrid & Usenet > Usenet server), as a backup for articles
the first one lacks. A missing article is read as zeros (a short glitch, not a
stop). Compressed, encrypted and 7z releases can not be streamed - they say so.
"""
import hashlib
import itertools
import json
import os
import queue
import threading
import time
from collections import OrderedDict
from concurrent.futures import Future
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote
from urllib.request import Request, urlopen

from . import usenet_nntp as nntp

PROP_PORT = 'meganexus.usenet.port'
SETTING = 'usenet_server'               # the user's own server (nntps://user:pass@host:563/10)
CACHE_PARTS = 40                        # decoded articles kept (~30 MB)
AHEAD = 24                              # articles read ahead of the player
IDLE = 300                              # seconds before an unused source closes its connections
WAIT = 60                               # seconds an article may take
SNIFF_LIMIT = 400                       # obfuscated files whose first article is read


def _log(text, level=None):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Usenet: %s' % text, xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


def _folder():
    from .meganexus.common import profile_path
    path = os.path.join(profile_path(), 'usenet')
    os.makedirs(path, exist_ok=True)
    return path


def own_servers(addon=None):
    try:
        if addon is None:
            from .settings_cache import cached_addon
            addon = cached_addon()
        return [line for line in (addon.getSetting(SETTING) or '').split() if line.strip()]
    except Exception:
        return []


def servers_for(row):
    listed = row.get('servers') if isinstance(row.get('servers'), list) else []
    return [str(s) for s in listed if s] + own_servers()


def playable(row):
    """An nzbUrl row MegaNexus can play: a link and at least one server."""
    return bool(isinstance(row, dict) and row.get('nzbUrl') and servers_for(row))


def register(row):
    """The local link Kodi plays for an nzbUrl row, or ''."""
    servers = servers_for(row)
    url = str(row.get('nzbUrl') or '')
    if not url or not servers:
        return ''
    try:
        import xbmcgui
        port = xbmcgui.Window(10000).getProperty(PROP_PORT)
    except Exception:
        port = ''
    if not port:
        return ''
    token = hashlib.sha256(('%s|%s' % (url, '|'.join(servers))).encode('utf-8')).hexdigest()[:32]
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    name = os.path.basename(str(hints.get('filename') or 'video.mkv')) or 'video.mkv'
    path = os.path.join(_folder(), token + '.json')
    if not os.path.isfile(path):
        temp = path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump({'nzb': url, 'servers': servers, 'name': name, 'at': time.time()}, handle)
        try:
            os.chmod(temp, 0o600)
        except Exception:
            pass
        os.replace(temp, path)
    return 'http://127.0.0.1:%s/usenet/%s/%s' % (port, token, quote(name))


# --- articles ----------------------------------------------------------------

class Fetcher(object):
    """Articles from the servers in order (a missing one is asked from the next),
    `connections` threads each; decoded parts are cached."""

    def __init__(self, servers):
        self.servers = servers
        self.queues = [queue.PriorityQueue() for _ in servers]
        self.started = [False] * len(servers)
        self.dead = [False] * len(servers)
        self.lock = threading.RLock()
        self.cache = OrderedDict()
        self.flying = {}
        self.order = itertools.count()
        self.closed = False
        self.missing = 0
        self.refused = ''                                  # a server that refused the login

    def get(self, message_id, priority=0):
        with self.lock:
            if message_id in self.cache:
                self.cache.move_to_end(message_id)
                done = Future()
                done.set_result(self.cache[message_id])
                return done
            future = self.flying.get(message_id)
            if future is not None and priority >= future.priority:
                return future
            if future is None:
                future = Future()
                self.flying[message_id] = future
            future.priority = priority                     # asked again, sooner: queued again
            self._queue(0, (priority, next(self.order), message_id, future))
            return future

    def _queue(self, index, task):
        while index < len(self.servers) and self.dead[index]:
            index += 1
        if index >= len(self.servers):
            self._finish(task[2], task[3], None)
            return
        self.queues[index].put(task)
        if not self.started[index]:
            self.started[index] = True
            for _ in range(self.servers[index]['connections']):
                threading.Thread(target=self._work, args=(index,), name='MegaNexusUsenet', daemon=True).start()

    def _finish(self, message_id, future, value):
        with self.lock:
            self.flying.pop(message_id, None)
            if value is not None:
                self.cache[message_id] = value
                while len(self.cache) > CACHE_PARTS:
                    self.cache.popitem(last=False)
            else:
                self.missing += 1
        if not future.done():
            try:
                future.set_result(value)
            except Exception:
                pass

    def _work(self, index):
        server, connection, failures = self.servers[index], None, 0
        while not self.closed:
            try:
                task = self.queues[index].get(timeout=2)
            except queue.Empty:
                continue
            priority, _, message_id, future = task
            if future.done():
                continue
            try:
                if connection is None:
                    connection = nntp.Connection(server)
                value = nntp.yenc_decode(connection.body(message_id))
                failures = 0
                self._finish(message_id, future, value)
            except nntp.Missing:
                with self.lock:
                    self._queue(index + 1, task)
            except nntp.AuthError as exc:
                _log('%s: %s' % (nntp.server_label(server), exc))
                self.refused = nntp.server_label(server)
                self.dead[index] = True
                with self.lock:
                    self._queue(index + 1, task)
                    while True:                            # hand the rest on
                        try:
                            self._queue(index + 1, self.queues[index].get_nowait())
                        except queue.Empty:
                            break
                break
            except Exception as exc:
                if connection is not None:
                    connection.close()
                connection = None
                failures += 1
                if failures >= 3:
                    _log('%s: %s' % (nntp.server_label(server), type(exc).__name__))
                    with self.lock:
                        self._queue(index + 1, task)
                    failures = 0
                    time.sleep(1)
                else:
                    self.queues[index].put(task)
        if connection is not None:
            connection.close()

    def close(self):
        self.closed = True


# --- the film inside the NZB ---------------------------------------------------

class Source(object):
    """One NZB: where the film's bytes lie (extents over the NZB's files)."""

    def __init__(self, data, servers):
        self.fetcher = Fetcher(servers)
        self.files = [f for f in nntp.parse_nzb(data) if f.segments]
        self.extents = []                                  # (nzb file, offset in it, length)
        self.size = 0
        self.name = ''
        self.used = time.time()
        self._layout()

    # first articles
    def _head(self, nzb_file):
        if nzb_file.head is None:
            value = self.fetcher.get(nzb_file.segments[0]).result(WAIT)
            if value is None:
                if self.fetcher.refused and all(self.fetcher.dead):
                    raise nntp.AuthError('%s refused the login' % self.fetcher.refused)
                raise nntp.NntpError('the first article of a file is missing')
            begin, data, size, name = value
            nzb_file.head = data
            nzb_file.size = size or len(data)
            nzb_file.part_size = len(data) if len(nzb_file.segments) > 1 else nzb_file.size
            if name and not nzb_file.name:
                nzb_file.name = name
                nzb_file.kind = nntp.kind_of_name(name)
        return nzb_file.head

    def _heads(self, files):
        for nzb_file in files:
            if nzb_file.head is None:
                self.fetcher.get(nzb_file.segments[0], priority=-1)
        for nzb_file in files:
            self._head(nzb_file)

    def _layout(self):
        files = self.files
        if not files:
            raise nntp.NntpError('empty NZB')
        biggest = max(f.bytes for f in files)
        named = [f for f in files if f.kind in ('video', 'rar', '7z')]
        if not named or max(f.bytes for f in named) < biggest * 0.5:
            # obfuscated names: what the first article of every big file is
            unknown = sorted((f for f in files if f.kind not in ('extra',) and f.bytes >= biggest * 0.05),
                             key=lambda f: f.bytes, reverse=True)[:SNIFF_LIMIT]
            self._heads(unknown)
            for nzb_file in unknown:
                nzb_file.kind = nntp.sniff(nzb_file.head) or nzb_file.kind
        videos = [f for f in files if f.kind == 'video']
        rars = [f for f in files if f.kind == 'rar']
        rar_bytes = sum(f.bytes for f in rars)
        if videos and max(f.bytes for f in videos) >= rar_bytes:
            film = max(videos, key=lambda f: f.bytes)
            self._head(film)
            self.extents = [(film, 0, film.size)]
            self.size, self.name = film.size, film.name
            return
        if rars:
            self._rar(rars)
            return
        if any(f.kind == '7z' for f in files):
            raise nntp.Unsupported('7z archive')
        raise nntp.NntpError('no video in the NZB')

    def _rar(self, rars):
        """The biggest RAR set; volumes in order; the stored film's extents."""
        sets = {}
        for nzb_file in rars:
            base = _rar_base(nzb_file.name) if nzb_file.name and nntp.kind_of_name(nzb_file.name) == 'rar' else ''
            sets.setdefault(base, []).append(nzb_file)
        volumes = max(sets.values(), key=lambda group: sum(f.bytes for f in group))
        if all(f.head is not None for f in volumes) or not all(nntp.kind_of_name(f.name) == 'rar' for f in volumes):
            self._heads(volumes)
            infos = {id(f): nntp.rar_volume(f.head) for f in volumes}
            volumes.sort(key=lambda f: (_volume_number(infos[id(f)], f), f.index, self.files.index(f)))
            self._exact(volumes, infos)
            return
        volumes.sort(key=lambda f: _name_order(f.name))
        # named volumes: the first, second and last say where the film lies in all
        # of them (RAR cuts every volume to the same size); checked by the total
        ends = [volumes[0]] + ([volumes[1]] if len(volumes) > 2 else []) + ([volumes[-1]] if len(volumes) > 1 else [])
        self._heads(ends)
        first = _film(nntp.rar_volume(volumes[0].head))
        if len(volumes) == 1:
            self._set([(volumes[0], first['offset'], first['length'])], first)
            return
        last = _film(nntp.rar_volume(volumes[-1].head), continued=True)
        middle = _film(nntp.rar_volume(volumes[1].head), continued=True) if len(volumes) > 2 else last
        total = first['length'] + middle['length'] * (len(volumes) - 2) + last['length']
        if total != first['size']:
            self._heads(volumes)
            self._exact(volumes, {id(f): nntp.rar_volume(f.head) for f in volumes})
            return
        extents = [(volumes[0], first['offset'], first['length'])]
        extents += [(v, middle['offset'], middle['length']) for v in volumes[1:-1]]
        extents.append((volumes[-1], last['offset'], last['length']))
        for nzb_file in volumes:                          # sizes of the files not read yet
            if not nzb_file.part_size:
                nzb_file.part_size = volumes[1].part_size
        self._set(extents, first)

    def _exact(self, volumes, infos):
        first = _film(infos[id(volumes[0])])
        extents = [(volumes[0], first['offset'], first['length'])]
        for nzb_file in volumes[1:]:
            part = _film(infos[id(nzb_file)], continued=True)
            extents.append((nzb_file, part['offset'], part['length']))
        self._set(extents, first)

    def _set(self, extents, film):
        self.extents = [e for e in extents if e[2] > 0]
        self.size = sum(e[2] for e in self.extents)
        self.name = film['name']
        if film['size'] and self.size > film['size']:
            self.size = film['size']

    # reading
    def _locate(self, position):
        for nzb_file, offset, length in self.extents:
            if position < length:
                return nzb_file, offset + position
            position -= length
        return None, 0

    def _part(self, nzb_file, offset):
        part = nzb_file.part_size or 1
        return min(offset // part, len(nzb_file.segments) - 1)

    def read(self, start, end, write):
        """Bytes start..end (inclusive) to write(); reads ahead."""
        position = start
        while position <= end:
            self.used = time.time()
            nzb_file, offset = self._locate(position)
            if nzb_file is None:
                return
            index = self._part(nzb_file, offset)
            self._ahead(position, nzb_file.part_size)
            part = nzb_file.part_size or 1
            for _ in range(4):                             # parts of another size: find the right one
                value = self.fetcher.get(nzb_file.segments[index], priority=0).result(WAIT)
                if value is None:
                    data, begin = b'\x00' * part, index * part
                else:
                    begin, data = value[0], value[1]
                if not data:
                    return
                if offset < begin and index > 0:
                    index = max(0, index - 1 - (begin - offset) // part)
                elif offset >= begin + len(data) and index < len(nzb_file.segments) - 1:
                    index = min(len(nzb_file.segments) - 1, index + 1 + (offset - begin - len(data)) // part)
                else:
                    break
            skip = offset - begin
            if skip < 0 or skip >= len(data):
                return
            chunk = data[skip:skip + (end - position + 1)]
            extent_left = self._extent_left(position)
            chunk = chunk[:extent_left]
            if not chunk:
                return
            write(chunk)
            position += len(chunk)

    def _extent_left(self, position):
        for _, _, length in self.extents:
            if position < length:
                return length - position
            position -= length
        return 0

    def _ahead(self, position, part):
        step = max(part or 0, 256 * 1024)
        for n in range(1, AHEAD + 1):
            nzb_file, offset = self._locate(position + n * step)
            if nzb_file is None:
                break
            self.fetcher.get(nzb_file.segments[self._part(nzb_file, offset)], priority=n)

    def close(self):
        self.fetcher.close()


def _rar_base(name):
    import re
    low = name.lower()
    return re.sub(r'(\.part\d+)?\.rar$|\.r\d{2,3}$|\.\d{3}$', '', low)


def _name_order(name):
    import re
    low = (name or '').lower()
    part = re.search(r'\.part(\d+)\.rar$', low)
    if part:
        return int(part.group(1))
    if low.endswith('.rar'):
        return -1
    old = re.search(r'\.([r-z])(\d{2,3})$', low)
    if old:
        return (ord(old.group(1)) - ord('r')) * 1000 + int(old.group(2))
    number = re.search(r'\.(\d{3})$', low)
    return int(number.group(1)) if number else 10 ** 6


def _volume_number(info, nzb_file):
    if info.get('volume') is not None:
        return info['volume']
    return 0 if info.get('first') else 1 + (_name_order(nzb_file.name) if nzb_file.name else 0)


def _film(info, continued=False):
    """The film's entry in a volume (the biggest video, or the continued file)."""
    files = info.get('files') or []
    if continued:
        files = [f for f in files if f['before']] or files
    else:
        videos = [f for f in files if f['name'].lower().endswith(nntp.VIDEO_EXT)]
        files = videos or files
    if not files:
        raise nntp.NntpError('no file in the RAR volume')
    film = max(files, key=lambda f: f['size'])
    if not film['stored']:
        raise nntp.Unsupported('compressed RAR')
    return film


# --- the local server ----------------------------------------------------------

_SOURCES = {}
_OPENING = {}
_LOCK = threading.Lock()
_server = None
_STOP = threading.Event()


def _source(token):
    with _LOCK:
        found = _SOURCES.get(token)
        opening = _OPENING.setdefault(token, threading.Lock())
    if found is not None:
        return found
    with opening:                                         # Kodi's parallel first requests: one opening
        with _LOCK:
            found = _SOURCES.get(token)
        if found is not None:
            return found
        return _open(token)


def _open(token):
    path = os.path.join(_folder(), os.path.basename(token) + '.json')
    with open(path, encoding='utf-8') as handle:
        saved = json.load(handle)
    servers = [s for s in (nntp.parse_server(v) for v in saved.get('servers') or []) if s]
    if not servers:
        raise nntp.NntpError('no Usenet server')
    request = Request(saved['nzb'], headers={'User-Agent': 'MegaNexus'})
    data = urlopen(request, timeout=30).read(64 * 1024 * 1024)
    started = time.time()
    found = Source(data, servers)
    _log('ready in %.1f s: %d files, film %.2f GB' % (time.time() - started, len(found.files), found.size / 1e9))
    with _LOCK:
        _SOURCES[token] = found
    return found


def _content_type(name):
    low = name.lower()
    for ext, kind in (('.mp4', 'video/mp4'), ('.m4v', 'video/mp4'), ('.avi', 'video/x-msvideo'), ('.webm', 'video/webm'),
                      ('.ts', 'video/mp2t'), ('.m2ts', 'video/mp2t'), ('.mov', 'video/quicktime')):
        if low.endswith(ext):
            return kind
    return 'video/x-matroska'


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args):
        pass

    def do_HEAD(self):
        self._serve(False)

    def do_GET(self):
        self._serve(True)

    def _serve(self, body):
        parts = self.path.split('?', 1)[0].strip('/').split('/')
        if len(parts) < 2 or parts[0] != 'usenet':
            self.send_error(404)
            return
        try:
            source = _source(parts[1])
        except nntp.Unsupported as exc:
            _log('can not stream this release: %s' % exc)
            self.send_error(415, str(exc))
            return
        except Exception as exc:
            _log('could not open the NZB: %s %s' % (type(exc).__name__, str(exc)[:80]))
            self.send_error(502)
            return
        size = source.size
        start, end = 0, size - 1
        ranged = self.headers.get('Range', '')
        if ranged.startswith('bytes='):
            first, _, last = ranged[6:].split(',')[0].partition('-')
            try:
                if first:
                    start = int(first)
                    end = int(last) if last else size - 1
                else:
                    start = max(0, size - int(last))
            except ValueError:
                pass
            end = min(end, size - 1)
            if start > end:
                self.send_response(416)
                self.send_header('Content-Range', 'bytes */%d' % size)
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            self.send_response(206)
            self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, size))
        else:
            self.send_response(200)
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Type', _content_type(source.name or parts[-1]))
        self.send_header('Content-Length', str(end - start + 1))
        self.end_headers()
        if body:
            try:
                source.read(start, end, self.wfile.write)
            except (BrokenPipeError, ConnectionResetError):
                pass                                       # the player seeked or stopped
            except Exception as exc:
                _log('read stopped: %s' % type(exc).__name__)


def _sweep():
    while not _STOP.wait(60):
        now = time.time()
        with _LOCK:
            old = [t for t, s in _SOURCES.items() if now - s.used > IDLE]
            for token in old:
                _SOURCES.pop(token).close()
                _OPENING.pop(token, None)
        try:                                               # saved sources older than two days
            folder = _folder()
            for name in os.listdir(folder):
                path = os.path.join(folder, name)
                if now - os.path.getmtime(path) > 2 * 86400:
                    os.remove(path)
        except Exception:
            pass


def start():
    """The service starts the server on 127.0.0.1 and publishes its port."""
    global _server
    if _server is not None:
        return
    _STOP.clear()
    try:
        _server = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
        _server.daemon_threads = True
    except Exception as exc:
        _log('server not started: %s' % exc)
        _server = None
        return
    threading.Thread(target=_server.serve_forever, name='MegaNexusUsenetServer', daemon=True).start()
    threading.Thread(target=_sweep, name='MegaNexusUsenetSweep', daemon=True).start()
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty(PROP_PORT, str(_server.server_address[1]))
    except Exception:
        pass


def stop():
    global _server
    server, _server = _server, None
    _STOP.set()
    try:
        import xbmcgui
        xbmcgui.Window(10000).clearProperty(PROP_PORT)
    except Exception:
        pass
    if server is not None:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
    with _LOCK:
        for source in _SOURCES.values():
            source.close()
        _SOURCES.clear()


TRIES = ((563, True), (443, True), (119, False))     # 7.0.43: the usual NNTP ports, SSL first


def detect(host, user, password, connections=10, port=None):
    """(server address 'nntps://...', reason) - finds the port and SSL by itself:
    a typed port with and without SSL, else 563 / 443 SSL, then 119. reason is ''
    when the login works; a wrong login keeps the port it reached."""
    import socket
    from urllib.parse import quote
    auth = '%s:%s@' % (quote(user, safe=''), quote(password, safe='')) if user else ''
    tries = ((port, True), (port, False)) if port else TRIES
    first = None
    for number, secure in tries:
        value = '%s://%s%s:%s/%s' % ('nntps' if secure else 'nntp', auth, host, number, connections)
        first = first or value
        server = nntp.parse_server(value)
        try:
            nntp.Connection(server, timeout=6).close()
            return value, ''
        except nntp.AuthError:
            return value, 'login refused - check the username and password'
        except socket.gaierror:
            return value, 'address %s not found - check the spelling' % host
        except Exception:
            continue
    return first, 'no Usenet server answered on %s' % ('port %s' % port if port else 'ports 563, 443 or 119')


def check(value):
    """Log in to a server ('nntps://...'): '' when it works, else why not."""
    server = nntp.parse_server(value)
    if not server:
        return 'not a server address'
    try:
        nntp.Connection(server, timeout=10).close()
        return ''
    except nntp.AuthError:
        return 'login refused'
    except OSError as exc:
        import socket
        if isinstance(exc, socket.gaierror):
            return 'address %s not found - check the spelling' % server['host']
        if isinstance(exc, (socket.timeout, ConnectionRefusedError)):
            return 'no answer on port %s - check the port and SSL' % server['port']
        return type(exc).__name__
    except Exception as exc:
        return type(exc).__name__
