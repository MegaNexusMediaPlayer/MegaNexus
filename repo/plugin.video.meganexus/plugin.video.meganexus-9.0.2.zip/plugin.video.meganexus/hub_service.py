# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import os
import sys
import threading
import time
import xbmc

addon_path = os.path.dirname(os.path.abspath(__file__))
lib_path = os.path.join(addon_path, 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

import xbmcgui

try:  # 7.0.52: player questions never stop all Python while a Usenet film closes
    from resources.lib.player_state import install as _safe_player
    _safe_player()
except Exception:
    pass

if __name__ == '__main__':
    # 7.0.21: a requested reset erases MegaNexus before anything reads a setting.
    try:
        from resources.lib import factory_reset
        factory_reset.apply()
    except Exception as exc:
        xbmc.log('[MegaNexus] factory reset check failed: %s' % exc, xbmc.LOGERROR)
    # 7.0: an update from the previous add-on IDs moves the profile first,
    # before anything reads settings; the next start removes the old add-ons.
    try:
        from resources.lib import rename_migration
        rename_migration.run()
        rename_migration.cleanup()
    except Exception as exc:
        xbmc.log('[MegaNexus] move from previous IDs failed: %s' % exc, xbmc.LOGERROR)


_SYNC_CYCLE_LOCK = threading.Lock()
try:
    from resources.lib.texts import tr
except Exception:
    try:
        from texts import tr
    except Exception:
        def tr(_s):
            return _s



def _purge_http_cache():
    import os as _os, time as _t
    try:
        from resources.lib.meganexus.addon_wire import HTTP_CACHE_DIR, catalog_ttl, meta_ttl
        max_ttl = max(catalog_ttl(), meta_ttl(), 3600) * 2
        if _os.path.isdir(HTTP_CACHE_DIR):
            now = _t.time()
            removed = 0
            for name in _os.listdir(HTTP_CACHE_DIR):
                path = _os.path.join(HTTP_CACHE_DIR, name)
                try:
                    if _os.path.isfile(path) and (now - _os.path.getmtime(path)) > max_ttl:
                        _os.remove(path)
                        removed += 1
                except Exception:
                    continue
            if removed:
                xbmc.log('[MegaNexus] purged %d stale http-cache files' % removed, xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] http-cache purge failed: %s' % exc, xbmc.LOGWARNING)

    try:
        import xbmcvfs
        subs_dir = xbmcvfs.translatePath('special://temp/meganexus_subs/')
        if _os.path.isdir(subs_dir):
            now = _t.time()
            cutoff = now - 86400  # 24h
            removed = 0
            for root, dirs, files in _os.walk(subs_dir):
                for fn in files:
                    fp = _os.path.join(root, fn)
                    try:
                        if _os.path.getmtime(fp) < cutoff:
                            _os.remove(fp)
                            removed += 1
                    except Exception:
                        continue
                try:
                    if root != subs_dir and not _os.listdir(root):
                        _os.rmdir(root)
                except Exception:
                    pass
            if removed:
                xbmc.log('[MegaNexus] purged %d stale subtitle files' % removed, xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] subs purge failed: %s' % exc, xbmc.LOGWARNING)

    try:
        import xbmcvfs
        switch_subs_dir = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/subtitle_cache/')
        if _os.path.isdir(switch_subs_dir):
            cutoff = _t.time() - (7 * 86400)
            removed = 0
            for fn in _os.listdir(switch_subs_dir):
                fp = _os.path.join(switch_subs_dir, fn)
                try:
                    if _os.path.isfile(fp) and _os.path.getmtime(fp) < cutoff:
                        _os.remove(fp)
                        removed += 1
                except Exception:
                    continue
            if removed:
                xbmc.log('[MegaNexus] purged %d stale switched-subtitle files' % removed, xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] switched-subs purge failed: %s' % exc, xbmc.LOGWARNING)

    try:
        from resources.lib import detail_cache as _mc
        n = _mc.purge_expired()
        if n:
            xbmc.log('[MegaNexus] purged %d expired meta_cache rows' % n, xbmc.LOGINFO)
    except Exception:
        pass
    try:
        from resources.lib import fanart_tv as _ft
        n = _ft.purge_expired()
        if n:
            xbmc.log('[MegaNexus] purged %d expired fanarttv rows' % n, xbmc.LOGINFO)
    except Exception:
        pass


def _win():
    try:
        return xbmcgui.Window(10000)
    except Exception:
        return None


def _interactive_busy(max_age=180.0):
    try:
        if xbmc.Player().isPlayingVideo():
            return True
    except Exception:
        pass
    try:
        win = _win()
        raw = win.getProperty('meganexus.interactive_busy') if win else ''
        return bool(raw and (time.time() - float(raw)) < float(max_age))
    except Exception:
        return False



def _setting(key, default=''):
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.meganexus').getSetting(key) or default
    except Exception:
        return default



def _primary_player_mode():
    raw = str(_setting('catalog_click_mode', 'TMDb Helper') or 'TMDb Helper').strip().lower()
    compact = raw.replace(' ', '').replace('_', '').replace('-', '')
    if compact in ('tmdbhelper', 'helper', '1') or 'tmdb' in compact:
        return 'tmdbhelper'
    if compact in ('ask', 'askeverytime', '2') or raw in ('Ask every time'):
        return 'ask'
    return 'meganexus'



def _iptv_on_again():
    """7.0.29: Live TV set up in MegaNexus starts with Kodi again - IPTV Simple
    left switched off by an interrupted save is switched back on.

    8.1.2: and the two settings that say so are put right from the lists on disk. They
    are a copy of what iptv-lists.json holds, and when the copy went stale this check -
    the one written for exactly this fault - could not even start: it read the settings,
    found "not set", and returned while Live TV stayed off with no playlist.
    """
    try:
        import xbmcaddon
        import xbmcvfs
        from resources.lib import iptv_config, iptv_lists
        folder = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/')
        numbers = iptv_lists.instances(folder)
        profile = xbmcvfs.translatePath('special://profile/addon_data/pvr.iptvsimple/')
        ours = [n for n in numbers if iptv_config.our_instance(profile, n)]
        if not ours:
            return
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        if addon.getSetting('meganexus_iptv_configured') != 'true':
            addon.setSetting('meganexus_iptv_configured', 'true')
            xbmc.log('[MegaNexus] Live TV is set up (%d list(s)) but the setting said it was not; '
                     'put right' % len(ours), xbmc.LOGWARNING)
        if str(addon.getSetting('meganexus_iptv_instance') or '') not in [str(n) for n in ours]:
            addon.setSetting('meganexus_iptv_instance', str(ours[0]))
        rpc = lambda method, params: json.loads(xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
        if not xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
            # 8.1.2: a list of ours with no IPTV Simple on the box at all - a restored
            # backup, or a box where it was uninstalled. Nothing to switch on, and the
            # old message ("could not be switched on") sent the reader looking for a
            # fault. Opening IPTV installs it (iptv.setup -> ensure_addon).
            xbmc.log('[MegaNexus] Live TV is set up but IPTV Simple is not installed on this '
                     'device; it is installed when you open IPTV.', xbmc.LOGINFO)
            return
        if not iptv_config.ensure_client_enabled(rpc):
            xbmc.log('[MegaNexus] IPTV Simple could not be switched on.', xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log('[MegaNexus] IPTV start check skipped: %s' % exc, xbmc.LOGWARNING)


def _publish_badge_props():
    return  # No source badge UI exists in the backend build.


def _publish_core_props(last_sync=''):
    win = _win()
    if not win:
        return
    try:
        from resources.lib import helper_player_file
        tmdbh_available = '1' if helper_player_file.has_tmdbhelper() else '0'
        tmdbh_installed = '1' if helper_player_file.player_installed() else '0'
    except Exception:
        tmdbh_available = '0'
        tmdbh_installed = '0'
    tmdbh_primary = '1' if _primary_player_mode() == 'tmdbhelper' else '0'
    try:
        from resources.lib import trakt_api
        trakt_enabled = '1' if trakt_api.enabled() else '0'
        trakt_connected = '1' if trakt_api.authorized() else '0'
    except Exception:
        trakt_enabled = '0'
        trakt_connected = '0'
    payload = {
        'meganexus.core.ready': '1',
        'meganexus.core.tmdbh.available': tmdbh_available,
        'meganexus.core.tmdbh.player_installed': tmdbh_installed,
        'meganexus.core.tmdbh.primary': tmdbh_primary,
        'meganexus.core.trakt.enabled': trakt_enabled,
        'meganexus.core.trakt.connected': trakt_connected,
        'meganexus.core.trakt.last_sync': str(last_sync or ''),
        'meganexus.core.formatter.enabled': '1' if ((_setting('enable_source_formatter', 'true') or 'true').lower() == 'true') else '0',
    }
    for k, v in payload.items():
        try:
            win.setProperty(k, v)
        except Exception:
            pass



def _invalidate_ui_caches():
    win = _win()
    if not win:
        return
    for key in ('meganexus.nextup_cache', 'meganexus.nextup_cache_ts', 'meganexus.fav_mirror_done'):
        try:
            win.clearProperty(key)
        except Exception:
            pass



def _sync_trakt_state(reason='manual'):
    try:
        from resources.lib import trakt_api
    except Exception:
        _publish_core_props('')
        return False
    if not trakt_api.enabled():
        _publish_core_props('')
        return False
    try:
        if not trakt_api.authorized():
            _publish_core_props('')
            return False
    except Exception:
        _publish_core_props('')
        return False

    did_work = False
    try:
        if trakt_api.sync_enabled():
            trakt_api.take_progress(limit=100)
            did_work = True
    except Exception as exc:
        xbmc.log('[MegaNexus] trakt progress sync failed (%s): %s' % (reason, exc), xbmc.LOGWARNING)

    try:
        from resources.lib import library_titles
        import time as _t
        win = _win()
        last = 0.0
        try:
            last = float(win.getProperty('meganexus.mirror.last') or 0) if win else 0.0
        except Exception:
            last = 0.0
        if _t.time() - last >= 30 * 60:
            include_trakt = (_setting('trakt_sync_watchlist', 'true') or 'true').lower() == 'true'
            library_titles.refresh_list_copy(include_trakt=include_trakt)
            if win:
                win.setProperty('meganexus.mirror.last', str(int(_t.time())))
            did_work = True
    except Exception as exc:
        xbmc.log('[MegaNexus] watchlist mirror sync failed (%s): %s' % (reason, exc), xbmc.LOGWARNING)

    if did_work:
        try:
            trakt_api.invalidate_cache('next_up_v1')
            trakt_api.invalidate_cache('/sync/playback/')
        except Exception:
            pass
        _invalidate_ui_caches()
        _publish_core_props(str(int(__import__('time').time())))
    else:
        _publish_core_props('')
    return did_work



def _sync_simkl_state(reason='manual'):
    if (_setting('simkl_service_sync', 'true') or 'true').lower() != 'true':
        return False
    try:
        from resources.lib import simkl_api
    except Exception:
        return False
    try:
        if not (simkl_api.enabled() and simkl_api.authorized()):
            return False
    except Exception:
        return False
    did_work = False
    try:
        simkl_api.sync_continue_watching(limit=60)
        did_work = True
    except Exception as exc:
        xbmc.log('[MegaNexus] simkl continue sync failed (%s): %s' % (reason, exc), xbmc.LOGWARNING)
    try:
        import time as _t
        win = _win()
        last = 0.0
        try:
            last = float(win.getProperty('meganexus.simkl.last_import') or 0) if win else 0.0
        except Exception:
            last = 0.0
        if _t.time() - last >= 6 * 3600:
            simkl_api.take_watched()
            if win:
                win.setProperty('meganexus.simkl.last_import', str(int(_t.time())))
            did_work = True
    except Exception as exc:
        xbmc.log('[MegaNexus] simkl watched import failed (%s): %s' % (reason, exc), xbmc.LOGWARNING)
    if did_work:
        try:
            simkl_api.invalidate_cache()
        except Exception:
            pass
        _invalidate_ui_caches()
    return did_work


def _sync_interval_ms():
    """How often Trakt and Simkl are asked in the background: 10 - 240 minutes (a setting)."""
    try:
        minutes = int(_setting('trakt_service_sync_interval', '30') or '30')
    except (TypeError, ValueError):
        minutes = 30
    return 60000 * max(10, min(240, minutes))


def _background_sync_loop(monitor):
    """Trakt and Simkl kept in step every interval while nothing else is busy (then it
    waits a minute); the HTTP cache cleaned once an hour."""
    if monitor.waitForAbort(60):
        return
    purged = time.time()
    while not monitor.abortRequested():
        busy = _interactive_busy() or not _SYNC_CYCLE_LOCK.acquire(False)
        if not busy:
            try:
                for service, step in (('trakt', _sync_trakt_state), ('simkl', _sync_simkl_state)):
                    try:
                        step(reason='service')
                    except Exception as exc:
                        xbmc.log('[MegaNexus] %s background sync failed: %s' % (service, exc), xbmc.LOGWARNING)
            finally:
                _SYNC_CYCLE_LOCK.release()
            if time.time() - purged >= 3600:
                try:
                    _purge_http_cache()
                except Exception:
                    pass
                purged = time.time()
            _publish_core_props(_win().getProperty('meganexus.core.trakt.last_sync') if _win() else '')
        if monitor.waitForAbort(60.0 if busy else _sync_interval_ms() / 1000.0):
            break


def _autodetect_language_first_run():
    """Pin the MegaNexus interface to English on first start/update.

    Subtitle preferences are deliberately left untouched: the interface language
    must not change the user's ability to play media or subtitles in any
    language.
    """
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        if (addon.getSetting('ui_language') or '').strip() != 'English':
            addon.setSetting('ui_language', 'English')
        addon.setSetting('ui_lang_autodetected', 'true')
        xbmc.log('[MegaNexus] English-only UI language applied', xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] English UI language migration failed: %s' % exc, xbmc.LOGWARNING)


def _migrate_legacy_brand_settings():
    """Carry hidden migration sentinels forward from pre-rename profiles."""
    try:
        import xbmcaddon
        from resources.lib import legacy_names
        from resources.lib.meganexus.paths import profile_path
        legacy_names.carry_forward(xbmcaddon.Addon('plugin.video.meganexus'), profile_path())
    except Exception as exc:
        xbmc.log('[MegaNexus] legacy brand-settings migration failed: %s' % exc, xbmc.LOGDEBUG)


if __name__ == '__main__':
    xbmc.log('[MegaNexus] companion service started', xbmc.LOGINFO)
    # 9.0.2: no black flash of the whole picture when a video stops (Amlogic) - first
    # thing, before anything that waits: the kernel sets the black-out again at every boot
    try:
        from resources.lib.video_layer import keep_last_frame
        if keep_last_frame():
            xbmc.log('[MegaNexus] Amlogic video layer keeps its last frame on stop (no black flash)', xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] video layer setting skipped: %s' % exc, xbmc.LOGWARNING)
    try:   # 8.1.3: Kodi went down while a resumed film opened muted (play_jobs._hush)
        import json as _json
        import xbmcvfs
        _mark = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/hushed')
        if os.path.exists(_mark):
            os.remove(_mark)
            xbmc.executeJSONRPC(_json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Application.SetMute', 'params': {'mute': False}}))
            xbmc.log('[MegaNexus] the sound was left muted by an interrupted start - on again', xbmc.LOGINFO)
    except Exception:
        pass
    try:   # 8.1.4: Kodi went down while a trailer's sound was coming up (volume_fade)
        import xbmcvfs
        _fade = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/volume_fade.json')
        if os.path.exists(_fade):
            with open(_fade, encoding='utf-8') as _handle:
                _volume = int(json.load(_handle).get('volume') or 0)
            os.remove(_fade)
            if _volume > 0:
                xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Application.SetVolume',
                                                'params': {'volume': _volume}}))
                xbmc.log('[MegaNexus] the volume was left down by an interrupted trailer - back to %d' % _volume, xbmc.LOGINFO)
    except Exception:
        pass
    _migrate_legacy_brand_settings()
    try:
        import xbmcaddon as _xa_trailers
        from resources.lib.imdb_trailers import migrate_defaults as _trailer_defaults
        _trailer_defaults(_xa_trailers.Addon('plugin.video.meganexus'))  # 6.0.27: IMDb, trailers on
    except Exception as exc:
        xbmc.log('[MegaNexus] trailer default migration skipped: %s' % exc, xbmc.LOGDEBUG)
    try:
        xbmc.log('[MegaNexus] platform: Kodi %s' % (xbmc.getInfoLabel('System.BuildVersion') or '?'),
                 xbmc.LOGINFO)
    except Exception:
        pass

    # New profiles use resources/settings.xml defaults. Existing profiles retain
    # every saved choice; upstream baseline migrations must not reset an update.
    # English is the default interface language (settings.xml).

    from resources.lib import interface_colors
    from resources.lib.presentation_settings import sync as sync_appearance
    sync_appearance()  # Update the persisted background before optional integrations start.
    interface_colors.sample_background()  # Fresh frame/colours before the interface is opened.

    _iptv_on_again()
    try:
        # 7.0.42: once - a screensaver picture of your own becomes the wallpaper too
        if not _setting('meganexus_wallpaper_follow_done'):
            from resources.lib import wallpaper as _wallpaper_once
            from resources.lib.settings_snapshot import cached_addon as _cached_once
            _wallpaper_once.follow_saver(_cached_once())
            _cached_once().setSetting('meganexus_wallpaper_follow_done', '1')
    except Exception as exc:
        xbmc.log('[MegaNexus] Wallpaper check skipped: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.42: once - an installed OpenSubtitles v3 that is OFF comes back ON
        if _setting('meganexus_opensubtitles_woken') != 'true':
            from resources.lib import subtitle_providers as _subs_once
            from resources.lib.settings_snapshot import cached_addon as _cached_subs
            if _subs_once.wake_installed(_cached_subs()):
                xbmc.log('[MegaNexus] OpenSubtitles v3 switched on as a subtitle source', xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] OpenSubtitles check skipped: %s' % exc, xbmc.LOGWARNING)
    if _setting('meganexus_collection_shapes_done') != 'true':
        # 7.0.42, once: the card shape of collections imported before it was kept (Nuvio)
        def _shapes_once():
            if xbmc.Monitor().waitForAbort(25):
                return
            try:
                from resources.lib import collection_profile as _profile_once
                from resources.lib.settings_snapshot import cached_addon as _cached_shapes
                changed = _profile_once.fill_shapes()
                _cached_shapes().setSetting('meganexus_collection_shapes_done', 'true')
                if changed:
                    xbmc.log('[MegaNexus] Collections: %d card shapes taken from Nuvio' % changed, xbmc.LOGINFO)
            except Exception as exc:
                xbmc.log('[MegaNexus] Collection shapes not refreshed: %s' % exc, xbmc.LOGWARNING)
        import threading as _thr_shapes
        _thr_shapes.Thread(target=_shapes_once, name='MegaNexusCollectionShapes', daemon=True).start()
    try:
        # 7.0.37: IPTV lists - only live TV in Kodi's channel list (films and series
        # stay out of the PVR, the biggest RAM and CPU cost on boxes), films and
        # series as the IPTV VOD source
        import threading as _thr_live
        import xbmcvfs as _vfs_live
        from resources.lib import iptv_live, iptv_lists

        def _live_setting():
            return (_setting('meganexus_iptv_configured') == 'true', _setting('meganexus_iptv_instance'),
                    _setting(iptv_live.SETTING, 'true') != 'false')

        def _live_busy():
            # Home may stay open all day: only a playing video or the IPTV screen waits
            return bool(xbmc.getCondVisibility('Player.HasMedia') or xbmc.getCondVisibility('Pvr.IsPlayingTV')
                        or xbmc.getCondVisibility('Window.IsVisible(meganexus_iptv.xml)')
                        or xbmc.getCondVisibility('Window.IsActive(TVChannels) | Window.IsActive(TVGuide) | Window.IsActive(TVRecordings)'))
        _thr_live.Thread(target=iptv_lists.run, name='MegaNexusIPTVLists',
                         args=(xbmc.Monitor(), _live_busy, _vfs_live.translatePath('special://profile/addon_data/plugin.video.meganexus/'),
                               _vfs_live.translatePath('special://profile/addon_data/pvr.iptvsimple/'), _live_setting,
                               lambda text: xbmc.log(text, xbmc.LOGINFO)), daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] IPTV live list unavailable: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.38: freed memory back to the system after MegaNexus closes or a video ends
        import threading as _thr_mem
        from resources.lib import memory_return
        _thr_mem.Thread(target=memory_return.run, name='MegaNexusMemory',
                        args=(xbmc.Monitor(), lambda: xbmcgui.Window(10000).getProperty('meganexus.frontend.running'),
                              lambda: xbmc.getCondVisibility('Player.HasVideo'), lambda text: xbmc.log(text, xbmc.LOGINFO),
                              2, lambda: xbmc.getCondVisibility('System.IdleTime(%d)' % memory_return.IDLE)),
                        daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Memory return unavailable: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.42: the diagnostics overlay's numbers (and the internet in use), every 2 s
        import threading as _thr_stats
        import xbmcvfs as _vfs_stats
        from resources.lib import stats_overlay
        _thr_stats.Thread(target=stats_overlay.run, name='MegaNexusStats',
                          args=(xbmc.Monitor(), lambda: xbmc.getCondVisibility('Skin.HasSetting(meganexus.stats)'),
                                xbmc.getInfoLabel, xbmcgui.Window(10000),
                                _vfs_stats.translatePath('special://profile/addon_data/plugin.video.meganexus/')), daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Diagnostics numbers unavailable: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.42: the network's speed for "No limit" stream choice (80 % of it)
        import threading as _thr_net
        import xbmcvfs as _vfs_net
        from resources.lib import net_speed
        _thr_net.Thread(target=net_speed.run, name='MegaNexusNetSpeed',
                        args=(xbmc.Monitor(), lambda: xbmc.getCondVisibility('Player.HasMedia'),
                              _vfs_net.translatePath('special://profile/addon_data/plugin.video.meganexus/'),
                              lambda text: xbmc.log(text, xbmc.LOGINFO)), daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Network speed unavailable: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.42: Trending now on TMDB - the HUB's (and the screensaver's) spotlight
        import threading as _thr_spot
        from resources.lib import hub_spotlight

        def _spot_showing():
            if xbmc.getCondVisibility('Player.HasVideo'):
                return False
            if xbmc.getCondVisibility('Window.IsVisible(meganexus_screensaver.xml)'):
                return True
            return bool(xbmc.getCondVisibility('Window.IsActive(Home)')
                        and not xbmcgui.Window(10000).getProperty('meganexus.frontend.running'))
        _thr_spot.Thread(target=hub_spotlight.run, name='MegaNexusSpotlight',
                         args=(xbmc.Monitor(), lambda: _setting(hub_spotlight.SETTING, 'true') != 'false', _spot_showing,
                               xbmcgui.Window(10000), lambda text: xbmc.log(text, xbmc.LOGINFO)), daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Trending spotlight unavailable: %s' % exc, xbmc.LOGWARNING)
    # 7.0.29: from the first second - a film started right after Kodi opened
    # could still play on behind Home while the rest of the service started.
    try:
        import threading as _thr_guard
        from resources.lib.foreground_guard import run as _foreground_guard
        _thr_guard.Thread(target=_foreground_guard, args=(xbmc.Monitor(),), name='MegaNexusForeground', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Foreground guard unavailable: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.29: downloads run here - nothing in the interface stops them
        from resources.lib.downloads import run as _downloads
        _thr_guard.Thread(target=_downloads, args=(xbmc.Monitor(),), name='MegaNexusDownloads', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Downloads unavailable: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.29: the player bar hides after 3 s without a key (not while its menus are open)
        from resources.lib.osd_autohide import run as _osd_autohide
        _thr_guard.Thread(target=_osd_autohide, args=(xbmc.Monitor(),), name='MegaNexusOSDHide', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Player bar auto-hide unavailable: %s' % exc, xbmc.LOGWARNING)
    try:
        from resources.lib import media_servers, local_files
        media_servers.migrate_home_rows()
        import threading as _thr_local
        _thr_local.Thread(target=local_files.run, args=(xbmc.Monitor(), lambda: xbmc.getCondVisibility('Player.HasVideo')),
                          name='MegaNexusLocalFiles', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Home rows check skipped: %s' % exc, xbmc.LOGWARNING)

    try:
        from resources.lib import helper_player_file
        helper_player_file.install_once()
    except Exception as exc:
        xbmc.log('[MegaNexus] tmdbh player auto-install failed: %s' % exc, xbmc.LOGWARNING)

    try:
        # 8.1.2: a frontend that crashed or was killed can leave its on-screen mark behind,
        # and then nothing would ever reload the skin again. At this point no window of
        # ours can be up yet, so the mark can only be stale.
        from resources.lib import screen_guard as _screen_guard
        _screen_guard.clear()
    except Exception:
        pass
    _publish_core_props('')
    _publish_badge_props()
    from resources.lib import art_cache
    art_cache.start()
    try:
        # 8.1.1: Kodi keeps pictures for the live picture path and no other. This finishes a
        # switch that was interrupted (Kodi closed, crashed, killed mid-way) and clears out
        # the other path's copies where they are there without one - a second copy of the
        # whole library otherwise sits on the disk for good. See art_switch.
        from resources.lib import art_switch as _art_switch
        threading.Thread(target=_art_switch.reconcile, args=(xbmc.Monitor(),),
                         name='MegaNexusPicturePath', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] picture-path switch not resumed: %s' % exc, xbmc.LOGWARNING)

    # The local poster proxy: one address per poster that serves the rated
    # (decorated) picture, or the plain one when the rating service is slow or
    # down - also on skins that never fall back from poster to thumb.
    _lightweight = (_setting('lightweight_mode', 'true') or 'true').strip().lower() in ('true', '1', 'yes', 'on')
    if not _lightweight:
        try:
            from resources.lib import framed_posters as _framed_posters
            _framed_posters.start()
        except Exception as exc:
            xbmc.log('[MegaNexus] poster-proxy not started: %s' % exc, xbmc.LOGWARNING)
    else:
        xbmc.log('[MegaNexus] Lightweight Mode — poster proxy skipped', xbmc.LOGINFO)
    # 7.0.44: collections imported from Nuvio before 7.0.44 get their name logos (once)
    try:
        import threading as _threading
        from resources.lib import nuvio_import as _nuvio_import
        _threading.Thread(target=_nuvio_import.fill_collection_logos, args=(xbmc.Monitor(),),
                          name='MegaNexusCollectionLogos', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] collection logos not checked: %s' % exc, xbmc.LOGWARNING)
    # 7.0.43: the local server that plays NZB sources (idle until one is played)
    try:
        # 7.0.52: on CoreELEC / Linux it moves to its own process on all cores (usenet_engine)
        from resources.lib import usenet_engine as _usenet_engine
        _usenet_engine.start()
        # 8.0: films read by the vfs.meganexus add-on hear MegaNexus' Stop at once
        from resources.lib import usenet_native as _usenet_native
        _usenet_native.start_watch()
        # 7.0.52: the quick setup's add-ons still answer (or are made again, e.g. after a restore)
        from resources.lib import aio_setup as _aio_setup
        threading.Thread(target=_aio_setup.revive_later, args=(xbmc.Monitor(),), name='MegaNexusQuickSetup',
                         daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Usenet player not started: %s' % exc, xbmc.LOGWARNING)
    try:
        # 7.0.52: Watch Party - friends, invites and the party, over public Nostr relays
        from resources.lib import party_service as _party_service
        _party_service.start()
    except Exception as exc:
        xbmc.log('[MegaNexus] Watch Party not started: %s' % exc, xbmc.LOGWARNING)

    if _lightweight:
        xbmc.log('[MegaNexus] Lightweight Mode enabled — index scheduler skipped', xbmc.LOGINFO)
    else:
        try:
            from resources.lib import catalog_index as _idx_render
            from resources.lib.catalog_index import sync as _sync_eng
            _idx_db = _idx_render.get_db()

            def _pinned_provider():
                try:
                    from resources.lib import hub as _plg
                    return _plg._section_catalogs(bucket=None) or []
                except Exception as exc:
                    xbmc.log('[MegaNexus] sync pinned-provider failed: %s' % exc,
                             xbmc.LOGWARNING)
                    return []

            toasts = {'last': 0.0}

            def _on_sync_progress(stage, info):
                """A few quiet notes while the index fills: the start, every fifth catalog
                (four seconds apart at least) and the end - none without catalogs."""
                try:
                    import xbmcgui as _xg
                    total, now = info.get('total') or 0, time.time()
                    if stage == 'start':
                        toasts['last'] = now
                        text, shown = tr('Starting library sync (%d catalogs)') % total, 2500
                    elif stage == 'catalog':
                        index = info.get('index') or 0
                        if not (index % 5 == 0 or index == total) or now - toasts['last'] < 4:
                            return
                        toasts['last'] = now
                        text, shown = '%d / %d  •  %s' % (index, total, info.get('catalog') or info.get('bucket') or ''), 2000
                    elif stage == 'done':
                        text = tr('Sync finished: %d succeeded in %.0f s') % (info.get('ok') or 0, info.get('duration') or 0)
                        shown = 3500
                    else:
                        return
                    if total > 0:
                        _xg.Dialog().notification('MegaNexus', text, _xg.NOTIFICATION_INFO, shown, sound=False)
                except Exception as exc:
                    xbmc.log('[MegaNexus] sync progress toast failed: %s' % exc, xbmc.LOGDEBUG)

            _idx_engine = _sync_eng.CatalogSync(
                _idx_db,
                pinned=_pinned_provider,
                progress=_on_sync_progress,
            )

            def _interval_hours():
                try:
                    raw = _setting('index_sync_interval_hours', '4') or '4'
                    return int(float(raw))
                except Exception:
                    return 4

            import threading as _thr
            _thr.Thread(
                target=_sync_eng.run_scheduler,
                args=(_idx_engine, xbmc.Monitor()),
                kwargs={'get_interval_hours': _interval_hours},
                name='MegaNexus-index-scheduler', daemon=True,
            ).start()
            xbmc.log('[MegaNexus] library index scheduler started', xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log('[MegaNexus] index scheduler not started: %s' % exc, xbmc.LOGWARNING)

    from resources.lib.playback_watch import PlaybackWatcher, SyncRetryLoop
    player = PlaybackWatcher()
    from resources.lib.seek_profile import restore as restore_seek
    try:restore_seek()
    except Exception:xbmc.log('[MegaNexus] Kodi seek migration will retry at next launch',xbmc.LOGWARNING)

    def _stop_owned_preview():
        """Stop a MegaNexus trailer preview / screensaver video before the box sleeps.
        A windowed video kept across suspend is a known way to come back with a
        frozen picture on Amlogic boxes; user-started playback is never touched."""
        try:
            home=xbmcgui.Window(10000);token=home.getProperty('meganexus.preview.active')
            player=xbmc.Player()
            if token and player.isPlayingVideo() and player.getPlayingItem().getProperty('meganexus.preview')==token:
                xbmc.executebuiltin('PlayerControl(Stop)')
        except Exception as exc:
            xbmc.log('[MegaNexus] sleep preview stop skipped: %s' % exc, xbmc.LOGDEBUG)

    class _MegaNexusMonitor(xbmc.Monitor):
        def onNotification(self,sender,method,data):
            # 8.1.2: the sender is 'meganexus' - Settings has sent NotifyAll(meganexus,...)
            # since the rename, and the service was still listening for the old name, so
            # Clear cache never reached the image memory. 'nuvio' stays accepted: an
            # interface from before the rename may still be the one that is installed.
            if sender in ('meganexus','nuvio') and 'artcache.' in method:art_cache.notify(method)
            elif method=='System.OnSleep':
                _stop_owned_preview()
                try:   # 7.0.58: a party never outlives the TV - the host ends it for everyone
                    from resources.lib import party_service as _party_service
                    _party_service.sleep()
                except Exception:pass
            elif method=='System.OnWake':
                try:
                    from resources.lib import party_service as _party_service
                    _party_service.wake()
                except Exception:pass
        def onSettingsChanged(self):
            from resources.lib import settings_snapshot
            settings_snapshot.invalidate()
            try:                    # 7.0.52: Watch Party turned on / off on its screen
                from resources.lib import party_service as _party_service
                _party_service.follow_setting()
            except Exception:
                pass

    monitor = _MegaNexusMonitor()

    SYNC_DIRTY_PROP = 'meganexus.sync_dirty'

    def _cloud_sync_loop(mon):
        """Infrequent, idle-only configuration/library work; progress has its own loop."""
        from resources.lib.meganexus import cloud_sync as sync
        if mon.waitForAbort(30):return
        next_run = time.monotonic()
        while not mon.abortRequested():
            try:interval=max(0, int(float(_setting('cloud_sync_interval_min', '30') or 30)))
            except (ValueError, TypeError):interval=30
            if interval and time.monotonic()>=next_run and not _interactive_busy() and sync.active_targets():
                if _SYNC_CYCLE_LOCK.acquire(False):
                    try:
                        sections=sync._cloud_sections('nuvio')
                        # Home collection replacements always go through explicit validation/import.
                        sections.update(progress=False, collections=False)
                        if sections.get('addons') or sections.get('library'):
                            sync.sync_round(targets=['nuvio'], sections=sections)
                    except Exception:
                        pass
                    finally:
                        next_run=time.monotonic()+max(300, interval*60)
                        _SYNC_CYCLE_LOCK.release()
            if mon.waitForAbort(15):return


    def _bytecode_warm_job():
        try:
            if monitor.waitForAbort(20):
                return
            from pyc_warmup import warm
            addon_root = os.path.dirname(os.path.abspath(__file__))
            checked, compiled = warm(addon_root, monitor=monitor)
            if compiled:
                xbmc.log('[MegaNexus] bytecode warm: compiled %d/%d files'
                         % (compiled, checked), xbmc.LOGDEBUG)
        except Exception as exc:
            xbmc.log('[MegaNexus] bytecode warm skipped: %s' % exc, xbmc.LOGDEBUG)

    def _update_loop(mon):
        """GitHub release check every 12 h; installs when automatic updates are ON."""
        from resources.lib import updater
        updater.boot_token()  # this Kodi session; a pending restart from an older one is cleared
        if mon.waitForAbort(90):return
        while not mon.abortRequested():
            try:
                import xbmcaddon as _xa
                _addon = _xa.Addon('plugin.video.meganexus')
                if updater.due(_addon) and not _interactive_busy():
                    status, info = updater.check_and_update(_addon)
                    if status == 'installed':
                        # Ask "restart now?" only when no video plays and MegaNexus is
                        # closed; "Later" reminds again at the next MegaNexus entry.
                        if updater.prompt_when_safe(_addon, mon):return
                    elif status == 'available':
                        xbmcgui.Dialog().notification('MegaNexus', '%s is available: Settings > Maintenance.' % info['version'], time=8000)
            except Exception as exc:
                xbmc.log('[MegaNexus] update check skipped: %s' % exc, xbmc.LOGDEBUG)
            if mon.waitForAbort(600):return

    def _component_sync(mon):
        # 6.0.23: no manual "Install or repair" after an update.
        try:
            from resources.lib.bundle_installer import auto_install
            auto_install(mon, busy=_interactive_busy)
        except Exception as exc:
            xbmc.log('[MegaNexus] automatic component install skipped: %s' % exc, xbmc.LOGWARNING)
        # 6.0.35: a preview's refresh-rate pause left behind by a crash.
        try:
            from resources.lib.refresh_guard import restore
            restore(force=True)
        except Exception as exc:
            xbmc.log('[MegaNexus] refresh-rate restore skipped: %s' % exc, xbmc.LOGWARNING)
        # 6.0.33: Kodi started without the MegaNexus skin the user chose.
        try:
            from resources.lib.skin_activation import restore_on_start
            restore_on_start(mon, busy=_interactive_busy)
        except Exception as exc:
            xbmc.log('[MegaNexus] skin check skipped: %s' % exc, xbmc.LOGWARNING)
        # 7.0: after a move from the previous IDs, retire them and ask to restart.
        try:
            from resources.lib.rename_migration import finish_in_service
            finish_in_service(mon, busy=_interactive_busy)
        except Exception as exc:
            xbmc.log('[MegaNexus] retiring the previous add-ons skipped: %s' % exc, xbmc.LOGWARNING)

    def _refresh_sweep(mon):
        # 7.0.50: a refresh-rate hold whose process died never leaves the setting off
        from resources.lib import refresh_guard
        while not mon.waitForAbort(refresh_guard.RENEW):
            try:
                refresh_guard.sweep()
            except Exception as exc:
                xbmc.log('[MegaNexus] refresh-rate check skipped: %s' % exc, xbmc.LOGDEBUG)

    try:
        import threading as _thr_upd
        _thr_upd.Thread(target=_component_sync, args=(monitor,), name='MegaNexusComponents', daemon=True).start()
        _thr_upd.Thread(target=_refresh_sweep, args=(monitor,), name='MegaNexusRefreshSweep', daemon=True).start()
        # 8.1.3: Sport reminders - "javi mi kad krene"
        from resources.lib.sport_reminders import run as _sport_reminders
        _thr_upd.Thread(target=_sport_reminders, args=(monitor,), name='MegaNexusSportReminders', daemon=True).start()
        _thr_upd.Thread(target=_update_loop, args=(monitor,), name='MegaNexusUpdates', daemon=True).start()
        # 6.0.36: add-on manifests (new catalogs) are re-read regularly.
        from resources.lib.manifest_refresh import service_loop as _manifest_loop
        _thr_upd.Thread(target=_manifest_loop, args=(monitor,), kwargs={'busy': _interactive_busy},
                        name='MegaNexusManifests', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] update checks not started: %s' % exc, xbmc.LOGWARNING)

    try:
        # 7.0.45: profiles - a switch cut short is finished before any sync starts; then
        # switches are made here, holding the sync lock (no sync runs during one)
        from resources.lib import user_profiles as _profiles
        with _SYNC_CYCLE_LOCK:
            _profiles.finish_cut_short()
        import threading as _thr_profiles
        _thr_profiles.Thread(target=_profiles.serve, args=(monitor, _SYNC_CYCLE_LOCK), name='MegaNexusProfiles', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] profiles not started: %s' % exc, xbmc.LOGWARNING)

    try:
        import threading as _thr
        _thr.Thread(target=_background_sync_loop, args=(monitor,), name='MegaNexusCoreLoop', daemon=True).start()
        _thr.Thread(target=_cloud_sync_loop, args=(monitor,), name='MegaNexusCloudLoop', daemon=True).start()

        from resources.lib.progress_sync import run as _progress_sync_run
        _thr.Thread(target=_progress_sync_run, args=(monitor, _SYNC_CYCLE_LOCK), name='MegaNexusProgressSync', daemon=True).start()
        _thr.Thread(target=_bytecode_warm_job, name='MegaNexusBytecodeWarm', daemon=True).start()
        from resources.lib.skip_service import run as _skip_run
        _thr.Thread(target=_skip_run, args=(player, monitor), name='MegaNexusSkip', daemon=True).start()
        from resources.lib import interface_colors
        interface_colors.publish()
        _thr.Thread(target=interface_colors.run, name='MegaNexusBackgroundColors', daemon=True).start()
        from resources.lib.spotnet import run as _spotnet_run   # 7.0.45: the Spotnet index kept up to date
        _thr.Thread(target=_spotnet_run, args=(monitor,), name='MegaNexusSpotnet', daemon=True).start()
        from resources.lib.saver_lead import run as _saver_lead_run   # 7.0.32: the screensaver's black a second early
        _thr.Thread(target=_saver_lead_run, args=(monitor,), name='MegaNexusSaverLead', daemon=True).start()
    except Exception as exc:
        xbmc.log('[MegaNexus] could not spawn core sync thread: %s' % exc, xbmc.LOGWARNING)
    try:
        from resources.lib.presentation_settings import sync as sync_appearance
        sync_appearance()
    except Exception:
        xbmc.log('[MegaNexus] Appearance preference will be restored when the interface opens.', xbmc.LOGWARNING)
    try:
        SyncRetryLoop(player).run()
    finally:
        art_cache.stop()
        try:
            from resources.lib import script_exit
            script_exit.stop()   # 7.0.5: idle workers kept Kodi from closing
        except Exception:
            pass
        try:
            from resources.lib import framed_posters as _framed_posters
            _framed_posters.stop()
        except Exception:
            pass
        try:
            from resources.lib import usenet_engine as _usenet_engine
            _usenet_engine.stop()
        except Exception:
            pass
        try:
            from resources.lib import party_service as _party_service
            _party_service.stop()
        except Exception:
            pass
        # 7.0.29: which threads are still busy as Kodi closes (Kodi waited on
        # them after "Unloaded skin" and hung) - named in the log to fix them.
        try:
            import threading as _thr_exit
            busy = [t.name for t in _thr_exit.enumerate() if t is not _thr_exit.current_thread() and t.is_alive()]
            if busy:
                xbmc.log('[MegaNexus] Still running at exit: %s' % ', '.join(sorted(busy)), xbmc.LOGINFO)
        except Exception:
            pass
