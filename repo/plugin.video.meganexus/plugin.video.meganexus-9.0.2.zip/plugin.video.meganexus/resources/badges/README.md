MegaNexus starter badges (7.0.29): the set every user has until they import their own.

`starter.json` is a Nuvio badge pack: the Elite badge pictures of a universal Nuvio pack,
referenced by URL (Kodi downloads and caches them like any imported badge; nothing is
bundled), with plain rules for what a source name says (resolution, source, HDR, codec,
audio, channels, language flags). Raise `version` when the set changes: devices still on
the starter set take the new one; an imported set is never replaced.

`sets.json` and `sets/<id>.json` (7.0.42, `review/make_badge_sets.py`): ready sets to choose
from. Each is a public Nuvio badge pack rebuilt with MegaNexus rules; its pictures stay
where their authors host them (linked, never bundled) and each set names its source:
Nebula - github.com/danielsdian/ColorfulAndConcise (MIT), Quasar - github.com/HazedNapkin/NuvioBadges,
Comet - github.com/Maitiaxixon/Badge_Titou, Stardust - github.com/IaemTary/nuvio-badges,
Galaxy - github.com/VincentGrimond/Badges-Nuvio.
