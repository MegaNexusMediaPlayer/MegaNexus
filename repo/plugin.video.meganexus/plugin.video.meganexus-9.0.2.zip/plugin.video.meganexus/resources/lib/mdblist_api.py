# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
# Endpoint and field shapes checked against the MDBList client of TMDb Helper
# (jurialmunkey/plugin.video.themoviedb.helper).
import json
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    try:
        from settings_snapshot import cached_addon as _cached_addon
    except Exception:
        _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')
API = 'https://api.mdblist.com'
_CACHE = {}
_CACHE_TTL = 300
_CACHE_BYTES = 8 * 1024 * 1024     # 7.0.37: list pages kept in memory, by their JSON size
_CACHE_USED = [0]


def _remember(key, data, has_more, size):
    """Keep an answer for _CACHE_TTL: expired and oldest answers go first, so
    the cache never grows past _CACHE_BYTES (it only checked the age before)."""
    now = time.time()
    old = _CACHE.pop(key, None)
    if old is not None:
        _CACHE_USED[0] -= old[3]
    for stale in [k for k, v in _CACHE.items() if now - v[0] > _CACHE_TTL]:
        _CACHE_USED[0] -= _CACHE.pop(stale)[3]
    if size > _CACHE_BYTES // 2:
        return
    while _CACHE and _CACHE_USED[0] + size > _CACHE_BYTES:
        _CACHE_USED[0] -= _CACHE.pop(next(iter(_CACHE)))[3]
    _CACHE[key] = (now, data, has_more, size)
    _CACHE_USED[0] += size


class MdblistFailure(Exception):
    """A failed MDBList call: a message for the user, the HTTP status, a short code, details."""

    def __init__(self, message, status=0, code='', details=''):
        super().__init__(str(message or 'MDBList request failed'))
        self.status, self.code, self.details = int(status or 0), str(code or ''), str(details or '')


STATUS_TEXT = {401: 'The MDBList API key is invalid or expired.', 403: 'MDBList denied access to this account.',
               429: 'MDBList rate limit reached. Wait a moment and refresh.'}
SHOW_WORDS = ('show', 'shows', 'series', 'tv', 'tvshow', 'anime')
FILM_WORDS = ('movie', 'movies')


def _error_message(status=0, details=''):
    status, details = int(status or 0), str(details or '').strip()
    if status in STATUS_TEXT:
        return STATUS_TEXT[status]
    if status >= 500:
        return 'MDBList is temporarily unavailable (HTTP %d).' % status
    if status:
        return 'MDBList request failed (HTTP %d)%s' % (status, ': %s' % details[:160] if details else '.')
    return details or 'Could not connect to MDBList.'


def _answer_error(body):
    """MDBList's own message from an error body (its message / error / detail field)."""
    body = str(body or '').strip()
    try:
        data = json.loads(body) if body else None
    except Exception:
        data = None
    if isinstance(data, dict):
        return str(data.get('message') or data.get('error') or data.get('detail') or '')[:240]
    return body[:240]


def clear_cache():
    _CACHE.clear()
    _CACHE_USED[0] = 0


def _setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


def _headers():
    return {'Accept': 'application/json', 'User-Agent': 'MegaNexus/%s (Kodi)' % (ADDON.getAddonInfo('version') or '8.1.0')}


def _answer(response, address):
    """(data, has_more) of an answer; the paging headers ride along in _meganexus_meta."""
    _note_quota(response.headers)
    body = response.read().decode('utf-8', 'ignore')
    try:
        data = json.loads(body) if body else {}
    except Exception as exc:
        raise MdblistFailure('MDBList returned invalid JSON.', status=getattr(response, 'status', 0), code='invalid_json',
                           details=str(exc))
    more = str(response.headers.get('X-Has-More') or '').strip().lower() == 'true'
    following = str(response.headers.get('X-Next-Cursor') or '').strip()
    if isinstance(data, dict) and (following or more):
        data = dict(data, _meganexus_meta={'next_cursor': following, 'has_more': more})
    _remember(address, data, more, len(body))
    return data, more


def _request(path, params=None, timeout=20):
    """(data, has_more) of a GET, the user's key added; kept _CACHE_TTL seconds by address."""
    params = dict(params or {})
    if api_key() and 'apikey' not in params:
        params['apikey'] = api_key()
    address = API + path + ('?' + urllib.parse.urlencode(params) if params else '')
    kept = _CACHE.get(address)
    if kept and time.time() - kept[0] <= _CACHE_TTL:
        return kept[1], kept[2]
    try:
        with urllib.request.urlopen(urllib.request.Request(address, headers=_headers(), method='GET'),
                                    timeout=timeout) as response:
            return _answer(response, address)
    except MdblistFailure:
        raise
    except urllib.error.HTTPError as exc:
        try:
            detail = _answer_error(exc.read().decode('utf-8', 'ignore'))
        except Exception:
            detail = ''
        raise MdblistFailure(_error_message(exc.code, detail), status=exc.code, code='http_error', details=detail)
    except Exception as exc:
        detail = str(getattr(exc, 'reason', '') or exc) if isinstance(exc, urllib.error.URLError) else str(exc)
        raise MdblistFailure(_error_message(0, 'Could not connect to MDBList: %s' % detail), code='network_error',
                           details=detail)


def api_key():
    return (_setting('mdblist_api_key', '') or '').strip()


def configured():
    return bool(api_key())


def fetch_user_info(strict=False):
    """The account (/user): profile and limits; {} without a key or when refused (unless strict)."""
    if not configured():
        return {}
    try:
        data, _more = _request('/user')
    except Exception:
        if strict:
            raise
        return {}
    return data if isinstance(data, dict) else {}


def _lists_in(value):
    """The list rows of a /lists answer, wherever this API version put them."""
    if isinstance(value, list):
        return value
    for key in ('lists', 'results', 'data') if isinstance(value, dict) else ():
        inner = value.get(key)
        if isinstance(inner, list):
            return inner
        if isinstance(inner, dict) and isinstance(inner.get('lists') or inner.get('results'), list):
            return inner.get('lists') or inner.get('results')
    return []


def _account_names():
    account = fetch_user_info(strict=True) or {}
    account = account.get('user') if isinstance(account.get('user'), dict) else account
    names = []
    for key in ('id', 'user_id', 'userid', 'username', 'user_name', 'name'):
        value = str((account or {}).get(key) or '').strip()
        if value and value not in names:
            names.append(value)
    return names[:2]


def own_lists():
    """The user's lists; when /lists/user answers none, asked again by the account's id / name."""
    if not configured():
        return []
    rows = _lists_in(_request('/lists/user', params={'sort': 'ranked'})[0])
    for name in [] if rows else _account_names():
        try:
            rows = _lists_in(_request('/lists/user/%s' % urllib.parse.quote(name), params={'sort': 'ranked'})[0])
        except MdblistFailure as exc:
            if exc.status in (400, 404, 405):
                continue
            raise
        if rows:
            break
    lists = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        try:
            count = int(row.get('items') or row.get('item_count') or row.get('count') or 0)
        except Exception:
            count = 0
        lists.append({'id': str(row.get('id') or ''), 'name': row.get('name') or row.get('slug') or '',
                      'slug': str(row.get('slug') or ''), 'user_name': str(row.get('user_name') or row.get('username') or ''),
                      'items': count, 'mediatype': str(row.get('mediatype') or ''),
                      'description': row.get('description') or '',
                      'private': bool(row.get('private') or row.get('is_private')),
                      'dynamic': bool(row.get('dynamic') or row.get('is_dynamic')),
                      'updated_at': str(row.get('last_updated_at') or row.get('updated_at') or row.get('updated') or '')})
    return lists


def _cursor_after(value):
    """The offset of our 'offset:N' cursor; None for MDBList's own cursors."""
    value = str(value or '').strip()
    if value.startswith('offset:'):
        try:
            return max(0, int(value.split(':', 1)[1]))
        except Exception:
            pass
    return None


def _with_page_cursor(params, cursor):
    offset = _cursor_after(cursor)
    if offset is not None:
        params['offset'] = offset
    elif cursor:
        params['cursor'] = cursor


def _yes(value):
    return value.strip().lower() in ('1', 'true', 'yes', 'on') if isinstance(value, str) else bool(value)


def _typed(row, media_filter):
    """A list item marked movie / show (by its own type, else by the filter asked for)."""
    item = dict(row)
    kind = str(item.get('_type') or item.get('mediatype') or item.get('media_type') or item.get('type') or '').lower()
    if kind in FILM_WORDS:
        item['_type'] = 'movie'
    elif kind in SHOW_WORDS:
        item['_type'] = 'show'
    else:
        item.setdefault('_type', 'movie' if media_filter in FILM_WORDS else 'show')
    return item


def _lift_ids(item):
    """imdb_id / tvdb_id / id (TMDB) taken out of a nested ids object (or list of them)."""
    nested = item.get('ids')
    found = [nested] if isinstance(nested, dict) else [one for one in nested if isinstance(one, dict)] \
        if isinstance(nested, list) else []
    for ids in found:
        for ours, theirs in (('imdb_id', 'imdb'), ('tvdb_id', 'tvdb'), ('id', 'tmdb')):
            if not item.get(ours) and ids.get(theirs):
                item[ours] = ids[theirs]
    if found and not isinstance(nested, dict):
        item.pop('ids', None)


def _items_of_answer(data, has_more, mf, current_cursor='', limit=100):
    """(items, next cursor) of a list page. MDBList's own cursor when it gives one, else our
    'offset:N' while more remain (by its has_more flags or its total)."""
    rows, following, paging = [], '', {}
    if isinstance(data, dict):
        paging = data.get('pagination') if isinstance(data.get('pagination'), dict) else {}
        meta = data.get('_meganexus_meta') if isinstance(data.get('_meganexus_meta'), dict) else {}
        following = str(paging.get('next_cursor') or data.get('next_cursor') or meta.get('next_cursor') or '').strip()
        has_more = any(_yes(flag) for flag in (has_more, paging.get('has_more'), meta.get('has_more')))
        for key, kind in (('movies', 'movie'), ('shows', 'show')):
            rows += [dict(row, _type=row.get('_type', kind)) for row in data.get(key) or [] if isinstance(row, dict)]
    elif isinstance(data, list):
        rows = [_typed(row, mf) for row in data if isinstance(row, dict)]
    count = len(rows)
    if not has_more and paging:
        try:
            total = int(paging.get('total') or paging.get('total_items') or 0)
            has_more = bool(total and int(paging.get('offset') or _cursor_after(current_cursor) or 0) + count < total)
        except Exception:
            pass
    if not following and has_more:
        start = _cursor_after(current_cursor)
        if start is None:
            try:
                start = int(paging.get('offset') or 0) if isinstance(data, dict) else 0
            except Exception:
                start = 0
        following = 'offset:%d' % (start + (count or max(1, int(limit or 100))))
    for item in rows:
        _lift_ids(item)
    mf = str(mf or 'auto').strip().lower()
    if mf in FILM_WORDS:
        rows = [row for row in rows if row.get('_type') == 'movie']
    elif mf in SHOW_WORDS:
        rows = [row for row in rows if row.get('_type') == 'show']
    if not rows and data:
        _log_empty(data, mf)
    return rows, following


def _log_empty(data, mf):
    """Why a non-empty answer gave no items: its shape and the first row's keys."""
    try:
        shape = list(data.keys())[:6] if isinstance(data, dict) else 'list[%d]' % len(data)
        first = next((data[key] for key in ('movies', 'shows') if data.get(key)), data) if isinstance(data, dict) else data
        keys = list(first[0].keys())[:10] if isinstance(first, list) and first and isinstance(first[0], dict) else '-'
        xbmc.log('[MegaNexus] MDBList items normalized to 0 rows (mf=%s) shape=%r first_row_keys=%r' % (mf, shape, keys),
                 xbmc.LOGWARNING)
    except Exception:
        pass


def _items_path_suffix(mf):
    if mf in FILM_WORDS:
        return '/items/movie', False
    if mf in ('show', 'shows', 'series', 'tv', 'anime'):
        return '/items/show', False
    return '/items', False


def items_by_id(list_id, media_filter='auto', cursor='', limit=100):
    """(items, next cursor) of one list page; a bare number counts as an offset."""
    list_id = str(list_id or '').strip()
    if not list_id:
        return [], ''
    offset = _cursor_after(cursor)
    if offset is None and str(cursor or '').isdigit():
        offset = int(cursor)
    params = dict({'limit': int(limit or 100)}, **({'offset': offset} if offset is not None else {}))
    data, more = _request('/lists/%s/items' % urllib.parse.quote(list_id), params=params)
    return _items_of_answer(data, more, str(media_filter or 'auto').strip().lower(), current_cursor=cursor,
                                     limit=limit)


def watchlist_rows(media_filter='auto', cursor='', limit=100):
    """(items, next cursor) of the watchlist."""
    if not configured():
        return [], ''
    mf = str(media_filter or 'auto').strip().lower()
    suffix, unified = _items_path_suffix(mf)
    params = {'limit': int(limit or 100)}
    _with_page_cursor(params, cursor)
    if unified:
        params['unified'] = 'true'
    data, more = _request('/watchlist%s' % suffix, params=params)
    return _items_of_answer(data, more, mf, current_cursor=cursor, limit=limit)


_RATINGS_CACHE = {}
_RATINGS_TTL = 24 * 3600           # 7.0.30: a day, also on disk (ratings move slowly)
_RATINGS_FILE = 'mdblist-ratings.json'
_RATINGS_LOADED = []
BATCH_SIZE = 200                   # MDBList's Media Info Batch takes up to 200 ids
PRELOAD_SHARE = .6                 # the opening screen may use 60 % of the day's requests ...
_QUOTA = {}                        # ... the rest stays for titles opened while browsing

_RATING_SOURCE_MAP = {
    'imdb': 'imdb',
    'metacritic': 'metacritic',
    'trakt': 'trakt',
    'tmdb': 'tmdb',                 # 7.0.29: /100, as Nuvio reads it
    'tomatoes': 'rt_crit',
    'tomatoesaudience': 'rt_aud',
    'popcorn': 'rt_aud',            # MDBList's name for the RT audience score
    'audience': 'rt_aud',
    'letterboxd': 'letterboxd',
    'myanimelist': 'mal',
    'mal': 'mal',
    'score_average': 'mdblist',
}


def _ratings_kind(media_type):
    return 'show' if str(media_type or '').lower() in ('series', 'show', 'tv', 'anime', 'tvshow') else 'movie'


def _imdb(value):
    value = str(value or '').strip()
    return value if not value or value.startswith('tt') else 'tt' + value


def _ratings_cache_keys(kind, imdb_id='', tmdb_id=''):
    """Where a title's ratings are kept: by TMDB id and by IMDb id."""
    tmdb_id, imdb_id = str(tmdb_id or '').strip(), _imdb(imdb_id)
    return (['%s:tmdb:%s' % (kind, tmdb_id)] if tmdb_id else []) + (['%s:%s' % (kind, imdb_id)] if imdb_id else [])


def _ratings_path():
    import os
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), _RATINGS_FILE)


def _read_ratings_file():
    try:
        with open(_ratings_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _load_ratings():
    """7.0.30: ratings kept on disk for a day - shared by the interface and the
    service, and there again after a restart."""
    if _RATINGS_LOADED:
        return
    _RATINGS_LOADED.append(True)
    now = time.time()
    for key, (stamp, values) in _read_ratings_file().items():
        if now - stamp <= _RATINGS_TTL and stamp > _RATINGS_CACHE.get(key, (0,))[0]:
            _RATINGS_CACHE[key] = (stamp, values)


def clear_ratings():
    """Forget every stored rating (memory and the day's file)."""
    import os
    _RATINGS_CACHE.clear()
    _RATINGS_LOADED[:] = [True]
    try:
        os.remove(_ratings_path())
    except OSError:
        pass


def _save_ratings():
    import os
    now = time.time()
    merged = {key: tuple(value) for key, value in _read_ratings_file().items()}
    for key, value in list(_RATINGS_CACHE.items()):
        if value[1] and value[0] > merged.get(key, (0,))[0]:
            merged[key] = value
    merged = {key: list(value) for key, value in merged.items() if now - value[0] <= _RATINGS_TTL}
    path = _ratings_path()
    try:
        with open(path + '.part', 'w', encoding='utf-8') as handle:
            json.dump(merged, handle, separators=(',', ':'))
        os.replace(path + '.part', path)
    except OSError:
        pass


def cached_ratings(imdb_id='', media_type='movie', tmdb_id=''):
    """A title's ratings when known today (memory, then the day's file) - never a request."""
    _load_ratings()
    for key in _ratings_cache_keys(_ratings_kind(media_type), imdb_id=imdb_id, tmdb_id=tmdb_id):
        kept = _RATINGS_CACHE.get(key)
        if kept and time.time() - kept[0] <= _RATINGS_TTL:
            return dict(kept[1])
    return {}


# services whose MDBList value is shown as it comes (0-100); Trakt's is shown out of 10
PERCENT_SERVICES = ('rt_crit', 'rt_aud', 'metacritic', 'mdblist', 'tmdb')


def _parse_ratings(data):
    """One title's MDBList answer -> {service: shown value}; Rotten Tomatoes' certified marks
    from its keywords; MDBList's own score last."""
    data = data or {}
    shown = {}
    for row in data.get('ratings') or []:
        service, value = _RATING_SOURCE_MAP.get(str(row.get('source') or '').strip().lower()), row.get('value')
        if not service or value in (None, '', 0) or service in shown:
            continue
        number = float(value)
        shown[service] = str(int(number)) if service in PERCENT_SERVICES else \
            '%.1f' % (number / 10.0 if service == 'trakt' else number)
    words = set(str(word.get('name') if isinstance(word, dict) else word).rsplit('.', 1)[-1].strip().lower()
                for word in data.get('keywords') or []
                if isinstance(word.get('name') if isinstance(word, dict) else word, str))
    for service, word in (('rt_crit', 'certified-fresh'), ('rt_aud', 'certified-hot')):
        if shown.get(service) and word in words:
            shown[service + '_certified'] = '1'
    score = next((data.get(key) for key in ('score', 'score_average') if data.get(key) not in (None, '', 0)), None)
    if score is not None:
        shown['mdblist'] = str(int(float(score)))
    return shown


def ratings_of(imdb_id='', media_type='movie', timeout=6, tmdb_id=''):
    """A title's ratings: kept ones, else asked by TMDB id (as TMDb Helper does), else IMDb id."""
    kind = _ratings_kind(media_type)
    tmdb_id, imdb_id = str(tmdb_id or '').strip(), _imdb(imdb_id)
    if not configured() or not (tmdb_id or imdb_id):
        return {}
    kept = cached_ratings(imdb_id=imdb_id, media_type=media_type, tmdb_id=tmdb_id)
    if kept:
        return kept
    try:
        data, _more = _request('/tmdb/%s/%s' % (kind, tmdb_id) if tmdb_id else '/imdb/%s/%s' % (kind, imdb_id),
                               params={'append_to_response': 'keyword'}, timeout=timeout)
        found = _parse_ratings(data)
    except Exception as exc:
        xbmc.log('[MegaNexus] mdblist ratings_of(%s/%s) failed: %s' % (tmdb_id or imdb_id, kind, exc), xbmc.LOGDEBUG)
        found = {}
    stamp = (time.time(), dict(found))
    for key in _ratings_cache_keys(kind, imdb_id=imdb_id, tmdb_id=tmdb_id):
        _RATINGS_CACHE[key] = stamp
    if found:
        _save_ratings()
    return found


def ratings_later(imdb_id='', media_type='movie', tmdb_id=''):
    """Ask for a title's ratings in the background (the source window shows them when ready)."""
    if not configured() or not (str(tmdb_id or '').strip() or str(imdb_id or '').strip()):
        return

    def ask():
        try:
            ratings_of(imdb_id=imdb_id, media_type=media_type, tmdb_id=tmdb_id)
        except Exception:
            pass
    try:
        from .side_jobs import maybe_run
        maybe_run(ask, key='mdblist-rating:%s:%s:%s' % (media_type or '', tmdb_id or '', imdb_id or ''))
    except Exception as exc:
        xbmc.log('[MegaNexus] mdblist warm task failed: %s' % exc, xbmc.LOGDEBUG)


def _post(path, payload, timeout=20):
    """POST with the key; notes the day's request quota from MDBList's headers."""
    api_key_value = api_key()
    url = API + path + ('?' + urllib.parse.urlencode({'apikey': api_key_value}) if api_key_value else '')
    headers = dict(_headers(), **{'Content-Type': 'application/json'})
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            _note_quota(resp.headers)
            body = resp.read().decode('utf-8', 'ignore')
            return json.loads(body) if body else []
    except urllib.error.HTTPError as exc:
        _note_quota(exc.headers)
        raise MdblistFailure(_error_message(exc.code), status=exc.code, code='http_error')


def _note_quota(headers):
    try:
        limit = int(headers.get('X-RateLimit-Limit'))
        left = int(headers.get('X-RateLimit-Remaining'))
    except (TypeError, ValueError, AttributeError):
        return
    _QUOTA.update(limit=limit, left=left)


def preload_allowed():
    """The opening screen may ask while more than 40 % of the day's requests are left."""
    if not _QUOTA:
        return True
    return _QUOTA['left'] > _QUOTA['limit'] * (1 - PRELOAD_SHARE)


def preload_ratings(titles, stopped=lambda: False):
    """7.0.30: ratings of many titles at once (Media Info Batch, 200 per request)
    behind the opening screen, so every card shows its ratings at once. Titles
    already known today are skipped; it stops at PRELOAD_SHARE of the day's
    requests. ``titles``: (media type, imdb id, tmdb id). Returns titles stored."""
    if not configured():
        return 0
    groups = {}
    for media_type, imdb_id, tmdb_id in titles:
        kind = _ratings_kind(media_type)
        imdb_id, tmdb_id = str(imdb_id or '').strip(), str(tmdb_id or '').strip()
        if imdb_id and not imdb_id.startswith('tt'):
            imdb_id = ''
        if not (imdb_id or tmdb_id) or cached_ratings(imdb_id=imdb_id, media_type=kind, tmdb_id=tmdb_id):
            continue
        provider, value = ('imdb', imdb_id) if imdb_id else ('tmdb', tmdb_id)
        groups.setdefault((kind, provider), [])
        if value not in groups[(kind, provider)]:
            groups[(kind, provider)].append(value)
    stored = 0
    for (kind, provider), ids in groups.items():
        for start in range(0, len(ids), BATCH_SIZE):
            if stopped() or not preload_allowed():
                if stored:
                    _save_ratings()
                return stored
            try:
                answer = _post('/%s/%s' % (provider, kind), {'ids': ids[start:start + BATCH_SIZE], 'append_to_response': ['keyword']})
            except Exception as exc:
                xbmc.log('[MegaNexus] mdblist ratings preload stopped: %s' % exc, xbmc.LOGINFO)
                if stored:
                    _save_ratings()
                return stored
            now = time.time()
            for item in answer if isinstance(answer, list) else []:
                if not isinstance(item, dict):
                    continue
                try:
                    out = _parse_ratings(item)
                except (TypeError, ValueError):
                    continue
                found = item.get('ids') or {}
                if not out:
                    continue
                for cache_key in _ratings_cache_keys(kind, imdb_id=found.get('imdb') or '', tmdb_id=found.get('tmdb') or ''):
                    _RATINGS_CACHE[cache_key] = (now, dict(out))
                stored += 1
    if stored:
        _save_ratings()
    return stored


_METAHUB_POSTER = 'https://images.metahub.space/poster/large/%s/img'


def _first(row, ids, *names):
    return str(next((source.get(name) for name in names for source in (ids, row) if source.get(name)), '') or '').strip()


def _poster(row, imdb, tmdb, media_type):
    """A poster for a watchlist row, and never nothing.

    8.1.2: this used MetaHub, which is addressed by IMDb id, and fell back to '' for a
    row that has only a TMDB id - so those cards were blank in Library ("Library nema
    neki postera"). card_art.usable_poster is what every other card goes through: it
    looks in the Artwork provider's own store (which knows TMDB ids), then the row's own
    picture, then MetaHub, and failing all of that the placeholder - so a card always has
    something to draw.
    """
    own = str(row.get('poster') or row.get('poster_url') or '').strip()
    try:
        from . import card_art
        meta = {'poster': own, 'title': row.get('title') or '',
                'year': row.get('release_year') or row.get('year') or '',
                'imdb_id': imdb or '', 'tmdb_id': tmdb or ''}
        found = str(card_art.usable_poster(meta, media_type) or '').strip()
        if found:
            return found
    except Exception as exc:
        xbmc.log('[MegaNexus] mdblist poster lookup skipped: %s' % type(exc).__name__, xbmc.LOGDEBUG)
    return own or (_METAHUB_POSTER % imdb if imdb else '')


def watchlist_copy_rows(limit=200):
    """The watchlist as Library mirror rows (IMDb id first; MetaHub poster when it has none)."""
    try:
        items, _cursor = watchlist_rows(limit=limit)
    except Exception as exc:
        xbmc.log('[MegaNexus] mdblist watchlist mirror failed: %s' % exc, xbmc.LOGDEBUG)
        return []
    rows = []
    for row in items or []:
        ids = row.get('ids') or {}
        imdb = _imdb(_first({}, ids, 'imdb', 'imdb_id') or str(row.get('imdb_id') or row.get('imdb') or '').strip())
        tmdb = _first({}, ids, 'tmdb', 'tmdb_id') or str(row.get('tmdb_id') or row.get('tmdb') or row.get('id') or '').strip()
        item = imdb or ('tmdb:' + tmdb if tmdb else '')
        if item:
            media_type = 'series' if str(row.get('_type') or '') == 'show' else 'movie'
            rows.append({'media_type': media_type,
                         'canonical_id': item, 'title': row.get('title') or '',
                         'poster': _poster(row, imdb, tmdb, media_type),
                         'background': row.get('backdrop') or row.get('background') or '',
                         'clearlogo': row.get('clearlogo') or '', 'year': row.get('release_year') or row.get('year') or 0,
                         'plot': row.get('overview') or ''})
    return rows
