# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""AI subtitles (8.1.3): the film's own subtitles, translated by Gemini into the language
chosen for subtitles - in the background, then put on.

Where the lines come from, best first:
1. the video's own text subtitles (mkv_subtitle_text) - made for exactly this release, so
   the translation needs no syncing;
2. the subtitle on screen, when it is not in the wanted language;
3. a subtitle found online (English first), synced afterwards like any other.

How it is translated (what the subtitle tools on GitHub do, and more): 100 lines a
request so a film takes a handful of requests (gemini_api paces them for the free tier);
the title, its year and its synopsis go with every request, and so do the last lines
already translated, so names, the way people address each other and running jokes stay
the same from one request to the next. The answer is JSON with each line's number; a
request that comes back with lines missing is split in two and asked again. A finished
translation is kept for the film and used again without asking Gemini.
"""
import hashlib
import json
import os
import re

from . import gemini_api
from .meganexus.paths import profile_path

BATCH = 60               # 8.1.3: shorter answers come back sooner (was 100)
MAX_CHARS = 3600
CONTEXT = 8
SPLITS = 3
FOLDER = 'ai_subtitles'
SCHEMA = {'type': 'ARRAY', 'items': {'type': 'OBJECT', 'properties': {'i': {'type': 'INTEGER'}, 't': {'type': 'STRING'}},
                                     'required': ['i', 't']}}
SYSTEM = (
    "You translate film and TV subtitles. Write the way professional subtitles in the target language read: "
    "natural spoken language, the tone, slang and level of swearing of the original, short enough to read. "
    "Use the synopsis and the earlier lines to get names, gender, who speaks to whom (formal or informal) and "
    "recurring terms right, and keep them the same throughout. Keep names of people and places as they are. "
    "Translate idioms by meaning, not word for word. Keep each line's line breaks (\\n) and tags such as <i> "
    "and </i>. Translate sound descriptions in brackets too. A subtitle has at most 2 lines of at most 42 "
    "characters each: when the translation runs longer, say it more briefly - never drop what is meant. "
    "Never merge, split, drop or reorder lines: every input line comes back once, with the same number i. "
    "Answer with the JSON only.")
# 8.1.5: the first request of an episode also brings the series' glossary - who is who, their
# gender, who says ti / Vi to whom, recurring terms - kept for the series and sent with every
# request after it, so a character is addressed the same way in every episode
GLOSSARY_SCHEMA = {'type': 'OBJECT', 'properties': {
    'lines': SCHEMA,
    'glossary': {'type': 'ARRAY', 'items': {'type': 'OBJECT', 'properties': {
        'term': {'type': 'STRING'}, 'note': {'type': 'STRING'}}, 'required': ['term', 'note']}}},
    'required': ['lines']}
GLOSSARY_ASK = ("Also return 'glossary': the people in these lines with their gender and how they address each "
                "other (formal or informal), and recurring names or terms with the translation you used - short "
                "notes, at most 20 entries, none that are already in the glossary given.")
GLOSSARY_MAX = 80
STEP = 5                # 8.1.5: per cent of the lines between two updates of the subtitle on screen
_TIME = re.compile(r'(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)')


SWITCH = 'meganexus_ai_subtitles'
READY = 'meganexus.ai.ready'


def configured():
    return gemini_api.configured()


def enabled():
    try:
        from .settings_snapshot import cached_addon
        return (cached_addon().getSetting(SWITCH) or 'true') != 'false'
    except Exception:
        return True


def publish():
    """The player's AI button: there while the option is on and a Gemini key is set."""
    try:
        import xbmc
        import xbmcgui
        on = enabled() and configured() and xbmc.Player().isPlayingVideo()
        xbmcgui.Window(10000).setProperty(READY, '1' if on else '')
    except Exception:
        pass


class Failed(ValueError):
    """Said to the user as it is."""


# ---- SRT ---------------------------------------------------------------------
def parse_srt(text):
    """[(start s, end s, text)] of an SRT (or WebVTT-like) file."""
    cues = []
    for block in re.split(r'\r?\n\s*\r?\n', text.replace('﻿', '')):
        lines = block.strip().splitlines()
        for at, line in enumerate(lines):
            found = _TIME.search(line)
            if found:
                h1, m1, s1, f1, h2, m2, s2, f2 = found.groups()
                start = int(h1) * 3600 + int(m1) * 60 + int(s1) + int(f1.ljust(3, '0')[:3]) / 1000.0
                end = int(h2) * 3600 + int(m2) * 60 + int(s2) + int(f2.ljust(3, '0')[:3]) / 1000.0
                body = '\n'.join(lines[at + 1:]).strip()
                if body:
                    cues.append((start, end, body))
                break
    return cues


def _clock(seconds):
    ms = int(round(max(0.0, seconds) * 1000))
    return '%02d:%02d:%02d,%03d' % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def write_srt(cues):
    return '\n'.join('%d\n%s --> %s\n%s\n' % (n, _clock(s), _clock(e), t) for n, (s, e, t) in enumerate(cues, 1))


# ---- translation -------------------------------------------------------------
def _about(context):
    title = str(context.get('title') or context.get('show_title') or context.get('name') or '').strip()
    year = str(context.get('year') or '')[:4]
    kind = 'series' if str(context.get('media_type') or '') in ('series', 'tv', 'episode') else 'film'
    lines = ['%s: %s%s' % (kind.capitalize(), title, (' (%s)' % year) if year else '')] if title else []
    if context.get('season') and context.get('episode'):
        lines.append('Episode: S%s E%s %s' % (context['season'], context['episode'], str(context.get('episode_title') or '')))
    plot = str(context.get('plot') or context.get('overview') or '').strip()
    if plot:
        lines.append('Synopsis: ' + plot[:900])
    return '\n'.join(lines)


def _batches(cues):
    batch, size = [], 0
    for index, cue in enumerate(cues):
        if batch and (len(batch) >= BATCH or size + len(cue[2]) > MAX_CHARS):
            yield batch
            batch, size = [], 0
        batch.append(index)
        size += len(cue[2])
    if batch:
        yield batch


def _ask(indexes, cues, done, about, source, target, stopped, depth=0, key=None, notes=None, glossary=None):
    """{index: translation} for these lines (split and asked again when lines go missing).
    ``key``: the Gemini key of this lane; ``notes``: the series' glossary, sent along;
    ``glossary``: a list to put the glossary Gemini returns in (the episode's first request)."""
    earlier = [i for i in range(max(0, indexes[0] - CONTEXT), indexes[0]) if i in done]
    prompt = ('%s\n\nTranslate the subtitle lines from %s into %s.\n' % (about, source, target)).lstrip()
    if notes:
        prompt += 'Glossary of this series (keep it consistent):\n' + '\n'.join(
            '%s - %s' % (n.get('term'), n.get('note')) for n in notes[:GLOSSARY_MAX]) + '\n'
    if glossary is not None:
        prompt += GLOSSARY_ASK + '\n'
    if earlier:
        prompt += 'The lines just before, already translated (context only, do not return them):\n' + \
            '\n'.join('%s => %s' % (cues[i][2].replace('\n', ' / '), done[i].replace('\n', ' / ')) for i in earlier) + '\n'
    prompt += 'Lines:\n' + json.dumps([{'i': i, 't': cues[i][2]} for i in indexes], ensure_ascii=False)
    try:
        answer = json.loads(gemini_api.generate(prompt, SYSTEM, schema=GLOSSARY_SCHEMA if glossary is not None else SCHEMA,
                                                stopped=stopped, key=key))
    except ValueError as exc:
        if isinstance(exc, gemini_api.GeminiError) or depth >= SPLITS or len(indexes) < 2:
            raise
        answer = []
    if isinstance(answer, dict):
        if glossary is not None:
            glossary.extend(n for n in answer.get('glossary') or [] if isinstance(n, dict) and n.get('term'))
        answer = answer.get('lines') or []
    got = {}
    for item in answer if isinstance(answer, list) else []:
        try:
            i, text = int(item.get('i')), str(item.get('t') or '').strip()
        except (TypeError, ValueError, AttributeError):
            continue
        if i in indexes and text:
            got[i] = text
    missing = [i for i in indexes if i not in got]
    if missing and depth < SPLITS and len(missing) > 1:
        half = len(missing) // 2
        for part in (missing[:half], missing[half:]):
            got.update(_ask(part, cues, {**done, **got}, about, source, target, stopped, depth + 1, key, notes))
    elif missing and depth < SPLITS:
        got.update(_ask(missing, cues, {**done, **got}, about, source, target, stopped, depth + 1, key, notes)
                   if depth + 1 < SPLITS else {})
    return got


def _first_batch(batches, cues, at):
    """The batch holding the line shown at ``at`` seconds (0 from the start)."""
    if at <= 0:
        return 0
    for number, indexes in enumerate(batches):
        if cues[indexes[-1]][1] >= at:
            return number
    return 0


def translate(cues, source, target, context=None, progress=None, stopped=lambda: False, start_at=0.0, partial=None):
    """The same cues in ``target`` (a line Gemini never returned keeps its original text).

    8.1.5: from where the film is now (``start_at`` seconds) on, then the part before it -
    the subtitle shows where you are watching first. With two Gemini keys two lanes work
    side by side, each with its own key and its own part of the film; a lane that is done
    takes half of what is left of the longest other one. Each lane goes in order, so every
    request carries the lines just before it. ``partial(done)`` is called with what is
    translated so far after the first request and then every STEP per cent."""
    import threading
    context = context or {}
    about = _about(context)
    keys = gemini_api.api_keys() or [None]
    batches = list(_batches(cues))
    first = _first_batch(batches, cues, float(start_at or 0))
    segments = [list(range(first, len(batches)))] + ([list(range(0, first))] if first else [])
    while len(segments) < len(keys):
        longest = max(segments, key=len)
        if len(longest) < 2:
            break
        middle = len(longest) // 2
        segments.append(longest[middle:])
        del longest[middle:]
    lock = threading.Lock()
    done, errors, finished = {}, [], [0]
    shown = [-STEP]
    notes = load_glossary(context, target)
    found_notes = [] if context.get('season') and context.get('episode') else None
    asked_notes = [found_notes is None]

    def steal():
        with lock:
            longest = max(segments, key=len, default=[])
            if len(longest) < 2:
                return longest
            middle = len(longest) // 2
            mine = longest[middle:]
            del longest[middle:]
            segments.append(mine)                    # its own half can be shared again
            return mine

    def lane(key, own):
        while not stopped():
            with lock:
                number = own.pop(0) if own else None
            if number is None:
                own = steal()
                if not own:
                    return
                continue
            with lock:
                ask_notes = not asked_notes[0]
                asked_notes[0] = True
                known = dict(done)
            try:
                got = _ask(batches[number], cues, known, about, source, target, stopped, 0, key, notes,
                           found_notes if ask_notes else None)
            except gemini_api.GeminiError as exc:
                with lock:
                    errors.append(str(exc))
                    own.insert(0, number)           # left for another lane
                return
            with lock:
                done.update(got)
                finished[0] += 1
                count, share = finished[0], len(done) * 100 // max(1, len(cues))
                due = share >= shown[0] + STEP or count == 1
                if due:
                    shown[0] = share
                snapshot = dict(done) if due else None
            if progress:
                progress(count, len(batches))
            if snapshot is not None and partial and count < len(batches):
                partial(snapshot)

    lanes = []
    for number, key in enumerate(keys):
        own = segments[number] if number < len(segments) else []
        thread = threading.Thread(target=lane, args=(key, own), name='MegaNexusAILane%d' % (number + 1), daemon=True)
        lanes.append(thread)
        thread.start()
    for thread in lanes:
        thread.join()
    if stopped():
        raise Failed('Stopped.')
    if len(done) < len(cues) * .8:
        raise Failed(errors[0] if errors else 'Gemini translated too few lines (%d of %d).' % (len(done), len(cues)))
    if found_notes:
        keep_glossary(context, target, notes + found_notes)
    return [(s, e, done.get(i, t)) for i, (s, e, t) in enumerate(cues)]


def _glossary_path(context, target):
    show = str(context.get('canonical_id') or context.get('imdb_id') or '').split(':')[0]
    if not show:
        return None
    folder = os.path.join(_folder(), 'glossary')
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, '%s-%s.json' % (hashlib.sha1(show.encode('utf-8')).hexdigest()[:16], target))


def load_glossary(context, target):
    """The series' glossary in ``target`` (8.1.5), [] for a film or a series not met before."""
    if not (context.get('season') and context.get('episode')):
        return []
    path = _glossary_path(context, target)
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return [n for n in data if isinstance(n, dict) and n.get('term')][:GLOSSARY_MAX]
    except Exception:
        return []


def keep_glossary(context, target, notes):
    """The glossary kept for the series - newest note per term, GLOSSARY_MAX at most."""
    path = _glossary_path(context, target)
    if not path:
        return
    merged = {}
    for note in notes:
        merged[str(note.get('term')).strip().lower()] = {'term': str(note.get('term')).strip(),
                                                       'note': str(note.get('note') or '').strip()[:160]}
    try:
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(list(merged.values())[-GLOSSARY_MAX:], handle, ensure_ascii=False)
    except OSError:
        pass


# ---- kept translations -------------------------------------------------------
def _folder():
    path = os.path.join(profile_path(), FOLDER)
    os.makedirs(path, exist_ok=True)
    return path


def key_of(context, target, any_stream=False):
    """``any_stream`` (8.1.5): the title's key without the source - a translation of a
    subtitle from online fits every source of the title the same (the timing is that file's)."""
    ids = [str(context.get(k) or '') for k in ('canonical_id', 'imdb_id', 'video_id')]
    part = '%s:%s' % (context.get('season') or '', context.get('episode') or '')
    stream = '' if any_stream else str(context.get('stream_title') or context.get('stream_name') or '')
    return hashlib.sha1(json.dumps([ids, part, stream, target]).encode('utf-8')).hexdigest()[:20]


NAME = 'MegaNexus AI'     # how the player's subtitle list names it: "Croatian - MegaNexus AI"


def _path(context, target, any_stream=False):
    """<key>/MegaNexus AI.<language>.srt - Kodi takes the name and the language from the
    file's name, so the list shows whose subtitle it is and in which language (8.1.3: it
    was <key>.srt, a nameless line of unknown language)."""
    folder = os.path.join(_folder(), key_of(context, target, any_stream))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, '%s.%s.srt' % (NAME, target))


def kept(context, target):
    for path in (_path(context, target), os.path.join(_folder(), key_of(context, target) + '.srt'),
                 _path(context, target, any_stream=True)):
        if os.path.isfile(path) and os.path.getsize(path) > 200 and not os.path.exists(path + '.partial'):
            return path
    return None


def keep(context, target, cues, partial=False, any_stream=False):
    """The translation in its file. 8.1.5: ``partial`` - what is translated so far, in the
    same file (the player's list keeps one entry), marked so it is never taken for done.
    ``any_stream``: translated from online - also kept for the title's other sources."""
    path = _path(context, target)
    if any_stream and not partial:
        with open(_path(context, target, any_stream=True), 'w', encoding='utf-8') as handle:
            handle.write(write_srt(cues))
    marker = path + '.partial'
    if partial:
        open(marker, 'w').close()
    with open(path, 'w', encoding='utf-8') as handle:
        handle.write(write_srt(cues))
    if not partial and os.path.exists(marker):
        os.remove(marker)
    return path


# ---- where the lines come from -------------------------------------------------
def video_tracks(context):
    """The video's own text subtitle tracks (mkv_subtitle_text.tracks), or None."""
    from . import mkv_subtitle_text as text
    try:
        return text.tracks(str(context.get('stream_url') or ''), context.get('request_headers') or {})
    except Exception as exc:
        context['meganexus_video_subtitles'] = 'pictures' if str(exc) == text.PICTURE_ONLY else ''
        import xbmc
        xbmc.log('[MegaNexus] AI subtitles: the video\'s own subtitles not read (%s)' % str(exc)[:80], xbmc.LOGINFO)
        return None


def from_video(context, target, progress=None, stopped=lambda: False, layout=None):
    """(cues, language) of the video's own best text subtitle not in ``target``, or None."""
    from . import mkv_subtitle_text as text
    from .meganexus_subtitles import language
    url = str(context.get('stream_url') or '')
    headers = context.get('request_headers') or {}
    # 8.1.5: read once - the next time it comes from here, the video's server is not asked
    saved = os.path.join(_folder(), key_of(context, 'video') + '.json')
    try:
        with open(saved, encoding='utf-8') as handle:
            got = json.load(handle)
        if got.get('language') != target and len(got.get('cues') or []) >= 30:
            return [tuple(cue) for cue in got['cues']], got['language']
    except (OSError, ValueError, AttributeError):
        pass
    layout = layout or video_tracks(context)
    if not layout:
        return None
    usable = [(number, entry) for number, entry in layout[4].items()
              if not entry.get('forced') and language(entry.get('language')) != target]
    if not usable:
        return None
    usable.sort(key=lambda pair: (language(pair[1].get('language')) != 'en', -pair[1]['lines']))
    number, entry = usable[0]
    try:
        cues = text.read(url, headers, number, layout=layout, stopped=stopped)
    except Exception as exc:
        import xbmc
        xbmc.log('[MegaNexus] AI subtitles: the video\'s own lines not read (%s)' % str(exc)[:80], xbmc.LOGINFO)
        return None
    try:
        with open(saved, 'w', encoding='utf-8') as handle:
            json.dump({'language': language(entry.get('language')), 'cues': cues}, handle)
    except OSError:
        pass
    return cues, language(entry.get('language'))


def from_file(path):
    try:
        import xbmcvfs
        handle = xbmcvfs.File(path)
        try:
            raw = bytes(handle.readBytes())
        finally:
            handle.close()
    except Exception:
        try:
            with open(path, 'rb') as stream:
                raw = stream.read()
        except OSError:
            return []
    for encoding in ('utf-8-sig', 'cp1250', 'latin-1'):
        try:
            return parse_srt(raw.decode(encoding))
        except UnicodeDecodeError:
            continue
    return []


def from_online(context, target):
    """(cues, language, row) of a subtitle found online - English first - or None."""
    from . import meganexus_subtitles as subs
    try:
        rows = subs.external_rows(context, search=True, fresh=True)
    except Exception:
        return None
    rows = [r for r in rows if subs.language(r.get('lang')) != target and not subs.machine_made(r)]
    rows.sort(key=lambda r: subs.language(r.get('lang')) != 'en')
    key = context.get('video_id') or context.get('canonical_id') or 'ai'
    for row in rows[:6]:
        try:
            path = subs.prepare_selected(row, key)
        except ValueError:
            continue
        cues = from_file(path)
        if len(cues) >= 30:
            return cues, subs.language(row.get('lang')), row
    return None
