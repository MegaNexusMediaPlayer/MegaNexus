# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Usenet player outside Kodi on CoreELEC / LibreELEC / Linux (7.0.52).

All Python in Kodi shares one lock (the GIL): our Usenet server read the articles,
decoded yEnc and sent the film on one core, next to the rest of MegaNexus. A
CoreELEC box gave ~90 Mbit/s that way; a remux needs more. These systems have
their own python3, so the service starts the same server (usenet_stream) there as
a separate process, and yEnc is decoded in a pool of worker processes, one per
free core. Kodi plays its 127.0.0.1 link as before.

Nothing to manage: the engine starts with the service, ends with it (it reads
Kodi's pipe; when Kodi is gone it exits) and a crash falls back to the server
inside Kodi. Android and Windows have no python3 of their own: the server stays
inside Kodi there. HUB Settings > Debrid & Usenet > Usenet > "Usenet on all cores" turns it off.

The pipe carries one JSON object per line:
  Kodi -> engine: {"folder", "keep", "ahead", "workers"} first, then {"halt": 1}
                  (MegaNexus stops the film) and {"nzb": token, "error": ""} (the NZB
                  is in <folder>/<token>.nzb - Kodi fetches it: the indexer's daily
                  downloads are counted in Kodi);
  engine -> Kodi: {"port"}, {"log"}, {"need": token}, {"reading": count}.
Server addresses and NZB links never travel on the pipe or into the log.
"""
import json
import os
import sys
import threading
import time

SETTING = 'usenet_engine'              # 'true' (default) / 'false'
START_WAIT = 15                        # s the engine may take to report its port
NZB_WAIT = 60                          # s the engine waits for Kodi's NZB
PARENT_CHECK = 2                       # s: a decoding process checks the engine is still there
LEAVING_EVERY = 0.25                   # s Kodi looks for MegaNexus' Stop while a film reads
LATER = 45                             # s after Kodi starts: never while Home loads (the server in
                                       # Kodi plays until then)


# --- in Kodi (the service) ------------------------------------------------------

_engine = {'process': None, 'reading': 0}


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Usenet: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def python():
    """This system's own python3 (3.8 or newer), or ''. Never on Android."""
    try:
        import xbmc
        if xbmc.getCondVisibility('System.Platform.Android') or not xbmc.getCondVisibility('System.Platform.Linux'):
            return ''
    except Exception:
        return ''
    import shutil
    for name in ('python3', 'python'):
        path = shutil.which(name) or ''
        if path and os.path.realpath(path) != os.path.realpath(sys.executable or ''):
            return path
    return ''


def wanted(addon=None):
    try:
        if addon is None:
            from .settings_snapshot import cached_addon
            addon = cached_addon()
        return (addon.getSetting(SETTING) or 'true') != 'false'
    except Exception:
        return True


def workers():
    """Decoding processes: the cores Kodi does not need (it plays the film on one or two)."""
    return max(0, min(4, (os.cpu_count() or 1) - 2))


def start():
    """The service: the server inside Kodi at once; the engine LATER seconds on, when this
    system can run it and no film plays from the server inside Kodi."""
    from . import usenet_stream
    usenet_stream.start()
    if _engine['process'] is None and wanted() and python():
        threading.Thread(target=_later, args=(usenet_stream,), name='MegaNexusUsenetEngineStart',
                         daemon=True).start()


def _later(usenet_stream):
    try:
        import xbmc
        monitor = xbmc.Monitor()
    except Exception:
        return
    if monitor.waitForAbort(LATER):
        return
    while True:
        with usenet_stream._LOCK:
            busy = bool(usenet_stream._SOURCES) or usenet_stream._READING['count'] > 0
        if not busy:
            break
        if monitor.waitForAbort(30):
            return
    try:
        _launch(usenet_stream)
    except Exception as exc:
        _log('engine not started (%s) - inside Kodi' % type(exc).__name__)


def _launch(usenet_stream):
    import subprocess
    exe = python()
    if not exe:
        return False
    keep, ahead = usenet_stream.limits()
    config = {'folder': usenet_stream._folder(), 'keep': keep, 'ahead': ahead, 'workers': workers()}
    process = subprocess.Popen([exe, '-u', os.path.abspath(__file__)], stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, close_fds=True,
                               cwd=os.path.dirname(os.path.abspath(__file__)))
    process.stdin.write((json.dumps(config) + '\n').encode('utf-8'))
    process.stdin.flush()
    ready = threading.Event()
    lock = threading.Lock()
    threading.Thread(target=_listen, args=(process, ready, lock, usenet_stream),
                     name='MegaNexusUsenetEngine', daemon=True).start()
    if not ready.wait(START_WAIT) or process.poll() is not None:
        _log('engine did not start - inside Kodi')
        try:
            process.kill()
        except Exception:
            pass
        return False
    _engine.update(process=process, lock=lock)
    usenet_stream.stop()                       # the server inside Kodi goes, the engine's link is given
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty(usenet_stream.PROP_PORT, str(_engine['port']))
    except Exception:
        pass
    _log('engine on %d decoding processes (%s)' % (config['workers'], os.path.basename(exe)))
    return True


def _send(message):
    process, lock = _engine.get('process'), _engine.get('lock')
    if process is None:
        return
    try:
        with lock:
            process.stdin.write((json.dumps(message) + '\n').encode('utf-8'))
            process.stdin.flush()
    except Exception:
        pass


def _listen(process, ready, lock, usenet_stream):
    for raw in process.stdout:
        try:
            message = json.loads(raw.decode('utf-8', 'replace'))
        except ValueError:
            continue
        if 'port' in message:
            _engine['port'] = int(message['port'])
            ready.set()
        elif 'log' in message:
            _log(str(message['log'])[:400])
        elif 'need' in message:
            threading.Thread(target=_give_nzb, args=(str(message['need']), usenet_stream),
                             name='MegaNexusUsenetNzb', daemon=True).start()
        elif 'reading' in message:
            _engine['reading'] = int(message['reading'] or 0)
            if _engine['reading'] and not _engine.get('watching'):
                _engine['watching'] = True
                threading.Thread(target=_watch_leaving, args=(usenet_stream,),
                                 name='MegaNexusUsenetLeaving', daemon=True).start()
    # the engine ended: a crash falls back to the server inside Kodi
    if _engine.get('process') is process:
        _engine['process'] = None
        if not _engine.get('stopping'):
            _log('engine ended (%s) - inside Kodi from now on' % process.poll())
            try:
                usenet_stream.start()
            except Exception:
                pass


def _give_nzb(token, usenet_stream):
    """The engine opens a source: Kodi fetches its NZB (and counts the indexer's grab)."""
    error = ''
    try:
        folder = usenet_stream._folder()
        token = os.path.basename(token)
        with open(os.path.join(folder, token + '.json'), encoding='utf-8') as handle:
            saved = json.load(handle)
        from . import usenet_nntp as nntp
        servers = [s for s in (nntp.parse_server(v) for v in saved.get('servers') or []) if s]
        data = usenet_stream.nzb_data(token, saved, servers)
        temp = os.path.join(folder, token + '.nzb.tmp')
        with open(temp, 'wb') as handle:
            handle.write(data)
        os.replace(temp, os.path.join(folder, token + '.nzb'))
    except Exception as exc:
        error = str(exc)[:160] if exc.__class__.__name__ in ('NntpError', 'Unsupported') else type(exc).__name__
    _send({'nzb': token, 'error': error})


def _watch_leaving(usenet_stream):
    """While a film reads from the engine: MegaNexus' Stop (OSD, Back) goes to it at once."""
    try:
        import xbmc
        import xbmcgui
        home, monitor = xbmcgui.Window(10000), xbmc.Monitor()
        home.clearProperty(usenet_stream.LEAVING)          # a Stop of another film, before this one
        while _engine['reading'] and _engine.get('process') is not None and not monitor.abortRequested():
            if home.getProperty(usenet_stream.LEAVING) == '1':
                home.clearProperty(usenet_stream.LEAVING)
                _send({'halt': 1})
            monitor.waitForAbort(LEAVING_EVERY)
    finally:
        _engine['watching'] = False


def stop():
    from . import usenet_stream
    process = _engine.get('process')
    _engine['stopping'] = True
    _engine['process'] = None
    if process is not None:
        try:
            process.stdin.close()                # the engine sees the end of its pipe and exits
            process.wait(3)
        except Exception:
            try:
                process.kill()
            except Exception:
                pass
        try:
            import xbmcgui
            xbmcgui.Window(10000).clearProperty(usenet_stream.PROP_PORT)
        except Exception:
            pass
    usenet_stream.stop()
    _engine['stopping'] = False


# --- the engine (system python3) -----------------------------------------------

def _engine_main():
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(os.path.dirname(here))         # the add-on folder: resources.lib.* import
    if root not in sys.path:
        sys.path.insert(0, root)
    config = json.loads(sys.stdin.readline() or '{}')
    out = threading.Lock()

    def say(message):
        with out:
            sys.stdout.write(json.dumps(message) + '\n')
            sys.stdout.flush()

    from resources.lib import usenet_nntp as nntp
    pool = None
    if int(config.get('workers') or 0) > 0:
        # made before any thread starts (fork); each worker decodes whole articles
        import multiprocessing
        from concurrent.futures import ProcessPoolExecutor
        count = int(config['workers'])
        pool = ProcessPoolExecutor(max_workers=count, mp_context=multiprocessing.get_context('fork'),
                                   initializer=_follow_parent, initargs=(os.getpid(),))
        # every worker now, while no other thread runs (a fork later could copy a held lock)
        for job in [pool.submit(time.sleep, 0.3) for _ in range(count)]:
            job.result(30)
    from resources.lib import usenet_stream
    folder = str(config['folder'])
    usenet_stream._log = lambda text, level=None: say({'log': text})
    usenet_stream._folder = lambda: folder
    keep, ahead = int(config.get('keep') or usenet_stream.CACHE_PARTS), int(config.get('ahead') or usenet_stream.AHEAD)
    usenet_stream.limits = lambda: (keep, ahead)
    if pool is not None:
        def decode(body):
            if usenet_stream.DECODE is None:
                return nntp.yenc_decode(body)
            try:
                return pool.submit(nntp.yenc_decode, body).result()
            except nntp.NntpError:
                raise
            except Exception as exc:                       # a worker died: decode here from now on
                usenet_stream.DECODE = None
                say({'log': 'decoding processes stopped (%s) - one core from now on' % type(exc).__name__})
                return nntp.yenc_decode(body)
        usenet_stream.DECODE = decode
    waiting = {}

    def nzb_from_kodi(token, saved, servers):
        token = os.path.basename(token)
        done = waiting[token] = [threading.Event(), '']
        say({'need': token})
        if not done[0].wait(NZB_WAIT):
            raise nntp.NntpError('the NZB did not come')
        if done[1]:
            raise nntp.NntpError(done[1])
        path = os.path.join(folder, token + '.nzb')
        try:
            with open(path, 'rb') as handle:
                return handle.read()
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
    usenet_stream.NZB_DATA = nzb_from_kodi
    reading = {'count': -1}
    original_flag = usenet_stream._set_flag

    def tell_reading(value):
        count = usenet_stream._READING['count']
        if count != reading['count']:
            reading['count'] = count
            say({'reading': max(0, count)})
        try:
            original_flag(value)
        except Exception:
            pass
    usenet_stream._set_flag = tell_reading
    usenet_stream.start()
    if usenet_stream._server is None:
        sys.exit(1)
    say({'port': usenet_stream._server.server_address[1]})
    for raw in sys.stdin:                                  # Kodi's pipe; its end ends the engine
        try:
            message = json.loads(raw)
        except ValueError:
            continue
        if message.get('halt'):
            usenet_stream._log('the player is stopping - reads end now')
            usenet_stream.halt()
        elif 'nzb' in message:
            done = waiting.pop(os.path.basename(str(message['nzb'])), None)
            if done is not None:
                done[1] = str(message.get('error') or '')
                done[0].set()
    usenet_stream.stop()
    if pool is not None:
        _end_pool(pool)
    os._exit(0)


def _follow_parent(parent):
    """A decoding process: it ends with the engine. Forked, it holds both ends of its own
    job pipe, so it would never see the engine go - it watches the engine's pid instead."""
    def watch():
        while os.getppid() == parent:
            time.sleep(PARENT_CHECK)
        os._exit(0)
    threading.Thread(target=watch, name='MegaNexusEngineParent', daemon=True).start()


def _end_pool(pool):
    """The decoding processes end with the engine (never left behind)."""
    processes = list((getattr(pool, '_processes', None) or {}).values())
    try:
        pool.shutdown(wait=False)
    except Exception:
        pass
    for process in processes:
        try:
            process.terminate()
        except Exception:
            pass


if __name__ == '__main__':
    _engine_main()
