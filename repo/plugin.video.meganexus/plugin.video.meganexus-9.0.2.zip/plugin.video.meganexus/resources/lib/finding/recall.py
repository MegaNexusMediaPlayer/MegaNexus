# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""What a search remembers, so the next one is better.

Two halves, one lifetime: the queries the user typed and how each add-on answered
them. Both are facts about searches already done, both live in the profile, and a
profile reset drops both - so they are one module rather than two.

The query log is written and travels in a backup (settings_backup.DATABASES); the
add-on record decides the order add-ons are asked in (``by_record``). Neither may
ever raise: a search that cannot write its own notes is still a search.
"""
import os
import sqlite3
import threading
import time

from ..hub_log import log
from ..meganexus.json_files import read_json, write_json
from ..meganexus.paths import profile_path

# ---------------------------------------------------------------------------------
# the queries the user typed
# ---------------------------------------------------------------------------------

QUERY_DB = os.path.join(profile_path(), 'search_history.db')   # the name 6.0 wrote; backups carry it
MAX_QUERIES = 50
LONGEST_QUERY = 200

_QUERY_TABLE = """
CREATE TABLE IF NOT EXISTS history (
    query       TEXT PRIMARY KEY,
    count       INTEGER NOT NULL DEFAULT 1,
    last_used   INTEGER NOT NULL,
    media_type  TEXT NOT NULL DEFAULT 'all'
);
CREATE INDEX IF NOT EXISTS idx_history_last ON history(last_used DESC);
"""

_COUNT_UP = """
INSERT INTO history (query, count, last_used, media_type) VALUES (?, 1, ?, ?)
ON CONFLICT(query) DO UPDATE SET count = count + 1,
                                 last_used = excluded.last_used,
                                 media_type = excluded.media_type
"""

# One statement holds the cap: everything outside the newest MAX_QUERIES goes.
_TRIM = 'DELETE FROM history WHERE query NOT IN (SELECT query FROM history ORDER BY last_used DESC LIMIT ?)'

_DB_READY = False
_DB_LOCK = threading.Lock()


def _query_db():
    connection = sqlite3.connect(QUERY_DB, timeout=0.35)
    for pragma in ('journal_mode=WAL', 'synchronous=NORMAL'):
        try:
            connection.execute('PRAGMA ' + pragma)
        except sqlite3.Error:
            pass            # an older SQLite, or a profile on a filesystem without WAL
    return connection


def _query_log_ready():
    global _DB_READY
    if _DB_READY:
        return True
    with _DB_LOCK:
        if _DB_READY:
            return True
        try:
            os.makedirs(os.path.dirname(QUERY_DB), exist_ok=True)
            connection = _query_db()
            try:
                connection.executescript(_QUERY_TABLE)
                connection.commit()
            finally:
                connection.close()
        except Exception as exc:
            log.warn('FIND', 'the search log is unavailable: %s', exc)
            return False
        _DB_READY = True
        return True


def note_query(query, media_type='all'):
    """One search the user typed. Counted up when it is one they typed before."""
    text = str(query or '').strip()
    if not text or len(text) > LONGEST_QUERY or not _query_log_ready():
        return
    try:
        connection = _query_db()
        try:
            connection.execute(_COUNT_UP, (text, int(time.time()), str(media_type or '') or 'all'))
            connection.execute(_TRIM, (MAX_QUERIES,))
            connection.commit()
        finally:
            connection.close()
    except Exception as exc:
        log.warn('FIND', 'the search log kept nothing for "%s": %s', text[:40], exc)


# ---------------------------------------------------------------------------------
# how each add-on answered
# ---------------------------------------------------------------------------------

ADDON_FILE = os.path.join(profile_path(), 'provider_performance.json')
MAX_ADDONS = 96

_SETTLED_AFTER = 8          # samples before a measurement stops moving the average far
_FAST_ALPHA, _SLOW_ALPHA = 0.35, 0.18
_SANE_MS = (1.0, 120000.0)  # a stopwatch reading outside this says more about the clock

_UNTRIED, _UNTRIED_OWN = 1000.0, 600.0   # our own servers are worth asking first
_FAILURE_COST, _EMPTY_COST = 3000.0, 500.0

_OWN_SERVERS = ('__plex__', '__emby__')

_ADDONS = None
_ADDON_LOCK = threading.RLock()


def _addon_ref(addon):
    """One key per thing we ask - each server of our own kinds separately."""
    row = addon or {}
    kind = str(row.get('id') or '').strip()
    if kind in _OWN_SERVERS:
        server = row.get('_server') or {}
        return '%s:%s' % (kind, server.get('id') or server.get('name') or 'default')
    told_apart_by = kind or row.get('base_url') or row.get('manifest_url') or row.get('name')
    return str(told_apart_by or 'unknown')[:240]


def _record():
    global _ADDONS
    with _ADDON_LOCK:
        if _ADDONS is None:
            _ADDONS = read_json(ADDON_FILE, {})     # a damaged file reads as no record at all
        return _ADDONS


def _newest(record):
    """The cap, newest kept - an add-on gone for good stops taking up room."""
    if len(record) <= MAX_ADDONS:
        return record
    by_age = sorted(record.items(), key=lambda row: int((row[1] or {}).get('updated_at') or 0), reverse=True)
    return dict(by_age[:MAX_ADDONS])


def note_addon(addon, elapsed, success, result_count=0):
    """How one add-on answered one search: how long it took, and whether it brought rows."""
    global _ADDONS
    low, high = _SANE_MS
    took_ms = max(low, min(float(elapsed or 0.0) * 1000.0, high))
    ref = _addon_ref(addon)
    with _ADDON_LOCK:
        record = dict(_record())
        before = dict(record.get(ref) or {})
        samples = int(before.get('samples') or 0)
        average = float(before.get('avg_ms') or 0.0)
        alpha = _FAST_ALPHA if samples < _SETTLED_AFTER else _SLOW_ALPHA
        record[ref] = {
            'avg_ms': round(took_ms if average <= 0 else average + (took_ms - average) * alpha, 1),
            'samples': min(samples + 1, 100000),
            'successes': min(int(before.get('successes') or 0) + (1 if success else 0), 100000),
            'failures': min(int(before.get('failures') or 0) + (0 if success else 1), 100000),
            'last_count': max(0, int(result_count or 0)),
            'updated_at': int(time.time()),
        }
        _ADDONS = _newest(record)
        try:
            write_json(ADDON_FILE, _ADDONS)
        except Exception as exc:
            log.warn('FIND', 'the add-on record was not saved: %s', exc)


def _cost(addon):
    """Lower is asked first. An add-on nobody has tried yet is worth a turn."""
    row = _record().get(_addon_ref(addon)) or {}
    samples = int(row.get('samples') or 0)
    if samples <= 0:
        return _UNTRIED_OWN if str((addon or {}).get('id') or '') in _OWN_SERVERS else _UNTRIED
    failed_share = 1.0 - (float(int(row.get('successes') or 0)) / float(samples))
    empty_last_time = _EMPTY_COST if int(row.get('last_count') or 0) <= 0 else 0.0
    return float(row.get('avg_ms') or 1500.0) + (failed_share * _FAILURE_COST) + empty_last_time


def by_record(targets):
    """The same targets, the ones that have been answering best first.

    Equal costs keep the order they came in, so a tie never shuffles the screen.
    """
    rows = list(targets or [])
    return sorted(rows, key=lambda target: _cost((target or ({},))[0]))
