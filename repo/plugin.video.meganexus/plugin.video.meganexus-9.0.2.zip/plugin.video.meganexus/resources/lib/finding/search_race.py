# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError
import time


def each_live(tasks, max_workers=6, timeout=None):
    if not tasks:
        return
    pool = ThreadPoolExecutor(max_workers=max(1, min(int(max_workers or 1), len(tasks), 8)))
    futures = {}
    try:
        for name, fn in tasks.items():
            futures[pool.submit(fn)] = name
        iterator = as_completed(futures, timeout=timeout) if timeout else as_completed(futures)
        try:
            for future in iterator:
                name = futures[future]
                try:
                    yield name, future.result(timeout=0)
                except Exception:
                    yield name, []
        except TimeoutError:
            return
    finally:
        for future in futures:
            if not future.done():
                future.cancel()
        try:
            pool.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            pool.shutdown(wait=False)


def run(tasks, max_workers=6, timeout=None):
    return {name: value for name, value in each_live(tasks, max_workers=max_workers, timeout=timeout)}
