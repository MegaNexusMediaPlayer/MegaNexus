# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The lines of a video's own text subtitles, read without downloading the film (8.1.3).

The Matroska index (mkv_subtitle_times) says, for every subtitle frame, the cluster it
sits in and where inside that cluster - a few hundred bytes each. They are the subtitles
made for exactly this release, so a translation of them needs no syncing at all.

8.1.5: a request per line, six at a time, was taken for abuse by a debrid CDN (TorBox:
429, then no connections at all - the playing video's too). Now one connection asks for
up to BATCH lines in one request (Range: a-b,c-d,... - multipart/byteranges, as nginx and
most file servers answer): an episode in about five requests, a film in about fifteen,
whatever its size. A server that answers one part only is read one line at a time,
slowly (PAUSE); one that sends the whole file is hung up on at once. The first 429, 503
or refused connection ends the reading.

Text tracks only (SRT, ASS/SSA, WebVTT); picture subtitles (PGS, VobSub) cannot be read
as text. Raises mkv_subtitle_times.Unavailable when the video gives nothing usable.
"""
import http.client
import re
import time
import zlib
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

from . import mkv_subtitle_times as mkv
from .mkv_subtitle_times import Unavailable

CUE_POINT, CUE_TIME, CUE_TRACK_POSITIONS, CUE_TRACK = mkv.CUE_POINT, mkv.CUE_TIME, mkv.CUE_TRACK_POSITIONS, mkv.CUE_TRACK
CUE_DURATION, CUE_CLUSTER_POSITION, CUE_RELATIVE_POSITION = mkv.CUE_DURATION, 0xF1, 0xF0
SIMPLE_BLOCK, BLOCK_GROUP, BLOCK, BLOCK_DURATION = 0xA3, 0xA0, 0xA1, 0x9B
TEXT = ('S_TEXT/UTF8', 'S_TEXT/ASS', 'S_TEXT/SSA', 'S_TEXT/WEBVTT', 'S_TEXT/ASCII')
PICTURES = ('S_HDMV/PGS', 'S_VOBSUB', 'S_DVBSUB')   # pictures of text - nothing to read
PICTURE_ONLY = 'its subtitles are pictures (PGS / VobSub), not text'
WINDOW = 2048                      # bytes read around one line (its block and some slack)
BATCH = 80                         # lines asked for in one request
PAUSE = 0.25                       # s between requests (one connection)
BUDGET = 90.0                      # seconds for all the lines (one at a time: SLOW_BUDGET)
SLOW_BUDGET = 240.0
_STOP = ('(429)', '(503)', 'refused the connection')   # the server says: enough
_BOUNDARY = re.compile(r'boundary="?([^";]+)"?', re.I)
_CONTENT_RANGE = re.compile(rb'content-range:\s*bytes\s+(\d+)-(\d+)', re.I)
MAX_LINES = 5000
_ASS_TAG = re.compile(r'\{[^}]*\}')


class _Ranges(object):
    """Range requests over one kept-open connection."""

    def __init__(self, url, headers):
        # where the link really leads (debrid links redirect) - asked once
        request = Request(mkv.web_address(url), headers=dict(headers, Range='bytes=0-0'))
        with urlopen(request, timeout=15) as reply:
            self.url = reply.geturl()
            if (getattr(reply, 'status', None) or reply.getcode()) != 206:
                raise Unavailable('no range requests')
            reply.read(1)
        parts = urlsplit(self.url)
        self.secure = parts.scheme == 'https'
        self.host = parts.netloc
        self.path = parts.path + ('?' + parts.query if parts.query else '')
        self.headers = dict(headers)
        self.conn = None
        self.requests = 0

    def _drop(self):
        try:
            self.conn.close()
        except Exception:
            pass
        self.conn = None

    def _ask(self, spans):
        """The reply to one request for ``spans`` [(start, end inclusive)]: (status, headers, body).
        Not a part reply (200 - the whole file): hung up at once, nothing read."""
        for attempt in (1, 2):
            if self.conn is None:
                kind = http.client.HTTPSConnection if self.secure else http.client.HTTPConnection
                self.conn = kind(self.host, timeout=8)
            try:
                self.requests += 1
                wanted = ','.join('%d-%d' % span for span in spans)
                self.conn.request('GET', self.path, headers=dict(self.headers, Range='bytes=' + wanted))
                reply = self.conn.getresponse()
                if reply.status != 206:
                    self._drop()
                    raise Unavailable('range refused (%s)' % reply.status)
                most = sum(end - start + 1 for start, end in spans) + 400 * len(spans) + 4096
                size = int(reply.headers.get('Content-Length') or 0)
                if size > most:
                    self._drop()
                    raise Unavailable('the server sent far more than asked')
                body = reply.read(size or most)
                if not size:
                    self._drop()                   # unknown length: the rest is not left on the line
                return reply.headers, body
            except Unavailable:
                raise
            except ConnectionRefusedError:
                self._drop()
                raise Unavailable('the video refused the connection')
            except Exception:
                self._drop()
                if attempt == 2:
                    raise
        return {}, b''

    def get(self, start, length):
        return self._ask([(start, start + length - 1)])[1]

    def many(self, spans):
        """{start: bytes} of the ``spans`` the server sent - all of them from a server that
        answers multipart/byteranges, the first only from one that does not."""
        headers, body = self._ask(spans)
        kind = headers.get('Content-Type') or ''
        if 'multipart/byteranges' not in kind.lower():
            found = re.search(r'bytes\s+(\d+)-', headers.get('Content-Range') or '')
            return {int(found.group(1)): body} if found else {}
        boundary = _BOUNDARY.search(kind)
        if not boundary:
            return {}
        out = {}
        for part in body.split(b'--' + boundary.group(1).encode('latin-1')):
            head, sep, data = part.partition(b'\r\n\r\n')
            got = _CONTENT_RANGE.search(head) if sep else None
            if got:
                length = int(got.group(2)) - int(got.group(1)) + 1
                out[int(got.group(1))] = data[:length]
        return out


def _positions(data, start, end, track):
    """[(time ticks, duration ticks or None, cluster position, relative position)] of ``track``."""
    found = []
    for eid, begin, stop, _ in mkv._elements(data, start, end):
        if eid != CUE_POINT:
            continue
        moment = None
        entries = []
        for cid, b, s, _ in mkv._elements(data, begin, stop):
            if cid == CUE_TIME:
                moment = mkv._uint(data, b, s)
            elif cid == CUE_TRACK_POSITIONS:
                item = {}
                for pid, pb, ps, _ in mkv._elements(data, b, s):
                    if pid in (CUE_TRACK, CUE_DURATION, CUE_CLUSTER_POSITION, CUE_RELATIVE_POSITION):
                        item[pid] = mkv._uint(data, pb, ps)
                entries.append(item)
        if moment is None:
            continue
        for item in entries:
            if item.get(CUE_TRACK) == track and CUE_CLUSTER_POSITION in item and CUE_RELATIVE_POSITION in item:
                found.append((moment, item.get(CUE_DURATION), item[CUE_CLUSTER_POSITION], item[CUE_RELATIVE_POSITION]))
    found.sort()
    return found


def _block(data, offset, track):
    """(payload, duration ticks or None) of the block of ``track`` at data[offset:], or None."""
    try:
        eid, n = mkv._vint(data, offset, True)
        size, m = mkv._vint(data, offset + n, False)
    except Unavailable:
        return None
    begin, end = offset + n + m, offset + n + m + size
    if size <= 4 or end > len(data):
        return None
    duration = None
    if eid == BLOCK_GROUP:
        inner = None
        for cid, b, s, cut in mkv._elements(data, begin, end):
            if cid == BLOCK and not cut:
                inner = (b, s)
            elif cid == BLOCK_DURATION:
                duration = mkv._uint(data, b, s)
        if inner is None:
            return None
        begin, end = inner
    elif eid != SIMPLE_BLOCK:
        return None
    try:
        number, k = mkv._vint(data, begin, False)
    except Unavailable:
        return None
    if number != track:
        return None
    payload = data[begin + k + 3:end]            # timecode (2) and flags (1)
    return bytes(payload), duration


def _text(payload, codec, compression):
    if compression:
        algo, settings = compression
        if algo == 0:
            payload = zlib.decompress(payload)
        elif algo == 3:
            payload = settings + payload
        else:
            return ''
    text = payload.decode('utf-8', 'replace').strip('\x00').strip()
    if codec in ('S_TEXT/ASS', 'S_TEXT/SSA'):
        text = text.split(',', 8)[-1]
        text = _ASS_TAG.sub('', text).replace('\\N', '\n').replace('\\n', '\n').replace('\\h', ' ')
    return text.strip()


def tracks(url, headers=None):
    """The video's text subtitle tracks: {number: {language, name, forced, codec, lines}}."""
    reader = mkv._Reader(str(url).split('|', 1)[0], headers or {}, urlopen, mkv.BUDGET)
    segment, scale, found, cues = mkv._layout(reader)
    out = {}
    for number, entry in found.items():
        if entry.get('codec') not in TEXT:
            continue
        lines = _positions(cues[0], cues[1], cues[2], number)
        if len(lines) >= mkv.MIN_CUES:
            out[number] = dict(entry, lines=len(lines))
    if not out:
        pictures = [entry for entry in found.values() if entry.get('codec') in PICTURES]
        raise Unavailable(PICTURE_ONLY if pictures else 'no text subtitle track with an index')
    return segment, scale, found, cues, out


def _spans(starts):
    """Ranges of WINDOW bytes from ``starts`` (sorted), the overlapping ones joined."""
    out = []
    for at in starts:
        if out and at <= out[-1][1] + 1:
            out[-1] = (out[-1][0], max(out[-1][1], at + WINDOW - 1))
        else:
            out.append((at, at + WINDOW - 1))
    return out


def xbmc_log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Video subtitles: ' + text, xbmc.LOGINFO)
    except Exception:
        pass


def read(url, headers, track, layout=None, progress=None, stopped=lambda: False):
    """[(start s, end s, text)] of one text track, in order."""
    url = str(url).split('|', 1)[0]
    headers = mkv.kodi_headers(headers)
    segment, scale, found, cues, _ = layout or tracks(url, headers)
    entry = found[track]
    positions = _positions(cues[0], cues[1], cues[2], track)[:MAX_LINES]
    ranges = _Ranges(url, headers)
    until = time.monotonic() + BUDGET
    # the block starts after the cluster's ID (4 bytes) and size (1 to 8 bytes)
    wanted = [(segment + cluster + relative + 5, item) for item in positions
              for _, _, cluster, relative in [item]]
    read_at = {}
    batch = BATCH
    failed = 0
    left = sorted(set(at for at, _ in wanted))
    while left:
        if stopped():
            raise Unavailable('stopped')
        if time.monotonic() > until:
            break
        spans = _spans(left[:batch])
        try:
            got = ranges.many(spans)
        except Unavailable as exc:
            if len(spans) > 1 and not any(no in str(exc) for no in _STOP):
                batch = 1                          # many ranges not taken (200, 416, 501): one at a time
                until = max(until, time.monotonic() + SLOW_BUDGET)
                xbmc_log('the video does not send several parts at once - its lines are read one by one')
                time.sleep(PAUSE)
                continue
            raise                                  # 429, 503, refused: no more asking
        except Exception:
            failed += 1
            if failed >= 3:
                raise Unavailable('the video stopped answering')
            time.sleep(PAUSE * 4)
            continue
        failed = 0
        before = len(left)
        for start, data in got.items():
            for at in left:
                if 0 <= at - start < len(data):
                    read_at[at] = data[at - start:at - start + WINDOW]
        left = [at for at in left if at not in read_at]
        if len(left) == before:
            break                                  # nothing usable came back
        if batch > 1 and len(got) < len(spans):
            batch = 1                              # one part per request: slowly, one line at a time
            until = max(until, time.monotonic() + SLOW_BUDGET)
            xbmc_log('the video sends one part per request - its lines are read one by one')
        if progress:
            progress(len(read_at), len(left) + len(read_at))
        time.sleep(PAUSE)
    xbmc_log('%d lines read in %d requests' % (len(read_at), ranges.requests))
    results = []
    for at, (moment, cue_duration, _, _) in wanted:
        data = read_at.get(at)
        for slack in range(8 if data else 0):
            got = _block(data, slack, track)
            if got:
                payload, duration = got
                text = _text(payload, entry.get('codec'), entry.get('compression'))
                if text:
                    results.append((moment, duration or cue_duration, text))
                break
    if len(results) < mkv.MIN_CUES:
        raise Unavailable('the lines could not be read')
    out = []
    for i, (moment, duration, text) in enumerate(results):
        start = moment * scale / 1e9
        if duration:
            end = start + duration * scale / 1e9
        elif i + 1 < len(results):
            end = min(results[i + 1][0] * scale / 1e9, start + mkv.CUE_LONGEST)
        else:
            end = start + mkv.LAST_CUE
        out.append((start, max(end, start + .3), text))
    return out
