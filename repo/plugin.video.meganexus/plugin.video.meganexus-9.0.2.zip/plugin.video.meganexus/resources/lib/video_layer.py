# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""No black flash when a video stops on Amlogic boxes (9.0.2).

CoreELEC / LibreELEC on Amlogic show video on a hardware layer under Kodi's interface.
When any video stops - a trailer in the corner, a Sport or IPTV preview, even one Kodi
plays by itself - the kernel's video driver blacks that layer out (blackout_policy 1),
and on a Fire TV Cube the whole picture flashed for a few milliseconds each time
("bljesak cijelog ekrana kad se mini player prekida i prebacuje"). Measured there: with
Kodi alone it flashed, with the policy at 0 (keep the last frame) it did not. The last
frame stays under an interface that covers it (a corner opens only once the next clip has
its first picture), so nothing else changes. The kernel sets 1 again at every boot; the
service sets 0 at every start. PCs and Android have no such file, or may not write it:
nothing happens there.
"""
POLICY = '/sys/class/video/blackout_policy'


def keep_last_frame(path=POLICY):
    """True when the video layer keeps its last frame on stop (set now, or already)."""
    try:
        with open(path) as handle:
            if handle.read().strip() == '0':
                return True
    except OSError:
        return False                 # not an Amlogic box
    try:
        with open(path, 'w') as handle:
            handle.write('0')
        return True
    except OSError:
        return False                 # not allowed here (Android)
