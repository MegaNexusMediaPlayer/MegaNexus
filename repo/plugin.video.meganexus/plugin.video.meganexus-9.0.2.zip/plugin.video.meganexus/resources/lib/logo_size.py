# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Logos the same size to the eye (8.1.3).

Home showed every logo in the same 600 x 114 box, keeping its shape - so the picture
itself decided how big it looked. A collection title from Nuvio is a 1280 x 720 canvas
with the name in the middle (Netflix: 1016 x 274 of it, the rest clear), and came out
about 160 x 43; "Action", cut tight at 1179 x 280, came out 480 x 114.

Nothing is decoded: the first bytes of the file say its width and height (PNG, WebP,
JPEG). From the shape, a box height is picked so that every logo covers about the same
area - a wide one lower, a compact one taller - and a 16:9 collection canvas gets a box
big enough for the name inside it. The skin has one image per height
(review/make_logo_fit.py); the card carries which (ListItem.Property(logo_fit)).
"""
import json
import os
import struct
import threading
from urllib.request import Request, urlopen

from .meganexus.paths import profile_path

AREA = 34000                       # px on a 1080 screen every logo should cover, about
HEIGHTS = (56, 72, 88, 104, 120, 140)
CANVAS = 'canvas'                  # a 16:9 title canvas (the name in its middle)
HEAD = 4096                        # bytes asked for - enough for the size of any of the three
TIMEOUT = 6
_lock = threading.Lock()
_sizes = None
_unreached = set()                 # not answered this run (a network blip) - asked again next start


def _path():
    return os.path.join(profile_path(), 'logo_sizes.json')


def _load():
    global _sizes
    if _sizes is None:
        try:
            with open(_path(), encoding='utf-8') as handle:
                loaded = json.load(handle)
            _sizes = loaded if isinstance(loaded, dict) else {}
        except (OSError, ValueError):
            _sizes = {}
    return _sizes


def dims(data):
    """(width, height) from a file's first bytes, or None."""
    if data[:8] == b'\x89PNG\r\n\x1a\n' and data[12:16] == b'IHDR':
        return struct.unpack('>II', data[16:24])
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        kind = data[12:16]
        if kind == b'VP8X':
            return (int.from_bytes(data[24:27], 'little') + 1, int.from_bytes(data[27:30], 'little') + 1)
        if kind == b'VP8L' and data[20:21] == b'\x2f':
            bits = int.from_bytes(data[21:25], 'little')
            return ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
        if kind == b'VP8 ' and data[23:26] == b'\x9d\x01\x2a':
            width, height = struct.unpack('<HH', data[26:30])
            return (width & 0x3FFF, height & 0x3FFF)
        return None
    if data[:2] == b'\xff\xd8':
        at = 2
        while at + 9 < len(data):
            if data[at] != 0xFF:
                return None
            marker = data[at + 1]
            length = struct.unpack('>H', data[at + 2:at + 4])[0]
            if marker in (0xC0, 0xC1, 0xC2):
                height, width = struct.unpack('>HH', data[at + 5:at + 9])
                return (width, height)
            at += 2 + length
    return None


def fit(url, collection=False):
    """The box for this logo: 'h88' and so on, 'canvas', or '' while its size is not known."""
    if not url:
        return ''
    size = _load().get(url)
    if not size:
        return ''
    width, height = size
    if not width or not height:
        return ''
    ratio = float(width) / height
    if collection and 1.70 <= ratio <= 1.82:
        return CANVAS                # Nuvio's title canvases; a film's logo is never this shape
    wanted = (AREA / ratio) ** .5
    return 'h%d' % min(HEIGHTS, key=lambda h: abs(h - wanted))


def missing(urls):
    known = _load()
    return [u for u in dict.fromkeys(urls) if u and u.startswith(('http://', 'https://')) and u not in known
            and u not in _unreached]


def learn(urls, stopped=None):
    """Read the sizes not known yet (first bytes only) and keep them. Returns how many."""
    todo = missing(urls)
    found = {}
    for url in todo:
        if stopped and stopped():
            break
        try:
            request = Request(url, headers={'Range': 'bytes=0-%d' % (HEAD - 1), 'User-Agent': 'MegaNexus/8'})
            with urlopen(request, timeout=TIMEOUT) as response:
                size = dims(response.read(HEAD))
        except Exception:
            _unreached.add(url)                        # kept only for this run, not for good
            continue
        found[url] = list(size) if size else [0, 0]   # a picture that cannot be measured is not asked again
    if found:
        with _lock:
            known = _load()
            known.update(found)
            try:
                from .meganexus.json_files import write_json
                write_json(_path(), known)
            except Exception:
                pass
    return len(found)
