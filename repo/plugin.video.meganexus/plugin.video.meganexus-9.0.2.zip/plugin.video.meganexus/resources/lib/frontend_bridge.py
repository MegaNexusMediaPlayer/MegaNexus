# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Launch the independent UI. The backend never loads a legacy presentation window."""
import xbmc
import xbmcgui


def open_home(settings=False, repair=False):
    """Opening the video add-on (also by mistake, before "Install") does the
    whole first start: install the interface, skin and screensaver, switch to
    the MegaNexus skin, then open MegaNexus (its first start offers setup)."""
    from .bundle_installer import ensure_components, outdated, paths
    busy=None
    try:
        packages,addons_dir=paths()
        if repair or outdated(packages,addons_dir):
            busy=xbmcgui.DialogProgressBG()
            busy.create('MegaNexus','Installing the interface, skin and screensaver...')
        ensure_components(force=repair)
    except Exception as exc:
        if busy:busy.close();busy=None
        xbmcgui.Dialog().ok('MegaNexus installation',str(exc))
        return
    finally:
        if busy:busy.close()
    import xbmcaddon
    addon=xbmcaddon.Addon('plugin.video.meganexus')
    from . import skin_activation
    # 6.0.33: checked at every entry, not only the first one - Kodi can lose the
    # skin (killed before saving, or an update it had not finished loading).
    # "No" in Kodi's keep-skin question is respected for this session.
    if skin_activation.wanted(addon):
        try:status=skin_activation.switch(addon)
        except Exception as exc:
            xbmc.log('[MegaNexus] Skin switch failed: %s'%exc,xbmc.LOGWARNING);status='failed'
        if status=='failed':skin_activation.report_failure()
        elif status=='declined':skin_activation.tell_needed()   # 7.0.51: No - the install stops here, said once
        # 7.0: the skin is required - MegaNexus (and its first-start setup)
        # opens only after Kodi's "Keep this skin?" was answered with Yes.
        if status!='ok' or xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):return
    xbmc.executebuiltin('RunScript(script.meganexus%s)'%(',settings' if settings else ''))


def open_context(context):
    from .meganexus import keyed_cache
    allowed=('media_type','canonical_id','title','video_id','season','episode','resume_seconds','resume_percent')
    context={key:context[key] for key in allowed if context.get(key) not in (None,'')}
    key=keyed_cache.put('meganexus_open',context)
    xbmc.executebuiltin('RunScript(script.meganexus,open,%s)'%key)


def legacy_streams(**context):
    return open_context(context)
