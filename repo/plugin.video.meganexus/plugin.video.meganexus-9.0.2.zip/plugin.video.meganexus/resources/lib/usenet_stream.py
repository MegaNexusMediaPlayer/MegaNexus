# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Plays NZB sources in Kodi (7.0.43).

A stream add-on can give a source as `nzbUrl` + `servers` (Usenet Streamer's
native mode; what Stremio v5 plays with its own Usenet client). Kodi cannot, so:

* register(row) - from any MegaNexus process - keeps the NZB link and the servers
  in the profile (usenet/<token>.json, never in a URL or the log) and gives Kodi
  http://127.0.0.1:<port>/usenet/<token>/<name>;
* the service runs this local server (start / stop). On the first request it reads
  the NZB, finds the film - a plain video file, or a film stored (not compressed)
  in RAR volumes, also with obfuscated names - and answers Kodi's range requests
  from the articles, several connections at once, reading ahead of the player.

The servers are the source's own (`servers`) and the user's Usenet server (HUB
HUB Settings > Debrid & Usenet > Usenet > Usenet server), as a backup for articles
the first one lacks. A missing article is read as zeros (a short glitch, not a
stop). Compressed, encrypted and 7z releases can not be streamed - they say so.
"""
import hashlib
import itertools
from concurrent.futures import TimeoutError as FutureTimeout
import json
import os
import queue
import threading
import time
from collections import OrderedDict
from concurrent.futures import Future
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote
from urllib.request import Request, urlopen

from . import usenet_nntp as nntp

PROP_PORT = 'meganexus.usenet.port'
SETTING = 'usenet_server'               # the user's own server (nntps://user:pass@host:563/10)
CACHE_PARTS = 64                        # decoded articles kept (~48 MB; 7.0.50: was 40)
AHEAD = 40                              # articles read ahead of the player (7.0.50: was 24 - 6 s at 25 Mbit/s)
# 7.0.51: by the device's memory (HUB Settings > RAM): (articles kept, read ahead) - as
# NuvioTV's engine (32 / 64 / 128 MiB budgets); 750 KB articles
BY_RAM = {'ram128': (32, 20), 'ram256': (64, 40), 'ram512': (100, 64)}
PIPELINE = 2                            # 7.0.51: BODY requests a connection sends before reading (SABnzbd's default)
WAIT_START = 30                         # 7.0.51: s an article of the film's start may take (the player needs it)
WAIT_PLAY = 12                          # ... later ones: then a gap (as a missing article) - not a long stall,
START_BYTES = 16 * 1024 * 1024          #     and Stop never waits a minute for one any more
WARM_BYTES = 3 * 1024 * 1024            # 7.0.51: the film's first and last 3 MB asked at once (MKV header, index)
REPORT_EVERY = 30                       # 7.0.50: seconds between the speed lines in the log
STOPPED_AFTER = 4                       # 7.0.51: s without a reader before the read-ahead is dropped
IDLE = 300                              # seconds before an unused source closes its connections
WAIT = 60                               # seconds an article may take
SNIFF_LIMIT = 400                       # obfuscated files whose first article is read
HEALTH_SAMPLES = 6                      # 7.0.45: articles through the film asked before it plays
HEALTH_WAIT = 20                        # ... seconds each may take (a slow answer is not counted as missing)
# 7.0.52: leaving a film is never held up (GitHub issue #13: 5 minutes on a TV box)
FLAG = 'meganexus.local_stream'         # Window(Home) while a film reads from this server (player_state)
LEAVING = 'meganexus.leaving'           # Window(Home) '1': the player is being stopped (OSD Stop, Back)
FLAG_HOLD = 30                          # s the flag stays after the last read: Kodi closes the film meanwhile
HALT = 3                                # s after "stopping": reads end at once and new ones are refused
SLICE = 0.25                            # s a read waits for an article before it looks for "stopping"
SEND_TIMEOUT = 20                       # s a write to Kodi may hang before the connection goes
# 7.0.52: set by the engine (usenet_engine.py: this server outside Kodi, on CoreELEC / Linux)
DECODE = None                           # yEnc on the other cores (a process pool)
NZB_DATA = None                         # the NZB, fetched by Kodi


def _log(text, level=None):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Usenet: %s' % text, xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


def _folder():
    from .meganexus.paths import profile_path
    path = os.path.join(profile_path(), 'usenet')
    os.makedirs(path, exist_ok=True)
    return path


def own_servers(addon=None):
    try:
        if addon is None:
            from .settings_snapshot import cached_addon
            addon = cached_addon()
        return [line for line in (addon.getSetting(SETTING) or '').split() if line.strip()]
    except Exception:
        return []


def servers_for(row):
    listed = row.get('servers') if isinstance(row.get('servers'), list) else []
    return [str(s) for s in listed if s] + own_servers()


def playable(row):
    """An nzbUrl row MegaNexus can play: a link and at least one server."""
    return bool(isinstance(row, dict) and row.get('nzbUrl') and servers_for(row))


def register(row):
    """The local link Kodi plays for an nzbUrl row, or ''."""
    servers = servers_for(row)
    url = str(row.get('nzbUrl') or '')
    if not url or not servers:
        return ''
    try:
        import xbmcgui
        port = xbmcgui.Window(10000).getProperty(PROP_PORT)
    except Exception:
        port = ''
    if not port:
        return ''
    token = hashlib.sha256(('%s|%s' % (url, '|'.join(servers))).encode('utf-8')).hexdigest()[:32]
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    name = os.path.basename(str(hints.get('filename') or 'video.mkv')) or 'video.mkv'
    if not os.path.splitext(name)[1].lower() in ('.mkv', '.mp4', '.m4v', '.avi', '.ts', '.m2ts', '.mov', '.webm'):
        name += '.mkv'                  # 7.0.45: an indexer's release name (no extension)
    path = os.path.join(_folder(), token + '.json')
    if not os.path.isfile(path):
        temp = path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump({'nzb': url, 'servers': servers, 'name': name, 'at': time.time()}, handle)
        try:
            os.chmod(temp, 0o600)
        except Exception:
            pass
        os.replace(temp, path)
    return 'http://127.0.0.1:%s/usenet/%s/%s' % (port, token, quote(name))


# --- articles ----------------------------------------------------------------

def limits():
    """(articles kept, read ahead) for this device's memory setting."""
    try:
        from .ram_profile import chosen, effective
        from .settings_snapshot import cached_addon
        return BY_RAM.get(effective(chosen(cached_addon())), (CACHE_PARTS, AHEAD))
    except Exception:
        return CACHE_PARTS, AHEAD


class Fetcher(object):
    """Articles from the servers in order (a missing one is asked from the next),
    `connections` threads each; decoded parts are cached."""

    def __init__(self, servers, keep=None):
        self.keep = keep or CACHE_PARTS
        self.servers = servers
        self.queues = [queue.PriorityQueue() for _ in servers]
        self.started = [False] * len(servers)
        self.dead = [False] * len(servers)
        self.lock = threading.RLock()
        self.cache = OrderedDict()
        self.flying = {}
        self.order = itertools.count()
        self.closed = False
        self.missing = 0
        self.refused = ''                                  # a server that refused the login
        self.fetched = 0                                   # 7.0.50: articles and bytes read, for the log
        self.bytes = 0
        self.reported = time.time()
        self.waited = self.worked = 0.0                    # 7.0.51: s waiting for the network / processing
        self.alive = [0] * len(servers)                    # 7.0.51: connections at work per server
        self.told_fewer = set()

    def get(self, message_id, priority=0):
        with self.lock:
            if message_id in self.cache:
                self.cache.move_to_end(message_id)
                done = Future()
                done.set_result(self.cache[message_id])
                return done
            future = self.flying.get(message_id)
            if future is not None and (priority >= future.priority or getattr(future, 'taken', False)
                                       or (priority > 0 and priority > future.priority // 2)):
                # 7.0.50: one being read is never queued again; 7.0.51: the read-ahead asks each
                # article again as the player nears it - queued again only when clearly sooner
                # (or needed now), not each time (21,000 stale copies piled up in 4 minutes)
                return future
            if future is None:
                future = Future()
                self.flying[message_id] = future
            future.priority = priority                     # asked again, sooner: queued again
            self._queue(0, (priority, next(self.order), message_id, future))
            return future

    def _queue(self, index, task):
        while index < len(self.servers) and self.dead[index]:
            index += 1
        if index >= len(self.servers):
            self._finish(task[2], task[3], None)
            return
        self.queues[index].put(task)
        if not self.started[index]:
            self.started[index] = True
            for _ in range(self.servers[index]['connections']):
                self.alive[index] += 1
                threading.Thread(target=self._work, args=(index,), name='MegaNexusUsenet', daemon=True).start()

    def _finish(self, message_id, future, value):
        with self.lock:
            self.flying.pop(message_id, None)
            if value is not None:
                self.cache[message_id] = value
                while len(self.cache) > self.keep:
                    self.cache.popitem(last=False)
            else:
                self.missing += 1
        if not future.done():
            try:
                future.set_result(value)
            except Exception:
                pass

    def _take(self, index, first):
        """The task and up to PIPELINE - 1 more waiting ones, each marked as being read."""
        batch, tasks = [], [first]
        while len(tasks) < PIPELINE:
            try:
                tasks.append(self.queues[index].get_nowait())
            except queue.Empty:
                break
        with self.lock:
            for task in tasks:
                future = task[3]
                # 7.0.50: a copy of a task asked again sooner - once one connection reads the
                # article, the others never read it too
                if future.done() or getattr(future, 'taken', False):
                    continue
                future.taken = True
                batch.append(task)
        return batch

    def _give_back(self, index, tasks, next_server=False):
        with self.lock:
            for task in tasks:
                task[3].taken = False
                if next_server:
                    self._queue(index + 1, task)
                else:
                    self.queues[index].put(task)

    def _work(self, index):
        try:
            self._serve(index)
        finally:
            with self.lock:
                self.alive[index] -= 1

    def _serve(self, index):
        server, connection, failures = self.servers[index], None, 0
        while not self.closed:
            try:
                first = self.queues[index].get(timeout=2)
            except queue.Empty:
                continue
            batch = self._take(index, first)
            if not batch:
                continue
            done = 0
            try:
                if connection is None:
                    connection = nntp.Connection(server)
                pipelined = hasattr(connection, 'send_body') and len(batch) > 1
                if pipelined:                              # 7.0.51: all requests out, then the answers
                    for task in batch:
                        connection.send_body(task[2])
                for task in batch:
                    message_id, future = task[2], task[3]
                    began = time.monotonic()
                    try:
                        body = connection.read_body(message_id) if pipelined else connection.body(message_id)
                    except nntp.Missing:
                        done += 1
                        self._give_back(index, [task], next_server=True)
                        continue
                    got = time.monotonic()
                    value = (DECODE or nntp.yenc_decode)(body)
                    done += 1
                    failures = 0
                    self._finish(message_id, future, value)
                    self._count(len(value[1]), got - began, time.monotonic() - got)
            except nntp.TooMany:
                # 7.0.51: the provider allows fewer at once - this connection goes, the others
                # read on (never the last one: it waits and tries again)
                self._give_back(index, batch[done:])
                if connection is not None:
                    connection.close()
                connection = None
                with self.lock:
                    last = self.alive[index] <= 1
                    if not last and index not in self.told_fewer:
                        self.told_fewer.add(index)
                        _log('%s allows fewer connections - %d at work'
                             % (nntp.server_label(server), self.alive[index] - 1))
                if not last:
                    return
                time.sleep(2)
            except nntp.AuthError as exc:
                _log('%s: %s' % (nntp.server_label(server), exc))
                self.refused = nntp.server_label(server)
                self.dead[index] = True
                self._give_back(index, batch[done:], next_server=True)
                with self.lock:
                    while True:                            # hand the rest on
                        try:
                            self._queue(index + 1, self.queues[index].get_nowait())
                        except queue.Empty:
                            break
                break
            except Exception as exc:
                if connection is not None:
                    connection.close()
                connection = None
                failures += 1
                left = batch[done:]
                if failures >= 3:
                    _log('%s: %s' % (nntp.server_label(server), type(exc).__name__))
                    self._give_back(index, left, next_server=True)
                    failures = 0
                    time.sleep(1)
                else:
                    self._give_back(index, left)
        if connection is not None:
            connection.close()

    def _count(self, size, waited=0.0, worked=0.0):
        """7.0.50: how fast the articles come, in the log every REPORT_EVERY seconds.
        7.0.51: and where the time goes - the network (more connections help) or this
        device's processing (a smaller release helps)."""
        with self.lock:
            self.fetched += 1
            self.bytes += size
            self.waited += waited
            self.worked += worked
            now = time.time()
            if now - self.reported < REPORT_EVERY:
                return
            took, fetched, size_read, missing = now - self.reported, self.fetched, self.bytes, self.missing
            spent = (self.waited + self.worked) or 1.0
            network, work = self.waited / spent, self.worked / spent
            self.reported, self.fetched, self.bytes, self.waited, self.worked = now, 0, 0, 0.0, 0.0
            waiting = sum(q.qsize() for q in self.queues)
            alive = sum(self.alive)
        _log('%.1f Mbit/s, %d articles in %.0f s, %d connections, network %d %% / processing %d %%, %d waiting, %d missing so far'
             % (size_read * 8 / took / 1e6, fetched, took, alive, round(network * 100), round(work * 100), waiting, missing))

    def drop_ahead(self):
        """7.0.51: the player stopped - the articles only read ahead are not fetched any more
        (the connections and the articles kept stay for a quick return)."""
        dropped = 0
        with self.lock:
            for waiting in self.queues:
                keep = []
                while True:
                    try:
                        task = waiting.get_nowait()
                    except queue.Empty:
                        break
                    future = task[3]
                    if task[0] > 0 and not getattr(future, 'taken', False) and not future.done():
                        if self.flying.get(task[2]) is future:
                            del self.flying[task[2]]
                            future.cancel()
                            dropped += 1
                    elif not future.done():
                        keep.append(task)
                for task in keep:
                    waiting.put(task)
        return dropped

    def close(self):
        self.closed = True


# --- the film inside the NZB ---------------------------------------------------

class Source(object):
    """One NZB: where the film's bytes lie (extents over the NZB's files)."""
    token = ''                                             # 7.0.52: its link's token (halted)

    def __init__(self, data, servers):
        self.keep, self.ahead = limits()
        self.fetcher = Fetcher(servers, self.keep)
        self.files = [f for f in nntp.parse_nzb(data) if f.segments]
        self.extents = []                                  # (nzb file, offset in it, length)
        self.size = 0
        self.name = ''
        self.used = time.time()
        self._layout()

    # first articles
    def _head(self, nzb_file):
        if nzb_file.head is None:
            value = self.fetcher.get(nzb_file.segments[0]).result(WAIT)
            if value is None:
                if self.fetcher.refused and all(self.fetcher.dead):
                    raise nntp.AuthError('%s refused the login' % self.fetcher.refused)
                raise nntp.NntpError('the first article of a file is missing')
            begin, data, size, name = value
            nzb_file.head = data
            nzb_file.size = size or len(data)
            nzb_file.part_size = len(data) if len(nzb_file.segments) > 1 else nzb_file.size
            if name and not nzb_file.name:
                nzb_file.name = name
                nzb_file.kind = nntp.kind_of_name(name)
        return nzb_file.head

    def check(self, samples=None):
        """7.0.45: a few articles spread through the film, asked over the connections the
        player opens anyway (no extra one - providers limit them): when most are gone
        the release is incomplete on these servers and another source is better
        (Autoplay goes on to the next). Returns (missing, asked)."""
        samples = samples or HEALTH_SAMPLES
        ids, seen = [], set()
        for nzb_file, _, _ in self.extents:
            if id(nzb_file) not in seen:
                seen.add(id(nzb_file))
                ids.extend(nzb_file.segments[1:])
        if not ids:
            return 0, 0
        step = max(1, len(ids) // samples)
        picked = ids[step // 2::step][:samples]
        futures = [self.fetcher.get(message_id, priority=-1) for message_id in picked]
        missing = answered = 0
        for future in futures:
            try:
                value = future.result(HEALTH_WAIT)
            except Exception:
                continue                 # a slow server is no proof of a gap: not counted
            answered += 1
            missing += value is None     # every server said the article is not there
        # only a release the servers clearly lack is refused - what played in 7.0.43 still plays
        if answered and missing * 2 > len(picked):
            raise nntp.NntpError('this release is incomplete on your Usenet server (%d of %d parts gone)' % (missing, len(picked)))
        return missing, len(picked)

    def _heads(self, files):
        for nzb_file in files:
            if nzb_file.head is None:
                self.fetcher.get(nzb_file.segments[0], priority=-1)
        for nzb_file in files:
            self._head(nzb_file)

    def _layout(self):
        files = self.files
        if not files:
            raise nntp.NntpError('empty NZB')
        biggest = max(f.bytes for f in files)
        named = [f for f in files if f.kind in ('video', 'rar', '7z')]
        if not named or max(f.bytes for f in named) < biggest * 0.5:
            # obfuscated names: what the first article of every big file is
            unknown = sorted((f for f in files if f.kind not in ('extra',) and f.bytes >= biggest * 0.05),
                             key=lambda f: f.bytes, reverse=True)[:SNIFF_LIMIT]
            self._heads(unknown)
            for nzb_file in unknown:
                nzb_file.kind = nntp.sniff(nzb_file.head) or nzb_file.kind
        videos = [f for f in files if f.kind == 'video']
        rars = [f for f in files if f.kind == 'rar']
        rar_bytes = sum(f.bytes for f in rars)
        if videos and max(f.bytes for f in videos) >= rar_bytes:
            film = max(videos, key=lambda f: f.bytes)
            self._head(film)
            self.extents = [(film, 0, film.size)]
            self.size, self.name = film.size, film.name
            return
        if rars:
            self._rar(rars)
            return
        if any(f.kind == '7z' for f in files):
            raise nntp.Unsupported('7z archive')
        raise nntp.NntpError('no video in the NZB')

    def _rar(self, rars):
        """The biggest RAR set; volumes in order; the stored film's extents."""
        sets = {}
        for nzb_file in rars:
            base = _rar_base(nzb_file.name) if nzb_file.name and nntp.kind_of_name(nzb_file.name) == 'rar' else ''
            sets.setdefault(base, []).append(nzb_file)
        volumes = max(sets.values(), key=lambda group: sum(f.bytes for f in group))
        if all(f.head is not None for f in volumes) or not all(nntp.kind_of_name(f.name) == 'rar' for f in volumes):
            self._heads(volumes)
            infos = {id(f): nntp.rar_volume(f.head) for f in volumes}
            volumes.sort(key=lambda f: (_volume_number(infos[id(f)], f), f.index, self.files.index(f)))
            self._exact(volumes, infos)
            return
        volumes.sort(key=lambda f: _name_order(f.name))
        # named volumes: the first, second and last say where the film lies in all
        # of them (RAR cuts every volume to the same size); checked by the total
        ends = [volumes[0]] + ([volumes[1]] if len(volumes) > 2 else []) + ([volumes[-1]] if len(volumes) > 1 else [])
        self._heads(ends)
        first = _film(nntp.rar_volume(volumes[0].head))
        if len(volumes) == 1:
            self._set([(volumes[0], first['offset'], first['length'])], first)
            return
        last = _film(nntp.rar_volume(volumes[-1].head), continued=True)
        middle = _film(nntp.rar_volume(volumes[1].head), continued=True) if len(volumes) > 2 else last
        total = first['length'] + middle['length'] * (len(volumes) - 2) + last['length']
        if total != first['size']:
            self._heads(volumes)
            self._exact(volumes, {id(f): nntp.rar_volume(f.head) for f in volumes})
            return
        extents = [(volumes[0], first['offset'], first['length'])]
        extents += [(v, middle['offset'], middle['length']) for v in volumes[1:-1]]
        extents.append((volumes[-1], last['offset'], last['length']))
        for nzb_file in volumes:                          # sizes of the files not read yet
            if not nzb_file.part_size:
                nzb_file.part_size = volumes[1].part_size
        self._set(extents, first)

    def _exact(self, volumes, infos):
        first = _film(infos[id(volumes[0])])
        extents = [(volumes[0], first['offset'], first['length'])]
        for nzb_file in volumes[1:]:
            part = _film(infos[id(nzb_file)], continued=True)
            extents.append((nzb_file, part['offset'], part['length']))
        self._set(extents, first)

    def _set(self, extents, film):
        self.extents = [e for e in extents if e[2] > 0]
        self.size = sum(e[2] for e in self.extents)
        self.name = film['name']
        if film['size'] and self.size > film['size']:
            self.size = film['size']

    # reading
    def _locate(self, position):
        for nzb_file, offset, length in self.extents:
            if position < length:
                return nzb_file, offset + position
            position -= length
        return None, 0

    def _part(self, nzb_file, offset):
        part = nzb_file.part_size or 1
        return min(offset // part, len(nzb_file.segments) - 1)

    _readers_lock = threading.Lock()                   # 7.0.59: Kodi reads with two connections on a jump

    def read(self, start, end, write):
        """Bytes start..end (inclusive) to write(); reads ahead."""
        with self._readers_lock:
            self.readers = getattr(self, 'readers', 0) + 1
        _flag(True)
        try:
            self._read(start, end, write)
        finally:
            with self._readers_lock:
                self.readers -= 1
                left = self.readers
            _flag(False)
            if not left:
                # 7.0.51: no player reads any more (stopped - or seeking: the next request
                # comes within a moment): the read-ahead goes after STOPPED_AFTER seconds
                stamp = self.stopped_at = time.monotonic()
                timer = threading.Timer(STOPPED_AFTER, self._stopped, args=(stamp,))
                timer.daemon = True
                timer.start()

    def _stopped(self, stamp):
        if not getattr(self, 'readers', 0) and getattr(self, 'stopped_at', None) == stamp:
            dropped = self.fetcher.drop_ahead()
            if dropped:
                _log('player stopped - %d articles read ahead not fetched' % dropped)

    def _read(self, start, end, write):
        position = start
        while position <= end:
            self.used = time.time()
            nzb_file, offset = self._locate(position)
            if nzb_file is None:
                return
            index = self._part(nzb_file, offset)
            self._ahead(position, nzb_file.part_size)
            part = nzb_file.part_size or 1
            wait = WAIT_START if position < START_BYTES else WAIT_PLAY
            for _ in range(4):                             # parts of another size: find the right one
                try:
                    value = self._wait(self.fetcher.get(nzb_file.segments[index], priority=0), wait)
                except FutureTimeout:
                    value = None                           # 7.0.51: too slow - a gap, the film goes on
                    _log('an article took over %d s - skipped' % wait)
                if halted(self.token):
                    return                                 # 7.0.52: the player is leaving
                if value is None:
                    data, begin = b'\x00' * part, index * part
                else:
                    begin, data = value[0], value[1]
                if not data:
                    return
                if offset < begin and index > 0:
                    index = max(0, index - 1 - (begin - offset) // part)
                elif offset >= begin + len(data) and index < len(nzb_file.segments) - 1:
                    index = min(len(nzb_file.segments) - 1, index + 1 + (offset - begin - len(data)) // part)
                else:
                    break
            skip = offset - begin
            if skip < 0 or skip >= len(data):
                return
            chunk = data[skip:skip + (end - position + 1)]
            extent_left = self._extent_left(position)
            chunk = chunk[:extent_left]
            if not chunk:
                return
            write(chunk)
            position += len(chunk)

    def _wait(self, future, wait):
        """7.0.52: future.result(wait), but a player that is leaving never waits for it."""
        until = time.monotonic() + wait
        while True:
            left = until - time.monotonic()
            try:
                return future.result(min(SLICE, max(0.0, left)))
            except FutureTimeout:
                if halted(self.token) or _leaving():
                    return None
                if left <= SLICE:
                    raise

    def _extent_left(self, position):
        for _, _, length in self.extents:
            if position < length:
                return length - position
            position -= length
        return 0

    def _ahead(self, position, part):
        step = max(part or 0, 256 * 1024)
        for n in range(1, getattr(self, 'ahead', AHEAD) + 1):
            nzb_file, offset = self._locate(position + n * step)
            if nzb_file is None:
                break
            self.fetcher.get(nzb_file.segments[self._part(nzb_file, offset)], priority=n)

    def warm(self):
        """7.0.51 ("Fast MKV startup"): the film's first and last WARM_BYTES asked at once - Kodi
        reads the header and then the index at the end before the first picture."""
        if not self.size:
            return
        for start in (0, max(0, self.size - WARM_BYTES)):
            position, seen = start, set()
            while position < min(self.size, start + WARM_BYTES):
                nzb_file, offset = self._locate(position)
                if nzb_file is None:
                    break
                index = self._part(nzb_file, offset)
                if (id(nzb_file), index) not in seen:
                    seen.add((id(nzb_file), index))
                    self.fetcher.get(nzb_file.segments[index], priority=1)
                position += max(nzb_file.part_size or 0, 256 * 1024)

    def close(self):
        self.fetcher.close()


def _rar_base(name):
    import re
    low = name.lower()
    return re.sub(r'(\.part\d+)?\.rar$|\.r\d{2,3}$|\.\d{3}$', '', low)


def _name_order(name):
    import re
    low = (name or '').lower()
    part = re.search(r'\.part(\d+)\.rar$', low)
    if part:
        return int(part.group(1))
    if low.endswith('.rar'):
        return -1
    old = re.search(r'\.([r-z])(\d{2,3})$', low)
    if old:
        return (ord(old.group(1)) - ord('r')) * 1000 + int(old.group(2))
    number = re.search(r'\.(\d{3})$', low)
    return int(number.group(1)) if number else 10 ** 6


def _volume_number(info, nzb_file):
    if info.get('volume') is not None:
        return info['volume']
    return 0 if info.get('first') else 1 + (_name_order(nzb_file.name) if nzb_file.name else 0)


def _film(info, continued=False):
    """The film's entry in a volume (the biggest video, or the continued file)."""
    files = info.get('files') or []
    if continued:
        files = [f for f in files if f['before']] or files
    else:
        videos = [f for f in files if f['name'].lower().endswith(nntp.VIDEO_EXT)]
        files = videos or files
    if not files:
        raise nntp.NntpError('no file in the RAR volume')
    film = max(files, key=lambda f: f['size'])
    if not film['stored']:
        raise nntp.Unsupported('compressed RAR')
    return film


# --- the local server ----------------------------------------------------------

_SOURCES = {}
_OPENING = {}
_LOCK = threading.Lock()
_server = None
_STOP = threading.Event()
_HALT = {'until': 0.0, 'tokens': set()}
_READING = {'count': 0, 'timer': None}


def halted(token=None):
    """The film(s) playing when Stop came are closing (another film may start at once)."""
    return time.monotonic() < _HALT['until'] and (token is None or token in _HALT['tokens'])


def _leaving():
    """7.0.52: MegaNexus' Stop (OSD button, Back) said so - read while a read waits only."""
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        if home.getProperty(LEAVING) != '1':
            return False
        home.clearProperty(LEAVING)
    except Exception:
        return False
    _log('the player is stopping - reads end now')
    halt()
    return True


def _clear_leaving():
    try:
        import xbmcgui
        xbmcgui.Window(10000).clearProperty(LEAVING)
    except Exception:
        pass


def halt():
    """7.0.52: the player is about to stop (MegaNexus leaves the film): every read ends at once
    and Kodi's new requests are refused for HALT seconds - Kodi closes the film without
    waiting for an article. The read-ahead goes too; the connections stay."""
    with _LOCK:
        sources = list(_SOURCES.values())
        _HALT['tokens'] = set(_SOURCES)
    _HALT['until'] = time.monotonic() + HALT
    for source in sources:
        try:
            source.fetcher.drop_ahead()
        except Exception:
            pass


def _flag(reading):
    """7.0.52: Window(Home) FLAG while Kodi reads a film from here, FLAG_HOLD s longer: the
    MegaNexus Player then asks Kodi through JSON-RPC (player_state), which never holds Python."""
    with _LOCK:
        _READING['count'] += 1 if reading else -1
        count = _READING['count']
        timer, _READING['timer'] = _READING['timer'], None
    if timer is not None:
        timer.cancel()
    if count > 0:
        _set_flag(str(time.time()))
    else:
        timer = threading.Timer(FLAG_HOLD, _flag_off)
        timer.daemon = True
        with _LOCK:
            _READING['timer'] = timer
        timer.start()


def _flag_off():
    with _LOCK:
        if _READING['count'] > 0:
            return
        _READING['timer'] = None
    _set_flag('')


def _set_flag(value):
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        if value:
            if not home.getProperty(FLAG):
                home.setProperty(FLAG, value)
        else:
            home.clearProperty(FLAG)
    except Exception:
        pass


def _source(token):
    with _LOCK:
        found = _SOURCES.get(token)
        opening = _OPENING.setdefault(token, threading.Lock())
    if found is not None:
        return found
    with opening:                                         # Kodi's parallel first requests: one opening
        with _LOCK:
            found = _SOURCES.get(token)
        if found is not None:
            return found
        return _open(token)


def prepare(token):
    """The source of a link: the NZB read, the film found in it, a few articles through it asked
    (an incomplete release says so). (path of its .json, what was saved, Source, servers)."""
    path = os.path.join(_folder(), os.path.basename(token) + '.json')
    with open(path, encoding='utf-8') as handle:
        saved = json.load(handle)
    servers = [s for s in (nntp.parse_server(v) for v in saved.get('servers') or []) if s]
    if not servers:
        raise nntp.NntpError('no Usenet server')
    data = (NZB_DATA or nzb_data)(token, saved, servers)
    started = time.time()
    found = Source(data, servers)
    found.token = token
    try:
        missing, asked = found.check()
    except Exception:
        found.fetcher.close()
        raise
    _log('ready in %.1f s: %d files, film %.2f GB, %d of %d sample parts there · %d connections, keep %d, ahead %d'
         % (time.time() - started, len(found.files), found.size / 1e9, asked - missing, asked,
            sum(s['connections'] for s in servers), found.keep, found.ahead))
    return path, saved, found, servers


def _open(token):
    path, saved, found, servers = prepare(token)
    found.warm()
    with _LOCK:
        _SOURCES[token] = found
    if not saved.get('size'):
        _remember(path, saved, found)
    return found


def nzb_data(token, saved, servers):
    """The NZB itself (in Kodi: the indexer's daily downloads are counted here; the engine
    asks Kodi for it, NZB_DATA)."""
    from . import newznab
    if saved['nzb'].startswith('spotnet:'):
        # 7.0.45: a Spotnet spot - its NZB is on Usenet too, read with the user's server
        from . import spotnet
        return spotnet.nzb(saved['nzb'][len('spotnet:'):], servers)
    counted = newznab.is_indexer(saved['nzb'])          # 7.0.45: an indexer's NZB counts as a grab
    if counted and not newznab.allowed(saved['nzb'], 'grab'):
        raise nntp.NntpError("the indexer's NZB downloads for today are used up")
    request = Request(saved['nzb'], headers={'User-Agent': 'MegaNexus'})
    data = urlopen(request, timeout=30).read(64 * 1024 * 1024)
    if counted:
        newznab.note(saved['nzb'], 'grab')
    return data


def _remember(path, saved, found):
    """7.0.52: the film's size and name kept with the source: Kodi asks for them (HEAD) when it
    closes the film, and a source already closed answers without opening the NZB again."""
    try:
        saved = dict(saved, size=found.size, film=found.name or '')
        temp = path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(saved, handle)
        os.replace(temp, path)
    except Exception:
        pass


class _Known(object):
    """A closed source's remembered size (HEAD only)."""

    def __init__(self, size, name):
        self.size, self.name = size, name


def _known(token):
    with _LOCK:
        found = _SOURCES.get(token)
    if found is not None:
        return found
    try:
        with open(os.path.join(_folder(), os.path.basename(token) + '.json'), encoding='utf-8') as handle:
            saved = json.load(handle)
    except Exception:
        return None
    return _Known(int(saved['size']), saved.get('film') or '') if saved.get('size') else None


def _content_type(name):
    low = name.lower()
    for ext, kind in (('.mp4', 'video/mp4'), ('.m4v', 'video/mp4'), ('.avi', 'video/x-msvideo'), ('.webm', 'video/webm'),
                      ('.ts', 'video/mp2t'), ('.m2ts', 'video/mp2t'), ('.mov', 'video/quicktime')):
        if low.endswith(ext):
            return kind
    return 'video/x-matroska'


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    timeout = SEND_TIMEOUT              # 7.0.52: a write Kodi no longer reads ends the connection

    def log_message(self, *args):
        pass

    def send_header(self, keyword, value):
        if keyword.lower() != 'connection':
            BaseHTTPRequestHandler.send_header(self, keyword, value)

    def end_headers(self):
        # 7.0.52: one request per connection - Kodi never sends a request on a connection
        # whose last answer is still being written
        BaseHTTPRequestHandler.send_header(self, 'Connection', 'close')
        self.close_connection = True
        BaseHTTPRequestHandler.end_headers(self)

    def do_HEAD(self):
        self._serve(False)

    def do_GET(self):
        self._serve(True)

    def _serve(self, body):
        parts = self.path.split('?', 1)[0].strip('/').split('/')
        if len(parts) < 2 or parts[0] != 'usenet':
            self.send_error(404)
            return
        if body:
            if halted(parts[1]):
                self.send_error(503)                       # 7.0.52: Kodi is closing the film
                return
            _clear_leaving()                               # a Stop that found no read waiting
        try:
            source = _source(parts[1]) if body else (_known(parts[1]) or _source(parts[1]))
        except nntp.Unsupported as exc:
            _log('can not stream this release: %s' % exc)
            self.send_error(415, str(exc))
            return
        except Exception as exc:
            _log('could not open the NZB: %s %s' % (type(exc).__name__, str(exc)[:80]))
            self.send_error(502)
            return
        size = source.size
        start, end = 0, size - 1
        ranged = self.headers.get('Range', '')
        if ranged.startswith('bytes='):
            first, _, last = ranged[6:].split(',')[0].partition('-')
            try:
                if first:
                    start = int(first)
                    end = int(last) if last else size - 1
                else:
                    start = max(0, size - int(last))
            except ValueError:
                pass
            end = min(end, size - 1)
            if start > end:
                self.send_response(416)
                self.send_header('Content-Range', 'bytes */%d' % size)
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            self.send_response(206)
            self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, size))
        else:
            self.send_response(200)
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Type', _content_type(source.name or parts[-1]))
        self.send_header('Content-Length', str(end - start + 1))
        self.end_headers()
        if body:
            try:
                source.read(start, end, self.wfile.write)
            except (BrokenPipeError, ConnectionResetError):
                pass                                       # the player seeked or stopped
            except Exception as exc:
                _log('read stopped: %s' % type(exc).__name__)


def _sweep():
    while not _STOP.wait(60):
        now = time.time()
        with _LOCK:
            old = [t for t, s in _SOURCES.items() if now - s.used > IDLE]
            for token in old:
                _SOURCES.pop(token).close()
                _OPENING.pop(token, None)
        try:                                               # saved sources older than two days
            folder = _folder()
            for name in os.listdir(folder):
                path = os.path.join(folder, name)
                if now - os.path.getmtime(path) > 2 * 86400:
                    os.remove(path)
        except Exception:
            pass


def start():
    """The service starts the server on 127.0.0.1 and publishes its port."""
    global _server
    if _server is not None:
        return
    _STOP.clear()
    try:
        _server = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
        _server.daemon_threads = True
    except Exception as exc:
        _log('server not started: %s' % exc)
        _server = None
        return
    threading.Thread(target=_server.serve_forever, name='MegaNexusUsenetServer', daemon=True).start()
    threading.Thread(target=_sweep, name='MegaNexusUsenetSweep', daemon=True).start()
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty(PROP_PORT, str(_server.server_address[1]))
    except Exception:
        pass


def stop():
    global _server
    server, _server = _server, None
    _STOP.set()
    try:
        import xbmcgui
        xbmcgui.Window(10000).clearProperty(PROP_PORT)
    except Exception:
        pass
    if server is not None:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
    with _LOCK:
        for source in _SOURCES.values():
            source.close()
        _SOURCES.clear()


TRIES = ((563, True), (443, True), (119, False))     # 7.0.43: the usual NNTP ports, SSL first


def detect(host, user, password, connections=10, port=None):
    """(server address 'nntps://...', reason) - finds the port and SSL by itself:
    a typed port with and without SSL, else 563 / 443 SSL, then 119. reason is ''
    when the login works; a wrong login keeps the port it reached."""
    import socket
    from urllib.parse import quote
    auth = '%s:%s@' % (quote(user, safe=''), quote(password, safe='')) if user else ''
    tries = ((port, True), (port, False)) if port else TRIES
    first = None
    for number, secure in tries:
        value = '%s://%s%s:%s/%s' % ('nntps' if secure else 'nntp', auth, host, number, connections)
        first = first or value
        server = nntp.parse_server(value)
        try:
            nntp.Connection(server, timeout=6).close()
            return value, ''
        except nntp.AuthError:
            return value, 'login refused - check the username and password'
        except socket.gaierror:
            return value, 'address %s not found - check the spelling' % host
        except Exception:
            continue
    return first, 'no Usenet server answered on %s' % ('port %s' % port if port else 'ports 563, 443 or 119')


def check(value):
    """Log in to a server ('nntps://...'): '' when it works, else why not."""
    server = nntp.parse_server(value)
    if not server:
        return 'not a server address'
    try:
        nntp.Connection(server, timeout=10).close()
        return ''
    except nntp.AuthError:
        return 'login refused'
    except OSError as exc:
        import socket
        if isinstance(exc, socket.gaierror):
            return 'address %s not found - check the spelling' % server['host']
        if isinstance(exc, (socket.timeout, ConnectionRefusedError)):
            return 'no answer on port %s - check the port and SSL' % server['port']
        return type(exc).__name__
    except Exception as exc:
        return type(exc).__name__
