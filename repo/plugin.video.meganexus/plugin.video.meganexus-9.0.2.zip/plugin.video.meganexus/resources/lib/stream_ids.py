# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The ids a title is asked for at the add-ons.

A title gets every id it has as an add-on spells it ('tt…', 'imdb:tt…', 'tmdb:…', 'tvdb:…',
'kitsu:…' and so on); for an episode each also with ':season:episode'. An add-on is then given
the ones its manifest says it understands, IMDb before TMDB before TVDB, an episode's own
id before the show's."""
import re

from .card_art import extract_ids

ANIME_KEYS = ('kitsu_id', 'anilist_id', 'anidb_id', 'mal_id')
# the start of an externalIds key -> the add-on prefix
EXTERNAL = (('tmdb', 'tmdb'), ('tvdb', 'tvdb'), ('anidb', 'anidb'), ('kitsu', 'kitsu'), ('anilist', 'anilist'))
# the order an add-on is asked in (an episode's id just before its show's)
RANK = ('tt', 'imdb:tt', 'tmdb:', 'tvdb:')


def unique(values):
    """Non-empty texts, each once, in order."""
    seen, out = set(), []
    for value in values:
        text = str(value or '').strip()
        if text and text not in seen:
            seen.add(text)
            out.append(text)
    return out


def from_canonical(cid):
    """The id a canonical id names: 'tmdb:123', 'tvdb:123' or 'tt1234567'."""
    tail = cid.rpartition(':')[2]
    if cid.startswith('tmdb:') and tail.isdigit():
        return {'tmdb_id': tail}
    if cid.startswith('tvdb:') and tail.isdigit():
        return {'tvdb_id': tail}
    if re.match(r'^tt\d{5,10}$', cid, re.I):
        return {'imdb_id': cid}
    return {}


def _imdb_pair(value):
    value = value if value.startswith('tt') else 'tt' + value
    return [value, 'imdb:' + value]


def candidates(canonical_id, meta=None, season=None, episode=None, with_episodes=False):
    meta = meta or {}
    ids = extract_ids(meta)
    found = [canonical_id]
    if ids.get('imdb_id'):
        found += [ids['imdb_id'], 'imdb:%s' % ids['imdb_id']]
    found += ['%s:%s' % (name, ids[name + '_id']) for name in ('tmdb', 'tvdb') if ids.get(name + '_id')]
    found += ['%s:%s' % (key[:-3], meta[key]) for key in ANIME_KEYS if meta.get(key)]
    external = meta.get('externalIds') or {}
    for key, value in (external.items() if isinstance(external, dict) else ()):
        if not value:
            continue
        key, value = str(key).lower(), str(value)
        if key.startswith('imdb'):
            found += _imdb_pair(value)
        else:
            found += ['%s:%s' % (prefix, value) for start, prefix in EXTERNAL if key.startswith(start)][:1]
    if with_episodes and season and episode:
        tail = ':%s:%s' % (int(season), int(episode))
        found = [cid + tail for cid in found if ':' in cid or cid.lower().startswith('tt')] + found
    return unique(found)


def id_prefixes(provider, media_type=None):
    """The id prefixes the add-on's stream resource names ([] = any id)."""
    for resource in ((provider or {}).get('manifest') or {}).get('resources', []) or []:
        if resource == 'stream':
            return []
        if isinstance(resource, dict) and resource.get('name') == 'stream':
            types = resource.get('types') or []
            if not (media_type and types and media_type not in types):
                return [str(x).lower() for x in (resource.get('idPrefixes') or []) if str(x or '').strip()]
    return []


def matching(ids, prefixes):
    prefixes = tuple(str(p or '').lower() for p in (prefixes or []) if str(p or '').strip())
    if not prefixes:
        return list(ids or [])
    return [cid for cid in ids or [] if str(cid or '').lower().startswith(prefixes)]


def ordered(ids, season=None, episode=None):
    try:
        tail = ':%s:%s' % (int(season), int(episode)) if season and episode else ''
    except Exception:
        tail = ''

    def place(value):
        text = str(value or '').lower()
        for spot, start in enumerate(RANK):
            if text.startswith(start):
                return (spot * 2 + (0 if tail and text.endswith(tail) else 1), text)
        return (len(RANK) * 2, text)
    return sorted(list(ids or []), key=place)
