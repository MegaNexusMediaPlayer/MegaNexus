# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Changing which address Kodi gets our pictures at, and clearing out the one it leaves.

A poster has two possible addresses: mnxart://i/<address> (vfs.meganexus 1.1.0, C++, no
port, no Python) and http://127.0.0.1:<port>/image?url=... (the image proxy). Kodi's
texture cache is keyed on the address itself, so a poster asked for both ways is kept
twice on the disk. That is not a theory: one machine held 47,312 pictures of which 39,212
were the same library over and over.

So one path is live at a time, and changing it is a job rather than a setting. The job
cannot be left half done:

  * it is written down (SWITCH_FILE) before a single row is touched, so a Kodi that is
    closed, killed or crashes in the middle picks it up again at its next start;
  * the rows go in ONE SQL transaction per database - every row of the path being left,
    or none of them, never some;
  * the thumbnail files of those rows are listed in that same file and removed from the
    list as they go, so a resume neither repeats work nor leaves orphans behind.

Why SQL and not Kodi: removing thousands of textures through Textures.RemoveTexture takes
one round trip each (~40,000 of them on the machine above) and doing it while Kodi draws
closed Kodi - 8.1.0 turned saver.CLEAN_OLD off for exactly that. Direct SQL is one
statement. Kodi tolerates it because in the path being left those rows are dead weight:
nothing asks for those addresses any more. If the database will not open or stays locked,
the job falls back to Kodi's own way and simply takes longer - it still finishes, because
the written-down job outlives the attempt.
"""
import json
import os
import sqlite3
import time
from pathlib import Path

from . import art_cache

SWITCH_FILE = 'art_switch.json'
DECIDED = 'meganexus_art_path_decided'   # '1' once the first start has read the cache (adopt)
BUSY_WAIT = 10.0        # s a locked texture database gets before the slow way is used instead
SQL_CHUNK = 500         # ids per DELETE ... IN (...) - sqlite's variable limit is 999
RPC_BATCH = 40          # 8.1.0: textures per round of the fallback
FILE_REPORT = 250       # files between progress reports (and between writes of what is left)
BROKEN_AFTER = 5.0      # s before looking for records with no picture file (cheap: a few ms)
ORPHAN_AGE = 1800.0     # s a picture file with no record gets before it counts as left behind
# The only folders Kodi's texture cache writes into: Thumbnails/<first hex digit>/<hash>.jpg.
# Thumbnails also holds Video/ (and on older Kodi Music/), which belong to the video and
# music libraries and are NOT in the texture table - walking the whole folder would have
# offered those up for deletion, and a library's artwork is not ours to judge.
ORPHAN_FOLDERS = tuple('0123456789abcdef')


def _log(text, level=None):
    try:
        import xbmc
        xbmc.log('[MegaNexus] picture path: %s' % text, level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass


def _path():
    from .meganexus.paths import profile_path
    return Path(profile_path()) / SWITCH_FILE


def pending():
    """The switch that still has work left, or {}."""
    try:
        job = json.loads(_path().read_text(encoding='utf-8'))
        return job if isinstance(job, dict) and job.get('leaving') in ('mnxart', 'proxy') else {}
    except Exception:
        return {}


def _write(job):
    target = _path()
    tmp = target.with_suffix('.part')
    tmp.write_text(json.dumps(job), encoding='utf-8')
    os.replace(str(tmp), str(target))


def _clear():
    try:
        _path().unlink()
    except OSError:
        pass


def request(to_native, addon=None):
    """Switch the picture path. Returns the job that finish() then carries out.

    The job is written BEFORE the setting changes: if everything stops between the two,
    the worst case is a job for a path we are still on, which finish() recognises and
    drops. The other order would lose the old path's pictures with no record that they
    are still there.
    """
    import xbmcaddon
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    want = bool(to_native)
    if want == (addon.getSetting(art_cache.NATIVE_SETTING) == 'true'):
        return {}
    job = {'leaving': 'proxy' if want else 'mnxart', 'arriving': 'mnxart' if want else 'proxy',
           'stage': 'rows', 'asked': time.time(), 'rows': 0, 'files': []}
    _write(job)
    addon.setSetting(art_cache.NATIVE_SETTING, 'true' if want else 'false')
    art_cache.forget_native()
    _log('switching to %s; Kodi\'s copies of the %s pictures are being removed'
         % (job['arriving'], job['leaving']))
    return job


def _has_textures(path):
    """This file is a texture database with something in it.

    8.1.2: Kodi leaves an EMPTY Textures13.db behind on an upgraded box - zero bytes,
    no tables at all - and asking it for rows raised OperationalError ("no such table:
    texture") at every start, which was then logged as a database that could not be
    cleared. Nothing is wrong with it; there is simply nothing in it.
    """
    try:
        if path.stat().st_size == 0:
            return False
        db = sqlite3.connect('file:%s?mode=ro' % path.as_posix(), uri=True, timeout=BUSY_WAIT)
    except Exception:
        return False
    try:
        return bool(db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='texture'").fetchone())
    except Exception:
        return False
    finally:
        db.close()


def _databases():
    """Every texture database in this profile that holds pictures, newest first.

    Kodi 21 writes Textures13.db and Kodi 22 Textures14.db, and an upgraded box has
    both: a picture left in the older one comes back the moment that Kodi is started
    again, so the switch clears all of them. An empty leftover is skipped (_has_textures).
    """
    try:
        import xbmcvfs
        root = Path(xbmcvfs.translatePath('special://database/'))
        return [path for path in sorted(root.glob('Textures*.db'), reverse=True) if _has_textures(path)]
    except Exception:
        return []


def _thumbnails():
    try:
        import xbmcvfs
        return Path(xbmcvfs.translatePath('special://thumbnails/'))
    except Exception:
        return None


def _sweep(database, scheme):
    """Every row of this database that belongs to `scheme`, gone in one transaction.

    Returns the Thumbnails names those rows had. Kodi's own textureDelete trigger takes
    the matching sizes rows with them, so nothing is left dangling. A LIKE wide enough to
    catch both the plain address and Kodi's wrapped/transformed forms picks the
    candidates; art_cache.ours decides, so a Usenet or phone-page link on 127.0.0.1 is
    never in the list.
    """
    like = '%mnxart%' if scheme == 'mnxart' else '%127.0.0.1%'
    db = sqlite3.connect(str(database), timeout=BUSY_WAIT, isolation_level=None)
    try:
        db.execute('PRAGMA busy_timeout=%d' % int(BUSY_WAIT * 1000))
        mine = [(row[0], row[2]) for row in
                db.execute('SELECT id,url,cachedurl FROM texture WHERE url LIKE ?', (like,))
                if art_cache.ours(row[1]) == scheme]
        if not mine:
            return []
        db.execute('BEGIN IMMEDIATE')
        try:
            for start in range(0, len(mine), SQL_CHUNK):
                part = [texture_id for texture_id, _ in mine[start:start + SQL_CHUNK]]
                db.execute('DELETE FROM texture WHERE id IN (%s)' % ','.join('?' * len(part)), part)
            db.execute('COMMIT')
        except Exception:
            db.execute('ROLLBACK')
            raise
        return [str(name) for _, name in mine if name]
    finally:
        db.close()


def drop_pictures(addresses):
    """9.0.0: Kodi's copies of these pictures of ours gone - ``addresses`` as handed out
    (art_cache.plain reads Kodi's wrapped and card-size forms back to them). The rows in one
    transaction per database, then their files. For the pictures a new Artwork choice no
    longer uses (startup.switch_artwork): they stayed on the disk for good."""
    wanted = set(a for a in addresses or () if a)
    if not wanted:
        return 0
    like = '%mnxart%' if any(a.startswith(art_cache.NATIVE_SCHEME) for a in wanted) else '%127.0.0.1%'
    names, rows = [], 0
    for database in _databases():
        db = sqlite3.connect(str(database), timeout=BUSY_WAIT, isolation_level=None)
        try:
            db.execute('PRAGMA busy_timeout=%d' % int(BUSY_WAIT * 1000))
            mine = [(row[0], row[2]) for row in db.execute('SELECT id,url,cachedurl FROM texture WHERE url LIKE ?', (like,))
                    if art_cache.ours(row[1]) and art_cache.plain(row[1]) in wanted]
            if not mine:
                continue
            db.execute('BEGIN IMMEDIATE')
            try:
                for start in range(0, len(mine), SQL_CHUNK):
                    part = [texture_id for texture_id, _ in mine[start:start + SQL_CHUNK]]
                    db.execute('DELETE FROM texture WHERE id IN (%s)' % ','.join('?' * len(part)), part)
                db.execute('COMMIT')
            except Exception:
                db.execute('ROLLBACK')
                raise
            rows += len(mine)
            names.extend(str(name) for _, name in mine if name)
        except Exception as exc:
            _log('the pictures no longer used could not be removed from %s: %s' % (database.name, exc))
        finally:
            db.close()
    root = _thumbnails()
    if root is not None:
        for name in names:
            try:
                (root / name).unlink()
            except OSError:
                pass
    return rows


UNUSED_DAYS = 7         # 9.0.0: days a picture may go unshown before it is removed
SWEEP_FILE = 'pictures_sweep.json'   # the files of a sweep still to remove: {'files': [...], 'total': n}


def _from_web(url):
    """A texture Kodi fetched from the web (http/https, also inside image:// and card size) -
    never one of the local files or add-ons' icons; 127.0.0.1 only as ours (art_cache.ours)."""
    value = art_cache.plain(url)
    return value.startswith(('http://', 'https://')) and not value.startswith(('http://127.0.0.1', 'http://localhost'))


def _sweep_path():
    from .meganexus.paths import profile_path
    return Path(profile_path()) / SWEEP_FILE


def _sweep_job():
    try:
        job = json.loads(_sweep_path().read_text(encoding='utf-8'))
        return job if isinstance(job, dict) and isinstance(job.get('files'), list) else {}
    except Exception:
        return {}


def _write_sweep(job):
    if not job.get('files'):
        try:
            _sweep_path().unlink()
        except OSError:
            pass
        return
    target = _sweep_path()
    tmp = target.with_suffix('.part')
    tmp.write_text(json.dumps(job), encoding='utf-8')
    os.replace(str(tmp), str(target))


def sweep_pending():
    """A sweep stopped half way (the screensaver ended) - it goes on before anything else."""
    return bool(_sweep_job().get('files'))


def drop_unused(days=UNUSED_DAYS, stopped=None, step=None):
    """9.0.0: the pictures Kodi has not shown for ``days`` gone from its cache - ours and any
    from the web (Kodi fetches one again when it is shown); local ones (installed add-ons'
    icons, files on the disk) stay. Kodi writes when each was last shown (sizes.lastusetime,
    local time). Posters of titles that left the catalogs, of an old metadata add-on, of an
    earlier Artwork choice stayed on the disk for good: 1,179 of 10,630 on one machine had
    not been shown for a week. The screensaver runs it every UNUSED_DAYS.

    A sweep can stop half way (``stopped``: the screensaver ends) and the next one carries
    on: the rows go in one transaction per database, their files are written down BEFORE
    that and taken off the list as they go. ``step(done, total)`` follows the files.
    Returns True when nothing is left to do."""
    stopped = stopped or (lambda: False)
    job = _sweep_job()
    if not job.get('files'):
        cutoff = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - days * 86400))
        job, rows = {'files': [], 'total': 0}, 0
        for database in _databases():
            if stopped():
                return False
            db = sqlite3.connect(str(database), timeout=BUSY_WAIT, isolation_level=None)
            try:
                db.execute('PRAGMA busy_timeout=%d' % int(BUSY_WAIT * 1000))
                mine = [(row[0], row[2]) for row in db.execute(
                    "SELECT t.id, t.url, t.cachedurl, MAX(s.lastusetime) AS shown FROM texture t "
                    "JOIN sizes s ON s.idtexture = t.id GROUP BY t.id HAVING shown < ?", (cutoff,))
                        if art_cache.ours(row[1]) or _from_web(row[1])]
                if not mine:
                    continue
                names = [str(name) for _, name in mine if name]
                job['files'] += names
                job['total'] += len(names)
                _write_sweep(job)                         # written down before a single row goes
                db.execute('BEGIN IMMEDIATE')
                try:
                    for start in range(0, len(mine), SQL_CHUNK):
                        part = [texture_id for texture_id, _ in mine[start:start + SQL_CHUNK]]
                        db.execute('DELETE FROM texture WHERE id IN (%s)' % ','.join('?' * len(part)), part)
                    db.execute('COMMIT')
                except Exception:
                    db.execute('ROLLBACK')                # the rows stay - and so do their files
                    job['files'] = job['files'][:-len(names)] if names else job['files']
                    job['total'] -= len(names)
                    _write_sweep(job)
                    raise
                rows += len(mine)
            except Exception as exc:
                _log('the pictures not shown lately could not be removed from %s: %s' % (database.name, exc))
            finally:
                db.close()
        if rows:
            _log('%d pictures not shown for %d days taken out of Kodi\'s cache' % (rows, days))
    files = list(job.get('files') or [])
    total = int(job.get('total') or len(files)) or len(files)
    root = _thumbnails()
    if root is None or not files:
        _write_sweep({})
        return True
    gone = 0
    for gone, name in enumerate(files):
        if gone % 20 == 0:
            if step:
                step(total - len(files) + gone, total)
            if stopped():
                break
            if gone and gone % FILE_REPORT == 0:
                _write_sweep({'files': files[gone:], 'total': total})
        try:
            (root / name).unlink()
        except OSError:
            pass
    else:
        gone = len(files)
    left = files[gone:]
    _write_sweep({'files': left, 'total': total})
    if step:
        step(total - len(left), total)
    if not left:
        _log('%d picture files not shown lately removed' % total)
    return not left


def _drop_broken(database, root):
    """Our rows whose picture file is gone, removed so Kodi fetches them again.

    8.1.2: Kodi keeps the row and the file separately, and a file that disappears -
    a cleaned Thumbnails folder, a restored backup, a half-finished tidy-up - leaves a
    row pointing at nothing. Kodi then logs "DoWork - Direct texture file loading failed
    for special://masterprofile/Thumbnails/..." and draws a blank every time that
    picture is asked for, on every screen, for good: it never re-fetches while it
    believes it has the picture. Eight of them were repeating on one machine.

    Only our own rows (art_cache.ours), so Kodi's icons and the skin's own pictures are
    never touched. Returns how many went.
    """
    db = sqlite3.connect(str(database), timeout=BUSY_WAIT, isolation_level=None)
    try:
        db.execute('PRAGMA busy_timeout=%d' % int(BUSY_WAIT * 1000))
        gone = [row[0] for row in db.execute('SELECT id,url,cachedurl FROM texture')
                if art_cache.ours(row[1]) and row[2] and not (root / str(row[2])).exists()]
        if not gone:
            return 0
        db.execute('BEGIN IMMEDIATE')
        try:
            for start in range(0, len(gone), SQL_CHUNK):
                part = gone[start:start + SQL_CHUNK]
                db.execute('DELETE FROM texture WHERE id IN (%s)' % ','.join('?' * len(part)), part)
            db.execute('COMMIT')
        except Exception:
            db.execute('ROLLBACK')
            raise
        return len(gone)
    finally:
        db.close()


def proxy_leftovers():
    """Everything the image proxy kept for itself, once the native path has taken over.

    8.1.2: finish() removes what KODI kept for the path being left, which is the part
    that matters (a poster's address contains the port, so those rows are dead). But the
    proxy also keeps things of its own that nothing will ever read again once mnxart
    serves the pictures:

      * art-cache/*.img  - its own copy of every picture it fetched, up to 512 MiB
      * the converted card animations in special://temp/meganexus-anim
      * art-cache/port   - the port it last listened on. A number from before 8.1.2 is
        one the kernel also hands to other programs, so it is dropped rather than kept:
        if the proxy is ever needed again it starts on the fixed ladder instead.

    Returns how many files went. Never touches anything while the proxy is the live path.
    """
    if not art_cache.native():
        return 0
    gone = 0
    try:
        from .meganexus.paths import profile_path
        root = Path(profile_path()) / 'art-cache'
    except Exception:
        return 0
    for pattern in ('*.img', '*.part'):
        for path in root.glob(pattern):
            try:
                path.unlink()
                gone += 1
            except OSError:
                pass
    try:
        import xbmcvfs
        anim = Path(xbmcvfs.translatePath(art_cache.ANIM_FOLDER))
        # Named folder, named files. Deleting "everything in the folder" would be one
        # bad translatePath away from emptying something that is not ours - a test
        # harness where every special:// path resolves to the profile wiped the progress
        # database with exactly that loop, and a device is not a safer place to find out.
        expected = art_cache.ANIM_FOLDER.rstrip('/').rsplit('/', 1)[-1]
        if anim.name == expected:
            for path in anim.glob('*.gif'):
                if path.is_file():
                    try:
                        path.unlink()
                        gone += 1
                    except OSError:
                        pass
    except Exception:
        pass
    portfile = root / 'port'
    try:
        if int(portfile.read_text()) not in art_cache.FIXED_PORTS:
            portfile.unlink()
            gone += 1
    except (OSError, ValueError):
        pass
    if gone:
        _log('%d file(s) the image proxy kept for itself removed - the pictures come '
             'through vfs.meganexus now' % gone)
    return gone


def drop_orphan_files(min_age=None):
    """Picture files in Kodi's Thumbnails folder that no record points at any more.

    8.1.2: the mirror of drop_broken. A record with no file blanks a card; a file with
    no record is simply invisible weight - Kodi never looks at it again, because it finds
    pictures through the records. 638 MB of them were left on the machine this was written
    on, after records had been cleared without their files.

    They are only removed once they are at least `min_age` old. Kodi writes the file and
    inserts the record as two steps, so a file that has just appeared may be a picture
    whose record is still coming - and deleting that would turn a working poster into a
    blank one.

    Every record in every texture database is read first, so a file is only orphaned when
    NO database claims it. Returns how many files went.
    """
    import time
    root = _thumbnails()
    if root is None or not root.is_dir():
        return 0
    databases = _databases()
    if not databases:
        return 0        # nothing read them: never guess that everything is an orphan
    known = set()
    for database in databases:
        try:
            db = sqlite3.connect('file:%s?mode=ro' % database.as_posix(), uri=True, timeout=BUSY_WAIT)
        except Exception:
            return 0    # a database we could not read may be the one that claims them
        try:
            known.update(str(row[0]) for row in db.execute('SELECT cachedurl FROM texture') if row[0])
        except Exception:
            return 0
        finally:
            db.close()
    cutoff = time.time() - (ORPHAN_AGE if min_age is None else min_age)
    gone, freed = 0, 0
    for folder in ORPHAN_FOLDERS:          # never Video/ or Music/ - see ORPHAN_FOLDERS
        for path in (root / folder).glob('*'):
            if not path.is_file():
                continue
            name = '%s/%s' % (folder, path.name)
            if name in known:
                continue
            try:
                stat = path.stat()
                if stat.st_mtime > cutoff:
                    continue    # too new to be sure its record is not on its way
                size = stat.st_size
                path.unlink()
            except OSError:
                continue
            gone += 1
            freed += size
    if gone:
        _log('%d picture file(s) no record points at removed - %d MB back'
             % (gone, freed // (1024 * 1024)))
    return gone


def live_proxy_base():
    """The address the image cache is listening on now, or '' while it is not known."""
    try:
        import xbmcgui
        base = xbmcgui.Window(10000).getProperty('meganexus.art_cache.base') or ''
    except Exception:
        return ''
    return base if base.startswith('http://127.0.0.1:') else ''


def _drop_other_ports(database, base):
    like = '%127.0.0.1%'
    db = sqlite3.connect(str(database), timeout=BUSY_WAIT, isolation_level=None)
    try:
        db.execute('PRAGMA busy_timeout=%d' % int(BUSY_WAIT * 1000))
        stale = [(row[0], row[2]) for row in
                 db.execute('SELECT id,url,cachedurl FROM texture WHERE url LIKE ?', (like,))
                 if art_cache.ours(row[1]) == 'proxy' and not art_cache.plain(row[1]).startswith(base + '/')]
        if not stale:
            return 0, []
        db.execute('BEGIN IMMEDIATE')
        try:
            for start in range(0, len(stale), SQL_CHUNK):
                part = [texture_id for texture_id, _ in stale[start:start + SQL_CHUNK]]
                db.execute('DELETE FROM texture WHERE id IN (%s)' % ','.join('?' * len(part)), part)
            db.execute('COMMIT')
        except Exception:
            db.execute('ROLLBACK')
            raise
        return len(stale), [str(name) for _, name in stale if name]
    finally:
        db.close()


def drop_other_ports():
    """Proxy pictures Kodi kept under a port the image cache no longer listens on.

    8.1.2: until this release the cache took whatever port the system handed out (8.0.1
    and older bind port 0), so a restart could change every poster's address. One machine
    had twelve ports in its texture cache and 39,212 of its 47,312 pictures were the same
    library over and over. 8.1.2 listens on a fixed port, which stops NEW copies - but the
    old ones still have their files, so drop_broken leaves them alone and they would sit
    there for ever. A device coming from 8.0.1 sheds them here, once, and gets the room
    back.

    Only our own proxy rows, and only ports other than the live one. Does nothing while
    the proxy is not the live path or the port is not known yet (it runs again next start).
    """
    base = live_proxy_base()
    if not base or art_cache.native():
        return 0
    root = _thumbnails()
    gone, names = 0, []
    for database in _databases():
        try:
            count, files = _drop_other_ports(database, base)
        except Exception as exc:
            _log('%s: pictures of an old port could not be removed (%s)'
                 % (database.name, type(exc).__name__))
            continue
        gone += count
        names.extend(files)
    if root is not None:
        for name in names:
            try:
                (root / name).unlink()
            except OSError:
                pass
    if gone:
        _log('%d picture(s) Kodi kept under an earlier image-cache port removed; the '
             'cache listens on one fixed port now (%s)' % (gone, base))
    return gone


def drop_broken():
    """Every texture database: our rows with no picture file behind them."""
    root = _thumbnails()
    if root is None:
        return 0
    gone = 0
    for database in _databases():
        try:
            gone += _drop_broken(database, root)
        except Exception as exc:
            _log('%s: rows with no picture could not be removed (%s)'
                 % (database.name, type(exc).__name__))
    if gone:
        _log('%d picture(s) Kodi had a record of but no file for - it fetches them again' % gone)
    return gone


def _rpc(method, params):
    import xbmc
    return json.loads(xbmc.executeJSONRPC(json.dumps(
        {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})) or '{}')


def _through_kodi(scheme, step=None):
    """The fallback: Kodi removes them itself, one at a time.

    Slow (one round trip each) but it needs no database of its own, so it also covers a
    Kodi whose texture database we could not open. It reports as it goes and returns how
    many went; whatever is left is picked up by the next run of the same job.
    """
    marker = 'mnxart' if scheme == 'mnxart' else '127.0.0.1'
    found = ((_rpc('Textures.GetTextures', {'properties': ['url'],
                                            'filter': {'field': 'url', 'operator': 'contains', 'value': marker}})
              .get('result') or {}).get('textures') or [])
    ids = [item.get('textureid') for item in found
           if isinstance(item, dict) and item.get('textureid') is not None
           and art_cache.ours(item.get('url')) == scheme]
    removed = 0
    for start in range(0, len(ids), RPC_BATCH):
        for texture_id in ids[start:start + RPC_BATCH]:
            if 'error' not in _rpc('Textures.RemoveTexture', {'textureid': texture_id}):
                removed += 1
        if step:
            step(removed, len(ids))
    return removed


def finish(step=None):
    """Carry out (or carry on) the written-down switch. Returns (rows, files, done).

    ``step(done, total)`` is only for showing progress - its answer is ignored on
    purpose. This is the one job in MegaNexus that may not be cancelled: stopping it
    half way leaves Kodi holding a second copy of every poster it had, which is the
    fault the whole switch exists to prevent.
    """
    job = pending()
    if not job:
        return 0, 0, True
    scheme = job['leaving']
    if scheme == ('mnxart' if art_cache.native() else 'proxy'):
        # The setting went back before the job ran (or was never written): those pictures
        # are the live cache again and must stay.
        _log('switch back to %s; nothing removed' % scheme)
        _clear()
        return 0, 0, True

    if job.get('stage') == 'rows':
        names, rows = [], 0
        for database in _databases():
            try:
                found = _sweep(database, scheme)
            except Exception as exc:
                _log('%s could not be cleared directly (%s); Kodi is asked to do it'
                     % (database.name, type(exc).__name__))
                rows += _through_kodi(scheme, step)
                continue
            names.extend(found)
            rows += len(found)
        job.update(stage='files', rows=job.get('rows', 0) + rows, files=names)
        _write(job)
        _log('%d of the %s pictures removed from Kodi\'s cache' % (rows, scheme))

    files, left = 0, list(job.get('files') or [])
    root = _thumbnails()
    total = len(left)
    while left:
        name = left.pop()
        if root is not None:
            try:
                (root / name).unlink()
                files += 1
            except OSError:
                pass
        if len(left) % FILE_REPORT == 0:
            job['files'] = left
            _write(job)
            if step:
                step(total - len(left), total)
    _clear()
    art_cache.forget_native()
    if job.get('arriving') == 'mnxart':
        # nothing reads the proxy's own copies any more (see proxy_leftovers)
        try:
            files += proxy_leftovers()
        except Exception as exc:
            _log('the image proxy\'s own files could not be cleared (%s)' % type(exc).__name__)
    _log('switch to %s done: %d pictures, %d files' % (job['arriving'], job.get('rows', 0), files))
    return job.get('rows', 0), files, True


def holds(scheme):
    """Kodi's texture cache still has at least one picture from this path.

    Stops at the first one: this only has to answer whether there is work, and the work
    itself (finish) reads them properly. A LIKE on an unindexed column over a few
    thousand rows is a couple of milliseconds; it runs once a start.
    """
    like = '%mnxart%' if scheme == 'mnxart' else '%127.0.0.1%'
    for database in _databases():
        try:
            db = sqlite3.connect('file:%s?mode=ro' % database.as_posix(), uri=True, timeout=BUSY_WAIT)
        except Exception:
            continue
        try:
            for row in db.execute('SELECT url FROM texture WHERE url LIKE ?', (like,)):
                if art_cache.ours(row[0]) == scheme:
                    return True
        except Exception:
            continue
        finally:
            db.close()
    return False


def adopt(addon=None):
    """Once, on the first start of 8.1.2: keep the picture path Kodi's cache already has.

    8.1.0 and 8.1.1 served the pictures natively whenever vfs.meganexus could, with no
    setting to it. A device coming from one of those holds a full set of mnxart pictures -
    4,622 of them, 666 MB, on the machine this was written on. Taking the new setting's
    default at face value would call every one of them dead and throw the lot away, and
    the proxy would then fetch the same library all over again: the first start would be
    the slow, data-hungry one we keep trying to get rid of.

    So the first start reads the cache instead of the default. Whichever path Kodi already
    has pictures for is the path it keeps. This is not the add-on switching itself on -
    installing vfs.meganexus still changes nothing (it installs everywhere, for Usenet).
    It is one decision, taken once, about a cache that already exists; after it the
    setting is whatever the user set, and changing it goes through request().
    """
    import xbmcaddon
    addon = addon or xbmcaddon.Addon('plugin.video.meganexus')
    if addon.getSetting(DECIDED) == '1':
        return ''
    addon.setSetting(DECIDED, '1')
    if addon.getSetting(art_cache.NATIVE_SETTING) == 'true':
        return ''                                   # already on: nothing to work out
    if not (art_cache.native_available() and holds('mnxart') and not holds('proxy')):
        return ''
    addon.setSetting(art_cache.NATIVE_SETTING, 'true')
    art_cache.forget_native()
    _log('Kodi already has its pictures at mnxart, so that path is kept (Settings > '
         'Performance & image cache changes it)')
    return 'mnxart'


def reconcile(monitor, delay=20, broken_after=None):
    """The service, once a start: Kodi keeps pictures for the LIVE path and no other.

    Two jobs in one, because they are the same job:

      * a switch that did not get to finish - Kodi closed, crashed or was killed in the
        middle - is finished now;
      * pictures of the path that is not live, with no switch ever asked for. They can be
        there all the same: a device that ran a build where the native path was simply on
        (8.1.0 did that), one whose vfs.meganexus was removed so the proxy took over, or a
        restored backup. Nobody asks for those addresses any more, so they are copies of
        the whole library sitting on the disk, and every later start would find them again.

    Delayed a little so the first screen is drawn first. It holds nothing up - the live
    path already serves every picture.
    """
    try:
        job = pending()
        if not job:
            try:
                adopt()                  # the first start keeps the path the cache already has
            except Exception:
                pass                     # a settings problem must not stop the clean-up below
            leaving = 'proxy' if art_cache.native() else 'mnxart'
            if not holds(leaving):
                # 8.1.2: soon, not after the switch's wait. A record with no picture file
                # blanks that card on every screen until it goes, and one session that
                # ended after 19 seconds never reached the 20-second wait at all - it
                # just logged 25 of those failures. The scan is a few milliseconds.
                if monitor.waitForAbort(BROKEN_AFTER if broken_after is None else broken_after):
                    return
                drop_broken()
                drop_other_ports()
                drop_orphan_files()
                return
            job = {'leaving': leaving, 'arriving': 'mnxart' if leaving == 'proxy' else 'proxy',
                   'stage': 'rows', 'asked': time.time(), 'rows': 0, 'files': []}
            _write(job)
            _log('Kodi still keeps %s pictures while %s is the live path; removing them'
                 % (leaving, job['arriving']))
        if monitor.waitForAbort(delay):
            return
        if job:
            finish()
        drop_broken()
        drop_other_ports()
        drop_orphan_files()
    except Exception as exc:
        import xbmc
        _log('the picture paths could not be put right (%s); tried again at the next start'
             % type(exc).__name__, xbmc.LOGWARNING)

