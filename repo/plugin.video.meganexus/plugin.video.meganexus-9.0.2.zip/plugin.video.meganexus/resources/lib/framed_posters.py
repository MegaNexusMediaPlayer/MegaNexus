# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import base64
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from urllib.request import Request, urlopen

import xbmc
import xbmcgui

# ── constants ─────────────────────────────────────────────────────────
PROXY_HOST = '127.0.0.1'
WINDOW_ID  = 10000
PROP_PORT  = 'meganexus.poster_proxy.port'

_CHUNK              = 64 * 1024     # streaming chunk size
_DECORATED_TIMEOUT  = 3.0
_CLEAN_TIMEOUT      = 4.0

_server          = None
_server_thread   = None


# ──────────────────────────────────────────────────────────────────────
# request handler
# ──────────────────────────────────────────────────────────────────────
class _FramedPosterRequest(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        return

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != '/poster':
            self.send_error(404, 'not-found')
            return
        qs = parse_qs(parsed.query)
        decorated = self._decode((qs.get('d') or [''])[0])
        clean     = self._decode((qs.get('c') or [''])[0])

        if decorated and self._stream_once(decorated, _DECORATED_TIMEOUT):
            return

        if clean and self._stream_once(clean, _CLEAN_TIMEOUT):
            return

        self.send_error(404, 'upstream-unreachable')

    # ── helpers ───────────────────────────────────────────────────────
    def _decode(self, b64):
        if not b64:
            return ''
        try:
            return base64.urlsafe_b64decode(b64 + '==' * (-len(b64) % 4)).decode('utf-8')
        except Exception:
            return ''

    def _stream_once(self, url, timeout):
        """The picture at ``url`` passed on to Kodi as it arrives (kept a day by Kodi); False
        when its server does not give it."""
        try:
            source = urlopen(Request(url, headers={'User-Agent': 'MegaNexus-poster-proxy/1.0'}), timeout=timeout)
        except Exception as exc:
            xbmc.log('[MegaNexus] poster-proxy upstream %s failed: %s' % (url[:80], exc), xbmc.LOGDEBUG)
            return False
        try:
            if not 200 <= source.getcode() < 400:
                return False
            size = source.headers.get('Content-Length')
            self.send_response(200)
            self.send_header('Content-Type', source.headers.get('Content-Type') or 'image/jpeg')
            if size:
                self.send_header('Content-Length', size)
            self.send_header('Cache-Control', 'public, max-age=86400')
            self.end_headers()
            for piece in iter(lambda: source.read(_CHUNK), b''):
                self.wfile.write(piece)
            return True
        except Exception as exc:
            xbmc.log('[MegaNexus] poster-proxy upstream %s failed: %s' % (url[:80], exc), xbmc.LOGDEBUG)
            return False
        finally:
            try:
                source.close()
            except Exception:
                pass


# ──────────────────────────────────────────────────────────────────────
# lifecycle
# ──────────────────────────────────────────────────────────────────────
def start():
    global _server, _server_thread
    if _server is not None:
        return True
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.bind((PROXY_HOST, 0))
            port = probe.getsockname()[1]

        _server = ThreadingHTTPServer((PROXY_HOST, port), _FramedPosterRequest)
        _server.daemon_threads = True
        _server_thread = threading.Thread(target=_server.serve_forever,
                                            name='MegaNexus-poster-proxy',
                                            daemon=True)
        _server_thread.start()

        try:
            xbmcgui.Window(WINDOW_ID).setProperty(PROP_PORT, str(port))
        except Exception:
            pass

        xbmc.log('[MegaNexus] poster-proxy started on 127.0.0.1:%d' % port,
                 xbmc.LOGINFO)
        return True
    except Exception as exc:
        xbmc.log('[MegaNexus] poster-proxy failed to start: %s' % exc,
                 xbmc.LOGWARNING)
        _server = None
        _server_thread = None
        return False


def stop():
    global _server, _server_thread
    if _server is None:
        return
    try:
        _server.shutdown()
        _server.server_close()
    except Exception:
        pass
    _server = None
    _server_thread = None
    try:
        xbmcgui.Window(WINDOW_ID).clearProperty(PROP_PORT)
    except Exception:
        pass
    xbmc.log('[MegaNexus] poster-proxy stopped', xbmc.LOGINFO)


def get_port():
    try:
        raw = xbmcgui.Window(WINDOW_ID).getProperty(PROP_PORT) or ''
        return int(raw) if raw.isdigit() else None
    except Exception:
        return None


def build_url(decorated_url, clean_url):
    if not (decorated_url and clean_url):
        return ''
    port = get_port()
    if not port:
        return ''
    try:
        d_b64 = base64.urlsafe_b64encode(decorated_url.encode('utf-8')).decode('ascii').rstrip('=')
        c_b64 = base64.urlsafe_b64encode(clean_url.encode('utf-8')).decode('ascii').rstrip('=')
    except Exception:
        return ''
    return 'http://%s:%d/poster?d=%s&c=%s' % (PROXY_HOST, port, d_b64, c_b64)
