# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A link shown under a QR code, used on the computer Kodi runs on (7.0.52).

On a PC there is no phone to scan with (recording the setup, a desktop user): selecting
the address opens it in the computer's browser and, where the system lets an add-on,
copies it too. Kodi has no clipboard for add-ons, so the system's own tools are used
(Windows: clip; Linux: wl-copy / xclip / xsel; macOS: pbcopy). TV boxes (Android,
CoreELEC) have neither - there the address is only read.
"""
import os
import shutil
import subprocess
import sys


def desktop():
    try:
        import xbmc
        # (not System.Platform.Linux.RaspberryPi: Kodi 22 answers every Linux.* condition True)
        if xbmc.getCondVisibility('System.Platform.Android'):
            return False
        if xbmc.getCondVisibility('System.Platform.Windows') or xbmc.getCondVisibility('System.Platform.OSX'):
            return True
        if xbmc.getCondVisibility('System.Platform.Linux'):
            # CoreELEC / LibreELEC run Kodi alone: no browser
            return bool(os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')) and not os.path.isdir('/storage/.kodi')
    except Exception:
        pass
    return False


def _run(command, text=None):
    try:
        process = subprocess.Popen(command, stdin=subprocess.PIPE if text is not None else subprocess.DEVNULL,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
        if text is not None:
            process.communicate(text.encode('utf-8'), timeout=5)
        return True
    except Exception:
        return False


def copy(url):
    if sys.platform.startswith('win'):
        return _run(['clip'], url)
    if sys.platform == 'darwin':
        return _run(['pbcopy'], url)
    for command in (['wl-copy'], ['xclip', '-selection', 'clipboard'], ['xsel', '--clipboard', '--input']):
        if shutil.which(command[0]) and _run(command, url):
            return True
    return False


def open_here(url):
    """(opened in the browser, copied) - neither on a TV box."""
    if not url or not url.startswith(('http://', 'https://')) or not desktop():
        return False, False
    copied = copy(url)
    if sys.platform.startswith('win'):
        try:
            os.startfile(url)                       # noqa - Windows only
            return True, copied
        except Exception:
            return False, copied
    command = 'open' if sys.platform == 'darwin' else 'xdg-open'
    return bool(shutil.which(command)) and _run([command, url]), copied
