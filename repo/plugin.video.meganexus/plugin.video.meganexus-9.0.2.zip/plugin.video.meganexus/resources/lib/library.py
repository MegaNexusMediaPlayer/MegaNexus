# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus Library (6.0.35): one place for "Add to Library" and the Library screen.

* Local: the device's own library (favorites_store, source 'local'), also
  synced with the Nuvio account library.
* Tracking services: Trakt watchlist + Simkl Plan to Watch (+ MDBList), merged
  into the external mirror (favorites_store source 'trakt'). TRACKERS is the
  one list to extend for another service: its name labels the Library tab and
  the small badge on each card.
* Calendar: everything in the Library by the month it was added.
Adding saves locally and, when connected, to Trakt and Simkl as well; a
tracking service that fails never loses the local save.
"""
import xbmc

LOCAL = 'local'
TRACKING = 'trakt'   # favorites_store source of the merged Trakt/Simkl/MDBList mirror
NUVIO = 'nuvio'      # the Nuvio account's own library, pulled by the cloud sync
# 8.1.2 (GitHub #22, "Nuvio library doesn't sync"): the sync pulled the account's
# library and saved every title under its own source - and the Library screen only ever
# listed 'local' and the tracking mirror, so none of it was ever shown. The sync then
# had nothing to do on the next run either ("pull 81, add here 0"), which made it look
# like nothing was being synced at all. The account's titles belong in Local, marked.
OWN = (LOCAL, NUVIO)


def _kind(media_type):
    return 'movie' if media_type == 'movie' else 'series'


def _trakt_connected():
    from . import trakt_api
    return trakt_api.authorized()


def _simkl_connected():
    from . import simkl_api
    return bool(simkl_api.enabled() and simkl_api.authorized())


def _mdblist_connected():
    from . import mdblist_api
    return bool(mdblist_api.configured())


def _wetrakr_connected():
    from . import wetrakr_api
    return bool(wetrakr_api.authorized())


def _trakt_rows():
    from . import trakt_api
    return trakt_api.fetch_watchlist(limit=200) or []


def _simkl_rows():
    from . import simkl_api
    return simkl_api.watchlist_copy_rows(limit=200) or []


def _mdblist_rows():
    from . import mdblist_api
    return mdblist_api.watchlist_copy_rows(limit=200) or []


def _wetrakr_rows():
    from . import wetrakr_api
    return wetrakr_api.watchlist_copy_rows(limit=200) or []


# id, name, connected(), watchlist rows(). Add a service here and the Library
# tab label, the card badges and the refresh follow.
TRACKERS = (
    ('trakt', 'Trakt', _trakt_connected, _trakt_rows),
    ('simkl', 'Simkl', _simkl_connected, _simkl_rows),
    ('mdblist', 'MDBList', _mdblist_connected, _mdblist_rows),
    ('wetrakr', 'WeTrakr', _wetrakr_connected, _wetrakr_rows),   # 8.1.2
)


def connected_trackers():
    found = []
    for tid, name, connected, _ in TRACKERS:
        try:
            if connected():
                found.append((tid, name))
        except Exception:
            continue
    return found


def tracking_connected():
    """A tracking service is connected (the Library opens on its tab)."""
    return bool(connected_trackers())


ICON = 'special://home/addons/script.meganexus/resources/media/%s.png'
# what is saved on this box carries our own mark - the M lifted off its tile, so it
# sits among the services' logos instead of being a square between them
ICON_FILE = {}
_ICONS = {}


def service_icon(service):
    """The picture of one service, '' when it has none.

    8.1.2: the cards and the tracking tab draw these instead of writing names out. The
    answer is kept per service - this is asked once per card per service while a screen
    of five hundred titles is drawn, and a file test each time would be felt.
    """
    name = str(service or '').strip().lower()
    if not name:
        return ''
    name = ICON_FILE.get(name, name)
    if name not in _ICONS:
        import os
        import xbmcvfs
        try:
            _ICONS[name] = bool(os.path.isfile(xbmcvfs.translatePath(ICON % name)))
        except Exception:
            _ICONS[name] = False
    return (ICON % name) if _ICONS[name] else ''


def tracking_label():
    names = [name for _, name in connected_trackers()]
    return ' · '.join(names) if names else 'Tracking'


def _origins_path():
    from . import library_titles
    return library_titles.ORIGINS_PATH


def _origins():
    from .meganexus.json_files import read_json
    data = read_json(_origins_path(), {})
    return data if isinstance(data, dict) else {}


def _forms(item):
    """Every ID a title may be stored under: its own, tt..., tmdb:..."""
    ids = _ids(item)
    forms = {str(item.get('canonical_id') or item.get('id') or '')}
    if ids.get('imdb_id'):
        forms.add(ids['imdb_id'])
    if ids.get('tmdb_id'):
        forms.add('tmdb:%s' % ids['tmdb_id'])
    forms.discard('')
    return forms


def contains(media_type, canonical_id, ids=None):
    """7.0.36: in the Library on this device OR on a tracking service (Trakt /
    Simkl / MDBList watchlist), under any of the title's IDs - the long-press
    menu offered "Add to Library" for titles shown in the Library."""
    from . import library_titles
    kind = _kind(media_type)
    forms = _forms(dict(ids or {}, canonical_id=canonical_id))
    for source in (LOCAL, NUVIO, TRACKING):   # 8.1.2: the Nuvio account's library counts too
        try:
            rows = library_titles.list_favorites(limit=5000, source=source)
        except Exception:
            continue
        if any(_kind(r.get('media_type')) == kind and r.get('canonical_id') in forms for r in rows):
            return True
    return False


def _ids(item):
    ids = {}
    for key in ('imdb_id', 'tmdb_id', 'tvdb_id'):
        if item.get(key):
            ids[key] = str(item[key])
    cid = str(item.get('canonical_id') or item.get('id') or '')
    if cid.startswith('tt') and 'imdb_id' not in ids:
        ids['imdb_id'] = cid.split(':')[0]
    if cid.startswith('tmdb:') and 'tmdb_id' not in ids:
        ids['tmdb_id'] = cid.split(':')[1]
    return ids


def _trakt_add(item):
    from . import trakt_api
    if not trakt_api.authorized():
        return False
    ids = trakt_api._ids_payload(_ids(item))
    if not ids:
        return False
    kind = 'movies' if _kind(item.get('media_type')) == 'movie' else 'shows'
    trakt_api._request('/sync/watchlist', payload={kind: [{'ids': ids}]}, method='POST', auth=True, timeout=8)
    trakt_api.invalidate_cache('/users/me/watchlist')
    return True


def _simkl_add(item):
    from . import simkl_api, simkl_watched
    if not (simkl_api.enabled() and simkl_api.authorized()):
        return False
    # 7.0.29: a watched title stays in Completed - Simkl keeps one list per title,
    # and Plan to Watch would have moved it out.
    if simkl_watched.state(simkl_watched.snapshot(), _kind(item.get('media_type')), item.get('canonical_id')).get('watched'):
        return False
    ctx = dict(_ids(item), media_type=_kind(item.get('media_type')), title=item.get('title') or '')
    return bool(simkl_api.add_to_library(ctx))


def _mdblist_add(item):
    if not _mdblist_connected():
        return False
    from . import mdblist_tracking
    ctx = dict(_ids(item), media_type=_kind(item.get('media_type')))
    return mdblist_tracking.watchlist(ctx, 'add')


def _wetrakr_add(item):
    from . import wetrakr_api
    if not wetrakr_api.authorized():
        return False
    return bool(wetrakr_api.add_to_library(item))


def _wetrakr_remove(item, force=False):
    from . import wetrakr_api
    if not wetrakr_api.authorized():
        return False
    return bool(wetrakr_api.remove_from_library(item))


def _mdblist_remove(item, force=False):
    if not _mdblist_connected():
        return False
    from . import mdblist_tracking
    return mdblist_tracking.watchlist(dict(_ids(item), media_type=item['media_type']), 'remove')


def add(item):
    """Save a title (row/meta-like dict). Returns the tracking services it also reached."""
    from . import library_titles
    media_type = _kind(item.get('media_type') or item.get('type'))
    cid = str(item.get('canonical_id') or item.get('id') or '')
    if not cid:
        raise ValueError('This title has no ID to save.')
    library_titles.add(media_type, cid, item.get('title') or item.get('name') or cid,
                        poster=item.get('poster') or '', background=item.get('background') or item.get('fanart') or '',
                        clearlogo=item.get('clearlogo') or item.get('logo') or '', plot=item.get('plot') or item.get('description') or '',
                        source=LOCAL)
    reached = []
    # 7.0.29: every connected tracking service - Trakt, Simkl and MDBList.
    full = dict(item, media_type=media_type, canonical_id=cid)
    for name, fn in (('Trakt', _trakt_add), ('Simkl', _simkl_add), ('MDBList', _mdblist_add),
                     ('WeTrakr', _wetrakr_add)):
        try:
            if fn(full):
                reached.append(name)
            else:
                # 7.0.36: why a service was left out (a series reached none of them)
                xbmc.log('[MegaNexus] Library: %s not saved (%s %s, ids %s)' % (name, media_type, cid, _ids(full)), xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log('[MegaNexus] Library: %s save skipped: %s' % (name, exc), xbmc.LOGWARNING)
    return reached


LOCAL_PLACE = 'local'


def places(media_type=None, canonical_id=None):
    """Where a saved title lives: this box, the Nuvio account and every connected
    service. 8.1.2: with more than one of them, "Remove from Library" was the only
    choice there was and it took the title off all of them at once.
    """
    found = [(LOCAL_PLACE, 'Library')]      # what this box itself keeps
    try:
        from .meganexus import cloud_sync
        if cloud_sync.NuvioCloud.is_linked():
            found.append((NUVIO, SERVICE_NAMES[NUVIO]))
    except Exception:
        pass
    found.extend(connected_trackers())
    return found


def forget(media_type, canonical_id, only=None):
    """Take a title out of what this box keeps - at once, with no network at all.

    8.1.2: the Library screen reads its rows from this box's mirror, and the badges from
    library_origins.json. The removal itself runs on a background thread (a service can
    take seconds to answer), so when the screen was redrawn straight afterwards the
    title was still there with its badge - "kliknuo sam remove from simkl ali nista se
    nije desilo".

    ``only``: None for every copy, 'local' for this box's own, 'nuvio' for the account's,
    or a tracker id - then that service's claim on the mirror row goes, and the row only
    when that was the last service holding it. True when something was taken away.
    """
    from . import library_titles
    kind = _kind(media_type)
    item = {'media_type': kind, 'canonical_id': canonical_id}
    if only is None:
        for form in _forms(item):
            # 7.0.36: also the services' copy shown in the Library - gone at once
            library_titles.remove(kind, form, source=LOCAL)
            library_titles.remove(kind, form, source=TRACKING)
            library_titles.remove(kind, form, source=NUVIO)   # 7.0.44: the sync takes it off Nuvio
        return True
    if only in SERVICE_NAMES:                 # this box, or the Nuvio account
        for form in _forms(item):
            library_titles.remove(kind, form, source=LOCAL if only == LOCAL_PLACE else NUVIO)
        return True
    origins = _origins()
    changed = False
    known = any(origins.get('%s|%s' % (kind, form)) for form in _forms(item))
    for form in _forms(item):
        key = '%s|%s' % (kind, form)
        holders = origins.get(key)
        if isinstance(holders, str):
            holders = [holders]          # library_origins.json of the first 6.0.35 build
        if not holders or only not in holders:
            continue
        holders = [held for held in holders if held != only]
        changed = True
        if holders:
            origins[key] = holders
        else:
            origins.pop(key, None)
            library_titles.remove(kind, form, source=TRACKING)
    if not changed and not known:
        # Nothing is recorded about this title at all (an older build, or the file was
        # lost). The row is taken off anyway rather than leaving a choice that visibly
        # does nothing; the next refresh brings it back if a service still lists it.
        for form in _forms(item):
            library_titles.remove(kind, form, source=TRACKING)
        changed = True
    if changed:
        try:
            from .meganexus.json_files import write_json
            write_json(_origins_path(), origins)
        except Exception as exc:
            xbmc.log('[MegaNexus] Library: the badges could not be written: %s' % exc, xbmc.LOGWARNING)
    return changed


def _nuvio_remove(item, force=False):
    """Off the Nuvio account as well (the same call its own sync makes)."""
    from .meganexus import cloud_sync
    cloud = cloud_sync.NuvioCloud
    if not cloud.is_linked():
        return False
    cloud._rpc('sync_delete_library_items', {'p_profile_id': cloud._profile_id(),
                                             'p_keys': [{'content_id': item['canonical_id'],
                                                         'content_type': item['media_type']}]})
    return True


def remove_on_services(media_type, canonical_id, only=None):
    """Tell the services. [(name, True/False)] - False when the service would not or
    could not take it off, so what is said about it afterwards is the truth."""
    item = {'media_type': _kind(media_type), 'canonical_id': canonical_id}
    done = []
    for tid, name, fn in ((NUVIO, 'Nuvio', _nuvio_remove), ('trakt', 'Trakt', _trakt_remove),
                          ('simkl', 'Simkl', _simkl_remove), ('mdblist', 'MDBList', _mdblist_remove),
                          ('wetrakr', 'WeTrakr', _wetrakr_remove)):
        if only is not None and only != tid:
            continue
        if only is None and tid == NUVIO:
            continue          # removing everywhere already drops the account's row locally
        try:
            # asked for by name: do it even for a title the service counts as watched
            done.append((name, bool(fn(item, force=True) if tid == 'simkl' and only == tid else fn(item))))
        except Exception as exc:
            xbmc.log('[MegaNexus] Library: %s removal skipped: %s' % (name, exc), xbmc.LOGWARNING)
            done.append((name, False))
    return done


def remove(media_type, canonical_id, only=None):
    """Take a title out of the Library - and, 7.0.29, out of the Trakt watchlist and
    Simkl's Plan to Watch it was also saved to (removing used to stay local).

    8.1.2: ``only`` names one place - 'local' for this box's Library, or a tracker id
    ('trakt', 'simkl', 'mdblist') - and nothing else is touched.
    """
    forget(media_type, canonical_id, only)
    return remove_on_services(media_type, canonical_id, only)


def _trakt_remove(item, force=False):
    from . import trakt_api
    if not trakt_api.authorized():
        return False
    ids = trakt_api._ids_payload(_ids(item))
    if not ids:
        return False
    kind = 'movies' if item['media_type'] == 'movie' else 'shows'
    trakt_api._request('/sync/watchlist/remove', payload={kind: [{'ids': ids}]}, method='POST', auth=True, timeout=8)
    trakt_api.invalidate_cache('/users/me/watchlist')
    return True


def _simkl_remove(item, force=False):
    """Simkl removes from lists AND history at once, so a title it counts as watched is
    left alone - taking it off "the Library" would throw away watched history nobody
    asked to lose.

    8.1.2: unless it was asked for by name ("Remove from Simkl"), which is exactly that
    request and is carried out.
    """
    from . import simkl_api, simkl_watched
    if not (simkl_api.enabled() and simkl_api.authorized()):
        return False
    state = simkl_watched.state(simkl_watched.snapshot(), item['media_type'], item['canonical_id'])
    if not force and (state.get('watched') or state.get('episodes') or state.get('seasons')):
        return False
    ids = simkl_api._ids_from_ctx(dict(_ids(item), media_type=item['media_type']))
    if not ids:
        return False
    kind = 'movies' if item['media_type'] == 'movie' else 'shows'
    simkl_api._request('/sync/history/remove', payload={kind: [{'ids': ids}]}, method='POST', auth=True, timeout=8)
    simkl_api.invalidate_cache('/sync/all-items')
    return True


def _poster(item):
    """Trakt sends no artwork: IMDb titles use the standard Stremio poster.

    8.1.2: and everything else gets one too. This only knew the "tt..." case, so a row
    that came from Simkl or Trakt keyed by a TMDB id, with no artwork of its own, got
    an empty string and the card in the Library was simply blank - "prikaz postera u
    library se zbugovao, neki se posteri ne vide". card_art.usable_poster is what the
    other screens use: the stored picture, the item's own, MetaHub by IMDb id, and a
    placeholder at the end, so there is always something to draw.
    """
    poster = str(item.get('poster') or '').strip()
    if poster:
        return poster
    try:
        from . import card_art
        meta = dict(item)
        meta.setdefault('id', str(item.get('canonical_id') or ''))
        return card_art.usable_poster(meta, _kind(item.get('media_type')))
    except Exception:
        cid = str(item.get('canonical_id') or '')
        return 'https://images.metahub.space/poster/medium/%s/img' % cid.split(':')[0] if cid.startswith('tt') else ''


def _items(source):
    """The rows of one source, or of several merged into one card per title.

    A merged row carries ``sources``: every store the title was found in, which is what
    the badges are made of.
    """
    from . import library_titles
    names = (source,) if isinstance(source, str) else tuple(source)
    merged, order = {}, []
    for name in names:
        try:
            found = library_titles.list_favorites(limit=500, source=name) or []
        except Exception:
            found = []
        for row in found:
            identity = (_kind(row.get('media_type')), str(row.get('canonical_id') or ''))
            known = merged.get(identity)
            if known is None:
                merged[identity] = dict(row, sources=[name])
                order.append(identity)
                continue
            if name not in known['sources']:
                known['sources'].append(name)
            for field in ('title', 'poster', 'background', 'clearlogo', 'plot'):
                if not known.get(field) and row.get(field):
                    known[field] = row[field]
            known['added_at'] = max(int(known.get('added_at') or 0), int(row.get('added_at') or 0))
    rows_out = [merged[identity] for identity in order]
    if len(names) > 1:
        rows_out.sort(key=lambda row: int(row.get('added_at') or 0), reverse=True)
    return rows_out


def _watching(item):
    """7.0.42: the services that follow the title as watched or in progress. A series
    being watched leaves Trakt's watchlist and Simkl's Plan to Watch (it is in
    Watching there), so a long-saved series showed only "Local"."""
    from . import simkl_watched
    kind = _kind(item.get('media_type'))
    forms = _forms(item)
    lists = (('simkl', simkl_watched._remote_snapshot().get('items') or {}),
             ('trakt', simkl_watched._trakt_items()), ('mdblist', simkl_watched._mdblist_items()),
             ('wetrakr', simkl_watched._wetrakr_items()))
    found = []
    for tid, items in lists:
        for form in forms:
            entry = items.get(simkl_watched.key(kind, form))
            if entry and (entry.get('watched') or entry.get('episodes')):
                found.append(tid)
                break
    return found


SERVICE_NAMES = {LOCAL: 'Local', NUVIO: 'Nuvio'}


def service_names():
    """id -> name for every place a title can live, this box and the Nuvio account
    included. One table, so a new service is a line in TRACKERS and nothing else."""
    names = dict(SERVICE_NAMES)
    names.update((tid, name) for tid, name, _, _ in TRACKERS)
    return names


def places_of(item, source, origins):
    """Where this title lives, as ids: 'local', 'nuvio', 'trakt', 'simkl', 'mdblist'.

    8.1.2: ids, not names. The cards draw one small round service icon each now, so
    what they need is which service - the name is only for the text under the title.
    """
    trackers = [tid for tid, _, _, _ in TRACKERS]
    if source == LOCAL or (isinstance(source, tuple) and LOCAL in source):
        here = [name for name in (item.get('sources') or [LOCAL]) if name in SERVICE_NAMES] or [LOCAL]
        try:
            following = [tid for tid in _watching(item) if tid in trackers]
        except Exception:
            following = []
        return here + following
    key = '%s|%s' % (_kind(item.get('media_type')), item.get('canonical_id'))
    found = origins.get(key) or []
    if isinstance(found, str):
        found = [found]          # library_origins.json of the first 6.0.35 build
    return [tid for tid in found if tid in trackers]


def _badges(item, source, origins):
    """Where a title comes from, in words (under the title in the list view)."""
    names = service_names()
    found = [names[tid] for tid in places_of(item, source, origins) if tid in names]
    return found or ([] if (source == LOCAL or (isinstance(source, tuple) and LOCAL in source)) else [tracking_label()])


def _card(item, badges, services=()):
    kind = _kind(item.get('media_type'))
    return {'title': item.get('title') or item.get('canonical_id'), 'poster': _poster(item),
            'fanart': item.get('background') or '', 'landscape': item.get('background') or '',
            'clearlogo': item.get('clearlogo') or '', 'plot': item.get('plot') or '', 'badges': list(badges),
            'services': list(services),
            'added_at': int(item.get('added_at') or 0),
            'target': {'media_type': kind, 'canonical_id': item.get('canonical_id')}}


def counts_by_service():
    """How many titles each place holds: [(id, name, count)], in a fixed order and
    without the ones that hold nothing.

    8.1.2: "ne zanima me koliko ukupno ima nego pored svakog servisa broj njegovih".
    This box and the Nuvio account are counted from their own rows; a tracking service
    from what the badges say, because the mirror keeps one row per title however many
    services list it.
    """
    found = []
    for name in OWN:
        try:
            found.append((name, SERVICE_NAMES[name], len(_items(name))))
        except Exception:
            found.append((name, SERVICE_NAMES[name], 0))
    origins = _origins()
    held = {}
    for item in _items(TRACKING):
        for tid in places_of(item, TRACKING, origins):
            held[tid] = held.get(tid, 0) + 1
    for tid, label, connected, _rows in TRACKERS:
        try:
            if not connected() and not held.get(tid):
                continue
        except Exception:
            if not held.get(tid):
                continue
        found.append((tid, label, held.get(tid, 0)))
    return [(tid, label, count) for tid, label, count in found if count]


def fill_missing_posters(limit=60):
    """Find a picture for the saved titles that have none, and keep it.

    8.1.2: the Nuvio account's library arrives keyed by TMDB id and, for a title whose
    page is new, with no artwork at all - 47 of 76 on the first box this was tried on.
    Those cards drew the placeholder, which is what "dosta postera se ne vidi, ima nas
    baner" is. TMDB is asked once per title, off the screen's thread, and the answer is
    written into the row so it is never asked again.

    Returns how many were filled in.
    """
    from . import library_titles, tmdb_api
    filled = 0
    for source in (LOCAL, NUVIO, TRACKING):
        for item in _items(source):
            if filled >= limit:
                return filled
            if str(item.get('poster') or '').strip():
                continue
            ids = _ids(item)
            canonical = str(item.get('canonical_id') or '')
            if not ids.get('tmdb_id') and canonical.startswith('tmdb:'):
                ids['tmdb_id'] = canonical.split(':', 1)[1]
            kind = _kind(item.get('media_type'))
            try:
                art = tmdb_api.art_for(tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                                       media_type='tv' if kind == 'series' else 'movie',
                                       title=item.get('title') or '', year=item.get('year') or '') or {}
            except Exception as exc:
                xbmc.log('[MegaNexus] Library: no picture for %s: %s' % (canonical, exc), xbmc.LOGDEBUG)
                continue
            poster = str(art.get('poster') or '').strip()
            if not poster:
                continue
            try:
                library_titles.add(kind, canonical, item.get('title') or canonical, poster=poster,
                                   background=str(art.get('background') or item.get('background') or ''),
                                   clearlogo=str(art.get('clearlogo') or art.get('logo') or ''),
                                   plot=item.get('plot') or '', source=source,
                                   added_at=int(item.get('added_at') or 0))   # never restamp it as today
                filled += 1
            except Exception as exc:
                xbmc.log('[MegaNexus] Library: the picture could not be kept: %s' % exc, xbmc.LOGWARNING)
    return filled


def rows(source):
    """(movies, series) cards for the Library screen. 8.1.2: Local is this box AND the
    Nuvio account's own library (OWN) - they are both "mine", and each card says which."""
    source = OWN if source == LOCAL else source
    origins = _origins() if source == TRACKING else {}
    movies, series = [], []
    for item in _items(source):
        found = places_of(item, source, origins)
        card = _card(item, _badges(item, source, origins), found)
        (movies if card['target']['media_type'] == 'movie' else series).append(card)
    return movies, series


MONTHS = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
          'September', 'October', 'November', 'December')


def calendar(limit=14):
    """[(\"October 2026\", cards)] - everything in the Library by the month it
    was added, newest first (month and year only). Older months share the
    last row."""
    import time as _time
    origins = _origins()
    merged = {}
    for source in (OWN, TRACKING):
        for item in _items(source):
            key = (_kind(item.get('media_type')), item.get('canonical_id'))
            badges = _badges(item, source, origins)
            found = places_of(item, source, origins)
            if key in merged:
                old = merged[key]
                old['badges'] += [b for b in badges if b not in old['badges']]
                old['services'] += [s for s in found if s not in old['services']]
                old['added_at'] = max(old['added_at'], int(item.get('added_at') or 0))
            else:
                merged[key] = _card(item, badges, found)
    months, undated = {}, []
    for card in sorted(merged.values(), key=lambda c: c['added_at'], reverse=True):
        if not card['added_at']:
            # 8.1.2: no date from anywhere. It used to be counted as today, which put
            # every such title in the current month and made the Calendar look wrong.
            undated.append(card)
            continue
        stamp = _time.localtime(card['added_at'])
        months.setdefault((stamp.tm_year, stamp.tm_mon), []).append(card)
    ordered = sorted(months.items(), reverse=True)
    result = [('%s %d' % (MONTHS[mon - 1], year), cards) for (year, mon), cards in ordered]
    if undated:
        result.append(('Date unknown', undated))
    if len(result) > limit:
        result = result[:limit - 1] + [('Earlier', [c for _, cards in result[limit - 1:] for c in cards])]
    return result


def refresh_tracking():
    """Pull the connected services' watchlists into the mirror (network; call
    off the GUI thread). One path for the Library, the service and Settings."""
    from . import library_titles
    return library_titles.refresh_list_copy(include_trakt=True)
