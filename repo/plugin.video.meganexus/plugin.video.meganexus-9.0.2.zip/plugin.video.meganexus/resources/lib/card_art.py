# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The pictures of every list item: poster, thumb, icon, background, landscape, banner and
title logo.

Each picture is chosen from an ordered list of places, written as short names:

    m:poster       the item's own field          i:poster,thumb   its `images` object
    h:background   its behaviorHints             f:poster         the caller's fallback art
    db:fanart      TMDb Helper's local artwork   tm:clearlogo     TMDB (tmdb_api)
    =name          a value worked out before     @default         the local placeholder poster
    @banner        MegaNexus' own background

The first place that holds a usable picture wins (`pick`). The modes differ only in their
lists: `native_meta_art` uses what the add-on gave, `enrich_meta_art` puts TMDb Helper /
TMDB first, `hybrid_meta_art` asks them only for a missing background or logo,
`composite_style_meta_art` keeps the add-on's poster and adds the rest (Plexio)."""
import os
import re
from urllib.parse import quote, urlparse

import xbmcaddon

from .hub_log import log
from .tmdb_api import art_for as tmdb_art
from .tmdb_helper_db import stored_pictures, stored_logo

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')
MEDIA = 'special://home/addons/script.meganexus/resources/media'
METAHUB_POSTER_URL = 'https://images.metahub.space/poster/large/%s/img'

SERIES_TYPES = ('series', 'anime', 'tv', 'show')
KODI_SCHEMES = ('http://', 'https://', 'special://', 'image://', 'file://', 'plugin://', 'smb://', 'nfs://')
NOT_A_PICTURE = ('none', 'null', 'n/a', '0')
IMAGE_SIZES = ('full', 'original', 'large', 'medium', 'small', 'thumb', 'url')

# ---- small helpers -----------------------------------------------------------------------


def _setting(key, default=''):
    try:
        value = ADDON.getSetting(key)
    except Exception:
        value = default
    return str(value or default).strip()


def poster_source_mode():
    return _setting('poster_source_mode', 'Local only')


def posters_prefer_local():
    """No remote artwork? The metadata choice decides (Native: yes, TMDb Helper: no); "Auto"
    or unset falls back to the older poster setting."""
    try:
        choice = (xbmcaddon.Addon('plugin.video.meganexus').getSetting('default_meta_source') or '').strip().lower()
    except Exception:
        choice = ''
    if 'native' in choice:
        return True
    if 'tmdb' in choice or 'helper' in choice:
        return False
    return str(poster_source_mode() or '').strip().lower() in ('local only', 'local', '0')


def media_path(name):
    """A picture of the interface; anything but black / white / meganexus_* becomes the mark."""
    if name not in ('black.png', 'white.png') and not name.startswith('meganexus_'):
        name = 'meganexus_mark.png'
    return os.path.join(MEDIA, name)


def addon_fanart():
    return media_path('meganexus_banner.png')


def neutral_fanart():
    return media_path('black.png')


def _placeholder(media_type='movie'):
    return media_path('default_series_poster.png' if media_type in SERIES_TYPES else 'default_movie_poster.png')


def usable(value):
    """The picture address when Kodi can show it ('' for none, a placeholder word or an
    unknown scheme); a path starting with / is kept for the caller to complete."""
    text = str(value or '').strip()
    low = text.lower()
    if not text or low in NOT_A_PICTURE or 'manifest bridge' in low:
        return ''
    if low.startswith(KODI_SCHEMES) or text.startswith('/'):
        return text
    return '' if '://' in text else text


def first(*values):
    return next((picture for picture in map(usable, values) if picture), '')


def from_images(images, *keys):
    """The first picture of an `images` object under these keys (a size object: its largest)."""
    if not isinstance(images, dict):
        return ''
    for key in keys:
        node = images.get(key)
        picture = first(*[node.get(size) for size in IMAGE_SIZES]) if isinstance(node, dict) else first(node)
        if picture:
            return picture
    return ''


def kodi_safe_url(url):
    """An address Kodi's texture cache would mangle (Plex / Plexio / Emby / Jellyfin pictures,
    tokens and transcode options in the query, overlay paths, very long addresses) handed
    over as an opaque image:// address; any other is kept as it is."""
    if not url:
        return url
    text = str(url).strip()
    low = text.lower()
    if not text or low.startswith(('image://', 'special://', 'file://', 'plugin://', 'smb://', 'nfs://', '/')) \
            or not low.startswith(('http://', 'https://')):
        return text
    fragile = len(text) > 250
    fragile = fragile or ('?' in text and any(mark in low for mark in _QUERY_MARKS))
    fragile = fragile or any(mark in low for mark in _PATH_MARKS)
    fragile = fragile or any(host in low for host in _HOSTS)
    if not fragile:
        return text
    try:
        return 'image://%s/' % quote(text, safe='')
    except Exception:
        return text


_QUERY_MARKS = ('x-plex-token', 'api_key=', 'token=', 'access_token=', 'apikey=', '/:/', 'plex', 'emby', 'jellyfin',
                'plexio', 'overlay', 'composite', 'transcode', 'thumb=', 'url=', 'minsize=', 'upscale=', 'width=',
                'height=', 'format=', '/items/')
_PATH_MARKS = ('/:/transcode', '/composite', '/overlay', '/photo/', '/collection-image/')
_HOSTS = ('plexio.', 'plex.tv', 'plexapp.com', 'emby.', 'jellyfin.')


def _safe(url):
    return kodi_safe_url(url) or url


def _logo_set(art, logo):
    if logo:
        for key in ('clearlogo', 'tvshow.clearlogo', 'logo', 'clearart'):
            art[key] = logo


# ---- the place names ----------------------------------------------------------------------

class _Places(object):
    """Where `pick` looks: the item, its images and hints, fallback art, the remote bundles."""

    def __init__(self, meta, media_type, fallback=None, db=None, tmdb=None):
        self.meta = meta
        hints = meta.get('behaviorHints') or {}
        self.hints = hints if isinstance(hints, dict) else {}
        self.images = meta.get('images') or {}
        self.fallback = fallback or {}
        self.db = db or {}
        self.tmdb = tmdb or {}
        self.media_type = media_type
        self.known = {}

    def value(self, place):
        if place == '@default':
            return _placeholder(self.media_type)
        if place == '@banner':
            return addon_fanart()
        source, _, keys = place.partition(':')
        if source == 'i':
            return from_images(self.images, *keys.split(','))
        if place.startswith('='):
            return self.known.get(place[1:], '')
        owner = {'m': self.meta, 'h': self.hints, 'f': self.fallback, 'db': self.db, 'tm': self.tmdb}[source]
        return owner.get(keys)

    def pick(self, places, name=None):
        found = first(*[self.value(place) for place in places.split()])
        if name:
            self.known[name] = found
        return found


ITEM_POSTER = ('m:poster m:posterUrl m:posterURL m:thumbnail m:thumb m:thumbUrl m:thumbURL m:image m:imageUrl '
               'm:imageURL m:plex_original_poster m:parentThumb m:grandparentThumb '
               'i:poster,thumb,thumbnail,cover,image,posterUrl,posterURL')
ITEM_BACKGROUND_IMAGES = 'i:background,fanart,backdrop,landscape,banner,art'
ITEM_LOGO = 'm:clearlogo i:clearlogo,clearart'


def _item_logo(places):
    return first(places.pick(ITEM_LOGO), places.hints.get('clearlogo'))


def native_meta_art(meta, media_type='movie', fallback_art=None):
    """Only the pictures the add-on gave (Plex / Emby rows: no TMDB requests), made safe for Kodi."""
    places = _Places(meta, media_type, fallback_art)
    poster = places.pick(ITEM_POSTER + ' h:poster h:thumbnail h:plex_original_poster f:poster f:thumb @default', 'poster')
    background = places.pick('m:background m:fanart m:landscape m:banner m:backdrop ' + ITEM_BACKGROUND_IMAGES
                             + ' h:background h:fanart', 'background')
    landscape = places.pick('m:landscape m:banner =background i:landscape,banner,fanart,backdrop =poster '
                            'f:landscape f:banner', 'landscape')
    fanart = places.pick('=background =landscape =poster f:fanart f:landscape @banner')
    thumb = places.pick('m:plex_original_poster m:thumbnail m:thumb m:thumbUrl m:thumbURL m:image '
                        'i:thumb,thumbnail,poster,image =poster f:thumb f:poster')
    icon = places.pick('m:plex_original_poster =poster i:poster,thumb f:icon f:poster @default')
    banner = places.pick('m:banner i:banner,landscape,backdrop =background =landscape =poster f:banner')
    fallback = places.fallback
    art = {
        'thumb': kodi_safe_url(thumb) or thumb or poster,
        'poster': kodi_safe_url(poster) or poster or fallback.get('poster') or fallback.get('thumb')
        or _placeholder(media_type),
        'icon': _safe(icon),
        'fanart': _safe(fanart),
        'landscape': _safe(landscape) or _safe(fanart),
        'banner': _safe(banner),
    }
    _logo_set(art, _safe(_item_logo(places)))
    return art


def _remote(meta, media_type, needed=('poster', 'fanart', 'clearlogo')):
    """(ids, TMDb Helper's pictures, TMDB's pictures) - TMDB is asked only when TMDb Helper
    lacks one of ``needed``."""
    ids = extract_ids(meta)
    asked = dict(tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                 media_type='tv' if media_type in SERIES_TYPES else 'movie',
                 title=meta.get('name') or meta.get('title') or '', year=meta.get('releaseInfo') or meta.get('year') or '')
    try:
        local = stored_pictures(**asked) or {}
    except Exception:
        local = {}
    remote = {}
    if not all(local.get(key) for key in needed):
        try:
            remote = tmdb_art(**asked) or {}
        except Exception:
            remote = {}
    return ids, local, remote


def mixed_meta_pictures(meta, media_type='movie', fallback_art=None):
    """The add-on's posters, TMDb Helper / TMDB only for a background or logo it lacks."""
    art = native_meta_art(meta, media_type, fallback_art=fallback_art)
    places = _Places(meta, media_type, fallback_art)
    background = places.pick('m:background m:fanart m:landscape m:banner ' + ITEM_BACKGROUND_IMAGES
                             + ' h:background h:fanart', 'background')
    logo = _item_logo(places)
    asked = not background or not logo
    ids = {'tmdb_id': '', 'imdb_id': ''}
    if asked:
        ids, places.db, places.tmdb = _remote(meta, media_type)
    places.known['art_fanart'], places.known['art_landscape'] = art.get('fanart'), art.get('landscape')
    places.known['art_banner'], places.known['art_poster'] = art.get('banner'), art.get('poster')
    fanart = places.pick('=background db:fanart db:landscape tm:fanart tm:landscape =art_fanart f:fanart '
                         'f:landscape @banner', 'fanart')
    landscape = places.pick('m:landscape m:banner =background db:landscape db:fanart tm:landscape tm:fanart '
                            '=art_landscape =fanart')
    art['fanart'] = fanart
    art['landscape'] = landscape or fanart
    art['banner'] = places.pick('m:banner =background db:landscape tm:landscape =art_banner =art_poster')
    logo = first(logo, places.db.get('clearlogo'), places.tmdb.get('clearlogo'),
                 stored_logo(tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                                       media_type=media_type) if asked else '')
    _logo_set(art, logo)
    return art


def layered_meta_pictures(meta, media_type='movie', fallback_art=None):
    """Plexio: the add-on's poster, its own background / logo first, then TMDb Helper / TMDB."""
    art = native_meta_art(meta, media_type, fallback_art=fallback_art)
    ids, local, remote = _remote(meta, media_type, needed=('fanart', 'clearlogo'))
    places = _Places(meta, media_type, fallback_art, local, remote)
    places.known['art_fanart'], places.known['art_landscape'] = art.get('fanart'), art.get('landscape')
    places.known['art_banner'] = art.get('banner')
    places.pick('m:background m:fanart m:backdrop m:landscape m:banner ' + ITEM_BACKGROUND_IMAGES
                + ' h:background h:fanart', 'background')
    fanart = places.pick('=background db:fanart db:landscape tm:fanart tm:landscape =art_fanart f:fanart '
                         'f:landscape @banner', 'fanart')
    landscape = places.pick('m:landscape m:banner =background i:landscape,banner,fanart,backdrop db:landscape '
                            'db:fanart tm:landscape tm:fanart =art_landscape =fanart', 'landscape')
    banner = places.pick('m:banner i:banner,landscape,backdrop =background =landscape =art_banner')
    art['fanart'] = _safe(fanart)
    art['landscape'] = kodi_safe_url(landscape) or landscape or art.get('fanart')
    if banner:
        art['banner'] = _safe(banner)
    logo = first(places.pick('m:clearlogo m:logo m:clearart i:clearlogo,clearart,logo'),
                 places.hints.get('clearlogo'), places.hints.get('logo'), local.get('clearlogo'), remote.get('clearlogo'),
                 stored_logo(tmdb_id=ids.get('tmdb_id') or '', imdb_id=ids.get('imdb_id') or '',
                                       media_type='tv' if media_type in SERIES_TYPES else 'movie'))
    _logo_set(art, _safe(logo))
    return art


def enrich_meta_art(meta, media_type='movie', fallback_art=None):
    """TMDb Helper / TMDB pictures first (some add-on poster addresses do not load on every
    device), the add-on's after; never the add-on's own background or logo for a title."""
    ids, local, remote = _remote(meta, media_type)
    places = _Places(meta, media_type, fallback_art, local, remote)
    item_poster = places.pick(ITEM_POSTER, 'item_poster')
    poster = places.pick('db:poster tm:poster =item_poster h:poster f:poster f:thumb f:icon @default', 'poster')
    backgrounds = 'm:background m:fanart m:backdrop ' + ITEM_BACKGROUND_IMAGES + ' h:background'
    fanart = places.pick('db:fanart tm:fanart ' + backgrounds + ' db:landscape tm:landscape h:poster =item_poster '
                         'f:fanart f:landscape f:poster f:thumb @banner', 'fanart')
    landscape = places.pick('db:landscape tm:landscape db:fanart tm:fanart ' + backgrounds
                            + ' =item_poster f:poster f:thumb =fanart')
    banner = places.pick('m:banner i:banner,landscape,backdrop m:background =item_poster f:banner')
    thumb = places.pick('m:thumbnail m:thumb i:thumb,thumbnail,poster =item_poster =poster f:thumb f:poster')
    icon = places.pick('=item_poster i:poster,thumb =poster f:icon f:poster @default')
    fallback = places.fallback
    poster_final = kodi_safe_url(poster or fallback.get('poster') or fallback.get('thumb') or _placeholder(media_type))
    art = {
        'thumb': kodi_safe_url(thumb or poster_final),
        'poster': poster_final,
        'icon': kodi_safe_url(icon),
        'fanart': kodi_safe_url(fanart),
        'landscape': kodi_safe_url(landscape),
        'banner': kodi_safe_url(banner),
    }
    logo = _item_logo(places)
    if not logo:
        logo = first(local.get('clearlogo'), remote.get('clearlogo'),
                     stored_logo(tmdb_id=ids.get('tmdb_id'), imdb_id=ids.get('imdb_id'),
                                           media_type=media_type))
    _logo_set(art, logo)
    return art


# ---- menus: root folders, providers, catalogs -------------------------------------------

ROOT_ICONS = {
    'add': 'root_add.png', 'providers': 'root_sources.png', 'search_movie': 'root_search_movie.png',
    'search_series': 'root_search_series.png', 'continue': 'root_continue.png', 'catalogs': 'root_catalogs.png',
    'plex': 'provider_plex.png', 'emby': 'provider_emby.png', 'jellyfin': 'provider_jellyfin.png',
    'emby_jellyfin': 'provider_emby_jellyfin.png', 'trakt': 'trakt.png', 'tmdb': 'tmdb.png', 'mdblist': 'mdblist.png',
    'simkl': 'simkl.png', 'stremio': 'stremio.png', 'kodi': 'kodi.png', 'settings': 'settings.png',
    'nextup': 'up-next.png', 'favorites': 'cat_watchlist.png', 'watchlist': 'cat_watchlist.png',
    'movies': 'cat_movies.png', 'series': 'cat_series.png', 'anime': 'cat_anime.png',
    'turkish': 'cat_series.png', 'korean': 'cat_series.png', 'live': 'cat_live.png', 'accounts': 'root_accounts.png',
}
ROOT_BG = {'search_movie': 'meganexus_banner.png', 'search_series': 'meganexus_banner.png'}
PROVIDER_ICONS = (('jellyfin', 'provider_jellyfin.png'), ('plex', 'provider_plex.png'), ('emby', 'provider_emby.png'),
                  ('mdblist', 'mdblist.png'), ('simkl', 'simkl.png'), ('stremio', 'stremio.png'), ('tmdb', 'tmdb.png'),
                  ('trakt', 'trakt.png'), ('kodi', 'kodi.png'))
CATALOG_ICONS = (('watchlist', 'cat_watchlist.png'), ('continue', 'cat_continue.png'), ('next up', 'cat_continue.png'),
                 ('4k', 'cat_4k.png'), ('anime', 'cat_anime.png'), ('kids', 'cat_kids.png'),
                 ('document', 'cat_doc.png'), ('doc', 'cat_doc.png'), ('collection', 'cat_collection.png'),
                 ('search', 'cat_search.png'))


def _menu_art(icon, background, logo):
    """The whole picture set skins read for a menu row (wide skins pick their view from it)."""
    return {'thumb': icon, 'icon': icon, 'poster': icon, 'fanart': background, 'landscape': background,
            'banner': background, 'clearlogo': logo, 'tvshow.clearlogo': logo, 'clearart': logo, 'logo': logo}


def normalize_name(value):
    return re.sub(r'\s+', ' ', str(value or '').strip().lower())


def root_art(key):
    logo = media_path(ROOT_ICONS.get(key, 'provider.png'))
    return _menu_art(logo, media_path(ROOT_BG.get(key, 'meganexus_banner.png')), logo)


def provider_art(name='', manifest=None, base_url=''):
    """An add-on's row: its own logo (a relative one completed with its address), else ours."""
    manifest = manifest or {}
    slug = normalize_name(name)
    ours = next((asset for word, asset in PROVIDER_ICONS if word in slug), 'provider.png')
    logo = first(manifest.get('logo'), manifest.get('icon'))
    if logo and logo.startswith('/') and base_url:
        try:
            parts = urlparse(base_url)
            if parts.scheme and parts.netloc:
                logo = '%s://%s%s' % (parts.scheme, parts.netloc, logo)
        except Exception as exc:
            log.silent('ART', exc)
    icon = first(logo or '', media_path(ours))
    return _menu_art(icon, first(manifest.get('background'), manifest.get('fanart'), addon_fanart()),
                     first(manifest.get('clearlogo'), manifest.get('logo'), icon))


def catalog_art(name='', media_type='movie', manifest=None, catalog=None):
    """A catalog's row: its own icon, else one of ours by its name (a real clearlogo only as logo)."""
    manifest, catalog = manifest or {}, catalog or {}
    icon = first(catalog.get('icon'), catalog.get('logo'))
    if not icon:
        slug = normalize_name(name)
        default = 'cat_series.png' if media_type in SERIES_TYPES else 'cat_movies.png'
        icon = media_path(next((asset for word, asset in CATALOG_ICONS if word in slug), default))
    background = first(catalog.get('background'), catalog.get('fanart'), manifest.get('background'),
                       manifest.get('fanart'), addon_fanart())
    return _menu_art(icon, background, first(catalog.get('clearlogo'), manifest.get('clearlogo')) or icon)


# ---- ids and the poster of the source screens -------------------------------------------

ID_KEYS = ('imdb_id', 'tmdb_id', 'tvdb_id', 'imdb', 'tmdb', 'tvdb', 'guid', 'external_id', 'imdbId', 'tmdbId',
           'tvdbId', 'anidbId')
# (kind, pattern) read from all the id texts of an item, first found wins per kind
ID_PATTERNS = (
    ('tmdb', r'tmdb(?::(?:movie|series|show|tv))?:(\d+)'), ('tmdb', r'themoviedb://(?:tv-)?(\d+)'),
    ('tmdb', r'tmdb://(\d+)'), ('imdb', r'\btt\d{5,10}\b'), ('imdb', r'imdb(?::|://)?(tt\d{5,10})'),
    ('tvdb', r'tvdb(?::|://)?(\d+)'), ('tvdb', r'thetvdb://(\d+)'),
)


def _id_texts(meta):
    texts = [str(meta.get('id') or '')]
    texts += [str(meta[key]) for key in ID_KEYS if meta.get(key)]
    external = meta.get('externalIds') or {}
    if isinstance(external, dict):
        texts += [str(value) for value in external.values() if value]
    hints = meta.get('behaviorHints') or {}
    if isinstance(hints, dict):
        texts += [str(hints[key]) for key in ('imdb_id', 'tmdb_id', 'tvdb_id', 'filename') if hints.get(key)]
        more = hints.get('externalIds') or {}
        if isinstance(more, dict):
            texts += [str(value) for value in more.values() if value]
    for link in meta.get('links') or []:
        if isinstance(link, dict):
            texts += [str(link[key]) for key in ('name', 'category', 'url', 'externalUrl') if link.get(key)]
        elif link:
            texts.append(str(link))
    return texts


def extract_ids(meta):
    """{tmdb_id, imdb_id, tvdb_id} of an item: its own id first ("tt…", "imdb:tt…", "tmdb:123",
    "tvdb:123"), then every id field, hint and link."""
    raw = str(meta.get('id') or '')
    low = raw.lower().strip()
    found = {'tmdb': '', 'imdb': '', 'tvdb': ''}
    tail = raw.split(':')[-1].strip()
    if low.startswith('tt'):
        found['imdb'] = raw.strip()
    elif low.startswith('imdb:tt'):
        found['imdb'] = raw.split(':', 1)[-1].strip()
    elif low.startswith(('tmdb:', 'tvdb:')) and tail.isdigit():
        found[low[:4]] = tail
    joined = ' '.join(_id_texts(meta))
    for kind, pattern in ID_PATTERNS:
        match = re.search(pattern, joined, re.I)
        if match and not found[kind]:
            value = match.group(1) if match.groups() else match.group(0)
            found[kind] = match.group(0) if kind == 'imdb' and not str(value).startswith('tt') else value
    return {'tmdb_id': found['tmdb'], 'imdb_id': found['imdb'], 'tvdb_id': found['tvdb']}


TRUSTED_POSTER_HOSTS = ('image.tmdb.org', 'images.metahub.space', 'media-amazon.com', 'm.media-amazon.com',
                        'img.youtube.com', 'i.imgur.com', 'fanart.tv', 'assets.fanart.tv', 'static.metahub.space',
                        'image.com', 'imgcdn', 'imageapi')
LOGO_FILES = tuple('/%s.%s' % (name, ext) for name, exts in (
    ('icon', ('png', 'jpg', 'jpeg', 'webp')), ('logo', ('png', 'jpg', 'jpeg', 'webp')), ('addon', ('png', 'jpg')),
    ('favicon', ('png', 'ico', 'jpg')), ('poster', ('png', 'jpg')), ('banner', ('png', 'jpg'))) for ext in exts)
LOGO_FOLDERS = ('/logo/', '/icon/', '/icons/', '/branding/', '/brand/', '/assets/icon')


def poster_is_logo(url):
    """An add-on's icon / logo handed over as a "poster" (picture CDNs are trusted)."""
    if not url or not isinstance(url, str):
        return False
    low = url.lower()
    if any(host in low for host in TRUSTED_POSTER_HOSTS):
        return False
    return low.endswith(LOGO_FILES) or any(folder in low for folder in LOGO_FOLDERS)


def usable_poster(meta, media_type='movie'):
    """The poster of the source screens: TMDb Helper's, the add-on's (not a logo), MetaHub's by
    IMDb id, then the 2:3 placeholder - never a wide picture squeezed into the card."""
    meta = meta if isinstance(meta, dict) else {}
    ids = extract_ids(meta)
    imdb_id, tmdb_id = str(ids.get('imdb_id') or '').strip(), str(ids.get('tmdb_id') or '').strip()
    try:
        local = str((stored_pictures(
            tmdb_id=tmdb_id, imdb_id=imdb_id,
            media_type='tv' if media_type in SERIES_TYPES + ('tvshow', 'episode') else 'movie',
            title=meta.get('title') or meta.get('name') or '',
            year=meta.get('year') or meta.get('releaseInfo') or '') or {}).get('poster') or '').strip()
        if local and not poster_is_logo(local):
            return local
    except Exception:
        pass
    own = str(meta.get('poster') or '').strip()
    if own and not poster_is_logo(own):
        return own
    if imdb_id:
        return METAHUB_POSTER_URL % imdb_id
    try:
        return _placeholder(media_type)
    except Exception:
        return ''
