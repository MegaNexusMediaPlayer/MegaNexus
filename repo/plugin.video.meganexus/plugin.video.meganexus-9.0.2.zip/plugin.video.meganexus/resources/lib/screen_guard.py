# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A MegaNexus window is on screen: nothing may pull the skin out from under it.

8.1.2, after a crash. The profile picker is open at Kodi's start. Behind it the
component installer finishes writing the new interface and skin and runs ReloadSkin.
Kodi unloads every window, frees their controls and builds them again. The picker was
in the middle of a key press - its context menu, then the keyboard for the new name -
and when that returned it refilled its list, on controls that no longer existed.
SIGSEGV inside Kodi, from our Python; the backtrace reads Python -> Kodi -> our
callback -> Kodi -> crash.

The cure is not to be careful during the reload - the Python API has no "the skin is
being replaced right now" to ask - it is for the reload not to happen while a window
of ours is up. The installer already waited for 'meganexus.frontend.running', but the
picker at Kodi's start does not go through ui_entry.launch() and so never set it, and
every future window opened outside launch() would have the same hole. hold()/release()
is the one mark for all of them, read across processes through the Home window.

Not reloading costs nothing: Kodi keeps the skin it has until its next start, and the
components are already on disk.
"""
HELD = 'meganexus.screen.held'      # how many MegaNexus windows are on screen


def _home():
    import xbmcgui
    return xbmcgui.Window(10000)


def _count(home):
    try:
        return max(0, int(home.getProperty(HELD) or '0'))
    except ValueError:
        return 0


def hold():
    """One of our windows is on screen. Always paired with release() in a finally."""
    try:
        home = _home()
        home.setProperty(HELD, str(_count(home) + 1))
    except Exception:
        pass


def release():
    try:
        home = _home()
        count = _count(home)
        if count <= 1:
            home.clearProperty(HELD)
        else:
            home.setProperty(HELD, str(count - 1))
    except Exception:
        pass


def held():
    """True while any MegaNexus window is on screen - do not reload the skin now."""
    try:
        return bool(_home().getProperty(HELD))
    except Exception:
        return False


def clear():
    """A crashed or killed interface can leave the mark behind; the service drops it at
    its start, when no window of ours can be on screen yet."""
    try:
        _home().clearProperty(HELD)
    except Exception:
        pass
