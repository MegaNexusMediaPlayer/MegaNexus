# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Watch Party itself (7.0.52): friends, invites, joining, the party channel.

Two ways in, both end-to-end encrypted, no server of ours (Nostr relays only):

* inbox - gift wraps (NIP-59) to our key: friend requests and answers, party invites,
  join requests, a party's key. Relays see only who it is for.
* party channel - ephemeral events (relays keep nothing) tagged with a value only members
  can work out (party_crypto.party_tag), the content NIP-44 encrypted with the party's
  key: hello / bye, the host's playback state, chat, ping / pong, the film, the roster.

A party's key is new for every party and changes when someone is removed (they keep the
old one, which nobody uses any more). Joining with a code: the code only finds the host;
the host lets the person in (approve) and only then sends the key. Old messages (more than
a couple of minutes) and anything not from a member are dropped. Content, links and keys
never go into the log.
"""
import hashlib
import json
import os
import threading
import time
from collections import deque

from . import party_crypto as crypto
from . import party_identity as ident
from . import party_sync as sync
from .party_relays import RelayPool, DEFAULT_RELAYS

CHANNEL_KIND = 20444            # ephemeral: relays pass it on and keep nothing
RUMOR_KIND = 20446              # the kind inside a gift wrap (never published as such)
LOBBY_KIND = 30078              # NIP-78 app data: a code's lobby (expires)
INBOX_DAYS = 3                  # gift wraps this old are still read (an invite while the TV was off)
# 7.0.61: party messages are ephemeral - relays keep none, so each one arrives as it is said. Judged
# by the clocks (2 minutes) a TV whose clock was a few minutes off was not heard at all - and heard
# nothing: the host counted 1 and the guest 2, the film never started there. Only a message from a
# clock this far off is dropped now; the film's times go through each TV's measured offset (ping).
MAX_AGE = 6 * 3600              # s
CLOCK_EVERY = 60                # s: a guest measures its clock against the host's this often
LOBBY_FOR = 600                 # s a join code is valid
MAX_MEMBERS = 8
CHAT_KEPT = 50
CHAT_MAX = 300                  # characters of one message
ALIVE_EVERY = 30                # s: the host says "still here" (also with no film playing)
# 7.0.61: was 90 s - a relay that dropped us for a minute or refused the host's messages ended the
# party on a guest while the host only rested (screensaver). A party ends with its button, a
# restart or a standby (the host's "end"); this is only for a host gone without a word (power cut)
HOST_GONE = 300                 # s without a word from the host: the party has ended for the guest
INVITE_FOR = 2 * 3600           # s an invite stays (7.0.58: an ended party's invite led into an empty party)
ACTIVE = 'party_active.json'
INVITE_LOG = 'party_invites.json'  # 7.0.61: invites already shown and parties already over (this profile)
MESSAGES = 'party_messages.json'    # direct messages with friends (this profile only, never in a backup)
# 7.0.61: a friend whose Kodi went without a word (closed hard, power, network) was shown online
# for up to 5 minutes - now 2.5 at most: "I am here" every minute, two missed and a bit = offline
ONLINE_EVERY = 60                   # s: friends hear "I am here" this often
ONLINE_FOR = 150                    # s: a friend heard from this recently is online
LIVE_AFTER = 20.0                   # s after the start: what arrives is new, not the relays' last minutes
OFFLINE_WAIT = 2.0                  # s: Kodi closing waits this long at most for the relays to take "offline"
ONLINE_EXPIRES = 600                # s: relays drop the "I am here" wraps after this (NIP-40)
DM_KEPT = 50                        # messages kept per friend


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Watch Party: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def media_key(media):
    """The same film (and episode) on every TV."""
    media = media or {}
    return '%s|%s|%s' % (media.get('id') or '', media.get('season') or '', media.get('episode') or '')


def lobby_tag(code):
    return hashlib.sha256(('meganexus-lobby|%s' % code).encode('ascii')).hexdigest()[:32]


def lobby_key(code):
    return crypto.party_conversation(hashlib.sha256(('meganexus-lobby-key|%s' % code).encode('ascii')).digest())


class Party(object):
    def __init__(self, party_id, secret, host, me):
        self.id, self.secret, self.host, self.me = party_id, secret, host, me
        self.tag = crypto.party_tag(secret)
        self.key = crypto.party_conversation(secret)
        self.members = {}               # public -> {'name', 'seen', 'status'}
        self.state = None               # the host's last playback state
        self.media = None               # what the host plays
        self.share = None               # the host's shared stream (only when the host chose so)
        self.chat = deque(maxlen=CHAT_KEPT)
        self.waiting = {}               # code joiners waiting for the host: public -> name
        self.invited = set()            # friends the host invited: their hello lets them in
        self.code = ''
        self.code_until = 0
        self.seq = 0
        self.event = 0                  # 7.0.55: what the host did (start, play, pause, jump) - guests follow these
        self.ready = set()              # guests whose film plays (the host waits for them at the start)
        self.confirmed = False          # a guest: the host has answered (its roster, state or film)
        self.hello_at = 0.0
        self.host_seen = time.time()    # a guest: when the host was last heard
        self.alive_at = 0.0             # the host: when it last said "still here"
        self.pinged_at = 0.0            # a guest: when it last measured the host's clock
        self.sub = 'party-' + party_id[:8]

    @property
    def hosting(self):
        return self.host == self.me

    def summary(self):
        return {'id': self.id, 'host': self.host, 'hosting': self.hosting, 'code': self.code,
                'members': [dict(m, public=p) for p, m in self.members.items()],
                'waiting': [{'public': p, 'name': n} for p, n in self.waiting.items()],
                'media': self.media, 'shared': bool(self.share), 'chat': list(self.chat)}


class PartyEngine(object):
    """``store``: where friends and the active party are kept (party_identity's files by
    default; tests give their own). Callbacks are optional: ``on_change()``,
    ``on_state(state)``, ``on_chat(message)``, ``on_media(media, share)``, ``on_invite(invite)``."""

    def __init__(self, identity=None, name=None, relays=DEFAULT_RELAYS, store=None, findable=False, clock=time.time):
        self.identity = identity or ident.identity()
        self.secret, self.me = self.identity['secret'], self.identity['public']
        self.name = (name or ident.display_name())[:24]
        self.store = store or FileStore()
        self.findable = findable
        self.clock = clock
        self.pool = RelayPool(relays, self.secret)
        self.lock = threading.RLock()
        self.party = None
        self.invites = {}               # party id -> invite (from friends)
        self.found = {}                 # friend code / name searches: public -> entry
        self.offsets = sync.Offsets()
        self.handled = deque(maxlen=500)
        self.seen = {}                  # friend -> when last heard from (online), on our clock
        self.heard = {}                 # friend -> the newest "online" time on its own clock (7.0.61)
        self.began = time.monotonic()
        self.asked = {}                 # host -> (party id, until): our join requests (only they may let us in)
        self.messages = self._load_messages()
        self.invite_log = self._load_invite_log()
        self.stopping = threading.Event()
        self.on_change = self.on_state = self.on_chat = self.on_media = self.on_invite = self.on_control = None
        self.on_dm = None

    # --- life -----------------------------------------------------------------------------
    def start(self):
        self.pool.start()
        since = int(self.clock() - INBOX_DAYS * 86400)
        self.pool.subscribe('inbox', [{'kinds': [1059], '#p': [self.me], 'since': since}], self._inbox)
        threading.Thread(target=self._announce, name='MegaNexusPartyDirectory', daemon=True).start()
        threading.Thread(target=self._presence, name='MegaNexusPartyOnline', daemon=True).start()
        # 7.0.58: a party never outlives Kodi - nothing is joined again after a restart (an old
        # party file from earlier versions goes)
        self.store.save_active(None)
        return self

    def stop(self):
        """Kodi closes, restarts or goes to standby: the host ends the party for everyone, a guest
        leaves it (7.0.58)."""
        self.stopping.set()
        party = self.party
        if party is not None:
            self.leave()
            time.sleep(0.3)                           # on its way before the relays close
        friends = self._friends_now()
        if friends:
            # 7.0.61: "offline" really reaches the relays before they close (sent and left at once,
            # it was often lost - friends saw this TV online minutes after Kodi closed)
            expires = self.clock() + ONLINE_EXPIRES
            sending = [threading.Thread(target=self._send, args=(public, {'type': 'offline'}),
                                        kwargs={'wait': OFFLINE_WAIT, 'expires': expires}, daemon=True)
                       for public in friends]
            for thread in sending:
                thread.start()
            until = time.monotonic() + OFFLINE_WAIT + 0.2
            for thread in sending:
                thread.join(max(0.0, until - time.monotonic()))
        self.pool.stop()

    # --- friends online -------------------------------------------------------------------------
    def _friends_now(self):
        return [p for p, row in self.store.friends().items() if row.get('state') == 'friend']

    def _tell_friends(self, payload, wait=0):
        for public in self._friends_now():
            try:
                self._send(public, payload, wait=wait, expires=self.clock() + ONLINE_EXPIRES)
            except Exception:
                pass

    def _presence(self):
        """Our friends hear "I am here" every ONLINE_EVERY seconds (encrypted, gone after
        ONLINE_EXPIRES on the relays); a friend heard from lately is online."""
        if not self.pool.wait_connected(15):
            return
        while not self.stopping.is_set():
            self._tell_friends({'type': 'online', 'name': self.name})
            if self.stopping.wait(ONLINE_EVERY):
                return

    def online(self, public):
        return self.clock() - self.seen.get(public, 0) < ONLINE_FOR

    def _got_online(self, sender, payload, at):
        if not self._is_friend(sender):
            return
        newer = at > self.heard.get(sender, 0)
        self.heard[sender] = max(self.heard.get(sender, 0), at)
        now = self.clock()
        if now - at < ONLINE_FOR:
            self.seen[sender] = max(self.seen.get(sender, 0), min(at, now))   # a clock ahead: not longer
        elif newer and time.monotonic() - self.began > LIVE_AFTER:
            # 7.0.61: a newer "I am here" while we run is said now - its TV's clock is behind
            self.seen[sender] = now

    def _got_offline(self, sender, payload, at):
        if sender in self.seen and at >= self.heard.get(sender, 0):   # both on the friend's own clock
            self.seen.pop(sender, None)

    def _is_friend(self, public):
        return (self.store.friends().get(public) or {}).get('state') == 'friend'

    # --- direct messages between friends ------------------------------------------------------------
    def _load_messages(self):
        load = getattr(self.store, 'load_messages', None)
        try:
            data = load() if load else {}
        except Exception:
            data = {}
        return data if isinstance(data, dict) else {}

    def _save_messages(self):
        save = getattr(self.store, 'save_messages', None)
        if save:
            try:
                save(self.messages)
            except Exception:
                pass

    def message(self, public, text):
        """A direct message to a friend (only friends, both sides confirmed)."""
        text = ' '.join(str(text or '').split())[:CHAT_MAX]
        if not text:
            return False
        if not self._is_friend(public):
            raise ValueError('Only friends get direct messages.')
        with self.lock:
            talk = self.messages.setdefault(public, {'items': [], 'unread': 0})
            talk['items'] = (talk['items'] + [{'from': self.me, 'text': text, 'at': self.clock()}])[-DM_KEPT:]
            self._save_messages()
        self._send(public, {'type': 'dm', 'text': text, 'name': self.name}, wait=0)
        self._changed()
        return True

    def read(self, public):
        with self.lock:
            talk = self.messages.get(public)
            if talk and talk.get('unread'):
                talk['unread'] = 0
                self._save_messages()
        self._changed()

    def _got_dm(self, sender, payload, at):
        if not self._is_friend(sender):
            return                                    # strangers cannot write to us
        text = ' '.join(str(payload.get('text') or '').split())[:CHAT_MAX]
        if not text:
            return
        self.seen[sender] = max(self.seen.get(sender, 0), min(at, self.clock()))
        talk = self.messages.setdefault(sender, {'items': [], 'unread': 0})
        if any(m.get('from') == sender and m.get('at') == at and m.get('text') == text for m in talk['items']):
            return                                    # read again after a restart (the inbox keeps 3 days)
        talk['items'] = (talk['items'] + [{'from': sender, 'text': text, 'at': at}])[-DM_KEPT:]
        talk['unread'] = int(talk.get('unread') or 0) + 1
        self._save_messages()
        name = (self.store.friends().get(sender) or {}).get('name') or str(payload.get('name') or 'A friend')[:24]
        if self.on_dm:
            try:
                self.on_dm({'from': sender, 'name': name, 'text': text, 'at': at})
            except Exception:
                pass

    def _announce(self):
        if self.pool.wait_connected(15):
            self.pool.publish(ident.directory_event(self.secret, self.name, self.findable))

    def _changed(self):
        if self.on_change:
            try:
                self.on_change()
            except Exception:
                pass

    # --- finding people -----------------------------------------------------------------------
    def find(self, code='', name='', wait=6.0):
        """[{'public', 'name', 'code'}] of MegaNexus profiles with this friend code or exact name."""
        code = ident.clean_code(code)
        if not code and not (name or '').strip():
            return []
        found, done = {}, threading.Event()
        sub = 'find-%d' % int(self.clock() * 1000)

        def got(event, host):
            entry = ident.entry_of(event)
            if entry and entry['public'] != self.me and (not code or entry['code'] == code):
                found[entry['public']] = entry
                done.set()
        self.pool.subscribe(sub, [ident.directory_filter(code, name)], got)
        done.wait(wait)
        time.sleep(0.5 if found else 0)
        self.pool.unsubscribe(sub)
        return list(found.values())

    # --- the inbox --------------------------------------------------------------------------------
    def _send(self, public, payload, wait=3, expires=None):
        rumor = {'kind': RUMOR_KIND, 'content': json.dumps(payload, separators=(',', ':')), 'tags': []}
        return self.pool.publish(crypto.gift_wrap(rumor, self.secret, public, expires=expires), wait=wait)

    def _inbox(self, event, host):
        try:
            sender, rumor = crypto.unwrap(event, self.secret)
        except Exception:
            return
        if rumor.get('kind') != RUMOR_KIND or rumor.get('id') in self.handled:
            return
        self.handled.append(rumor.get('id'))
        try:
            payload = json.loads(rumor.get('content') or '{}')
        except ValueError:
            return
        if self.clock() - int(rumor.get('created_at') or 0) > INBOX_DAYS * 86400:
            return
        handler = getattr(self, '_got_' + str(payload.get('type') or '').replace('-', '_'), None)
        if handler:
            with self.lock:
                handler(sender, payload, int(rumor.get('created_at') or 0))
            self._changed()

    def add_friend(self, public, name=''):
        """A friend request (they see our name and the same pair code)."""
        friends = self.store.friends()
        if (friends.get(public) or {}).get('state') == 'asking':
            return self.accept_friend(public)
        self.store.set_friend(public, name, 'asked')
        self._send(public, {'type': 'friend-request', 'name': self.name})
        self._changed()
        return crypto.pair_code(self.me, public)

    def accept_friend(self, public):
        row = self.store.friends().get(public) or {}
        self.store.set_friend(public, row.get('name'), 'friend', confirmed=True)
        self._send(public, {'type': 'friend-accept', 'name': self.name})
        self._changed()
        return crypto.pair_code(self.me, public)

    def remove_friend(self, public):
        self.store.remove_friend(public)
        self._send(public, {'type': 'friend-remove'})
        self._changed()

    def _got_friend_request(self, sender, payload, at):
        row = self.store.friends().get(sender) or {}
        if row.get('state') == 'friend':
            return
        if row.get('state') == 'asked':        # both asked: friends at once
            self.store.set_friend(sender, payload.get('name'), 'friend', confirmed=True)
            self._send(sender, {'type': 'friend-accept', 'name': self.name})
            return
        self.store.set_friend(sender, payload.get('name'), 'asking')

    def _got_friend_accept(self, sender, payload, at):
        if (self.store.friends().get(sender) or {}).get('state') in ('asked', 'friend'):
            self.store.set_friend(sender, payload.get('name'), 'friend', confirmed=True)

    def _got_friend_remove(self, sender, payload, at):
        self.store.remove_friend(sender)

    # --- parties: host --------------------------------------------------------------------------
    def create(self):
        """A new party with us as host."""
        with self.lock:
            self.leave()
            party = Party(os.urandom(8).hex(), os.urandom(32), self.me, self.me)
            party.members[self.me] = {'name': self.name, 'seen': self.clock(), 'status': 'host'}
            self._enter(party)
        self._changed()
        return party.summary()

    def invite(self, public):
        party = self._hosting()
        if not self.store.friends().get(public, {}).get('state') == 'friend':
            raise ValueError('Invite friends only.')
        party.invited.add(public)
        self._send(public, {'type': 'invite', 'party': party.id, 'secret': party.secret.hex(), 'host': self.me,
                            'name': self.name, 'media': party.media})

    def open_code(self):
        """A join code (valid LOBBY_FOR seconds): people who type it can ask to join."""
        party = self._hosting()
        code = ''.join(ident.ALPHABET[b % len(ident.ALPHABET)] for b in os.urandom(ident.CODE_LENGTH))
        party.code, party.code_until = code, self.clock() + LOBBY_FOR
        content = crypto.encrypt(json.dumps({'party': party.id, 'name': self.name}), lobby_key(code))
        expires = int(self.clock() + LOBBY_FOR)
        event = crypto.sign_event(LOBBY_KIND, content, [['d', 'meganexus-lobby'], ['t', lobby_tag(code)],
                                                        ['expiration', str(expires)]], self.secret)
        self.pool.publish(event, wait=3)
        self._changed()
        return code

    def approve(self, public):
        party = self._hosting()
        name = party.waiting.pop(public, None)
        if name is None:
            raise ValueError('Nobody is waiting with that name any more.')
        self._admit(party, public, name)

    def deny(self, public):
        party = self._hosting()
        party.waiting.pop(public, None)
        self._changed()

    def _admit(self, party, public, name):
        if len(party.members) >= MAX_MEMBERS:
            raise ValueError('The party is full (%d).' % MAX_MEMBERS)
        party.members[public] = {'name': name, 'seen': self.clock(), 'status': 'joining'}
        self._send(public, {'type': 'party-key', 'party': party.id, 'secret': party.secret.hex(), 'host': self.me,
                            'name': self.name, 'media': party.media})
        self._roster(party)
        self._changed()

    def remove(self, public):
        """Out of the party: a new key for everyone else (the removed one keeps a dead key)."""
        party = self._hosting()
        if public == self.me or public not in party.members:
            return
        del party.members[public]
        self._send(public, {'type': 'removed', 'party': party.id})
        self._rekey(party)

    def _rekey(self, party):
        old_sub = party.sub
        party.secret = os.urandom(32)
        party.tag, party.key = crypto.party_tag(party.secret), crypto.party_conversation(party.secret)
        party.sub = 'party-%s-%d' % (party.id[:8], int(self.clock()))
        self.pool.unsubscribe(old_sub)
        self._subscribe(party)
        for member in party.members:
            if member != self.me:
                self._send(member, {'type': 'party-key', 'party': party.id, 'secret': party.secret.hex(),
                                    'host': self.me, 'name': self.name, 'media': party.media})
        self._roster(party)
        self._changed()

    def set_media(self, media, share=None):
        """The host plays something: ``media`` names the title and the release (never a link);
        ``share``: the host's own stream for guests without a source - only when the host chose."""
        party = self._hosting()
        if media_key(media) != media_key(party.media):
            party.ready = set()                       # a new film: everyone gets ready again
        party.media, party.share = media, share
        self._say({'type': 'media', 'media': media, 'share': share})
        self._changed()

    def send_state(self, paused, position_ms, duration_ms=0, waiting=False, bump=False):
        """``bump``: the host did something (start, play, pause, jump) - guests follow it."""
        party = self._hosting()
        party.seq += 1
        if bump:
            party.event += 1
        state = {'type': 'state', 'seq': party.seq, 'paused': bool(paused), 'pos': int(position_ms),
                 'dur': int(duration_ms or 0), 'at': int(self.clock() * 1000), 'waiting': bool(waiting),
                 'event': party.event, 'from': self.me}
        party.state = state
        self._say(state)

    def _hosting(self):
        party = self.party
        if party is None or not party.hosting:
            raise ValueError('Start a party first.')
        return party

    def _roster(self, party):
        self._say({'type': 'roster', 'members': {p: m['name'] for p, m in party.members.items()}})

    # --- parties: guest ---------------------------------------------------------------------------
    def _got_invite(self, sender, payload, at):
        if not self.store.friends().get(sender, {}).get('state') == 'friend' or payload.get('host') != sender:
            return
        party_id = str(payload.get('party'))
        if self.clock() - at > INVITE_FOR or party_id in self.invite_log['gone']:
            return                                     # an old invite or a party that is over
        if self.party is not None and self.party.id == party_id:
            return                                     # already in it
        invite = {'party': party_id, 'secret': str(payload.get('secret')), 'host': sender,
                  'name': str(payload.get('name') or '')[:24], 'media': payload.get('media'), 'at': at}
        self.invites[party_id] = invite
        if party_id in self.invite_log['shown']:
            return                                     # listed in Watch Party, never shown again
        self._note_invite('shown', party_id, at)
        if self.on_invite:
            try:
                self.on_invite(invite)
            except Exception:
                pass

    # 7.0.61: Kodi reads the last days' gift wraps again at every start - an invite was shown again
    # and again (yesterday's "... invites you" at today's start). Each one is shown once, an old one
    # never, and one for a party that is over (ended, declined, joined and left) is not listed.
    def _load_invite_log(self):
        load = getattr(self.store, 'load_invite_log', None)
        try:
            data = load() if load else {}
        except Exception:
            data = {}
        data = data if isinstance(data, dict) else {}
        return {'shown': dict(data.get('shown') or {}), 'gone': dict(data.get('gone') or {})}

    def _note_invite(self, kind, party_id, at=None):
        log = self.invite_log
        log[kind][str(party_id)] = float(at or self.clock())
        oldest = self.clock() - INBOX_DAYS * 86400 - 3600
        for name in ('shown', 'gone'):
            log[name] = {k: v for k, v in log[name].items() if float(v or 0) >= oldest}
        save = getattr(self.store, 'save_invite_log', None)
        if save:
            try:
                save(log)
            except Exception:
                pass

    def decline(self, party_id):
        self.invites.pop(str(party_id), None)
        self._note_invite('gone', party_id)

    def _invites_now(self):
        now = self.clock()
        for party_id in [k for k, v in self.invites.items() if now - float(v.get('at') or 0) > INVITE_FOR]:
            self.invites.pop(party_id, None)
        return list(self.invites.values())

    def accept(self, party_id):
        self._invites_now()
        invite = self.invites.pop(party_id, None)
        if invite is None:
            raise ValueError('That invite is gone - the party may have ended.')
        self._note_invite('gone', party_id)                # joined: never invited to it again
        self._join(invite['party'], invite['secret'], invite['host'], invite['name'], invite.get('media'))

    def join_code(self, code, wait=8.0):
        """Ask the host behind a join code to let us in (answered by party-key)."""
        code = ident.clean_code(code)
        if not code:
            raise ValueError('That is not a join code.')
        found, done = [], threading.Event()

        def got(event, host):
            try:
                tags = dict((t[0], t[1]) for t in event['tags'] if len(t) > 1)
                if int(tags.get('expiration') or 0) < self.clock():
                    return
                data = json.loads(crypto.decrypt(event['content'], lobby_key(code)))
                found.append((event['pubkey'], data))
                done.set()
            except Exception:
                return
        sub = 'lobby-%s' % code
        self.pool.subscribe(sub, [{'kinds': [LOBBY_KIND], '#t': [lobby_tag(code)]}], got)
        done.wait(wait)
        self.pool.unsubscribe(sub)
        if not found:
            raise ValueError('No party with that code (it lasts %d minutes).' % (LOBBY_FOR // 60))
        host, data = found[-1]
        self.asked[host] = (str(data.get('party') or ''), self.clock() + LOBBY_FOR)
        self._send(host, {'type': 'join-request', 'party': data.get('party'), 'name': self.name})
        return {'host': host, 'name': str(data.get('name') or '')[:24]}

    def _got_join_request(self, sender, payload, at):
        party = self.party
        if party is None or not party.hosting or payload.get('party') != party.id or not party.code:
            return
        if self.clock() > getattr(party, 'code_until', 0):
            return                                    # the code ran out
        if sender in party.members:
            return
        if self.store.friends().get(sender, {}).get('state') == 'friend':
            self._admit(party, sender, str(payload.get('name') or '')[:24])          # friends need no approval
            return
        party.waiting[sender] = str(payload.get('name') or 'Guest')[:24]

    def _got_party_key(self, sender, payload, at):
        party = self.party
        if party is not None and party.id == payload.get('party') and party.host == sender and not party.hosting:
            # the host gave everyone a new key (someone left)
            self.pool.unsubscribe(party.sub)
            party.secret = bytes.fromhex(payload['secret'])
            party.tag, party.key = crypto.party_tag(party.secret), crypto.party_conversation(party.secret)
            party.sub = 'party-%s-%d' % (party.id[:8], int(self.clock()))
            self._subscribe(party)
            return
        if payload.get('host') != sender:
            return
        # 7.0.54: only a host we asked (join code) lets us in - anyone else's key would pull this
        # TV into a stranger's party (their film, their pause / seek)
        party_id, until = self.asked.get(sender) or ('', 0)
        if party_id != str(payload.get('party')) or self.clock() > until:
            return
        self.asked.pop(sender, None)
        self._join(str(payload.get('party')), str(payload.get('secret')), sender, payload.get('name'), payload.get('media'))

    def _got_invite_gone(self, sender, payload, at):
        invite = self.invites.get(str(payload.get('party')))
        if invite and invite.get('host') == sender:
            self.invites.pop(str(payload.get('party')), None)
        if self._is_friend(sender):                    # it may come before its invite (read again at a start)
            self._note_invite('gone', payload.get('party'), at)

    def _got_removed(self, sender, payload, at):
        party = self.party
        if party is not None and party.id == payload.get('party') and party.host == sender:
            self.leave(quiet=True)

    def _join(self, party_id, secret_hex, host, host_name, media):
        with self.lock:
            self.leave()
            party = Party(party_id, bytes.fromhex(secret_hex), host, self.me)
            party.members[host] = {'name': str(host_name or 'Host')[:24], 'seen': self.clock(), 'status': 'host'}
            party.members[self.me] = {'name': self.name, 'seen': self.clock(), 'status': 'joined'}
            party.media = media
            self._enter(party)
        self._say({'type': 'hello', 'name': self.name})
        self._changed()

    def leave(self, quiet=False):
        party = self.party
        if party is None:
            return
        self._note_invite('gone', party.id)            # 7.0.61: its invite is never listed again
        if not quiet:
            self._say({'type': 'end' if party.hosting else 'bye'})   # the host ends it for everyone
            if party.hosting:
                for public in list(party.invited):    # invited but not in yet: the invite is withdrawn
                    try:
                        self._send(public, {'type': 'invite-gone', 'party': party.id}, wait=0)
                    except Exception:
                        pass
        self.pool.unsubscribe(party.sub)
        self.party = None
        self.store.save_active(None)
        self._changed()

    # --- the channel ---------------------------------------------------------------------------------
    def _enter(self, party):
        self.party = party
        self._subscribe(party)

    def _subscribe(self, party):
        # no "since": the relays keep none of these, and a "since" by our clock shut out a TV whose
        # clock is behind (7.0.61)
        self.pool.subscribe(party.sub, [{'kinds': [CHANNEL_KIND], '#t': [party.tag]}], self._channel)

    def _say(self, payload):
        party = self.party
        if party is None:
            return 0
        content = crypto.encrypt(json.dumps(payload, separators=(',', ':')), party.key)
        event = crypto.sign_event(CHANNEL_KIND, content, [['t', party.tag]], self.secret)
        return self.pool.publish(event)

    def say(self, text):
        """A chat message from us (from the phone)."""
        text = ' '.join(str(text or '').split())[:CHAT_MAX]
        if not text or self.party is None:
            return False
        message = {'from': self.me, 'name': self.name, 'text': text, 'at': self.clock()}
        self.party.chat.append(message)
        self._say({'type': 'chat', 'text': text})
        self._changed()
        return True

    def ready(self, media):
        """A guest: the party's film plays here now (the host waits for this at the start)."""
        if self.party is not None and not self.party.hosting:
            self._say({'type': 'ready', 'key': media_key(media)})

    def guests_ready(self):
        """The host: every guest who is here has the film playing."""
        party = self.party
        if party is None:
            return True
        guests = [p for p, m in party.members.items() if p != self.me and m.get('status') != 'away']
        return all(p in party.ready for p in guests)

    def guests(self):
        party = self.party
        return [] if party is None else [p for p, m in party.members.items() if p != self.me and m.get('status') != 'away']

    def keep_alive(self):
        """Every tick of the service: the host says "still here" every ALIVE_EVERY seconds; a guest
        whose host has been silent HOST_GONE seconds (power cut, crash, no network) leaves -
        True when the party ended that way."""
        party = self.party
        if party is None:
            return False
        now = self.clock()
        if party.hosting:
            if now - party.alive_at >= ALIVE_EVERY:
                party.alive_at = now
                self._say({'type': 'alive'})
            return False
        if now - party.host_seen > HOST_GONE:
            self.leave(quiet=True)
            return True
        return False

    def hello_again(self, every=15.0):
        """A guest the host has not answered yet (its TV was restarting when we said hello - party
        messages are not kept by the relays): hello again, every ``every`` seconds."""
        party = self.party
        if party is None or party.hosting or party.confirmed or self.clock() - party.hello_at < every:
            return False
        party.hello_at = self.clock()
        self._say({'type': 'hello', 'name': self.name})
        return True

    def ask_host(self, action, position_ms=None, delta_ms=None):
        """A guest's pause / play / seek: the host's player does it, everyone follows."""
        party = self.party
        if party is None or party.hosting:
            return False
        self._say({'type': 'control', 'action': str(action), 'pos': position_ms, 'delta': delta_ms})
        return True

    def keep_clock(self, every=CLOCK_EVERY):
        """A guest: the host's clock against ours (ping / pong) - at once in a party, then every
        ``every`` seconds; the host's film times are read through it (7.0.61: never measured before,
        a TV clock a few minutes off put the guest's film minutes away)."""
        party = self.party
        if party is None or party.hosting or self.clock() - party.pinged_at < (5 if party.host not in self.offsets.best else every):
            return False
        party.pinged_at = self.clock()
        self.ping()
        return True

    def ping(self):
        if self.party is not None:
            self._say({'type': 'ping', 't': int(self.clock() * 1000)})

    def _channel(self, event, host):
        party = self.party
        if party is None or event['pubkey'] == self.me:
            return
        if abs(self.clock() - int(event.get('created_at') or 0)) > MAX_AGE:
            return                                   # a replay, or a clock far off
        if not any(t[0] == 't' and len(t) > 1 and t[1] == party.tag for t in event['tags']):
            return
        try:
            payload = json.loads(crypto.decrypt(event['content'], party.key))
        except Exception:
            return
        sender, kind = event['pubkey'], payload.get('type')
        with self.lock:
            if kind == 'hello' and party.hosting and sender not in party.members:
                # 7.0.56: the party key is the membership - only people let in have it, and a
                # removed one gets a dead key (_rekey). So whoever says hello with it is in, also
                # after the host's TV restarted (its saved list had missed a late guest, who was then
                # ignored: no film, no state on that TV)
                if len(party.members) < MAX_MEMBERS:
                    party.invited.discard(sender)
                    party.members[sender] = {'name': str(payload.get('name') or 'Guest')[:24], 'seen': self.clock(),
                                             'status': 'joined'}
            known = sender in party.members
            if kind == 'hello':
                if not known and not party.hosting:
                    party.members[sender] = {'name': str(payload.get('name') or 'Guest')[:24], 'seen': self.clock(),
                                             'status': 'joined'}
                elif known:
                    party.members[sender].update(seen=self.clock(), status='joined' if sender != party.host else 'host')
                if party.hosting and known:
                    self._roster(party)
                    if party.media:
                        self._say({'type': 'media', 'media': party.media, 'share': party.share})
                    if party.state:
                        self.send_state(party.state['paused'], sync.expected_position(party.state, int(self.clock() * 1000)),
                                        party.state.get('dur') or 0)
                self._changed()
                return
            if not known:
                return                                # not a member (or removed): ignored
            party.members[sender]['seen'] = self.clock()
            if sender == party.host:
                party.host_seen = self.clock()
            if kind == 'bye':
                party.members[sender]['status'] = 'away'
            elif kind == 'end' and sender == party.host and not party.hosting:
                self.leave(quiet=True)                # the host ended the party
                if self.on_chat:
                    self.on_chat({'from': sender, 'name': party.members[sender]['name'], 'text': 'ended the party',
                                  'at': self.clock()})
                return
            elif kind == 'chat':
                text = ' '.join(str(payload.get('text') or '').split())[:CHAT_MAX]
                if text:
                    message = {'from': sender, 'name': party.members[sender]['name'], 'text': text, 'at': self.clock()}
                    party.chat.append(message)
                    if self.on_chat:
                        self.on_chat(message)
            elif kind == 'state' and sender == party.host:
                party.confirmed = True
                if sync.newer(payload, party.state):
                    party.state = payload
                    if self.on_state:
                        self.on_state(dict(payload, at=int(payload.get('at') or 0) + self.offsets.of(sender)))
            elif kind == 'media' and sender == party.host:
                party.confirmed = True
                party.media, party.share = payload.get('media'), payload.get('share')
                if self.on_media:
                    self.on_media(party.media, party.share)
            elif kind == 'roster' and sender == party.host:
                names = payload.get('members') or {}
                party.confirmed = party.confirmed or self.me in names
                for public, name in names.items():
                    if public not in party.members:
                        party.members[public] = {'name': str(name)[:24], 'seen': 0, 'status': 'joined'}
                for public in [p for p in party.members if p not in names]:
                    del party.members[public]
            elif kind == 'ready' and party.hosting:
                if payload.get('key') == media_key(party.media):
                    party.ready.add(sender)
            elif kind == 'control' and party.hosting and self.on_control:
                self.on_control(sender, payload)
            elif kind == 'ping' and party.hosting:       # 7.0.61: only the host's clock is measured
                self._say({'type': 'pong', 't': payload.get('t'), 'peer': int(self.clock() * 1000), 'to': sender})
            elif kind == 'pong' and payload.get('to') == self.me:
                self.offsets.add(sender, int(payload.get('t') or 0), int(payload.get('peer') or 0), int(self.clock() * 1000))
        self._changed()

    def snapshot(self):
        """What the TV and the phone show (no keys)."""
        party = self.party
        friends = self.store.friends()
        def talk(public):
            data = self.messages.get(public) or {}
            return {'messages': list(data.get('items') or []), 'unread': int(data.get('unread') or 0)}
        return {'me': {'public': self.me, 'name': self.name, 'code': self.identity['code']},
                'friends': [dict(row, public=p, pair=crypto.pair_code(self.me, p), online=self.online(p), **talk(p))
                            for p, row in friends.items()],
                'invites': [dict(i, secret=None) for i in self._invites_now()],
                'party': party.summary() if party else None,
                'relays': [self.pool.connected(), len(self.pool.relays)]}


class FileStore(object):
    """Friends and the active party in this profile's files."""

    def friends(self):
        return ident.friends()

    def set_friend(self, public, name, state, confirmed=False):
        return ident.set_friend(public, name, state, confirmed)

    def remove_friend(self, public):
        return ident.remove_friend(public)

    def load_messages(self):
        return ident._read(MESSAGES, {})

    def save_messages(self, value):
        ident._write(MESSAGES, value)

    def load_invite_log(self):
        return ident._read(INVITE_LOG, {})

    def save_invite_log(self, value):
        ident._write(INVITE_LOG, value)

    def load_active(self):
        return ident._read(ACTIVE, {})

    def save_active(self, value):
        if value:
            ident._write(ACTIVE, value)
        else:
            try:
                os.remove(os.path.join(ident._profile(), ACTIVE))
            except OSError:
                pass
