# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Small Kodi entry point."""

def run():
    try:
        from .settings_snapshot import invalidate as _invalidate_settings
        _invalidate_settings()
    except Exception:
        pass
    try:
        from .texts import reset_language_cache
        reset_language_cache()
    except Exception:
        pass
    from .hub import run as plugin_run
    return plugin_run()
