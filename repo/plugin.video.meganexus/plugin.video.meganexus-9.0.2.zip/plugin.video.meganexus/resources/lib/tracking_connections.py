# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Read-only local tracking audit, executed inside Kodi; no credentials output."""
import sqlite3
from pathlib import Path
import xbmcaddon
import xbmcvfs

addon=xbmcaddon.Addon('plugin.video.meganexus')
from . import trakt_api,simkl_api,mdblist_tracking,stremio_account
from .meganexus import cloud_sync as sync


def flag(key,default=True):
    return (addon.getSetting(key) or ('true' if default else 'false'))=='true'


def check(linked,fn):
    if not linked:return 'not_connected'
    try:fn();return 'responds'
    except Exception as error:
        code=getattr(error,'code',None)
        return 'HTTP %s'%code if isinstance(code,int) else type(error).__name__


def check_connections():
    nuvio=sync.NuvioCloud.is_linked();stremio=stremio_account.linked()
    t=trakt_api.authorized();s=simkl_api.authorized();m=bool(mdblist_tracking.api_key())
    from . import wetrakr_api
    w=wetrakr_api.authorized()
    report={
        'Nuvio':{'connected':nuvio,'sync':flag('nuvio_sync_enabled'),'profile_selected':bool(sync.NuvioCloud.token().get('profile_index')),
                 'direction':sync._sync_direction('nuvio'),'sections':sync._cloud_sections('nuvio'),
                 'connection':check(nuvio,lambda:sync.NuvioCloud.profiles())},
        'Stremio':{'connected':stremio,'sync':stremio_account.keep_in_sync(),
                   'connection':check(stremio,lambda:sync.Stremio._api('addonCollectionGet',{'authKey':sync.Stremio._auth_key(),'update':True}))},
        'Trakt':{'connected':t,'sync':trakt_api.enabled() and trakt_api.sync_enabled(),'scrobble':trakt_api.enabled() and trakt_api.scrobble_enabled(),
                 'connection':check(t,lambda:trakt_api._request('/sync/last_activities',auth=True,timeout=6))},
        'Simkl':{'connected':s,'sync':simkl_api.enabled() and flag('simkl_service_sync'),'scrobble':simkl_api.mark_watched_enabled(),
                 'connection':check(s,lambda:simkl_api._request('/sync/activities',method='POST',payload={},auth=True,timeout=6))},
        'MDBList':{'connected':m,'sync':mdblist_tracking.enabled(),'scrobble':mdblist_tracking.enabled(),
                   'connection':check(m,lambda:mdblist_tracking.request('GET','/sync/last_activities',timeout=6))},
        'WeTrakr':{'connected':w,'sync':wetrakr_api.enabled(),'scrobble':wetrakr_api.enabled(),
                   'connection':check(w,lambda:wetrakr_api.last_activities())}}
    folder=Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
    path=folder/'playback.db';counts={}
    if path.is_file():
        connection=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=2)
        try:
            names={r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for name in ('nuvio_progress_outbox','playback_progress'):
                if name in names:counts[name]=connection.execute('SELECT COUNT(*) FROM '+name).fetchone()[0]
        finally:connection.close()
    report['local']=counts
    return report

