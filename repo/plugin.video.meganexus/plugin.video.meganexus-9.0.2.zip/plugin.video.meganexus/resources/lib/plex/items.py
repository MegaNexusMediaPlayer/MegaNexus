# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A Plex library item (its XML element) as a plain dict for lists, details and playback.

Each Media/Part is a version the user can choose: resolution, HDR / Dolby Vision, codecs,
audio layout, container, size and its external subtitle files (the token added to their
addresses; picture subtitles left out - setSubtitles cannot load them). Pictures and the
Direct Play address get the server address and token."""
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from . import wire
from .server_list import clean_address

KINDS = {'show': 'show', 'season': 'season', 'episode': 'episode', 'clip': 'episode',
         'artist': 'audio', 'album': 'audio', 'track': 'audio'}
# (Plex's guid start, our id) - the longer agent names before the short ones they contain
GUID_KINDS = (('com.plexapp.agents.themoviedb://', 'tmdb_id'), ('com.plexapp.agents.thetvdb://', 'tvdb_id'),
              ('com.plexapp.agents.imdb://', 'imdb_id'), ('themoviedb://', 'tmdb_id'), ('thetvdb://', 'tvdb_id'),
              ('imdb://', 'imdb_id'), ('tmdb://', 'tmdb_id'), ('tvdb://', 'tvdb_id'))
VIDEO_CODECS = {'hevc': 'HEVC', 'h264': 'H.264', 'h265': 'H.265', 'av1': 'AV1', 'mpeg4': 'MPEG4', 'vc1': 'VC-1',
                'mpeg2video': 'MPEG2'}
AUDIO_CODECS = {'truehd': 'TrueHD', 'dca': 'DTS', 'dts': 'DTS', 'dtshd': 'DTS-HD', 'eac3': 'EAC3', 'ac3': 'AC3',
                'aac': 'AAC', 'mp3': 'MP3', 'flac': 'FLAC', 'opus': 'Opus', 'pcm': 'PCM'}
CHANNELS = {1: '1.0', 2: '2.0', 6: '5.1', 8: '7.1'}
PICTURE_SUBTITLES = frozenset(('pgs', 'hdmv_pgs_subtitle', 'hdmv-pgs-subtitle', 'vobsub', 'dvd_subtitle',
                               'dvd-subtitle', 'dvdsub', 'dvb_subtitle', 'dvb-subtitle', 'dvbsub', 'xsub'))
SUBTITLE_FILES = {'subrip': 'srt', 'srt': 'srt', 'ass': 'ass', 'ssa': 'ssa', 'webvtt': 'vtt', 'vtt': 'vtt',
                  'mov_text': 'srt'}
TAG_LISTS = (('genres', 'Genre', 6), ('directors', 'Director', 4), ('writers', 'Writer', 4), ('cast', 'Role', 10))


def _number(value, default=0):
    try:
        return int(float(value or 0))
    except Exception:
        return default


def _decimal(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def ids_of(node):
    """{imdb_id, tmdb_id, tvdb_id} from the item's guid and its <Guid> children."""
    ids = {'imdb_id': '', 'tmdb_id': '', 'tvdb_id': ''}
    for guid in [node.attrib.get('guid') or ''] + [child.attrib.get('id') or '' for child in node.findall('./Guid')]:
        guid = str(guid or '')
        for start, name in GUID_KINDS:
            at = guid.lower().find(start)
            if at < 0:
                continue
            value = guid[at + len(start):].split('?')[0].split('/')[0]
            if name == 'tmdb_id' and value.lower().startswith('tv-'):
                value = value[3:]
            if value:
                ids[name] = value
            break
    return ids


def _resolution(value):
    value = str(value or '').strip()
    if not value:
        return ''
    try:
        lines = int(value)
    except ValueError:
        return value.upper()
    return '4K' if lines > 1088 else '1080p' if lines >= 1080 else '720p' if lines >= 720 else 'SD'


def _size(count):
    try:
        count = int(count or 0)
    except (TypeError, ValueError):
        return ''
    if count <= 0:
        return ''
    gigabytes = count / (1024.0 ** 3)
    return '%.1f GB' % gigabytes if gigabytes >= 1 else '%.0f MB' % (count / (1024.0 ** 2))


def _dynamic_range(part):
    """Dolby Vision / HDR from the video stream's display title."""
    for stream in part.findall('.//Stream') if part is not None else ():
        if stream.attrib.get('streamType') != '1':
            continue
        title = (stream.attrib.get('displayTitle') or '').upper()
        if 'DOLBY VISION' in title or 'DOVI' in title or ' DV' in title or title.startswith('DV '):
            return 'Dolby Vision'
        if 'HDR' in title:
            return 'HDR'
    return ''


def _sound(media):
    codec = (media.attrib.get('audioCodec') or '').lower()
    if not codec:
        return ''
    label = AUDIO_CODECS.get(codec, codec.upper())
    channels = media.attrib.get('audioChannels') or ''
    if channels:
        try:
            label += ' %s' % CHANNELS.get(int(channels), '%sch' % channels)
        except (TypeError, ValueError):
            pass
    return label


def with_token(base_url, key, token=''):
    """A server path (or full address) as an address carrying X-Plex-Token once."""
    key = str(key or '').strip()
    if not key:
        return ''
    url = key if key.startswith(('http://', 'https://')) else str(base_url or '').rstrip('/') + '/' + key.lstrip('/')
    if not token:
        return url
    try:
        parts = urlsplit(url)
        pairs = parse_qsl(parts.query, keep_blank_values=True)
        if not any(name.lower() == 'x-plex-token' for name, _value in pairs):
            pairs.append(('X-Plex-Token', str(token)))
        return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(pairs), parts.fragment))
    except Exception:
        return url + ('&' if '?' in url else '?') + urlencode({'X-Plex-Token': str(token)})


def _subtitle_files(part, base_url='', token=''):
    """The part's external (sidecar) text subtitles; embedded tracks stay with the player."""
    rows = []
    for stream in part.findall('.//Stream') if part is not None else ():
        info = stream.attrib
        if str(info.get('streamType') or '') != '3' or not info.get('key'):
            continue
        codec, form = str(info.get('codec') or '').lower(), str(info.get('format') or '').lower()
        url = with_token(base_url, info['key'], token)
        if codec in PICTURE_SUBTITLES or form in PICTURE_SUBTITLES or not url:
            continue
        lang = info.get('languageCode') or info.get('languageTag') or info.get('language') or 'und'
        kind = codec or form
        rows.append({'id': str(info.get('id') or len(rows) + 1), 'url': url, 'key': url, 'lang': str(lang),
                     'language': str(info.get('language') or lang), 'languageCode': str(info.get('languageCode') or lang),
                     'codec': kind or 'subrip', 'format': SUBTITLE_FILES.get(kind, kind or 'srt'),
                     'sourceType': 'stream', 'sourceName': 'Plex',
                     'title': str(info.get('title') or info.get('displayTitle') or ''),
                     'forced': str(info.get('forced') or '') == '1', 'selected': str(info.get('selected') or '') == '1'})
    return rows


def versions_of(node, base_url='', token=''):
    """Every playable version (one per Part) with its facts and two ready lines:
    info_line "[ 4K ] • [ HDR ] • …" and version_label "4K · HDR · 12.3 GB · MKV"."""
    found = []
    for media in node.findall('./Media'):
        info = media.attrib
        resolution = _resolution(info.get('videoResolution'))
        video = VIDEO_CODECS.get((info.get('videoCodec') or '').lower(), (info.get('videoCodec') or '').upper())
        sound = _sound(media)
        container = (info.get('container') or '').upper()
        try:
            bitrate = round(float(info.get('bitrate') or 0) / 1000.0, 1)
        except (TypeError, ValueError):
            bitrate = 0.0
        for part in media.findall('./Part'):
            dynamic, count = _dynamic_range(part), _number(part.attrib.get('size'))
            size = _size(count)
            found.append({
                'part_key': part.attrib.get('key') or '', 'file': part.attrib.get('file') or '',
                'resolution': resolution, 'hdr': dynamic, 'video_codec': video, 'audio': sound,
                'container': container, 'bitrate_mbps': bitrate, 'bit_depth': info.get('bitDepth') or '',
                'size_bytes': count, 'size_label': size,
                'info_line': ' • '.join('[ %s ]' % fact for fact in (resolution, dynamic, video, sound, size) if fact),
                'version_label': ' · '.join(fact for fact in (resolution, dynamic, size, container) if fact)
                                 or 'Version %d' % (len(found) + 1),
                'subtitles': _subtitle_files(part, base_url, token)})
    return found


def node_item(node, server, base_url=''):
    """One library item; an episode's title leads with its show ("Show — Episode")."""
    info = node.attrib
    kind = KINDS.get((info.get('type') or '').lower(), 'movie')
    show = info.get('grandparentTitle') or ''
    title = info.get('title') or show or 'Plex'
    media = node.find('./Media')
    part = media.find('./Part') if media is not None else None
    token = server.get('token') or ''
    item = {
        'server_id': str(server.get('id') or ''), 'server_name': server.get('name') or 'Plex',
        'server_url': base_url or ((server.get('connections') or [{}])[0].get('uri') or ''), 'token': token,
        'rating_key': str(info.get('ratingKey') or ''), 'key': info.get('key') or '',
        'part_key': part.attrib.get('key') if part is not None else '',
        'versions': versions_of(node, base_url, token), 'media_type': kind,
        'title': '%s — %s' % (show, title) if kind == 'episode' and show else title,
        'raw_title': info.get('title') or ('%s — %s' % (show, title) if kind == 'episode' and show else title),
        'show_title': show, 'year': _number(info.get('year')), 'duration_ms': _number(info.get('duration')),
        'view_offset_ms': _number(info.get('viewOffset')), 'index': _number(info.get('index')),
        'season': _number(info.get('parentIndex')), 'summary': info.get('summary') or '',
        'thumb': info.get('thumb') or info.get('parentThumb') or '',
        'art': info.get('art') or info.get('grandparentArt') or '', 'parent_thumb': info.get('parentThumb') or '',
        'leaf_count': _number(info.get('leafCount')), 'view_count': _number(info.get('viewCount')),
        'rating': _decimal(info.get('rating') or info.get('audienceRating')),
        'content_rating': info.get('contentRating') or '', 'studio': info.get('studio') or '',
        'tagline': info.get('tagline') or '', 'premiered': info.get('originallyAvailableAt') or '',
        'ids': ids_of(node), 'info_line': '', 'size_label': ''}
    for field, tag, most in TAG_LISTS:
        item[field] = [child.attrib.get('tag') for child in node.findall('./' + tag) if child.attrib.get('tag')][:most]
    if item['versions']:
        item['info_line'] = item['versions'][0].get('info_line') or ''
        item['size_label'] = item['versions'][0].get('size_label') or ''
    return item


def rows_of(root, server, base, kinds=None):
    """The Video / Directory children as items (only `kinds` media types when given)."""
    found = []
    for node in list(root):
        if node.tag.rsplit('}', 1)[-1] in ('Video', 'Directory'):
            row = node_item(node, server, base)
            if kinds is None or row['media_type'] in kinds:
                found.append(row)
    return found


def artwork_url(item, path):
    """A picture path of the item's server as an address with the token."""
    value = str(path or '').strip()
    if not value or value.startswith(('http://', 'https://')):
        return value
    base = clean_address(item.get('server_url'))
    if not base:
        return ''
    parts = urlsplit(base + '/' + value.lstrip('/'))
    pairs = list(parse_qsl(parts.query, keep_blank_values=True))
    if item.get('token') and not any(name == 'X-Plex-Token' for name, _value in pairs):
        pairs.append(('X-Plex-Token', item.get('token')))
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(pairs), parts.fragment))


def poster_url(item, path, width=500, height=750):
    """The picture resized by the server's photo transcoder (a card needs no original)."""
    value = str(path or '').strip()
    base = clean_address(item.get('server_url'))
    if not value or not base or value.startswith(('http://', 'https://')):
        return artwork_url(item, value)
    return base + '/photo/:/transcode?' + urlencode({'width': int(width), 'height': int(height), 'minSize': 1,
                                                     'upscale': 0, 'url': value, 'X-Plex-Token': item.get('token') or ''})


def logo_url(item, base_url=''):
    """The item's clearLogo."""
    key = str(item.get('rating_key') or '').strip()
    return artwork_url(item, '/library/metadata/%s/clearLogo' % key) if key else ''


def playback_url(item, part_key=''):
    """The Direct Play address of a version (the first by default)."""
    part = str(part_key or item.get('part_key') or '').strip()
    if not part:
        raise wire.PlexFailure('No directly playable version of this item in Plex')
    return artwork_url(item, part)
