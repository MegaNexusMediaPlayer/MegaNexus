# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A Plex server's libraries, pages, details and search.

The library list is kept 6 hours in memory and in a Home window property (one request per
device, not per interpreter); an empty or failed answer is never kept - the server may
just have been asleep. Details ask for the <Guid> children (includeGuids), without which
an item has no IMDb / TMDB ids. A search asks the server-wide /library/all first, then
each library of the wanted type at once (its /search, else /all?title= for agents whose
/search answers nothing); one item seen by several of them is listed once."""
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmc
import xbmcgui

from . import items, server_list, saved, wire

SECTIONS_LIFE = 6 * 3600
PAGE_SIZE = 80
VIDEO = ('movie', 'show')
TYPE_NUMBERS = {'movie': '1', 'show': '2', 'series': '2', 'episode': '4'}
SECTION_FOR = {'1': 'movie', '2': 'show', '4': 'show'}
FOUND_KINDS = ('movie', 'show', 'episode')


def _shared_name(server_id):
    return 'meganexus.plex.libs.%s' % server_id


def libraries(server, force=False):
    """[{key, title, type, thumb, art}] of the movie, show, music and photo libraries."""
    sid = str(server.get('id') or '')
    kept = saved.sections.get(sid) or {}
    if not force and kept.get('rows') is not None and kept.get('at', 0) + SECTIONS_LIFE > time.time():
        return list(kept.get('rows') or [])
    if not force and sid:
        try:
            shared = json.loads(xbmcgui.Window(saved.HOME).getProperty(_shared_name(sid)) or 'null')
            if shared and shared.get('at', 0) + SECTIONS_LIFE > time.time():
                saved.sections[sid] = shared
                return list(shared.get('rows') or [])
        except Exception:
            pass
    try:
        root, _base = server_list.ask(server, '/library/sections')
    except wire.PlexFailure as exc:
        xbmc.log('[MegaNexus] Plex UNREACHABLE: server=%s error=%s' % (server.get('name') or '?', exc), xbmc.LOGERROR)
        return []
    rows = [{'key': str(node.attrib.get('key') or ''), 'title': node.attrib.get('title') or 'Library',
             'type': (node.attrib.get('type') or '').lower(), 'thumb': node.attrib.get('thumb') or '',
             'art': node.attrib.get('art') or ''}
            for node in root.findall('./Directory')
            if (node.attrib.get('type') or '').lower() in ('movie', 'show', 'artist', 'photo')]
    if not rows:
        xbmc.log('[MegaNexus] Plex libraries EMPTY for server=%s — not caching, will retry on the next call'
                 % (server.get('name') or '?'), xbmc.LOGWARNING)
        try:
            xbmcgui.Window(saved.HOME).clearProperty(_shared_name(sid))
        except Exception:
            pass
        saved.sections.pop(sid, None)
        return []
    xbmc.log('[MegaNexus] Plex libraries: server=%s sections=%d' % (server.get('name') or '?', len(rows)), xbmc.LOGINFO)
    kept = {'at': time.time(), 'rows': rows}
    saved.sections[sid] = kept
    if sid:
        try:
            xbmcgui.Window(saved.HOME).setProperty(_shared_name(sid), json.dumps(kept))
        except Exception:
            pass
    return list(rows)


def _page(start, size):
    return {'X-Plex-Container-Start': int(start or 0), 'X-Plex-Container-Size': int(size or PAGE_SIZE)}


def children(server, key, start=0, size=PAGE_SIZE, sort=''):
    """(items, total) of one page of a library, show or season."""
    root, base = server_list.ask(server, key, dict(_page(start, size), sort=sort))
    rows = items.rows_of(root, server, base)
    try:
        total = int(float(root.attrib.get('totalSize') or 0))
    except Exception:
        total = len(rows)
    return rows, total


def on_deck(server, start=0, size=PAGE_SIZE):
    root, base = server_list.ask(server, '/library/onDeck', _page(start, size))
    return [items.node_item(node, server, base) for node in root.findall('./Video')]


def metadata(server, rating_key):
    """The item's full record, with its ids."""
    root, base = server_list.ask(server, '/library/metadata/%s' % rating_key, {'includeGuids': 1})
    found = items.rows_of(root, server, base)
    if not found:
        raise wire.PlexFailure('Plex item not found')
    return found[0]


def _video_sections(server, wanted):
    """The libraries that can hold the wanted type (a movie library is never asked for shows);
    when the server seems to have no video library at all, the list is fetched once more."""
    def of_type(rows):
        rows = [row for row in rows if row.get('type') in VIDEO]
        return [row for row in rows if row.get('type') == SECTION_FOR[wanted]] if wanted in SECTION_FOR else rows
    found = of_type(libraries(server))
    if found:
        return found
    try:
        every = [row for row in libraries(server) if row.get('type') in VIDEO]
    except Exception:
        every = []
    if not every:
        try:
            every = [row for row in libraries(server, force=True) if row.get('type') in VIDEO]
        except Exception:
            every = []
    return of_type(every)


def server_find(server, query, media_type='', limit=40):
    """Films, shows and episodes on one server matching `query`, each item once."""
    wanted = TYPE_NUMBERS.get((media_type or '').lower(), '')
    sections = _video_sections(server, wanted)
    if not sections:
        return []
    typed = {'type': wanted} if wanted else {}

    def asking(**params):
        return dict(params, **typed)
    found = []
    try:
        root, base = server_list.ask(server, '/library/all', asking(query=query, includeGuids=1, **_page(0, limit)))
        found = items.rows_of(root, server, base, FOUND_KINDS)
    except wire.PlexFailure:
        pass

    def one_library(section):
        try:
            root, base = server_list.ask(server, '/library/sections/%s/search' % section['key'],
                                     asking(query=query, limit=int(limit), includeGuids=1))
            rows = items.rows_of(root, server, base, FOUND_KINDS)
        except wire.PlexFailure:
            rows = []
        if rows:
            return rows
        try:
            root, base = server_list.ask(server, '/library/sections/%s/all' % section['key'],
                                     asking(title=query, includeGuids=1, **_page(0, limit)))
            return items.rows_of(root, server, base, FOUND_KINDS)
        except wire.PlexFailure:
            return []                       # one library out of reach never hides the rest

    with ThreadPoolExecutor(max_workers=min(6, len(sections))) as pool:
        for done in as_completed([pool.submit(one_library, section) for section in sections]):
            try:
                found.extend(done.result() or [])
            except Exception:
                continue
            if len(found) >= int(limit):
                break
    unique, seen = [], set()
    for row in found:
        key = str(row.get('rating_key') or '')
        if key and key in seen:
            continue
        seen.add(key)
        unique.append(row)
    return unique[:int(limit)]


def search_all(query, media_type='', limit_per_server=40):
    """Every server at once; the results in the server list's order (an offline one adds nothing)."""
    every = server_list.servers()
    if not every:
        return []
    if len(every) == 1:
        try:
            return server_find(every[0], query, media_type, limit_per_server)
        except wire.PlexFailure:
            return []
    answers = {}
    with ThreadPoolExecutor(max_workers=min(4, len(every))) as pool:
        asked = dict((pool.submit(server_find, server, query, media_type, limit_per_server), place)
                     for place, server in enumerate(every))
        for done in as_completed(asked):
            try:
                answers[asked[done]] = done.result()
            except Exception:
                answers[asked[done]] = []
    return [row for place in range(len(every)) for row in answers.get(place) or []]
