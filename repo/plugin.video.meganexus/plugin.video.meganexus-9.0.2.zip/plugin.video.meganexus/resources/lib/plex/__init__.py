# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus' own Plex client: no interface, plain dicts in and out.

    store        the sign-in, the server list and the device id (setting + file + property)
    wire         requests (X-Plex-* headers, the certificate-check retry), PlexFailure
    signin       PIN / QR sign-in, sign-out
    server_list  the account's servers and the address each answers at
    items        a library item with its versions, subtitles, pictures and play address
    library      libraries, pages, details, search
    matching     a title the user opened, found on the servers by its ids or its name

Nothing here runs before the user signs in and switches Plex on (media_servers.py).
Credentials never reach a log line."""
from .signin import account, auth_link_url, is_signed_in, poll_pin, request_pin, sign_out  # noqa: F401
from .items import artwork_url, node_item, logo_url, playback_url, poster_url  # noqa: F401
from .library import children, libraries, metadata, on_deck, search_all, server_find  # noqa: F401
from .matching import episode_node_item, all_by_ids, item_by_guid  # noqa: F401
from .server_list import ask, is_local_connection, server_by_id, servers  # noqa: F401
from .saved import client_identifier  # noqa: F401
from .wire import PlexFailure, fetch  # noqa: F401
