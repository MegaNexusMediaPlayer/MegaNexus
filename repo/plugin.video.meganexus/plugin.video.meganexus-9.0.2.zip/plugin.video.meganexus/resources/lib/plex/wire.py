# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Requests to plex.tv and to Plex servers.

Every request names this device the way Plex apps do (X-Plex-* headers, the stable client
id). An error says only the status - never the address, which can carry the token.

Plex serves a home server over HTTPS under a *.plex.direct name whose certificate chains
to Let's Encrypt; the CA store of many Kodi / CoreELEC builds cannot check that chain, so
every request failed. A request that fails ONLY on the certificate check is sent once more
without it: the address came from plex.tv's own list and the token authenticates the
server."""
import json
import platform
import ssl
import xml.etree.ElementTree as ET
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import xbmc

from . import saved
from ..texts import tr

PLEX_TV = 'https://plex.tv'
CERTIFICATE_WORDS = ('CERTIFICATE_VERIFY_FAILED', 'CERTIFICATE VERIFY FAILED', 'CERTIFICATE VALIDATION FAILED')


class PlexFailure(Exception):
    """A Plex or network failure, short enough for a notification."""


def device_headers(token='', accept='application/xml'):
    try:
        version = saved.addon().getAddonInfo('version') or '8.1.0'
    except Exception:
        version = '8.1.0'
    try:
        system = platform.uname()[2] or '0'
    except Exception:
        system = '0'
    found = {'Accept': accept, 'X-Plex-Product': 'MegaNexus', 'X-Plex-Version': version,
             'X-Plex-Client-Identifier': saved.client_identifier(), 'X-Plex-Platform': 'Kodi',
             'X-Plex-Client-Platform': 'Kodi', 'X-Plex-Platform-Version': system, 'X-Plex-Language': 'en',
             'X-Plex-Device': 'Kodi', 'X-Plex-Device-Name': 'Kodi', 'X-Plex-Provides': 'player,controller'}
    if token:
        found['X-Plex-Token'] = str(token)
    return found


def wait():
    """The request timeout: the add-on's `timeout` setting, at least 5 s."""
    try:
        return max(5, int(saved.addon().getSetting('timeout') or '20'))
    except Exception:
        return 20


def certificate_failed(exc):
    """A certificate check failure, also one urllib wrapped (URLError.reason)."""
    seen = set()
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        if isinstance(exc, (ssl.SSLCertVerificationError, ssl.CertificateError)):
            return True
        if any(word in str(exc or '').upper() for word in CERTIFICATE_WORDS):
            return True
        inner = getattr(exc, 'reason', None)
        if inner is exc:
            break
        exc = inner
    return False


def fetch(url, method='GET', token='', data=None, headers=None, timeout=None):
    """The answer's bytes; PlexFailure on any failure."""
    sent = device_headers(token)
    sent.update(headers or {})
    asked = Request(url, data=data.encode('utf-8') if isinstance(data, str) else data, headers=sent, method=method)
    try:
        with urlopen(asked, timeout=timeout or wait()) as answer:
            return answer.read()
    except HTTPError as exc:
        raise PlexFailure('Plex HTTP %s' % exc.code)
    except Exception as exc:
        if not certificate_failed(exc):
            raise PlexFailure(tr('Could not reach the Plex server (%s)') % exc)
        xbmc.log('[MegaNexus] Plex TLS validation failed (%s) — retrying without chain validation' % exc,
                 xbmc.LOGWARNING)
        unchecked = ssl.create_default_context()
        unchecked.check_hostname = False
        unchecked.verify_mode = ssl.CERT_NONE
        try:
            with urlopen(asked, timeout=timeout or wait(), context=unchecked) as answer:
                return answer.read()
        except Exception as again:
            raise PlexFailure(tr('Could not reach the Plex server (%s)') % again)


def xml_of(data):
    try:
        return ET.fromstring(data or b'')
    except Exception as exc:
        raise PlexFailure(tr('Invalid Plex response (%s)') % exc)


def json_of(data):
    """A JSON object answer ({} for any other JSON)."""
    try:
        value = json.loads((data or b'').decode('utf-8', 'ignore'))
    except Exception as exc:
        raise PlexFailure(tr('Invalid Plex response (%s)') % exc)
    return value if isinstance(value, dict) else {}


def value_of(node, name, default=''):
    """An attribute, else a child element's text."""
    if node is None:
        return default
    return node.attrib.get(name, node.findtext(name, default)) or default
