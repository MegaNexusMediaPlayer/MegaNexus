# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Finding a title the user opened (IMDb / TMDB / TVDB ids, its name) on their Plex servers.

1. Plex's own matcher (metadata.provider.plex.tv, as the Plexio add-on uses it) turns an
   IMDb or TMDB id into the item's canonical plex:// guid - the only value
   /library/all?guid= filters on; the imdb:// / tmdb:// forms (also the legacy agents'
   longer ones) are tried after it. A match there is the answer: nothing else is asked.
2. Else the ids themselves are searched for (Plex indexes them), each guid form is
   asked at once, and finally the title is searched.
Every hit must carry one of the wanted ids - or, without any ids of its own, the same
title - so a wrong film never comes through. A title may be catalogued several times on
one server (4K, other language, archive): every copy is kept. Copies without their
Media/Part records get their details at once."""
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode

import xbmc

from . import items, library, server_list, signin, wire

MATCHER = 'https://metadata.provider.plex.tv'
SERIES = ('series', 'show', 'episode')
_NOISE = re.compile(r'[\[\](){}:.,!?\'"`~*_/\\|+-]+')
_YEAR = re.compile(r'\b(19|20)\d{2}\b')
_canonical = {}             # (id, type number) -> plex:// guid ('' = none)
ID_NAMES = ('imdb_id', 'tmdb_id', 'tvdb_id')


def _plain_title(value):
    """A title as people compare it: case, year and punctuation ignored."""
    text = str(value or '').strip().lower()
    if not text:
        return ''
    return ' '.join(_NOISE.sub(' ', _YEAR.sub(' ', text)).split())


def same_title(first, second):
    """Equal - or the shorter (6+ characters) inside the longer ("Cheat Sheet" / "Cheat Sheet 2026 4K")."""
    first, second = _plain_title(first), _plain_title(second)
    if not first or not second:
        return False
    if first == second:
        return True
    short, long_ = sorted((first, second), key=len)
    return len(short) >= 6 and short in long_


def _type_number(media_type):
    return 2 if str(media_type).lower() in SERIES else 1


def plex_guid_for_ids(ids, media_type='movie'):
    """The canonical plex:// guid of an IMDb / TMDB id ('' when Plex does not know it); kept."""
    imdb, tmdb = (str((ids or {}).get(name) or '').strip() for name in ('imdb_id', 'tmdb_id'))
    if not (imdb or tmdb):
        return ''
    number = _type_number(media_type)
    key = (imdb or tmdb, number)
    if key in _canonical:
        return _canonical[key]
    token = signin.account().get('token') or ''
    asked = ([('imdb-%s' % imdb, 'com.plexapp.agents.imdb://%s?lang=en' % imdb)] if imdb else []) + (
        [('tmdb-%s' % tmdb, 'com.plexapp.agents.themoviedb://%s?lang=en' % tmdb)] if tmdb else [])
    guid = ''
    for title, agent in asked:
        query = urlencode({'X-Plex-Token': token, 'type': number, 'title': title, 'guid': agent})
        try:
            root = wire.xml_of(wire.fetch('%s/library/metadata/matches?%s' % (MATCHER, query), timeout=8))
        except wire.PlexFailure as exc:
            xbmc.log('[MegaNexus] Plex matcher failed (%s)' % exc, xbmc.LOGWARNING)
            continue
        guid = next((value for value in (str(node.attrib.get('guid') or '').strip() for node in list(root))
                     if value.startswith('plex://')), '')
        if guid:
            break
    _canonical[key] = guid
    xbmc.log('[MegaNexus] Plex guid resolved: %s -> %s' % (imdb or tmdb, guid or 'NOT FOUND'), xbmc.LOGINFO)
    return guid


def _carries(row, wanted):
    """The row has one of the wanted ids (compared without case)."""
    have = row.get('ids') or {}
    return any(wanted.get(name) and str(have.get(name) or '').lower() == wanted[name] for name in ID_NAMES)


def item_by_guid(server, ids, media_type='movie', limit=12):
    """The items matching the canonical guid, else an imdb / tmdb / tvdb guid form (verified by id)."""
    given = dict((name, str((ids or {}).get(name) or '').strip()) for name in ID_NAMES)
    forms = [guid for guid in [plex_guid_for_ids(ids, media_type=media_type)] if guid]
    for name, short, agent in (('imdb_id', 'imdb', 'imdb'), ('tmdb_id', 'tmdb', 'themoviedb'),
                               ('tvdb_id', 'tvdb', 'thetvdb')):
        if given[name]:
            forms += ['%s://%s' % (short, given[name]), 'com.plexapp.agents.%s://%s?lang=en' % (agent, given[name])]
    if not forms:
        return []
    wanted = dict((name, str((ids or {}).get(name) or '').lower()) for name in ID_NAMES if (ids or {}).get(name))
    found, seen = [], set()
    for guid in forms:
        try:
            root, base = server_list.ask(server, '/library/all', {'guid': guid, 'type': str(_type_number(media_type)),
                                                              'includeGuids': 1})
        except wire.PlexFailure:
            continue
        for row in items.rows_of(root, server, base):
            key = str(row.get('rating_key') or '')
            if key and key not in seen and _carries(row, wanted):
                seen.add(key)
                found.append(row)
        if found:
            xbmc.log('[MegaNexus] Plex matched by GUID: server=%s guid=%s hits=%d'
                     % (server.get('name') or '?', guid, len(found)), xbmc.LOGINFO)
            break
    return found[:int(limit)]


def _number(value):
    return int(str(value).strip())


def episode_node_item(server, show_item, season, episode):
    """The episode (with its versions) of a show item: show -> season -> episode; None."""
    try:
        season, episode = _number(season), _number(episode)
    except (TypeError, ValueError):
        return None

    def children_key(row):
        return row.get('key') or '/library/metadata/%s/children' % row.get('rating_key')
    try:
        seasons, _total = library.children(server, children_key(show_item), size=60)
    except Exception:
        return None
    for row in seasons or []:
        try:
            if int(row.get('index') or -1) != season:
                continue
        except (TypeError, ValueError):
            continue
        try:
            episodes, _total = library.children(server, children_key(row), size=200)
        except Exception:
            return None
        for each in episodes or []:
            try:
                if int(each.get('index') or -1) != episode:
                    continue
            except (TypeError, ValueError):
                continue
            try:
                return library.metadata(server, each.get('rating_key'))   # a listing has no Parts
            except Exception:
                return each
    return None


def _guid_forms(wanted, kind):
    forms = []
    if wanted['imdb_id']:
        forms += ['imdb://%s' % wanted['imdb_id'], 'com.plexapp.agents.imdb://%s?lang=en' % wanted['imdb_id']]
    if wanted['tmdb_id']:
        forms += ['tmdb://%s' % wanted['tmdb_id'], 'themoviedb://%s' % wanted['tmdb_id'],
                  'com.plexapp.agents.themoviedb://%s?lang=en' % wanted['tmdb_id']]
        if kind == 'show':
            forms.append('themoviedb://tv-%s' % wanted['tmdb_id'])
    if wanted['tvdb_id']:
        forms += ['tvdb://%s' % wanted['tvdb_id'], 'thetvdb://%s' % wanted['tvdb_id'],
                  'com.plexapp.agents.thetvdb://%s?lang=en' % wanted['tvdb_id']]
    return list(dict.fromkeys(forms))


def all_by_ids(server, ids, media_type='movie', title='', limit=10):
    """Every copy of the title on this server, with its versions."""
    found, seen = [], set()

    def add(row):
        key = str(row.get('rating_key') or '')
        if key and key not in seen:
            seen.add(key)
            found.append(row)
            return True
        return False
    for row in item_by_guid(server, ids, media_type=media_type, limit=limit):
        add(row)
    if found:
        xbmc.log('[MegaNexus] Plex exact guid match — skipping the title fallbacks (server=%s, %d copies)'
                 % (server.get('name') or '?', len(found)), xbmc.LOGINFO)
        return _with_versions(server, found, limit)

    wanted = dict((name, str((ids or {}).get(name) or '').lower()) for name in ID_NAMES)
    kind = 'show' if str(media_type).lower() in SERIES else 'movie'
    by_id = ([wanted['imdb_id']] if wanted['imdb_id'] else []) + (
        [wanted['tmdb_id'], 'tmdb://%s' % wanted['tmdb_id']] if wanted['tmdb_id'] else []) + (
        ['tvdb://%s' % wanted['tvdb_id']] if wanted['tvdb_id'] else [])
    for query in by_id:
        if len(found) >= int(limit):
            break
        try:
            hits = library.server_find(server, query, media_type=kind, limit=max(10, int(limit)))
        except Exception:
            continue
        for row in hits or []:
            if _carries(row, wanted):
                add(row)
    if found:
        xbmc.log('[MegaNexus] Plex matched by ID: server=%s hits=%d' % (server.get('name') or '?', len(found)),
                 xbmc.LOGINFO)

    forms = _guid_forms(wanted, kind)

    def by_guid(guid):
        try:
            root, base = server_list.ask(server, '/library/all', {'guid': guid, 'includeGuids': 1, 'X-Plex-Container-Start': 0,
                                                              'X-Plex-Container-Size': max(20, int(limit))})
        except Exception:
            return []
        return items.rows_of(root, server, base, ('show',) if kind == 'show' else ('movie',))
    if forms:
        with ThreadPoolExecutor(max_workers=min(6, len(forms))) as pool:
            for done in as_completed([pool.submit(by_guid, guid) for guid in forms]):
                try:
                    rows = done.result() or []
                except Exception:
                    rows = []
                for row in rows:
                    key = str(row.get('rating_key') or '')
                    if not key or key in seen:
                        continue
                    try:
                        row = library.metadata(server, key)
                    except Exception:
                        pass
                    # an exact guid answer may come without its Guid children: the server filtered it
                    if _carries(row, wanted) or not any((row.get('ids') or {}).values()):
                        add(row)

    try:
        named = library.server_find(server, title or '', media_type=kind, limit=max(20, int(limit)))
    except Exception:
        named = []
    refused = []
    for row in named or []:
        matches = _carries(row, wanted)
        if not matches and not (row.get('ids') or {}):
            try:
                full = library.metadata(server, row.get('rating_key'))   # the ids live in the full record
            except Exception:
                full = None
            if full:
                if _carries(full, wanted):
                    if add(full):
                        xbmc.log('[MegaNexus] Plex matched by ID (via metadata): server=%s title=%s'
                                 % (server.get('name') or '?', full.get('title') or '?'), xbmc.LOGINFO)
                    continue
                row, matches = full, False
        if not (matches or same_title(row.get('title'), title)):
            refused.append('%s [%s]' % (row.get('title') or '?', ','.join(
                '%s=%s' % (name, value) for name, value in (row.get('ids') or {}).items() if value) or 'no ids'))
            continue
        add(row)
    if not found and refused:
        xbmc.log('[MegaNexus] Plex saw but rejected: %s' % ' | '.join(refused[:6]), xbmc.LOGWARNING)
    return _with_versions(server, found, limit)


def _with_versions(server, found, limit):
    """The first `limit` copies; those listed without Media/Part get their full record (at once)."""
    rows = found[:int(limit)]
    missing = [row for row in rows if not (row.get('versions') or []) and row.get('rating_key')]
    full = {}
    if missing:
        with ThreadPoolExecutor(max_workers=min(6, len(missing))) as pool:
            asked = dict((pool.submit(library.metadata, server, row.get('rating_key')), row) for row in missing)
            for done in as_completed(asked):
                try:
                    full[str(asked[done].get('rating_key'))] = done.result()
                except Exception:
                    pass
    return [full.get(str(row.get('rating_key')), row) for row in rows]
