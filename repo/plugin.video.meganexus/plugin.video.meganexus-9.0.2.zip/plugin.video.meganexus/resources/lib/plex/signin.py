# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Signing in to Plex with a PIN, as plex.tv/link does.

The typed code is a weak 4-character PIN from the v2 JSON endpoint (the old /pins.xml one,
retired on many plex.tv deployments, is the fallback). The QR code opens app.plex.tv/auth
directly, which accepts only a STRONG pin and only with the same client id and device
context the pin was made with - the parameter set python-plexapi's MyPlexPinLogin.oauthUrl
uses. Polling keeps to the PIN route that answered (trying a dead one every 2 s made the
QR screen lag). The PIN's token is exchanged for the account's lasting one
(/users/account)."""
import time
from urllib.parse import urlencode

import xbmc

from . import saved, wire
from .. import plex_account_file

PIN_WAIT = 8.0                  # a PIN call never holds the screen for the full timeout
JSON = {'Accept': 'application/json'}
_answering_route = {}           # pin id -> 'v2' / 'legacy'


def account():
    """{token, username, user_id, signed_in_at}, or {} - from either keeper (plex_state too)."""
    found = saved.load(saved.ACCOUNT, {})
    if not found.get('token'):
        found = plex_account_file.stored_account()
        if found.get('token'):
            saved.save(saved.ACCOUNT, found)
    elif not plex_account_file.stored_account().get('token'):
        plex_account_file.save_account(found)
    return found if found.get('token') else {}


def is_signed_in():
    """Signed in - or servers kept from before (their own tokens still search and play)."""
    return bool(account().get('token') or plex_account_file.servers_kept())


def sign_out():
    saved.sections.clear()
    saved.forget(saved.ACCOUNT)
    saved.forget(saved.SERVERS)
    plex_account_file.forget_account()


def _link_address(code):
    return 'https://plex.tv/link/?' + urlencode({'pin': str(code).upper()})


def request_pin(strong=False):
    """{id, code, flavor, strong, link_url}. A strong pin (for the QR) exists only on v2."""
    try:
        answer = wire.json_of(wire.fetch(wire.PLEX_TV + '/api/v2/pins', method='POST',
                                         data=urlencode({'strong': 'true' if strong else 'false'}), timeout=PIN_WAIT,
                                         headers=dict(JSON, **{'Content-Type': 'application/x-www-form-urlencoded'})))
        if answer.get('id') and answer.get('code'):
            code = str(answer['code'])
            return {'id': str(answer['id']), 'code': code if strong else code.upper(), 'flavor': 'v2',
                    'strong': bool(strong), 'link_url': _link_address(code)}
    except wire.PlexFailure as exc:
        xbmc.log('[MegaNexus] Plex v2 PIN failed (%s)%s' % (exc, '' if strong else ' - trying legacy'),
                 xbmc.LOGWARNING)
    if strong:
        raise wire.PlexFailure('strong PIN unavailable')
    answer = wire.xml_of(wire.fetch(wire.PLEX_TV + '/pins.xml', method='POST', timeout=PIN_WAIT))
    code, pin = (answer.findtext('code') or '').strip(), (answer.findtext('id') or '').strip()
    if not (code and pin):
        raise wire.PlexFailure('Plex did not send a link code')
    return {'id': pin, 'code': code.upper(), 'flavor': 'legacy', 'strong': False, 'link_url': _link_address(code)}


def auth_link_url(code):
    """The app.plex.tv/auth address the QR code holds (verified against python-plexapi)."""
    sent = wire.device_headers()
    fields = [('clientID', 'X-Plex-Client-Identifier'), ('context[device][product]', 'X-Plex-Product'),
              ('context[device][version]', 'X-Plex-Version'), ('context[device][platform]', 'X-Plex-Platform'),
              ('context[device][platformVersion]', 'X-Plex-Platform-Version'),
              ('context[device][device]', 'X-Plex-Device'), ('context[device][deviceName]', 'X-Plex-Device-Name')]
    return 'https://app.plex.tv/auth/#!?' + urlencode([(name, sent[header]) for name, header in fields]
                                                      + [('code', str(code or '').strip())])


def _user(token):
    """The account for a PIN's token, with the lasting authentication token when Plex gives it."""
    try:
        root = wire.xml_of(wire.fetch(wire.PLEX_TV + '/users/account', token=token))
        found = root.find('.//user')
        user = root if root.tag.lower() == 'user' else (found if found is not None and len(found) else root)
        lasting = (root.findtext('.//authentication-token') or user.attrib.get('authenticationToken') or '').strip()
        name = (user.attrib.get('username') or user.attrib.get('title') or wire.value_of(user, 'username')
                or wire.value_of(user, 'title'))
        if lasting or name:
            return {'token': str(lasting or token), 'username': name or '',
                    'user_id': user.attrib.get('id') or wire.value_of(user, 'id'), 'signed_in_at': int(time.time())}
    except wire.PlexFailure:
        pass
    user = wire.json_of(wire.fetch(wire.PLEX_TV + '/api/v2/user', token=token, headers=JSON))
    return {'token': str(token), 'username': user.get('username') or user.get('title') or user.get('email') or '',
            'user_id': str(user.get('id') or ''), 'signed_in_at': int(time.time())}


def _v2_token(pin_id, code):
    address = '%s/api/v2/pins/%s' % (wire.PLEX_TV, pin_id) + ('?' + urlencode({'code': str(code)}) if code else '')
    answer = wire.json_of(wire.fetch(address, method='GET', timeout=PIN_WAIT, headers=JSON))
    return answer.get('authToken') or answer.get('auth_token') or ''


def _legacy_token(pin_id, _code):
    answer = wire.xml_of(wire.fetch('%s/pins/%s.xml' % (wire.PLEX_TV, pin_id), method='GET', timeout=PIN_WAIT))
    return (answer.findtext('auth_token') or wire.value_of(answer, 'auth_token')
            or wire.value_of(answer, 'authToken') or '').strip()


def poll_pin(pin_id, code='', flavor='v2'):
    """The signed-in account once the PIN is linked, None while waiting; both PIN routes are
    tried (the first that answers is kept for this pin)."""
    routes = {'v2': _v2_token, 'legacy': _legacy_token}
    first = _answering_route.get(str(pin_id)) or ('legacy' if str(flavor or 'v2') == 'legacy' else 'v2')
    token, failure = '', None
    for name in [first] + [other for other in ('v2', 'legacy') if other != first]:
        try:
            token = routes[name](pin_id, code)
        except wire.PlexFailure as exc:
            failure = exc
            continue
        _answering_route[str(pin_id)] = name
        failure = None
        break
    if not token:
        if failure is not None:
            raise failure
        return None
    _answering_route.pop(str(pin_id), None)
    found = _user(token)
    saved.save(saved.ACCOUNT, found)
    plex_account_file.save_account(found)
    saved.setting(saved.SERVERS, '')
    saved.remove(saved.SERVERS)
    return found
