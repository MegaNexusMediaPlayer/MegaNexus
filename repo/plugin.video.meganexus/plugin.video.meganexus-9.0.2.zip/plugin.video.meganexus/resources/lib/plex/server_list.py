# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The account's Plex servers and the address each one is reached at.

The list comes from clients.plex.tv/api/v2/resources (the XML /api/resources as fallback)
and is kept a day. A plex.tv failure or an empty answer keeps the last list - an outage
must never look like a deleted account; without the account token the kept servers (each
with its own access token) still work.

Connections are ordered home network first, relay last, HTTPS before HTTP. A home server
that does not require HTTPS also gets a plain http://<ip>:<port> fallback (a router's
DNS-rebinding protection can hide the *.plex.direct name). The address that answers
/identity first in that order is kept 10 minutes, shared by every interpreter through a
Home window property."""
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode, urlsplit

import xbmc
import xbmcgui

from . import signin, saved, wire
from .. import plex_account_file

RESOURCES = 'https://clients.plex.tv/api/v2/resources?includeHttps=1&includeRelay=1&includeIPv6=1'
OLD_RESOURCES = wire.PLEX_TV + '/api/resources?includeHttps=1&includeRelay=1'
LIST_LIFE = 24 * 3600
ADDRESS_LIFE = 10 * 60
_addresses = {}                 # server id -> (address, until)


def clean_address(value):
    value = str(value or '').strip().rstrip('/')
    return value if value.startswith(('http://', 'https://')) else ''


def _yes(value):
    return value is True or str(value or '').strip().lower() in ('1', 'true')


def _devices(token):
    try:
        rows = json.loads((wire.fetch(RESOURCES, token=token, timeout=min(8, wire.wait()),
                                      headers={'Accept': 'application/json'}) or b'').decode('utf-8', 'ignore'))
        if isinstance(rows, list):
            return rows
    except (wire.PlexFailure, ValueError) as exc:
        xbmc.log('[MegaNexus] Plex v2 resources unavailable (%s); trying the older endpoint' % exc, xbmc.LOGINFO)
    root = wire.xml_of(wire.fetch(OLD_RESOURCES, token=token, timeout=min(8, wire.wait())))
    return [dict(device.attrib, connections=[dict(c.attrib) for c in device.findall('./Connection')])
            for device in root.findall('.//Device')]


def _connections(device):
    https_only = _yes(device.get('httpsRequired'))
    found, known = [], set()
    for row in device.get('connections') or []:
        address = clean_address(row.get('uri'))
        if not address:
            continue
        home, relay = _yes(row.get('local')), _yes(row.get('relay'))
        ip, port = str(row.get('address') or '').strip(), str(row.get('port') or '').strip()
        scheme = str(row.get('protocol') or urlsplit(address).scheme or '').lower()
        found.append({'uri': address, 'local': home, 'relay': relay, 'protocol': scheme, 'address': ip, 'port': port})
        known.add(address)
        if home and not relay and not https_only and ip and port and scheme == 'https':
            plain = clean_address('http://%s:%s' % ('[%s]' % ip if ':' in ip and not ip.startswith('[') else ip, port))
            if plain and plain not in known:
                found.append({'uri': plain, 'local': True, 'relay': False, 'protocol': 'http', 'address': ip,
                              'port': port, 'fallback': True})
                known.add(plain)
    found.sort(key=lambda c: (not c['local'], c['relay'], not c['uri'].startswith('https://')))
    return found


def _server(device, token):
    if 'server' not in (device.get('provides') or '').lower():
        return None
    ways = _connections(device)
    name = device.get('clientIdentifier') or device.get('machineIdentifier') or device.get('name')
    if not ways or not name:
        return None
    return {'id': str(name), 'name': device.get('name') or 'Plex Server',
            'product': device.get('product') or 'Plex Media Server', 'platform': device.get('platform') or '',
            'owned': _yes(device.get('owned')), 'https_required': _yes(device.get('httpsRequired')),
            'token': str(device.get('accessToken') or token), 'connections': ways}


def _keep(found):
    saved.sections.clear()          # owners, connections and libraries may have changed
    kept = {'fetched_at': int(time.time()), 'servers': found or []}
    saved.save(saved.SERVERS, kept)
    plex_account_file.keep_servers(found or [], kept['fetched_at'])


def servers(force=False):
    """Every server the account can use (kept a day; `force` asks plex.tv now)."""
    token = signin.account().get('token')
    kept = saved.load(saved.SERVERS, {})
    if not (kept.get('servers') or []):
        kept = plex_account_file.load_server_cache()
        if kept.get('servers'):
            saved.save(saved.SERVERS, kept)
    known = kept.get('servers') or []
    if not token:
        if known:
            xbmc.log('[MegaNexus] Plex account token unavailable; using %d cached server(s)' % len(known),
                     xbmc.LOGWARNING)
        return known or []
    if not force and known and int(kept.get('fetched_at') or 0) + LIST_LIFE > time.time():
        return known
    try:
        devices = _devices(token)
    except wire.PlexFailure as exc:
        if known:
            xbmc.log('[MegaNexus] Plex resource refresh failed; using stale cache (%s)' % exc, xbmc.LOGWARNING)
            return known
        raise
    found = [server for server in (_server(device, token) for device in devices) if server]
    if found or not known:
        _keep(found)
        return found
    xbmc.log('[MegaNexus] Plex returned zero resources; keeping stale server cache', xbmc.LOGWARNING)
    return known


def server_by_id(server_id, force=False):
    return next((server for server in servers(force=force) if str(server.get('id')) == str(server_id)), None)


def _answers(address, token='', timeout=3):
    try:
        wire.fetch(address + '/identity', token=token, timeout=timeout)
        return True
    except wire.PlexFailure:
        return False


def address_of(server, force=False):
    """The first connection (in preference order) that answers - all asked at once, 3 s each."""
    sid = str(server.get('id') or '')
    now = time.time()
    if not force and sid:
        known = _addresses.get(sid)
        if known and now < known[1]:
            return known[0]
        try:
            shared = xbmcgui.Window(saved.HOME).getProperty('meganexus.plex.uri.%s' % sid) or ''
            if shared:
                address, until = shared.rsplit('|', 1)
                if now < float(until):
                    _addresses[sid] = (address, float(until))
                    return address
        except Exception:
            pass
    ways = [address for address in (clean_address(c.get('uri')) for c in server.get('connections') or []) if address]
    if not ways:
        return ''
    best = ways[0]
    if len(ways) > 1:
        token = server.get('token') or signin.account().get('token') or ''
        answered = {}
        with ThreadPoolExecutor(max_workers=min(4, len(ways))) as pool:
            asked = dict((pool.submit(_answers, address, token), address) for address in ways)
            for done in as_completed(asked):
                try:
                    answered[asked[done]] = bool(done.result())
                except Exception:
                    answered[asked[done]] = False
        best = next((address for address in ways if answered.get(address)), ways[0])
    until = now + ADDRESS_LIFE
    if sid:
        _addresses[sid] = (best, until)
        try:
            xbmcgui.Window(saved.HOME).setProperty('meganexus.plex.uri.%s' % sid, '%s|%s' % (best, until))
        except Exception:
            pass
    return best


def _address_for(server, base, path, params):
    """base + path + query, the token in the query (a relay passes no headers; never logged)."""
    pairs = [(str(k), str(v)) for k, v in (params or {}).items() if v not in (None, '')]
    token = server.get('token') or signin.account().get('token')
    if token:
        pairs.append(('X-Plex-Token', str(token)))
    query = urlencode(pairs)
    return base + '/' + str(path or '').lstrip('/') + ('?' + query if query else '')


def ask(server, path, params=None):
    """(XML root, the address that answered): the kept address, once more after a fresh check
    (the network changed), then every connection in turn."""
    wait = min(8, wire.wait())
    base = address_of(server)
    if base:
        try:
            return wire.xml_of(wire.fetch(_address_for(server, base, path, params), timeout=wait)), base
        except wire.PlexFailure:
            again = address_of(server, force=True)
            if again and again != base:
                try:
                    return wire.xml_of(wire.fetch(_address_for(server, again, path, params), timeout=wait)), again
                except wire.PlexFailure:
                    pass
    failure = None
    for connection in server.get('connections') or []:
        each = clean_address(connection.get('uri'))
        if not each:
            continue
        try:
            return wire.xml_of(wire.fetch(_address_for(server, each, path, params), timeout=wait)), each
        except wire.PlexFailure as exc:
            failure = exc
    raise failure or wire.PlexFailure('No valid connection to the Plex server')


def is_local_connection(server, base_url):
    """`base_url` is one of the server's home-network connections."""
    base = clean_address(base_url)
    return any(c.get('local') and clean_address(c.get('uri')) == base for c in server.get('connections') or [])
