# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Where the Plex sign-in, the server list and this device's Plex id are kept.

Kodi runs several warm interpreters, each with its own settings snapshot: one that started
before the sign-in reads an empty account. So every value lives three times - the add-on
setting, a file in the add-on's profile folder (written atomically) and, for the account,
a Home window property all interpreters share. A value missing in one place is read from
the next and copied back; an empty read is never taken for a sign-out."""
import json
import os

import xbmc
import xbmcaddon
import xbmcgui

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

FILES = {'plex_auth_json': 'plex_account.json', 'plex_servers_cache_json': 'plex_servers.json',
         'plex_client_identifier': 'plex_client_id.txt'}
ACCOUNT = 'plex_auth_json'
SERVERS = 'plex_servers_cache_json'
DEVICE = 'plex_client_identifier'
SHARED = {ACCOUNT: 'meganexus.plex.auth'}      # setting -> Home window property
HOME = 10000
sections = {}                                   # server id -> {at, rows}: the libraries, this interpreter


def addon():
    """A new handle every time (a kept one holds the settings of when it was made)."""
    return xbmcaddon.Addon('plugin.video.meganexus')


def setting(name, value=None):
    """Read a setting (''), or write it and give the value back."""
    if value is None:
        try:
            return addon().getSetting(name) or ''
        except Exception:
            return ''
    try:
        addon().setSetting(name, str(value))
    except Exception:
        pass
    return str(value)


def _file(name):
    try:
        folder = 'special://profile/addon_data/plugin.video.meganexus/'
        folder = xbmcvfs.translatePath(folder) if xbmcvfs is not None else folder
        if not folder or folder.startswith('special://') or name not in FILES:
            return ''
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, FILES[name])
    except Exception:
        return ''


def read(name):
    path = _file(name)
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return handle.read().strip()
    except Exception:
        return ''


def write(name, value):
    """Atomically (a cut power never leaves half a file)."""
    path = _file(name)
    if not path:
        return False
    part = path + '.tmp'
    try:
        with open(part, 'w', encoding='utf-8') as handle:
            handle.write(str(value or ''))
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
        os.replace(part, path)
        return True
    except Exception as exc:
        try:
            if os.path.exists(part):
                os.remove(part)
        except Exception:
            pass
        xbmc.log('[MegaNexus] Plex persistent write failed: %s' % exc, xbmc.LOGWARNING)
        return False


def remove(name):
    path = _file(name)
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def load(name, default):
    """A JSON value: the setting, else the shared property, else the file (copied back)."""
    text = setting(name)
    if not text and name in SHARED:
        try:
            text = xbmcgui.Window(HOME).getProperty(SHARED[name]) or ''
        except Exception:
            text = ''
    if not text:
        text = read(name)
        if text:
            setting(name, text)
    try:
        value = json.loads(text or '')
    except Exception:
        return default
    return value if isinstance(value, type(default)) else default


def save(name, value):
    try:
        text = json.dumps(value, separators=(',', ':'), ensure_ascii=False)
        setting(name, text)
        write(name, text)
        if name in SHARED:
            xbmcgui.Window(HOME).setProperty(SHARED[name], text)
    except Exception:
        pass


def forget(name):
    setting(name, '')
    remove(name)
    if name in SHARED:
        try:
            xbmcgui.Window(HOME).clearProperty(SHARED[name])
        except Exception:
            pass


def client_identifier():
    """This device's Plex id (PIN sign-in needs it); a passing empty settings read never
    makes a new one - the user would have to link the device again."""
    import uuid
    value = setting(DEVICE).strip()
    if not value:
        value = read(DEVICE).strip()
        if value:
            setting(DEVICE, value)
    if not value:
        value = uuid.uuid4().hex
        setting(DEVICE, value)
        write(DEVICE, value)
    elif not read(DEVICE):
        write(DEVICE, value)
    return value
