# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The plugin actions answered straight from a table: the action, the hub function and
what it is given (the request's own values, or a fixed one)."""
_NOT_HANDLED = object()

# action -> (hub function, fixed arguments...)
_PLAIN = {
    'setup_center': ('setup_center',), 'setup_playback': ('setup_playback',),
    'setup_subtitles': ('setup_subtitles',), 'setup_quality': ('setup_quality',),
    'setup_stability': ('setup_stability',), 'setup_diagnostics': ('setup_diagnostics',),
    'emby_menu': ('mediabrowser_menu',), 'emby_login': ('emby_login',), 'emby_logout': ('emby_logout',),
    'emby_continue': ('mediabrowser_continue',),
    'plex_menu': ('plex_home',), 'plex_login': ('plex_sign_in',), 'plex_logout': ('plex_logout',),
    'plex_refresh': ('plex_refresh',), 'plex_servers': ('plex_server_list',),
    'switch_source': ('change_source',), 'cloud_sync_now': ('cloud_sync_now',),
    'nuvio_login': ('_cloud_login', 'nuvio'), 'nuvio_logout': ('_cloud_logout', 'nuvio'),
    'stremio_login': ('_cloud_login', 'stremio'), 'stremio_logout': ('_cloud_logout', 'stremio'),
    'meganexus_qr_login': ('_cloud_qr_login', 'nuvio'), 'stremio_qr_login': ('_cloud_qr_login', 'stremio'),
}

# action -> (hub function, [request values in order], {keyword: request value}); a value
# is (name, default)
_LISTING = {'title': ('title', ''), 'start': ('start', '0')}
_LIBRARY = dict(_LISTING, library_type=('library_type', ''), sort=('sort', ''))
_SERVER = ('server_id', '')
_ASKED = {
    'search': ('search', [('media_type', 'movie'), ('provider_id', None)], {'query': ('query', '')}),
    'emby_library': ('mediabrowser_library', [('key', '')], _LIBRARY),
    'emby_children': ('mediabrowser_children', [('key', '')], _LISTING),
    'emby_play': ('mediabrowser_play', [('item_id', '')], {}),
    'plex_server': ('plex_server_rows', [_SERVER], {}),
    'plex_continue': ('plex_continue_rows', [_SERVER], {}),
    'plex_library': ('plex_library_rows', [_SERVER, ('key', '')], _LIBRARY),
    'plex_children': ('plex_child_rows', [_SERVER, ('key', '')], _LISTING),
    'plex_search': ('plex_find', [_SERVER], {}),
    'plex_play': ('plex_start', [_SERVER, ('rating_key', '')], {}),
}


def dispatch(action, params, api):
    if action in _PLAIN:
        name, fixed = _PLAIN[action][0], _PLAIN[action][1:]
        return getattr(api, name)(*fixed)
    if action in _ASKED:
        name, ordered, named = _ASKED[action]
        value = lambda pair: params.get(pair[0], pair[1])
        return getattr(api, name)(*[value(pair) for pair in ordered],
                                  **{key: value(pair) for key, pair in named.items()})
    return _NOT_HANDLED
