# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from __future__ import absolute_import


def qr_login(service):
    if service != 'nuvio':return False
    from resources.lib.phone_link import qr_pair
    return qr_pair(service)


def login(service, addon, tr):
    if service != 'nuvio':return False
    import xbmcgui
    from resources.lib.meganexus import cloud_sync as sync
    dlg = xbmcgui.Dialog()
    email = (addon.getSetting('%s_email' % service) or '').strip()
    password = addon.getSetting('%s_password' % service) or ''
    if not email or not password:
        dlg.ok('MegaNexus', tr('Enter the email and password in Settings first.'))
        return False
    try:
        if service == 'nuvio':
            sync.NuvioCloud.login(email, password)
        else:
            sync.StremioCloud.login(email, password)
        try:
            addon.setSetting('%s_sync_enabled' % service, 'true')
        except Exception:
            pass
        dlg.notification('MegaNexus', tr('Logged in ✓'), xbmcgui.NOTIFICATION_INFO, 4000)
        return True
    except Exception as exc:
        dlg.ok('MegaNexus', tr('Login failed:') + '\n' + str(exc))
        return False


def logout(service, tr):
    import xbmcgui
    from resources.lib.meganexus import cloud_sync as sync
    if service == 'nuvio':
        sync.NuvioCloud.clear()
    else:
        sync.StremioCloud.clear()
    xbmcgui.Dialog().notification('MegaNexus', tr('Logged out'), xbmcgui.NOTIFICATION_INFO, 3000)
    return True


def direction(addon):
    raw = addon.getSetting('cloud_sync_direction') or 'Two-way'
    if raw in ('Upload only'):
        return 'push'
    if raw in ('Download only'):
        return 'pull'
    return 'both'


def sync_options(addon, tr, setting):
    import xbmcgui
    while True:
        try:
            interval = int(float(setting('cloud_sync_interval_min', '30') or '30'))
        except Exception:
            interval = 30
        continuous = (setting('cloud_sync_continuous', 'true') or 'true'
                      ).strip().lower() in ('true', '1', 'yes', 'on')
        if interval <= 0:
            mode = tr('Off')
        elif continuous:
            mode = tr('Continuous (instant)')
        else:
            mode = tr('Smart and lightweight')
        rows = [
            '%s:  [B]%s[/B]' % (tr('Sync mode'), mode),
            '%s:  [B]%s[/B]' % (
                tr('Pull interval'),
                (tr('%d min') % interval) if interval > 0 else tr('Off')),
            tr('Sync now'),
        ]
        choice = xbmcgui.Dialog().select(tr('Sync settings'), rows)
        if choice < 0:
            return
        if choice == 0:
            modes = [tr('Continuous (instant)'), tr('Smart and lightweight'), tr('Off')]
            pick = xbmcgui.Dialog().select(tr('Sync mode'), modes)
            if pick == 2:                                    # off: no pulling at all
                addon.setSetting('cloud_sync_interval_min', '0')
            elif pick >= 0:
                if interval <= 0:                            # on again: every half hour
                    addon.setSetting('cloud_sync_interval_min', '30')
                addon.setSetting('cloud_sync_continuous', 'true' if pick == 0 else 'false')
        elif choice == 1:
            minutes = (5, 15, 30, 60, 120, 240)
            pick = xbmcgui.Dialog().select(tr('Pull interval'), [tr('%d min') % n for n in minutes])
            if pick >= 0:
                addon.setSetting('cloud_sync_interval_min', str(minutes[pick]))
        else:
            return sync_now(addon, tr, only=None)
        try:
            from resources.lib import settings_snapshot
            settings_snapshot.invalidate()
        except Exception:
            pass


def sync_now(addon, tr, only=None):
    import xbmcgui
    from resources.lib.meganexus import cloud_sync as sync
    dlg = xbmcgui.Dialog()
    targets = sync.active_targets()
    if only:
        targets = [t for t in targets if t == only]
        if not targets:
            dlg.ok('MegaNexus', tr('No linked account for this service.'))
            return False
    if not targets:
        dlg.ok('MegaNexus', tr('Enable a Nuvio or Stremio account and log in first.'))
        return False
    pd = xbmcgui.DialogProgressBG()
    pd.create('MegaNexus', tr('Syncing accounts…'))
    try:
        pd.update(15, tr('Preparing sync…'))
        result = sync.sync_round(targets=targets, force_full=False)
        pd.update(95, tr('Saving results…'))
    finally:
        pd.close()
    if not result or not result.get('ok'):
        # every section that failed, as service/section: why
        errors = ['%s/%s: %s' % (row.get('service'), name, part.get('error', ''))
                  for row in (result or {}).get('report', []) for name, part in (row.get('sections') or {}).items()
                  if not part.get('ok')]
        dlg.ok('MegaNexus', tr('Sync failed:') + '\n' + ('\n'.join(errors) or str((result or {}).get('error', ''))))
        return False
    ok_services = [r['service'] for r in result.get('report', []) if r.get('ok')]
    wb = result.get('writeback', {})
    msg = tr('Sync complete')
    if ok_services:
        msg += ' • ' + ', '.join(ok_services)
    msg += ' • ' + tr('+%d addons, %d progress items') % (
        wb.get('providers', 0), wb.get('progress', 0))
    dlg.notification('MegaNexus', msg, xbmcgui.NOTIFICATION_INFO, 6000)
    errors = []
    for row in result.get('report', []):
        for name, section in (row.get('sections') or {}).items():
            if not section.get('ok'):
                errors.append('%s/%s: %s' % (row.get('service'), name, section.get('error', '')))
    if errors:
        dlg.ok('MegaNexus • Sync details', '\n'.join(errors))
    return True
