# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The numbers of the diagnostics overlay (7.0.42), every STEP seconds.

The overlay (skin Custom_1111_MegaNexusStats.xml) showed Kodi's own labels; the
frame rate one changes every frame, so Kodi redrew the whole screen all the
time while the overlay was on - over half a CPU core on a Fire TV Cube with
nothing happening. The service now writes CPU, memory, frame rate and the
internet in use (down / up, from /proc/net/dev; not on every platform) into
Window(Home) properties, only while the overlay is switched on.
"""
import time

STEP = 2.0
PREFIX = 'meganexus.stats.'


def net_bytes(path='/proc/net/dev'):
    """(received, sent) bytes of every interface but loopback, or None."""
    try:
        with open(path) as handle:
            lines = handle.readlines()[2:]
    except OSError:
        return None
    down = up = 0
    for line in lines:
        name, _, data = line.partition(':')
        if name.strip() == 'lo' or not data:
            continue
        fields = data.split()
        if len(fields) >= 9:
            down += int(fields[0])
            up += int(fields[8])
    return down, up


def rate(bits_per_second):
    if bits_per_second >= 1e6:
        return '%.1f Mbit/s' % (bits_per_second / 1e6)
    return '%.0f kbit/s' % (bits_per_second / 1e3)


def net_line(before, after, seconds):
    if not before or not after or seconds <= 0:
        return 'not available here'
    down = max(0, after[0] - before[0]) * 8 / seconds
    up = max(0, after[1] - before[1]) * 8 / seconds
    return '↓ %s  ·  ↑ %s' % (rate(down), rate(up))


def max_line(measured, now=None):
    """7.0.42: the network's top speed, from the hourly measurement (net_speed)."""
    down, up = measured.get('mbps'), measured.get('up')
    if not down:
        return 'measured within 2 minutes of start'
    at = time.strftime('%H:%M', time.localtime(float(measured.get('at') or 0))) if measured.get('at') else ''
    return '↓ %.1f Mbit/s  ·  ↑ %s%s' % (float(down), '%.1f Mbit/s' % float(up) if up else '-', '  (%s)' % at if at else '')


BARS = '▁▂▃▄▅▆▇█'
HOT, WARM = 'FFFF7A6E', 'FFFFB74D'     # a core / the memory this full shows amber, then red


def cpu_times(path='/proc/stat'):
    """{core: (busy, total)} from the kernel (Linux, CoreELEC; not every Android), or None."""
    try:
        with open(path) as handle:
            lines = handle.readlines()
    except OSError:
        return None
    found = {}
    for line in lines:
        name, _, rest = line.partition(' ')
        if not name.startswith('cpu') or name == 'cpu':
            continue
        numbers = [int(x) for x in rest.split()[:8] if x.isdigit()]
        if len(numbers) >= 4:
            idle = numbers[3] + (numbers[4] if len(numbers) > 4 else 0)
            found[name] = (sum(numbers) - idle, sum(numbers))
    return found or None


def core_loads(before, after):
    """Per-core use in %, in core order."""
    loads = []
    for core in sorted(after, key=lambda n: int(n[3:]) if n[3:].isdigit() else 0):
        if core in before:
            busy, total = after[core][0] - before[core][0], after[core][1] - before[core][1]
            loads.append(max(0.0, min(100.0, 100.0 * busy / total)) if total > 0 else 0.0)
    return loads


def label_loads(text):
    """Kodi's own CPU label ("CPU0: 12% CPU1: 3%..." or "12%") as numbers - where /proc/stat
    can not be read."""
    import re
    return [float(x) for x in re.findall(r'(\d+(?:\.\d+)?)\s*%', str(text or ''))]


def _colour(value, text):
    colour = HOT if value >= 90 else WARM if value >= 70 else ''
    return '[COLOR %s]%s[/COLOR]' % (colour, text) if colour else text


MAX_BARS = 16


def cores_line(loads):
    """A bar for each core: up to 8 with a space between, up to 16 close together; more are
    shown in pairs (32 cores: 16 bars), so they always fit the tile."""
    loads = list(loads)
    while len(loads) > MAX_BARS:
        loads = [sum(loads[i:i + 2]) / len(loads[i:i + 2]) for i in range(0, len(loads), 2)]
    joiner = ' ' if len(loads) <= 8 else ''
    return joiner.join(_colour(v, BARS[min(len(BARS) - 1, int(v / 100.0 * len(BARS)))]) for v in loads)


def bar(percent, width=16):
    full = max(0, min(width, int(round(percent / 100.0 * width))))
    return _colour(percent, '━' * full) + '[COLOR 33FFFFFF]%s[/COLOR]' % ('━' * (width - full))


def _number(text):
    import re
    found = re.search(r'(\d+(?:\.\d+)?)', str(text or ''))
    return float(found.group(1)) if found else 0.0


def run(monitor, shown, label, window, folder=''):
    """Service loop; ``shown()`` - the overlay is on, ``label(name)`` - a Kodi info label."""
    last, at, cpu_last = None, 0., None
    while not monitor.waitForAbort(STEP):
        try:
            if not shown():
                last = None
                continue
            from . import stall_watch                    # 8.1.0: Python busy, while the overlay is on
            stall_watch.start()
            longest, average = stall_watch.numbers()
            window.setProperty(PREFIX + 'python_value', '%d ms' % longest if longest is not None else '…')
            window.setProperty(PREFIX + 'python_sub', 'longest wait · avg %.1f ms' % average if average is not None else 'measuring')
            now, sample = time.monotonic(), net_bytes()
            # 8.1.0: the card's tiles - a bar for each core, however many
            times = cpu_times()
            loads = core_loads(cpu_last, times) if (times and cpu_last) else ([] if times else label_loads(label('System.CPUUsage')))
            cpu_last = times
            window.setProperty(PREFIX + 'cpu_total', '%d%%' % round(sum(loads) / len(loads)) if loads else '…')
            window.setProperty(PREFIX + 'cores', cores_line(loads) if loads else '')
            window.setProperty(PREFIX + 'temp', label('System.CPUTemperature'))
            used = _number(label('System.Memory(used.percent)'))
            window.setProperty(PREFIX + 'mem_pct', '%d%%' % used)
            window.setProperty(PREFIX + 'mem_caption', '%s / %s' % (label('System.Memory(used)'), label('System.Memory(total)')))
            window.setProperty(PREFIX + 'mem_bar', bar(used))
            window.setProperty(PREFIX + 'fps_value', '%d' % _number(label('System.FPS')))
            window.setProperty(PREFIX + 'net', net_line(last, sample, now - at) if last else 'measuring…')
            if folder:
                from . import net_speed
                window.setProperty(PREFIX + 'netmax', max_line(net_speed.last(folder)))
            last, at = sample, now
        except Exception:
            pass
