# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The catalog index (Settings: index mode Hybrid / Fast Index): Home sections and search
answered from catalog titles kept on the device instead of asking every add-on again.

`store` is the file, `sync` fills it in the background, this module turns its rows back
into the catalog items the screens draw. Nothing here asks the network; an empty answer
(None) tells the caller to ask the add-ons as usual."""
import json
import os
import threading

import xbmc

from .library_file import LibraryStore

FILE_NAME = 'library.sqlite3'
EMPTY_SUMMARY = {'items': 0, 'sources': 0, 'catalogs': 0, 'last_sync': 0, 'db_size': 0}
_OPEN = {'store': None}
_OPENING = threading.Lock()


def get_db():
    """The library file of this profile, opened once."""
    if _OPEN['store'] is None:
        with _OPENING:
            if _OPEN['store'] is None:
                from ..meganexus.paths import profile_path
                _OPEN['store'] = LibraryStore(os.path.join(profile_path(), FILE_NAME))
    return _OPEN['store']


def _as_item(row, extra=True):
    """A stored row as the catalog item it was, gaps filled from the row's own columns."""
    try:
        item = json.loads(row['meta_blob']) if row['meta_blob'] else {}
    except Exception:
        item = {}
    item.setdefault('id', row['id'])
    item.setdefault('imdb_id', row.get('imdb_id') or row['id'])
    item.setdefault('type', row['type'])
    item.setdefault('name', row['title'])
    gaps = (('poster', 'poster'),)
    if extra:
        gaps += (('background', 'background'), ('description', 'description'))
    for column, key in gaps:
        if row.get(column) and not item.get(key):
            item[key] = row[column]
    if extra:
        if row.get('rating') is not None and not item.get('imdbRating'):
            item['imdbRating'] = row['rating']
        if row.get('year') and not item.get('year'):
            item['year'] = row['year']
    item['_meganexus_indexed'] = True
    return item


def query_bucket_metas(bucket, sort='release_date', media_type=None, genre=None, year=None, language=None,
                       limit=80, offset=0):
    """A Home section's catalog items with the add-on / catalog that lists each one
    (_meganexus_provider_id / _meganexus_catalog_id - playing asks that add-on);
    None when the index has nothing for it."""
    try:
        rows = get_db().section(bucket, sort=sort, media_type=media_type, genre=genre, year=year,
                                language=language, limit=limit, offset=offset)
    except Exception as exc:
        xbmc.log('[MegaNexus] index query failed: %s' % exc, xbmc.LOGWARNING)
        return None
    items = []
    for row in rows or []:
        item = _as_item(row)
        item['_meganexus_provider_id'] = row.get('best_provider_id') or ''
        item['_meganexus_catalog_id'] = row.get('best_catalog_id') or ''
        items.append(item)
    return items or None


def bucket_has_data(bucket):
    try:
        return get_db().section_size(bucket) > 0
    except Exception:
        return False


def stats():
    try:
        return get_db().summary()
    except Exception:
        return dict(EMPTY_SUMMARY)


