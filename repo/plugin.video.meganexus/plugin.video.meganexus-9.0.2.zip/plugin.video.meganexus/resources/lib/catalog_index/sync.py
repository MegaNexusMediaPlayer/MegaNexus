# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Filling the catalog index: the Home sections' catalogs read in the background.

`CatalogSync` reads a set of pinned catalogs (all, one Home section, or one catalog) two
at a time and writes their first page into the index; one run at a time, a second asks
are turned away. `run_scheduler` repeats a full run every few hours (the service)."""
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmc

AT_ONCE = 2           # catalogs read together - background work, the user's bandwidth comes first
CATALOG_TIMEOUT = 8   # s per catalog
PAGE = 100            # titles per catalog
EVERY_HOURS = 4
FIRST_WAIT = 30       # s after Kodi starts
HOURS_RANGE = (1, 48)


class CatalogSync(object):
    """Pinned catalogs -> index. ``pinned()`` gives (provider, catalog, bucket[, pin]) entries,
    asked at every run (pins change); ``progress(stage, info)`` hears start / catalog / done."""

    def __init__(self, store, pinned=None, progress=None):
        self._store = store
        self._pinned = pinned or (lambda: [])
        self._progress = progress or (lambda *args, **kwargs: None)
        self._one_run = threading.Lock()
        self._busy = False
        self._halt = threading.Event()

    def is_running(self):
        return self._busy

    def stop(self):
        self._halt.set()

    def _run(self, choose, label, quiet_busy=False):
        if not self._one_run.acquire(False):
            if not quiet_busy:
                xbmc.log('[MegaNexus] %s: another sync is running, skipping' % label.split(':')[0], xbmc.LOGINFO)
            return {'skipped': True}
        try:
            self._busy = True
            self._halt.clear()
            return self._read(choose(list(self._pinned() or [])), label)
        finally:
            self._busy = False
            self._one_run.release()

    def sync_all(self):
        return self._run(lambda entries: entries, 'full')

    def sync_bucket(self, bucket):
        return self._run(lambda entries: [entry for entry in entries
                                          if (entry[2] if len(entry) > 2 else '') == bucket],
                         'bucket:%s' % bucket)

    def sync_single(self, provider_id, catalog_id, bucket):
        def one(entries):
            for entry in entries:
                if len(entry) >= 3 and (entry[0].get('id'), entry[1].get('id'), entry[2]) == (
                        provider_id, catalog_id, bucket):
                    return [entry]
            return []
        return self._run(one, 'single:%s/%s' % (provider_id, catalog_id), quiet_busy=True)

    def _read(self, entries, label):
        if not entries:
            self._progress('done', {'label': label, 'total': 0, 'message': 'no pinned catalogs to sync'})
            return {'total': 0, 'ok': 0, 'errors': 0}
        began = time.time()
        total = len(entries)
        self._progress('start', {'label': label, 'total': total})
        good = bad = 0
        with ThreadPoolExecutor(max_workers=AT_ONCE, thread_name_prefix='MegaNexus-sync') as pool:
            jobs = {}
            for number, entry in enumerate(entries):
                if self._halt.is_set():
                    break
                jobs[pool.submit(self._read_one, entry, number, total)] = entry
            for job in as_completed(jobs):
                if self._halt.is_set():
                    break
                try:
                    outcome = job.result()
                except Exception as exc:
                    bad += 1
                    xbmc.log('[MegaNexus] sync future failed: %s' % exc, xbmc.LOGWARNING)
                    continue
                if outcome and outcome.get('status') == 'ok':
                    good += 1
                else:
                    bad += 1
        seconds = time.time() - began
        self._progress('done', {'label': label, 'total': total, 'ok': good, 'errors': bad, 'duration': seconds})
        xbmc.log('[MegaNexus] sync %s done: %d catalogs in %.1fs (%d ok / %d errors)'
                 % (label, total, seconds, good, bad), xbmc.LOGINFO)
        return {'total': total, 'ok': good, 'errors': bad, 'duration': seconds}

    def _read_one(self, entry, number, total):
        if not isinstance(entry, (tuple, list)) or len(entry) < 2:
            xbmc.log('[MegaNexus] sync skipping malformed entry: %r' % (entry,), xbmc.LOGDEBUG)
            return {'status': 'error', 'error': 'malformed entry'}
        provider, catalog = entry[0] or {}, entry[1] or {}
        bucket = entry[2] if len(entry) > 2 else ''
        if not isinstance(provider, dict) or not isinstance(catalog, dict):
            return {'status': 'error', 'error': 'non-dict entry'}
        provider_id, catalog_id = provider.get('id') or '', catalog.get('id') or ''
        self._progress('catalog', {'index': number + 1, 'total': total,
                                   'provider': provider.get('name') or provider_id,
                                   'catalog': catalog.get('name') or catalog_id, 'bucket': bucket})
        began = time.time()
        try:
            from ..meganexus.addon_wire import fetch_catalog
            page = fetch_catalog(provider, catalog.get('type') or 'movie', catalog_id,
                                 extra={'limit': str(PAGE)}, timeout_override=CATALOG_TIMEOUT)
            items = (page or {}).get('metas') or []
            added, refreshed, _ = self._store.add_catalog(items if isinstance(items, list) else [],
                                                          provider_id, catalog_id, bucket)
            seconds = time.time() - began
            self._store.note_sync(provider_id, catalog_id, bucket, item_count=added + refreshed,
                                  duration=seconds, status='ok')
            return {'status': 'ok', 'inserted': added, 'updated': refreshed, 'duration': seconds}
        except Exception as exc:
            seconds = time.time() - began
            reason = str(exc)[:300]
            try:
                self._store.note_sync(provider_id, catalog_id, bucket, item_count=0, duration=seconds,
                                      status='error', error_message=reason)
            except Exception:
                pass
            xbmc.log('[MegaNexus] sync %s/%s failed: %s' % (provider_id, catalog_id, reason), xbmc.LOGWARNING)
            return {'status': 'error', 'error': reason}


def run_scheduler(syncer, monitor, get_interval_hours=None):
    """A full run now and then (the service's thread), until Kodi stops. The interval is
    read each time, so a changed setting counts without a restart."""
    monitor.waitForAbort(FIRST_WAIT)
    while not monitor.abortRequested():
        try:
            syncer.sync_all()
        except Exception as exc:
            xbmc.log('[MegaNexus] scheduler error: %s' % exc, xbmc.LOGWARNING)
        try:
            hours = int(get_interval_hours() if get_interval_hours else EVERY_HOURS)
        except Exception:
            hours = EVERY_HOURS
        if monitor.waitForAbort(max(HOURS_RANGE[0], min(HOURS_RANGE[1], hours)) * 3600):
            break
