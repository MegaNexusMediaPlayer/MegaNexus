# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The library file (library.sqlite3): catalog titles kept on the device.

Each title is one row of `items` however many catalogs list it; `item_sources` says which
add-on catalog (and Home section) listed it and at which position; `catalog_sync` keeps
how each catalog's last refresh went. A full-text table follows `items` through triggers.
The tables, indexes and triggers keep their names, so files written by any earlier
version open as they are."""
import json
import os
import re
import sqlite3
import threading
import time
from contextlib import contextmanager

SETTINGS = ('journal_mode = WAL', 'synchronous = NORMAL', 'temp_store = MEMORY', 'cache_size = -8000',
            'foreign_keys = ON')

ITEM_COLUMNS = (
    ('id', 'TEXT PRIMARY KEY'), ('type', 'TEXT NOT NULL'), ('title', 'TEXT NOT NULL'),
    ('title_norm', 'TEXT NOT NULL'), ('year', 'INTEGER'), ('release_date', 'TEXT'),
    ('added_date', 'INTEGER NOT NULL'), ('updated_date', 'INTEGER NOT NULL'), ('imdb_id', 'TEXT'),
    ('tmdb_id', 'TEXT'), ('poster', 'TEXT'), ('background', 'TEXT'), ('description', 'TEXT'),
    ('rating', 'REAL'), ('genres', 'TEXT'), ('runtime', 'INTEGER'), ('language', 'TEXT'),
    ('meta_blob', 'TEXT NOT NULL'),
)
TABLES = (
    ('items', [' '.join(column) for column in ITEM_COLUMNS]),
    ('item_sources', ['item_id TEXT NOT NULL', 'provider_id TEXT NOT NULL', 'catalog_id TEXT NOT NULL',
                      'bucket TEXT NOT NULL', 'priority INTEGER NOT NULL DEFAULT 0', 'last_seen INTEGER NOT NULL',
                      'PRIMARY KEY (item_id, provider_id, catalog_id, bucket)',
                      'FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE']),
    ('catalog_sync', ['provider_id TEXT NOT NULL', 'catalog_id TEXT NOT NULL', 'bucket TEXT NOT NULL',
                      'last_sync INTEGER', 'item_count INTEGER DEFAULT 0', 'sync_duration REAL', 'status TEXT',
                      'error_message TEXT', 'PRIMARY KEY (provider_id, catalog_id, bucket)']),
)
# (name, table, columns, only rows where)
INDEXES = (
    ('idx_items_type_release', 'items', 'type, release_date DESC', ''),
    ('idx_items_type_added', 'items', 'type, added_date DESC', ''),
    ('idx_items_type_rating', 'items', 'type, rating DESC', ''),
    ('idx_items_type_year', 'items', 'type, year DESC', ''),
    ('idx_items_type_title', 'items', 'type, title_norm ASC', ''),
    ('idx_items_imdb', 'items', 'imdb_id', 'imdb_id IS NOT NULL'),
    ('idx_sources_bucket_seen', 'item_sources', 'bucket, last_seen DESC', ''),
    ('idx_sources_bucket_prio', 'item_sources', 'bucket, priority ASC', ''),
    ('idx_sources_item', 'item_sources', 'item_id', ''),
    ('idx_catalog_sync_last', 'catalog_sync', 'last_sync ASC', ''),
)
SEARCHED = ('title', 'description', 'genres')
SEARCH_TABLE = 'items_fts'


def _searched(prefix):
    return ', '.join('%s.%s' % (prefix, column) if column == 'title' else "COALESCE(%s.%s,'')" % (prefix, column)
                     for column in SEARCHED)


def schema():
    """Every statement that makes (or, for an existing file, leaves alone) the library."""
    out = ['PRAGMA %s' % setting for setting in SETTINGS]
    out += ['CREATE TABLE IF NOT EXISTS %s (%s)' % (name, ', '.join(columns)) for name, columns in TABLES]
    out += ['CREATE INDEX IF NOT EXISTS %s ON %s(%s)%s' % (name, table, columns, ' WHERE ' + where if where else '')
            for name, table, columns, where in INDEXES]
    out.append("CREATE VIRTUAL TABLE IF NOT EXISTS %s USING fts5(%s, content='items', content_rowid='rowid', "
               "tokenize = 'unicode61 remove_diacritics 2')" % (SEARCH_TABLE, ', '.join(SEARCHED)))
    names = ', '.join(SEARCHED)
    add = 'INSERT INTO %s(rowid, %s) VALUES (new.rowid, %s);' % (SEARCH_TABLE, names, _searched('new'))
    drop = "INSERT INTO %s(%s, rowid, %s) VALUES('delete', old.rowid, %s);" % (
        SEARCH_TABLE, SEARCH_TABLE, names, _searched('old'))
    for suffix, event, body in (('ai', 'INSERT', add), ('ad', 'DELETE', drop), ('au', 'UPDATE', drop + ' ' + add)):
        out.append('CREATE TRIGGER IF NOT EXISTS %s_%s AFTER %s ON items BEGIN %s END'
                   % (SEARCH_TABLE, suffix, event, body))
    return out


# ---- a catalog title as an `items` row --------------------------------------------------

def _number(value, read=int):
    if value is None or value == '':
        return None
    try:
        return read(value)
    except (TypeError, ValueError):
        return None


def _year(meta):
    first = meta.get('year') or meta.get('releaseInfo')
    year = None if first is None else _number(str(first).split('-', 1)[0])
    if year is None and meta.get('releaseInfo'):
        year = _number(str(meta['releaseInfo'])[:4])
    return year


def _minutes(value):
    """"120", 95, "1h 50min", "120 min" as minutes."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).lower()
    plain = _number(text.strip())
    if plain is not None:
        return plain
    hours, minutes = re.search(r'(\d+)\s*h', text), re.search(r'(\d+)\s*m', text)
    total = (int(hours.group(1)) * 60 if hours else 0) + (int(minutes.group(1)) if minutes else 0)
    return total or None


def _genres(meta):
    found = meta.get('genres') or meta.get('genre') or []
    if isinstance(found, str):
        found = [name.strip() for name in found.split(',') if name.strip()]
    return found if isinstance(found, list) else []


def item_row(meta, now):
    """{column: value} of one catalog title, None when it has no id or no name."""
    raw = str(meta.get('imdb_id') or meta.get('id') or '').strip()
    title = str(meta.get('name') or meta.get('title') or '').strip()
    if not raw or not title:
        return None
    key = raw.split(':', 1)[0] if raw.startswith('tt') else raw   # an episode id names its series
    return {
        'id': key, 'type': str(meta.get('type') or 'movie').strip(), 'title': title, 'title_norm': title.lower(),
        'year': _year(meta), 'release_date': str(meta.get('released') or meta.get('release_date') or '')[:10],
        'added_date': now, 'updated_date': now, 'imdb_id': key if key.startswith('tt') else None,
        'tmdb_id': str(meta.get('tmdb_id') or '') or None, 'poster': str(meta.get('poster') or ''),
        'background': str(meta.get('background') or meta.get('fanart') or ''),
        'description': str(meta.get('description') or meta.get('plot') or ''),
        'rating': _number(meta.get('imdbRating') or meta.get('rating'), float),
        'genres': json.dumps(_genres(meta), ensure_ascii=False), 'runtime': _minutes(meta.get('runtime')),
        'language': str(meta.get('language') or '')[:8] or None, 'meta_blob': json.dumps(meta, ensure_ascii=False),
    }


_CHANGED = [name for name, _ in ITEM_COLUMNS if name not in ('id', 'added_date')]
_UPDATE = 'UPDATE items SET %s WHERE id = ?' % ', '.join('%s = ?' % name for name in _CHANGED)
_ALL = [name for name, _ in ITEM_COLUMNS]
_INSERT = 'INSERT INTO items (%s) VALUES (%s)' % (', '.join(_ALL), ', '.join('?' * len(_ALL)))
_ORPHANS = 'DELETE FROM items WHERE id NOT IN (SELECT DISTINCT item_id FROM item_sources)'

# folder order -> (column, direction)
ORDERS = {
    'release_date': ('i.release_date', 'DESC'), 'release': ('i.release_date', 'DESC'),
    'added_date': ('s.last_seen', 'DESC'), 'last_added': ('s.last_seen', 'DESC'),
    'rating': ('i.rating', 'DESC'), 'popular': ('i.rating', 'DESC'),
    'title': ('i.title_norm', 'ASC'), 'name': ('i.title_norm', 'ASC'), 'a_z': ('i.title_norm', 'ASC'),
    'year': ('i.year', 'DESC'), 'priority': ('best_priority', 'ASC'),
}


class LibraryStore(object):
    """One connection per thread (WAL: reading never waits for the writer); writers queue."""

    def __init__(self, path):
        self._path = path
        self._local = threading.local()
        self._writing = threading.Lock()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        first = self._open()
        try:
            for statement in schema():
                first.execute(statement)
        finally:
            first.close()

    def _open(self):
        connection = sqlite3.connect(self._path, timeout=10.0, isolation_level=None)
        connection.row_factory = sqlite3.Row
        return connection

    @property
    def conn(self):
        connection = getattr(self._local, 'conn', None)
        if connection is None:
            connection = self._local.conn = self._open()
        return connection

    @contextmanager
    def write(self):
        with self._writing:
            yield self.conn

    def _rows(self, sql, args=()):
        return [dict(row) for row in self.conn.execute(sql, list(args)).fetchall()]

    # ---- writing --------------------------------------------------------------------------

    def add_catalog(self, metas, provider_id, catalog_id, bucket):
        """A catalog's titles in (new ones added, known ones refreshed) and where they came from.
        Returns (added, refreshed, sources)."""
        now = int(time.time())
        items, sources = [], []
        for position, meta in enumerate(metas or []):
            row = item_row(meta, now) if isinstance(meta, dict) else None
            if row:
                items.append(row)
                sources.append((row['id'], provider_id, catalog_id, bucket, position, now))
        if not items:
            return (0, 0, 0)
        added = refreshed = 0
        with self.write() as connection:
            cursor = connection.cursor()
            cursor.execute('BEGIN')
            try:
                for row in items:
                    cursor.execute(_UPDATE, [row[name] for name in _CHANGED] + [row['id']])
                    if cursor.rowcount:
                        refreshed += 1
                    else:
                        cursor.execute(_INSERT, [row[name] for name in _ALL])
                        added += 1
                cursor.executemany('INSERT OR REPLACE INTO item_sources (item_id, provider_id, catalog_id, '
                                   'bucket, priority, last_seen) VALUES (?, ?, ?, ?, ?, ?)', sources)
                cursor.execute('COMMIT')
            except Exception:
                cursor.execute('ROLLBACK')
                raise
        return (added, refreshed, len(sources))

    def note_sync(self, provider_id, catalog_id, bucket, item_count, duration, status='ok', error_message=None):
        with self.write() as connection:
            connection.execute('INSERT OR REPLACE INTO catalog_sync (provider_id, catalog_id, bucket, last_sync, '
                               'item_count, sync_duration, status, error_message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                               (provider_id, catalog_id, bucket, int(time.time()), int(item_count),
                                float(duration), status, error_message))

    def forget_provider(self, provider_id):
        """Everything one add-on listed (it was removed)."""
        provider_id = str(provider_id or '').strip()
        if provider_id:
            self._forget('provider_id = ?', (provider_id,))

    def forget_catalog(self, provider_id, catalog_id, bucket=None):
        """What one catalog listed - in one Home section, or everywhere."""
        provider_id, catalog_id = str(provider_id or '').strip(), str(catalog_id or '').strip()
        if not provider_id or not catalog_id:
            return
        where, args = 'provider_id = ? AND catalog_id = ?', [provider_id, catalog_id]
        if bucket:
            where += ' AND bucket = ?'
            args.append(str(bucket).strip())
        self._forget(where, args)

    def _forget(self, where, args):
        with self.write() as connection:
            for table in ('item_sources', 'catalog_sync'):
                connection.execute('DELETE FROM %s WHERE %s' % (table, where), args)
            connection.execute(_ORPHANS)

    def wipe(self):
        with self.write() as connection:
            for table in ('item_sources', 'items', 'catalog_sync'):
                connection.execute('DELETE FROM ' + table)
        self.compact()

    def compact(self):
        try:
            self.conn.execute('VACUUM')
        except Exception:
            pass

    # ---- reading --------------------------------------------------------------------------

    def sync_states(self, provider_id=None, catalog_id=None, bucket=None):
        tests = [(name, value) for name, value in
                 (('provider_id', provider_id), ('catalog_id', catalog_id), ('bucket', bucket)) if value]
        where = ''.join(' AND %s = ?' % name for name, _ in tests)
        return self._rows('SELECT * FROM catalog_sync WHERE 1=1%s ORDER BY last_sync DESC' % where,
                          [value for _, value in tests])

    def section(self, bucket, sort='release_date', media_type=None, genre=None, year=None, language=None,
                limit=80, offset=0):
        """A Home section's titles, each with the catalog that lists it highest
        (best_provider_id / best_catalog_id / best_priority) - so playing it asks that add-on.
        8.1: "Last added" works (the order needs each source's last_seen)."""
        column, direction = ORDERS.get((sort or '').lower(), ORDERS['release_date'])
        tests, args = [], [bucket]
        if media_type:
            tests.append('i.type = ?')
            args.append(media_type)
        if genre:
            tests.append('i.genres LIKE ?')
            args.append('%"' + genre + '"%')
        if year:
            try:
                args.append(int(year))
                tests.append('i.year = ?')
            except (TypeError, ValueError):
                pass
        if language:
            tests.append('i.language = ?')
            args.append(language)
        sql = ('SELECT i.*, s.provider_id AS best_provider_id, s.catalog_id AS best_catalog_id, '
               's.priority AS best_priority FROM items i JOIN (SELECT item_id, provider_id, catalog_id, priority, last_seen, '
               'ROW_NUMBER() OVER (PARTITION BY item_id ORDER BY priority ASC, last_seen DESC) AS rn '
               'FROM item_sources WHERE bucket = ?) s ON s.item_id = i.id AND s.rn = 1 WHERE %s ORDER BY %s %s '
               'LIMIT ? OFFSET ?' % (' AND '.join(['1=1'] + tests), column, direction))
        return self._rows(sql, args + [int(limit), int(offset)])

    def section_size(self, bucket, media_type=None):
        sql = ('SELECT COUNT(DISTINCT i.id) AS n FROM items i JOIN item_sources s ON s.item_id = i.id '
               'WHERE s.bucket = ?')
        args = [bucket]
        if media_type:
            sql += ' AND i.type = ?'
            args.append(media_type)
        row = self.conn.execute(sql, args).fetchone()
        return int(row['n']) if row else 0

    def find(self, query, media_type=None, limit=80):
        """Titles whose name, description or genres start with the typed words (best first);
        a plain name search when the full-text search refuses the words."""
        words = ' '.join(word + '*' for word in str(query or '').strip().replace('"', '""').split())
        if not words:
            return []
        sql = ('SELECT i.*, bm25(%s) AS score FROM %s JOIN items i ON i.rowid = %s.rowid WHERE %s MATCH ?'
               % ((SEARCH_TABLE,) * 4))
        args = [words]
        if media_type:
            sql += ' AND i.type = ?'
            args.append(media_type)
        try:
            return self._rows(sql + ' ORDER BY score LIMIT ?', args + [int(limit)])
        except sqlite3.OperationalError:
            sql, args = 'SELECT * FROM items WHERE title_norm LIKE ?', ['%' + query.lower() + '%']
            if media_type:
                sql += ' AND type = ?'
                args.append(media_type)
            return self._rows(sql + ' ORDER BY rating DESC LIMIT ?', args + [int(limit)])

    def summary(self):
        count = lambda sql: self.conn.execute(sql).fetchone()[0]   # noqa: E731
        return {
            'items': int(count('SELECT COUNT(*) FROM items') or 0),
            'sources': int(count('SELECT COUNT(*) FROM item_sources') or 0),
            'catalogs': int(count('SELECT COUNT(*) FROM catalog_sync') or 0),
            'last_sync': int(count('SELECT MAX(last_sync) FROM catalog_sync') or 0),
            'db_size': os.path.getsize(self._path) if os.path.exists(self._path) else 0,
        }
