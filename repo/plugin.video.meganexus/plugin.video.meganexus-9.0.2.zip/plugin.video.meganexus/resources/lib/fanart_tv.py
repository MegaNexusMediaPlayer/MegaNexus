# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Pictures from fanart.tv: poster (also a textless one), logo, clear art, banner, disc,
landscape, background and (shows) character art.

Films are asked by TMDB or IMDb id, shows by TVDB id (else TMDB / IMDb). Of each kind the
picture in the interface language wins, then English, then the most liked. Answers are
kept in fanarttv_cache.db for 14 days (6 hours when fanart.tv has nothing) and an hour in
memory; every connection is closed, a failed write rolled back. At most five requests run
at once. The user's own key is used when set (Settings), else the public project key."""
import json
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.request

import xbmcaddon

from .hub_log import log
from .meganexus.paths import profile_path

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

PROJECT_KEY = 'fcca59bee130b70db37ee43e63f8d6c1'
KEEP_FOUND = 14 * 86400
KEEP_EMPTY = 6 * 3600
KEEP_IN_MEMORY = 3600
MEMORY_MOST = 600
PAYLOAD_VERSION = 2               # 7.0.29: posters too
DB_PATH = os.path.join(profile_path(), 'fanarttv_cache.db')
SHOW_TYPES = ('series', 'show', 'tv', 'tvshow', 'anime')
TEXTLESS = '00'                   # fanart.tv's language of a picture without text
# our field <- fanart.tv's lists (the first that holds pictures), for films and shows
FIELDS = {
    'movie': (('poster', ('movieposter',)), ('clearart', ('hdmovieclearart', 'movieart')),
              ('clearlogo', ('hdmovielogo', 'movielogo')), ('banner', ('moviebanner',)), ('discart', ('moviedisc',)),
              ('landscape', ('moviethumb',)), ('fanart', ('moviebackground',))),
    'tv': (('poster', ('tvposter',)), ('clearart', ('hdclearart', 'clearart')), ('clearlogo', ('hdtvlogo', 'clearlogo')),
           ('banner', ('tvbanner',)), ('landscape', ('tvthumb',)), ('fanart', ('showbackground',)),
           ('characterart', ('characterart',))),
}

_lock = threading.Lock()
_made = [False]
_memory = {}                      # 'kind|id' -> (until, payload)
_memory_lock = threading.Lock()
_turns = threading.Semaphore(5)


def _open():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    try:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
    except Exception:
        pass
    return conn


def _ready():
    if _made[0]:
        return True
    with _lock:
        if not _made[0]:
            try:
                os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
                conn = _open()
                try:
                    conn.execute('CREATE TABLE IF NOT EXISTS fanart (media_type TEXT NOT NULL, art_id TEXT NOT NULL, '
                                 'payload TEXT NOT NULL, expires_at INTEGER NOT NULL, PRIMARY KEY (media_type, art_id))')
                    conn.commit()
                finally:
                    conn.close()
                _made[0] = True
            except Exception as exc:
                log.warn('FANART', 'fanarttv_cache init failed: %s', exc)
    return _made[0]


def _setting(name, default=''):
    try:
        return (ADDON.getSetting(name) or default).strip()
    except Exception:
        return default


def _enabled():
    try:
        return ADDON.getSettingBool('fanarttv_enrich')
    except Exception:
        return True


def _language():
    try:
        from .texts import current_language
        return current_language() or 'en'
    except Exception:
        return 'en'


def _remembered(key, now):
    with _memory_lock:
        kept = _memory.get(key)
        if kept and kept[0] < now:
            _memory.pop(key, None)
            kept = None
        return kept[1] if kept else None


def _remember(key, payload, until):
    with _memory_lock:
        _memory[key] = (until, payload)
        if len(_memory) > MEMORY_MOST:
            for old in list(_memory)[:60]:
                _memory.pop(old, None)


def _stored(kind, ident, now):
    if not _ready():
        return None
    try:
        conn = _open()
        try:
            row = conn.execute('SELECT payload, expires_at FROM fanart WHERE media_type=? AND art_id=?',
                               (kind, ident)).fetchone()
        finally:
            conn.close()
        return json.loads(row[0]) if row and row[1] >= now else None
    except Exception:
        return None


def _store(kind, ident, payload, until):
    if not _ready():
        return
    try:
        conn = _open()
        try:
            conn.execute('INSERT OR REPLACE INTO fanart (media_type, art_id, payload, expires_at) VALUES (?, ?, ?, ?)',
                         (kind, ident, json.dumps(payload, ensure_ascii=False), until))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    except Exception as exc:
        log.warn('FANART', 'fanarttv_cache put failed: %s', exc)


def _ask(url, timeout=8):
    """fanart.tv's answer; {} when it knows nothing (404), None when it could not be asked."""
    with _turns:
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'MegaNexus/8'}),
                                        timeout=timeout) as answer:
                if answer.status >= 400:
                    return None
                return json.loads(answer.read().decode('utf-8', errors='replace'))
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                return {}
            log.warn('FANART', 'http %s for %s', exc.code, url)
        except Exception as exc:
            log.warn('FANART', 'fetch %s failed: %s', url, exc)
    return None


def _best(pictures, language):
    """The picture in `language` first, else English, then the most liked; '' for none."""
    if not isinstance(pictures, list) or not pictures:
        return ''

    def rank(picture):
        lang = str(picture.get('lang', '') or '').lower()
        try:
            likes = int(picture.get('likes', 0) or 0)
        except Exception:
            likes = 0
        bonus = 1000 if language and lang == language else 0
        if language and language != 'en' and lang == 'en':
            bonus = 500
        return bonus + likes
    return str(max(pictures, key=rank, default={}).get('url', '') or '') if pictures else ''


def _pictures(answer, kind, language):
    if not isinstance(answer, dict):
        return {}
    found = {}
    for field, lists in FIELDS[kind]:
        found[field] = _best(next((answer.get(name) for name in lists if answer.get(name)), None), language)
    posters = answer.get('movieposter' if kind == 'movie' else 'tvposter')
    found['poster_textless'] = _best([p for p in posters if str((p or {}).get('lang') or '') == TEXTLESS], '') \
        if isinstance(posters, list) else ''
    return dict((field, value) for field, value in found.items() if value)


def _public(payload):
    return dict((key, value) for key, value in payload.items() if not key.startswith('_'))


def get_art(media_type, tmdb_id='', tvdb_id='', imdb_id='', cached_only=False, force=False):
    """The title's fanart.tv pictures ({} when none or switched off; None with `cached_only`
    when nothing is kept)."""
    if not (force or _enabled()):
        return {}
    kind = 'tv' if (media_type or '').lower() in SHOW_TYPES else 'movie'
    ident = str((tvdb_id or tmdb_id or imdb_id) if kind == 'tv' else (tmdb_id or imdb_id) or '').strip()
    if not ident:
        return {}
    now = int(time.time())
    key = '%s|%s' % (kind, ident)
    kept = _remembered(key, now)
    if kept is not None and kept.get('_v') == PAYLOAD_VERSION:
        return _public(kept)
    if cached_only == 'memory':
        return None            # 8.1.3: a screen being drawn never opens this file
    kept = _stored(kind, ident, now)
    if kept is not None and kept.get('_v') == PAYLOAD_VERSION:
        _remember(key, kept, now + KEEP_IN_MEMORY)
        return _public(kept)
    if cached_only:
        return None
    answer = _ask('https://webservice.fanart.tv/v3/%s/%s?api_key=%s' % ('tv' if kind == 'tv' else 'movies', ident,
                                                                         _setting('fanarttv_api_key') or PROJECT_KEY))
    if answer is None:
        return {}
    payload = dict(_pictures(answer, kind, _language()), _v=PAYLOAD_VERSION)
    until = now + (KEEP_FOUND if len(payload) > 1 else KEEP_EMPTY)
    _store(kind, ident, payload, until)
    _remember(key, payload, min(now + KEEP_IN_MEMORY, until))
    return _public(payload)


def fill_meta(meta, media_type, tmdb_id='', tvdb_id='', imdb_id=''):
    """The item's empty picture fields filled from fanart.tv (changes and returns meta)."""
    if not isinstance(meta, dict):
        return meta
    for key, value in (get_art(media_type, tmdb_id=tmdb_id, tvdb_id=tvdb_id, imdb_id=imdb_id) or {}).items():
        if value and not meta.get(key):
            meta[key] = value
    return meta


def purge_expired():
    """Expired rows dropped (service start); how many."""
    if not _ready():
        return 0
    try:
        conn = _open()
        try:
            gone = conn.execute('DELETE FROM fanart WHERE expires_at < ?', (int(time.time()),)).rowcount or 0
            conn.commit()
        finally:
            conn.close()
        return gone
    except Exception:
        return 0
