# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A shared Nuvio setup (a JSON file or link): its add-ons and its collections.

Every Stremio manifest address found anywhere in the file (add-on lists, profiles, config
blocks) is installed unless the same address is installed already; the collections go
through shared_collections. What was taken and when is kept in nuvio_sync_state.json."""
import json
import os
import time

from . import shared_collections
from .meganexus import addon_registry
from .meganexus.addon_wire import manifest_ok
from .meganexus.paths import profile_path
from .meganexus.json_files import write_json

STATE_FILE = os.path.join(profile_path(), 'nuvio_sync_state.json')
ADDRESS_FIELDS = ('manifest_url', 'manifestUrl', 'manifestURL', 'transportUrl', 'url')
LIST_FIELDS = ('addons', 'providers', 'manifests', 'stremioAddons', 'installedAddons', 'sources')
NESTED_FIELDS = ('profile', 'config', 'setup', 'data', 'payload')


def state():
    try:
        with open(STATE_FILE, 'r', encoding='utf-8') as handle:
            kept = json.load(handle)
    except Exception:
        kept = {}
    kept = kept if isinstance(kept, dict) else {}
    for key, empty in (('sync_url', ''), ('last_sync', 0), ('last_imported_providers', 0),
                       ('last_imported_collections', 0)):
        kept.setdefault(key, empty)
    return kept


def set_sync_url(url):
    kept = state()
    kept['sync_url'] = str(url or '').strip()
    write_json(STATE_FILE, kept)
    return kept


def manifest_addresses(data):
    """Every distinct http(s) manifest address in the file, in the order found."""
    found = []

    def take(value):
        value = str(value or '').strip()
        if value.startswith(('http://', 'https://')) and 'manifest' in value.lower() and value not in found:
            found.append(value)

    def walk(node):
        if isinstance(node, str):
            take(node)
        elif isinstance(node, list):
            for item in node:
                walk(item)
        elif isinstance(node, dict):
            for field in ADDRESS_FIELDS:
                take(node.get(field))
            for field in LIST_FIELDS:
                if field in node:
                    walk(node[field])
            for field in NESTED_FIELDS:
                if isinstance(node.get(field), (dict, list)):
                    walk(node[field])
    walk(data)
    return found


def take_backup(raw, source_label='Nuvio Sync', manifest_resolver=None):
    """{providers, collections}: how many add-ons were installed and whether a collection set came."""
    data = json.loads(raw.decode('utf-8', 'replace') if isinstance(raw, bytes) else raw) \
        if isinstance(raw, (bytes, str)) else raw
    if not isinstance(data, (dict, list)):
        raise ValueError('Invalid sync file')
    installed = set(str(row.get('manifest_url') or '').rstrip('/') for row in addon_registry.list_providers() or [])
    added = 0
    for address in manifest_addresses(data):
        try:
            manifest = manifest_ok(address)
            if address.rstrip('/') not in installed:
                addon_registry.add_provider(manifest.get('name') or 'Stremio Addon', address, manifest)
                installed.add(address.rstrip('/'))
                added += 1
        except Exception:
            continue
    try:
        sets = data.get('collections') if isinstance(data, dict) else data
        collections = 1 if shared_collections.add_set_from_text(
            json.dumps(sets if sets is not None else data, ensure_ascii=False), source_label=source_label,
            manifest_resolver=manifest_resolver) else 0
    except Exception:
        collections = 0
    kept = state()
    kept.update(last_sync=int(time.time()), last_imported_providers=added, last_imported_collections=collections)
    write_json(STATE_FILE, kept)
    return {'providers': added, 'collections': collections}
