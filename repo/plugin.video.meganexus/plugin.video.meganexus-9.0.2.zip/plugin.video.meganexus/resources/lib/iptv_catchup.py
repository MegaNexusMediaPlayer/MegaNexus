# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Catch-up for any IPTV list (7.0.48).

IPTV Simple plays a channel's archive only when the playlist says how: catchup,
catchup-days, catchup-source (or the old timeshift / tvg-rec tags, which it reads
as "shift" catch-up - ?utc=... after the channel's link). Xtream playlists
(get.php) mostly carry nothing of it, or a timeshift="2" the server does not
answer that way (seen 16.10.2026: 92 of 1138 channels, the archive answered only
at /timeshift/...); their links may not be the /live/<user>/<pass>/<id> form
IPTV Simple's own Xtream mode needs (/play/<code>/<n>).

For an Xtream list MegaNexus asks the server itself which streams keep an archive
and how many days (player_api.php get_live_streams: tv_archive,
tv_archive_duration) and writes each channel's catch-up into the channel file
IPTV Simple reads: the server's /timeshift/ link, the days, and the hours between
this device's clock and the server's (IPTV Simple writes the start time in the
device's local time, the server reads it in its own). As catchup="vod" and the
programme as one .ts file: the server sends it whole, with its length, and answers
byte ranges - Kodi's own player plays it like a film and seeks in it exactly.
Through IPTV Simple's timeshifting catch-up (inputstream.ffmpegdirect) a seek on
this server's streams lost the time and the sound (seek distance -349094958 s,
audio sync error 1.8e19); its .m3u8 (inputstream.adaptive) counted as live, a seek
went to the next whole minute (16.10.2026). And through IPTV Simple Kodi does not seek
in it at all (the add-on has no CanSeekStream): MegaNexus plays a programme of such a
channel itself, as a file in Kodi's player (programme_url, from the list's small
private index - index()), and the tags keep the guide's catch-up (what can play). Channels the server keeps
no archive for lose catch-up tags it would not answer. Other lists keep their
tags as they were. A failed question changes nothing.
"""
import calendar
import json
import re
import time
from urllib.parse import parse_qs, quote, urlencode, urlsplit
from urllib.request import Request, urlopen

TIMEOUT = 30
TAGS = re.compile(r'\s+(?:catchup|catchup-days|catchup-source|catchup-correction|catchup-type|timeshift|tvg-rec)="[^"]*"', re.I)
ATTR = re.compile(r'([A-Za-z][\w-]*)="([^"]*)"')
OWN = re.compile(r'\b(?:catchup|catchup-days|timeshift|tvg-rec)="\s*[^"0\s][^"]*"', re.I)
EXTINF = re.compile(r'^(\s*#EXTINF:\s*-?\d+(?:\.\d+)?)', re.I)


def xtream_account(m3u):
    """(server, username, password) of an Xtream playlist link (.../get.php?username=&password=)."""
    parts = urlsplit(m3u or '')
    if parts.scheme not in ('http', 'https') or not parts.path.lower().endswith('get.php'):
        return None
    query = parse_qs(parts.query)
    user = (query.get('username') or [''])[0]
    password = (query.get('password') or [''])[0]
    if not user or not password:
        return None
    return '%s://%s' % (parts.scheme, parts.netloc), user, password


def server_offset(info):
    """The server's offset from UTC in seconds (its clock and its timestamp), to the quarter hour."""
    try:
        local = calendar.timegm(time.strptime(str(info['time_now']), '%Y-%m-%d %H:%M:%S'))
        return int(round((local - int(info['timestamp_now'])) / 900.0)) * 900
    except (KeyError, TypeError, ValueError):
        return None


def local_offset(now=None):
    stamp = time.time() if now is None else now
    return calendar.timegm(time.localtime(stamp)) - int(stamp)


def _name(text):
    return ' '.join(str(text or '').casefold().split())


channel_key = _name     # how a channel's name is kept in index()


def channel_name(line):
    """The channel's name: tvg-name, else after the last comma of #EXTINF."""
    attrs = dict(ATTR.findall(line))
    return attrs.get('tvg-name') or line.rsplit(',', 1)[-1]


def has_catchup(block):
    """The playlist itself gives this channel catch-up (any list)."""
    return any(line.lstrip().upper().startswith('#EXTINF') and OWN.search(line) for line in block)


class Xtream:
    """The archive of an Xtream server's channels, asked once per list build."""

    def __init__(self, account, opener=None, now=None):
        self.base, self.user, self.password = account
        self.opener = opener
        self.days = {}            # stream id -> days of archive (0: none)
        self.names = {}           # stream id -> name
        self.by_name = {}         # name -> [stream ids]
        self.correction = 0.0     # hours: this device's clock minus the server's
        self.offset = None        # the server's offset from UTC in seconds
        self.marked = {}          # channel name -> [stream id, days] (index())
        self.now = now

    def _get(self, extra=''):
        url = '%s/player_api.php?%s%s' % (self.base, urlencode({'username': self.user, 'password': self.password}), extra)
        request = Request(url, headers={'User-Agent': 'MegaNexus/7'})
        with (self.opener or (lambda r: urlopen(r, timeout=TIMEOUT)))(request) as response:
            return json.loads(response.read().decode('utf-8', 'replace'))

    def load(self):
        info = self._get()
        if not isinstance(info, dict) or str((info.get('user_info') or {}).get('auth')) != '1':
            raise ValueError('the server did not accept the login')
        streams = self._get('&action=get_live_streams')
        if not isinstance(streams, list):
            raise ValueError('no channel list from the server')
        for stream in streams:
            if not isinstance(stream, dict) or stream.get('stream_id') in (None, ''):
                continue
            sid = str(stream['stream_id'])
            try:
                days = int(float(stream.get('tv_archive_duration') or 0)) if str(stream.get('tv_archive')) == '1' else 0
            except (TypeError, ValueError):
                days = 0
            self.days[sid] = max(0, days)
            self.names[sid] = stream.get('name') or ''
            self.by_name.setdefault(_name(stream.get('name')), []).append(sid)
        offset = server_offset(info.get('server_info') or {})
        self.offset = offset
        if offset is not None:
            self.correction = (local_offset(self.now) - offset) / 3600.0
        return self

    def stream_id(self, line, url):
        """Which of the server's streams a playlist channel is."""
        parts = urlsplit(url).path.rstrip('/').split('/')
        last = parts[-1].split('.', 1)[0]
        if last.isdigit() and last in self.days and self.user in parts and self.password in parts:
            return last                                   # /live/<user>/<pass>/<id>.ts, /<user>/<pass>/<id>
        name = _name(channel_name(line))
        for _, value in ATTR.findall(line):              # other panels: an attribute holding the stream id
            if value.isdigit() and value in self.days and _name(self.names[value]) == name:
                return value
        found = self.by_name.get(name) or []
        return found[0] if len(found) == 1 else None

    def source(self, sid):
        return '%s/timeshift/%s/%s/{duration:60}/{Y}-{m}-{d}:{H}-{M}/%s.ts' % (
            self.base, quote(self.user, safe=''), quote(self.password, safe=''), sid)

    def mark(self, block, url):
        """The channel's lines with its catch-up as the server keeps it -> (lines, days or None)."""
        for index, line in enumerate(block):
            if not line.lstrip().upper().startswith('#EXTINF'):
                continue
            sid = self.stream_id(line, url)
            if sid is None:
                return block, None                       # not known to the server: as it was
            days = self.days[sid]
            line = TAGS.sub('', line)
            if days > 0:
                for name in {_name(line.rsplit(',', 1)[-1]), _name(channel_name(line))} - {''}:
                    self.marked[name] = [sid, days]
                tags = ' catchup="vod" catchup-days="%d" catchup-source="%s"' % (days, self.source(sid))
                if abs(self.correction) >= 0.01:
                    tags += ' catchup-correction="%g"' % round(self.correction, 2)
                line = EXTINF.sub(lambda match: match.group(1) + tags, line, count=1)
            return block[:index] + [line] + block[index + 1:], days
        return block, None


    def index(self):
        """What MegaNexus needs to play a programme itself (kept private, like the playlist)."""
        return {'server': self.base, 'username': self.user, 'password': self.password,
                'offset': self.offset, 'channels': self.marked}


def programme_url(index, name, start, end):
    """The programme as one file from the server (start / end: UTC seconds), or ''.
    The server reads the start in its own time zone, in whole minutes."""
    found = (index or {}).get('channels', {}).get(_name(name))
    if not found or index.get('offset') is None or end <= start:
        return ''
    begin = time.strftime('%Y-%m-%d:%H-%M', time.gmtime(int(start) + int(index['offset'])))
    minutes = int((end - start + 59) // 60)
    return '%s/timeshift/%s/%s/%d/%s/%s.ts' % (index['server'], quote(index['username'], safe=''),
                                                 quote(index['password'], safe=''), minutes, begin, found[0])


def for_list(m3u, opener=None, log=None):
    """The Xtream helper of a list, or None (another kind of list, or the server did not answer)."""
    account = xtream_account(m3u)
    if account is None:
        return None
    try:
        return Xtream(account, opener).load()
    except Exception as exc:
        if log:
            code = getattr(exc, 'code', None)
            log('[MegaNexus] IPTV catch-up not asked: %s' % ('HTTP %s' % code if code else type(exc).__name__))
        return None
