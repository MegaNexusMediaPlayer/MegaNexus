# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Watch Party playback sync: where everyone should be, and when to do something about it.

The host's player is the reference. Its state - paused, position, when it was taken (its
clock), an event number - goes to the party on every change and every few seconds.

7.0.55: guests follow EVENTS, not the clock. An event is something the host did: the film
started, play, pause, a jump. Then each guest pauses / plays / jumps to the host. Between
events everyone plays at their own pace - a box at 24 fps and one at 60 drift a little, and
seeking them back every few seconds was a film that kept stopping; a few seconds apart is
fine. Only a guest DRIFT_MAX_MS away (a long buffering) is moved once.

Clocks: devices keep NTP time; the offset measured with ping / pong corrects what is left.
"""
SEEK_AFTER_MS = 3000          # on an event: a guest this far from the host jumps to it
DRIFT_MAX_MS = 30000          # between events: only a guest this far away is moved (a long buffering)
# 7.0.61: was 5 s - with every TV of a household behind one address, relay.damus.io banned it for
# "too many rate-limit violations"; the guests follow events, this only keeps a late one in line
STATE_EVERY = 15.0            # s between the host's state messages while nothing changes
STALE_AFTER_MS = 20000        # a state older than this (host gone quiet) is not followed
START_WAIT = 45.0             # s the host waits, paused at the start, for the guests' films


def expected_position(state, now_ms):
    """Where the host's player is at ``now_ms`` (our clock, offset already applied)."""
    position = int(state.get('pos') or 0)
    if not state.get('paused'):
        position += max(0, now_ms - int(state.get('at') or now_ms))
    duration = int(state.get('dur') or 0)
    position = max(0, position)
    return min(position, duration) if duration else position


def newer(candidate, current):
    if current is None:
        return True
    if int(candidate.get('seq') or 0) != int(current.get('seq') or 0):
        return int(candidate.get('seq') or 0) > int(current.get('seq') or 0)
    return str(candidate.get('from') or '') > str(current.get('from') or '')


def correction(local_ms, local_paused, state, now_ms, event=True):
    """What a guest's player does: None, ('seek', ms), ('pause', ms or None) or ('play', ms or None).
    ``event``: the host did something since the guest last followed (or the guest's film just
    started) - follow it; else only a long way off (DRIFT_MAX_MS) is corrected."""
    if now_ms - int(state.get('at') or now_ms) > STALE_AFTER_MS and not state.get('paused'):
        return None
    target = expected_position(state, now_ms)
    away = abs(local_ms - target)
    if not event:
        if not state.get('paused') and not local_paused and away > DRIFT_MAX_MS:
            return ('seek', target)
        return None
    jump = target if away > SEEK_AFTER_MS else None
    if state.get('paused') and not local_paused:
        return ('pause', jump)
    if not state.get('paused') and local_paused:
        return ('play', jump)
    if jump is not None:
        return ('seek', jump)
    return None


def clock_offset(sent_ms, peer_ms, received_ms):
    """Our clock minus the peer's, from one ping (sent / received on ours, the peer's in between)."""
    return (sent_ms + received_ms) // 2 - peer_ms


class Offsets(object):
    """The best (shortest round trip) offset per peer."""

    def __init__(self):
        self.best = {}

    def add(self, peer, sent_ms, peer_ms, received_ms):
        trip = received_ms - sent_ms
        if trip < 0:
            return
        if peer not in self.best or trip < self.best[peer][0]:
            self.best[peer] = (trip, clock_offset(sent_ms, peer_ms, received_ms))

    def of(self, peer):
        return self.best.get(peer, (0, 0))[1]
