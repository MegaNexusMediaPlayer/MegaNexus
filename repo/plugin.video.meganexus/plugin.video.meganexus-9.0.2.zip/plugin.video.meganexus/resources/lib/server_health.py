# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""How the user's Plex / Jellyfin / Emby servers have been answering (server_health.json).

Each server keeps its answer time (a running average), failures in a row and whether its
last search found anything. A failing server rests 15 s, 30 s, 60 s, then 120 s after
each further failure; one answer clears it. Media servers are asked fastest-first: not
resting, fewest failures, last search with results, shortest answer time. At most 64
servers are kept (the most recently seen)."""
import json
import os
import threading
import time

try:
    import xbmcvfs
    _FOLDER = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/')
except Exception:
    _FOLDER = ''
FILE = os.path.join(_FOLDER, 'server_health.json') if _FOLDER else ''
MOST = 64
REST_FIRST, REST_MOST = 15, 120
NEW_WEIGHT = 0.3                         # weight of the newest answer time in the average

_lock = threading.RLock()
_rows = [None]


def server_key(backend, server):
    server = server or {}
    name = (server.get('id') or server.get('machine_id') or server.get('server_id') or server.get('url')
            or server.get('name') or 'unknown')
    return '%s:%s' % (str(backend or 'server').lower(), str(name))


def _all():
    with _lock:
        if _rows[0] is None:
            try:
                with open(FILE, 'r', encoding='utf-8') as handle:
                    kept = json.load(handle)
                _rows[0] = kept if isinstance(kept, dict) else {}
            except Exception:
                _rows[0] = {}
        return _rows[0]


def _write(rows):
    if not FILE:
        return
    try:
        if len(rows) > MOST:
            rows = dict(sorted(rows.items(), key=lambda item: float((item[1] or {}).get('last_seen') or 0),
                               reverse=True)[:MOST])
            _rows[0] = rows
        os.makedirs(os.path.dirname(FILE), exist_ok=True)
        with open(FILE + '.tmp', 'w', encoding='utf-8') as handle:
            json.dump(rows, handle, ensure_ascii=False, separators=(',', ':'))
        os.replace(FILE + '.tmp', FILE)
    except Exception:
        pass


def should_query(backend, server, now=None):
    """Not resting."""
    row = _all().get(server_key(backend, server)) or {}
    return float(row.get('cooldown_until') or 0) <= float(now or time.time())


def note_answer(backend, server, elapsed, success, result_count=0):
    now = time.time()
    key = server_key(backend, server)
    with _lock:
        rows = _all()
        row = dict(rows.get(key) or {})
        took, average = max(1.0, float(elapsed or 0) * 1000.0), float(row.get('latency_ms') or 0)
        row.update(latency_ms=round(took if average <= 0 else average * (1 - NEW_WEIGHT) + took * NEW_WEIGHT, 1),
                   last_seen=now)
        if success:
            row.update(successes=int(row.get('successes') or 0) + 1, failures=0, last_success=now, cooldown_until=0,
                       last_results=int(result_count or 0))
        else:
            failures = int(row.get('failures') or 0) + 1
            row.update(failures=failures, cooldown_until=now + min(REST_MOST, REST_FIRST * 2 ** min(failures - 1, 3)))
        rows[key] = row
        _write(rows)


def score(backend, server):
    """The sort key (lower = asked first)."""
    row = _all().get(server_key(backend, server)) or {}
    return (1 if float(row.get('cooldown_until') or 0) > time.time() else 0, int(row.get('failures') or 0),
            0 if int(row.get('last_results') or 0) > 0 else 1, float(row.get('latency_ms') or 1500))


def servers_fastest_first(targets):
    """Add-on targets first as they are, media servers fastest-first."""
    backends = {'__plex__': 'plex', '__emby__': 'emby'}

    def key(target):
        provider = (target or ({}, ''))[0] or {}
        backend = backends.get(provider.get('id'))
        return score(backend, provider.get('_server') or {}) if backend else (0, 0, 0, 0)
    return sorted(list(targets or []), key=key)
