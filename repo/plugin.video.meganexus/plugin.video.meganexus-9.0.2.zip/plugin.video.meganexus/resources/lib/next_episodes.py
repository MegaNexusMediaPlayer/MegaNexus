# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Next Up: the next episode of every series the user is watching.

Trakt's own Next Up comes first; then, from the local playback history, each recently
watched show (latest episode at least 70 % played, or marked watched) gets the episode
after it - the next one of the season, else the first of the next season - from the
show's episode list (kept an hour per show in Home window properties).

The list is kept in a Home window property and in nextup_cache.json: 10 minutes fresh;
up to 6 hours it is shown at once and rebuilt in the background; older, it is rebuilt now."""
import json
import os
import time

import xbmc

LIST_KEY = 'meganexus.nextup_cache'
LIST_TIME_KEY = 'meganexus.nextup_cache_ts'
SHOW_LIFE = 3600
FRESH = 600
SHOWN_STALE = 6 * 3600
WATCHED_SHARE = 70.0
SERIES_TYPES = ['series', 'anime', 'tv', 'show']


def _file():
    try:
        from .meganexus.paths import profile_path
        return os.path.join(profile_path(), 'nextup_cache.json')
    except Exception:
        return ''


def _from_file():
    try:
        with open(_file(), 'r', encoding='utf-8') as handle:
            kept = json.load(handle)
        if isinstance(kept, dict) and isinstance(kept.get('items'), list) and int(kept.get('ts') or 0):
            return kept['items'], int(kept['ts'])
    except Exception:
        pass
    return None, 0


def _keep(window, rows):
    """The list into the window property and the file, stamped now."""
    try:
        window.setProperty(LIST_KEY, json.dumps(rows))
        window.setProperty(LIST_TIME_KEY, str(int(time.time())))
        from .meganexus.json_files import write_json
        if _file():
            write_json(_file(), {'ts': int(time.time()), 'items': rows or []})
    except Exception:
        pass


def invalidate_nextup_cache(window):
    for key in (LIST_KEY, LIST_TIME_KEY):
        try:
            window.clearProperty(key)
        except Exception:
            pass
    try:
        if _file() and os.path.exists(_file()):
            os.remove(_file())
    except Exception:
        pass


def show_videos_kept(canonical_id, *, window, prop_prefix, provider_order_for_id, fetch_meta, fast_timeout_value,
                         item_fallback_art, resolve_meta_art, provider_prefers_native_art,
                         media_type='series', title=''):
    """A show's episode list from the first add-on that has it (an hour per show); its
    pictures and title are kept beside it for the Next Up cards."""
    canonical_id = str(canonical_id or '').strip()
    if not canonical_id:
        return []
    key = prop_prefix + canonical_id
    kind = media_type or 'series'
    try:
        when = int(window.getProperty(key + '.ts') or '0')
    except Exception:
        when = 0
    if when and time.time() - when <= SHOW_LIFE:
        try:
            kept = json.loads(window.getProperty(key) or 'null')
            if isinstance(kept, list) and kept:
                return kept
        except Exception:
            pass
    meta = None
    for provider in provider_order_for_id(kind, canonical_id):
        try:
            answer = fetch_meta(provider, kind, canonical_id, timeout_override=fast_timeout_value) or {}
            found = answer.get('meta') or answer.get('metas')
            found = (found[0] if found else None) if isinstance(found, list) else found
            if not (found and found.get('videos')):
                continue
            meta = found
            try:
                art = resolve_meta_art(provider, kind, found, fallback_art=item_fallback_art(provider, kind))
                window.setProperty(key + '.art', json.dumps(art))
                window.setProperty(key + '.native_art', '1' if provider_prefers_native_art(provider) else '0')
            except Exception:
                pass
            break
        except Exception:
            continue
    if not meta:
        return []
    videos = meta.get('videos') or []
    try:
        for suffix, value in (('', json.dumps(videos)), ('.ts', str(int(time.time()))),
                              ('.title', title or meta.get('name') or canonical_id), ('.media_type', kind)):
            window.setProperty(key + suffix, value)
    except Exception:
        pass
    return videos


def _episode(videos, season, number):
    for video in videos:
        try:
            if int(video.get('season') or 0) == season and int(video.get('episode') or 0) == number:
                return video
        except Exception:
            continue
    return None


def _following(videos, season, number):
    """(season, episode, video) after the given one: the season's next, else the next season's first."""
    for place in ((season, number + 1), (season + 1, 1)):
        found = _episode(videos, *place)
        if found:
            return place[0], place[1], found
    return None


def _build(limit, trakt_mod, playback_store_mod, series_videos_loader, log_prefix='[MegaNexus]'):
    rows, seen = [], set()
    try:
        for row in trakt_mod.next_up_rows(limit=limit) or []:
            key = (row.get('canonical_id') or '', row.get('season') or 0, row.get('episode') or 0)
            if key not in seen:
                seen.add(key)
                rows.append(row)
    except Exception as exc:
        xbmc.log('%s nextup trakt fetch failed: %s' % (log_prefix, exc), xbmc.LOGDEBUG)
    try:
        history = playback_store_mod.list_recent_items(limit=max(40, min(120, limit * 2)), media_types=SERIES_TYPES,
                                                       include_watched=True) or []
    except Exception:
        history = []
    latest = {}                                   # show -> its most recent playback
    for row in history:
        try:
            show = row.get('canonical_id') or ''
            if show and show not in latest:
                latest[show] = row
                if len(latest) >= max(40, min(80, limit)):
                    break
        except Exception:
            continue
    for show, row in latest.items():
        try:
            kind = (row.get('media_type') or '').lower() or 'series'
            if float(row.get('percent') or 0.0) < WATCHED_SHARE and str(row.get('event_type') or '').lower() != 'watched':
                continue
            season, number = int(row.get('season') or 0), int(row.get('episode') or 0)
            if season <= 0 or number <= 0:
                continue
            following = _following(series_videos_loader(show, media_type=kind, title=row.get('title') or show),
                                   season, number)
            if not following or (show,) + following[:2] in seen:
                continue
            season, number, video = following
            seen.add((show, season, number))
            rows.append({'media_type': kind or 'series', 'canonical_id': show, 'video_id': video.get('id') or show,
                         'title': row.get('title') or show, 'episode_title': video.get('title') or '',
                         'season': season, 'episode': number, 'plot': video.get('overview') or '',
                         'poster': row.get('poster') or '', 'background': row.get('background') or '',
                         'clearlogo': row.get('clearlogo') or '', 'provider_name': row.get('provider_name') or '',
                         'last_watched_at': int(row.get('updated_at') or 0)})
            if len(rows) >= limit:
                break
        except Exception:
            continue
    return sorted(rows, key=lambda row: int(row.get('last_watched_at') or 0), reverse=True)[:limit]


def nextup_items_cached(limit=40, *, window, trakt_mod, playback_store_mod, series_videos_loader, log_prefix='[MegaNexus]'):
    """The Next Up rows: kept ones while fresh, kept ones and a background rebuild while
    only stale, else built now."""
    try:
        when = int(window.getProperty(LIST_TIME_KEY) or '0')
    except Exception:
        when = 0
    kept = None
    if when:
        try:
            kept = json.loads(window.getProperty(LIST_KEY) or 'null')
            kept = kept if isinstance(kept, list) else None
        except Exception:
            kept = None
    if kept is None:
        kept, when = _from_file()
        if kept is not None:
            try:
                window.setProperty(LIST_KEY, json.dumps(kept))
                window.setProperty(LIST_TIME_KEY, str(when))
            except Exception:
                pass
    age = time.time() - when if when else 999999

    def build():
        return _build(limit, trakt_mod, playback_store_mod, series_videos_loader, log_prefix=log_prefix)
    if kept is not None and age <= FRESH:
        return kept[:limit]
    if kept is not None and age <= SHOWN_STALE:
        def again():
            try:
                _keep(window, build())
            except Exception as exc:
                xbmc.log('%s nextup refresh failed: %s' % (log_prefix, exc), xbmc.LOGDEBUG)
        try:
            from .side_jobs import maybe_run
            maybe_run(again, key='nextup-cache-refresh')
        except Exception:
            pass
        return kept[:limit]
    rows = build()
    _keep(window, rows)
    return rows[:limit]
