# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Title details kept on the device (meta_cache.db): a page drawn again needs no add-on.

Two layers: this process's memory (MEMORY_KEEP entries, the oldest tenth goes when it is
full) and the file (survives Kodi). A detail lives as long as it is likely to stay true:

    movie two or more years old     LONG
    newer movie                     WEEK
    ended / cancelled series        LONG
    series with a next air date     until a day after it (at least a day)
    other series                    SHORT

The table keeps its name and columns; Fanart.tv's cache shares the file (its own table)."""
import json
import os
import sqlite3
import threading
import time
from collections import OrderedDict
from datetime import datetime

from .hub_log import log
from .meganexus.paths import profile_path

DB_PATH = os.path.join(profile_path(), 'meta_cache.db')
DAY = 86400
LONG, WEEK, SHORT = 180 * DAY, 7 * DAY, 4 * DAY
OLD_AFTER_YEARS = 2
SERIES = ('series', 'show', 'tv', 'tvshow', 'anime')
FINISHED = ('ended', 'canceled', 'cancelled')
NEXT_AIR_KEYS = ('next_episode_to_air', 'next_air', 'next_aired', 'next_episode_air')
MEMORY_KEEP = 800
IN_CLAUSE = 800        # ids per query (SQLite allows 999 parameters)
TABLE = ('CREATE TABLE IF NOT EXISTS meta (media_type TEXT NOT NULL, canonical_id TEXT NOT NULL, '
         "source_id TEXT NOT NULL DEFAULT 'auto', payload TEXT NOT NULL, created_at INTEGER NOT NULL, "
         'expires_at INTEGER NOT NULL, PRIMARY KEY (media_type, canonical_id, source_id))')
INDEX = 'CREATE INDEX IF NOT EXISTS idx_meta_expires ON meta(expires_at)'


def lifetime_end(media_type, payload, now):
    """When a detail stops being trusted (epoch seconds)."""
    if (media_type or '').lower() in SERIES:
        try:
            if str(payload.get('status') or '').strip().lower() in FINISHED:
                return now + LONG
            extra = payload.get('extra_info') or {}
            for key in NEXT_AIR_KEYS:
                day = (extra.get(key) if isinstance(extra, dict) else None) or (payload.get(key) if key in payload else None)
                if day:
                    try:
                        return max(now + DAY, int(datetime.strptime(str(day)[:10], '%Y-%m-%d').timestamp()) + DAY)
                    except Exception:
                        continue
        except Exception:
            pass
        return now + SHORT
    try:
        year = int(payload.get('year') or 0)
        if year and time.gmtime(now).tm_year - year >= OLD_AFTER_YEARS:
            return now + LONG
    except Exception:
        pass
    return now + WEEK


class _Memory(object):
    def __init__(self):
        self._items = OrderedDict()
        self._lock = threading.Lock()

    def get(self, key, now):
        with self._lock:
            found = self._items.get(key)
            if found and found[0] < now:
                del self._items[key]
                return None
            return found[1] if found else None

    def put(self, key, payload, until):
        with self._lock:
            self._items[key] = (until, payload)
            if len(self._items) > MEMORY_KEEP:
                for _ in range(int(MEMORY_KEEP * 0.1)):
                    self._items.popitem(last=False)

    def clear(self):
        with self._lock:
            self._items.clear()

    def __len__(self):
        return len(self._items)


_memory = _Memory()
_ready = {'done': False}
_opening = threading.Lock()


def _key(media_type, canonical_id, source_id='auto'):
    return '%s|%s|%s' % ((media_type or '').lower(), canonical_id or '', source_id or 'auto')


def _open():
    connection = sqlite3.connect(DB_PATH, timeout=2.0)
    try:
        for pragma in ('journal_mode=WAL', 'synchronous=NORMAL', 'temp_store=MEMORY'):
            connection.execute('PRAGMA ' + pragma)
    except Exception:
        pass
    return connection


def _ensure():
    """The file and its table, made once per process; False when that failed."""
    if not _ready['done']:
        with _opening:
            if not _ready['done']:
                try:
                    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
                except Exception:
                    pass
                try:
                    connection = _open()
                    try:
                        connection.execute(TABLE)
                        connection.execute(INDEX)
                        connection.commit()
                    finally:
                        connection.close()
                    _ready['done'] = True
                except Exception as exc:
                    log.error('META', 'meta_cache init failed: %s', exc, exc_info=True)
    return _ready['done']


def _query(sql, params, many=False):
    connection = _open()
    try:
        cursor = connection.execute(sql, params)
        return cursor.fetchall() if many else cursor.fetchone()
    finally:
        connection.close()


def _write(sql, params=()):
    connection = _open()
    try:
        cursor = connection.execute(sql, params)
        connection.commit()
        return cursor.rowcount
    finally:
        connection.close()


def get(media_type, canonical_id, source_id='auto'):
    """A kept detail (a copy), None when there is none or it expired."""
    if not (media_type and canonical_id):
        return None
    now = int(time.time())
    key = _key(media_type, canonical_id, source_id)
    found = _memory.get(key, now)
    if found is not None:
        return dict(found)
    if not _ensure():
        return None
    try:
        row = _query('SELECT payload, expires_at FROM meta WHERE media_type=? AND canonical_id=? AND source_id=?',
                     (media_type.lower(), canonical_id, source_id))
        if not row or row[1] < now:   # expired rows go in the service's daily sweep
            return None
        try:
            payload = json.loads(row[0])
        except Exception:
            return None
        _memory.put(key, payload, row[1])
        return dict(payload)
    except Exception as exc:
        log.warn('META', 'meta_cache get(%s) failed: %s', key, exc)
        return None


def get_many(media_type, canonical_ids, source_id='auto'):
    """{id: detail} of the ids kept (missing ones simply absent) - one query per IN_CLAUSE ids."""
    if not (media_type and canonical_ids):
        return {}
    now = int(time.time())
    kind = media_type.lower()
    found, missing = {}, []
    for canonical_id in OrderedDict.fromkeys(cid for cid in canonical_ids if cid):
        hit = _memory.get(_key(kind, canonical_id, source_id), now)
        if hit is not None:
            found[canonical_id] = dict(hit)
        else:
            missing.append(canonical_id)
    if not missing or not _ensure():
        return found
    try:
        for start in range(0, len(missing), IN_CLAUSE):
            part = missing[start:start + IN_CLAUSE]
            rows = _query('SELECT canonical_id, payload, expires_at FROM meta WHERE media_type=? AND source_id=? '
                          'AND canonical_id IN (%s)' % ','.join('?' * len(part)), (kind, source_id) + tuple(part),
                          many=True)
            for canonical_id, blob, until in rows:
                if until < now:
                    continue
                try:
                    payload = json.loads(blob)
                except Exception:
                    continue
                _memory.put(_key(kind, canonical_id, source_id), payload, until)
                found[canonical_id] = dict(payload)
    except Exception as exc:
        log.warn('META', 'meta_cache get_many(n=%d) failed: %s', len(missing), exc)
    return found


def put(media_type, canonical_id, payload, source_id='auto', expires_at=None):
    """Keep a detail (in memory at once, then in the file); its lifetime worked out when not given."""
    if not (media_type and canonical_id and isinstance(payload, dict)):
        return False
    now = int(time.time())
    until = lifetime_end(media_type, payload, now) if expires_at is None else expires_at
    key = _key(media_type, canonical_id, source_id)
    _memory.put(key, payload, until)
    if not _ensure():
        return False
    try:
        _write('INSERT OR REPLACE INTO meta (media_type, canonical_id, source_id, payload, created_at, expires_at) '
               'VALUES (?, ?, ?, ?, ?, ?)',
               (media_type.lower(), canonical_id, source_id, json.dumps(payload, ensure_ascii=False), now, until))
        return True
    except Exception as exc:
        log.warn('META', 'meta_cache put(%s) failed: %s', key, exc)
        return False


def purge_expired():
    """The expired details out of the file (the service, now and then). Returns how many."""
    if not _ensure():
        return 0
    try:
        return _write('DELETE FROM meta WHERE expires_at < ?', (int(time.time()),)) or 0
    except Exception as exc:
        log.warn('META', 'meta_cache purge failed: %s', exc)
        return 0


def clear_all():
    _memory.clear()
    if not _ensure():
        return False
    try:
        connection = _open()
        try:
            connection.execute('DELETE FROM meta')
            connection.execute('VACUUM')
            connection.commit()
        finally:
            connection.close()
        return True
    except Exception as exc:
        log.warn('META', 'meta_cache clear failed: %s', exc)
        return False


def stats():
    kept = len(_memory)
    if not _ensure():
        return {'entries': 0, 'db_bytes': 0, 'mem_entries': kept}
    try:
        entries = _query('SELECT COUNT(*) FROM meta', ())[0]
        try:
            size = os.path.getsize(DB_PATH)
        except Exception:
            size = 0
        return {'entries': int(entries or 0), 'db_bytes': int(size), 'mem_entries': len(_memory)}
    except Exception:
        return {'entries': 0, 'db_bytes': 0, 'mem_entries': len(_memory)}
