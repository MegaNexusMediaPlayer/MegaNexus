# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Short-lived cache in front of xbmcaddon.Addon('plugin.video.meganexus').getSetting().



7.0.21: on Kodi 21 every new xbmcaddon.Addon() parses the add-on's whole
settings definition again on its first getSetting(). Hot paths (the metadata
switches behind every catalog, title and Home row) read through setting()
here: on CoreELEC they re-read the settings 15 times a second and made
collections open slowly.
"""
import time

import xbmcaddon

_TTL = 2.0


class AddonSnapshot(object):

    def __init__(self, addon):
        self._addon = addon
        self._cache = {}
        self._stamp = 0.0
        self._factory = xbmcaddon.Addon

    def _fresh(self):
        now = time.time()
        # A replaced xbmcaddon.Addon (a test double) starts from fresh values.
        if now - self._stamp > _TTL or xbmcaddon.Addon is not self._factory:
            self._factory = xbmcaddon.Addon
            self._cache.clear()
            # Clearing Python values is insufficient when the Kodi Addon object
            # still owns the settings snapshot from before a wizard write.
            self._addon = self._write_addon()
            self._stamp = now

    def getSetting(self, sid):
        self._fresh()
        if sid in self._cache:
            return self._cache[sid]
        value = self._addon.getSetting(sid)
        self._cache[sid] = value
        return value

    def getSettingBool(self, sid):
        self._fresh()
        key = ('bool', sid)
        if key in self._cache:
            return self._cache[key]
        value = self._addon.getSettingBool(sid)
        self._cache[key] = value
        return value

    def _write_addon(self):
        # Kodi saves the WHOLE tree of settings from the instance that writes, so a long-lived
        # instance would save its old snapshot over newer values: writes use a fresh one.
        try:
            return xbmcaddon.Addon('plugin.video.meganexus')
        except Exception:
            return self._addon

    def invalidate(self):
        """Read the settings again on the next ask (after a write, ours or another's)."""
        self._cache.clear()
        self._stamp = 0.0

    def setSetting(self, sid, value):
        self.invalidate()
        return self._write_addon().setSetting(sid, value)

    def setSettingBool(self, sid, value):
        self.invalidate()
        return self._write_addon().setSettingBool(sid, value)

    def __getattr__(self, name):          # everything else: Kodi's own Addon
        return getattr(self._addon, name)


_INSTANCE = []        # the one snapshot of this run


def cached_addon():
    if not _INSTANCE:
        _INSTANCE.append(AddonSnapshot(xbmcaddon.Addon('plugin.video.meganexus')))
    return _INSTANCE[0]


def setting(sid):
    """getSetting() of MegaNexus through the shared short-lived cache."""
    return cached_addon().getSetting(sid)


def invalidate():
    for snapshot in _INSTANCE:
        snapshot.invalidate()
