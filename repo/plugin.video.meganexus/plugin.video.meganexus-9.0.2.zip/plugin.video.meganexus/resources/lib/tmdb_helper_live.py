# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""What TMDb Helper says about the item in focus, when MegaNexus is opened from a skin that
uses it (Arctic Fuse, Arctic Horizon, …).

TMDb Helper's monitor publishes the focused item as Home window properties
`TMDbHelper.ListItem.*`. Taken only when its TMDB id (or else IMDb id) is the opened item's -
a neighbouring item's values never leak in:

    pictures   a missing logo, background or poster
    ratings    IMDb, TMDB, Trakt, Rotten Tomatoes (critics, audience), Metacritic - plus
               MDBList's when already kept (asked for only on request: never on the
               way to the source window) - as meganexus.rating.* for the sources' row
    resume     the resume point a TMDb Helper player address does not carry

Property names differ between TMDb Helper versions; each value is looked for under all of
them. Anything missing gives an empty value and the chip stays hidden."""
import xbmc
import xbmcgui

PREFIX = 'TMDbHelper.ListItem.'
RATING_NAMES = (('imdb', ('IMDb_Rating', 'imdb_rating', 'Rating.IMDb')),
                ('tmdb', ('Rating', 'TMDb_Rating', 'themoviedb_rating')),
                ('trakt', ('Trakt_Rating', 'trakt_rating')),
                ('rt_crit', ('RottenTomatoes_Rating', 'Tomatometer', 'rottentomatoes_rating')),
                ('rt_aud', ('RottenTomatoes_AudienceRating', 'Audience_Rating', 'rottentomatoes_audiencerating')),
                ('metacritic', ('Metacritic_Rating', 'metacritic_rating')))
PERCENT_RATINGS = ('rt_crit', 'rt_aud', 'metacritic')       # 0-100 scores, never shown as 0-10
PICTURE_NAMES = (('clearlogo', ('Art(clearlogo)', 'Art(tvshow.clearlogo)', 'clearlogo')),
                 ('fanart', ('Art(fanart)', 'fanart')), ('poster', ('Art(poster)', 'poster')))
SHOWN_RATINGS = ('imdb', 'tmdb', 'trakt', 'rt_crit', 'rt_aud', 'metacritic', 'letterboxd', 'mdblist', 'mal')
RESUME_NAMES = {'position': ('ResumeTime', 'Resume.Time', 'Player.ResumeTime', 'Progress.Time', 'Resume'),
                'duration': ('TotalTime', 'DurationSeconds', 'Player.Duration', 'Duration'),
                'percent': ('PercentPlayed', 'Progress', 'ResumePercent', 'Player.Progress')}
ITEM_RESUME = {'position': ('ListItem.ResumeTime', 'ListItem.Property(ResumeTime)', 'ListItem.Property(resumetime)'),
               'duration': ('ListItem.Duration', 'ListItem.Property(TotalTime)', 'ListItem.Property(DurationSeconds)'),
               'percent': ('ListItem.PercentPlayed', 'ListItem.Property(PercentPlayed)', 'ListItem.Property(progress)')}
WATCHED_AT = 90.0           # 6.0.35: watched at 90 %
TOO_EARLY = 30.0            # seconds: not worth resuming


def _home():
    return xbmcgui.Window(10000)


def _value(*names):
    """The first TMDb Helper property among `names` that holds something."""
    try:
        home = _home()
        return next((value for value in ((home.getProperty(PREFIX + name) or '').strip() for name in names) if value), '')
    except Exception:
        return ''


def _label(*names):
    """The first Kodi info label among `names` that holds something."""
    for name in names:
        try:
            value = (xbmc.getInfoLabel(name) or '').strip()
        except Exception:
            value = ''
        if value:
            return value
    return ''


def rating_text(value, percent=False):
    """'7.4' on a 0-10 scale (a 0-100 value is divided), or '86' for a percent score
    (a 0-1 value is multiplied); '' for nothing usable."""
    try:
        number = float((value or '').strip().replace('%', '')) if value else 0.0
    except ValueError:
        return ''
    if number <= 0:
        return ''
    if percent:
        return str(int(round(number * 100.0 if number <= 1.0 else number)))
    return '%.1f' % (number / 10.0 if number > 10.0 else number)


def _seconds(value):
    """Seconds from '123', '45%' or a clock 'HH:MM:SS' / 'MM:SS'; 0 for nothing."""
    try:
        text = str(value or '').strip().replace('%', '')
        if not text:
            return 0.0
        total = 0.0
        for part in text.split(':'):
            total = total * 60.0 + float(part or 0)
        return total
    except Exception:
        return 0.0


def live_context(expected_tmdb_id=None, expected_imdb_id=None, fetch_mdblist_ratings=False):
    """{monitor_tmdb_id, monitor_type, art, ratings} of the focused item - {} when TMDb
    Helper describes another one."""
    shown_id, shown_type = _value('Monitor.TMDb_ID'), _value('Monitor.TMDb_Type')
    if expected_tmdb_id and shown_id and str(shown_id) != str(expected_tmdb_id):
        shown_imdb = _value('IMDb')
        if not (expected_imdb_id and shown_imdb and str(shown_imdb) == str(expected_imdb_id)):
            return {}
    art = dict((key, value) for key, value in ((key, _value(*names)) for key, names in PICTURE_NAMES) if value)
    ratings = dict((key, value) for key, value in (
        (key, rating_text(_value(*names), key in PERCENT_RATINGS)) for key, names in RATING_NAMES) if value)
    try:
        imdb = str(expected_imdb_id or _value('IMDb') or '').strip()
        tmdb = str(expected_tmdb_id or shown_id or '').strip()
        if imdb or tmdb:
            from . import mdblist_api
            ask = mdblist_api.ratings_of if fetch_mdblist_ratings else mdblist_api.cached_ratings
            for key, value in (ask(imdb_id=imdb, media_type=(shown_type or 'movie'), tmdb_id=tmdb) or {}).items():
                if value and not ratings.get(key):
                    ratings[key] = value
    except Exception:
        pass
    return {'monitor_tmdb_id': shown_id, 'monitor_type': shown_type, 'art': art, 'ratings': ratings}


def _same_item(expected_tmdb_id, expected_imdb_id, season, episode):
    """The focused Kodi item is the opened one (its ids and episode, when it shows them)."""
    if expected_tmdb_id or expected_imdb_id:
        tmdb = _label('ListItem.UniqueID(tmdb)', 'ListItem.Property(tmdb_id)')
        imdb = _label('ListItem.UniqueID(imdb)', 'ListItem.IMDBNumber')
        if expected_tmdb_id and tmdb and str(tmdb) != str(expected_tmdb_id):
            return False
        if expected_imdb_id and imdb and str(imdb).lower() != str(expected_imdb_id).lower():
            return False
    return True


def resume_hint(expected_tmdb_id=None, expected_imdb_id=None, season=None, episode=None):
    """{resume_seconds, resume_percent, duration, updated_at, source} of the focused item, read
    before the focus moves; {} for another item, nothing to resume or a watched one."""
    ctx = live_context(expected_tmdb_id=expected_tmdb_id, expected_imdb_id=expected_imdb_id)
    if not ctx and not _same_item(expected_tmdb_id, expected_imdb_id, season, episode):
        return {}
    try:
        wanted = (int(season or 0), int(episode or 0))
    except Exception:
        wanted = (0, 0)
    shown = (int(_seconds(_label('ListItem.Season'))), int(_seconds(_label('ListItem.Episode'))))
    if any(want and have and want != have for want, have in zip(wanted, shown)):
        return {}
    found = {}
    for key in ('position', 'duration', 'percent'):
        found[key] = _seconds(_value(*RESUME_NAMES[key]))
        if found[key] <= 0:
            found[key] = _seconds(_label(*ITEM_RESUME[key]))
    position, duration, percent = found['position'], found['duration'], found['percent']
    if percent <= 0 and position > 0 and duration > 0:
        percent = position * 100.0 / duration
    if position <= 0 and percent > 0 and duration > 0:
        position = duration * percent / 100.0
    if position <= TOO_EARLY or percent >= WATCHED_AT:
        return {}
    return {'resume_seconds': position, 'resume_percent': percent if 0 < percent < 95 else 0.0,
            'duration': duration, 'updated_at': 0, 'source': 'tmdbhelper'}


def fill_art(meta, ctx):
    """The item's missing logo, background and poster from TMDb Helper (changes and returns meta)."""
    art = (ctx or {}).get('art') or {}
    if not ctx:
        return meta
    if not meta.get('clearlogo') and art.get('clearlogo'):
        meta['clearlogo'] = meta['logo'] = art['clearlogo']
    if not (meta.get('fanart') or meta.get('background')) and art.get('fanart'):
        meta['fanart'] = meta['background'] = art['fanart']
    if not meta.get('poster') and art.get('poster'):
        meta['poster'] = art['poster']
    return meta


def show_ratings(window, ctx):
    """meganexus.rating.<source> (and .any) on Home and on `window`; True when one has a value."""
    ratings = (ctx or {}).get('ratings') or {}
    home = _home()
    shown = False
    for target in [home] + ([window] if window is not None and window is not home else []):
        try:
            for key in SHOWN_RATINGS:
                target.setProperty('meganexus.rating.%s' % key, ratings.get(key, ''))
                shown = shown or bool(ratings.get(key, ''))
            target.setProperty('meganexus.rating.any', '1' if ratings else '')
        except Exception:
            pass
    return shown


def enrich(window, meta, log=None, fetch_mdblist_ratings=False):
    """The pictures filled and the ratings published for the opened item (a previous item's
    ratings are cleared when TMDb Helper has nothing for this one)."""
    try:
        ctx = live_context(expected_tmdb_id=str((meta or {}).get('tmdb_id') or '').strip() or None,
                           expected_imdb_id=str((meta or {}).get('imdb_id') or '').strip() or None,
                           fetch_mdblist_ratings=fetch_mdblist_ratings)
        if not ctx:
            show_ratings(window, {})
            return meta
        meta = fill_art(meta, ctx)
        show_ratings(window, ctx)
        if log:
            log('tmdbh_context: ratings=%s art=%s' % (list(ctx['ratings']), list(ctx['art'])))
        return meta
    except Exception as exc:
        if log:
            try:
                log('tmdbh_context error: %s' % exc)
            except Exception:
                pass
        return meta
