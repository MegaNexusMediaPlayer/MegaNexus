# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Kodi's own settings written to disk at once (7.0.60).

A Kodi setting changed over JSON-RPC (Settings.SetSettingValue) lives only in memory:
Kodi writes guisettings.xml when it closes cleanly or its settings window closes. Closed
any other way (Windows: the window's X while add-ons still close, a shutdown, a crash),
the change was gone - on a new Windows Kodi the MegaNexus screensaver was off again at
every start. Every skin builtin that sets a value makes Kodi save all its settings; this
one sets a flag nothing reads.
"""
import xbmc

FLAG = 'meganexus.kodi.kept'


def keep():
    """Kodi writes all its settings (guisettings.xml) now."""
    try:
        xbmc.executebuiltin('Skin.SetBool(%s)' % FLAG)
    except Exception:
        pass
