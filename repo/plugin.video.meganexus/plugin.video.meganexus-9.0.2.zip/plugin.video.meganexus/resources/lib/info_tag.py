# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A list item's video information through Kodi 20+'s InfoTag (setInfo is deprecated there).

Every field the item has goes to its setter; a value Kodi refuses is skipped, never the rest.
Also: the resume point, the unique ids (for an episode, season or show also as the show's
ids - TMDb Helper and the skins read those), the video stream and the cast with pictures."""
import re

import xbmc


def _names(value, separators=r','):
    """A list of names from a list or a 'A, B' text."""
    if isinstance(value, str):
        value = [part.strip() for part in re.split(r'[%s]' % separators, value) if part.strip()]
    return list(value) if value else []


def _several(value):
    return value if isinstance(value, (list, tuple)) else [str(value)]


# info field -> (InfoTag setter, how the value is given)
FIELDS = (('title', 'setTitle', str), ('originaltitle', 'setOriginalTitle', str), ('plot', 'setPlot', str),
          ('plotoutline', 'setPlotOutline', str), ('tagline', 'setTagLine', str), ('mpaa', 'setMpaa', str),
          ('studio', 'setStudios', lambda v: v if isinstance(v, (list, tuple)) else (str(v),)),
          ('country', 'setCountries', _several), ('director', 'setDirectors', _names),
          ('writer', 'setWriters', _names), ('genre', 'setGenres', lambda v: _names(v, ',/')),
          ('year', 'setYear', int), ('premiered', 'setPremiered', str), ('rating', 'setRating', float),
          ('votes', 'setVotes', int), ('duration', 'setDuration', int), ('trailer', 'setTrailer', str),
          ('imdbnumber', 'setIMDBNumber', str), ('playcount', 'setPlaycount', int),
          ('tvshowtitle', 'setTvShowTitle', str), ('season', 'setSeason', int), ('episode', 'setEpisode', int))
SHOW_KINDS = ('episode', 'tvshow', 'season')


def _call(setter, *args):
    try:
        setter(*args)
    except Exception:
        pass


def unique_ids(ids, show=False):
    """({'imdb': …, 'tmdb': …, 'tvdb': …}, the default one) from the item's ids; a show's
    episode, season or the show itself also names them as the show's (tvshow.imdb …)."""
    ids = ids or {}
    found = dict((short, str(ids[short + '_id'])) for short in ('imdb', 'tmdb', 'tvdb') if ids.get(short + '_id'))
    default = next((short for short in ('imdb', 'tmdb', 'tvdb') if short in found), '')
    if show:
        found.update(dict(('tvshow.' + short, value) for short, value in list(found.items())))
    return found, default


def _unique_ids(tag, ids, kind):
    found, default = unique_ids(ids, kind in SHOW_KINDS)
    if found:
        _call(tag.setUniqueIDs, found, default)


def _actors(cast):
    actors = []
    for person in cast:
        if not isinstance(person, dict) or not str(person.get('name') or '').strip():
            continue
        name = str(person['name']).strip()
        role = str(person.get('role') or person.get('character') or '').strip()
        picture = str(person.get('thumbnail') or person.get('photo') or person.get('profile_path') or '').strip()
        try:
            order = int(person['order']) if person.get('order') is not None else len(actors)
        except (ValueError, TypeError):
            order = len(actors)
        try:
            actors.append(xbmc.Actor(name, role, order, picture))
        except Exception:
            try:
                actors.append(xbmc.Actor(name=name, role=role, order=order, thumbnail=picture))
            except Exception:
                pass
    return actors


def apply(item, info, ids=None, cast=None):
    """True when the InfoTag was filled (False: Kodi has none - the caller uses setInfo)."""
    try:
        tag = item.getVideoInfoTag(offscreen=True)
    except Exception:
        return False
    info = info or {}
    if info.get('mediatype'):
        _call(tag.setMediaType, info['mediatype'])
    for field, setter, given in FIELDS:
        if info.get(field) is not None:
            try:
                value = given(info[field])
            except (ValueError, TypeError):
                continue
            _call(getattr(tag, setter), value)
    if info.get('resumetime') is not None or info.get('totaltime') is not None:
        try:
            position = float(info.get('resumetime') or 0.0)
            total = float(info.get('totaltime') or info.get('duration') or 0.0)
            if position > 0 and total > 0:
                _call(tag.setResumePoint, position, total)
        except Exception:
            pass
    if ids:
        _unique_ids(tag, ids, str(info.get('mediatype') or '').strip().lower())
    video = (info.get('streamdetails') or {}).get('video') if isinstance(info.get('streamdetails') or {}, dict) else None
    if isinstance(video, dict) and hasattr(tag, 'addVideoStream'):
        try:
            _call(tag.addVideoStream, int(video.get('width') or 0), int(video.get('height') or 0),
                  float(video.get('aspect') or 0), int(video.get('duration') or 0), str(video.get('codec') or ''),
                  str(video.get('stereomode') or ''))
        except Exception:
            pass
    if cast:
        try:
            actors = _actors(cast)
            if actors:
                _call(tag.setCast, actors)
        except Exception:
            pass
    return True
