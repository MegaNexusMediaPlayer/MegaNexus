# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""How well a search matches a title: 0 (not at all - the row is not shown) to 100.

Both are folded first (`fold`): lower case, accents and other marks dropped ("Šok" is
"sok"), everything that is not a letter or digit a space. Then, in this order:

    same text                                   100
    the title starts with the query (a word)     88
    every query word in the title                80   (a word one or two typos off: 0.9)
    four fifths of them                          74
    a multi-word query inside the title          66
    three fifths of a multi-word query           58
    one long word nearly equal to a title word   52

A number in the query must be in the title as it is ("Season 5" never finds "Season 50"),
and a single short word must be a whole word of the title."""
import unicodedata
from functools import lru_cache

TITLE_KEYS = ('name', 'title', 'original_title', 'original_name', 'originalTitle', 'english_title',
              'aliases', 'alias', 'aka', 'alternate_titles', 'alternative_titles', 'translations')
ALIASES_MAX, ALIAS_CHARS, ALIAS_DEPTH = 24, 300, 2


@lru_cache(maxsize=16384)
def _folded(text):
    chars = (char for char in unicodedata.normalize('NFKD', text.casefold()) if not unicodedata.combining(char))
    return ' '.join(''.join(char if char.isalnum() else ' ' for char in chars).split())


def fold(text):
    return _folded(str(text or ''))


def within(a, b, limit):
    """True when a and b are at most `limit` edits apart (insert, delete, change, swap two
    neighbours) - stops as soon as a row can not get back under the limit."""
    if a == b:
        return True
    if abs(len(a) - len(b)) > limit:
        return False
    if not a or not b:
        return max(len(a), len(b)) <= limit
    before, last = None, list(range(len(b) + 1))
    for i, char_a in enumerate(a, 1):
        row = [i]
        for j, char_b in enumerate(b, 1):
            best = min(last[j - 1] + (char_a != char_b), last[j] + 1, row[j - 1] + 1)
            if before is not None and j > 1 and char_a == b[j - 2] and a[i - 2] == char_b:
                best = min(best, before[j - 2] + 1)
            row.append(best)
        if min(row) > limit:
            return False
        before, last = last, row
    return last[-1] <= limit


def near(word, other, min_len=4):
    """Two words the same, or a typo or two apart - never when either holds a digit."""
    if word == other:
        return True
    if any(char.isdigit() for char in word + other) or len(word) < min_len or len(other) < 4:
        return False
    return within(word, other, 2 if max(len(word), len(other)) >= 8 else 1)


@lru_cache(maxsize=16384)
def _score(query, title):
    query, title = fold(query), fold(title)
    if not query or not title:
        return 0
    if query == title:
        return 100
    query_words, title_words = query.split(), title.split()
    asked, offered = set(query_words), set(title_words)
    if any(word.isdigit() and word not in offered for word in asked):
        return 0
    if title.startswith(query + ' '):
        return 88
    found = 0.0
    for word in asked:
        if word in offered:
            found += 1
        elif any(near(word, other) for other in offered):
            found += 0.9
    share = found / len(asked)
    for least, points in ((0.999, 80), (0.8, 74)):
        if share >= least:
            return points
    if len(asked) >= 2 and query in title:
        return 66
    if len(asked) >= 2 and share >= 0.6:
        return 58
    if len(asked) == 1:
        word = next(iter(asked))
        return 52 if len(word) >= 5 and any(near(word, other, 5) for other in offered) else 0
    return int(50 * share)


def score(query, title):
    return _score(str(query or ''), str(title or ''))


def titles_of(value):
    """A title's names: the name and its aliases / translations (at most ALIASES_MAX, each once)."""
    if not isinstance(value, dict):
        if isinstance(value, (list, tuple, set)):
            return tuple(str(name).strip() for name in value if str(name or '').strip())[:ALIASES_MAX]
        text = str(value or '').strip()
        return (text,) if text else ()
    names, seen = [], set()

    def take(raw, depth):
        if len(names) >= ALIASES_MAX or raw is None or depth > ALIAS_DEPTH:
            return
        if isinstance(raw, str):
            text = raw.strip()[:ALIAS_CHARS]
            if text and text.casefold() not in seen:
                seen.add(text.casefold())
                names.append(text)
        elif isinstance(raw, (list, tuple, set)):
            for item in raw:
                take(item, depth + 1)
        elif isinstance(raw, dict):
            keys = [key for key in TITLE_KEYS if key in raw]
            for item in [raw.get(key) for key in keys] if keys else list(raw.values()):
                take(item, depth + 1)

    for key in TITLE_KEYS:
        take(value.get(key), 0)
    return tuple(names)


def best_score(query, value):
    return max((score(query, name) for name in titles_of(value)), default=0)


def keep_relevant(items, query, title_of=lambda item: item, fallback_when_empty=True):
    """([(item, score)...] of the rows that match at all, how many were dropped). When none
    matches, every row stays (with its 0) rather than an empty page."""
    scored = [(item, best_score(query, title_of(item))) for item in (items or [])]
    kept = [pair for pair in scored if pair[1] > 0]
    if not kept and fallback_when_empty:
        return scored, 0
    return kept, len(scored) - len(kept)
