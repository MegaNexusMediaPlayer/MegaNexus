# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""HUB Settings > Help & diagnostics > Report a problem (7.0.29).

The viewer describes the problem on the phone (QR code, the same local service
as "Set up on phone"); MegaNexus adds its versions and the Kodi log and sends
it to the MegaNexus report relay, which opens a GitHub issue. The relay holds
the GitHub key - it is never in the add-on (tools/report-relay).

The log goes to a public issue, so everything personal is removed first:
add-on configurations in links, stream and debrid tokens, IPTV user names and
passwords, API keys, e-mail addresses and the user's home folder.
"""
import json
import re

import xbmc
import xbmcaddon
import xbmcvfs

# The deployed relay (tools/report-relay/README.md). The setting overrides it.
RELAY_URL = 'https://meganexus-report.mladenstojanovic1988.workers.dev/report'
RELAY_SETTING = 'meganexus_report_relay'
LOG_MAX = 150 * 1024          # the end of kodi.log
OLD_LOG_MAX = 40 * 1024       # the end of the previous run (a crash before a restart)
TITLE_MAX, TEXT_MAX, CONTACT_MAX = 120, 5000, 120
PER_DAY = 3                   # reports in 24 hours (the relay counts too)
TIMES_SETTING = 'meganexus_report_times'
DEVICE_SETTING = 'meganexus_report_device'
ROWS_KEPT = 20                # the relay keeps this many system rows (tools/report-relay)

_SECRET_KEYS = ('token', 'key', 'apikey', 'api_key', 'api-key', 'password', 'pass', 'passwd', 'pwd', 'user', 'username',
                'auth', 'authorization', 'sig', 'signature', 'secret', 'session', 'sessionid', 'access_token',
                'refresh_token', 'client_secret', 'x-plex-token', 'expires', 'key-pair-id', 'policy', 'hash', 'email')
_RULES = (
    # user:password@host
    (re.compile(r'(?i)\b([a-z][a-z0-9+.-]*://)[^/\s:@]+:[^/\s@]+@'), r'\1***:***@'),
    # Xtream: /live|movie|series/<user>/<password>/ and get.php?username=&password=
    (re.compile(r'(?i)(/(?:live|movie|series|timeshift)/)[^/\s]+/[^/\s]+/'), r'\1***/***/'),
    # secret query values
    (re.compile(r'(?i)([?&|](?:%s)=)[^&\s"\'|]+' % '|'.join(re.escape(k) for k in _SECRET_KEYS)), r'\1***'),
    # Authorization / bearer headers and JSON secrets
    (re.compile(r'(?i)\b(bearer|basic)\s+[a-z0-9._~+/=-]{8,}'), r'\1 ***'),
    (re.compile(r'(?i)("(?:%s)"\s*:\s*")[^"]*"' % '|'.join(re.escape(k) for k in _SECRET_KEYS)), r'\1***"'),
    # add-on configurations and tokens inside links: long random path pieces
    (re.compile(r'(?<=/)[A-Za-z0-9_\-=%.~+]{28,}(?=[/?#\s"\']|$)'), '<cfg>'),
    # e-mail addresses
    (re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'), '<email>'),
    # the user's home folder
    (re.compile(r'(/home/|/Users/|\\Users\\)[^/\\\s]+'), r'\1<user>'),
    # long hex / base64 secrets standing alone (API keys, session ids)
    (re.compile(r'(?<![A-Za-z0-9])[A-Fa-f0-9]{32,}(?![A-Za-z0-9])'), '<hex>'),
)


def redact(text):
    for pattern, replacement in _RULES:
        text = pattern.sub(replacement, text)
    return text


def _tail(path, limit):
    try:
        real = xbmcvfs.translatePath(path)
        with open(real, 'rb') as handle:
            handle.seek(0, 2)
            size = handle.tell()
            handle.seek(max(0, size - limit))
            data = handle.read()
    except (OSError, IOError):
        return ''
    text = data.decode('utf-8', 'replace')
    if size > limit:
        text = text[text.find('\n') + 1:]   # start on a whole line
    return text


def logs():
    """(kodi.log end, previous run's end), both without personal data."""
    return redact(_tail('special://logpath/kodi.log', LOG_MAX)), redact(_tail('special://logpath/kodi.old.log', OLD_LOG_MAX))


def _read(path, limit=256):
    try:
        with open(path, 'rb') as handle:
            return handle.read(limit).decode('utf-8', 'replace').replace('\x00', '').strip()
    except (OSError, IOError):
        return ''


def _android_prop(name):
    """getprop, the only way to ask an Android box what it is."""
    try:
        import subprocess
        out = subprocess.run(['getprop', name], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             timeout=3)
        return out.stdout.decode('utf-8', 'replace').strip()
    except Exception:
        return ''


def hardware():
    """(device, operating system, memory) - what the box is, in words a human reads.

    8.1.2: a report said only "Platform: Linux", which is the same answer for a Fire TV
    Cube, a CoreELEC box and a desktop - and those three behave nothing alike. Knowing
    which one it is decides whether a fault is worth chasing at all.

    Nothing here identifies the person: a model name, the distribution's own name and
    the amount of memory. The hostname is deliberately NOT included (Kodi's
    System.FriendlyName usually carries it), and these rows go into a public issue.
    """
    import platform
    arch = platform.machine() or '-'
    android = xbmc.getCondVisibility('System.Platform.Android')
    device = ''
    if android:
        maker = _android_prop('ro.product.manufacturer')
        model = _android_prop('ro.product.model')
        device = ' '.join(part for part in (maker, model) if part)
    if not device:
        # ARM boxes (CoreELEC, LibreELEC, a Pi) name themselves here
        device = _read('/proc/device-tree/model', 128).rstrip('\x00')
    if not device:
        # x86: the board's own idea of what it is
        vendor = _read('/sys/devices/virtual/dmi/id/sys_vendor', 64)
        product = _read('/sys/devices/virtual/dmi/id/product_name', 64)
        device = ' '.join(part for part in (vendor, product) if part and part.lower() not in ('to be filled by o.e.m.',))
    if not device:
        device = platform.system() or '-'
    system_name = ''
    if android:
        release = _android_prop('ro.build.version.release')
        system_name = ('Android %s' % release).strip() if release else 'Android'
    if not system_name:
        for line in _read('/etc/os-release', 1024).splitlines():
            if line.startswith('PRETTY_NAME='):
                system_name = line.split('=', 1)[1].strip().strip('"')
                break
    if not system_name:
        system_name = ' '.join(part for part in (platform.system(), platform.release()) if part) or '-'
    memory = ''
    for line in _read('/proc/meminfo', 256).splitlines():
        if line.startswith('MemTotal:'):
            try:
                memory = '%.1f GB' % (int(line.split()[1]) / 1024.0 / 1024.0)
            except (IndexError, ValueError):
                memory = ''
            break
    if not memory:
        memory = xbmc.getInfoLabel('System.Memory(total)') or '-'
    return '%s · %s' % (device, arch) if device != '-' else arch, system_name, memory


def picture_path():
    """Which of the two picture paths is live, and what the native add-on is.

    8.1.2: a whole day went into a fault that was one line in this add-on (a picture
    stat answering size 0, so Kodi re-cached every poster on every screen). A report
    that had said "vfs.meganexus 1.1.0, pictures through mnxart" would have pointed
    straight at it.
    """
    try:
        version = xbmcaddon.Addon('vfs.meganexus').getAddonInfo('version')
    except Exception:
        version = ''
    if not version:
        native = 'not installed'
    elif not xbmc.getCondVisibility('System.AddonIsEnabled(vfs.meganexus)'):
        native = 'vfs.meganexus %s · switched off in Kodi' % version
    else:
        native = 'vfs.meganexus %s' % version
    try:
        from . import art_cache
        if art_cache.native():
            pictures = 'mnxart (native, no port)'
        else:
            import xbmcgui
            base = xbmcgui.Window(10000).getProperty('meganexus.art_cache.base')
            pictures = ('image proxy %s' % base) if base else 'the providers\' own links'
    except Exception:
        pictures = '-'
    return native, pictures


def system():
    def version(addon_id):
        try:
            return xbmcaddon.Addon(addon_id).getAddonInfo('version')
        except Exception:
            return '-'
    # The order is the order of usefulness, because a reader of the issue reads it from
    # the top - and because the relay keeps only the first ROWS_KEPT of them. Anything
    # added later goes at the end, where losing it costs least.
    rows = [('MegaNexus', version('plugin.video.meganexus')), ('Interface', version('script.meganexus')),
            ('Skin', '%s %s' % (xbmc.getSkinDir(), version(xbmc.getSkinDir()))),
            ('Kodi', xbmc.getInfoLabel('System.BuildVersion'))]
    try:
        # 8.1.2: which box this is. "Linux" alone reads the same for a Fire TV Cube, a
        # CoreELEC box and a desktop, and those behave nothing alike - it decides whether
        # a fault is even worth chasing.
        device_name, system_name, memory = hardware()
        rows.extend([('Device', device_name), ('OS', system_name)])
    except Exception:
        device_name = system_name = memory = ''
    try:
        # 8.1.2: the native picture add-on and the path actually in use. A whole day went
        # into a fault that was one line in that add-on; a report saying this would have
        # pointed straight at it.
        native, pictures = picture_path()
        rows.extend([('Native', native), ('Pictures', pictures)])
    except Exception:
        pass
    rows.extend([('Platform', ', '.join(p for p in ('Android', 'Linux', 'Windows', 'OSX', 'IOS', 'TVOS', 'Webos', 'Tizen')
                                        if xbmc.getCondVisibility('System.Platform.%s' % p)) or '-'),
                 ('Screen', xbmc.getInfoLabel('System.ScreenResolution'))])
    if memory:
        rows.append(('Memory', memory))
    try:
        from .theme import current
        rows.append(('Theme', current()))
    except Exception:
        pass
    try:
        rows.append(('Screensaver', version('screensaver.meganexus')))
    except Exception:
        pass
    # These go into a public issue like the log does, so they are cleaned the same way.
    return [(name, redact(str(value or '-'))) for name, value in rows]


def relay():
    try:
        value = xbmcaddon.Addon('plugin.video.meganexus').getSetting(RELAY_SETTING).strip()
    except Exception:
        value = ''
    return value or RELAY_URL


def _addon():
    return xbmcaddon.Addon('plugin.video.meganexus')


def _times(now):
    try:
        values = json.loads(_addon().getSetting(TIMES_SETTING) or '[]')
    except ValueError:
        values = []
    return [t for t in values if isinstance(t, (int, float)) and 0 <= now - t < 86400]


def left_today():
    """How many reports this device may still send in the next 24 hours."""
    import time
    return max(0, PER_DAY - len(_times(time.time())))


def _sent():
    import time
    now = time.time()
    _addon().setSetting(TIMES_SETTING, json.dumps(_times(now) + [now]))


def device():
    """An anonymous id made once on this device: the relay's 3-in-24-hours count."""
    addon = _addon()
    value = addon.getSetting(DEVICE_SETTING)
    if not value:
        import uuid
        value = uuid.uuid4().hex
        addon.setSetting(DEVICE_SETTING, value)
    return value


def _clean(value, limit):
    return str(value or '').replace('\x00', '').strip()[:limit]


def send(body):
    """The phone's report -> {'url': issue link, 'number': n}. ValueError says what is wrong."""
    title = _clean(body.get('title'), TITLE_MAX)
    text = _clean(body.get('description'), TEXT_MAX)
    steps = _clean(body.get('steps'), TEXT_MAX)
    contact = _clean(body.get('contact'), CONTACT_MAX)
    if len(title) < 5:
        raise ValueError('Give the problem a short title (5 characters or more).')
    if len(text) < 10:
        raise ValueError('Describe what happened (10 characters or more).')
    if not left_today():
        raise ValueError('You can send %d reports in 24 hours. Try again tomorrow.' % PER_DAY)
    url = relay()
    if not url:
        raise ValueError('Problem reports are not available in this version yet.')
    log, old_log = logs() if body.get('log', True) else ('', '')
    payload = {'title': title, 'description': text, 'steps': steps, 'contact': contact, 'device': device(),
               'system': system(), 'log': log, 'old_log': old_log}
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    data = json.dumps(payload).encode('utf-8')
    request = Request(url, data=data, headers={'Content-Type': 'application/json',
                                               'User-Agent': 'MegaNexus/%s (Kodi)' % system()[0][1]})
    try:
        with urlopen(request, timeout=45) as response:
            reply = json.loads(response.read(65536).decode('utf-8') or '{}')
    except HTTPError as exc:
        try:
            reply = json.loads(exc.read(65536).decode('utf-8') or '{}')
        except Exception:
            reply = {}
        raise ValueError(reply.get('error') or 'The report could not be sent (%d). Try again later.' % exc.code)
    except (URLError, OSError, ValueError):
        raise ValueError('The report could not be sent. Check the internet connection and try again.')
    if not reply.get('ok') or not reply.get('url'):
        raise ValueError(reply.get('error') or 'The report could not be sent. Try again later.')
    _sent()
    xbmc.log('[MegaNexus] Problem report sent: %s' % reply.get('url'), xbmc.LOGINFO)
    return {'url': reply['url'], 'number': reply.get('number')}
