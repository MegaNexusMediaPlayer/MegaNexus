# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""How long Kodi's Python was busy (8.1.0, the diagnostics overlay).

Every Python add-on in Kodi - MegaNexus' screens, its service, Watch Party - shares one lock:
while one of them computes, the others (the screen under the remote too) wait. A thread here
asks to wake every TICK; how late it wakes is how long Python was held by someone else. The
overlay shows the longest wait of the last WINDOW seconds; one of LOG_FROM or more goes to the
log, so a stutter can be found afterwards. It runs only while the overlay is on.
"""
import threading
import time

TICK = 0.02                 # s between looks
WINDOW = 10.0               # s the overlay's number covers
LOG_FROM = 0.4              # s: a wait this long is written to the log
LOG_EVERY = 5.0             # s at most one log line

_samples = []               # (when, how late) of the last WINDOW seconds
_lock = threading.Lock()
_thread = None
_until = [0.0]              # the overlay was on until then (renewed by the overlay's loop)
KEEP = 5.0                  # s it runs on after the overlay's last renewal


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus][perf] %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def stop():
    """Kodi closes: the watch ends at once (Kodi waits for every thread of the service)."""
    _until[0] = 0.0


def _watch():
    logged = 0.0
    while time.monotonic() < _until[0]:      # never a Kodi call from here (50 a second)
        before = time.monotonic()
        time.sleep(TICK)
        now = time.monotonic()
        late = now - before - TICK
        with _lock:
            _samples.append((now, late))
            while _samples and now - _samples[0][0] > WINDOW:
                _samples.pop(0)
        if late >= LOG_FROM and now - logged >= LOG_EVERY:
            logged = now
            _log('Python busy %d ms (another add-on or MegaNexus held it)' % (late * 1000))


def start():
    """The overlay is on: look (on) for KEEP seconds more - its loop calls this every 2 s."""
    global _thread
    _until[0] = time.monotonic() + KEEP
    if _thread is not None and _thread.is_alive():
        return
    with _lock:
        del _samples[:]
    _thread = threading.Thread(target=_watch, name='MegaNexusStallWatch', daemon=True)
    _thread.start()


def numbers():
    """(longest, average) wait in ms of the last WINDOW s, or (None, None) while measuring."""
    with _lock:
        lates = [late for _, late in _samples]
    if not lates:
        return None, None
    return max(0, max(lates)) * 1000, max(0, sum(lates) / len(lates)) * 1000


def summary():
    """The overlay's line: the longest wait of the last WINDOW s and how often it was long."""
    with _lock:
        lates = [late for _, late in _samples]
    if not lates:
        return 'measuring…'
    worst, average = max(lates), sum(lates) / len(lates)
    # Python hands its lock over every 5 ms: a long wait is one call that kept it (a big JSON, a
    # Kodi call waiting on Kodi); the average says how busy the others keep it
    return 'longest %d ms  ·  average %.1f ms' % (max(0, worst) * 1000, max(0, average) * 1000)
