# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""What a subtitle is called: its language, its add-on, its release name and the file it
is saved as.

Add-ons describe a language in every way there is - "hr", "hrv", "Croatian", a list, an
object, a flag emoji - and often only in the file name ("Film.2020.HRV.srt" with lang
"und"). `language_key` turns all of them into one code ('hr', 'pt-br'); `language_of`
gives the code, flag, English name and short code a subtitle row is shown with.

    title_of    "🇭🇷 Croatian · [COLOR cyan]OpenSubtitles[/COLOR] · Film.2020.1080p"
    file_name   "Film.2020.1080p - Croatian - [OpenSubtitles]" (Kodi lists external
                subtitles by their file name)"""
import re

import xbmc
import xbmcaddon

from .hub_base import COLOR_TAG_RE, MULTI_WS_RE, REGIONAL_FLAG_RE, STREAM_ICON_RE
from .sourcefacts.text import ascii_only, flag_code

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

# code, flag, English name, the other ways add-ons and file names write it
LANGUAGES = (
    ('hr', '🇭🇷', 'Croatian', 'hrv cro croatian hrvatski'),
    ('sr', '🇷🇸', 'Serbian', 'srp scc serbian srpski'),
    ('bs', '🇧🇦', 'Bosnian', 'bos bosnian bosanski'),
    ('sl', '🇸🇮', 'Slovenian', 'slv slo slovenian slovene slovenski'),
    ('mk', '🇲🇰', 'Macedonian', 'mkd mac macedonian'),
    ('en', '🇺🇸', 'English', 'eng english'),
    ('de', '🇩🇪', 'German', 'ger deu german deutsch'),
    ('fr', '🇫🇷', 'French', 'fre fra french francais français'),
    ('es', '🇪🇸', 'Spanish', 'spa spanish espanol español'),
    ('it', '🇮🇹', 'Italian', 'ita italian italiano'),
    ('pt-br', '🇧🇷', 'Portuguese BR', 'pob pb brazilian'),
    ('pt', '🇵🇹', 'Portuguese', 'por portuguese portugues'),
    ('nl', '🇳🇱', 'Dutch', 'dut nld dutch nederlands'),
    ('pl', '🇵🇱', 'Polish', 'pol polish polski'),
    ('cs', '🇨🇿', 'Czech', 'cze ces czech cesky'),
    ('sk', '🇸🇰', 'Slovak', 'slk slovak'),
    ('hu', '🇭🇺', 'Hungarian', 'hun hungarian magyar'),
    ('ro', '🇷🇴', 'Romanian', 'rum ron romanian'),
    ('bg', '🇧🇬', 'Bulgarian', 'bul bulgarian'),
    ('el', '🇬🇷', 'Greek', 'gre ell greek'),
    ('tr', '🇹🇷', 'Turkish', 'tur turkish turkce türkçe'),
    ('ru', '🇷🇺', 'Russian', 'rus russian russky'),
    ('uk', '🇺🇦', 'Ukrainian', 'ukr ukrainian'),
    ('sv', '🇸🇪', 'Swedish', 'swe swedish svenska'),
    ('no', '🇳🇴', 'Norwegian', 'nor nob norwegian norsk'),
    ('da', '🇩🇰', 'Danish', 'dan danish dansk'),
    ('fi', '🇫🇮', 'Finnish', 'fin finnish suomi'),
    ('ja', '🇯🇵', 'Japanese', 'jpn japanese'),
    ('ko', '🇰🇷', 'Korean', 'kor korean'),
    ('zh', '🇨🇳', 'Chinese', 'chi zho chinese'),
    ('hi', '🇮🇳', 'Hindi', 'hin hindi'),
    ('fa', '🇮🇷', 'Persian', 'fas per persian farsi'),
)
UNKNOWN = ('🏳️', 'Unknown')
SHOWN = dict((code, (flag, name)) for code, flag, name, _words in LANGUAGES)
CODES = dict((word, code) for code, _flag, _name, words in LANGUAGES for word in [code] + words.split())
# a flag emoji alone: the country's language
COUNTRIES = {'hr': 'hr', 'rs': 'sr', 'ba': 'bs', 'si': 'sl', 'mk': 'mk', 'us': 'en', 'gb': 'en', 'uk': 'en',
             'de': 'de', 'at': 'de', 'fr': 'fr', 'es': 'es', 'it': 'it', 'br': 'pt-br', 'pt': 'pt', 'nl': 'nl',
             'pl': 'pl', 'cz': 'cs', 'sk': 'sk', 'hu': 'hu', 'ro': 'ro', 'bg': 'bg', 'gr': 'el', 'tr': 'tr',
             'ru': 'ru', 'ua': 'uk', 'se': 'sv', 'no': 'no', 'dk': 'da', 'fi': 'fi', 'jp': 'ja',
             'kr': 'ko', 'cn': 'zh', 'in': 'hi', 'ir': 'fa'}
# a file name's language: a whole word for short codes ("Film.HRV.srt"), anywhere for names
_HINTS = [(word, code) for code, _flag, _name, words in LANGUAGES for word in words.split()] + [
    ('jp', 'ja'), ('kr', 'ko'), ('cn', 'zh')] + [(code, code) for code, _flag, _name, _words in LANGUAGES]
_WORD = re.compile(r'[\s._\-\[\]()]+')

LANGUAGE_FIELDS = ('lang', 'language', 'languageCode', 'iso639', 'code', 'name')
NAME_FIELDS = ('displayName', 'label', 'title', 'name', 'release', 'filename', 'fileName')
SOURCE_FIELDS = ('sourceName', 'providerName', 'addonName', 'sourceAddon', 'addonId', 'providerId', 'provider',
                 'addon', 'source', 'origin')
GENERIC = frozenset(('external', 'embedded', 'internal', 'subtitle', 'subtitles', 'sub', 'subs', 'caption',
                     'captions', 'closed captions', 'cc', 'sdh'))
NOT_A_SOURCE = GENERIC | frozenset(('addon', 'stream', 'manual', 'subtitle addon'))
KIND_SHOWN = {'stream': 'Stream', 'manual': 'Manual', 'addon': 'Addon'}
FILE_TYPES = ('srt', 'vtt', 'ass', 'ssa', 'sub', 'sbv', 'idx')
_MEDIA_ENDING = re.compile(r'\.(mkv|mp4|avi|m2ts|ts|mov|wmv|flv|webm|srt|ass|ssa)$', re.I)


def language_key(value):
    """One code for a language however it is written; 'und' when it cannot be told."""
    if isinstance(value, (list, tuple, set)):
        return next((key for key in map(language_key, value) if key and key != 'und'), 'und')
    if isinstance(value, dict):
        return next((key for key in (language_key(value.get(field)) for field in LANGUAGE_FIELDS
                                     if value.get(field)) if key and key != 'und'), 'und')
    text = str(value or 'und').strip()
    if not text:
        return 'und'
    try:
        flagged = REGIONAL_FLAG_RE.sub(flag_code, text)
        if flagged.startswith('[') and flagged.endswith(']') and flagged.strip('[]').lower() in COUNTRIES:
            return COUNTRIES[flagged.strip('[]').lower()]
    except Exception:
        pass
    text = text.lower().replace('_', '-').replace(' ', '-')
    return CODES.get(text) or CODES.get(text.split('-')[0]) or text


def language_from_text(text):
    """The language a release or file name names ("Film.2020.HRV", "croatian.srt"); ''."""
    text = str(text or '').strip().lower()
    if not text:
        return ''
    words = set(_WORD.split(text))
    for hint, code in _HINTS:
        if (hint in words) if len(hint) <= 3 else (hint in text):
            return code
    return ''


def _kodi_name(code):
    try:
        return xbmc.convertLanguage(code, xbmc.ENGLISH_NAME) or ''
    except Exception:
        return ''


def language_of(sub):
    """(code, flag, English name, short code) of a subtitle row; an unknown language is
    looked for in its names, file name and address."""
    given = sub.get('lang') or sub.get('language') or sub.get('languageCode') or sub.get('iso639') or 'und'
    key = language_key(given)
    if key in ('und', ''):
        key = next((found for found in map(language_from_text, [sub.get(field) for field in NAME_FIELDS]
                                           + [sub.get('url'), sub.get('id')]) if found), '') or language_from_text(
            ' '.join(str(sub.get(field) or '') for field in SOURCE_FIELDS[:6] + NAME_FIELDS + ('url', 'id')))
    key = key or 'und'
    fallback = str(given).title() if given else 'Unknown'
    flag, name = SHOWN.get(key) or (UNKNOWN if key == 'und' else ('🏳️', _kodi_name(key) or fallback))
    return key, flag or '', name or fallback, key.split('-')[0].upper()


def basename(value):
    """A file or release name without its media / subtitle ending (plain ASCII)."""
    text = ascii_only(value)
    return _MEDIA_ENDING.sub('', text).strip() if text else ''


def clean(value):
    """A name without colours, flags, icons, a leading hash or track number and underscores."""
    text = basename(value)
    text = STREAM_ICON_RE.sub(' ', REGIONAL_FLAG_RE.sub(' ', COLOR_TAG_RE.sub('', text)))
    text = re.sub(r'^\d{1,3}[._\-\s]+', '', re.sub(r'^[0-9a-f]{12,}[_\-\s]*', '', text, flags=re.I))
    return MULTI_WS_RE.sub(' ', text.replace('_', ' ')).strip(' -|_.')


def source_of(sub):
    """The add-on or server the subtitle came from ('' for a mere kind like "addon")."""
    text = clean(next((sub.get(field) for field in SOURCE_FIELDS if sub.get(field)), ''))
    return '' if text.lower() in NOT_A_SOURCE else text


def release_of(sub):
    """The subtitle's own name (release / file), never the add-on's name again or a word like "Subtitles"."""
    source = source_of(sub).lower()
    for value in (sub.get(field) for field in NAME_FIELDS):
        text = clean(value)
        low = text.lower()
        if not text or low in GENERIC or (source and low == source):
            continue
        if source and low.startswith(source + ' ') and (low[len(source):].strip(' -|_.') or 'sub') in GENERIC:
            continue
        return text
    return ''


def title_of(sub):
    """The line a subtitle is listed with: language, [add-on], release, Forced / SDH."""
    _key, flag, name, code = language_of(sub)
    source, release = source_of(sub), release_of(sub)
    parts = [' '.join(part for part in (flag, name or code) if part).strip() or code]
    if source:
        parts.append('[COLOR cyan]%s[/COLOR]' % source)
    elif str(sub.get('sourceType') or '').strip().lower() in KIND_SHOWN:
        parts.append('[COLOR grey]%s[/COLOR]' % KIND_SHOWN[str(sub.get('sourceType')).strip().lower()])
    if release and release.lower() != source.lower():
        parts.append(release)
    parts += [mark for field, mark in (('forced', 'Forced'), ('hearingImpaired', 'SDH')) if sub.get(field)]
    return ' · '.join(part for part in parts if part).strip()


def summary(subtitles):
    """The first four subtitles' lines (each once), then "+N"."""
    if not subtitles:
        return ''
    lines = []
    for sub in subtitles[:4]:
        line = title_of(sub)
        if line not in lines:
            lines.append(line)
    if len(subtitles) > 4:
        lines.append('+%d' % (len(subtitles) - 4))
    return ' | '.join(lines)


def file_part(value, limit=48):
    """A name made safe for a file name, at most `limit` characters."""
    text = MULTI_WS_RE.sub(' ', re.sub(r'[^\w\- ]+', ' ', clean(value), flags=re.UNICODE)).strip(' -|_.')
    return text[:limit].strip()


def extension_of(sub, url):
    """The subtitle's file type: its format / codec, else its address' ending, else srt."""
    given = str(sub.get('format') or sub.get('codec') or '').lower().replace('/', '').strip('.').strip()
    if given in FILE_TYPES:
        return given
    from urllib.parse import urlparse
    try:
        path = urlparse(str(url or '')).path or ''
    except Exception:
        path = ''
    ending = path.rsplit('.', 1)[-1].lower().strip() if '.' in path else ''
    return ending if ending in FILE_TYPES else (given or 'srt')


def file_name(sub, url, taken, work_title=''):
    """'<release> - <Language> [- [<add-on>]]', unique among `taken` (lower case, updated),
    with its file type. Without a release name the film's title leads, never the add-on's."""
    key, _flag, name, code = language_of(sub)
    language = re.sub(r'[<>:"/\\|?*]+', ' ', name if name and name.lower() != 'unknown' else code).strip() or code
    source = file_part(source_of(sub), 36) if source_of(sub) else ''
    release = file_part(release_of(sub), 60) if release_of(sub) else ''
    lead = release or (file_part(work_title, 60) if source and work_title else '')
    if lead:
        parts = [lead, language] + (['[%s]' % source] if source and source.lower() != lead.lower() else [])
    elif source:
        parts = [source, language]
    else:
        kind = str(sub.get('sourceType') or '').strip().lower()
        parts = [kind.title(), language]
    base = ' - '.join(part for part in parts if part)
    unique, number = base, 1
    while unique.lower() in taken:
        number += 1
        unique = '%s (%d)' % (base, number)
    taken.add(unique.lower())
    return '%s.%s' % (unique, extension_of(sub, url)), key


# ---- the user's languages ------------------------------------------------------------------


def wanted_keys():
    """The preferred subtitle languages as codes, in order (English when none is set)."""
    try:
        chosen = str(ADDON.getSetting('preferred_subtitle_langs') or 'en')
    except Exception:
        chosen = 'en'
    keys = []
    for part in chosen.split(','):
        key = language_key(part) if part.strip() else ''
        if key and key not in keys:
            keys.append(key)
    return keys or ['en']


def pick_mode():
    """'play_with_subtitles' when the subtitle mode shows them at the start, else 'play'."""
    try:
        mode = str(ADDON.getSetting('subtitle_search_mode') or '').strip().lower()
    except Exception:
        mode = ''
    return 'play_with_subtitles' if any(word in mode for word in (
        'with subtitle', 'play_with_subtitles', 'auto', 'playback')) else 'play'


def default_index(subtitles, ctx=None):
    """The subtitle to start with: one marked selected / default, then the user's languages in
    order, not forced, the first; AI subtitles only when chosen by hand. -1 when none."""
    from .subtitle_choice import allow_automatic
    wanted = wanted_keys()

    def place(sub):
        key = language_key(sub.get('lang') or sub.get('languageCode') or sub.get('language') or 'und')
        base = key.split('-')[0].lower() if key else ''
        for index, want in enumerate(wanted):
            want = language_key(want)
            if key == want or (base and base == want.split('-')[0].lower()):
                return index
        return len(wanted) + 10
    ranked = [((0 if (sub.get('selected') or sub.get('default')) else 1, place(sub), 1 if sub.get('forced') else 0,
                index), index) for index, sub in enumerate(subtitles or []) if allow_automatic(sub)]
    return min(ranked)[1] if ranked else -1


def choose_on_player(player, show=False, attempts=4, delay_ms=400):
    """Switch the playing video to its first subtitle track in the user's languages (Kodi
    loads the tracks a moment after the start, so it looks a few times); `show` also
    turns subtitles on. False when no track is in those languages."""
    wanted = [key.split('-')[0].lower() for key in wanted_keys() if key]
    for _attempt in range(max(1, attempts)):
        try:
            tracks = player.getAvailableSubtitleStreams() or []
        except Exception:
            tracks = []
        if tracks:
            bases = [(str(code or '').split('-')[0] or '').strip().lower() for code in tracks]
            index = next((bases.index(want) for want in wanted if want in bases), -1)
            if index < 0:
                return False
            try:
                player.setSubtitleStream(index)
                if show:
                    player.showSubtitles(True)
            except Exception:
                return False
            xbmc.log('[MegaNexus] auto-selected subtitle stream #%d (%s) from %d available'
                     % (index, tracks[index], len(tracks)), xbmc.LOGINFO)
            return True
        xbmc.sleep(delay_ms)
    return False
