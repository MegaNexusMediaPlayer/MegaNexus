# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Collections shared as JSON (Nuvio / Fusion Widgets exports, Plexio collections.json,
stremiolabar share links) turned into saved sets (collection_sets.json).

The files come in several shapes; `read_entries` brings them to one list of entries:

    [entry, ...]                               plain list
    [{"title", "folders": [entry, ...]}, ...]  groups of folders (share links)
    {"collections" | "widgets" | "entries" | "items" | "folders": [...]}
    {"exportType": "fusionWidgets", "widgets": [{"dataSource": {"kind": "collection",
        "payload": {"items": [entry, ...]}}}]}   widget shells around the real entries

An entry is either several catalogs of add-ons (`catalogSources` -> kind multiCatalog)
or one data source (`dataSource` / the first of `dataSources`). Add-ons are named by
their manifest id; `add_from_text` finds or adds each one (`find_addon`)."""
import base64
import gzip
import hashlib
import io
import json
import os
import ssl
import uuid
from urllib.parse import urlparse, urlunparse

from .meganexus import addon_registry as _addon_registry
from .meganexus.addon_wire import manifest_ok
from .meganexus.paths import profile_path

SETS_FILE = os.path.join(profile_path(), 'collection_sets.json')
# public catalog add-ons collection files name by id only (an installed add-on always wins)
KNOWN_ADDON_MANIFESTS = {
    'pw.ers.netflix-catalog': 'https://7a82163c306e-stremio-netflix-catalog-addon.baby-beamup.club/manifest.json',
}
# add-ons that only work with the user's own configured manifest (their public one lists nothing)
CONFIG_REQUIRED_ADDONS = {'com.stremio.plexio', 'com.stremio.plexbridge', 'plexio', 'plexbridge', 'streambridge',
                          'com.stremio.streambridge'}
CONFIG_WORDS = ('plexio', 'plexbridge', 'streambridge')
LIST_KEYS = ('collections', 'widgets', 'entries', 'items', 'folders')
FUSION_EXPORTS = ('fusionwidgets', 'fusion_widgets', 'fusion-widget-export')
GENERIC_NAMES = (None, '', 'Folder', 'Collection')
SERIES_WORDS, KNOWN_TYPES = ('series', 'show', 'tv'), ('movie', 'series', 'anime')
WIDE_ASPECTS = ('wide', 'landscape', 'banner', '16:9', '16x9')
WIDE_SHAPES = ('landscape', 'wide', 'banner')
LOGO_KEYS = ('clearlogo', 'clearLogoUrl', 'clearLogoURL', 'titleLogoUrl', 'titleLogoURL', 'titleLogo', 'logo', 'logoURL',
             'logoUrl')
PICTURE_KEYS = ('backgroundImageURL', 'coverImageUrl', 'imageURL', 'imageUrl', 'poster', 'posterURL', 'posterUrl')
FETCH_TIMEOUT = 20
_kept = {'rows': None, 'mtime': None}


# ---- the file ------------------------------------------------------------------------

def _mtime():
    try:
        return os.path.getmtime(SETS_FILE)
    except Exception:
        return None


def list_sets():
    mtime = _mtime()
    if _kept['rows'] is not None and mtime == _kept['mtime']:
        return list(_kept['rows'])
    rows = []
    try:
        with open(SETS_FILE, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if isinstance(data, list):
            rows = data
    except Exception:
        pass
    _kept['rows'], _kept['mtime'] = rows, mtime
    return list(rows)


def _save(rows):
    from .meganexus.json_files import write_json   # atomic: a crash mid-save keeps the old file
    write_json(SETS_FILE, rows)
    _kept['rows'], _kept['mtime'] = list(rows), _mtime()


# ---- reading the shapes ----------------------------------------------------------------

def manifest_of_collection(url):
    """Plexio's .../collections.json -> the .../manifest.json beside it ('' for other addresses)."""
    url = str(url or '').strip()
    if not url.lower().startswith(('http://', 'https://')):
        return ''
    try:
        parts = urlparse(url)
        if (parts.path or '').lower().endswith('/collections.json'):
            path = parts.path[:-len('collections.json')] + 'manifest.json'
            return urlunparse((parts.scheme, parts.netloc, path, parts.params, parts.query, parts.fragment))
    except Exception:
        pass
    at = url.lower().find('/collections.json')
    return url[:at] + '/manifest.json' + url[at + len('/collections.json'):] if at >= 0 else ''


def normalize_catalog_id_and_type(catalog_id, catalog_type='movie'):
    """("movie::plex-col-1", ...) -> ("plex-col-1", "movie"); tv / show -> series, movies -> movie."""
    catalog = str(catalog_id or '').strip()
    kind = str(catalog_type or '').strip() or 'movie'
    head, sep, tail = catalog.partition('::')
    if sep and head.strip().lower() in ('movie', 'movies', 'series', 'show', 'tv', 'anime') and tail.strip():
        catalog = tail.strip()
        head = head.strip().lower()
        kind = 'series' if head in SERIES_WORDS else 'anime' if head == 'anime' else 'movie'
    low = kind.lower()
    if low in ('tv', 'show', 'shows'):
        kind = 'series'
    elif low == 'movies':
        kind = 'movie'
    return catalog, kind


def _first(raw, keys):
    return next((raw.get(key) for key in keys if raw.get(key)), '')


def _catalog_sources(raw):
    found = []
    for source in raw.get('catalogSources') or raw.get('catalog_sources') or []:
        if not isinstance(source, dict):
            continue
        addon = (source.get('addonId') or source.get('addon_id') or '').strip()
        catalog, kind = normalize_catalog_id_and_type((source.get('catalogId') or source.get('catalog_id') or '').strip(),
                                                      (source.get('type') or source.get('catalogType') or 'movie').strip())
        if addon and catalog:
            found.append({'addonId': addon, 'catalogId': catalog, 'catalogType': kind,
                          'genre': source.get('genre') or '', 'extra': source.get('extra') or {}})
    return found


def _entry(raw):
    """One clean entry of a raw one, None when it can not be used."""
    if not isinstance(raw, dict):
        return None
    sources = raw.get('catalogSources') or raw.get('catalog_sources') or []
    if isinstance(sources, list) and sources:
        cleaned = _catalog_sources(raw)
        if cleaned:
            return {
                'id': str(raw.get('id') or uuid.uuid4().hex[:12]),
                'name': str(raw.get('title') or raw.get('name') or 'Folder').strip() or 'Folder',
                'layout': 'Wide' if (raw.get('tileShape') or '').upper() == 'LANDSCAPE' else 'Poster',
                'background': str(raw.get('coverImageUrl') or raw.get('focusGifUrl') or raw.get('backgroundImageURL')
                                  or '').strip(),
                'clearlogo': str(_first(raw, LOGO_KEYS) or '').strip(),
                'hide_title': bool(raw.get('hideTitle') or False),
                'kind': 'multiCatalog',
                'payload': {'sources': cleaned},
                'open_mode': str(raw.get('open_mode') or raw.get('openMode') or 'skip').strip() or 'skip',   # like a widget
            }
    source = raw.get('dataSource') or {}
    if not source or not isinstance(source, dict):
        listed = raw.get('dataSources') or []
        source = listed[0] if listed and isinstance(listed[0], dict) else {}
    kind = (source.get('kind') or '').strip()
    payload = source.get('payload') or {}
    if not kind or not isinstance(payload, dict):
        return None
    payload = dict(payload)
    if kind == 'addonCatalog':
        catalog, catalog_kind = normalize_catalog_id_and_type(payload.get('catalogId') or payload.get('catalog_id') or '',
                                                              payload.get('catalogType') or payload.get('type') or 'movie')
        if catalog:
            payload['catalogId'] = catalog
        if catalog_kind:
            payload['catalogType'] = catalog_kind
    aspect = str(raw.get('imageAspect') or raw.get('image_aspect') or '').strip().lower()
    shape = str(raw.get('tileShape') or raw.get('tile_shape') or '').strip().lower()
    layout = str(raw.get('layout') or '').strip() or ('Wide' if aspect in WIDE_ASPECTS or shape in WIDE_SHAPES else 'Poster')
    picture = str(raw.get('backgroundImageURL') or raw.get('coverImageUrl') or raw.get('imageURL') or raw.get('imageUrl')
                  or '').strip()
    poster = str(raw.get('poster') or raw.get('posterURL') or raw.get('posterUrl') or '').strip()
    return {
        'id': str(raw.get('id') or uuid.uuid4().hex[:12]),
        'name': str(raw.get('name') or raw.get('title') or 'Collection').strip() or 'Collection',
        'layout': layout,
        'background': picture or poster,
        'image_aspect': aspect,
        'poster': poster,
        'clearlogo': str(_first(raw, LOGO_KEYS) or '').strip(),
        'hide_title': bool(raw.get('hideTitle') or False),
        'kind': kind,
        'payload': payload,
    }


def _from_widget(widget):
    """A Fusion widget shell -> its real entries (its picture and title lent to generic ones)."""
    if not isinstance(widget, dict):
        return [widget]
    source = widget.get('dataSource') or {}
    payload = source.get('payload') or {}
    items = payload.get('items') if isinstance(payload, dict) else None
    if str(source.get('kind') or '').strip().lower() != 'collection' or not isinstance(items, list) or not items:
        return [widget]
    out = []
    for child in items:
        if not isinstance(child, dict):
            continue
        row = dict(child)
        lent = next((key for key in PICTURE_KEYS if not row.get(key) and widget.get(key)), None)
        if lent:
            row[lent] = widget.get(lent)
        for key in ('title', 'name'):
            if row.get(key) in GENERIC_NAMES and widget.get(key):
                row[key] = widget.get(key)
        out.append(row)
    return out or [widget]


def _unwrap_widgets(data):
    if isinstance(data, dict):
        kind = str(data.get('exportType') or data.get('type') or '').strip().lower()
        widgets = data.get('widgets') if isinstance(data.get('widgets'), list) else None
        if widgets and kind in FUSION_EXPORTS:
            return [row for widget in widgets for row in _from_widget(widget)]
        return data
    if isinstance(data, list):
        return [row for item in data for row in _from_widget(item)]
    return data


def _open_groups(data):
    """Groups with folders -> their folders (a generic folder name takes the group's)."""
    out = []
    for item in data:
        if isinstance(item, dict) and isinstance(item.get('folders'), list):
            for folder in item['folders']:
                if isinstance(folder, dict):
                    if folder.get('title') in GENERIC_NAMES:
                        folder = dict(folder, title=item.get('title') or folder.get('title') or 'Folder')
                    out.append(folder)
        else:
            out.append(item)
    return out


def collection_rows(text):
    """Every usable entry of a collection file (ValueError when there is none)."""
    try:
        data = json.loads(text)
    except Exception:
        try:
            data = json.loads(text.strip().lstrip('﻿'))
        except Exception:
            raise ValueError('Invalid JSON')
    data = _unwrap_widgets(data)
    if isinstance(data, dict):
        data = next((data[key] for key in LIST_KEYS if isinstance(data.get(key), list)), [data])
    data = _unwrap_widgets(data)
    if not isinstance(data, list):
        raise ValueError('The file does not contain a list of items')
    entries = [entry for entry in map(_entry, _open_groups(data)) if entry]
    if not entries:
        raise ValueError('No valid items were found in the file')
    return entries


# ---- the add-ons an entry names ---------------------------------------------------------

def _plain_manifest(url):
    url = str(url or '').strip()
    return url[:-1] if url.lower().endswith('/manifest.json/') else url


def addon_by_id(addon_id):
    """The installed add-on with this manifest id; Plexio / StreamBridge matched loosely (a
    configured server answers as com.stremio.plexbridge while files say com.stremio.plexio)."""
    if not addon_id:
        return None
    addon_id = str(addon_id).strip().lower()
    plexio = 'plexio' in addon_id or 'plexbridge' in addon_id or addon_id == 'plexbridge'
    bridge = 'streambridge' in addon_id or addon_id.startswith('sb.')
    for row in _addon_registry.list_providers():
        manifest = row.get('manifest') or {}
        mid = str(manifest.get('id') or '').strip().lower()
        url = str(row.get('manifest_url') or '').strip().lower()
        name = str(row.get('name') or manifest.get('name') or '').strip().lower()
        if mid and mid == addon_id:
            return row
        if plexio and (mid in ('com.stremio.plexbridge', 'com.stremio.plexio') or 'plexio' in url or 'plexio' in name
                       or 'plexbridge' in name):
            return row
        if bridge and (mid == 'com.stremio.streambridge' or 'streambridge' in url or 'streambridge' in name
                       or 'emby' in name):
            return row
    return None


def known_manifest_for_addon_id(addon_id):
    return _plain_manifest(KNOWN_ADDON_MANIFESTS.get(str(addon_id or '').strip().lower(), ''))


def needs_setup(addon_id):
    addon_id = str(addon_id or '').strip().lower()
    return addon_id in CONFIG_REQUIRED_ADDONS or any(w in addon_id for w in CONFIG_WORDS) or addon_id.startswith('sb.')


def addon_known(manifest_url):
    """The add-on of this manifest - the installed one, or added after its manifest checked out."""
    manifest_url = _plain_manifest(manifest_url)
    for row in _addon_registry.list_providers():
        if _plain_manifest(row.get('manifest_url')) == manifest_url:
            return row
    manifest = manifest_ok(manifest_url)
    return _addon_registry.add_provider(manifest.get('name') or 'Addon', manifest_url, manifest)


def addon_for_id(addon_id, manifest_resolver=None, share_url=''):
    """The add-on for an id: installed, the id as a manifest address, a known public one, or
    what `manifest_resolver` (the user) gives - never the empty public shell of an add-on
    that needs the user's configuration."""
    addon_id = str(addon_id or '').strip()
    if not addon_id:
        return None
    found = addon_by_id(addon_id)
    if found:
        return found
    if addon_id.startswith(('http://', 'https://')):
        try:
            return addon_known(addon_id)
        except Exception:
            return None
    known = known_manifest_for_addon_id(addon_id)
    if known:
        try:
            return addon_known(known)
        except Exception:
            pass
    if not manifest_resolver:
        return None
    try:
        answer = manifest_resolver(addon_id, share_url)
        return addon_known(answer) if answer else None
    except Exception:
        return None


def addon_ids_in(entries):
    """The add-on ids the entries name, each once, in order."""
    found = []
    for entry in entries or []:
        payload = entry.get('payload') or {}
        if entry.get('kind') == 'addonCatalog':
            ids = [payload.get('addonId')]
        elif entry.get('kind') == 'multiCatalog':
            ids = [source.get('addonId') for source in payload.get('sources') or []]
        else:
            ids = []
        for addon_id in ids:
            addon_id = (addon_id or '').strip()
            if addon_id and addon_id not in found:
                found.append(addon_id)
    return found


# ---- saving ----------------------------------------------------------------------------

def add_set_from_text(text, source_label='Entered manually', manifest_resolver=None):
    """A collection file saved as a set (the same text replaces its earlier copy); its add-ons
    found or added first."""
    entries = collection_rows(text)
    for addon_id in addon_ids_in(entries):
        addon_for_id(addon_id, manifest_resolver=manifest_resolver, share_url='')
    row = {'id': hashlib.sha1(text.encode('utf-8')).hexdigest()[:12], 'name': source_label or 'Collection Set',
           'source_url': '', 'entries': entries}
    _save([r for r in list_sets() if r.get('id') != row['id']] + [row])
    return row


def import_sets(rows):
    """Backup / shared sets merged in (the same id replaces); returns how many."""
    incoming = []
    for row in rows or []:
        if not isinstance(row, dict) or not isinstance(row.get('entries') or [], list):
            continue
        entries = row.get('entries') or []
        key = str(row.get('id') or '').strip() or hashlib.sha1(
            json.dumps(entries, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()[:12]
        incoming.append({'id': key, 'name': str(row.get('name') or row.get('title') or 'Shared Collection').strip(),
                         'source_url': str(row.get('source_url') or row.get('source') or '').strip(), 'entries': entries})
    if not incoming:
        return 0
    replaced = {row['id'] for row in incoming}
    _save([row for row in list_sets() if row.get('id') not in replaced] + incoming)
    return len(incoming)


# ---- fetching a shared file -------------------------------------------------------------

def _share_token_text(token):
    """A stremiolabar share link carries the whole file: URL-safe base64 of (usually gzipped) JSON."""
    if not token:
        return None
    try:
        try:
            raw = base64.urlsafe_b64decode(token + '=' * ((4 - len(token) % 4) % 4))
        except Exception:
            fixed = token.replace('-', '+').replace('_', '/')
            raw = base64.b64decode(fixed + '=' * ((4 - len(fixed) % 4) % 4))
        try:
            raw = gzip.decompress(raw)
        except Exception:
            pass
        return raw.decode('utf-8', 'replace')
    except Exception as exc:
        import xbmc
        xbmc.log('[MegaNexus] share token decode failed: %s' % exc, xbmc.LOGDEBUG)
        return None


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] fetch_raw_text ' + text, xbmc.LOGINFO)
    except Exception:
        pass


def _body(response):
    body = response.read()
    if 'gzip' in (response.headers.get('Content-Encoding') or '').lower():
        try:
            body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
        except Exception:
            pass
    return body.decode('utf-8', 'replace')


def text_of(url):
    """A shared collection file's text: decoded from a share link itself, else fetched - with a
    second try without certificate checks (some CoreELEC builds carry a cut CA store) and a
    third through `requests` when it is installed."""
    from urllib.request import Request, urlopen
    if '/api/share/' in (url or ''):
        decoded = _share_token_text(url.rsplit('/api/share/', 1)[-1].split('?', 1)[0].split('#', 1)[0])
        if decoded:
            return decoded
    try:
        import xbmcaddon
        version = xbmcaddon.Addon().getAddonInfo('version') or '8.1.0'
    except Exception:
        version = '8.1.0'
    headers = {'Accept': 'application/json, text/plain, */*', 'Accept-Encoding': 'gzip',
               'User-Agent': 'MegaNexus/%s (Kodi)' % version}
    failure = None
    try:
        with urlopen(Request(url, headers=headers), timeout=FETCH_TIMEOUT) as response:
            return _body(response)
    except Exception as exc:
        failure = exc
        _log('default fetch failed: %s — trying unverified SSL' % exc)
    try:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        with urlopen(Request(url, headers=headers), timeout=FETCH_TIMEOUT, context=context) as response:
            _log('succeeded with unverified SSL')
            return _body(response)
    except Exception as exc:
        failure = exc
        _log('unverified SSL failed: %s' % exc)
    try:
        import requests  # type: ignore
        response = requests.get(url, headers=headers, timeout=FETCH_TIMEOUT)
        response.raise_for_status()
        _log('succeeded via requests library')
        return response.text
    except ImportError:
        pass
    except Exception as exc:
        failure = exc
    raise failure if failure else IOError('Unknown fetch failure')
