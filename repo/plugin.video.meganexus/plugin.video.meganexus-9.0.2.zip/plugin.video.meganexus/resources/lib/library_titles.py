# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Library's own titles (favorites.db): what the user saved here, and a mirror of the
watchlists of Trakt, Simkl and MDBList (one card per title; library_origins.json tells which
services hold it). Home's Favorites row reads the mirror, so it stays instant when a
service is slow or offline. Rows have the Continue Watching shape."""
import os
import sqlite3
import threading
import time
import xbmc

from .meganexus.paths import profile_path

DB_PATH = os.path.join(profile_path(), 'favorites.db')
ORIGINS_PATH = os.path.join(profile_path(), 'library_origins.json')   # mirror row -> service (6.0.35)
COLUMNS = ('media_type', 'canonical_id', 'title', 'poster', 'background', 'clearlogo', 'year', 'plot', 'source',
           'added_at')
TABLE = ('CREATE TABLE IF NOT EXISTS favorites (media_type TEXT NOT NULL, canonical_id TEXT NOT NULL, title TEXT, '
         'poster TEXT, background TEXT, clearlogo TEXT, year INTEGER, plot TEXT, '
         "source TEXT NOT NULL DEFAULT 'local', added_at INTEGER, PRIMARY KEY (media_type, canonical_id, source))")
INDEXES = (('idx_fav_added', 'added_at DESC'), ('idx_fav_source', 'source'),
           ('idx_fav_identity', 'media_type, canonical_id'))
FILLED = ('title', 'poster', 'background', 'clearlogo', 'year', 'plot')
MIRROR = 'trakt'                      # the mirror's source name (all services, stored as before)
_made = [False]
_lock = threading.Lock()


def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=2.0)
    try:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
    except Exception:
        pass
    return conn


class _Opened(object):
    """A connection, closed on leaving; committed when nothing failed."""

    def __enter__(self):
        _ensure_db()
        self.conn = _connect()
        return self.conn

    def __exit__(self, failed, *_rest):
        try:
            if not failed:
                self.conn.commit()
        finally:
            self.conn.close()
        return False


def _table_text(conn):
    try:
        row = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='favorites'").fetchone()
        return row[0] if row and row[0] else ''
    except Exception:
        return ''


def _ensure_db():
    """The table (a file from before the per-source key is moved over once)."""
    if _made[0]:
        return
    with _lock:
        if _made[0]:
            return
        conn = _connect()
        try:
            text = _table_text(conn).lower().replace('\n', ' ')
            if text and 'primary key (media_type, canonical_id, source)' not in text:
                conn.execute('ALTER TABLE favorites RENAME TO favorites_legacy')
                conn.execute(TABLE)
                conn.execute('INSERT OR REPLACE INTO favorites (%s) SELECT media_type, canonical_id, title, poster, '
                             "background, clearlogo, year, plot, COALESCE(NULLIF(source, ''), 'local'), added_at "
                             'FROM favorites_legacy' % ', '.join(COLUMNS))
                conn.execute('DROP TABLE favorites_legacy')
            elif not text:
                conn.execute(TABLE)
            for name, columns in INDEXES:
                conn.execute('CREATE INDEX IF NOT EXISTS %s ON favorites(%s)' % (name, columns))
            conn.commit()
        finally:
            conn.close()
        _made[0] = True


def _mark_sync_dirty():
    try:
        import xbmcgui
        # 7.0.44: its own mark - the progress sync cleared the shared one without
        # sending the Library (progress_sync.LIBRARY_DIRTY)
        xbmcgui.Window(10000).setProperty('meganexus.library_dirty', str(time.time_ns()))
    except Exception:
        pass


def add(media_type, canonical_id, title, poster='', background='', clearlogo='', year=0, plot='', source='local',
        added_at=0):
    """Save a title (again: newer pictures, year and plot replace empty ones).

    8.1.2: ``added_at`` is when it was really saved - the date the service it came from
    gives. Without it this stamped "now" on every write, AND overwrote the date on every
    later write, so a library that is synced every few minutes ended up looking as
    though every title had been added this month: "kalendar... pise svi u jednom
    mjesecu". The earliest date we know of is the one that is kept.
    """
    keep = ', '.join("%s=CASE WHEN excluded.%s %s THEN excluded.%s ELSE favorites.%s END"
                     % (name, name, '> 0' if name == 'year' else "!= ''", name, name)
                     for name in ('poster', 'background', 'clearlogo', 'year', 'plot'))
    when = int(added_at or 0) or int(time.time())
    with _Opened() as conn:
        conn.execute('INSERT INTO favorites (%s) VALUES (%s) ON CONFLICT(media_type, canonical_id, source) DO UPDATE SET '
                     'title=excluded.title, %s, added_at=CASE WHEN favorites.added_at>0 AND '
                     '(excluded.added_at=0 OR excluded.added_at>favorites.added_at) '
                     'THEN favorites.added_at ELSE excluded.added_at END'
                     % (', '.join(COLUMNS), ','.join('?' * 10), keep),
                     (media_type or 'movie', canonical_id or '', title or canonical_id or '', poster or '',
                      background or '', clearlogo or '', int(year or 0), plot or '', source or 'local', when))
    if (source or 'local') != 'nuvio':
        _mark_sync_dirty()


def remove(media_type, canonical_id, source=None):
    """Remove a title (from one source, or from all)."""
    with _Opened() as conn:
        conn.execute('DELETE FROM favorites WHERE media_type=? AND canonical_id=?' + (' AND source=?' if source else ''),
                     (media_type or '', canonical_id or '') + ((source,) if source else ()))
    _mark_sync_dirty()


def favorite_keys():
    with _Opened() as conn:
        rows = conn.execute('SELECT media_type, canonical_id FROM favorites GROUP BY media_type, canonical_id').fetchall()
    return set((str(row[0] or ''), str(row[1] or '')) for row in rows or [])


def _row(values):
    row = dict(zip(COLUMNS, values))
    row['source'] = row['source'] or 'local'
    row['sources'] = [row['source']]
    return row


def list_favorites(limit=200, source=None):
    """Saved titles, newest first. With `source` its rows as they are; else one per title: the
    sources it has ('mixed' when several), empty fields filled from another source's row, the
    newest save time."""
    with _Opened() as conn:
        if source:
            rows = conn.execute('SELECT %s FROM favorites WHERE source=? ORDER BY added_at DESC LIMIT ?'
                                % ', '.join(COLUMNS), (source, limit)).fetchall()
            return [dict(_row(values), source=values[8], sources=[values[8]]) for values in rows]
        rows = conn.execute("SELECT %s FROM favorites ORDER BY added_at DESC, CASE WHEN source='local' THEN 0 ELSE 1 END"
                            % ', '.join(COLUMNS)).fetchall()
    titles, order = {}, []
    for values in rows:
        row = _row(values)
        key = (row['media_type'], row['canonical_id'])
        known = titles.get(key)
        if known is None:
            titles[key] = row
            order.append(row)
            continue
        known['sources'] = sorted(set(known['sources']) | {row['source']})
        if row['source'] != known['source']:
            known['source'] = 'mixed'
        for field in FILLED:
            if not known.get(field) and row.get(field):
                known[field] = row[field]
        known['added_at'] = max(int(known.get('added_at') or 0), int(row.get('added_at') or 0))
    order.sort(key=lambda row: int(row.get('added_at') or 0), reverse=True)
    return order[:max(0, int(limit or 0))] if limit else order


def replace_trakt_mirror(rows):
    """The mirror rows replaced by these (one bad row never stops the rest)."""
    with _Opened() as conn:
        conn.execute('DELETE FROM favorites WHERE source=?', (MIRROR,))
        for row in rows or []:
            try:
                conn.execute('INSERT OR REPLACE INTO favorites (%s) VALUES (%s)' % (', '.join(COLUMNS), ','.join('?' * 10)),
                             (row.get('media_type') or 'movie', row.get('canonical_id') or '',
                              row.get('title') or row.get('canonical_id') or '', row.get('poster') or '',
                              row.get('background') or '', row.get('clearlogo') or '', int(row.get('year') or 0),
                              row.get('plot') or '', MIRROR, int(row.get('added_at') or 0)))
            except Exception:
                continue


def count(source=None):
    """Distinct titles (of one source)."""
    with _Opened() as conn:
        found = conn.execute('SELECT COUNT(*) FROM (SELECT 1 FROM favorites%s GROUP BY media_type, canonical_id)'
                             % (' WHERE source=?' if source else ''), (source,) if source else ()).fetchone()[0]
    return int(found or 0)


def _switched_on(key):
    try:
        import xbmcaddon
        return (xbmcaddon.Addon('plugin.video.meganexus').getSetting(key) or 'true').strip().lower() == 'true'
    except Exception:
        return True


def refresh_list_copy(include_trakt=True):
    """The watchlists of Trakt, Simkl (watchlist_merge_simkl) and MDBList (watchlist_merge_mdblist)
    into the mirror: one card per title, the first service's row; a title keeps the date it was
    first seen when the service gives none (6.0.35, Library). How many titles."""
    first_seen = dict(((row['media_type'], row['canonical_id']), int(row.get('added_at') or 0))
                      for row in list_favorites(limit=5000, source=MIRROR))
    titles, taken, origins = [], set(), {}

    def take(rows, service):
        for row in rows or []:
            key = (row.get('media_type'), row.get('canonical_id'))
            if not key[1]:
                continue
            holders = origins.setdefault('%s|%s' % ('movie' if key[0] == 'movie' else 'series', key[1]), [])
            if service not in holders:
                holders.append(service)
            if key not in taken:
                taken.add(key)
                # 8.1.2: no invented date. A row with none keeps 0 and the Calendar puts
                # it under "Date unknown" instead of claiming it was saved today.
                titles.append(dict(row, added_at=int(row.get('added_at') or 0) or first_seen.get(key) or 0))

    def from_service(service, ask):
        try:
            rows = ask()
            if rows is not None:
                take(rows, service)
        except Exception as exc:
            xbmc.log('[MegaNexus] watchlist mirror (%s) failed: %s' % (service, exc), xbmc.LOGDEBUG)

    def trakt_rows():
        from . import trakt_api
        return (trakt_api.fetch_watchlist(limit=200) or []) if trakt_api.enabled() else None

    def simkl_rows():
        from . import simkl_api
        return simkl_api.watchlist_copy_rows(limit=200) \
            if simkl_api.enabled() and simkl_api.authorized() and _switched_on('watchlist_merge_simkl') else None

    def mdblist_rows():
        from . import mdblist_api
        return mdblist_api.watchlist_copy_rows(limit=200) \
            if mdblist_api.configured() and _switched_on('watchlist_merge_mdblist') else None
    for service, ask in (('trakt', trakt_rows), ('simkl', simkl_rows), ('mdblist', mdblist_rows)):
        if service != 'trakt' or include_trakt:
            from_service(service, ask)
    replace_trakt_mirror(titles)
    try:
        from .meganexus.json_files import write_json
        write_json(ORIGINS_PATH, origins)
    except Exception:
        pass
    return len(titles)
