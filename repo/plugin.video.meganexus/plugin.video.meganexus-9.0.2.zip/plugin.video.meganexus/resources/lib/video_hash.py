# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The playing file's OpenSubtitles hash (8.1.5) - what Stremio sends subtitle add-ons.

The hash is the file's size plus its first and last 64 KB read as 64-bit numbers; two
small range requests, nothing else of the film. With it (videoHash, videoSize) the
OpenSubtitles add-on marks a subtitle found by this very file with m: "h" - made for
exactly this release, so Autosync trusts it right after the video's own subtitles, and
it needs no syncing. Without it every match was by IMDb id only (m: "i").
"""
import re
import struct
from urllib.request import Request, urlopen

CHUNK = 64 * 1024
TIMEOUT = 6
_known = {}                    # address -> (hash, size), this run


def _read(url, headers, start, end, timeout=TIMEOUT):
    request = Request(url, headers=dict(headers or {}, Range='bytes=%d-%d' % (start, end)))
    with urlopen(request, timeout=timeout) as reply:
        status = getattr(reply, 'status', None) or reply.getcode()
        data = reply.read(end - start + 1)
        whole = re.search(r'/(\d+)\s*$', reply.headers.get('Content-Range') or '')
    if status != 206 or not whole:
        raise ValueError('no range requests')
    return data, int(whole.group(1))


def compute(url, headers=None, timeout=TIMEOUT):
    """(16-hex hash, size) of the file at ``url``, or None when it cannot be read. ``timeout``
    for each of the two reads - the subtitle search keeps to its own deadline."""
    try:
        from .mkv_subtitle_times import kodi_headers
        headers = kodi_headers(dict(headers or {}, **_url_headers(url)))
    except Exception:
        pass
    url = str(url or '').split('|', 1)[0]
    if not url.startswith(('http://', 'https://')):
        return None
    try:
        from .mkv_subtitle_times import web_address
        url = web_address(url)
    except Exception:
        pass
    if url in _known:
        return _known[url]
    try:
        head, size = _read(url, headers, 0, CHUNK - 1, timeout)
        if size < 2 * CHUNK or len(head) < CHUNK:
            return None
        tail, _ = _read(url, headers, size - CHUNK, size - 1, timeout)
        if len(tail) < CHUNK:
            return None
    except Exception:
        return None
    value = size
    for block in (head[:CHUNK], tail[-CHUNK:]):
        for (word,) in struct.iter_unpack('<Q', block):
            value = (value + word) & 0xFFFFFFFFFFFFFFFF
    found = ('%016x' % value, size)
    _known[url] = found
    return found


def _url_headers(url):
    """The headers Kodi carries after '|' in a playback address (url|Referer=...&User-Agent=...)."""
    from urllib.parse import parse_qsl
    text = str(url or '')
    return dict(parse_qsl(text.split('|', 1)[1])) if '|' in text else {}


def matched(row):
    """The subtitle add-on found this subtitle by the file's hash: made for this release."""
    return str((row or {}).get('m') or '').strip().lower() == 'h'
