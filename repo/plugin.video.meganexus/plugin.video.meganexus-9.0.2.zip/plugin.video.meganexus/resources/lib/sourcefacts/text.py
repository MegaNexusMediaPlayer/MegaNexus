# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Plain text out of whatever an add-on puts into a stream row.

Add-ons decorate their rows with Kodi colour markup, emoji, flag pairs, HTML entities
and typographic punctuation. Everything that reads a row works on this plain text:
`plain` keeps letters of every script, `ascii_only` is what the tag tables read.
Both are pure and cached - the same provider and add-on names repeat on every row."""
import html
import re
import unicodedata
from functools import lru_cache

from ..hub_base import BRACKET_RE, COLOR_TAG_RE, HEX_ENTITIES, MULTI_WS_RE, REGIONAL_FLAG_RE, SPECIAL_BLANKS, STREAM_ICON_RE

FLAG_BASE = 0x1F1E6 - ord('A')      # regional indicator A..Z -> letter
_SPACES = {0x200F: ' ', 0x200E: ' ', 0xA0: ' '}
_PUNCTUATION = {0x2022: ' | ', 0xB7: ' | ', 0x2014: '-', 0x2013: '-'}
_EDGES = ' -|_'


def flag_code(match):
    """A flag emoji (two regional indicators) as its country code in brackets."""
    first, second = match.group(0)[:2]
    return '[%s%s]' % (chr(ord(first) - FLAG_BASE), chr(ord(second) - FLAG_BASE))


def _replace_all(text, pairs):
    for old, new in pairs:
        if old in text:
            text = text.replace(old, new)
    return text


def _printable(text):
    """Decomposed, without accents and without control characters (new lines and tabs stay)."""
    kept = []
    for char in unicodedata.normalize('NFKD', text):
        if unicodedata.combining(char):
            continue
        if char in '\n\t' or ord(char) >= 32:
            kept.append(char)
    return ''.join(kept)


CACHED_UP_TO = 256      # names repeat on every row; long texts (a row's whole blob) are not kept


def _plain(text):
    text = _replace_all(html.unescape(text), HEX_ENTITIES)
    text = COLOR_TAG_RE.sub(' ', text)
    text = REGIONAL_FLAG_RE.sub(flag_code, text)
    text = STREAM_ICON_RE.sub(' ', text).translate(_SPACES)
    text = _replace_all(_printable(text), SPECIAL_BLANKS).translate(_PUNCTUATION)
    text = BRACKET_RE.sub(' ', text)
    return MULTI_WS_RE.sub(' ', text).strip(_EDGES).strip()


def _ascii(text):
    text = _plain(text).encode('ascii', 'ignore').decode('ascii')
    return MULTI_WS_RE.sub(' ', text).strip(_EDGES)


_plain_kept = lru_cache(maxsize=2048)(_plain)
_ascii_kept = lru_cache(maxsize=2048)(_ascii)


def plain(value):
    text = str(value or '')
    return _plain_kept(text) if len(text) <= CACHED_UP_TO else _plain(text)


def ascii_only(value):
    text = str(value or '')
    return _ascii_kept(text) if len(text) <= CACHED_UP_TO else _ascii(text)


# a debrid add-on's own tag in brackets: [RD+], [TB+], [AD download], [PM] ...
_SERVICE_TAG = re.compile(r'\[\s*((?:rd|ad|pm|tb|ed|dl|oc)(?:\+|\s+download)?)\s*\]', re.I)


def unbracketed(value):
    """ascii_only, but a debrid tag in brackets stays ("[RD+] Torrentio" keeps RD+); every
    other bracket ("[ Torrent911.pm ]") still goes, so a site name never looks like a service."""
    return ascii_only(_SERVICE_TAG.sub(lambda match: ' %s ' % match.group(1), str(value or '')))


def squash(value, drop='|'):
    """One line of words: ``drop`` characters become spaces, runs of space one, no edge marks."""
    text = str(value or '')
    for char in drop:
        text = text.replace(char, ' ')
    return MULTI_WS_RE.sub(' ', text).strip(' -_.')
