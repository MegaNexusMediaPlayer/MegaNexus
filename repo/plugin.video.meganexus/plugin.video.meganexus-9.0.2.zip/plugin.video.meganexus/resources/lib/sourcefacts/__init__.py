# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Everything the source list shows about one stream row, worked out once.

`describe(row, provider)` returns the facts every source card, chip, badge row and
sort key reads: the file name, picture and sound tags, size, the add-on / service /
indexer it came through, its transport and the one-line origin. Rows written by
MegaNexus' AIOStreams preset are read from their labelled lines (`formatter`); any
other add-on's row from its fields and texts (`identity`, `tags`)."""
from . import formatter, identity, tags
from .text import ascii_only

# the badge row: these tags in this order, at most BADGE_ROW_MAX of them
BADGE_ROW = ('2160P', '1080P', '720P', 'DV', 'HDR10+', 'HDR10', 'HDR', 'HEVC', 'AV1', 'ATMOS',
             'TRUEHD', 'DTS-HD', 'DTS-X', 'DD+', 'DD', '5.1', '7.1', 'MULTI', 'DUBBED', 'SUBS')
BADGE_ROW_MAX = 8
CODECS = ('HEVC', 'H264', 'AV1')
SOUND_FORMATS = ('ATMOS', 'TRUEHD', 'DTS-X', 'DTS-HD', 'DTS', 'DD+', 'DD', 'AC3', 'FLAC', 'AAC', 'OPUS')
DYNAMIC_RANGE = ('DV', 'HDR10+', 'HDR10', 'HDR')

# the card's tag groups: group -> (wanted values, how many shown)
SOURCE_MARKS = ('REMUX', 'BLURAY', 'WEB-DL', 'WEBDL', 'WEBRIP', 'HDTV', 'DVD', 'CAM')
GROUPS = (
    ('encode', ('HEVC', 'H264', 'H.264', 'AVC', 'AV1', 'XVID'), 1, 'picture'),
    ('visual', ('DV', 'HDR10+', 'HDR10', 'HDR', 'HLG', 'IMAX', '10BIT', '3D'), 3, 'picture'),
    ('audio', ('ATMOS', 'TRUEHD', 'DTS-X', 'DTS-HD MA', 'DTS-HD', 'DTS', 'DD+', 'DD', 'AC3', 'FLAC',
               'AAC', 'OPUS'), 2, 'sound'),
    ('channels', ('7.1', '5.1', '2.0', '8CH'), 1, 'sound'),
)
LANGUAGE_WORDS = (('ENGLISH', 'EN'), ('RUSSIAN', 'RU'), ('MULTI', 'Multi'))
LANGUAGES_SHOWN = 4
FORMATTER_LANGUAGES_SHOWN = 6


def badge_row(picture, sound, subtitles):
    present = {str(x).upper() for x in list(picture or []) + list(sound or [])}
    shown = [tag for tag in BADGE_ROW if tag in present]
    if subtitles and 'SUBS' not in shown:
        shown.append('SUBS')
    return ' • '.join(shown[:BADGE_ROW_MAX])


def tag_groups(picture, sound, row=None):
    """{group: values} for the card - read from the tags found, no text scanned again."""
    lists = {'picture': [str(x or '').upper() for x in (picture or [])],
             'sound': [str(x or '').upper() for x in (sound or [])]}
    groups = {}
    marks = [mark for mark in SOURCE_MARKS if any(mark in value for value in lists['picture'])]
    if marks:
        groups['source'] = marks[:1]
    for name, wanted, shown, side in GROUPS:
        found = [value for value in lists[side] if value in wanted]
        if found:
            groups[name] = found[:shown]
    languages = []
    for value in identity.values((row or {}).get('languages')):
        value = ' '.join(value.split())
        if value and value not in languages:
            languages.append(value)
    for word, name in LANGUAGE_WORDS:
        if word in lists['sound'] and name not in languages:
            languages.append(name)
    if languages:
        groups['languages'] = languages[:LANGUAGES_SHOWN]
    return groups


def _first(found, wanted):
    return next((value for value in found if value in wanted), '')


def _from_formatter(row, provider_name, labelled, hints):
    facts = {
        'display_name': (labelled.get('file') or hints.get('filename') or labelled.get('title')
                         or identity.file_name(row, _basename())),
        'picture': formatter.items(labelled.get('video')),
        'sound': formatter.items(labelled.get('audio')),
        'size': identity.size(labelled.get('size')) or str(labelled.get('size') or '').strip(),
        'indexer': ascii_only(labelled.get('indexer') or '').upper(),
        'service': ascii_only(labelled.get('service') or '').upper(),
        'addon_url': identity.http_origin(labelled.get('url')),
        'raw_blob': '',
    }
    addon_name = ascii_only(labelled.get('source') or labelled.get('addon') or '')
    facts['addon'] = addon_name.upper() if addon_name else identity.addon(row, provider_name)
    if not (facts['picture'] or facts['sound']):
        # a preset without the VIDEO / AUDIO lines: the row's texts fill the gap
        whole = identity.blob(identity.row_texts(row))
        facts['picture'] = facts['picture'] or tags.picture(whole, facts['display_name'])
        facts['sound'] = facts['sound'] or tags.sound(whole, facts['display_name'])
    facts['transport'] = identity.transport_from_label(labelled.get('type'))
    badge = identity.SERVICE_BADGE.get(facts['service'].upper())
    if not badge:
        badge = facts['service'][:12] if facts['service'] else identity.service_badge(row, provider_name, ' ')
    facts['badge'] = badge
    return facts


def _from_row(row, provider_name):
    texts = identity.row_texts(row)
    whole = identity.blob(texts)
    hints = identity.hints_of(row)
    raw_hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    facts = {'display_name': identity.file_name(row, _basename()), 'raw_blob': whole}
    facts['addon'] = identity.addon(row, provider_name)
    facts['indexer'] = identity.indexer(row, provider_name, texts=texts, addon_name=facts['addon'])
    facts['service'] = identity.service(row, texts=texts)
    facts['addon_url'] = next((origin for origin in map(identity.http_origin, identity.field_values(
        row, 'manifestUrl', 'manifest_url', 'addonUrl', 'addon_url')) if origin), '')
    facts['size'] = identity.size(row.get('size'), row.get('videoSize'), raw_hints.get('videoSize'),
                                  raw_hints.get('size')) or identity.size(whole)
    facts['picture'] = tags.picture(whole, facts['display_name'])
    facts['sound'] = tags.sound(whole, facts['display_name'])
    facts['badge'] = identity.service_badge(row, provider_name, whole)
    facts['transport'] = None
    del hints
    return facts


def describe(row, provider_name, provider_origin=''):
    row = row or {}
    labelled = formatter.read(row)
    provider_url = identity.http_origin(provider_origin)
    facts = (_from_formatter(row, provider_name, labelled, identity.hints_of(row)) if labelled
             else _from_row(row, provider_name))
    picture, sound, whole = facts['picture'], facts['sound'], facts['raw_blob']
    provider_domain, addon_domain = identity.host_of(provider_url), identity.host_of(facts['addon_url'])
    transport = facts['transport'] or identity.transport(row, provider_name, whole, facts['badge'])
    subtitles = row.get('subtitles') or []
    groups = tag_groups(picture, sound, row=row)
    if labelled.get('lang'):
        spoken = formatter.languages(labelled['lang'])
        if spoken:
            groups['languages'] = spoken[:FORMATTER_LANGUAGES_SHOWN]
    return {
        'display_name': facts['display_name'],
        'site': identity.site(row, provider_name, addon_name=facts['addon']),
        'addon': facts['addon'],
        'indexer': facts['indexer'],
        'service': facts['service'],
        'origin_line': identity.origin_line(row, provider_name, facts['addon'], facts['indexer'], facts['service'],
                                            provider_domain, addon_domain),
        'provider_domain': provider_domain,
        'provider_url': provider_url,
        'addon_domain': addon_domain,
        'addon_url': facts['addon_url'],
        'provider_badge': facts['badge'],
        'size': facts['size'],
        'video_bits': picture,
        'audio_bits': sound,
        'subtitles': subtitles,
        'badges': badge_row(picture, sound, subtitles),
        'tags': groups,
        'source_type': transport,
        'codec': _first(picture, CODECS),
        'audio': _first(sound, SOUND_FORMATS),
        'hdr': _first(picture, DYNAMIC_RANGE),
        '_raw_blob': whole,
        '_formatter': labelled,
    }


def _basename():
    from ..subtitle_names import basename
    return basename


def card_lines(row, provider_name, index=None, facts=None):
    """(label, label2, plot) of a source in Kodi's own list."""
    facts = facts or describe(row, provider_name)
    from ..subtitle_names import summary as _subtitles_summary
    labelled = facts.get('_formatter') or {}
    name = facts['display_name']
    picture, sound = facts['video_bits'], facts['audio_bits']
    label = '[B]%s%s[/B]' % (('%02d. ' % int(index)) if index else '', name)
    second = (['SIZE: %s' % facts['size']] if facts['size'] else []) + [
        'VIDEO: %s' % (' | '.join(picture[:6]) if picture else '--'),
        'AUDIO: %s' % (' | '.join(sound[:6]) if sound else '--')]
    if facts['site']:
        second.append('SITE: %s' % facts['site'])
    if facts['badges']:
        second.append('TAGS: %s' % facts['badges'])
    plot = []
    title = ascii_only(labelled.get('title') or row.get('title') or '')
    if title and title.upper() != name:
        plot.append(title)
    description = '' if labelled else ascii_only(row.get('description') or '')
    if description and description.upper() not in [line.upper() for line in plot]:
        plot.append(description)
    subtitles = _subtitles_summary(facts['subtitles'])
    if subtitles:
        plot.append('Subtitles: %s' % subtitles)
    return label, '    '.join(second), '\n'.join(plot) or name
