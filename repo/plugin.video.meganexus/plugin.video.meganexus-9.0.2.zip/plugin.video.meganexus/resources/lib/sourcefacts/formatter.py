# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The labelled description MegaNexus' AIOStreams preset writes.

AIOStreams has already worked out the file, picture, sound, size, languages and where a
stream comes from; the preset puts each on its own line under a label, e.g.

    FILE Movie.2024.2160p.WEB-DL.mkv
    VIDEO 2160P | DV | HEVC
    SOURCE Torrentio | SERVICE TorBox | TYPE debrid

so these values are read as they are, never analysed again."""
import re

LINES = ('file', 'title', 'video', 'audio', 'size', 'lang', 'subs', 'source')
ORIGIN_PARTS = ('source', 'addon', 'service', 'indexer', 'type', 'url')
READ_LINES = 16
_ORIGIN_SPLIT = re.compile('\\s*[|\u2022]\\s*')
_LIST_SPLIT = re.compile('\\s*(?:\\||\u2022|\u00b7)\\s*')


def _labelled(text, labels):
    """(label, value) of "LABEL value" when the label is one of ``labels``."""
    words = ' '.join(str(text or '').split())
    label, _, value = words.partition(' ')
    label = label.lower()
    if label in labels and value:
        return label, value
    return None, ''


def read(row):
    """{label: value} of the description's labelled lines ({} for any other description)."""
    description = str((row or {}).get('description') or '')
    found = {}
    if not description:
        return found
    for line in description.splitlines()[:READ_LINES]:
        label, value = _labelled(line, LINES)
        if not label:
            continue
        if label != 'source':
            found[label] = value
            continue
        for position, part in enumerate(_ORIGIN_SPLIT.split(value)):
            part = part.strip()
            if not part:
                continue
            part_label, part_value = _labelled(part, ORIGIN_PARTS)
            if part_label:
                found[part_label] = part_value
            elif position == 0:
                found['source'] = part
    return found


def items(value, prefix=''):
    """A labelled value's list ("2160P | DV | HEVC"), upper case, each once."""
    text = str(value or '').strip()
    if prefix and text.upper().startswith(prefix.upper() + ' '):
        text = text[len(prefix) + 1:].strip()
    out = []
    for part in _LIST_SPLIT.split(text):
        word = ' '.join(part.split()).strip(' -_.').upper()
        if word and word != '--' and word not in out:
            out.append(word)
    return out


def languages(value):
    return [part.strip() for part in re.split('\\s*(?:/|\\||\u2022|\u00b7)\\s*', str(value or '')) if part.strip()]
