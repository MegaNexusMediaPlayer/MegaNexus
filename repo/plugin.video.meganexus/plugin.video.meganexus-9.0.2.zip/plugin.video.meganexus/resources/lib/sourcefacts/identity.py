# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Where a stream comes from: the add-on that listed it, the Usenet indexer, the debrid or
download service, the web site, the kind of transport - and its file name and size.

Fields an add-on fills in itself (addon, indexer, service...) are trusted first; the
row's texts are read only when those are missing."""
import html
import re
from urllib.parse import urlparse

from ..hub_base import SIZE_RE
from .text import ascii_only, plain, squash, unbracketed

# a row's texts: the fields that can say something about the source or its quality, in
# this order; then the same from behaviorHints. Each text at most TEXT_CAP characters,
# at most TEXTS_CAP of them - one unusual row must never stall the list.
ROW_TEXT_KEYS = tuple("""name title description filename fileName folderName url externalUrl site host tracker
    sourceSite indexer indexerName sourceIndexer source sourceType transport type addon addonName sourceAddon
    provider streamName releaseTitle release bingeGroup resolution quality encode codec releaseGroup network
    service serviceName debridService visualTags audioTags audioChannels languages size videoSize sizeLabel""".split())
HINT_TEXT_KEYS = tuple("""filename fileName name title description bingeGroup videoSize quality source sourceType
    transport type provider site indexer indexerName service serviceName resolution codec audioTags audioChannels
    visualTags languages size""".split())
TEXT_CAP = 768
TEXTS_CAP = 48
BLOB_CAP = 8192

# names that say nothing about which add-on it was
NOT_AN_ADDON = frozenset(['direct play', 'cached torrent', 'uncached torrent']
                         + 'direct transcode external torrent stream usenet nzb nntp newznab http https web download '
                           'cached uncached unknown rd rd+ realdebrid ad ad+ alldebrid pm premiumize tb tb+ torbox '
                           'ed ed+ easydebrid'.split())
_NAME = '([a-z0-9][a-z0-9 ._+\\-]{1,40}?)(?=\\s*(?:[|\u2022\u00b7\\n]|$))'
_ADDON_AFTER_LABEL = re.compile('(?im)\\b(?:source|addon)\\s*[:=\\-]?\\s*' + _NAME)
_ADDON_AFTER_TAG = re.compile('(?im)^\\s*\\[[^\\]\\n]{1,16}\\]\\s*' + _NAME)

INDEXERS = (
    ('NZBGEEK', r'nzb\s*geek'), ('DRUNKENSLUG', r'drunken\s*slug'),
    ('NZBFINDER', r'nzb\s*finder'), ('ALTHUB', r'alt\s*hub'), ('DOGNZB', r'dog\s*nzb'),
    ('OMGWTFNZBS', r'omgwtf(?:nzbs?)?'), ('ABNZB', r'ab\s*nzb'),
    ('TABULA RASA', r'tabula\s*rasa'), ('NZB.SU', r'nzb\s*\.\s*su'),
    ('NZBFORYOU', 'nzbforyou'), ('NEWZNAB', 'newznab'),
)
SERVICES = (
    ('REAL-DEBRID', (r'real[ -]?debrid', r'rd\+?')), ('ALLDEBRID', (r'all[ -]?debrid', r'ad\+?')),
    ('PREMIUMIZE', ('premiumize', r'pm\+?')), ('TORBOX', ('torbox', r'tb\+?')),
    ('EASYDEBRID', (r'easy[ -]?debrid', r'ed\+?')), ('EASYNEWS', ('easynews',)),
)
SERVICE_BADGE = {'RD': 'RD+', 'REAL-DEBRID': 'RD+', 'REALDEBRID': 'RD+',
                 'AD': 'AD+', 'ALLDEBRID': 'AD+', 'ALL-DEBRID': 'AD+',
                 'PM': 'PM', 'PREMIUMIZE': 'PM', 'TB': 'TB', 'TORBOX': 'TB',
                 'ED': 'ED+', 'EASYDEBRID': 'ED+', 'EASY-DEBRID': 'ED+'}
DEBRID_BADGES = ('RD+', 'AD+', 'PM', 'TB', 'ED+')
_INDEXER_RES = tuple((label, re.compile(r'\b%s\b' % spelling, re.I)) for label, spelling in INDEXERS)
_SERVICE_RES = tuple((label, re.compile('|'.join(r'\b%s\b' % s for s in spellings), re.I))
                     for label, spellings in SERVICES)
NOT_AN_INDEXER = ('usenet', 'nzb', 'nntp', 'newznab', 'unknown')
NOT_A_SERVICE = ('usenet', 'nzb', 'nntp', 'none', 'unknown')

# the chip of each transport: (label, ARGB colour); Plex and Emby in their brand colours
KINDS = dict((kind, (kind.upper(), colour)) for kind, colour in (
    ('usenet', 'FFD97706'), ('debrid', 'FF059669'), ('torrent', 'FFDC2626'),
    ('direct', 'FF2563EB'), ('plex', 'FFE5A00D'), ('emby', 'FF52B54B')))
USENET_WORDS = re.compile('usenet|nzb|sabnzbd|newznab|easynews|eweka|newshosting|tweaknews|drunkenslug'
                          '|althub|dognzb|omgwtf|binsearch|newsdemon|giganews|supernews|astraweb'
                          '|usenetserver|newsgroup', re.I)
TORRENT_WORDS = re.compile(r'\btorrent\w*\b|\bmagnet\b|\bseeders?\b|\bpeers?\b|\bp2p\b', re.I)
PLEX_PREFIX, EMBY_PREFIX = 'Plex \u2022 ', 'Emby \u2022 '


def kind(key):
    return (key,) + KINDS[key]


def hints_of(row):
    hints = (row or {}).get('behaviorHints')
    return hints if isinstance(hints, dict) else {}


def values(value):
    """Every non-empty text inside a value (lists, tuples, sets and dicts opened up)."""
    if value is None:
        return
    if isinstance(value, dict):
        value = list(value.values())
    if isinstance(value, (list, tuple, set)):
        for entry in value:
            for text in values(entry):
                yield text
        return
    text = str(value).strip()
    if text:
        yield text


def field_values(row, *keys):
    """The texts of these fields, each key from the row and then from its hints."""
    hints = hints_of(row)
    for key in keys:
        for text in values(row.get(key)):
            yield text
        for text in values(hints.get(key)):
            yield text


def row_texts(row):
    """A row's distinct texts as ROW_TEXT_KEYS / HINT_TEXT_KEYS order them, capped."""
    row = row or {}
    texts, seen = [], set()
    sources = [(row, ROW_TEXT_KEYS)]
    if isinstance(row.get('behaviorHints') or {}, dict):
        sources.append((row.get('behaviorHints') or {}, HINT_TEXT_KEYS))
    for owner, keys in sources:
        for key in keys:
            for text in values(owner.get(key)):
                text = text.strip()[:TEXT_CAP]
                if not text or text in seen:
                    continue
                seen.add(text)
                texts.append(text)
                if len(texts) >= TEXTS_CAP:
                    return texts
    return texts


def blob(texts):
    """The texts as one string for the tag tables (" | " keeps them apart)."""
    return ' | '.join(texts)[:BLOB_CAP]


def spaced(texts):
    """The texts as one string for service / transport words."""
    return ' '.join(texts)[:BLOB_CAP]


def http_origin(raw):
    """scheme://host of an address - configured tokens and paths never reach the screen."""
    try:
        parts = urlparse(str(raw or '').strip())
        scheme, host = parts.scheme.lower(), (parts.netloc or '').split('@')[-1]
    except Exception:
        return ''
    return '%s://%s' % (scheme, host) if scheme in ('http', 'https') and host else ''


def host_of(address):
    try:
        host = urlparse(address).netloc
    except Exception:
        return ''
    return host[4:] if host.startswith('www.') else host


def readable_size(value):
    """Bytes as "1.50 GB" / "300.00 MB" / "12 B"; '' for no size."""
    try:
        if isinstance(value, (int, float)) and value > 0:
            for unit, power in (('GB', 3), ('MB', 2)):
                if value >= 1024 ** power:
                    return '%.2f %s' % (value / float(1024 ** power), unit)
            return '%.0f B' % float(value)
    except Exception:
        pass
    return ''


def size(*candidates):
    """The first size found: a byte count, or "42.5 GB" in a text (the dot read before any
    clean-up turns it into a space)."""
    for value in candidates:
        if isinstance(value, (int, float)):
            text = readable_size(value)
            if text:
                return text
        found = (SIZE_RE.search(html.unescape(str(value or '')).replace(',', '.'))
                 or SIZE_RE.search(plain(value)))
        if found:
            return found.group(1).upper().replace('GIB', 'GB').replace('MIB', 'MB')
    return ''


def _addon_word(value):
    text = ascii_only(value)
    if not text or text.lower() in NOT_AN_ADDON:
        return ''
    return squash(text, '|/').upper()


def addon(row, provider_name):
    """The add-on's own name: its fields, then "Source: X" / "[tag] X" in its texts, then the
    provider - never a transport or debrid word."""
    hints = hints_of(row)
    own = (row.get('addon'), row.get('addonName'), row.get('sourceAddon'), row.get('source_addon'),
           hints.get('addon', ''), hints.get('addonName', ''))
    for value in own:
        name = _addon_word(value)
        if name:
            return name
    for raw in (row.get('description'), row.get('name')):
        text = str(raw or '')[:1536]
        if not text:
            continue
        for found in _ADDON_AFTER_LABEL.findall(text) + _ADDON_AFTER_TAG.findall(text):
            name = _addon_word(found)
            if name:
                return name
    for value in (provider_name, row.get('provider'), hints.get('provider', ''),
                  row.get('source'), hints.get('source', '')):
        name = _addon_word(value)
        if name:
            return name
    return (provider_name or 'ADDON').upper()


def indexer(row, provider_name='', texts=None, addon_name=''):
    addon_name = addon_name or addon(row, provider_name)
    pool = list(field_values(row, 'indexer', 'indexerName', 'sourceIndexer', 'tracker',
                             'sourceSite', 'site', 'host'))
    pool += texts if texts is not None else row_texts(row)
    text = ' '.join(ascii_only(v) for v in pool if v)
    for label, pattern in _INDEXER_RES:
        if pattern.search(text):
            return label
    # an indexer field may hold a custom Newznab name or domain
    for value in field_values(row, 'indexer', 'indexerName', 'sourceIndexer'):
        name = squash(ascii_only(value))
        if name and name.lower() not in NOT_AN_INDEXER and name.upper() not in (addon_name, str(provider_name or '').upper()):
            return name.upper()
    return ''


def _service_in(text):
    for label, pattern in _SERVICE_RES:
        if pattern.search(text):
            return label
    return ''


def service(row, texts=None):
    for value in field_values(row, 'service', 'serviceName', 'debridService'):
        text = ascii_only(value)
        label = _service_in(text)
        if label:
            return label
        name = squash(text)
        if name and name.lower() not in NOT_A_SERVICE:
            return name.upper()
    return _service_in(spaced(texts if texts is not None else row_texts(row)))


def origin_line(row, provider_name, addon_name='', indexer_name='', service_name='',
                provider_domain='', addon_domain=''):
    """"Provider  •  domain  •  ADDON  •  SERVICE  •  INDEXER", every name once (a composite like
    "Emby • Emby" is split, a word doubled inside one name kept once)."""
    addon_name = addon_name or addon(row, provider_name)
    indexer_name = indexer_name or indexer(row, provider_name, addon_name=addon_name)
    service_name = service_name or service(row)
    names = (' '.join(str(provider_name or 'Provider').split()), provider_domain, addon_name,
             addon_domain, service_name, indexer_name)
    shown, keys = [], set()
    for name in names:
        for piece in re.split('[\u2022\u00b7|]', str(name or '')):
            words = []
            for word in piece.split():
                if not words or word.lower() != words[-1].lower():
                    words.append(word)
            piece = ' '.join(words)
            if piece and piece.lower() not in keys:
                keys.add(piece.lower())
                shown.append(piece)
    return '  \u2022  '.join(shown)


def _url_host(row):
    for key in ('url', 'externalUrl'):
        address = row.get(key)
        if not address:
            continue
        try:
            host = urlparse(str(address)).netloc.lower()
        except Exception:
            host = ''
        if host:
            host = host.split('@')[-1]
            return (host[4:] if host.startswith('www.') else host).upper()
    return ''


def site(row, provider_name, addon_name=''):
    addon_name = addon_name or addon(row, provider_name)
    from_url = _url_host(row)
    for value in (row.get('site'), row.get('host'), row.get('tracker'), row.get('sourceSite'),
                  hints_of(row).get('site', '') if isinstance(row.get('behaviorHints'), dict) else ''):
        text = ascii_only(value)
        if not text or 'direct play' in text.lower() or 'transcode' in text.lower():
            continue
        text = squash(text, '|/').upper()
        if text and text != addon_name:
            return text
    if from_url and from_url != addon_name:
        return from_url
    return addon_name


def file_name(row, basename):
    """The release's file / folder / title name in capitals ("STREAM" when it has none)."""
    hints = hints_of(row)
    for value in (row.get('folderName'), row.get('filename'), row.get('fileName'),
                  hints.get('filename', '') if isinstance(row.get('behaviorHints'), dict) else '',
                  row.get('releaseTitle'), row.get('release'), row.get('title'), row.get('name'),
                  row.get('description')):
        if value:
            name = basename(value)
            if name:
                return name.upper()
    return 'STREAM'


def _native_server(provider_name):
    name = str(provider_name or '')
    if name.startswith(PLEX_PREFIX):
        return 'plex'
    if name.startswith(EMBY_PREFIX):
        return 'emby'
    return ''


def service_badge(row, provider_name, text=''):
    """The short chip of the debrid service (RD+, AD+, PM, TB, ED+), PLEX / EMBY for the
    built-in servers, else the provider's name (12 letters)."""
    server = _native_server(provider_name)
    if server:
        return server.upper()
    # 8.1: read with the words in brackets - "[RD+] Torrentio" is a Real-Debrid row
    if text:
        low = unbracketed(text).lower()
    else:
        pool = row_texts(row) + [provider_name]
        low = ' '.join(unbracketed(v).lower() for v in pool if v)[:BLOB_CAP]
    for badge, words, pattern in _BADGE_TESTS:
        if any(word in low for word in words) or (pattern is not None and pattern.search(low)):
            return badge
    name = ascii_only(provider_name or '')
    return name.upper()[:12] if name else 'SRC'


_BADGE_TESTS = (
    ('RD+', ('realdebrid', 'rd+'), re.compile(r'\brd\+?\b')),
    ('AD+', ('alldebrid',), re.compile(r'\bad\+?\b')),
    ('PM', ('premiumize',), re.compile(r'\bpm\+?\b')),
    ('TB', ('torbox',), re.compile(r'\btb\+?\b')),
    ('ED+', ('easydebrid', 'ed+'), None),
)


def transport(row, provider_name, text='', badge=''):
    """(key, chip label, chip colour) - usenet / debrid / torrent / direct, plex / emby."""
    hints = hints_of(row)
    native = str(hints.get('nativeProvider') or '').lower()
    if native:
        return kind('plex' if 'plex' in native else 'emby' if ('emby' in native or 'jellyfin' in native) else 'direct')
    server = _native_server(provider_name)
    if server:
        return kind(server)
    for value in (row.get('type'), row.get('sourceType'), row.get('transport'),
                  hints.get('type'), hints.get('sourceType')):
        if 'usenet' in str(value or '').lower():
            return kind('usenet')
    raw = str(text or '')[:BLOB_CAP] or spaced(row_texts(row))
    low = unbracketed(raw).lower()
    if USENET_WORDS.search(low):
        return kind('usenet')
    badge = badge or service_badge(row, provider_name, raw)
    if (badge in DEBRID_BADGES or 'debrid' in low or 'offcloud' in low or 'premiumize' in low
            or '\u26a1' in raw):
        return kind('debrid')
    info_hash = str(row.get('infoHash') or row.get('infohash') or hints.get('infoHash') or '')
    address = str(row.get('url') or row.get('externalUrl') or '')
    if info_hash or address.lower().startswith('magnet:') or TORRENT_WORDS.search(low):
        return kind('torrent')
    return kind('direct')


def transport_from_label(value):
    """The kind a formatter's TYPE line names, None when it names none."""
    low = str(value or '').strip().lower()
    if not low:
        return None
    if 'usenet' in low or low in ('nzb', 'nntp'):
        return kind('usenet')
    if 'debrid' in low:
        return kind('debrid')
    if 'torrent' in low or low == 'p2p':
        return kind('torrent')
    return kind('direct')
