# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""What a release name says about its picture and sound.

Each tag is written as the spellings release groups use, in a small notation:
``_`` any (or no) space, ``~`` one optional space or dash, ``>`` at the end: the next
character may be anything. Every spelling stands as a whole word. A tag is reported once,
in table order within each text, texts in the order given."""
import re

from .text import ascii_only

PICTURE = (
    ('2160P', ('2160p', '4k', 'uhd')),
    ('1080P', ('1080p', 'fhd')),
    ('720P', ('720p',)),
    ('480P', ('480p', 'sd')),
    ('REMUX', ('remux',)),
    ('BLURAY', ('blu~ray',)),
    ('WEB-DL', ('web~dl',)),
    ('WEBRIP', ('web~rip',)),
    ('HDR10+', (r'hdr10\+',)),
    ('HDR10', ('hdr10',)),
    ('HDR', (r'high\s+dynamic\s+range_\(hdr\)', 'hdr')),
    ('DV', ('dolby_vision', 'dovi', 'dv')),
    ('HEVC', ('hevc', 'x265', 'h265')),
    ('H264', ('x264', 'h264')),
    ('AV1', ('av1',)),
    ('10BIT', ('10bit', '10-bit')),
    ('HYBRID', ('hybrid',)),
    ('SDR', ('sdr',)),
    ('3D', ('3d',)),
    ('NF', ('nf', 'netflix')),
    ('AMZN', ('amzn', 'amazon')),
    ('DSNP', ('dsnp', r'disney\+?')),
    ('HULU', ('hulu',)),
    ('ATVP', ('atvp', r'apple\s?tv')),
    ('DVD', ('dvd_source', 'dvd')),
    ('WEB', ('web_source',)),
    ('PACK', ('pack',)),
)

SOUND = (
    ('ATMOS', ('atmos',)),
    ('TRUEHD', ('truehd', 'true-hd')),
    ('DD+', ('dolby_digital_plus', r'ddp(?:\+|\b)>', 'eac-?3', r'dd\+')),
    ('DD-EX', ('dolby_digital_ex', 'dd-?ex')),
    ('DD', ('dolby_digital', 'dd')),
    ('AC3', ('ac-?3',)),
    ('DTS-X', ('dts_x', 'dtsx')),
    ('DTS-HD MA', ('dts~hd_master_audio', 'dts~hd_ma')),
    ('DTS-HD', ('dts~hd',)),
    ('DTS', ('dts',)),
    ('FLAC', ('flac',)),
    ('AAC', ('aac',)),
    ('OPUS', ('opus',)),
    ('MP3', ('mp3',)),
    ('PCM', ('pcm',)),
    ('8CH', ('8ch(?:_audio)?',)),
    ('7.1', (r'7\.1', '7ch(?:_audio)?')),
    ('5.1', ('6ch(?:_audio)?', r'5\.1')),
    ('2.0', ('2ch(?:_audio)?', r'2\.0')),
    ('MULTI', ('multi(?:~audio|~lang(?:uages?)?)?',)),
    ('DUAL', ('dual(?:~audio)?',)),
    ('DUBBED', ('dubbed?', 'dub')),
    ('SUBS', ('subs?', 'subbed', 'subtitles')),
    ('ENGLISH', ('english',)),
    ('RUSSIAN', ('russian',)),
)


def _spelling(text):
    open_end = text.endswith('>')
    body = (text[:-1] if open_end else text).replace('_', r'\s*').replace('~', '[- ]?')
    return r'\b' + body + ('' if open_end else r'\b')


def compile_table(table):
    return tuple((label, re.compile('|'.join(_spelling(s) for s in spellings), re.I))
                 for label, spellings in table)


_PICTURE = compile_table(PICTURE)
_SOUND = compile_table(SOUND)


def find(table, texts):
    found = []
    for value in texts:
        text = ascii_only(value).lower()
        if not text:
            continue
        for label, pattern in table:
            if label not in found and pattern.search(text):
                found.append(label)
    return found


def picture(*texts):
    return find(_PICTURE, texts)


def sound(*texts):
    return find(_SOUND, texts)
