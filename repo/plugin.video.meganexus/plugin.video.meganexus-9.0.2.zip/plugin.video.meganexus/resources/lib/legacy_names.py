# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Identifiers from before the MegaNexus rename, used only for upgrades.

MegaNexus 7 moved every add-on ID, file and setting of our own software off the
previous working name; a 6.0 profile is moved once (rename_migration.py). The
previous name is assembled at runtime so it does not appear anywhere in the
shipped sources or interface.
"""
import os

# One-shot defaults migrations already applied by earlier builds.
DONE_SENTINELS = ('meganexus_v510_defaults_applied', 'meganexus_v520_defaults_applied')


# --- Previous working name (up to 6.0.40) -------------------------------------
# MegaNexus 7 moved every add-on ID, file and setting of our own software off
# the previous working name. These are read only to move a profile and remove
# the old add-ons (rename_migration.py). The Nuvio sync integration is an
# external service and keeps its own names (modules, settings, files, tables).
_N = bytes((110, 117, 118, 105, 111)).decode('ascii')
PREV = _N
PREV_TITLE = _N.capitalize()
PREV_ADDONS = {'plugin.video.meganexus': 'plugin.video.' + _N + 'hub', 'script.meganexus': 'script.' + _N,
               'skin.meganexus': 'skin.' + _N, 'screensaver.meganexus': 'screensaver.' + _N}
PREV_IPTV_NAME = PREV_TITLE + ' IPTV'
PREV_PLAYBACK_KEYMAP = _N + '-playback.xml'
PREV_PLAYBACK_MARKER = PREV_TITLE + ' owned playback keys'
# Our own markers that only looked like the service's names.
PREV_EXPLICIT = {_N + '_profile_applied': 'meganexus_profile_applied',
                 _N + '_import.json': 'profile_import.json'}
_KEEP = ['api.%s.tv' % _N, '%sMedia' % PREV_TITLE, '%sTV' % PREV_TITLE, '%s TV' % PREV_TITLE,
         '%sWeb' % PREV_TITLE, '%sMobile' % PREV_TITLE, 'badges-%s' % _N,
         '%s_stremio_sync' % _N, '%s_import' % _N, '%s_progress' % _N, '%s_sync' % _N,
         'sign_in_%s' % _N, 'import_from_%s' % _N, 'sync_from_%s' % _N, 'choose_%s_profile' % _N,
         'import_%s_collections' % _N, '%s_sign_in' % _N, '%s_sign_out' % _N, '%s_select_profile' % _N,
         '%s_profile' % _N, '%s_login' % _N, '%s_logout' % _N, '%s_status' % _N, '_library_to_%s' % _N,
         '_addons_to_%s' % _N, '_progress_to_%s' % _N, 'sync_%s' % _N, '%s_token' % _N, '%s_email' % _N,
         '%s_password' % _N, '%s_user' % _N, 'next_%s' % _N, '%s_failures' % _N, 'due_%s' % _N,
         "'%s'" % _N, '"%s"' % _N, '/api/%s/' % _N, 'S.%s' % _N]
_RULES = [('plugin.video.%shub' % _N, 'plugin.video.meganexus'), ('%s-Hub-Complete' % PREV_TITLE, 'MegaNexus-Complete'),
          ('%s-Hub' % PREV_TITLE, 'MegaNexus'), ('%s Hub' % PREV_TITLE, 'MegaNexus'), ('%sHub' % PREV_TITLE, 'MegaNexus'),
          ('%sHUB' % _N.upper(), 'MEGANEXUS'), ('%shub' % _N, 'meganexus'), ('%s_ui' % _N, 'meganexus_ui'),
          ('[%s]' % PREV_TITLE, '[MegaNexus]'), (_N, 'meganexus')]
_URL = __import__('re').compile(r'https?://[^\s"\'<>]+')


def prev_translate(text):
    """Our identifiers under the previous name -> MegaNexus (the rules of
    review/rebrand_meganexus.py). Web addresses and the service's names stay."""
    if not text or _N not in text.lower():
        return text
    if text in PREV_EXPLICIT:
        return PREV_EXPLICIT[text]
    masks = {}

    def mask(value):
        token = '\x00M%d\x00' % len(masks)
        masks[token] = value
        return token
    text = _URL.sub(lambda m: mask(m.group(0)), text)
    for value in _KEEP:
        if value in text:
            text = text.replace(value, mask(value))
    for old, new in _RULES:
        text = text.replace(old, new)
    text = __import__('re').sub(PREV_TITLE + r'(?=[A-Z])', 'MegaNexus', text)
    for token in reversed(list(masks)):
        text = text.replace(token, masks[token])
    return text


def legacy_setting(addon, key):
    try:
        return (addon.getSetting(key) or '').strip()
    except Exception:
        return ''


def profile_in_use(profile_dir):
    """True when this profile was configured by an earlier build.

    Older profiles already ran every one-shot defaults migration; if their
    sentinels cannot be read any more they must not be re-applied over the
    user's choices.
    """
    for name in ('providers.json', 'meganexus_collections.json'):
        if os.path.exists(os.path.join(profile_dir, name)):
            return True
    return False


def carry_forward(addon, profile_dir=None):
    """A profile configured by an earlier build whose defaults marker can not be read:
    its one-shot defaults migrations count as done (never re-applied over the user's
    choices). Returns True when anything was written."""
    if not profile_dir or legacy_setting(addon, 'meganexus_defaults_rev') or not profile_in_use(profile_dir):
        return False
    addon.setSetting('meganexus_defaults_rev', '470-release-defaults')
    for key in DONE_SENTINELS:
        if legacy_setting(addon, key).lower() != 'true':
            addon.setSetting(key, 'true')
    return True
