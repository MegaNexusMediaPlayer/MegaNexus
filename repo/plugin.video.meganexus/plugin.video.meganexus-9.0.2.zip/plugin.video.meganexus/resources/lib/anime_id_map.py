# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""An anime's other ids (IMDb, TMDB, TVDB, Kitsu, MAL, AniList, AniDB) from Fribb's public
anime-lists, so an anime add-on can be asked by the id it understands.

The list (about 40 000 rows) is kept in anime_ids.db and rebuilt every 14 days in the
background - a lookup never waits for it (`anime_id_mapping` switches it off)."""
import json
import os
import sqlite3
import threading
import time
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

SOURCE_URL = 'https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-full.json'
REBUILD_AFTER = 14 * 86400
# Fribb's field -> ours
FIELDS = (('imdb_id', 'imdb_id'), ('themoviedb_id', 'tmdb_id'), ('thetvdb_id', 'tvdb_id'), ('kitsu_id', 'kitsu_id'),
          ('mal_id', 'mal_id'), ('anilist_id', 'anilist_id'), ('anidb_id', 'anidb_id'))
KEYS = tuple(ours for _theirs, ours in FIELDS)

_lock = threading.Lock()
_building = [False]
_answers = {}


def _addon():
    return xbmcaddon.Addon('plugin.video.meganexus')


def enabled():
    try:
        return (_addon().getSetting('anime_id_mapping') or 'true').strip().lower() in ('true', '1', 'yes', 'on')
    except Exception:
        return True


def _file():
    try:
        folder = xbmcvfs.translatePath(_addon().getAddonInfo('profile'))
    except Exception:
        folder = xbmc.translatePath('special://profile/addon_data/plugin.video.meganexus')
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, 'anime_ids.db')


def _open():
    conn = sqlite3.connect(_file(), timeout=5)
    conn.execute('CREATE TABLE IF NOT EXISTS map (%s)' % ', '.join('%s TEXT' % key for key in KEYS))
    conn.execute('CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)')
    for key in KEYS:
        conn.execute('CREATE INDEX IF NOT EXISTS idx_%s ON map(%s)' % (key, key))
    return conn


def _current(conn):
    try:
        row = conn.execute("SELECT v FROM meta WHERE k='built_at'").fetchone()
        return float(row[0] if row else 0.0) + REBUILD_AFTER > time.time()
    except Exception:
        return False


def build(force=False):
    """Download and store the list (unless it is current); True when the map is usable."""
    with _lock:
        conn = _open()
        try:
            if not force and _current(conn):
                return True
            with urlopen(Request(SOURCE_URL, headers={'User-Agent': 'MegaNexus/8', 'Accept': 'application/json'}),
                         timeout=60) as answer:
                entries = json.loads(answer.read().decode('utf-8'))
            if not isinstance(entries, list) or not entries:
                return False
            rows = [row for row in (tuple(str(entry.get(theirs) or '').strip().lower() or None for theirs, _ours in FIELDS)
                                    for entry in entries if isinstance(entry, dict)) if any(row)]
            conn.execute('DELETE FROM map')
            conn.executemany('INSERT INTO map (%s) VALUES (%s)' % (','.join(KEYS), ','.join('?' * len(KEYS))), rows)
            conn.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('built_at', ?)", (str(time.time()),))
            conn.commit()
            xbmc.log('[MegaNexus] anime id map built: %d entries' % len(rows), xbmc.LOGINFO)
            return True
        except Exception as exc:
            try:
                conn.rollback()
            except Exception:
                pass
            xbmc.log('[MegaNexus] anime id map build failed: %s' % exc, xbmc.LOGWARNING)
            return False
        finally:
            conn.close()


def ensure_async():
    """(Re)build in the background, once at a time."""
    if _building[0]:
        return
    _building[0] = True

    def work():
        try:
            build()
        finally:
            _building[0] = False
    try:
        from .side_jobs import maybe_run
        started = maybe_run(work, key='anime-id-map-build')
    except Exception:
        started = False
    if not started:
        _building[0] = False


def _clean(key, value):
    value = str(value or '').strip().lower()
    if key == 'imdb_id':
        return value if value.startswith('tt') else ''
    return value.split(':')[-1] if value else ''


def lookup(ids):
    """The ids the map adds to the given ones ({} when unknown, switched off or not built yet)."""
    if not enabled() or not isinstance(ids, dict):
        return {}
    known = dict((key, value) for key, value in ((key, _clean(key, ids.get(key))) for key in KEYS) if value)
    if not known:
        return {}
    key = tuple(sorted(known.items()))
    if key in _answers:
        return dict(_answers[key])
    if not os.path.isfile(_file()):
        ensure_async()
        return {}
    found = {}
    try:
        conn = _open()
        try:
            if not _current(conn):
                ensure_async()
            for name, value in known.items():
                row = conn.execute('SELECT %s FROM map WHERE %s = ? LIMIT 1' % (','.join(KEYS), name), (value,)).fetchone()
                if row:
                    found = dict((field, str(row[place])) for place, field in enumerate(KEYS)
                                 if row[place] and not known.get(field))
                    break
        finally:
            conn.close()
    except Exception as exc:
        xbmc.log('[MegaNexus] anime id lookup failed: %s' % exc, xbmc.LOGDEBUG)
        return {}
    _answers[key] = dict(found)
    return found
