# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Watch Party identity and friends (7.0.52).

Each MegaNexus profile has its own Nostr key (party_identity.json) and friends
(party_friends.json); both move with the profile (user_profiles.FILES) and go into the
backup. The key never leaves the box except in the backup file the user makes.

Finding someone: by their friend code (8 characters, shown in Watch Party) or by their
exact profile name when they chose "Others can find me by name". Both are a small,
replaceable MegaNexus directory entry on the relays (kind 30078, NIP-78 app data) with
single-letter tags every relay indexes: t = meganexus, n = the name in small letters,
c = the friend code. Names are not unique on Nostr, so every new friend is confirmed
with a 6-digit code both TVs show (party_crypto.pair_code) before a party.
"""
import json
import os
import re
import time

from . import party_crypto as crypto

IDENTITY = 'party_identity.json'
FRIENDS = 'party_friends.json'
DIRECTORY_KIND = 30078
DIRECTORY_D = 'meganexus-profile'
ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'      # no 0/O, 1/I: read aloud easily
CODE_LENGTH = 8


def _profile():
    from .meganexus.paths import profile_path
    return profile_path()


def _read(name, default):
    try:
        with open(os.path.join(_profile(), name), encoding='utf-8') as handle:
            value = json.load(handle)
        return value if isinstance(value, type(default)) else default
    except (OSError, ValueError):
        return default


def _write(name, value):
    path = os.path.join(_profile(), name)
    temp = path + '.tmp'
    with open(temp, 'w', encoding='utf-8') as handle:
        json.dump(value, handle)
    try:
        os.chmod(temp, 0o600)
    except Exception:
        pass
    os.replace(temp, path)


def identity():
    """{'secret': bytes, 'public': hex, 'code': friend code} - made the first time."""
    data = _read(IDENTITY, {})
    secret_hex = data.get('secret') or ''
    if not re.match(r'^[0-9a-f]{64}$', secret_hex):
        secret_hex = crypto.new_secret().hex()
        _write(IDENTITY, {'secret': secret_hex, 'created': time.time()})
    secret = bytes.fromhex(secret_hex)
    public = crypto.public_key(secret).hex()
    return {'secret': secret, 'public': public, 'code': friend_code(public)}


def friend_code(public_hex):
    value = int(public_hex[:16], 16)
    out = ''
    for _ in range(CODE_LENGTH):
        value, digit = divmod(value, len(ALPHABET))
        out += ALPHABET[digit]
    return out


def clean_code(text):
    code = re.sub(r'[\s-]+', '', str(text or '')).upper()
    return code if len(code) == CODE_LENGTH and all(ch in ALPHABET for ch in code) else ''


def display_name():
    try:
        from . import user_profiles
        row = user_profiles.get(user_profiles.active()) or {}
        return str(row.get('name') or 'MegaNexus')[:24]
    except Exception:
        return 'MegaNexus'


def directory_event(secret, name, findable):
    """Our directory entry: always findable by friend code, by name only when chosen."""
    public = crypto.public_key(secret).hex()
    tags = [['d', DIRECTORY_D], ['t', 'meganexus'], ['c', friend_code(public)]]
    if findable:
        tags.append(['n', name.strip().lower()])
    content = json.dumps({'name': name, 'v': 1}, separators=(',', ':'))
    return crypto.sign_event(DIRECTORY_KIND, content, tags, secret)


def directory_filter(code='', name=''):
    flt = {'kinds': [DIRECTORY_KIND], '#t': ['meganexus'], 'limit': 20}
    if code:
        flt['#c'] = [code]
    if name:
        flt['#n'] = [name.strip().lower()]
    return flt


def entry_of(event):
    """{'public', 'name', 'code'} of a directory event (signature already checked), or None."""
    try:
        tags = dict((t[0], t[1]) for t in event['tags'] if len(t) > 1)
        if event['kind'] != DIRECTORY_KIND or tags.get('d') != DIRECTORY_D:
            return None
        if tags.get('c') != friend_code(event['pubkey']):
            return None                                  # a code someone else's key does not make
        name = str(json.loads(event['content']).get('name') or '')[:24] or 'MegaNexus'
        return {'public': event['pubkey'], 'name': name, 'code': tags['c']}
    except Exception:
        return None


# --- friends -------------------------------------------------------------------------------

def friends():
    """{public hex: {'name', 'since', 'confirmed', 'state'}}; state: friend / asked (we asked) /
    asking (they asked us)."""
    return _read(FRIENDS, {})


def set_friend(public, name, state, confirmed=False):
    rows = friends()
    old = rows.get(public) or {}
    rows[public] = {'name': str(name or old.get('name') or 'MegaNexus')[:24], 'state': state,
                    'confirmed': bool(confirmed or old.get('confirmed')), 'since': old.get('since') or time.time()}
    _write(FRIENDS, rows)
    return rows[public]


def remove_friend(public):
    rows = friends()
    if rows.pop(public, None) is not None:
        _write(FRIENDS, rows)
        return True
    return False


