# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Google Gemini with the user's own free key (8.1.3) - for AI subtitle translation.

Gentle with the free tier, whose limits Google sets per project and has cut more than
once: one request at a time, never closer than GAP seconds, the wait Google names when it
says "too many" (retryDelay), and the next model when one model's day is used up. The
model is not written in here: the key's own list says which Flash models it may use, the
full one first, then Flash-Lite.
"""
import json
import re
import threading
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen

BASE = 'https://generativelanguage.googleapis.com/v1beta'
SETTING = 'gemini_api_key'
SETTING_2 = 'gemini_api_key_2'   # 8.1.5: a second free key - the two translate side by side
GAP = 4.5                 # seconds between two requests: at most ~13 a minute
TRIES = 6                 # a batch is asked this often when Gemini says "too many"
TIMEOUT = 60              # 8.1.3: a model that has not answered by then is passed over (was 120)
MODELS_LIFE = 24 * 3600
SKIP = ('image', 'tts', 'audio', 'live', 'embed', 'vision', 'learnlm', 'robotics', 'computer')
def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Gemini: ' + text, xbmc.LOGINFO)
    except Exception:
        pass


SAFETY = [{'category': c, 'threshold': 'BLOCK_NONE'} for c in (
    'HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH',
    'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT')]   # film dialogue
_lock = threading.Lock()
# 8.1.5: everything Google counts, counted per key - each key has its own pace, its own
# models, its own rests and its own day; one key waiting never holds the other up
_keys = {}                # key -> {'last', 'spent', 'cool', 'models', 'models_at', 'lock'}
COOL = 60.0               # seconds a busy model is left alone
SLOW_COOL = 1800.0        # 8.1.5: a model that gave no answer in TIMEOUT rests half an hour (was 2 min)
WAIT_ALL = 600.0          # seconds to wait for one to come free when all are busy
MAIN_FILE = 'gemini_model.json'    # 8.1.3: the model that last translated - asked first


def _main():
    try:
        import os
        from .meganexus.paths import profile_path
        return os.path.join(profile_path(), MAIN_FILE)
    except Exception:
        return ''


def main_model():
    try:
        with open(_main(), encoding='utf-8') as handle:
            return str(json.load(handle).get('model') or '')
    except Exception:
        return ''


def _remember(model):
    """The model that answered becomes the first one asked, this run and the next."""
    if main_model() == model:
        return
    try:
        with open(_main(), 'w', encoding='utf-8') as handle:
            json.dump({'model': model}, handle)
        _log('%s is the main model now' % model.split('/')[-1])
    except Exception:
        pass


_NAME = re.compile(r'^models/gemini-(?:\d+(?:\.\d+)?-)?flash(?:-lite)?(?:-latest|-preview[\w.-]*|-\d{3})?$')


class GeminiError(ValueError):
    """Said to the user as it is (never with the key in it)."""


def api_key():
    try:
        from .settings_snapshot import cached_addon
        return (cached_addon().getSetting(SETTING) or '').strip()
    except Exception:
        return ''


def api_keys():
    """8.1.5: every Gemini key set (the first, then the second), each once."""
    try:
        from .settings_snapshot import cached_addon
        addon = cached_addon()
        found = [(addon.getSetting(name) or '').strip() for name in (SETTING, SETTING_2)]
    except Exception:
        found = [api_key()]
    return [key for i, key in enumerate(found) if len(key) >= 20 and key not in found[:i]]


def _of(key):
    with _lock:
        state = _keys.get(key)
        if state is None:
            state = _keys[key] = {'last': 0.0, 'spent': set(), 'cool': {}, 'models': [], 'models_at': 0.0,
                                  'lock': threading.Lock()}
        return state


def configured():
    return bool(api_keys())


def _call(path, key, body=None, timeout=TIMEOUT):
    data = json.dumps(body).encode('utf-8') if body is not None else None
    request = Request(BASE + path, data=data, method='POST' if data else 'GET',
                      headers={'x-goog-api-key': key, 'Content-Type': 'application/json'})
    with urlopen(request, timeout=timeout) as reply:
        return json.loads(reply.read().decode('utf-8', 'replace') or '{}')


def _version(name):
    numbers = re.findall(r'(\d+(?:\.\d+)?)', name.split('/')[-1])
    return float(numbers[0]) if numbers else 0.0


def models(key=None):
    """The Flash models this key may use for text, best first (cached a day)."""
    key = key or api_key()
    now = time.time()
    state = _of(key)
    if state['models'] and now - state['models_at'] < MODELS_LIFE:
        return list(state['models'])
    try:
        answer = _call('/models?pageSize=200', key, timeout=20)
    except HTTPError as exc:
        if exc.code in (400, 401, 403):
            raise GeminiError('Gemini did not accept the API key.')
        raise GeminiError('Gemini did not answer (HTTP %s).' % exc.code)
    except Exception:
        raise GeminiError('Gemini could not be reached.')
    found = []
    for model in answer.get('models') or []:
        name = str(model.get('name') or '')
        low = name.lower()
        if 'generateContent' not in (model.get('supportedGenerationMethods') or []) or not _NAME.match(low):
            continue                           # 8.1.3: Flash and Flash-Lite text models only (not "omni" and the like)
        if any(word in low for word in SKIP):
            continue
        lite = 'lite' in low
        preview = 'preview' in low or 'exp' in low
        # 8.1.5: Flash-Lite first, the newest first - it answers in seconds and translates
        # subtitles as well as the full Flash, which went past 60 s again and again (a whole
        # film took 280 s; with Flash-Lite first 47 s). The full Flash models stand in.
        found.append(((not lite, preview, -_version(name), name), name))
    names = [name for _, name in sorted(found)]
    if not names:
        raise GeminiError('This Gemini key has no Flash model to use.')
    state.update(models=names, models_at=now)
    return list(names)


def _pace(key):
    state = _of(key)
    with state['lock']:
        wait = GAP - (time.monotonic() - state['last'])
        if wait > 0:
            time.sleep(wait)
        state['last'] = time.monotonic()


def _retry_delay(body):
    try:
        for detail in json.loads(body).get('error', {}).get('details') or []:
            delay = str(detail.get('retryDelay') or '')
            if delay.endswith('s'):
                return min(90.0, float(delay[:-1]) + 1)
    except Exception:
        pass
    return 0.0


def _per_day(body):
    return bool(re.search(r'per ?day|PerDay|daily', body or '', re.I))


def generate(prompt, system, schema=None, temperature=.3, stopped=lambda: False, key=None):
    """The model's text answer (JSON text when ``schema``). Raises GeminiError."""
    key = key or (api_keys() or [''])[0]
    if not key:
        raise GeminiError('Add your Gemini API key in HUB Settings > API keys.')
    config = {'temperature': temperature}
    if schema is not None:
        config.update(responseMimeType='application/json', responseSchema=schema)
    waited_since = time.monotonic()
    while True:
        state = _of(key)
        names = [m for m in models(key) if m not in state['spent']]
        main = main_model()
        if main in names:                      # the one that worked last time first
            names.remove(main)
            names.insert(0, main)
        if not names:
            raise GeminiError("Gemini's free requests for today are used up. Try again tomorrow.")
        ready = [m for m in names if state['cool'].get(m, 0) <= time.monotonic()]
        if not ready:
            if time.monotonic() - waited_since > WAIT_ALL:
                raise GeminiError('Gemini is too busy right now. Try again in a few minutes.')
            wait = max(1.0, min(state['cool'].get(m, 0) for m in names) - time.monotonic())
            _log('every model is busy - waiting %.0f s' % wait)
            time.sleep(wait)
            continue
        answer_text = _ask(ready[0], key, prompt, system, config, stopped)
        if answer_text is not None:
            _remember(ready[0])
            return answer_text


def _ask(model, key, prompt, system, config, stopped):
    """The text from one model, or None when it is busy / out for today (marked so)."""
    # thinking as little as each model allows: off for 2.x; for 3.x the lowest level it
    # takes ("minimal" was refused by gemini-3.8-flash, then "low"), else none sent
    levels = ['minimal', 'low', None] if _version(model) >= 3 else ['off', None]
    tries = 0
    while tries < TRIES:
        if stopped():
            raise GeminiError('Stopped.')
        tries += 1
        level = levels[0]
        settle = {} if level is None else {'thinkingConfig': {'thinkingBudget': 0} if level == 'off'
                                            else {'thinkingLevel': level}}
        body = {'systemInstruction': {'parts': [{'text': system}]},
                'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
                'generationConfig': dict(config, **settle),
                'safetySettings': SAFETY}
        _pace(key)
        began = time.monotonic()
        try:
            answer = _call('/%s:generateContent' % model, key, body)
            _log('%s answered in %.1f s' % (model.split('/')[-1], time.monotonic() - began))
        except HTTPError as exc:
            text = ''
            try:
                text = exc.read().decode('utf-8', 'replace')
            except Exception:
                pass
            _log('%s: HTTP %s after %.1f s' % (model.split('/')[-1], exc.code, time.monotonic() - began))
            if exc.code == 400 and levels[0] is not None and 'thinking' in text.lower():
                levels.pop(0)                      # not this setting: the next one down
                tries -= 1
                continue
            if exc.code in (401, 403):
                raise GeminiError('Gemini did not accept the API key.')
            if exc.code == 429:
                if _per_day(text):
                    _of(key)['spent'].add(model)   # this model's day is over (for this key) - the next one
                    _log('%s: today\'s free requests are used up - the next model' % model.split('/')[-1])
                    return None
                wait = _retry_delay(text) or 15 * tries
                _log('too many requests - waiting %.0f s as asked' % wait)
                time.sleep(wait)
                continue
            if exc.code in (500, 502, 503, 504):
                if exc.code == 503 and tries >= 2:
                    _of(key)['cool'][model] = time.monotonic() + COOL   # overloaded: left alone a minute
                    _log('%s is overloaded - the next model for a minute' % model.split('/')[-1])
                    return None
                time.sleep(5 * tries)
                continue
            if exc.code == 404:
                _of(key)['spent'].add(model)       # gone since the list was read
                return None
            raise GeminiError('Gemini refused the request (HTTP %s).' % exc.code)
        except GeminiError:
            raise
        except Exception as exc:
            _log('%s: no answer (%s) after %.1f s' % (model.split('/')[-1], type(exc).__name__, time.monotonic() - began))
            if 'timeout' in type(exc).__name__.lower() or 'timed out' in str(exc).lower():
                _of(key)['cool'][model] = time.monotonic() + SLOW_COOL   # 8.1.5: too slow - half an hour off
                return None
            time.sleep(5 * tries)
            continue
        candidates = answer.get('candidates') or []
        parts = ((candidates[0].get('content') or {}).get('parts') or []) if candidates else []
        text = ''.join(str(part.get('text') or '') for part in parts if not part.get('thought'))
        if text.strip():
            return text
        reason = (candidates[0].get('finishReason') if candidates else '') or \
            ((answer.get('promptFeedback') or {}).get('blockReason') or 'empty')
        raise GeminiError('Gemini gave no text (%s).' % reason)
    _of(key)['cool'][model] = time.monotonic() + COOL   # asked TRIES times without an answer
    return None
