# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Does the server of a link answer at all? (8.1.5) - asked before Kodi gets the link.

A TorBox link listed as ready (TorBox's API answers) was served from a download server
that refused every connection from the person's network. Kodi tried it for 5-6 s and
put up its own "Playback failed" over the loading screen, and the next source had to
wait for that. One byte is asked here first, through the redirects (StremThru hands on
to the same download server); only a server that cannot be reached at all counts - a
slow one, or one that answers with an error Kodi may still get past (its own headers),
is left to Kodi as before.
"""
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl
from urllib.request import Request, urlopen

WAIT = 4.0


def unreachable(url):
    """Why the server of ``url`` cannot be reached ('' when it can, or when unsure)."""
    text = str(url or '')
    address, _, extra = text.partition('|')
    if not address.startswith(('http://', 'https://')):
        return ''
    headers = dict(parse_qsl(extra)) if extra else {}
    try:
        from .mkv_subtitle_times import kodi_headers, web_address
        headers = kodi_headers(headers)
        address = web_address(address)
    except Exception:
        pass
    try:
        with urlopen(Request(address, headers=dict(headers, Range='bytes=0-0')), timeout=WAIT) as reply:
            reply.read(1)
        return ''
    except HTTPError:
        return ''                      # it answered - Kodi's own request may still go through
    except URLError as exc:            # no connection at all: refused, no route, no name, no answer
        reason = getattr(exc, 'reason', exc)
        return '%s (%s)' % (type(reason).__name__, str(reason)[:60])
    except Exception:
        return ''                      # connected and slow to send: Kodi's to judge
