# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The user's own Prowlarr as a torrent search for the debrid services (7.0.45).

Prowlarr runs on the user's server with the user's torrent indexers. MegaNexus
asks it once per title (/api/v1/search, every indexer at once, the title by its
IMDb ID - an episode with its season and episode) and takes only the names,
sizes, seeders and info hashes: a few kilobytes, so the server's bandwidth is not
used. The hashes join the public index's (debrid.index), the user's TorBox /
Premiumize / Offcloud says which are cached, and the film comes from the debrid
service's servers - never through Prowlarr.

Kept in the hidden setting ``prowlarr_server`` as ``url|apikey``; the key is never
shown again or written to the log. An answer is kept CACHE_TTL.
"""
import json
import re
import threading
import time
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen

SETTING = 'prowlarr_server'
TIMEOUT = 25
MAX_BYTES = 4 * 1024 * 1024
MAX_ITEMS = 120
CACHE_TTL = 6 * 3600
CATEGORY = {'movie': '2000', 'series': '5000'}
_HASH = re.compile(r'(?:btih:)?([0-9a-fA-F]{40})')
_LOCK = threading.Lock()
_CACHE = {}


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_snapshot import cached_addon
    return cached_addon()


def base_url(url):
    url = str(url or '').strip().rstrip('/')
    if not re.match(r'https?://[^/\s]+', url, re.I):
        raise ValueError('Enter your Prowlarr address, e.g. http://192.168.1.10:9696.')
    return re.sub(r'/api(?:/v1)?(?:/search)?$', '', url, flags=re.I)


def parse(value):
    """'http://host:9696 KEY' / 'url|key' -> (base_url, key)."""
    text = str(value or '').strip()
    if not text:
        return None
    pieces = re.split(r'[|\s]+', text, maxsplit=1)
    url, key = pieces[0], (pieces[1] if len(pieces) > 1 else '').strip()
    if not key or any(ch.isspace() for ch in key):
        raise ValueError('Enter Prowlarr as its address and API key (Settings > General in Prowlarr).')
    return base_url(url), key


def server(addon=None):
    try:
        return parse((_addon(addon).getSetting(SETTING) or '').replace('|', ' '))
    except ValueError:
        return None


def name(url):
    return urlsplit(url).netloc or 'Prowlarr'


def _get(url, key, path, params=None, timeout=TIMEOUT):
    request = Request(url + path + ('?' + urlencode(params) if params else ''),
                      headers={'X-Api-Key': key, 'Accept': 'application/json', 'User-Agent': 'MegaNexus/7'})
    try:
        with urlopen(request, timeout=timeout) as response:
            body = response.read(MAX_BYTES + 1)
    except Exception as exc:
        code = getattr(exc, 'code', None)
        if code in (401, 403):
            raise ValueError('Prowlarr did not accept the API key')
        # The address may hold credentials: only the kind of failure is told.
        raise ValueError('Prowlarr gave no answer (%s)' % (code or type(exc).__name__))
    if len(body) > MAX_BYTES:
        raise ValueError('the answer was too large')
    try:
        return json.loads(body.decode('utf-8', 'replace'))
    except ValueError:
        raise ValueError('Prowlarr gave an unexpected answer')


def check(url, key):
    """'' when Prowlarr answers with this key and has torrent indexers, else what is wrong."""
    try:
        indexers = _get(url, key, '/api/v1/indexer', timeout=10)
    except Exception as exc:
        return str(exc)
    if not isinstance(indexers, list):
        return 'Prowlarr gave an unexpected answer'
    torrent = [i for i in indexers if isinstance(i, dict) and i.get('enable', True) and str(i.get('protocol') or '').lower() == 'torrent']
    return '' if torrent else 'Prowlarr has no torrent indexer switched on'


def save_value(value, addon=None):
    addon = _addon(addon)
    found = parse(value)
    if found:
        reason = check(*found)
        if reason:
            raise ValueError('%s.' % reason)
    addon.setSetting(SETTING, '%s|%s' % found if found else '')
    try:
        from . import settings_snapshot
        settings_snapshot.invalidate()
    except Exception:
        pass


def query(imdb, season=None, episode=None):
    """Prowlarr's own search syntax (its NewznabRequest): {ImdbId:tt..}{Season:1}{Episode:2}."""
    text = '{ImdbId:%s}' % imdb
    if season is not None:
        text += '{Season:%d}{Episode:%d}' % (int(season), int(episode))
    return text


def items(rows, season=None, episode=None):
    """Prowlarr's releases -> the debrid index's items (torrents with an info hash only)."""
    from .debrid import _episode_match
    found, seen = [], set()
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict) or str(row.get('protocol') or 'torrent').lower() != 'torrent':
            continue
        digest = str(row.get('infoHash') or '').lower()
        if not re.fullmatch(r'[0-9a-f]{40}', digest):
            found_hash = _HASH.search(str(row.get('magnetUrl') or ''))
            digest = found_hash.group(1).lower() if found_hash and 'btih' in str(row.get('magnetUrl') or '') else ''
        title = str(row.get('title') or '').strip()
        if not digest or digest in seen or not title:
            continue
        # a season pack is kept (the episode is picked from its files); another episode is not
        if season is not None and re.search(r's\d+[ ._-]*e\d+', title, re.I) and not _episode_match(title, season, episode):
            continue
        seen.add(digest)
        try:
            size = float(row.get('size') or 0)
        except (TypeError, ValueError):
            size = 0
        found.append({'hash': digest, 'title': title, 'filename': title, 'size': size,
                      'seeders': int(row.get('seeders') or 0), 'file_idx': None,
                      'label': str(row.get('indexer') or 'Prowlarr')})
        if len(found) >= MAX_ITEMS:
            break
    found.sort(key=lambda item: -item['seeders'])
    return found


def search(kind, imdb, season=None, episode=None, addon=None):
    """The title's torrents from the user's Prowlarr ([] when none is set)."""
    found = server(addon)
    if not found:
        return []
    url, key = found
    cache_key = '%s|%s|%s|%s' % (url, imdb, season, episode)
    with _LOCK:
        kept = _CACHE.get(cache_key)
    if kept and time.time() - kept[0] < CACHE_TTL:
        return kept[1]
    params = {'query': query(imdb, season, episode), 'type': 'tvsearch' if season is not None else 'movie',
              'categories': CATEGORY['series' if season is not None else 'movie'], 'limit': 200}
    try:
        rows = items(_get(url, key, '/api/v1/search', params), season, episode)
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('[MegaNexus] Prowlarr: %s' % exc, xbmc.LOGINFO)
        except Exception:
            pass
        return []
    with _LOCK:
        _CACHE[cache_key] = (time.time(), rows)
        while len(_CACHE) > 60:
            _CACHE.pop(next(iter(_CACHE)))
    return rows
