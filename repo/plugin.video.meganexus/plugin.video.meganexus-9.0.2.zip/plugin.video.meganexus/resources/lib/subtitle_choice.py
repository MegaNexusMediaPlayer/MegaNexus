# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Which subtitle may come on by itself, and which one the player starts with.

A machine-made subtitle (a provider's own AI track) is offered like any other, but is
never switched on unless the user picked it: its timing is usually right and its words
often are not, and a wrong subtitle nobody chose reads as our mistake.

Providers say so in no agreed way - a flag, a name, a model, a path - so a row is read
whole and judged on what it says about itself.
"""

# A flag has to be exactly True: providers also send 'no' and 0 in these.
MACHINE_FLAGS = ('is_ai', 'ai', 'generated', 'ai_generated')
# Each one is bounded, by punctuation or spaces, so 'Thai' and 'Spain' stay subtitles.
MACHINE_WORDS = ('ai_public', 'ai-generated', 'ai_generated', '/ai/', ' ai ',
                 'artificial intelligence')
BY_HAND_FLAGS = ('user_selected', 'manual_selected')
# Every field a provider may put its own name, service, model or link in.
DESCRIBING = ('sourceName', 'providerName', 'provider', 'addonName', 'addon', 'sourceAddon',
              'source', 'sourceType', 'origin', 'title', 'displayName', 'name', 'url', 'key',
              'id', 'type', 'category', 'model')


def _as_described(row):
    return ' '.join(str((row or {}).get(field) or '') for field in DESCRIBING).lower()


def made_by_machine(row):
    """A flag the provider set, or its own words giving it away."""
    if any((row or {}).get(flag) is True for flag in MACHINE_FLAGS):
        return True
    said = _as_described(row)
    return any(word in said for word in MACHINE_WORDS)


def asked_for_by_hand(row):
    """The user chose this one, so what it is made of is their business."""
    row = row or {}
    return bool(any(row.get(flag) for flag in BY_HAND_FLAGS)
                or str(row.get('sourceType') or '').lower() == 'manual')


def allow_automatic(row):
    return bool(row) and (asked_for_by_hand(row) or not made_by_machine(row))


def automatic_rows(rows):
    """The same rows in the same order, without the ones that may not come on alone."""
    return [row for row in (rows or []) if allow_automatic(row)]


def selected_first(rows, forced, chosen, context, pick_index):
    """(the one to list first, the rest) - ([], all of them) when none was asked for.

    ``pick_index`` reads the user's own preference and may fail on a row it cannot
    make sense of; the first subtitle is then as good an answer as any.
    """
    rows = list(rows or [])
    if not rows or not (forced or chosen):
        return [], rows
    try:
        place = pick_index(rows, context)
    except Exception:
        place = 0
    if not 0 <= place < len(rows):
        return [], rows                       # a preference for something not on offer
    return [rows[place]], rows[:place] + rows[place + 1:]


def wanted_languages():
    """The user's subtitle languages; English when nothing is set or readable."""
    try:
        from .subtitle_search import wanted_languages as preferred
        return [str(language).lower() for language in (preferred() or [])] or ['en']
    except Exception:
        return ['en']


def _language_of(row):
    """'hr' for 'hr-HR': a region is still its language."""
    return str((row or {}).get('lang_key') or '').lower().split('-')[0]


def first_to_turn_on(prepared, paths):
    """(path, its place in ``paths``) of the subtitle the player starts with.

    The user's languages decide, in their order, before the order the providers
    answered in; a subtitle without a file, and one no one asked for that a machine
    wrote, cannot be it.
    """
    if not paths:
        return '', -1
    usable = [row for row in (prepared or []) if (row or {}).get('path') and allow_automatic(row)]
    if not usable:
        return '', -1
    best_per_language = {}
    for row in usable:
        best_per_language.setdefault(_language_of(row), row)
    chosen = next((best_per_language[language] for language in wanted_languages()
                   if language in best_per_language), usable[0])
    path = chosen.get('path') or ''
    try:
        return path, paths.index(path)
    except ValueError:
        return path, 0
