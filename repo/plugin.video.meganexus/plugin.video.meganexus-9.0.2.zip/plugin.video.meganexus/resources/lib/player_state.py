# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Asking Kodi about the player without stopping all Python (7.0.52, GitHub issue #13).

Leaving a Usenet film took 5 minutes on a TV box. When a film closes, Kodi
holds its player lock and records the file in its database, and on the way it
reads the file's date from our local Usenet server (an HTTP HEAD). Kodi's
xbmc.Player() questions - isPlayingVideo(), getTime() and the others - wait
for that same lock while keeping Python's lock (the GIL, shared by every add-on).
All Python then stood still, so the server could not answer Kodi's request,
and Kodi only went on after its timeouts ran out: 4 requests, 3 tries each.

Kodi's JSON-RPC lets go of Python while it waits. So while one of our local
streams plays, the MegaNexus Player asks through JSON-RPC instead, and the
server answers at once. With no local stream, every call works as before.
install() swaps xbmc.Player in the calling script for this Player.
"""
import json
import time

import xbmc

FLAG = 'meganexus.local_stream'       # Window(Home): set by the Usenet server while it serves a film
CHECK_EVERY = 0.5                     # s the flag is read again (cheap on Home: one read per half second)
_flag = {'at': -10.0, 'on': False}


def local_stream():
    """A film from our local server plays (or played a moment ago)."""
    now = time.monotonic()
    if now - _flag['at'] >= CHECK_EVERY:
        try:
            import xbmcgui
            _flag['on'] = bool(xbmcgui.Window(10000).getProperty(FLAG))
        except Exception:
            _flag['on'] = False
        _flag['at'] = now
    return _flag['on']


def leaving():
    """MegaNexus is about to stop a film: a local stream ends its waits at once, so Kodi closes
    the film without waiting for an article (usenet_stream: the OSD Stop button says the same)."""
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        told = False
        if home.getProperty('meganexus.usenet.port'):  # the Usenet player runs (in Kodi or as the engine)
            home.setProperty('meganexus.leaving', '1')
            told = True
        if xbmc.getInfoLabel('Player.Filenameandpath').startswith('mnxusenet://'):
            from .usenet_native import leaving as native_leaving
            told = native_leaving() or told        # the film is read by vfs.meganexus
        return told
    except Exception:
        pass
    return False


def _rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        request['params'] = params
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except (TypeError, ValueError):
        return None
    return reply.get('result') if isinstance(reply, dict) else None


def active():
    """{player type: player id} of the players playing now ('video', 'audio', 'picture')."""
    found = {}
    for player in _rpc('Player.GetActivePlayers') or []:
        if isinstance(player, dict) and player.get('type'):
            found[player['type']] = player.get('playerid')
    return found


def _seconds(value):
    if not isinstance(value, dict):
        return 0.0
    return (value.get('hours', 0) * 3600 + value.get('minutes', 0) * 60 + value.get('seconds', 0)
            + value.get('milliseconds', 0) / 1000.0)


def _position(name):
    players = active()
    playerid = players.get('video', players.get('audio'))
    if playerid is None:
        raise RuntimeError('Kodi is not playing any media file')
    result = _rpc('Player.GetProperties', {'playerid': playerid, 'properties': [name]}) or {}
    return _seconds(result.get(name))


def install():
    """xbmc.Player becomes the MegaNexus Player in this script (once; subclasses made later
    inherit it). Returns the Player class."""
    native = xbmc.Player
    if not isinstance(native, type) or getattr(native, '_meganexus_safe', False):
        return native

    class Player(native):
        _meganexus_safe = True

        def isPlaying(self):
            if local_stream():
                players = active()
                return 'video' in players or 'audio' in players
            return native.isPlaying(self)

        def isPlayingVideo(self):
            if local_stream():
                return 'video' in active()
            return native.isPlayingVideo(self)

        def isPlayingAudio(self):
            if local_stream():
                return 'audio' in active() and 'video' not in active()
            return native.isPlayingAudio(self)

        def getTime(self):
            if local_stream():
                return _position('time')
            return native.getTime(self)

        def getTotalTime(self):
            if local_stream():
                return _position('totaltime')
            return native.getTotalTime(self)

    def guarded(name):
        call = getattr(native, name)

        def method(self, *args, **kwargs):
            # the rest have no JSON-RPC twin: asked only while a player is open, never while
            # one closes (a closing player is no longer listed)
            if local_stream() and not active():
                raise RuntimeError('Kodi is not playing any file')
            return call(self, *args, **kwargs)
        method.__name__ = name
        return method

    for name in ('getPlayingFile', 'getPlayingItem', 'getVideoInfoTag', 'getSubtitles',
                 'getAvailableSubtitleStreams', 'getAvailableAudioStreams', 'getAvailableVideoStreams'):
        if hasattr(native, name):
            setattr(Player, name, guarded(name))
    xbmc.Player = Player
    return Player
