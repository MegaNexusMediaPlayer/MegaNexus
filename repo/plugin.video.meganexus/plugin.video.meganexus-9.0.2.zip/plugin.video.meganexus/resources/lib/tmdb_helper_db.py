# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""What TMDb Helper already keeps on this device: ids, details and artwork of the titles it
has shown, read from its ItemDetails.db - no request to TMDB.

The file is opened read-only (TMDb Helper's own service writes it). Its tables and columns
changed over TMDb Helper's versions, so every lookup first asks which columns a table has
(once per table and connection) and uses the names that are there. Answers are kept in a
small memory (MEMO entries); a missing file costs nothing."""
import json
import re
import sqlite3
from collections import OrderedDict
from contextlib import contextmanager
from functools import lru_cache

import xbmcvfs

TMDB_IMAGES = 'https://image.tmdb.org/t/p/'
SIZES = {'poster': 'w500', 'backdrop': 'w1280', 'logo': 'w500'}   # Kodi never shows them bigger
DATABASES = tuple('special://userdata/addon_data/plugin.video.themoviedb.helper/database_%02d/ItemDetails.db' % n
                  for n in (10, 9, 8, 7, 6, 5))
MEMO = 1024

TV_WORDS = ('tvshow', 'episode', 'season', 'series', 'show', 'tv')
TITLE_COLUMNS = ('title', 'name', 'label', 'originaltitle', 'originalname', 'showname')
TMDB_COLUMNS = ('tmdb_id', 'tmdb')
IMDB_COLUMNS = ('imdb_id', 'imdb')
TVDB_COLUMNS = ('tvdb_id', 'tvdb')
KIND_COLUMNS = ('media_type', 'mediatype', 'type')
YEAR_COLUMNS = ('year', 'release_year')
OWNER_COLUMNS = ('parent_id', 'item_id', 'media_id', 'dbid')
NAME_COLUMNS = ('name', 'title', 'value', 'label')
ORDER_COLUMNS = ('order', 'sort_order', 'sortorder', 'ordering')
ID_TABLES = ('unique_ids', 'item_ids', 'items')

# the artwork kinds asked for -> image size; the kinds searched first for each
ART_SIZE = {'posters': 'poster', 'poster': 'poster', 'thumb': 'poster', 'backdrops': 'backdrop',
            'fanarts': 'backdrop', 'landscape': 'backdrop', 'stills': 'backdrop', 'logos': 'logo',
            'clearlogo': 'logo'}
ART_FIRST = {'fanarts': 'backdrops', 'landscape': 'backdrops', 'thumb': 'posters', 'clearlogo': 'logos'}
ENGLISH_FIRST = "CASE WHEN iso_language='en' THEN 0 WHEN iso_language IS NULL THEN 1 ELSE 2 END"
FANART_TV = {'logos': 'logos', 'clearlogo': 'logos', 'fanarts': 'backdrops', 'landscape': 'backdrops',
             'backdrops': 'backdrops'}

_memo = OrderedDict()


def _remember(key, value):
    if key not in _memo:
        _memo[key] = value
        if len(_memo) > MEMO:
            _memo.popitem(last=False)


def kind_of(media_type):
    return 'tv' if media_type in TV_WORDS else 'movie'


def image(icon, kind='poster'):
    """A full image address: kept as it is when it is one, else TMDB's at the size for its kind."""
    icon = str(icon or '').strip()
    if icon and '](' in icon:   # a markdown link [x](address)
        icon = icon.split('](')[-1].replace(')', '')
    if not icon or icon.startswith('http'):
        return icon
    return TMDB_IMAGES + SIZES.get(kind, SIZES['poster']) + icon


@lru_cache(maxsize=1)
def _database():
    for candidate in DATABASES:
        try:
            path = xbmcvfs.translatePath(candidate)
            if xbmcvfs.exists(path):
                return path
        except Exception:
            continue
    return ''


class _Reader(object):
    """One read-only connection; knows each table's columns after asking once."""

    def __init__(self, path):
        self.connection = sqlite3.connect('file:%s?mode=ro' % path, uri=True, timeout=2)
        self._columns = {}

    def columns(self, table):
        if table not in self._columns:
            try:
                self._columns[table] = [row[1] for row in self.connection.execute('PRAGMA table_info(%s)' % table)]
            except Exception:
                self._columns[table] = []
        return self._columns[table]

    def pick(self, table, names):
        present = self.columns(table)
        return next((name for name in names if name in present), '')

    def row(self, sql, params=()):
        try:
            return self.connection.execute(sql, tuple(params)).fetchone()
        except Exception:
            return None

    def rows(self, sql, params=()):
        try:
            return self.connection.execute(sql, tuple(params)).fetchall() or []
        except Exception:
            return []

    def digits(self, sql, params=()):
        """The first column of the first row when it is a number ('' otherwise)."""
        found = self.row(sql, params)
        value = str(found[0]) if found and found[0] not in (None, '') else ''
        return value if value.isdigit() else ''

    def as_dict(self, table, row):
        names = self.columns(table)
        return {} if not names or row is None else dict(zip(names, row))

    def close(self):
        self.connection.close()


@contextmanager
def _reading():
    """A reader of TMDb Helper's file, or None when there is none (or it can not be opened)."""
    path = _database()
    reader = None
    if path:
        try:
            reader = _Reader(path)
        except Exception:
            reader = None
    try:
        yield reader
    finally:
        if reader is not None:
            reader.close()


def _plain(title):
    return re.sub(r'\s+', ' ', str(title or '')).strip().lower()


def _year_digits(year):
    return str(year or '').isdigit()


# ---- TMDB id of a title ----------------------------------------------------------------

def _tmdb_for_imdb(reader, imdb_id, kind):
    if not imdb_id:
        return ''
    own = 'tvshow' if kind == 'tv' else 'movie'
    asks = []
    for table in ('unique_ids', 'item_ids'):
        for tmdb, imdb in (('tmdb_id', 'imdb_id'), ('tmdb', 'imdb')):
            asks.append(('SELECT %s FROM %s WHERE %s=? LIMIT 1' % (tmdb, table, imdb), (imdb_id,)))
    asks.append(('SELECT tmdb_id FROM items WHERE imdb_id=? AND media_type=? LIMIT 1', (imdb_id, kind)))
    asks.append(('SELECT tmdb_id FROM items WHERE imdb_id=? LIMIT 1', (imdb_id,)))
    for key in ('imdb_id', 'imdb'):   # TMDb Helper 5+: unique_id(key, value, parent_id)
        asks.append(('SELECT {0}.tmdb_id FROM unique_id JOIN {0} ON {0}.id=unique_id.parent_id '
                     "WHERE unique_id.key='{1}' AND unique_id.value=? LIMIT 1".format(own, key), (imdb_id,)))
    for sql, params in asks:
        found = reader.digits(sql, params)
        if found:
            return found
    return ''


def _tmdb_for_title(reader, title, kind, year=''):
    words = _plain(title)
    if not str(title or '').strip():
        return ''
    for table in ('tvshow' if kind == 'tv' else 'movie', 'items', 'item_ids', 'unique_ids'):
        titles = [name for name in TITLE_COLUMNS if name in reader.columns(table)]
        tmdb = reader.pick(table, TMDB_COLUMNS)
        if not titles or not tmdb:
            continue
        kind_column, year_column = reader.pick(table, KIND_COLUMNS), reader.pick(table, YEAR_COLUMNS)
        for column in titles:
            sql, params = 'SELECT %s FROM %s WHERE lower(%s)=?' % (tmdb, table, column), [words]
            if kind_column:
                sql += ' AND %s=?' % kind_column
                params.append('tvshow' if kind == 'tv' and table == 'tvshow' else kind)
            if year_column and _year_digits(year):
                sql += ' AND %s=?' % year_column
                params.append(int(year))
            found = reader.digits(sql + ' LIMIT 1', params)
            if found:
                return found
    return ''


# ---- external ids ----------------------------------------------------------------------

def _take_ids(found, row, columns):
    """Fill the ids still missing from one row of (tmdb, imdb, tvdb) columns."""
    values = dict(zip([name for name in columns if name], row))
    tmdb_col, imdb_col, tvdb_col = columns
    if tmdb_col and not found['tmdb_id']:
        value = str(values.get(tmdb_col) or '').strip()
        if value.isdigit():
            found['tmdb_id'] = value
    if imdb_col and not found['imdb_id']:
        value = str(values.get(imdb_col) or '').strip()
        if value:
            found['imdb_id'] = value if value.startswith('tt') else ('tt' + value if value.isdigit() else value)
    if tvdb_col and not found['tvdb_id']:
        value = str(values.get(tvdb_col) or '').strip()
        if value.isdigit():
            found['tvdb_id'] = value
    return bool(found['tmdb_id'] and found['imdb_id'])


def _id_columns(reader, table):
    return reader.pick(table, TMDB_COLUMNS), reader.pick(table, IMDB_COLUMNS), reader.pick(table, TVDB_COLUMNS)


def _ids_by_id(reader, found, kind):
    for table in ID_TABLES:
        columns = _id_columns(reader, table)
        chosen = [name for name in columns if name]
        tests, params = [], []
        for name, key in zip(columns, ('tmdb_id', 'imdb_id', 'tvdb_id')):
            if found[key] and name:
                tests.append('%s=?' % name)
                params.append(found[key])
        if not chosen or not tests:
            continue
        sql = 'SELECT %s FROM %s WHERE (%s)' % (', '.join(chosen), table, ' OR '.join(tests))
        kind_column = reader.pick(table, KIND_COLUMNS)
        if kind_column:
            sql += ' AND %s=?' % kind_column
            params.append(kind)
        row = reader.row(sql + ' LIMIT 1', params)
        if row and _take_ids(found, row, columns):
            return


def _ids_by_title(reader, found, kind, title, year):
    words = _plain(title)
    for table in ('items', 'item_ids', 'unique_ids'):
        titles = [name for name in TITLE_COLUMNS if name in reader.columns(table)]
        if not titles:
            continue
        columns = _id_columns(reader, table)
        chosen = [name for name in columns if name]
        if not chosen:
            continue
        kind_column, year_column = reader.pick(table, KIND_COLUMNS), reader.pick(table, YEAR_COLUMNS)
        for column in titles:
            sql, params = 'SELECT %s FROM %s WHERE lower(%s)=?' % (', '.join(chosen), table, column), [words]
            if kind_column:
                sql += ' AND %s=?' % kind_column
                params.append(kind)
            if year_column and _year_digits(year):
                sql += ' AND %s=?' % year_column
                params.append(int(year))
            row = reader.row(sql + ' LIMIT 1', params)
            if row and _take_ids(found, row, columns):
                return


def get_external_ids_from_db(tmdb_id='', media_type='movie', imdb_id='', tvdb_id='', title='', year=''):
    """IMDb / TMDB / TVDB ids TMDb Helper knows for a title (the ones given are kept). Stream
    add-ons answer best to an IMDb id, while a title from TMDb Helper often arrives as tmdb:123."""
    kind = kind_of(media_type)
    found = {'tmdb_id': str(tmdb_id or '').strip(), 'imdb_id': str(imdb_id or '').strip(),
             'tvdb_id': str(tvdb_id or '').strip()}
    key = 'ids:%s:%s:%s:%s:%s:%s' % (kind, found['tmdb_id'], found['imdb_id'], found['tvdb_id'], title or '',
                                       year or '')
    if key in _memo:
        return dict(_memo[key] or {})
    try:
        with _reading() as reader:
            if reader is not None:
                _ids_by_id(reader, found, kind)
                if (not found['imdb_id'] or not found['tmdb_id']) and title:
                    _ids_by_title(reader, found, kind, title, year)
    except Exception:
        pass
    _remember(key, dict(found))
    return found


# ---- details ---------------------------------------------------------------------------

def _value(raw):
    """A stored value as Python: numbers stay, JSON lists / objects are read, text trimmed."""
    if raw in (None, ''):
        return ''
    if isinstance(raw, bytes):
        try:
            raw = raw.decode('utf-8', 'ignore')
        except Exception:
            return ''
    if isinstance(raw, (int, float)):
        return raw
    text = str(raw).strip()
    if text[:1] in ('{', '['):
        try:
            return json.loads(text)
        except Exception:
            return text
    return text


def _names(raw):
    """A list of names out of a JSON list / object or "a, b / c | d" text - each once."""
    raw = _value(raw)
    found = []
    if isinstance(raw, list):
        for entry in raw:
            if isinstance(entry, dict):
                name = next((entry.get(k) for k in NAME_COLUMNS if entry.get(k)), '')
                if name:
                    found.append(str(name).strip())
            elif entry not in (None, ''):
                found.append(str(entry).strip())
    elif isinstance(raw, dict):
        name = next((raw.get(k) for k in NAME_COLUMNS if raw.get(k)), None)
        if name:
            found.append(str(name).strip())
    else:
        text = str(raw or '').strip()
        if text and (',' in text or ' / ' in text or '|' in text):
            found += [part.strip() for part in re.split(r'\s*(?:,|/|\|)\s*', text) if part.strip()]
        elif text:
            found.append(text)
    out, seen = [], set()
    for name in found:
        name = str(name or '').strip()
        if name and name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)
    return out


EMPTY = (None, '', [], {})


def _field(row, *names):
    """The first of these fields (any letter case) that holds something."""
    by_lower = {str(key).lower(): key for key in (row or {}).keys()}
    for name in names:
        key = name if name in row else by_lower.get(str(name).lower())
        if key:
            value = _value(row.get(key))
            if value not in EMPTY:
                return value
    return ''


def _number(row, *names):
    value = _field(row, *names)
    if value in EMPTY:
        return ''
    try:
        if isinstance(value, str):
            found = re.search(r'\d+(?:\.\d+)?', value.replace(',', ''))
            return float(found.group(0)) if found else ''
        return float(value)
    except Exception:
        return ''


def _title_row(reader, kind, tmdb_id='', imdb_id='', title='', year=''):
    """(the title's row of movie / tvshow / items, its TMDB id)."""
    tmdb = str(tmdb_id or '').strip()
    if not tmdb and imdb_id:
        tmdb = _tmdb_for_imdb(reader, imdb_id, kind)
    if not tmdb and title:
        tmdb = _tmdb_for_title(reader, title, kind, year)
    for table in ('tvshow' if kind == 'tv' else 'movie', 'items'):
        if not reader.columns(table):
            continue
        tmdb_column, kind_column = reader.pick(table, TMDB_COLUMNS), reader.pick(table, KIND_COLUMNS)
        titles = [name for name in TITLE_COLUMNS if name in reader.columns(table)]
        narrow = table == 'items' and kind_column
        row = None
        if tmdb and tmdb_column:
            sql, params = 'SELECT * FROM %s WHERE %s=?' % (table, tmdb_column), [tmdb]
            if narrow:
                sql += ' AND %s=?' % kind_column
                params.append(kind)
            row = reader.row(sql + ' LIMIT 1', params)
        if not row and title and titles:
            year_column = reader.pick(table, YEAR_COLUMNS)
            for column in titles:
                sql, params = 'SELECT * FROM %s WHERE lower(%s)=?' % (table, column), [_plain(title)]
                if narrow:
                    sql += ' AND %s=?' % kind_column
                    params.append(kind)
                if year_column and _year_digits(year):
                    sql += ' AND %s=?' % year_column
                    params.append(int(year))
                row = reader.row(sql + ' LIMIT 1', params)
                if row:
                    break
        if row:
            data = reader.as_dict(table, row)
            if not tmdb and tmdb_column:
                value = str(data.get(tmdb_column) or '').strip()
                if value.isdigit():
                    tmdb = value
            return data, tmdb
    return {}, tmdb


def _owners(kind, tmdb_id='', imdb_id='', tvdb_id='', internal_id=''):
    """The parent ids TMDb Helper may have filed a title's people, genres and pictures under."""
    out = []
    candidates = [internal_id] if internal_id not in (None, '') else []
    if tmdb_id:
        candidates += ['%s.%s' % (kind, tmdb_id)]
        candidates += ['tvshow.%s' % tmdb_id, 'tv.%s' % tmdb_id] if kind == 'tv' else ['movie.%s' % tmdb_id]
        candidates.append(tmdb_id)
    if imdb_id:
        candidates += ['%s.%s' % (kind, imdb_id), '%s.imdb:%s' % (kind, imdb_id), imdb_id]
    if tvdb_id:
        candidates += ['%s.tvdb:%s' % (kind, tvdb_id), tvdb_id]
    for candidate in candidates:
        candidate = str(candidate or '').strip()
        if candidate and candidate not in out:
            out.append(candidate)
    return out


def _owned_rows(reader, table, owners, limit, default_limit):
    """Rows of a table that belong to any of the owners (in its own order when it has one)."""
    owner = reader.pick(table, OWNER_COLUMNS)
    name = reader.pick(table, NAME_COLUMNS)
    if not owner or not name:
        return None, []
    order = reader.pick(table, ORDER_COLUMNS)
    sql = 'SELECT * FROM %s WHERE %s=?' % (table, owner)
    if order:
        sql += ' ORDER BY %s ASC' % order
    sql += ' LIMIT %d' % int(limit or default_limit)
    return name, [(reader.as_dict(table, row)) for parent in owners or [] for row in reader.rows(sql, (parent,))]


def _related(reader, tables, owners, roles=None, limit=30):
    """Names (genres, studios, directors...) filed under the owners, each once."""
    names = []
    for table in tables:
        if not reader.columns(table):
            continue
        name_column, rows = _owned_rows(reader, table, owners, limit, 30)
        if not name_column:
            continue
        role_column = reader.pick(table, ('role', 'job', 'department', 'type'))
        for data in rows:
            if roles and role_column and not any(role in str(data.get(role_column) or '').lower() for role in roles):
                continue
            name = str(_value(data.get(name_column)) or '').strip()
            if name:
                names.append(name)
    out, seen = [], set()
    for name in names:
        if name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)
    return out[:limit]


def _cast(reader, owners, limit=25):
    people = []
    for table in ('cast', 'actors', 'actor', 'credits_cast'):
        if not reader.columns(table):
            continue
        name_column, rows = _owned_rows(reader, table, owners, limit, 25)
        if not name_column:
            continue
        role_column = reader.pick(table, ('character', 'role', 'castrole'))
        picture_column = reader.pick(table, ('thumbnail', 'thumb', 'profile_path', 'icon', 'image'))
        for data in rows:
            name = str(_value(data.get(name_column)) or '').strip()
            if not name:
                continue
            picture = str(_value(data.get(picture_column)) or '').strip() if picture_column else ''
            people.append({'name': name, 'thumbnail': image(picture) if picture.startswith('/') else picture,
                           'role': str(_value(data.get(role_column)) or '').strip() if role_column else ''})
            if len(people) >= limit:
                return people
    return people


# (output keys, row fields) of the plain details
_TEXTS = (
    (('originaltitle',), ('originaltitle', 'original_title', 'originalname', 'original_name')),
    (('description', 'overview', 'plot'), ('plot', 'overview', 'description')),
    (('tagline',), ('tagline',)),
    (('certification', 'mpaa'), ('certification', 'mpaa', 'contentrating', 'content_rating', 'rated')),
    (('trailer',), ('trailer',)),
    (('status',), ('status',)),
)
# (output keys, row fields, related tables, roles)
_LISTS = (
    (('genres', 'genre'), ('genres', 'genre'), ('genre', 'genres'), None),
    (('studios', 'studio'), ('studio', 'studios', 'production_companies', 'productionCompanies', 'network', 'networks'),
     ('studio', 'studios', 'production_company', 'production_companies', 'network', 'networks'), None),
    (('country',), ('country', 'countries', 'origin_country'), ('country', 'countries'), None),
    (('director',), ('director', 'directors'), ('director', 'directors', 'crew', 'credits_crew'), ('director',)),
    (('writer',), ('writer', 'writers'), ('writer', 'writers', 'crew', 'credits_crew'), ('writer', 'screenplay')),
)


def _details(reader, kind, tmdb_id, imdb_id, tvdb_id, title, year):
    row, tmdb_found = _title_row(reader, kind, tmdb_id=tmdb_id, imdb_id=imdb_id, title=title, year=year)
    tmdb = str(tmdb_id or tmdb_found or '').strip()
    ids = get_external_ids_from_db(tmdb_id=tmdb, media_type=kind, imdb_id=imdb_id, tvdb_id=tvdb_id,
                                   title=title, year=year) or {}
    tmdb = str(ids.get('tmdb_id') or tmdb or '').strip()
    imdb = str(ids.get('imdb_id') or imdb_id or '').strip()
    tvdb = str(ids.get('tvdb_id') or tvdb_id or '').strip()
    owners = _owners(kind, tmdb, imdb, tvdb, _field(row, 'id', 'dbid', 'parent_id'))
    out = {}
    name = _field(row, 'title', 'name', 'label', 'showtitle') or title
    if name:
        out['name'] = out['title'] = str(name)
    for keys, fields in _TEXTS:
        value = _field(row, *fields)
        if value:
            for key in keys:
                out[key] = str(value)
    released = _field(row, 'premiered', 'released', 'release_date', 'firstaired', 'first_air_date', 'air_date', 'date')
    year_found = _field(row, 'year', 'release_year') or year
    if not year_found and released:
        digits = re.search(r'(\d{4})', str(released))
        year_found = digits.group(1) if digits else ''
    if released:
        out['released'] = out['premiered'] = out['releaseInfo'] = str(released)
    elif year_found:
        out['releaseInfo'] = str(year_found)
    if year_found:
        try:
            out['year'] = int(float(year_found))
        except Exception:
            out['year'] = str(year_found)
    runtime = _field(row, 'runtime', 'duration')
    if runtime:
        out['runtime'] = runtime
    rating = _number(row, 'rating', 'vote_average', 'userrating', 'user_rating', 'imdb_rating', 'score')
    if rating not in (None, ''):
        out['imdbRating'] = out['rating'] = rating
    votes = _number(row, 'votes', 'vote_count', 'imdb_votes')
    if votes not in (None, ''):
        try:
            out['imdb_votes'] = out['votes'] = int(votes)
        except Exception:
            out['imdb_votes'] = out['votes'] = votes
    for keys, fields, tables, roles in _LISTS:
        names = _names(_field(row, *fields)) or _related(reader, tables, owners, roles, limit=12)
        if names:
            for key in keys:
                out[key] = names
    people = _cast(reader, owners)
    if people:
        out['cast'] = people
    if tmdb:
        out['tmdb_id'] = tmdb
        out.setdefault('id', 'tmdb:%s' % tmdb)
    if imdb:
        out['imdb_id'] = imdb
    if tvdb:
        out['tvdb_id'] = tvdb
    out['type'] = 'series' if kind == 'tv' else 'movie'
    return out


def stored_meta(tmdb_id='', media_type='movie', imdb_id='', tvdb_id='', title='', year=''):
    """A title's details as TMDb Helper keeps them (title, plot, year, rating, genres, studios,
    people, ids) plus its artwork - so a MegaNexus card can look like one from TMDb Helper."""
    kind = kind_of(media_type)
    key = 'meta:%s:%s:%s:%s:%s:%s' % (kind, tmdb_id or '', imdb_id or '', tvdb_id or '', title or '', year or '')
    if key in _memo:
        return dict(_memo[key])
    out = {}
    try:
        with _reading() as reader:
            if reader is not None:
                out = _details(reader, kind, tmdb_id, imdb_id, tvdb_id, title, year)
    except Exception:
        out = {}
    art = stored_pictures(tmdb_id=out.get('tmdb_id') or tmdb_id, media_type=kind,
                                 imdb_id=out.get('imdb_id') or imdb_id, title=title, year=year) or {}
    backdrop = art.get('fanart') or art.get('landscape') or ''
    if art.get('poster'):
        out['poster'] = out['thumbnail'] = out['thumb'] = art['poster']
    if backdrop:
        out['background'] = out['fanart'] = backdrop
        out['landscape'] = art.get('landscape') or backdrop
    if art.get('clearlogo'):
        out['logo'] = out['clearlogo'] = art['clearlogo']
    if not out.get('landscape') and art.get('landscape'):
        out['landscape'] = art['landscape']
    _remember(key, dict(out))
    return out


# ---- artwork ---------------------------------------------------------------------------

def _icon(reader, table, owner, kind, order=''):
    present = reader.columns(table)
    if not present or not all(name in present for name in ('icon', 'parent_id', 'type')):
        return ''
    sql = 'SELECT icon FROM %s WHERE type=? AND parent_id=?' % table
    found = reader.row(sql + (' ORDER BY ' + order if order else '') + ' LIMIT 1', (kind, owner))
    return str(found[0]).strip() if found and found[0] not in (None, '') else ''


def _picture(reader, owner, wanted):
    """One picture of a kind: TMDb Helper's art table (English first, best rated), its user and
    default choices, then its Fanart.tv cache."""
    kinds = [ART_FIRST[wanted], wanted] if wanted in ART_FIRST else [wanted]

    def tries():
        for kind in kinds:
            yield lambda kind=kind: _icon(reader, 'art', owner, kind, ENGLISH_FIRST + ', rating DESC')
        for kind in kinds:
            yield lambda kind=kind: _icon(reader, 'user_art', owner, kind)
            yield lambda kind=kind: _icon(reader, 'default_art', owner, kind)
        if wanted in FANART_TV:
            yield lambda: _icon(reader, 'fanart_tv', owner, FANART_TV[wanted], ENGLISH_FIRST + ', likes DESC')
    for attempt in tries():
        icon = attempt()
        if icon:
            return image(icon, ART_SIZE.get(wanted, 'poster'))
    return ''


# bundle key -> the kinds asked, in order
_BUNDLE = (('poster', ('posters', 'thumb')), ('fanart', ('backdrops', 'fanarts')),
           ('landscape', ('landscape', 'backdrops')), ('clearlogo', ('logos',)))


def stored_pictures(tmdb_id='', media_type='movie', imdb_id='', title='', year=''):
    """{poster, fanart, landscape, clearlogo} of a title from TMDb Helper's file ('' for each
    it has not got; landscape falls back to fanart)."""
    kind = kind_of(media_type)
    key = 'bundle:%s:%s:%s:%s:%s' % (kind, tmdb_id or '', imdb_id or '', title or '', year or '')
    if key in _memo:
        return dict(_memo[key])
    bundle = {'poster': '', 'fanart': '', 'landscape': '', 'clearlogo': ''}
    try:
        with _reading() as reader:
            if reader is not None:
                tmdb = tmdb_id or _tmdb_for_imdb(reader, imdb_id, kind) or _tmdb_for_title(reader, title, kind, year)
                owners = []
                if tmdb:
                    owners += ['%s.%s' % (kind, tmdb)]
                    owners += ['tv.%s' % tmdb, 'tvshow.%s' % tmdb] if kind == 'tv' else ['movie.%s' % tmdb]
                if imdb_id:
                    owners += ['%s.%s' % (kind, imdb_id), '%s.imdb:%s' % (kind, imdb_id), imdb_id]
                for owner in OrderedDict.fromkeys(owners):
                    for slot, kinds in _BUNDLE:
                        if not bundle[slot]:
                            bundle[slot] = next((url for url in (_picture(reader, owner, k) for k in kinds) if url), '')
                    if bundle['poster'] and bundle['fanart'] and bundle['clearlogo']:
                        break
    except Exception:
        pass
    bundle['landscape'] = bundle['landscape'] or bundle['fanart']
    _remember(key, dict(bundle))
    return bundle


def stored_logo(tmdb_id='', media_type='movie', imdb_id=''):
    return (stored_pictures(tmdb_id=tmdb_id, media_type=media_type, imdb_id=imdb_id) or {}).get('clearlogo', '')
