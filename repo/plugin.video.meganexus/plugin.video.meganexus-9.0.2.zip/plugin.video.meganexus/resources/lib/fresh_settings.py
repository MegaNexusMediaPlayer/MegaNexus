# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import os

import xbmcaddon
import xbmcgui
import xbmcvfs

from .hub_log import log

ADDON = xbmcaddon.Addon('plugin.video.meganexus')

_read = {'stamp': None, 'values': {}}     # the settings file as last read, and when it changed


def _stored_setting(key):
    """The setting as saved in the profile's settings.xml now (another process may have
    written it after our Addon object was made); None when it cannot be read."""
    try:
        path = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'settings.xml')
        info = os.stat(path)
        stamp = (info.st_mtime, info.st_size)
        if _read['stamp'] != stamp:
            import xml.etree.ElementTree as tree
            values = dict((node.get('id'), ((node.text if node.text is not None else node.get('value')) or '').strip())
                          for node in tree.parse(path).getroot().iter('setting') if node.get('id'))
            _read.update(stamp=stamp, values=values)
        return _read['values'].get(key)
    except Exception:
        return None


def fresh_setting(key, window_property='', default=''):
    disk = _stored_setting(key)
    if disk is not None and disk.strip():
        return disk.strip()
    if window_property:
        try:
            live = (xbmcgui.Window(10000).getProperty(window_property) or '').strip()
        except Exception:
            live = ''
        if live:
            return '' if live == '-' else live
    try:
        return (ADDON.getSetting(key) or default).strip()
    except Exception:
        return default


def fresh_bool(key, window_property='', default=True):
    raw = fresh_setting(key, window_property,
                       'true' if default else 'false').strip().lower()
    return raw in ('true', '1', 'yes', 'on')
