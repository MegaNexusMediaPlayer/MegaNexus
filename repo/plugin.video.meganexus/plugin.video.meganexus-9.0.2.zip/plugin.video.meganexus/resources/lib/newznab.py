# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The user's own Newznab indexers, searched from this box (7.0.45).

NZBgeek, DrunkenSlug, NZBFinder, nzb.su, a Prowlarr or NZBHydra link - any
indexer with the Newznab API. The search goes from the Kodi box straight to the
indexer with the user's API key (no add-on server in between): a film by its
IMDb ID, an episode by IMDb ID + season + episode (by its name where the indexer
does not take IMDb IDs for series). The results are NZB sources in the source
list, played by usenet_stream with the user's Usenet server - so they are only
searched once that server is set.

Kept in the hidden setting ``newznab_indexers`` as ``url|apikey`` entries; the
keys are never shown again or written to the log. An indexer's answer is kept
for CACHE_TTL; searches and NZB downloads stay within each indexer's daily limits.
"""
import hashlib
import json
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen

SETTING = 'newznab_indexers'
TIMEOUT = 15
MAX_BYTES = 5 * 1024 * 1024
LIMIT = 100                    # results asked per search
MAX_ROWS = 60                  # sources kept per indexer
MIN_SIZE = 50 * 1024 * 1024    # smaller posts are samples and extras
CATEGORY = {'movie': '2000', 'series': '5000'}
TEST_ID = '0111161'            # a film every indexer has (the key check)
_CREDENTIALS = ('100', '101', '102')
_UNSUPPORTED = ('201', '202', '203')
# Well-known Newznab indexers (public facts: their API addresses and where the key is):
# picked from a list, only the API key is typed.
PRESETS = (
    ('abNZB', 'https://abnzb.com/api', 'abnzb.com/profile'),
    ('altHUB', 'https://api.althub.co.za/api', 'althub.co.za/profile'),
    ('AmeNZB', 'https://amenzb.moe/api', 'amenzb.moe/profile'),
    ('Aninzb', 'https://aninzb.moe/api', 'aninzb.moe/profile'),
    ('ClubNZB', 'https://clubnzb.com/api', 'clubnzb.com/profile'),
    ('Digital Carnage', 'https://digitalcarnage.info/api', 'digitalcarnage.info/profile'),
    ('DOGnzb', 'https://api.dognzb.cr/api', 'dognzb.cr/profile'),
    ('DrunkenSlug', 'https://drunkenslug.com/api', 'drunkenslug.com/profile'),
    ('GingaDADDY', 'https://www.gingadaddy.com/api', 'gingadaddy.com/profile'),
    ('Miatrix', 'https://www.miatrix.com/api', 'miatrix.com/profile'),
    ('NewzBay', 'https://newzbay.cc/api', 'newzbay.cc/profile'),
    ('NinjaCentral', 'https://ninjacentral.co.za/api', 'ninjacentral.co.za/profile'),
    ('NZB Atlas', 'https://nzbatlas.com/api', 'nzbatlas.com/profile'),
    ('Nzb.life', 'https://api.nzb.life/api', 'nzb.life/profile'),
    ('NZBFinder', 'https://nzbfinder.ws/api', 'nzbfinder.ws/profile'),
    ('NZBgeek', 'https://api.nzbgeek.info/api', 'nzbgeek.info/profile'),
    ('NzbNest', 'https://nzbnest.com/api', 'nzbnest.com/profile'),
    ('NzbNoob', 'https://nzbnoob.com/api', 'nzbnoob.com/profile'),
    ('NzbPlanet', 'https://api.nzbplanet.net/api', 'nzbplanet.net/profile'),
    ('NZBStars', 'https://nzbstars.com/api', 'nzbstars.com/profile'),
    ('PourCeSoir', 'https://pourcesoir.in/api', 'pourcesoir.in/profile'),
    ('SquareEyed', 'https://squareeyed.org/api', 'squareeyed.org/profile'),
    ('Tabula Rasa', 'https://www.tabula-rasa.pw/api/v1/api', 'tabula-rasa.pw/profile'),
    ('TorBox Search', 'https://search-api.torbox.app/newznab/api', 'torbox.app/settings'),
    ('Treasure Maps', 'https://treasure-maps.com/api', 'treasure-maps.com/account'),
    ('Usenet Crawler', 'https://www.usenet-crawler.com/api', 'usenet-crawler.com/profile'),
    ('Videothek', 'https://videothek.io/api', 'videothek.io/profile'),
)
TORBOX = 'TorBox Search'


def _plain(text):
    return re.sub(r'[^a-z0-9]', '', str(text or '').lower())


def preset(text):
    """(label, api_url, key_page) for a name ('nzbgeek', 'drunken slug') or an address."""
    plain = _plain(text)
    for row in PRESETS:
        if plain and (plain == _plain(row[0]) or plain in (_plain(row[1]), _plain(row[1].rsplit('/api', 1)[0]))):
            return row
    return None


_RESOLUTION = re.compile(r'(?<!\d)(2160|1080|720|480)[pi]', re.I)
_SAMPLE = re.compile(r'\b(?:sample|trailer|featurette|extras?)\b', re.I)


def _addon(addon=None):
    if addon is not None:
        return addon
    from .settings_snapshot import cached_addon
    return cached_addon()


# --- the stored list ---------------------------------------------------------

def base_url(url):
    """'https://api.nzbgeek.info' / '.../api' / '.../api?' -> 'https://api.nzbgeek.info/api'."""
    url = str(url or '').strip().split('?', 1)[0].rstrip('/')
    if not re.match(r'https?://[^/\s]+', url, re.I):
        raise ValueError('Enter the indexer address, e.g. https://api.nzbgeek.info.')
    return url if url.lower().endswith('/api') else url + '/api'


def parse(value):
    """'url key, url|key, url?apikey=key' -> [(base_url, key)]."""
    found = []
    for part in re.split(r'[,;\n]+', str(value or '')):
        part = part.strip()
        if not part:
            continue
        key = re.search(r'[?&]apikey=([^&\s]+)', part, re.I)
        if key:
            url, key = part, key.group(1)
        else:
            pieces = re.split(r'[|\s]+', part, maxsplit=1)
            url, key = pieces[0], (pieces[1] if len(pieces) > 1 else '')
            # 7.0.45: a known indexer by its name ('nzbgeek KEY', 'Drunken Slug KEY')
            words = part.split()
            for size in (3, 2, 1):
                known = preset(' '.join(words[:size])) if len(words) > size else None
                if known and not re.match(r'https?://', words[0], re.I):
                    url, key = known[1], ' '.join(words[size:])
                    break
        key = key.strip()
        if not key or any(ch.isspace() for ch in key):
            raise ValueError('Enter each indexer as its address and API key, e.g. https://api.nzbgeek.info YOURKEY.')
        found.append((base_url(url), key))
    return found


def indexers(addon=None):
    """[(base_url, key)] as stored."""
    try:
        return parse(' , '.join((_addon(addon).getSetting(SETTING) or '').split()).replace('|', ' '))
    except ValueError:
        return []


def store(entries, addon=None):
    addon = _addon(addon)
    addon.setSetting(SETTING, ' '.join('%s|%s' % (url, key) for url, key in entries))
    try:
        from . import settings_snapshot
        settings_snapshot.invalidate()
    except Exception:
        pass


def name(url):
    """'https://api.nzbgeek.info/api' -> 'NZBgeek' (a known indexer), else its host (never the key)."""
    known = preset(url)
    if known:
        return known[0]
    host = urlsplit(url).hostname or 'indexer'
    return re.sub(r'^(?:api|www|feed)\.', '', host)


def active(addon=None):
    """Indexers set and a Usenet server to play their NZBs."""
    if not indexers(addon):
        return False
    from . import usenet_stream
    return bool(usenet_stream.own_servers(addon))


# --- staying within each indexer's limits (7.0.45) -------------------------------
# Indexers count searches (API hits) and NZB downloads (grabs) per day and suspend
# accounts that keep asking after the limit. MegaNexus counts both per indexer and
# day (UTC), takes the limits an indexer reports (newznab:apilimits), stops at
# SHARE of them, rests an indexer that said "limit reached" until the next day
# (an HTTP 429: an hour) and keeps every answer CACHE_TTL. Nothing is asked in the
# background: only when a source list is opened.
USAGE = 'newznab_usage.json'
CACHE = 'newznab_cache.json'
DEFAULT_API_MAX = 200          # searches a day when the indexer does not say
SHARE = .9                     # ... of which at most this share is used
CACHE_TTL = 6 * 3600
CACHE_KEEP = 80
RETRY_AFTER = 3600             # an HTTP 429 without a day's limit
_LOCK = threading.Lock()
_LIMITS = re.compile(rb'<[^>]*apilimits\b([^>]*)>', re.I)


class LimitReached(ValueError):
    pass


def _profile_file(name):
    try:
        from .meganexus.paths import profile_path
        return os.path.join(profile_path(), name)
    except Exception:
        return ''


def _load(name):
    path = _profile_file(name)
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save(name, data):
    path = _profile_file(name)
    if not path:
        return
    try:
        temp = path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
        os.replace(temp, path)
    except Exception:
        pass


def _day(now=None):
    return time.strftime('%Y-%m-%d', time.gmtime(time.time() if now is None else now))


def _tomorrow(now=None):
    now = time.time() if now is None else now
    return (int(now) // 86400 + 1) * 86400


def _entry(data, url, now=None):
    entry = data.setdefault(urlsplit(url).hostname or url, {})
    if entry.get('day') != _day(now):
        entry.update(day=_day(now), api=0, grab=0)
    return entry


def allowed(url, kind='api', now=None):
    """Whether this indexer may be asked again today ('api' search or 'grab')."""
    with _LOCK:
        data = _load(USAGE)
        entry = _entry(data, url, now)
    now = time.time() if now is None else now
    if entry.get('paused_until', 0) > now and kind in entry.get('paused', ('api', 'grab')):
        return False
    limit = entry.get(kind + '_max') or (DEFAULT_API_MAX if kind == 'api' else 0)
    return not limit or entry.get(kind, 0) < limit * SHARE


def note(url, kind='api', body=b'', now=None):
    """One more search / grab; the limits the indexer reported in its answer."""
    with _LOCK:
        data = _load(USAGE)
        entry = _entry(data, url, now)
        entry[kind] = entry.get(kind, 0) + 1
        found = _LIMITS.search(body[:4096]) if body else None
        if found:
            attrs = dict((k.decode().lower(), v.decode()) for k, v in re.findall(rb'(\w+)="(\d+)"', found.group(1)))
            for name, field in (('apimax', 'api_max'), ('grabmax', 'grab_max')):
                if attrs.get(name, '').isdigit() and int(attrs[name]):
                    entry[field] = int(attrs[name])
            for name, field in (('apicurrent', 'api'), ('grabcurrent', 'grab')):
                if attrs.get(name, '').isdigit():
                    entry[field] = max(entry.get(field, 0), int(attrs[name]))
        _save(USAGE, data)


def pause(url, until, kinds=('api', 'grab')):
    with _LOCK:
        data = _load(USAGE)
        entry = _entry(data, url)
        entry.update(paused_until=until, paused=list(kinds))
        _save(USAGE, data)
    _log('%s rests until %s' % (name(url), time.strftime('%H:%M UTC', time.gmtime(until))))


def today(url, now=None):
    """'12 searches today' / 'resting until tomorrow' for the settings list."""
    with _LOCK:
        entry = _entry(_load(USAGE), url, now)
    if entry.get('paused_until', 0) > (time.time() if now is None else now):
        return 'resting (its limit) until %s' % time.strftime('%H:%M UTC', time.gmtime(entry['paused_until']))
    limit = entry.get('api_max')
    return '%d searches today%s' % (entry.get('api', 0), (' of %d' % limit) if limit else '')


def is_indexer(url):
    host = urlsplit(str(url or '')).hostname
    return bool(host) and any(urlsplit(u).hostname == host for u, _ in indexers())


# --- the API -----------------------------------------------------------------

def _get(url, key, params, timeout=TIMEOUT):
    if not allowed(url, 'api'):
        raise LimitReached("today's searches are used up - it is asked again tomorrow")
    query = dict(params, apikey=key)
    request = Request(url + '?' + urlencode(query), headers={'User-Agent': 'MegaNexus/7', 'Accept': 'application/rss+xml, application/xml'})
    try:
        with urlopen(request, timeout=timeout) as response:
            body = response.read(MAX_BYTES + 1)
    except Exception as exc:
        code = getattr(exc, 'code', None)
        if code in (401, 403):
            raise ValueError('the API key was not accepted')
        if code == 429:
            pause(url, time.time() + RETRY_AFTER, ('api',))
            raise LimitReached('the indexer asked to wait - it is asked again in an hour')
        # The URL holds the key: only the kind of failure is told.
        raise ValueError('no answer (%s)' % (code or type(exc).__name__))
    note(url, 'api', body)
    if len(body) > MAX_BYTES:
        raise ValueError('the answer was too large')
    # Newznab 500: the day's searches are used up, 501: its downloads
    head = body[:600]
    if re.search(rb'<error[^>]*code="500"', head):
        pause(url, _tomorrow(), ('api', 'grab'))
        raise LimitReached("the indexer's daily limit is reached - it is asked again tomorrow")
    if re.search(rb'<error[^>]*code="501"', head):
        pause(url, _tomorrow(), ('grab',))
        raise LimitReached("the indexer's daily NZB downloads are used up")
    return body


def results(body):
    """Newznab RSS -> [{'title', 'link', 'size', 'grabs', 'password'}]; an <error> raises."""
    head = body[:2048].lower()
    if b'<!doctype' in head or b'<!entity' in body.lower():
        raise ValueError('the indexer gave an unexpected answer')
    try:
        root = ET.fromstring(body)
    except ET.ParseError:
        raise ValueError('the indexer gave an unexpected answer')
    if root.tag == 'error':
        code = str(root.get('code') or '')
        if code in _CREDENTIALS:
            raise ValueError('the API key was not accepted')
        if code in _UNSUPPORTED:
            raise LookupError(code)
        raise ValueError(str(root.get('description') or 'error %s' % code)[:80])
    found = []
    for item in root.iter('item'):
        attrs = {}
        for child in item:
            if child.tag == 'attr' or child.tag.endswith('}attr'):
                attrs[str(child.get('name') or '').lower()] = str(child.get('value') or '')
        enclosure = item.find('enclosure')
        link = (enclosure.get('url') if enclosure is not None else '') or (item.findtext('link') or '')
        try:
            size = int(attrs.get('size') or (enclosure.get('length') if enclosure is not None else 0) or 0)
        except ValueError:
            size = 0
        try:
            grabs = int(attrs.get('grabs') or 0)
        except ValueError:
            grabs = 0
        title = (item.findtext('title') or '').strip()
        if title and link.startswith('http'):
            found.append({'title': title, 'link': link.strip(), 'size': size, 'grabs': grabs,
                          'password': attrs.get('password', '0') not in ('', '0')})
    return found


def search(url, key, media_type, imdb, season=None, episode=None, title=None):
    """One indexer's hits for a film (IMDb ID) or an episode (IMDb ID, else its name)."""
    number = str(imdb or '').lower().replace('tt', '', 1)
    common = {'extended': 1, 'limit': LIMIT, 'cat': CATEGORY['series' if season is not None else 'movie']}
    if season is None:
        return results(_get(url, key, dict(common, t='movie', imdbid=number)))
    episode_params = dict(common, t='tvsearch', season=season, ep=episode)
    try:
        hits = results(_get(url, key, dict(episode_params, imdbid=number)))
    except LookupError:
        hits = []                       # this indexer takes no IMDb ID for series
    if hits or not title:
        return hits
    found = title() if callable(title) else title
    name_ = found[0] if isinstance(found, (tuple, list)) else found   # title_of gives (name, year)
    if not name_:
        return []
    try:
        return results(_get(url, key, dict(episode_params, q=name_)))
    except LookupError:
        return []


def check(url, key):
    """'' when the indexer answers with this key, else what is wrong."""
    try:
        results(_get(url, key, {'t': 'movie', 'imdbid': TEST_ID, 'limit': 1}))
        return ''
    except LookupError:
        try:
            results(_get(url, key, {'t': 'search', 'q': 'test', 'limit': 1}))
            return ''
        except Exception as exc:
            return str(exc)
    except Exception as exc:
        return str(exc)


def add(url, key, addon=None):
    """Check and keep one indexer (the same address again replaces its key)."""
    url = base_url(url)
    key = str(key or '').strip()
    if not key or any(ch.isspace() for ch in key):
        raise ValueError('Copy the API key from the indexer\'s profile page.')
    reason = check(url, key)
    if reason:
        raise ValueError('%s: %s.' % (name(url), reason))
    entries = [(u, k) for u, k in indexers(addon) if u != url] + [(url, key)]
    store(entries, addon)
    return entries


def save_value(value, addon=None):
    """The phone / API keys page: the whole list at once ('' removes all)."""
    entries = parse(value)
    for url, key in entries:
        reason = check(url, key)
        if reason:
            raise ValueError('%s: %s.' % (name(url), reason))
    store(entries, addon)


# --- sources -----------------------------------------------------------------

def _size_label(size):
    return ('%.2f GB' % (size / 1e9)) if size >= 1e9 else (('%.0f MB' % (size / 1e6)) if size else '')


def rows_of(hits, indexer, season=None, episode=None):
    """Stremio-shaped NZB rows (played by usenet_stream with the user's server)."""
    from .debrid import _episode_match
    rows, seen = [], set()
    for hit in hits:
        title = hit['title']
        if hit['password'] or _SAMPLE.search(title) or (hit['size'] and hit['size'] < MIN_SIZE):
            continue
        if season is not None and not _episode_match(title, season, episode):
            continue
        if title.lower() in seen:
            continue
        seen.add(title.lower())
        resolution = _RESOLUTION.search(title)
        detail = [title]
        if hit['size']:
            detail.append('💾 ' + _size_label(hit['size']) + ('  ⬇ %d' % hit['grabs'] if hit['grabs'] else ''))
        rows.append({'name': '[NZB] %s\n%s' % (indexer, resolution.group(0).lower() if resolution else 'Usenet'),
                     'title': '\n'.join(detail), 'nzbUrl': hit['link'], 'type': 'usenet',
                     'behaviorHints': {'videoSize': hit['size'] or None, 'filename': title,
                                       'bingeGroup': 'newznab-%s' % (resolution.group(0).lower() if resolution else 'any')}})
        if len(rows) >= MAX_ROWS:
            break
    return rows


def jobs(media_type, video_id, addon=None):
    """[(name, fn)] - one job for all indexers (asked at the same time, each
    release once), or [] when nothing is set."""
    if not active(addon):
        return []
    from .debrid import _video_ref, title_of
    ref = _video_ref(media_type, video_id)
    if not ref:
        return []
    kind, stremio_id, season, episode = ref
    imdb = stremio_id.split(':')[0]
    entries = indexers(addon)
    scope = 'newznab:' + hashlib.sha256('|'.join(u for u, _ in entries).encode('utf-8')).hexdigest()[:12]

    cache_key = '%s|%s|%s' % (scope, kind, stremio_id)

    def job():
        from concurrent.futures import ThreadPoolExecutor
        with _LOCK:
            kept = _load(CACHE).get(cache_key)
        if kept and time.time() - kept.get('at', 0) < CACHE_TTL:
            return kept.get('rows') or []
        lookup = {}

        def title():
            if 'name' not in lookup:
                lookup['name'] = title_of(kind, imdb)
            return lookup['name']

        def one(entry):
            url, key = entry
            origin = {'id': 'newznab', 'name': name(url), 'base_url': ''}
            try:
                hits = search(url, key, kind, imdb, season, episode, title)
            except Exception as exc:
                _log('%s: %s' % (name(url), exc))
                return []
            return [dict(row, _meganexus_source=origin) for row in rows_of(hits, name(url), season, episode)]
        with ThreadPoolExecutor(max_workers=min(4, len(entries)), thread_name_prefix='MegaNexusNewznab') as pool:
            answers = list(pool.map(one, entries))
        rows, seen = [], set()
        for row in (row for answer in answers for row in answer):
            release = row['behaviorHints']['filename'].lower()
            if release not in seen:
                seen.add(release)
                rows.append(row)
        if rows:
            with _LOCK:
                data = _load(CACHE)
                data[cache_key] = {'at': time.time(), 'rows': rows}
                fresh = sorted(((k, v) for k, v in data.items() if time.time() - v.get('at', 0) < CACHE_TTL),
                               key=lambda pair: pair[1]['at'], reverse=True)[:CACHE_KEEP]
                _save(CACHE, dict(fresh))
        return rows
    return [('Newznab', job)]


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Newznab: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass
