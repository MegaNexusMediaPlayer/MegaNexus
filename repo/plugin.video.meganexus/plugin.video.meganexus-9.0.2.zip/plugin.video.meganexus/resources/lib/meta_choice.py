# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Where an item's details and pictures come from.

Every add-on (and every virtual list - Continue Watching, Trakt / MDBList collections) has a
choice, kept in the hidden setting `provider_meta_map` ({target: source}):

    auto         Plex / Emby / Jellyfin add-ons get another add-on's details, the rest keep theirs
    native       the add-on's own details, untouched
    tmdb_helper  TMDb Helper's local database (TMDB pictures when it has nothing)
    <add-on id>  any installed add-on that offers `meta`

The folder being drawn may override it (plugin.get_bucket_meta_source); without a choice
the `default_meta_source` setting decides. An explicit choice is strict: the old pictures
are dropped, and the result is stamped (_meganexus_meta_*) so later art code keeps it.

Picture order per art type (`global_art_map` / `bucket_art_map`) is read here too."""
import json

import xbmc
import xbmcaddon

from .card_art import extract_ids
from .meganexus import addon_registry as _addon_registry
from .meganexus.addon_wire import fetch_meta

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

SPECIAL = ('auto', 'native', 'tmdb_helper')
SERIES_TYPES = ('series', 'anime', 'tv', 'show')
ART_TYPES = ('poster', 'background', 'clearlogo', 'landscape', 'banner', 'clearart')

# What the add-on's name, id, address and manifest text say about it.
SERVER_WORDS = ('plex', 'emby', 'jellyfin')              # their own pictures need a token
PLEXIO_WORDS = ('plexio', 'plexbridge')                  # already a full Stremio details add-on
STREAM_WORDS = ('torrentio', 'comet', 'mediafusion', 'watchhub', 'opensubtitles', 'orion',
                'debrid', 'rd:', 'aiostreams')           # offer meta, but nobody wants theirs

# Stored labels of the two labelenum settings.
DEFAULT_WORDS = (('tmdb_helper', ('tmdb helper', 'tmdb_helper'), '1'),
                 ('native', ('native',), '2'))
CUSTOM_WORDS = ('custom',)

# Picture fields an explicit choice removes from the add-on's own item first.
OWN_ART = ('poster posterUrl posterURL thumbnail thumb thumbUrl thumbURL image imageUrl imageURL '
           'background fanart landscape banner backdrop logo clearlogo clearart plex_original_poster '
           'parentThumb grandparentThumb').split()
OWN_IMAGES = frozenset(('poster thumb thumbnail cover image posterurl poster_url background fanart backdrop '
                        'landscape banner art clearlogo clearart logo').split())
# Fields the chosen source's item replaces (when it has a value).
TAKEN = ('poster posterUrl posterURL thumbnail thumb image background fanart landscape backdrop banner '
         'logo clearlogo clearart '
         'description overview plot plotoutline tagline genres genre '
         'releaseInfo released premiered firstaired date year '
         'imdbRating rating voteAverage score imdb_votes votes userrating '
         'cast credits_cast director writer runtime duration country certification mpaa '
         'studio studios network networks production_companies originaltitle trailer status type '
         'tmdb_id imdb_id tvdb_id id images behaviorHints name title videos trailers links').split()
NOTHING = (None, '', [], {})


class _JsonSetting(object):
    """A hidden JSON setting, parsed once per run (a 60-item catalog asks for it 60 times)."""

    def __init__(self, key, clean):
        self.key = key
        self.clean = clean
        self.value = None

    def get(self):
        if self.value is None:
            try:
                self.value = self.clean(json.loads(ADDON.getSetting(self.key) or '{}'))
            except Exception:
                self.value = {}
        return self.value

    def put(self, value):
        try:
            ADDON.setSetting(self.key, json.dumps(value or {}, ensure_ascii=False))
            self.value = dict(value or {})
        except Exception:
            self.value = None


def _art_lists(types):
    """{art type: [source ids]} with unknown types and non-lists left out."""
    return dict((kind, [str(pid) for pid in ids if pid]) for kind, ids in types.items()
                if kind in ART_TYPES and isinstance(ids, list))


def _folder_art_lists(data):
    folders = {}
    for folder, types in (data.items() if isinstance(data, dict) else ()):
        if isinstance(types, dict):
            lists = _art_lists(types)
            if lists:
                folders[str(folder)] = lists
    return folders


_choices = _JsonSetting('provider_meta_map', lambda data: data if isinstance(data, dict) else {})
_global_art = _JsonSetting('global_art_map', lambda data: _art_lists(data) if isinstance(data, dict) else {})
_folder_art = _JsonSetting('bucket_art_map', _folder_art_lists)


def _forget_answers():
    """Kept /meta/ answers are dropped so the next page shows the new choice at once."""
    try:
        from .meganexus.addon_wire import purge_meta_cache
        purge_meta_cache()
    except Exception:
        pass


# ---- the choice ------------------------------------------------------------------------------


def default_choice():
    try:
        stored = (ADDON.getSetting('default_meta_source') or '').strip().lower()
    except Exception:
        stored = ''
    for choice, words, index in DEFAULT_WORDS:
        if stored == index or any(word in stored for word in words):
            return choice
    return 'auto'


def choice_for(target):
    """The folder being drawn first, then the target's own choice, then the default."""
    try:
        from . import hub
        folder = hub._get_active_bucket()
        if folder:
            chosen = hub.section_meta_source(folder)
            if chosen and chosen != 'auto':
                return chosen
    except Exception:
        pass
    own = (_choices.get().get(target or '') or '').strip()
    return own if own and own != 'auto' else default_choice()


def choose(target, source):
    if not target:
        return
    choices = _choices.get()
    if source and source != 'auto':
        choices[target] = source
    else:
        choices.pop(target, None)
    _choices.put(choices)
    _forget_answers()


def forget_choices():
    _choices.put({})
    _forget_answers()


def art_mode():
    """'custom' (per-folder picture order) or 'unified' (one order everywhere)."""
    try:
        stored = (ADDON.getSetting('art_configuration_mode') or 'Unified').strip().lower()
    except Exception:
        stored = 'unified'
    return 'custom' if stored in CUSTOM_WORDS else 'unified'


def global_art_order(art_type):
    return list(_global_art.get().get(art_type) or []) if art_type in ART_TYPES else []


def folder_art_order(folder, art_type):
    """The folder's source order for this art type ([] = the usual art rules)."""
    if not folder or art_type not in ART_TYPES:
        return []
    return list((_folder_art.get().get(str(folder)) or {}).get(art_type) or [])


# ---- the sources -----------------------------------------------------------------------------


def _words(provider):
    provider = provider or {}
    manifest = provider.get('manifest') or {}
    return ' '.join(str(value or '') for value in (
        provider.get('name'), provider.get('id'), provider.get('base_url'), provider.get('manifest_url'),
        manifest.get('name'), manifest.get('id'), manifest.get('description'))).lower()


def _says(provider, words):
    text = _words(provider)
    return any(word in text for word in words)


def stream_only(provider):
    """A media-server add-on: good streams and lists, pictures Kodi often cannot load."""
    return _says(provider, SERVER_WORDS)


def _offers_details(provider):
    resources = ((provider or {}).get('manifest') or {}).get('resources', [])
    if not any(res == 'meta' or (isinstance(res, dict) and res.get('name') == 'meta') for res in resources):
        return False
    return not _says(provider, SERVER_WORDS + STREAM_WORDS)


def choices():
    """The picker: the three special sources, then every add-on that offers details."""
    rows = [{'id': 'auto', 'name': 'Automatic (smart)', 'kind': 'special'},
            {'id': 'native', 'name': "The addon's own metadata", 'kind': 'special'},
            {'id': 'tmdb_helper', 'name': 'TMDb Helper (no API needed)', 'kind': 'builtin'}]
    listed = set()
    for provider in _addon_registry.list_providers() or []:
        pid = provider.get('id') or '' if _offers_details(provider) else ''
        if pid and pid not in listed:
            listed.add(pid)
            rows.append({'id': pid, 'name': provider.get('name') or pid, 'kind': 'stremio'})
    return rows


def label_of(source):
    names = {'': 'Automatic', 'auto': 'Automatic', 'native': 'Addon metadata', 'tmdb_helper': 'TMDb Helper'}
    if not source or source in names:
        return names[source or '']
    provider = _addon_registry.get_provider(source)
    return (provider.get('name') or source) if provider else source


def _lookup_ids(ids):
    """The ids an add-on is asked with: IMDb, then tmdb:, then tvdb:."""
    imdb, tmdb, tvdb = ids.get('imdb_id') or '', ids.get('tmdb_id') or '', ids.get('tvdb_id') or ''
    found = [imdb if imdb.startswith('tt') else 'tt' + imdb] if imdb else []
    return found + ['%s:%s' % (kind, value) for kind, value in (('tmdb', tmdb), ('tvdb', tvdb)) if value]


def from_addon(source, media_type, ids):
    """The chosen add-on's details for the first id it knows (pictures or a plot needed)."""
    provider = _addon_registry.get_provider(source) if source else None
    if not provider:
        return None
    kind = 'series' if media_type in SERIES_TYPES else 'movie'
    for item_id in _lookup_ids(ids):
        try:
            found = fetch_meta(provider, kind, item_id).get('meta') or {}
            if found and (found.get('poster') or found.get('background') or found.get('description')):
                return found
        except Exception as exc:
            xbmc.log('[MegaNexus] meta fetch %s:%s failed: %s' % (provider.get('name'), item_id, exc), xbmc.LOGDEBUG)
    return None


def from_helper(ids, meta, media_type):
    """TMDb Helper's whole item (title, plot, cast, ratings, pictures) from its local database;
    when it has not cached the item, TMDB pictures only - never a blank poster."""
    kind = 'tv' if media_type in SERIES_TYPES else 'movie'
    wanted = dict(tmdb_id=str(ids.get('tmdb_id') or '').strip(), imdb_id=str(ids.get('imdb_id') or '').strip(),
                  media_type=kind, title=str(meta.get('name') or meta.get('title') or '').strip(),
                  year=str(meta.get('releaseInfo') or meta.get('year') or '').strip())
    try:
        from . import tmdb_helper_db
        cached = tmdb_helper_db.stored_meta(tvdb_id=str(ids.get('tvdb_id') or '').strip(),
                                                        **wanted) or {}
    except Exception:
        cached = {}
    if any(cached.get(key) for key in ('poster', 'background', 'description', 'genres', 'cast')):
        return cached
    try:
        from . import tmdb_api
        art = tmdb_api.art_for(**wanted) or {}
    except Exception:
        art = {}
    poster = art.get('poster') or ''
    fanart = art.get('fanart') or art.get('landscape') or ''
    logo = art.get('clearlogo') or ''
    if not (poster or fanart or logo):
        return None
    return {'poster': poster, 'thumbnail': poster, 'thumb': poster, 'background': fanart, 'fanart': fanart,
            'landscape': art.get('landscape') or fanart, 'logo': logo, 'clearlogo': logo}


def _from_any_addon(media_type, ids):
    for row in choices():
        if row.get('kind') == 'stremio':
            found = from_addon(row.get('id') or '', media_type, ids)
            if found:
                return found
    return None


# ---- putting it together ---------------------------------------------------------------------


def _complete_enough(meta):
    """Auto mode leaves an item alone when it has a poster/logo and a background or a real plot."""
    if not isinstance(meta, dict) or not (meta.get('poster') or meta.get('logo') or meta.get('clearlogo')):
        return False
    if meta.get('background') or meta.get('fanart') or meta.get('landscape'):
        return True
    return len(str(meta.get('description') or meta.get('overview') or '')) >= 80


def _without_art(meta):
    """The item with its own pictures removed - also from `images` and behaviorHints."""
    out = dict(meta or {})
    for key in OWN_ART:
        out.pop(key, None)
    for holder, drop in (('images', lambda key: str(key).lower() in OWN_IMAGES),
                         ('behaviorHints', lambda key: key in OWN_ART)):
        inner = out.get(holder)
        if isinstance(inner, dict):
            kept = dict((key, value) for key, value in inner.items() if not drop(key))
            if kept:
                out[holder] = kept
            else:
                out.pop(holder, None)
    return out


def stamped(meta, source='', provider='', strict=False, virtual=''):
    """The item marked with where its details came from; strict = later art code adds nothing."""
    out = dict(meta or {})
    for key, value in (('_meganexus_meta_source_id', source), ('_meganexus_meta_provider_id', provider),
                       ('_meganexus_meta_virtual_key', virtual)):
        if value:
            out[key] = str(value)
    if strict:
        out['_meganexus_art_strict'] = '1'
    return out


def _combined(meta, found, strict, source='', provider='', virtual=''):
    out = _without_art(meta) if strict else dict(meta or {})
    for key in TAKEN if found else ():
        value = found.get(key)
        if value in NOTHING:
            continue
        if key in ('clearlogo', 'logo') and out.get(key) and not value:
            continue                   # a kept logo is never swapped for a falsy one
        out[key] = value
    return stamped(out, source, provider, strict, virtual)


def apply_virtual(target, media_type, meta):
    """The choice for a list with no add-on behind it (Continue Watching, Trakt / MDBList)."""
    if not target:
        return meta
    meta = dict(meta or {})
    ids = extract_ids(meta)
    if not any(ids.values()):
        return meta
    source = choice_for(target)
    if source == 'native':
        return meta
    if source in ('', 'auto'):
        found = from_helper(ids, meta, media_type) or _from_any_addon(media_type, ids)
    elif source == 'tmdb_helper':
        found = from_helper(ids, meta, media_type)
        if not found:              # keep the seed pictures rather than blank icons
            return stamped(meta, source, virtual=target)
    else:
        found = from_addon(source, media_type, ids)
    return _combined(meta, found, source not in ('', 'auto'), source, virtual=target)


def _plexio_native(provider, source):
    return source == 'native' or (source == 'auto' and _says(provider, PLEXIO_WORDS))


def apply(provider, media_type, meta):
    """The add-on's choice applied to one item. Native (and Plexio in auto) is a strict no-op;
    auto replaces only media-server add-ons; an explicit source with nothing for the item
    still gets TMDb Helper / TMDB pictures, never the add-on's old poster."""
    if not provider:
        return meta
    pid = provider.get('id') or ''
    source = choice_for(provider.get('id'))
    if _plexio_native(provider, source):
        return stamped(meta, 'native', pid)
    ids = extract_ids(meta)
    if not any(ids.values()):
        return meta
    explicit = source not in ('', 'auto')
    if not explicit:
        if not stream_only(provider):
            return meta
        found = _from_any_addon(media_type, ids) or from_helper(ids, meta, media_type)
    elif source == 'tmdb_helper':
        found = from_helper(ids, meta, media_type)
    else:
        found = from_addon(source, media_type, ids) or from_helper(ids, meta, media_type)
    return _combined(meta, found, explicit, source, pid)


def apply_many(provider, media_type, metas):
    """`apply` for a whole page, in parallel; in auto mode complete items are not asked about."""
    if not provider or not metas:
        return metas
    source = choice_for(provider.get('id'))
    if _plexio_native(provider, source):
        return [stamped(meta, 'native', provider.get('id') or '') for meta in metas]
    if source == 'auto' and not stream_only(provider):
        return metas
    from .meganexus.addon_wire import all_at_once

    def one(meta):
        try:
            return meta if source == 'auto' and _complete_enough(meta) else apply(provider, media_type, meta)
        except Exception:
            return meta
    return [meta if isinstance(result, Exception) else result for meta, result in all_at_once(one, metas)]
