# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The progress shown while the add-ons are asked for sources (or a search runs): Kodi's
own progress dialog. Back before any result cancels; after one it shows what was found.

    with open_progress(style, title=..., provider_names=[...]) as progress:
        progress.update(provider_name=name, index=done)     # that add-on has answered
        progress.add_found(n, provider_name=name, unique_total=total)
        if progress.is_stopped(): ...                         # is_cancelled(): drop everything

(9.0: the earlier full-screen sheet is gone - its skin file was never in the bundle.)"""
import time

import xbmcgui

from .texts import tr
from .hub_log import log


def _seconds(started):
    return '%.1f %s' % (max(0.0, time.monotonic() - started), tr('s'))


def _names(provider_names):
    names = []
    for name in provider_names or []:
        name = str(name or '').strip()
        if name and name not in names:
            names.append(name)
    return names


class KodiProgress(object):
    """Kodi's own progress dialog with the same calls (one button: Back)."""

    def __init__(self, title='', subtitle='', provider_count=0, provider_names=None, **_pictures_and_ids):
        self.subtitle = str(subtitle or '')
        self.count = max(0, int(provider_count or 0)) or len(_names(provider_names))
        self.done = 0
        self.results = 0
        self.current = ''
        self.status = tr('Searching for add-ons...')
        self.note = ''
        self.started = time.monotonic()
        self._win = None
        self._stopped = {'cancel': False, 'enough': False}
        self._painted = None

    def __enter__(self):
        try:
            self._win = xbmcgui.DialogProgress()
            try:
                self._win.create('MegaNexus', self._text())
            except TypeError:
                self._win.create('MegaNexus')
            self._paint(always=True)
        except Exception as exc:
            log.silent('NATIVE_LOADING', exc)
            self._win = None
        return self

    def __exit__(self, *_exc):
        try:
            self._check()
        except Exception:
            pass
        try:
            if self._win is not None:
                self._win.close()
        except Exception as exc:
            log.silent('NATIVE_LOADING', exc)
        self._win = None
        return False

    def _percent(self):
        return max(0, min(100, int(round(100.0 * min(self.done, self.count) / float(self.count))))) if self.count > 0 else 0

    def _text(self):
        second = '%s %s' % (tr('Now checking:'), self.current) if self.current else self.subtitle
        facts = ([self.note] if self.note else []) + (
            ['%s %d/%d' % (tr('Add-ons'), min(self.done, self.count), self.count)] if self.count else []) + (
            ['%d %s' % (self.results, tr('result'))] if self.results else []) + [_seconds(self.started)]
        return '\n'.join(line for line in (self.status, second, '  •  '.join(facts)) if line)

    def _paint(self, always=False):
        if self._win is None:
            return
        now = (self._percent(), self._text())
        if not always and now == self._painted:
            return
        self._painted = now
        try:
            self._win.update(*now)
        except TypeError:                    # older Kodi: three message lines
            lines = now[1].split('\n') + ['', '', '']
            try:
                self._win.update(now[0], lines[0], lines[1], lines[2])
            except Exception as exc:
                log.silent('NATIVE_LOADING', exc)
        except Exception as exc:
            log.silent('NATIVE_LOADING', exc)

    def _check(self):
        """Back pressed: before any result it cancels, after one it means "show them"."""
        if self._stopped['cancel'] or self._stopped['enough']:
            return True
        if self._win is None:
            return False
        try:
            if not self._win.iscanceled():
                return False
        except Exception:
            return False
        self._stopped['enough' if self.results > 0 else 'cancel'] = True
        try:
            self._win.close()
        except Exception:
            pass
        return True

    def is_cancelled(self):
        self._check()
        return self._stopped['cancel']

    def is_stopped(self):
        return self._check()

    def update(self, provider_name='', index=0, status=None, sub_status=None):
        if provider_name:
            self.current = str(provider_name)
        if index:
            try:
                self.done = max(self.done, int(index))
            except Exception:
                pass
        if status is not None:
            self.status = str(status or '')
        if sub_status is not None:
            self.note = str(sub_status or '')
        self._check()
        self._paint()

    def add_found(self, n=0, provider_name='', unique_total=None):
        if provider_name:
            self.current = str(provider_name)
        for value, total in ((n, False), (unique_total, True)):
            if value is None:
                continue
            try:
                self.results = max(0, int(value)) if total else self.results + max(0, int(value or 0))
            except Exception:
                pass
        self._check()
        self._paint()

    def mark_sufficient(self, auto_seconds=0):
        self.status = tr('Enough results found')
        self._paint(always=True)

    def clear_sufficient(self):
        self.status = tr('Searching for add-ons...')
        self._paint(always=True)

    def consume_continue_search(self):
        return False                         # one button only; patient mode is a setting

    def set_finalizing(self, msg=None):
        self.done = max(self.done, self.count)
        self.status = str(msg or tr('Sorting results...'))
        self._paint(always=True)


def open_progress(style=None, *args, **kwargs):
    """The progress dialog (``style``, the old search_style setting, is no longer used)."""
    return KodiProgress(*args, **kwargs)
