# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus' lines in kodi.log: "[MegaNexus][AREA] message".


Arguments are put into the message only when it is written. Keys, tokens and passwords
never reach the file: every line goes through `_redact`. `silent` records an error that
was deliberately caught (debug level, info with Settings > verbose logging) and keeps
the last one for "Copy last silent error".
"""
import re
import time
import traceback

import xbmc

_PREFIX = '[MegaNexus]'
HIDDEN = '***'

# key=value forms whose value is hidden (the value: letters, digits . _ -)
_KEYS = ('api[_-]?key', 'token', 'access[_-]?token', 'refresh[_-]?token', None, 'secret', 'X-Plex-Token')
_JSON_KEYS = ('api_key', 'token', 'access_token', 'refresh_token', 'password', 'secret', 'client_secret')
_VALUE = '[A-Za-z0-9._\\-]+'


def _rules():
    rules = []
    for key in _KEYS:
        if key is None:   # a password may hold anything but a space or the next &
            rules.append(re.compile(r'(password=)[^\s&]+', re.IGNORECASE))
        else:
            rules.append(re.compile('(%s=)%s' % (key, _VALUE), re.IGNORECASE))
    rules.append(re.compile(r'(Bearer\s+)' + _VALUE))
    rules.append(re.compile(r'("(?:%s)"\s*:\s*")[^"]+(")' % '|'.join(_JSON_KEYS), re.IGNORECASE))
    return tuple(rules)


_RULES = _rules()


def _hide(match):
    return match.group(1) + HIDDEN + (match.group(2) if match.lastindex and match.lastindex >= 2 else '')


def _redact(text):
    """The text with every secret's value replaced by ***; the same when run twice."""
    if text is None:
        return text
    if not isinstance(text, str):
        try:
            text = str(text)
        except Exception:
            return '<unprintable>'
    for rule in _RULES:
        try:
            text = rule.sub(_hide, text)
        except Exception:
            pass
    return text


_LEVELS = {'debug': xbmc.LOGDEBUG, 'info': xbmc.LOGINFO, 'notice': xbmc.LOGINFO, 'warning': xbmc.LOGWARNING,
           'warn': xbmc.LOGWARNING, 'error': xbmc.LOGERROR, 'fatal': xbmc.LOGFATAL}


def _write(level, area, message, args, exc_info=False):
    """Never raises - a failing log line must not break what logs it."""
    try:
        if args:
            try:
                text = message % args
            except Exception:
                text = '%s | args=%r' % (message, args)
        else:
            text = str(message)
        tag = '[%s]' % area.upper() if area else ''
        priority = _LEVELS.get(level, xbmc.LOGINFO)
        xbmc.log('%s%s %s' % (_PREFIX, tag, _redact(text)), priority)
        if exc_info:
            xbmc.log('%s%s traceback:\n%s' % (_PREFIX, tag, _redact(traceback.format_exc())), priority)
    except Exception:
        try:
            xbmc.log('%s logging failure' % _PREFIX, xbmc.LOGERROR)
        except Exception:
            pass


def _verbose_logging_enabled():
    try:
        import xbmcaddon
        setting = xbmcaddon.Addon('plugin.video.meganexus').getSetting('verbose_logging') or 'false'
        return setting.strip().lower() == 'true'
    except Exception:
        return False


_EMPTY = {'when': None, 'category': '', 'message': '', 'traceback': ''}
_last_silent_error = dict(_EMPTY)


class _HubLogger(object):
    def _level(name):   # noqa: N805 - builds the methods below
        def write(self, category, msg, *args, exc_info=False):
            _write(name, category, msg, args, exc_info)
        write.__name__ = name
        return write

    debug = _level('debug')
    info = _level('info')
    warn = warning = _level('warn')
    error = _level('error')
    fatal = _level('fatal')
    del _level

    def silent(self, category, exc, context_msg=''):
        """A caught error, written at debug level (info when verbose) and kept as the last one."""
        global _last_silent_error
        try:
            error = '%s: %s' % (exc.__class__.__name__, exc) if isinstance(exc, BaseException) else str(exc)
            text = '%s — %s' % (context_msg, error) if context_msg else error
            _last_silent_error = {
                'when': time.time(), 'category': category or '?', 'message': _redact(text),
                'traceback': _redact(traceback.format_exc()) if isinstance(exc, BaseException) else '',
            }
            _write('info' if _verbose_logging_enabled() else 'debug', category, '[silent] %s', (text,))
        except Exception:
            try:
                xbmc.log('%s log.silent failure' % _PREFIX, xbmc.LOGERROR)
            except Exception:
                pass


log = _HubLogger()


