# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Kodi directory items: one ListItem per row, collected and handed to Kodi at the end.

add_item fills the item's labels (translated), video info (InfoTag on Kodi 20+, else
setInfo), pictures (also as properties, which skins read), ids (tmdb / imdb / tvdb and the
TMDb Helper type) and the context menu. end_dir picks the content type from the route
when the caller names none (episodes, seasons, tvshows, movies, videos, files)."""
import json
import os
import sys
import urllib.parse

import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .texts import tr

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')
try:
    HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
except Exception:
    HANDLE = -1

from .card_art import addon_fanart  # noqa: E402
from .hub_base import WINDOW_ID, _get_int_setting  # noqa: E402

TRANSLATED_INFO = ('title', 'plot', 'genre', 'tagline', 'status')
ART_PROPERTIES = ('clearlogo', 'logo', 'tvshow.clearlogo', 'clearart', 'landscape', 'banner', 'poster', 'tvshow.poster',
                  'season.poster', 'thumb', 'icon', 'thumbnail', 'cover', 'image', 'tvshow.thumb', 'fanart')
SHOW_INFO_TYPES = ('tvshow', 'season', 'episode')
# content type by route, then by media type, then by Home folder
ROUTE_CONTENT = dict([(route, 'episodes') for route in ('episodes', 'nextup', 'next_up', 'calendar', 'plex_on_deck',
                                                        'emby_nextup', 'emby_continue', 'simkl_continue')]
                     + [(route, 'seasons') for route in ('seasons', 'series_meta', 'show_seasons')]
                     + [(route, 'videos') for route in ('continue', 'favorites', 'hub_search_menu', 'search_from_history',
                                                        'people_search', 'mdblist_watchlist_browse')])
TYPE_CONTENT = dict([(kind, 'episodes') for kind in ('episode', 'episodes')] + [(kind, 'seasons') for kind in ('season', 'seasons')]
                    + [(kind, 'tvshows') for kind in ('series', 'show', 'shows', 'tv', 'tvshow', 'anime')]
                    + [(kind, 'movies') for kind in ('movie', 'movies')]
                    + [(kind, 'videos') for kind in ('video', 'videos', 'channel', 'channels', 'live', 'all', 'mixed')])
FOLDER_CONTENT = {'series': 'tvshows', 'anime': 'tvshows', 'turkish': 'tvshows', 'korean': 'tvshows', 'movies': 'movies',
                  'live': 'videos'}


def _plugin():
    from . import hub as _p
    return _p


def _add_kodi_sorting(*a, **k):
    return _plugin()._add_kodi_sorting(*a, **k)

def _put_unique_ids(*a, **k):
    return _plugin()._put_unique_ids(*a, **k)

def _favorite_props(*a, **k):
    return _plugin()._favorite_props(*a, **k)

def _add_waiting_items(*a, **k):
    return _plugin()._add_waiting_items(*a, **k)

def _kodi_pictures(*a, **k):
    return _plugin()._kodi_pictures(*a, **k)

def _videoinfotag_apply(*a, **k):
    return _plugin()._videoinfotag_apply(*a, **k)


def _profile_path():
    try:
        path = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        if path:
            os.makedirs(path, exist_ok=True)
    except Exception:
        path = ''
    return path or xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/')


def _listing_page_size():
    return _get_int_setting('large_section_limit', 30, minimum=12, maximum=60)


def _try(call, *args, **kwargs):
    try:
        return call(*args, **kwargs)
    except Exception:
        return None


def _id_properties(ids, info):
    """tmdb / imdb / tvdb ids as the properties skins and TMDb Helper read."""
    found = {}
    for name in ('tmdb_id', 'imdb_id', 'tvdb_id'):
        if ids.get(name):
            found[name] = str(ids[name])
    if found.get('imdb_id'):
        found['imdb'] = found['IMDBNumber'] = found['imdb_id']
    found['tmdb_type'] = 'tv' if str(info.get('mediatype') or '').lower() in SHOW_INFO_TYPES else 'movie'
    return found


def add_item(label, path, is_folder=True, info=None, art=None, properties=None, label2=None, ids=None, context_menu=None, is_favorite=None, cast=None):
    plugin = _plugin()
    item = xbmcgui.ListItem(label=tr(label), label2=tr(label2 or '') if label2 else '')
    art = _kodi_pictures(art)
    info = dict(info or {})
    for field in TRANSLATED_INFO:
        if isinstance(info.get(field), str):
            info[field] = tr(info[field])
    if cast is None and isinstance(info.get('cast'), list):
        cast = info.pop('cast')
    _put_unique_ids(item, ids, info)
    modern = plugin._KODI_MAJOR >= 20
    if info and not (modern and _videoinfotag_apply(item, info, ids=ids, cast=cast)):
        _try(item.setInfo, 'video', info)
    if art:
        _try(item.setArt, art)
        if modern:
            _try(lambda: item.getVideoInfoTag(offscreen=True).setArtwork(dict((k, v) for k, v in art.items() if v)))
    shown = dict(fanart_image=(art or {}).get('fanart') or (art or {}).get('landscape') or (art or {}).get('poster')
                 or addon_fanart())
    if ids:
        shown.update(_try(_id_properties, ids, info or {}) or {})
    if not is_folder and 'action=play_item' in str(path or ''):
        shown.setdefault('IsPlayable', 'true')
    shown.update(dict((key, art[key]) for key in ART_PROPERTIES if art and art.get(key)))
    shown.update(_favorite_props(is_favorite))
    shown.update(properties or {})
    _try(item.setProperties, shown)
    if context_menu:
        _try(item.addContextMenuItems, [(tr(name), command) for name, command in list(context_menu)], replaceItems=True)
    plugin._PENDING_ITEMS.append((path, item, is_folder))


def _infer_content_type():
    """The content type the route implies (Kodi chooses views and sorting by it)."""
    try:
        raw = sys.argv[2] if len(sys.argv) > 2 else ''
        asked = dict(urllib.parse.parse_qsl(str(raw or '').lstrip('?'), keep_blank_values=True))
    except Exception:
        asked = {}
    route = str(asked.get('action') or '').strip().lower()
    kind = str(asked.get('media_type') or asked.get('type') or '').strip().lower()
    folder = str(asked.get('bucket') or '').strip().lower()
    return ROUTE_CONTENT.get(route) or TYPE_CONTENT.get(kind) or FOLDER_CONTENT.get(folder) or 'files'


def end_dir(content=None, cache=True, sortable=True):
    kind = str(content or '').strip().lower() or _infer_content_type()
    xbmcplugin.setContent(HANDLE, kind)
    _add_kodi_sorting(kind, sortable=sortable)
    _add_waiting_items()
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def _merge_seed_ids(base_ids, seed_ids):
    """The ids, with the seed's filling the empty ones."""
    merged = dict(base_ids or {})
    merged.update((key, value) for key, value in (seed_ids or {}).items() if value and not merged.get(key))
    return merged


def _get_tmdbh_seed_ids(canonical_id=None):
    """The ids TMDb Helper's player call left (meganexus.tmdbh_seed_ids) - only for its item."""
    try:
        home = xbmcgui.Window(WINDOW_ID)
        kept, item = home.getProperty('meganexus.tmdbh_seed_ids') or '', home.getProperty('meganexus.tmdbh_seed_for') or ''
        if not kept or (canonical_id and item and item != canonical_id):
            return {}
        return json.loads(kept) or {}
    except Exception:
        return {}
