# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Requests to a Jellyfin or Emby server.

6.0.39: Jellyfin 12 dropped Emby's ways of signing a request (X-Emby-* headers, the api_key
parameter) and the /emby path prefix. A Jellyfin server gets `Authorization: MediaBrowser
…, Token="…"`, the ApiKey parameter and root paths (valid since Jellyfin 10); an Emby
server keeps `Authorization: Emby …`, X-Emby-Authorization / X-Emby-Token, api_key and,
when its address does not already end in /emby, the /emby prefix. Which one a server is
comes from its public /System/Info/Public (`detect`) and is kept with the sign-in."""
import json
from urllib.parse import urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from . import saved

JELLYFIN, EMBY = 'jellyfin', 'emby'
STATUS_TEXT = {401: 'The server rejected the sign-in or access token.',
               403: 'The server does not permit access for this user.',
               404: 'The server API was not found at this address.'}
UNREACHABLE = 'Could not reach the server. Check its address, connection and HTTPS certificate.'


class ServerError(Exception):
    """A Jellyfin / Emby failure, short enough for a notification; `status` = the HTTP status."""

    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def flavor_of(server):
    return EMBY if str((server or {}).get('flavor') or '').lower() == EMBY else JELLYFIN


def token_name(server):
    """The query parameter that carries the token in stream and picture addresses."""
    return 'api_key' if flavor_of(server) == EMBY else 'ApiKey'


def _client(token=''):
    try:
        version = saved.addon().getAddonInfo('version') or '6'
    except Exception:
        version = '6'
    value = 'MediaBrowser Client="MegaNexus", Device="Kodi", DeviceId="%s", Version="%s"' % (saved.device_id(), version)
    return value + (', Token="%s"' % token if token else '')


def headers(token='', flavor=JELLYFIN):
    sent = {'Accept': 'application/json', 'Accept-Charset': 'UTF-8,*', 'Content-Type': 'application/json'}
    if flavor == EMBY:
        sent['Authorization'] = _client(token).replace('MediaBrowser ', 'Emby ', 1)
        sent['X-Emby-Authorization'] = _client()
        if token:
            sent['X-Emby-Token'] = token
    else:
        sent['Authorization'] = _client(token)
    return sent


def base(server):
    """The server's root address: http:// added when missing, a /web or /web/index.html page cut."""
    url = str((server or {}).get('url') or '').strip().rstrip('/')
    if not url:
        return url
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
    parts = urlsplit(url)
    path = parts.path.rstrip('/')
    for page in ('/web/index.html', '/web'):
        if path.lower().endswith(page):
            path = path[:-len(page)]
            break
    return urlunsplit((parts.scheme, parts.netloc, path, '', ''))


def prefix(server):
    """'/emby' for an Emby server whose address does not hold it already (or as detected)."""
    if 'api_prefix' in (server or {}):
        return '/emby' if server['api_prefix'] == '/emby' else ''
    return '/emby' if flavor_of(server) == EMBY and not urlsplit(base(server)).path.lower().endswith('/emby') else ''


def request(url, method='GET', token='', data=None, timeout=None, flavor=JELLYFIN):
    """The answer's bytes; ServerError (with the status) on any failure."""
    body = json.dumps(data).encode('utf-8') if data is not None else None
    try:
        with urlopen(Request(url, data=body, headers=headers(token, flavor), method=method),
                     timeout=timeout or saved.wait()) as answer:
            return answer.read()
    except Exception as exc:
        status = getattr(exc, 'code', None)
        raise ServerError(STATUS_TEXT.get(status, UNREACHABLE), status) from None


def json_of(raw):
    try:
        return json.loads((raw or b'').decode('utf-8'))
    except Exception as exc:
        raise ServerError('Emby returned an unreadable response (%s)' % exc)


def api(server, path, params=None, token='', method='GET', data=None):
    """A signed API call of the server ({} for an empty answer)."""
    query = urlencode([(str(key), str(value)) for key, value in (params or {}).items() if value not in (None, '')])
    url = base(server) + prefix(server) + '/' + str(path or '').lstrip('/') + ('?' + query if query else '')
    raw = request(url, method=method, token=token or server.get('token') or '', data=data, flavor=flavor_of(server))
    return json_of(raw) if raw else {}


def detect(url, timeout=8):
    """{flavor, name, version, url, api_prefix} from the public server info (no sign-in). Emby's
    public info has no product name: its 4.x version or the /emby route tell it; a server
    that wants a sign-in even for that (401) is taken for Emby."""
    root = base({'url': url})
    if not root:
        raise ServerError('Enter the server address')
    info, route, guarded = {}, '', None
    for path in ('/System/Info/Public', '/emby/System/Info/Public'):
        try:
            info = json_of(request(root + path, timeout=timeout))
            route = '/emby' if path.startswith('/emby/') else ''
            break
        except ServerError as error:
            if error.status == 401 and guarded is None:
                guarded = {'flavor': EMBY, 'name': 'Emby', 'version': '', 'url': root,
                           'api_prefix': '/emby' if path.startswith('/emby/') else ''}
    if not info:
        if guarded:
            return guarded
        raise ServerError('No Jellyfin or Emby server answered at this address')
    product, version = str(info.get('ProductName') or ''), str(info.get('Version') or '')
    emby = 'jellyfin' not in product.lower() and (
        'emby' in product.lower() or route == '/emby' or (not product and version.startswith('4.')))
    return {'flavor': EMBY if emby else JELLYFIN, 'name': str(info.get('ServerName') or product or 'Server'),
            'version': version, 'url': root, 'api_prefix': route}
