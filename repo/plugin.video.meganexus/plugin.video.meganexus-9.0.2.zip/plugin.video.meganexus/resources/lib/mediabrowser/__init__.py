# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus' own Jellyfin and Emby client (both grew out of MediaBrowser): no interface,
items in the same shape as the plex package's, so one path draws and plays both.

    store    the two sign-ins and the device id
    wire     signed requests per server kind, `detect`, ServerError
    signin   name / password, Jellyfin Quick Connect, the connected servers
    items    an item with its versions, subtitles, pictures and playback
    library  libraries, pages, Continue Watching, Next Up, Latest, search, finding by id

Nothing here runs before the user connects a server and switches it on (media_servers.py)."""
from .items import artwork_url, node_item, logo_url, playback_url, playable_of  # noqa: F401
from .library import (children, episode_node_item, all_by_ids, latest, libraries, metadata,  # noqa: F401
                      next_up, resume, server_find)
from .signin import (account, account_for_url, is_signed_in, quick_connect_poll, quick_connect_start,  # noqa: F401
                     require_kind, servers, sign_in, sign_out)
from .saved import device_id  # noqa: F401
from .wire import EMBY, JELLYFIN, ServerError, detect, flavor_of, headers, json_of, request  # noqa: F401
