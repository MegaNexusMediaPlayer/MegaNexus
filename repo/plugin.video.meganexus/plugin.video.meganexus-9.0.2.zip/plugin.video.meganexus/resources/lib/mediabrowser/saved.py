# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Jellyfin and Emby sign-ins (7.0.29: one each, both may be connected) and this
device's id. A sign-in lives in its setting and in a Home window property every warm
interpreter shares (a kept Addon handle may still hold the settings of before the
sign-in)."""
import json

import xbmcaddon
import xbmcgui

HOME = 10000
SIGN_INS = {'jellyfin': 'jellyfin_auth_json', 'emby': 'emby_auth_json'}
views = {}                       # server id -> {at, rows}: its libraries, this interpreter


def addon():
    """A new handle every time (a kept one holds the settings of when it was made)."""
    return xbmcaddon.Addon('plugin.video.meganexus')


def setting(name, value=None):
    """Read a setting (''), or write it (a failed write is a ServerError: the connection
    would be lost)."""
    if value is None:
        try:
            return addon().getSetting(name) or ''
        except Exception:
            return ''
    try:
        addon().setSetting(name, value)
    except Exception:
        from .wire import ServerError
        raise ServerError('Could not save the server connection in this Kodi profile.') from None
    return value


def wait():
    try:
        return max(5, int(addon().getSetting('timeout') or '20'))
    except Exception:
        return 20


def shared_name(name):
    """'jellyfin_auth_json' -> 'meganexus.jellyfin.auth'; '' for other settings."""
    return 'meganexus.%s' % name.replace('_json', '').replace('_', '.') if name.endswith('auth_json') else ''


def load(name, default):
    try:
        text = setting(name)
        if not text and shared_name(name):
            text = xbmcgui.Window(HOME).getProperty(shared_name(name)) or ''
        return json.loads(text) if text else default
    except Exception:
        return default


def save(name, value):
    text = json.dumps(value)
    setting(name, text)
    try:
        if shared_name(name):
            xbmcgui.Window(HOME).setProperty(shared_name(name), text)
    except Exception:
        pass


def clear(name):
    setting(name, '')
    try:
        xbmcgui.Window(HOME).clearProperty(shared_name(name))
    except Exception:
        pass


def device_id():
    value = setting('emby_device_id')
    if not value:
        import uuid
        value = uuid.uuid4().hex
        setting('emby_device_id', value)
    return value
