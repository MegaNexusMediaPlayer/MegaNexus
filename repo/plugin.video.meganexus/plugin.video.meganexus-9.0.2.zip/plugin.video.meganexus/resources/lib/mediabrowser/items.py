# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A Jellyfin / Emby item in the same dict shape as a Plex item, so lists, the source
picker, the switch-source index, resume and subtitles share one path.

Every MediaSource is a version (resolution, HDR / Dolby Vision, codecs, audio with Atmos,
container, size, its external text subtitles). Pictures are resized by the server
(posters 500 px, backgrounds 1280 px). Playback asks PlaybackInfo afresh at the handoff
(kept MediaSources go stale and carry no PlaySessionId): the server's DirectStream /
Transcoding address wins, the static stream route is the fallback for older Emby."""
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit

from . import saved, wire

KINDS = {'Movie': 'movie', 'Series': 'show', 'Season': 'season', 'Episode': 'episode'}
CHANNELS = {1: '1.0', 2: '2.0', 6: '5.1', 8: '7.1'}
PICTURE_SUBTITLES = frozenset(('pgs', 'hdmv_pgs_subtitle', 'hdmv-pgs-subtitle', 'vobsub', 'dvd_subtitle',
                               'dvd-subtitle', 'dvdsub', 'dvb_subtitle', 'dvb-subtitle', 'dvbsub', 'xsub'))
SUBTITLE_FILES = {'subrip': 'srt', 'srt': 'srt', 'ass': 'ass', 'ssa': 'ssa', 'webvtt': 'vtt', 'vtt': 'vtt',
                  'mov_text': 'srt'}
TOKEN_NAMES = frozenset(('api_key', 'apikey', 'x-emby-token'))
PEOPLE = (('directors', 'Director', 4), ('writers', 'Writer', 4), ('cast', 'Actor', 10))


def _file_type(codec):
    codec = str(codec or '').lower()
    return SUBTITLE_FILES.get(codec, codec or 'srt')


def _size(count):
    try:
        count = int(count or 0)
    except (TypeError, ValueError):
        return ''
    if count <= 0:
        return ''
    gigabytes = count / (1024.0 ** 3)
    return '%.1f GB' % gigabytes if gigabytes >= 1 else '%.0f MB' % (count / (1024.0 ** 2))


def _resolution(height, width=0):
    try:
        height, width = int(height or 0), int(width or 0)
    except (TypeError, ValueError):
        return ''
    if height > 1088 or width >= 3800:
        return '4K'
    return '1080p' if height >= 1080 else '720p' if height >= 720 else 'SD' if height else ''


def with_token(url, token, server=None):
    """The address with the server's token parameter, unless it carries a token already."""
    if not url or not token:
        return url
    name = wire.token_name(server or _first_sign_in())
    try:
        parts = urlsplit(url)
        pairs = parse_qsl(parts.query, keep_blank_values=True)
        if not {str(key).lower() for key, _value in pairs} & TOKEN_NAMES:
            pairs.append((name, str(token)))
        return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(pairs), parts.fragment))
    except Exception:
        return url + ('&' if '?' in url else '?') + urlencode({name: token})


def _first_sign_in():
    from .signin import account
    return account()


def _subtitles(item_id, source, server):
    """The source's external text subtitles: the server's DeliveryUrl, else its subtitle route."""
    rows, root, token = [], wire.base(server), str(server.get('token') or '')
    for stream in source.get('MediaStreams') or []:
        codec = str(stream.get('Codec') or '').lower()
        if str(stream.get('Type') or '').lower() != 'subtitle' or codec in PICTURE_SUBTITLES:
            continue
        delivery = str(stream.get('DeliveryUrl') or '').strip()
        if delivery:
            url = delivery if delivery.startswith(('http://', 'https://')) else root.rstrip('/') + '/' + delivery.lstrip('/')
        elif stream.get('IsExternal') or stream.get('Path'):
            try:
                number = int(stream.get('Index'))
            except Exception:
                continue
            url = '%s%s/Videos/%s/%s/Subtitles/%s/Stream.%s' % (
                root.rstrip('/'), wire.prefix(server), quote(str(item_id), safe=''),
                quote(str(source.get('Id') or ''), safe=''), number, _file_type(codec))
        else:
            continue
        url = with_token(url, token, server)
        lang = str(stream.get('Language') or 'und')
        rows.append({'id': str(stream.get('Index') if stream.get('Index') is not None else len(rows) + 1),
                     'url': url, 'key': url, 'lang': lang, 'language': lang, 'languageCode': lang,
                     'codec': codec or 'subrip', 'format': _file_type(codec), 'sourceType': 'stream',
                     'sourceName': server.get('name') or 'Emby',
                     'title': str(stream.get('DisplayTitle') or stream.get('Title') or ''),
                     'forced': bool(stream.get('IsForced')), 'selected': bool(stream.get('IsDefault'))})
    return rows


def _first_stream(source, kind):
    return next((stream for stream in source.get('MediaStreams') or [] if str(stream.get('Type') or '') == kind), None) or {}


def _dynamic_range(video):
    title, kind = str(video.get('DisplayTitle') or '').upper(), str(video.get('VideoRange') or '').upper()
    if 'DOVI' in title or 'DOLBY VISION' in title or 'DOVI' in kind:
        return 'Dolby Vision'
    return 'HDR' if 'HDR' in kind or 'HDR' in title else ''


def _sound(audio):
    label = str(audio.get('Codec') or '').upper()
    if not label:
        return ''
    try:
        if audio.get('Channels'):
            label += ' %s' % CHANNELS.get(int(audio['Channels']), '%sch' % int(audio['Channels']))
    except (TypeError, ValueError):
        pass
    return label + (' Atmos' if 'Atmos' in str(audio.get('DisplayTitle') or '') else '')


def versions_of(item, server):
    found = []
    for source in item.get('MediaSources') or []:
        video = _first_stream(source, 'Video')
        resolution, dynamic = _resolution(video.get('Height'), video.get('Width')), _dynamic_range(video)
        codec, sound = str(video.get('Codec') or '').upper(), _sound(_first_stream(source, 'Audio'))
        count = source.get('Size') or 0
        size, container = _size(count), str(source.get('Container') or '').upper()
        found.append({
            'media_source_id': str(source.get('Id') or ''), 'file': str(source.get('Path') or ''),
            'resolution': resolution, 'hdr': dynamic, 'video_codec': codec, 'audio': sound, 'container': container,
            'size_bytes': count, 'size_label': size,
            'info_line': ' • '.join('[ %s ]' % fact for fact in (resolution, dynamic, codec, sound, size) if fact),
            'version_label': ' · '.join(fact for fact in (resolution, dynamic, size, container) if fact)
                             or 'Version %d' % (len(found) + 1),
            'subtitles': _subtitles(item.get('Id') or '', source, server)})
    return found


def ids_of(item):
    given = dict((str(name).lower(), str(value)) for name, value in (item.get('ProviderIds') or {}).items() if value)
    return {'imdb_id': given.get('imdb', ''), 'tmdb_id': given.get('tmdb', ''), 'tvdb_id': given.get('tvdb', '')}


def node_item(item, server):
    versions = versions_of(item, server)
    try:
        duration = int(item.get('RunTimeTicks') or 0) // 10000
    except (TypeError, ValueError):
        duration = 0
    ident = str(item.get('Id') or '')
    people = item.get('People') or []
    row = {
        'backend': 'emby', 'server_id': str(server.get('id') or ''), 'server_name': server.get('name') or 'Emby',
        'rating_key': ident, 'key': ident, 'media_type': KINDS.get(str(item.get('Type') or 'Movie'), 'movie'),
        'title': str(item.get('Name') or 'Emby'), 'raw_title': str(item.get('Name') or ''),
        'summary': str(item.get('Overview') or ''), 'year': item.get('ProductionYear') or 0,
        'duration_ms': duration, 'index': item.get('IndexNumber') or 0, 'season': item.get('ParentIndexNumber') or 0,
        'thumb': ident, 'art': ident, 'rating': float(item.get('CommunityRating') or 0) or 0,
        'content_rating': str(item.get('OfficialRating') or ''),
        'studio': ', '.join(studio.get('Name') for studio in item.get('Studios') or [] if studio.get('Name'))[:60],
        'tagline': '', 'premiered': str(item.get('PremiereDate') or '')[:10],
        'genres': list(item.get('Genres') or [])[:6], 'versions': versions, 'ids': ids_of(item),
        'series_id': str(item.get('SeriesId') or ''), 'show_title': str(item.get('SeriesName') or ''),
        'info_line': versions[0]['info_line'] if versions else '',
        'size_label': versions[0]['size_label'] if versions else ''}
    for field, role, most in PEOPLE:
        row[field] = [person.get('Name') for person in people if person.get('Type') == role and person.get('Name')][:most]
    return row


def artwork_url(server, item_id, kind='Primary', width=0):
    """The picture resized by the server (500 px posters, 1280 px backgrounds by default)."""
    if not item_id:
        return ''
    width = width or (1280 if kind in ('Backdrop', 'Thumb') else 500)
    return '%s%s/Items/%s/Images/%s?%s' % (wire.base(server), wire.prefix(server), quote(str(item_id), safe=''),
                                           quote(str(kind), safe=''), urlencode({'maxWidth': width, 'quality': 90,
                                                                                 wire.token_name(server): server.get('token') or ''}))


def logo_url(server, item_id):
    return artwork_url(server, item_id, kind='Logo') if item_id else ''


def _stream_query(server, source_id='', session=''):
    query = {'static': 'true', wire.token_name(server): server.get('token') or ''}
    if source_id:
        query['MediaSourceId'] = source_id
    if session:
        query['PlaySessionId'] = session
    return urlencode(query)


def playback_url(server, item_id, media_source_id=''):
    return '%s%s/Videos/%s/stream?%s' % (wire.base(server), wire.prefix(server), item_id,
                                         _stream_query(server, media_source_id))


def playback_info(server, item_id):
    """A fresh PlaybackInfo for this user and device."""
    return wire.api(server, '/Items/%s/PlaybackInfo' % quote(str(item_id), safe=''),
                    params={'UserId': server.get('user_id') or '', 'StartTimeTicks': 0, 'AutoOpenLiveStream': 'false'},
                    method='POST', data={'UserId': server.get('user_id') or '', 'DeviceId': saved.device_id()})


def playable_of(server, item_id, media_source_id=''):
    """{url, media_source_id, play_session_id, version} of one source, from fresh PlaybackInfo."""
    info = playback_info(server, item_id)
    sources = list(info.get('MediaSources') or [])
    wanted = str(media_source_id or '')
    source = next((each for each in sources if str(each.get('Id') or '') == wanted), None) or (sources[0] if sources else {})
    source_id, session = str(source.get('Id') or wanted), str(info.get('PlaySessionId') or '')
    given = source.get('DirectStreamUrl') or source.get('DirectUrl') or source.get('TranscodingUrl') or ''
    if given:
        if not str(given).startswith(('http://', 'https://')):
            given = wire.base(server).rstrip('/') + '/' + str(given).lstrip('/')
        url = with_token(str(given), str(server.get('token') or ''), server)
    else:
        container = str(source.get('Container') or '').strip().lower()
        url = '%s%s/Videos/%s/stream%s?%s' % (wire.base(server), wire.prefix(server), quote(str(item_id), safe=''),
                                              '.' + container if container and container.isalnum() else '',
                                              _stream_query(server, source_id, session))
    version = (versions_of({'Id': item_id, 'MediaSources': [source]}, server) or [{}])[0]
    return {'url': url, 'media_source_id': source_id, 'play_session_id': session, 'version': version}
