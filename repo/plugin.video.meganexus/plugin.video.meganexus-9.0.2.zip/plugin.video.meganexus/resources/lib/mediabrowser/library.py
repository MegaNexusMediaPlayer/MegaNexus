# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A Jellyfin / Emby server's libraries, pages, Continue Watching, Next Up, Latest, search,
details - and the title the user opened, found by its ids.

Emby filters by provider id (AnyProviderIdEquals); Jellyfin ignores that filter and answers
the first items of the library, so for Jellyfin the ids of every movie and series are read
once (ids only, no pictures or user data) and kept 15 minutes. Every hit must carry one of
the wanted ids; on Emby, a copy without any ids may also come by its exact title (the
unidentified releases a library often holds)."""
import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmc
import xbmcgui

from . import items, saved, wire
from .wire import JELLYFIN, ServerError

VIEWS_LIFE = 15 * 60
PAGE_SIZE = 80
LIST_FIELDS = 'Overview,Genres,Studios,ProviderIds,OfficialRating,CommunityRating,PremiereDate,ProductionYear,DateCreated'
DETAIL_FIELDS = ('MediaSources,Overview,Genres,Studios,People,ProviderIds,OfficialRating,CommunityRating,'
                 'PremiereDate,ProductionYear,Path')
FOLDERS = ('folder', 'collectionfolder', 'userrootfolder')
SEARCH_TYPES = {'movie': 'Movie', 'show': 'Series', 'series': 'Series', 'episode': 'Episode'}
SERIES = ('series', 'show', 'episode')
INDEX_LIFE = 15 * 60
INDEX_MOST = 50000
PROVIDERS = (('imdb', 'imdb_id'), ('tmdb', 'tmdb_id'), ('tvdb', 'tvdb_id'))
_indexes = {}               # (url, user) -> (at, {'Movie'|'Series': {'imdb:tt1': [item ids]}})


def _user_items(server, tail=''):
    return '/Users/%s/Items%s' % (server.get('user_id'), tail)


def libraries(server, force=False):
    """[{key, title, type}] of the movie, show, collection and mixed libraries (15 minutes)."""
    sid = str(server.get('id') or '')
    kept = saved.views.get(sid) or {}
    if not force and kept.get('rows') is not None and kept.get('at', 0) + VIEWS_LIFE > time.time():
        return list(kept['rows'])
    shared_name = 'meganexus.emby.libs.%s' % sid
    if not force and sid:
        try:
            shared = xbmcgui.Window(saved.HOME).getProperty(shared_name) or ''
            if shared:
                shared = json.loads(shared)
                if shared.get('at', 0) + VIEWS_LIFE > time.time():
                    saved.views[sid] = shared
                    return list(shared.get('rows') or [])
        except Exception:
            pass
    answer = wire.api(server, '/Users/%s/Views' % server.get('user_id'))
    rows = [{'key': str(view.get('Id') or ''), 'title': str(view.get('Name') or 'Library'),
             'type': 'show' if str(view.get('CollectionType') or '').lower() == 'tvshows' else 'movie'}
            for view in answer.get('Items') or []
            if str(view.get('CollectionType') or '').lower() in ('movies', 'tvshows', 'boxsets', '')]
    kept = {'at': time.time(), 'rows': rows}
    saved.views[sid] = kept
    if sid:
        try:
            xbmcgui.Window(saved.HOME).setProperty(shared_name, json.dumps(kept))
        except Exception:
            pass
    return list(rows)


def children(server, parent_id, start=0, size=PAGE_SIZE, sort='', include_types='', recursive=False):
    """(items, total) of a library, show or season page. A top library is asked recursively
    for typed rows, so folders are never listed as films; 'Name:desc' sorts backwards."""
    backwards = str(sort or '').endswith(':desc')
    params = {'ParentId': parent_id, 'StartIndex': int(start or 0), 'Limit': int(size or PAGE_SIZE),
              'Fields': LIST_FIELDS, 'SortBy': str(sort).split(':', 1)[0] if backwards else sort or 'SortName',
              'SortOrder': 'Descending' if backwards else 'Ascending'}
    if include_types:
        params['IncludeItemTypes'] = str(include_types)
    if recursive:
        params['Recursive'] = 'true'
    answer = wire.api(server, _user_items(server), params)
    allowed = {kind.strip().lower() for kind in str(include_types or '').split(',') if kind.strip()}
    rows = [items.node_item(node, server) for node in answer.get('Items') or []
            if str(node.get('Type') or '').lower() not in FOLDERS
            and (not allowed or str(node.get('Type') or '').lower() in allowed)]
    return rows, int(answer.get('TotalRecordCount') or len(rows))


def _position(node):
    """The resume position in ms (UserData ticks)."""
    try:
        return int(((node.get('UserData') or {}).get('PlaybackPositionTicks')) or 0) // 10000
    except Exception:
        return 0


def _with_position(node, server):
    row = items.node_item(node, server)
    row['resume_ms'] = _position(node)
    return row


def resume(server, start=0, size=PAGE_SIZE):
    """(items, total) the user started - Continue Watching, as Plex's On Deck."""
    answer = wire.api(server, _user_items(server, '/Resume'), {
        'StartIndex': int(start or 0), 'Limit': int(size or PAGE_SIZE), 'Fields': LIST_FIELDS,
        'MediaTypes': 'Video', 'Recursive': 'true', 'EnableTotalRecordCount': 'true'})
    rows = [_with_position(node, server) for node in answer.get('Items') or []]
    return rows, int(answer.get('TotalRecordCount') or len(rows))


def next_up(server, limit=PAGE_SIZE):
    """The next unwatched episode of each series ([] when the server cannot say)."""
    try:
        answer = wire.api(server, '/Shows/NextUp', {'UserId': server.get('user_id'), 'Limit': int(limit or PAGE_SIZE),
                                                    'Fields': LIST_FIELDS})
    except Exception:
        return []
    return [_with_position(node, server) for node in answer.get('Items') or []]


def latest(server, limit=PAGE_SIZE):
    """Recently added movies and series."""
    answer = wire.api(server, _user_items(server, '/Latest'), {'IncludeItemTypes': 'Movie,Series',
                                                                'Limit': int(limit or PAGE_SIZE), 'Fields': LIST_FIELDS,
                                                                'GroupItems': 'true'})
    nodes = answer if isinstance(answer, list) else answer.get('Items') or []
    return [items.node_item(node, server) for node in nodes if str(node.get('Type') or '') in ('Movie', 'Series')]


def server_find(server, query, media_type='', limit=40):
    answer = wire.api(server, _user_items(server), {
        'SearchTerm': query, 'IncludeItemTypes': SEARCH_TYPES.get((media_type or '').lower(), 'Movie,Series,Episode'),
        'Recursive': 'true', 'Limit': int(limit), 'Fields': LIST_FIELDS})
    rows = [items.node_item(node, server) for node in answer.get('Items') or []]
    return [row for row in rows if row['media_type'] in ('movie', 'show', 'episode')]


def metadata(server, item_id):
    return items.node_item(wire.api(server, _user_items(server, '/%s' % item_id), {'Fields': DETAIL_FIELDS}), server)


def id_keys(ids):
    """['imdb:tt1', 'tmdb:5', …] of the ids that are set."""
    return ['%s:%s' % (name[:4], str((ids or {}).get(name) or '').strip().lower())
            for name in ('imdb_id', 'tmdb_id', 'tvdb_id') if str((ids or {}).get(name) or '').strip()]


def carries(row, ids):
    """The item carries one of the wanted ids."""
    return bool(set(id_keys(row.get('ids') or {})) & set(id_keys(ids)))


def id_index(server, force=False):
    """{'Movie' | 'Series': {'imdb:tt1': [item ids]}} of the whole server (Jellyfin, 15 minutes)."""
    key = (server.get('url'), server.get('user_id'))
    kept = _indexes.get(key)
    if kept and not force and time.time() - kept[0] < INDEX_LIFE:
        return kept[1]
    answer = wire.api(server, _user_items(server), {
        'IncludeItemTypes': 'Movie,Series', 'Recursive': 'true', 'Fields': 'ProviderIds',
        'EnableImages': 'false', 'EnableUserData': 'false', 'Limit': INDEX_MOST})
    index = {'Movie': {}, 'Series': {}}
    for node in answer.get('Items') or []:
        kind = str(node.get('Type') or '')
        if kind in index and node.get('Id'):
            for found in id_keys(items.ids_of(node)):
                index[kind].setdefault(found, []).append(str(node['Id']))
    _indexes[key] = (time.time(), index)
    return index


def _kind(media_type):
    return 'Series' if str(media_type).lower() in SERIES else 'Movie'


def all_by_ids(server, ids, media_type='movie', title='', limit=10):
    """Every copy of the title on this server, with its versions."""
    if wire.flavor_of(server) == JELLYFIN:
        index = id_index(server).get(_kind(media_type)) or {}
        found = []
        for wanted in id_keys(ids):
            for item_id in index.get(wanted) or []:
                if item_id not in found:
                    found.append(item_id)
        rows = []
        for item_id in found[:int(limit)]:
            try:
                rows.append(metadata(server, item_id))
            except ServerError:
                continue
        return [row for row in rows if carries(row, ids)]
    return [row for row in _emby_copies(server, ids, media_type, title, limit)
            if carries(row, ids) or (title and not id_keys(row.get('ids') or {}))]


def _emby_copies(server, ids, media_type, title, limit):
    found, seen = [], set()

    def add(row):
        key = str(row.get('rating_key') or '')
        if key and key not in seen:
            seen.add(key)
            found.append(row)
    for provider, name in PROVIDERS:
        value = str((ids or {}).get(name) or '')
        if not value:
            continue
        try:
            answer = wire.api(server, _user_items(server), {
                'AnyProviderIdEquals': '%s.%s' % (provider, value), 'IncludeItemTypes': _kind(media_type),
                'Recursive': 'true', 'Limit': int(limit), 'Fields': DETAIL_FIELDS})
        except ServerError:
            continue
        for node in answer.get('Items') or []:
            add(items.node_item(node, server))
    if found:                       # an exact id match is the answer: no title scan
        xbmc.log('[MegaNexus] Emby exact id match — skipping the title pass (server=%s, %d copies)'
                 % (server.get('name') or '?', len(found)), xbmc.LOGINFO)
        return _with_versions(server, found, limit)
    if title and len(found) < int(limit):
        wanted = dict((name, str((ids or {}).get(name) or '')) for name in ('imdb_id', 'tmdb_id'))
        for row in server_find(server, title, media_type=media_type, limit=int(limit)):
            have = row.get('ids') or {}
            if (any(wanted[name] and have.get(name) == wanted[name] for name in wanted)
                    or str(row.get('title') or '').strip().lower() == str(title).strip().lower()):
                add(row)
    return _with_versions(server, found, limit)


def _with_versions(server, found, limit):
    """The first `limit` copies; those without MediaSources get their full record (at once)."""
    rows = found[:int(limit)]
    missing = [row for row in rows if not (row.get('versions') or []) and row.get('rating_key')]
    full = {}
    if missing:
        with ThreadPoolExecutor(max_workers=min(6, len(missing))) as pool:
            asked = dict((pool.submit(metadata, server, row.get('rating_key')), row) for row in missing)
            for done in as_completed(asked):
                try:
                    full[str(asked[done].get('rating_key'))] = done.result()
                except Exception:
                    pass
    return [full.get(str(row.get('rating_key')), row) for row in rows]


def episode_node_item(server, show_item, season, episode):
    """The episode (with its MediaSources) of a series item; None."""
    try:
        answer = wire.api(server, '/Shows/%s/Episodes' % show_item.get('rating_key'), {
            'UserId': server.get('user_id'), 'Season': int(season), 'Fields': DETAIL_FIELDS})
    except (ServerError, TypeError, ValueError):
        return None
    for node in answer.get('Items') or []:
        try:
            if int(node.get('IndexNumber') or -1) == int(episode):
                return items.node_item(node, server)
        except (TypeError, ValueError):
            continue
    return None
