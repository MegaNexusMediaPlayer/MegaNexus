# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Connecting Jellyfin and Emby: name and password (AuthenticateByName) for both, or
Jellyfin's Quick Connect (a 6-digit code approved in another signed-in Jellyfin app).

Before 7.0.29 one slot held whichever server was connected last; a Jellyfin sign-in found
there moves to its own setting once, and switches set for an Emby server shown as
"Jellyfin" move to Emby's. A sign-in from before 6.0.39 has no flavor: the server is asked
once (an offline one again at most every 10 minutes)."""
import time
from urllib.parse import urlencode

from . import saved, wire
from .wire import EMBY, JELLYFIN, ServerError

ASK_AGAIN = 600
_asked = {'at': 0.0}
MOVED_SWITCHES = (('meganexus_jellyfin_enabled', 'meganexus_emby_enabled'),
                  ('meganexus_home_jellyfin', 'meganexus_home_emby'),
                  ('emby_in_sources', 'emby_server_in_sources'))


def _move_old_slot():
    old = saved.load(saved.SIGN_INS[EMBY], {}) or {}
    if saved.setting('meganexus_emby_split') != 'true':
        try:
            if old.get('token') and old.get('flavor', EMBY) == EMBY:
                for before, after in MOVED_SWITCHES:
                    if saved.setting(before):
                        saved.setting(after, saved.setting(before))
            saved.setting('meganexus_emby_split', 'true')
        except ServerError:
            pass
    if old.get('flavor') == JELLYFIN and not saved.load(saved.SIGN_INS[JELLYFIN], {}):
        saved.save(saved.SIGN_INS[JELLYFIN], old)
        saved.clear(saved.SIGN_INS[EMBY])


def _sign_in_of(flavor):
    found = saved.load(saved.SIGN_INS[flavor], {}) or {}
    if flavor == EMBY and found.get('token') and found.get('url') and not found.get('flavor'):
        if time.time() - _asked['at'] > ASK_AGAIN:
            _asked['at'] = time.time()
            try:
                found.update(flavor=wire.detect(found['url'], timeout=4)['flavor'])
                saved.save(saved.SIGN_INS[EMBY], found)
                _move_old_slot()
                return _sign_in_of(flavor)
            except Exception:
                pass
        found = dict(found, flavor=EMBY)            # made the Emby way
    return found


def _complete(found):
    return bool(found.get('token') and found.get('user_id') and found.get('url'))


def account(flavor=None):
    """One kind's sign-in; without a kind, the first complete one ({})."""
    _move_old_slot()
    if flavor:
        return _sign_in_of(flavor)
    return next((found for found in map(_sign_in_of, (JELLYFIN, EMBY)) if _complete(found)), {})


def account_for_url(url):
    """The sign-in of the server at this address (else the first one)."""
    url = str(url or '').rstrip('/')
    for kind in (JELLYFIN, EMBY):
        found = account(kind)
        if found.get('url') and str(found['url']).rstrip('/') == url:
            return found
    return account()


def is_signed_in(flavor=None):
    return _complete(account(flavor))


def sign_out(flavor=None):
    for kind in (flavor,) if flavor else (JELLYFIN, EMBY):
        saved.setting(saved.SIGN_INS[kind], '')
        try:
            import xbmcgui
            xbmcgui.Window(saved.HOME).clearProperty(saved.shared_name(saved.SIGN_INS[kind]))
        except Exception:
            pass
    saved.views.clear()


def _keep(server, answer, username=''):
    token, user = answer.get('AccessToken') or '', answer.get('User') or {}
    if not token or not user.get('Id'):
        raise ServerError('Sign-in failed')
    found = {'url': server['url'], 'flavor': server['flavor'], 'token': str(token), 'user_id': str(user.get('Id')),
             'username': user.get('Name') or username or '',
             'server_name': answer.get('ServerName') or server.get('name') or ('Emby' if server['flavor'] == EMBY else 'Jellyfin'),
             'server_version': server.get('version') or '', 'signed_in_at': int(time.time())}
    if 'api_prefix' in server:
        found['api_prefix'] = server['api_prefix']
    if answer.get('ServerId'):
        found['server_id'] = str(answer['ServerId'])
    saved.save(saved.SIGN_INS[server['flavor']], found)
    saved.views.clear()
    return found


def require_kind(server, flavor):
    """The detected server, or a ServerError naming where it belongs."""
    if flavor and server['flavor'] != flavor:
        other = 'Emby' if server['flavor'] == EMBY else 'Jellyfin'
        raise ServerError('This is %s %s server - connect it under %s.' % ('an' if other == 'Emby' else 'a', other, other))
    return server


def sign_in(url, username, password='', flavor=None):
    """Name and password; `flavor` = the connection the user is setting up."""
    server = require_kind(wire.detect(url), flavor)
    raw = wire.request('%s%s/Users/AuthenticateByName' % (server['url'], wire.prefix(server)), method='POST',
                       flavor=server['flavor'], data={'Username': str(username or ''), 'Pw': str(password or '')})
    return _keep(server, wire.json_of(raw), username)


def quick_connect_start(url):
    """{server, secret, code}: the code to approve in another Jellyfin app."""
    server = wire.detect(url)
    if server['flavor'] != JELLYFIN:
        raise ServerError('Quick Connect is a Jellyfin feature. Use the username and password for Emby.')
    try:
        on = wire.json_of(wire.request(server['url'] + '/QuickConnect/Enabled'))
    except ServerError:
        on = False
    if on is not True:
        raise ServerError('Quick Connect is turned off on this server. Use the username and password.')
    answer = wire.json_of(wire.request(server['url'] + '/QuickConnect/Initiate', method='POST'))
    if not answer.get('Secret') or not answer.get('Code'):
        raise ServerError('The server did not start Quick Connect')
    return {'server': server, 'secret': str(answer['Secret']), 'code': str(answer['Code'])}


def quick_connect_poll(state):
    """None while waiting; the kept sign-in once the code was approved."""
    server = state['server']
    answer = wire.json_of(wire.request('%s/QuickConnect/Connect?%s' % (server['url'], urlencode({'Secret': state['secret']}))))
    if not answer.get('Authenticated'):
        return None
    raw = wire.request(server['url'] + '/Users/AuthenticateWithQuickConnect', method='POST',
                       data={'Secret': state['secret']})
    return _keep(server, wire.json_of(raw))


def servers(flavor=None):
    """One server per connected kind, in the item-list shape the Plex servers have."""
    found = []
    for kind in (flavor,) if flavor else (JELLYFIN, EMBY):
        signed = account(kind)
        if not is_signed_in(kind):
            continue
        server = {'id': signed.get('user_id') or 'emby', 'name': signed.get('server_name') or 'Emby',
                  'url': signed.get('url') or '', 'token': signed.get('token') or '',
                  'user_id': signed.get('user_id') or '', 'backend': 'emby', 'flavor': wire.flavor_of(signed)}
        if 'api_prefix' in signed:
            server['api_prefix'] = signed['api_prefix']
        found.append(server)
    return found
