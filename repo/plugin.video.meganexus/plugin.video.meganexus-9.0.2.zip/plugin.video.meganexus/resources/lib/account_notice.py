# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.0.0: an account that is signed out for good says so - Kodi's notification, top right.

Nuvio, Stremio, Trakt and Simkl renew or redo their sign-in by themselves; when that is
refused (not when the network is down) nothing told the person: Continue Watching, the
library and the scrobbles just stopped.
"""
TOLD = 'special://profile/addon_data/plugin.video.meganexus/signed_out_told.json'


def signed_out(service, session=''):
    """The account refused its sign-in and MegaNexus could not renew or redo it by itself (no
    password kept, a changed one, a withdrawn app): Kodi's own notification, top right. ONCE
    for that sign-in (``session``: what identifies it - only a digest of it is kept), also
    over Kodi restarts: it came back at every start ("obavijest treba da bude samo jednom").
    Never over a video - then at a later call."""
    try:
        import hashlib
        import json
        import xbmc
        import xbmcgui
        import xbmcvfs
        mark = hashlib.sha256(('%s|%s' % (service, session)).encode('utf-8')).hexdigest()[:16]
        path = xbmcvfs.translatePath(TOLD)
        try:
            with open(path, encoding='utf-8') as handle:
                told = json.load(handle)
        except (OSError, ValueError):
            told = {}
        if not isinstance(told, dict) or told.get(service) == mark:
            return
        if xbmc.getCondVisibility('Player.HasVideo'):
            return
        told[service] = mark
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(told, handle)
        xbmcgui.Dialog().notification('MegaNexus', '%s: signed out · sign in again in Settings › Accounts & tracking'
                                      % service, xbmcgui.NOTIFICATION_WARNING, 8000)
    except Exception:
        pass
