# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Which sources the list shows and in which order (Settings > Sources).

The quality profile decides the preferences: Best / Balanced / Data saver are fixed
presets, Custom reads each switch. Nothing is ever hidden for its resolution - the list
is a complete inventory; only CAM / TS copies (when chosen) and formats the device can
not decode (when excluded) leave it, and the user's own Plex / Emby / Jellyfin copies
never do. Order: the user's provider priority, then quality, size, debrid, the source
played last time, HDR and sound."""
import re
from urllib.parse import urlparse

GB = 1024 ** 3
UNITS = {'KB': 1024, 'MB': 1024 ** 2, 'GB': GB, 'TB': 1024 ** 4}
_SIZE = re.compile(r'(\d+(?:\.\d+)?)\s*(GB|MB|KB|TB)')

# quality tiers: (tier, any of these in the text)
TIERS = ((4, ('2160', '4K', 'UHD')), (3, ('1080', 'FHD')), (2, ('720',)), (1, ('480', 'SD')))
FLOORS = {'no filter': 0, '480p+': 1, '720p+': 2, '1080p+': 3, '4k only': 4}

# the row fields that describe it, in the order they are read
ROW_TEXT = ('quality', 'badges', 'name', 'label2', 'source_info', 'addon', 'source_site',
            'provider_name_raw', 'provider')
MATCH_TEXT = ('provider_name_raw', 'provider', 'addon', 'source_site', 'name', 'source_info')
PRIORITY_TEXT = ('provider_name_raw', 'addon', 'name')
SERVER_TEXT = ('provider_name_raw', 'provider', 'addon', 'name')
SERVER_MARKS = ('plex native', 'plex •', 'emby native', 'emby •', 'dplex', 'jellyfin native',
                'jellyfin •')
CAM_WORDS = ('CAM', 'CAMRIP', 'HDCAM', 'TS', 'TELESYNC', 'HDTS', 'TC', 'TELECINE', 'SCREENER')
DEBRID_CHIPS = ('RD+', 'AD+', 'PM', 'TB', 'ED+')
HDR_MARKS = ('DV', 'DOVI', 'HDR10+', 'HDR10', 'HDR')
SOUND_SCORES = (('ATMOS', 6), ('TRUEHD', 5), ('DTS-X', 4), ('DTS-HD', 3), ('DD+', 2), ('7.1', 2), ('5.1', 1))
PRIORITY_TOP = 10000
EXCLUDABLE = (('AV1', re.compile(r'\bAV1\b')),
              ('HEVC', re.compile(r'\b(?:HEVC|H\.265|X265|H265)\b')),
              ('DV', re.compile(r'\b(?:DOLBY[ ._-]?VISION|DOVI|DV)\b')))

# profile -> (floor, hide CAM/TS, prefer debrid, prefer HDR, prefer Atmos)
PROFILES = {
    'best': ('4K only', True, True, True, True),
    'balanced': ('1080p+', True, True, False, False),
    'data_saver': ('720p+', True, False, False, False),
}
# what the profile setting may hold (its labels, also of earlier versions)
PROFILE_NAMES = {
    'best': 'best', 'balanced': 'balanced', 'balanced (recommended)': 'balanced',
    'data saver': 'data_saver', 'data_saver': 'data_saver', 'custom': 'custom',
}
DEFAULT_PROFILE = 'Balanced (recommended)'
YES = ('true', '1', 'yes', 'on')


def bytes_of(value):
    """Bytes of a size: a number as it is, "1.5 GB" / "700 MiB" read from text, else 0."""
    try:
        if isinstance(value, (int, float)):
            return int(value)
        text = str(value or '').strip().upper().replace('GIB', 'GB').replace('MIB', 'MB')
        found = _SIZE.search(text)
        return int(float(found.group(1)) * UNITS[found.group(2)]) if found else 0
    except Exception:
        return 0


def entry_text_blob(entry):
    return ' '.join(str(entry.get(key) or '') for key in ROW_TEXT).upper()


def quality_rank(value):
    """0-4: unknown, SD, 720p, 1080p, 4K - of a row or a text."""
    text = (entry_text_blob(value) if isinstance(value, dict) else str(value or '')).upper()
    for tier, marks in TIERS:
        if any(mark in text for mark in marks):
            return tier
    return 0


def is_cam_entry(entry):
    words = ' %s ' % entry_text_blob(entry)
    return any(' %s ' % word in words for word in CAM_WORDS)


def is_debrid_entry(entry):
    return str(entry.get('provider') or '').upper() in DEBRID_CHIPS


def _lower_text(entry, keys):
    return ' '.join(str(entry.get(key) or '').lower() for key in keys)


def entry_matches_last_source(entry, pref):
    """The row comes from the provider / host the title was played from last time."""
    if not pref:
        return False
    wanted = [str(pref.get(key) or '').strip().lower() for key in ('provider_name', 'provider_id')]
    host = str(pref.get('stream_url_host') or '').strip().lower()
    text = _lower_text(entry, MATCH_TEXT)
    if any(word and word in text for word in wanted):
        return True
    address = str(entry.get('stream_url') or '').strip()
    if host and address and (urlparse(address).netloc or '').lower() == host:
        return True
    return bool(host and host in text)


def _min_quality_required_rank(raw):
    return FLOORS.get(str(raw or 'No filter').strip().lower(), 0)


def _profile(addon):
    try:
        raw = addon.getSetting('quality_profile') or DEFAULT_PROFILE
    except Exception:
        raw = DEFAULT_PROFILE
    return PROFILE_NAMES.get(raw.strip().lower(), 'balanced')


def _switch(addon, name, default=False):
    fallback = 'true' if default else 'false'
    try:
        raw = addon.getSetting(name) or fallback
    except Exception:
        raw = fallback
    return raw.strip().lower() in YES


def _priority(addon):
    """The provider priority: the typed list, else the order of the Sources page."""
    try:
        order = [part.strip().lower() for part in (addon.getSetting('source_priority_order') or '').split(',')
                 if part.strip()]
    except Exception:
        order = []
    if order:
        return order
    try:
        from .meganexus import addon_registry
        for provider in addon_registry.list_providers() or []:
            name = (provider.get('name') or provider.get('id') or '').strip().lower()
            if name:
                order.append(name)
    except Exception:
        pass
    return order


def source_settings(addon):
    order = _priority(addon) if _switch(addon, 'bypass_all_filters') else None
    if order is not None:
        # "show every source": nothing is filtered, the preferences still order the list
        return {'hide_cam_ts': False, 'prefer_debrid': _switch(addon, 'prefer_debrid', True),
                'prefer_hdr': _switch(addon, 'prefer_hdr', True), 'prefer_atmos': _switch(addon, 'prefer_atmos', True),
                'min_quality_rank': 0, 'source_priority_order': order, 'quality_profile': 'bypass',
                'bypass_all_filters': True}
    profile = _profile(addon)
    if profile != 'custom':
        floor, hide, debrid, hdr, atmos = PROFILES[profile]
    else:
        try:
            floor = addon.getSetting('min_quality') or 'No filter'
        except Exception:
            floor = 'No filter'
        hide, debrid, hdr, atmos = (_switch(addon, name, True) for name in
                                    ('hide_cam_ts', 'prefer_debrid', 'prefer_hdr', 'prefer_atmos'))
    order = _priority(addon)
    codecs = {name for name, setting in (('AV1', 'exclude_av1'), ('HEVC', 'exclude_hevc'))
              if _switch(addon, setting)}
    ranges = {'DV'} if _switch(addon, 'exclude_dv') else set()
    return {'hide_cam_ts': hide, 'prefer_debrid': debrid, 'prefer_hdr': hdr, 'prefer_atmos': atmos,
            'min_quality_rank': _min_quality_required_rank(floor), 'source_priority_order': order,
            'quality_profile': profile, 'codec_exclusions': codecs, 'dr_exclusions': ranges}


def _own_server(entry):
    text = _lower_text(entry, SERVER_TEXT)
    return any(mark in text for mark in SERVER_MARKS)


def _formats(entry):
    text = entry_text_blob(entry)
    return {name for name, pattern in EXCLUDABLE if pattern.search(text)}


def filter_stream_entries(entries, settings):
    """The rows that stay, in their order: own servers always; others without CAM / TS
    (when hidden) and without an excluded format."""
    rows = list(entries or [])
    excluded = set(settings.get('codec_exclusions') or set()) | set(settings.get('dr_exclusions') or set())
    hide_cam = settings.get('hide_cam_ts', True)

    def stays(row):
        if _own_server(row):
            return True
        if hide_cam and is_cam_entry(row):
            return False
        return not (excluded and _formats(row) & excluded)
    return [row for row in rows if stays(row)]


def _priority_bonus(entry, order):
    """PRIORITY_TOP minus the position of the first listed provider the row names; 0 when none."""
    if not order:
        return 0
    texts = [text for text in (str(entry.get(key) or '').lower() for key in PRIORITY_TEXT) if text]
    for position, name in enumerate(order):
        if name and any(name in text for text in texts):
            return PRIORITY_TOP - position
    return 0


def source_order_key(entry, settings, preferred_source=None):
    """Higher is better: priority, quality, size, debrid, played last, HDR, sound, then names."""
    chips = str(entry.get('badges') or '').upper()
    hdr = int(bool(settings.get('prefer_hdr', True) and any(mark in chips for mark in HDR_MARKS)))
    sound = 0
    if settings.get('prefer_atmos', True):
        sound = max([score for word, score in SOUND_SCORES if word in chips] or [0])
    return (
        _priority_bonus(entry, settings.get('source_priority_order') or []),
        quality_rank(entry) or quality_rank(entry.get('quality')),
        bytes_of(entry.get('size_label')),
        int(bool(settings.get('prefer_debrid', True) and is_debrid_entry(entry))),
        int(entry_matches_last_source(entry, preferred_source)),
        hdr,
        sound,
        str(entry.get('addon') or ''),
        str(entry.get('name') or ''),
    )


def renumber_stream_entries(entries):
    rows = list(entries or [])
    for number, row in enumerate(rows, 1):
        row['count'] = '%02d.' % number
    return rows


def finalize_stream_entries(entries, settings, preferred_source=None, resort=True):
    rows = list(entries or [])
    kept = filter_stream_entries(rows, settings) or rows
    if resort:
        kept = sorted(kept, key=lambda row: source_order_key(row, settings, preferred_source), reverse=True)
    return renumber_stream_entries(kept)
