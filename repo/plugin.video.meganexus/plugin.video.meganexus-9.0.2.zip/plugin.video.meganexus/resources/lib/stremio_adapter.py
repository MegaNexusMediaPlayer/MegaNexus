# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Stremio source adapter."""
from .meganexus import addon_wire as _backend

SERIES_TYPES = ("series", "tv", "show", "episode")

def stremio_type(media_type):
    value = str(media_type or "movie").strip().lower()
    if value in SERIES_TYPES:
        return "series"
    return value

def offers_streams(provider, media_type, item_id=None):
    mt = stremio_type(media_type)
    if _backend.offers(provider, "stream", media_type=mt, item_id=item_id):
        return True
    if mt == "anime":
        return _backend.offers(provider, "stream", media_type="series", item_id=item_id)
    return False

def fetch(provider, media_type, item_id, timeout_override=None):
    mt = stremio_type(media_type)
    data = _backend.fetch_streams(provider, mt, item_id, timeout_override=timeout_override)
    if (not (data or {}).get("streams")) and mt == "anime":
        data = _backend.fetch_streams(provider, "series", item_id, timeout_override=timeout_override)
    return data

def __getattr__(name):
    return getattr(_backend, name)
