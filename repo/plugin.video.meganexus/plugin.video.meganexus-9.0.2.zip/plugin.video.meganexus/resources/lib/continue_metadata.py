# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Enrich incomplete cloud progress without rewriting position or timestamps."""
from . import backend_api
import re


def metadata_identity(target):
    mt=str(target.get('media_type') or 'movie').lower()
    if mt in ('tv','tvshow','show','episode','anime'):mt='series'
    cid=str(target.get('imdb_id') or target.get('canonical_id') or target.get('video_id') or '').strip()
    if not cid and target.get('tmdb_id'):
        value=str(target['tmdb_id']);cid=value if value.startswith('tmdb:') else 'tmdb:'+value
    match=re.fullmatch(r'(tt\d+|tmdb:\d+)(?::\d+:\d+)?',cid)
    if match:cid=match.group(1)
    if cid.isdigit():cid='tmdb:'+cid
    return mt,cid


def _missing_title(value):
    return str(value or '').strip().lower() in ('unknown','untitled','','loading title…')

def _enrich_rows(rows):
    result=[]
    for original in rows:
        row=dict(original);target=dict(row.get('target') or {})
        mt,lookup=metadata_identity(target)
        if lookup:
            target.update(canonical_id=lookup,media_type=mt)
            row['target']=target
        # 8.1.3: progress from the cloud carries a percentage and nothing else - the
        # title's length comes from TMDB (kept 30 days), so the card can say how long is
        # left and when it would end, like one played here ("Fury: 5% watched", no time)
        if lookup and not row.get('remaining_seconds') and float(row.get('percent_value') or 0)>0:
            try:
                from . import tmdb_api
                from .home_data import continue_line
                found=tmdb_api.meta_of(tmdb_id=str(target.get('tmdb_id') or (lookup[5:] if lookup.startswith('tmdb:') else '')),
                                       imdb_id=str(target.get('imdb_id') or (lookup if lookup.startswith('tt') else '')),media_type=mt)
                minutes=int((found or {}).get('runtime') or 0)
                if minutes:
                    row['remaining_seconds']=int(minutes*60*(100-float(row['percent_value']))/100)
                    year=str((found or {}).get('year') or '')[:4]
                    row['meta_line']=continue_line(mt,row.get('subtitle') or '',row['remaining_seconds'],year)
            except Exception:
                pass
        # 7.0.42: a card without its description is completed too (Home shows it above
        # the row like every other card's; it came only for cards missing a poster / title)
        if row.get('poster') and not _missing_title(row.get('title')) and row.get('plot'):
            result.append(row);continue
        if lookup:
            try:
                meta=backend_api.metadata(mt,lookup)
                name=meta.get('name') or meta.get('title')
                if _missing_title(row.get('title')) and not _missing_title(name):row['title']=name
                row['poster']=row.get('poster') or meta.get('poster') or ''
                row['fanart']=row.get('fanart') or meta.get('background') or ''
                row['clearlogo']=row.get('clearlogo') or meta.get('logo') or meta.get('clearlogo') or ''
                row['plot']=meta.get('description') or meta.get('overview') or row.get('plot') or ''
                year=str(meta.get('year') or meta.get('releaseInfo') or '')[:4]
                # 8.1.2: the kind first, then the year - the same mark the title page
                # and every card on Home carry, so one title reads the same whichever
                # way it was reached (home_data, details). The episode stays after it.
                from .home_data import continue_line
                row['meta_line']=continue_line(mt,row.get('subtitle') or '',row.get('remaining_seconds') or 0,year)
                target.update(title=row.get('title') or '')
                row['target']=target
                key=row.get('progress_key')
                if isinstance(key,(list,tuple)) and len(key)==3:
                    from .meganexus.progress_db import update_metadata
                    update_metadata(*key,title='' if _missing_title(row.get('title')) else row['title'],
                                    poster=row['poster'],background=row['fanart'],clearlogo=row['clearlogo'],
                                    plot=row.get('plot') or '')
            except Exception:
                pass
        if _missing_title(row.get('title')):
            row['title']='Saved '+('episode' if mt=='series' else 'movie')+(' · '+lookup if lookup else '')
        result.append(row)
    return result

def _keys(row,network=False):
    """Every id a card is known by: its own, its IMDb id, and the IMDb id of a
    TMDB id (cached; fetched when ``network``) - the same film saved by Nuvio
    as tmdb:12153 and by MegaNexus as tt0381707 is one title (7.0.29)."""
    target=row.get('target') or {}
    kind,cid=metadata_identity(target)
    keys=set()
    if cid:keys.add((kind,cid))
    imdb=str(target.get('imdb_id') or '')
    if imdb.startswith('tt'):keys.add((kind,imdb.split(':')[0]))
    # 7.0.29: the TMDB / TVDB ids the card carries
    for column,prefix in (('tmdb_id','tmdb:'),('tvdb_id','tvdb:')):
        value=str(target.get(column) or '').strip()
        if value and value not in ('0','None'):keys.add((kind,value if value.startswith(prefix) else prefix+value))
    if cid.startswith('tmdb:'):
        try:
            from . import tmdb_api
            number=cid.split(':',1)[1]
            mt='movie' if kind=='movie' else 'tv'
            mapped=tmdb_api.imdb_of(number,mt) if network else (tmdb_api.kept('imdb_for:%s:%s'%(mt,number)) or '')
            if mapped:keys.add((kind,mapped))
        except Exception:pass
    return keys

def dedupe(rows,network=False):
    """7.0.24: one card per title. The same film or series can come twice
    (Nuvio and another app saving it under different IDs, or in another
    language); the newer card stays and takes the pictures the other one has."""
    result,seen=[],{}
    for row in rows:
        target=row.get('target') or {}
        title=str(row.get('title') or '').strip().casefold()
        if not target:
            result.append(row);continue
        kind='movie' if target.get('media_type')=='movie' else 'series'
        keys=_keys(row,network)
        if title and not _missing_title(title) and not title.startswith('saved '):keys.add((kind,'title:'+title))
        kept=next((seen[k] for k in keys if k in seen),None)
        if kept is None:
            result.append(row)
            for k in keys:seen[k]=row
            continue
        for art in ('poster','fanart','landscape','clearlogo'):
            if not kept.get(art) and row.get(art):kept[art]=row[art]
        for k in keys:seen.setdefault(k,kept)
    return result

UPDATE_EVERY = .4     # 8.1.2: s between reports to the screen while the rows fill


def enrich(rows,on_update=None,should_stop=lambda:False):
    from concurrent.futures import ThreadPoolExecutor,as_completed
    import time as _time
    result=[dict(r) for r in rows]
    pool=ThreadPoolExecutor(max_workers=2)
    tasks={pool.submit(_enrich_rows,[row]):i for i,row in enumerate(rows)}
    # 8.1.2: the screen hears from this a few times, not once per row. Forty-three rows
    # meant forty-three reports, and each one has the window take all forty-three cards
    # down and put them back - 10-25 ms a card on a CoreELEC box, while this is still
    # running. The rows still appear as they arrive; they arrive in handfuls.
    last=[0.0]
    def report(done=False):
        if not on_update:return
        now=_time.monotonic()
        if not done and now-last[0]<UPDATE_EVERY:return
        last[0]=now
        on_update(dedupe([dict(r) for r in result]))
    try:
        for task in as_completed(tasks):
            if should_stop():break
            result[tasks[task]]=task.result()[0]
            report()
        else:
            # Only when every row was done. After a stop the window is closing or has
            # moved on, and a report then paints a screen that is no longer there.
            report(done=True)   # the last handful is never left unsaid
    finally:
        # Kodi 21 on Windows still embeds Python 3.8 (no cancel_futures kwarg).
        for task in tasks:task.cancel()
        pool.shutdown(wait=False)
    return dedupe(result)
