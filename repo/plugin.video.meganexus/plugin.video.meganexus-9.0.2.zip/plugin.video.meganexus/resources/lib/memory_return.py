# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Give freed memory back to the system after MegaNexus closes (7.0.38).

Kodi's memory allocator keeps what was freed for later use. Measured on a
Fire TV Cube with MegaNexus open: Kodi 637 MB, of which 174 MB live data and
131 MB already freed but kept; one malloc_trim(0) returned 104 MB to the system
in 35 ms, the live data unchanged. Every visit left a little more kept memory,
so the box's used RAM grew visit by visit although nothing leaked.

The service does it a few seconds after the interface closed (AFTER_CLOSE)
or a video ended (AFTER_VIDEO) and once more AGAIN seconds later, never while
a video plays. glibc
(CoreELEC, LibreELEC, Linux): malloc_trim(0); Android: mallopt(M_PURGE).
Elsewhere (Windows, Apple) nothing is done.
"""
import ctypes
import time

AFTER_CLOSE = 6
AFTER_VIDEO = 10
AGAIN = 34          # 7.0.40: once more 40 s after closing - Python was still ending the
                    # interface at the first one (34 MB more came back on a Cube)
IDLE = 45           # 7.0.41: also while MegaNexus stays open - after this long without a key
IDLE_EVERY = 180    # and at most this often (a Cube kept 144 MB freed memory during
                    # a long visit: it came back only when MegaNexus closed)
M_PURGE = -101          # Android 10+ (bionic): release free pages


def _rss():
    try:
        with open('/proc/self/status') as status:
            for line in status:
                if line.startswith('VmRSS'):
                    return int(line.split()[1]) // 1024
    except OSError:
        pass
    return 0


def give_back(lib=None):
    """Return the allocator's free memory to the system: (MB returned, ms) or None."""
    try:
        lib = lib or ctypes.CDLL(None)
    except Exception:          # Windows has no process-wide C library handle
        return None
    before, start = _rss(), time.monotonic()
    try:
        if hasattr(lib, 'malloc_trim'):
            lib.malloc_trim(0)
        elif hasattr(lib, 'mallopt'):
            lib.mallopt(M_PURGE, 0)
        else:
            return None
    except Exception:
        return None
    return max(0, before - _rss()), int((time.monotonic() - start) * 1000)


def _add(times, *new):
    """Leaving and a video ending come seconds apart: one give-back serves both."""
    for when in new:
        if not any(abs(when - other) < 10 for other in times):
            times.append(when)
    return times


def run(monitor, frontend_open, video_playing, log=None, step=2, idle=lambda: False):
    """Service loop: after the interface closed or a video ended, twice; while it
    stays open, when the remote rests (``idle()``: no key for IDLE seconds)."""
    was_open = was_video = False
    times = []
    last = 0.
    while not monitor.waitForAbort(step):
        try:
            is_open, is_video = bool(frontend_open()), bool(video_playing())
        except Exception:
            continue
        now = time.monotonic()
        if was_open and not is_open:
            times = _add(times, now + AFTER_CLOSE, now + AFTER_CLOSE + AGAIN)
        if was_video and not is_video:
            times = _add(times, now + AFTER_VIDEO, now + AFTER_VIDEO + AGAIN)
        was_open, was_video = is_open, is_video
        times.sort()
        resting = is_open and not is_video and now - last >= IDLE_EVERY and idle()
        if (times and now >= times[0] and not is_video) or resting:
            times = [when for when in times if when > now]
            last = now
            result = give_back()
            if result and log:
                log('[MegaNexus] Memory given back to the system: %d MB (%d ms)' % result)
