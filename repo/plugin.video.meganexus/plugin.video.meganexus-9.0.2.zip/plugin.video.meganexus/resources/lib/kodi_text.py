# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Text with emoji for Kodi's labels (8.1.0).

Kodi keeps 16 bits of each character it draws, so an emoji above U+FFFF (😀 👍 🔥 - most of
them) never reached a font and showed nothing. The chat font (skin.meganexus MNChat.ttf,
review/make_chat_font.py) has each of those emoji at a Private Use code as well
(resources/emoji_pua.json); a label drawn with that font gets those codes. Skin tones,
families and flags still join: the font's rules work on its glyphs, not on the codes.
"""
import json
import os

_MAP = None


def _table():
    global _MAP
    if _MAP is None:
        try:
            path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'emoji_pua.json')
            with open(path, encoding='utf-8') as handle:
                _MAP = {int(k, 16): chr(int(v, 16)) for k, v in json.load(handle).items()}
        except (OSError, ValueError):
            _MAP = {}
    return _MAP


def for_kodi(text):
    """``text`` for a label in the chat font: emoji above U+FFFF at their Private Use codes;
    one the font does not have is left out (Kodi would draw a wrong character)."""
    text = str(text or '')
    if not any(ord(char) > 0xFFFF for char in text):
        return text
    table = _table()
    return ''.join(table.get(ord(char), '') if ord(char) > 0xFFFF else char for char in text)
