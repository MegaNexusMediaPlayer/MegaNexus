# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""QR sign-in, now part of "Set up on phone" (6.0.22).

The 6.0.7 pairing page only linked an account, and its server code was lost in
the 6.0.10 import. The backend route ``meganexus_qr_login`` keeps working: it opens
the phone setup service of the interface (resources.lib.phone_setup), whose
Account tab signs in to Nuvio.
"""
import xbmc


def qr_pair(service):
    """Open phone setup. Only Nuvio accounts are supported there."""
    if service != 'nuvio':
        return False
    xbmc.executebuiltin('RunScript(script.meganexus,phone)')
    return True
