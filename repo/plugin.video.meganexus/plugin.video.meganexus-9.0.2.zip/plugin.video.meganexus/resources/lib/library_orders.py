# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import os
import threading

from .meganexus.paths import profile_path
from .meganexus.json_files import read_json, write_json

_LOCK = threading.RLock()
_MEM = None
_STAMP = None


def store_path():
    return os.path.join(profile_path(), 'sort_prefs.json')


def _stamp(path):
    try:
        st = os.stat(path)
        return (st.st_mtime, st.st_size)
    except Exception:
        return None


def _load():
    global _MEM, _STAMP
    with _LOCK:
        path = store_path()
        stamp = _stamp(path)
        if _MEM is not None and stamp == _STAMP:
            return _MEM
        try:
            data = read_json(path, {})
        except Exception:
            data = {}
        _MEM = data if isinstance(data, dict) else {}
        _STAMP = stamp
        return _MEM


def _key(backend, server_id, library_key):
    return '%s|%s|%s' % (backend or '', server_id or '', library_key or '')


def sort_of(backend, server_id, library_key, default=''):
    try:
        value = _load().get(_key(backend, server_id, library_key))
    except Exception:
        value = None
    return value if isinstance(value, str) and value else default


def keep_sort(backend, server_id, library_key, sort_value):
    global _MEM, _STAMP
    with _LOCK:
        path = store_path()
        data = dict(_load())
        key = _key(backend, server_id, library_key)
        if sort_value:
            data[key] = sort_value
        else:
            data.pop(key, None)
        try:
            write_json(path, data)
        except Exception:
            pass
        _MEM = data
        _STAMP = _stamp(path)
    return sort_value


