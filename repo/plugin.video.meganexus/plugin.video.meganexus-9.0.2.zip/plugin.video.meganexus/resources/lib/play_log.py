# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The playback log: one JSON line per playback event, in Kodi's log ([MegaNexusMonitor]) and in
a small file of its own (cut to its last 128 KiB once it passes 256 KiB)."""
import json
import os
import time

import xbmc

MOST, KEEP = 262144, 131072


def record(event, payload, safe, whole=(dict, list)):
    """The event's record: its fields without the empty ones, texts made log-safe (`whole` kinds kept as they are)."""
    out = {'event': str(event or ''), 'ts': int(time.time())}
    for key, value in dict(payload or {}).items():
        if value in (None, '', [], {}, ()):
            continue
        try:
            out[key] = value if isinstance(value, whole) else safe(value)
        except Exception:
            continue
    return out


def _append(path, line):
    folder = os.path.dirname(path)
    if folder and not os.path.exists(folder):
        os.makedirs(folder, exist_ok=True)
    try:
        if os.path.exists(path) and os.path.getsize(path) > MOST:
            with open(path, 'rb') as handle:
                tail = handle.read()[-KEEP:]
            with open(path, 'wb') as handle:
                handle.write(tail)
    except Exception:
        pass
    with open(path, 'a', encoding='utf-8') as handle:
        handle.write(line + '\n')


def write(entry, level, path):
    """Put the record in Kodi's log and the playback log file (never raises)."""
    line = json.dumps(entry, ensure_ascii=False, sort_keys=True)
    try:
        xbmc.log('[MegaNexusMonitor] %s' % line, level)
    except Exception:
        pass
    try:
        if path:
            _append(path, line)
    except Exception:
        pass
