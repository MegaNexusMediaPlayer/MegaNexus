# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import urllib.error
import urllib.parse
import urllib.request

import xbmcaddon

from .hub_log import log
from .meganexus.net.transport import slow_down, wait_turn

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    try:
        from settings_snapshot import cached_addon as _cached_addon
    except Exception:
        _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

_IMG_BASE = 'https://image.tmdb.org/t/p'


def _get(url, timeout=8):
    """TMDB's JSON answer, or None (a 429 slows the next asks down)."""
    wait_turn(url, max_wait=2.0)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'MegaNexus/3.9'}), timeout=timeout) as reply:
            return json.loads(reply.read().decode('utf-8', errors='replace')) if reply.status < 400 else None
    except urllib.error.HTTPError as refused:
        if refused.code == 429:
            slow_down(url, capacity=8, rate=2.0)
        log.warn('PEOPLE', 'http %s for %s', refused.code, url)
    except Exception as exc:
        log.warn('PEOPLE', 'fetch failed %s: %s', url, exc)
    return None


def poster_url(path, size='w342'):
    """A TMDB picture path as its address (a full address stays as it is)."""
    path = str(path or '')
    return path if not path or path.startswith('http') else '%s/%s%s' % (_IMG_BASE, size, path)


