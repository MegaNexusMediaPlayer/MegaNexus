# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import os
import shutil
from functools import lru_cache

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .texts import tr

TMDBH_ID = 'plugin.video.themoviedb.helper'
ADDON_ID = 'plugin.video.meganexus'
PLAYER_FILENAME = 'meganexus.json'
_STALE_PLAYER_PREFIXES = ('meganexus', 'plugin.video.meganexus')


def _addon():
    return xbmcaddon.Addon('plugin.video.meganexus')


def _bundled_player_path():
    """Our TMDb Helper player file, as shipped in the add-on."""
    return os.path.join(_addon().getAddonInfo('path'), 'resources', 'players', PLAYER_FILENAME)


def _tmdbh_players_dir():
    """Where TMDb Helper looks for player files."""
    return xbmcvfs.translatePath('special://profile/addon_data/%s/players/' % TMDBH_ID)


def _read_player_text(path):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return fh.read()
    except Exception:
        return ''


def _is_meganexus_player_file(folder, filename):
    lower = str(filename or '').strip().lower()
    if not lower.endswith('.json'):
        return False
    if lower == PLAYER_FILENAME or any(lower.startswith(prefix) for prefix in _STALE_PLAYER_PREFIXES):
        return True
    raw = _read_player_text(os.path.join(folder, filename))
    if not raw:
        return False
    try:
        import json
        data = json.loads(raw)
        return str(data.get('plugin') or '').strip() == ADDON_ID
    except Exception:
        return ADDON_ID in raw


def _stale_player_files():
    folder = _tmdbh_players_dir()
    try:
        names = os.listdir(folder)
    except Exception:
        return []
    return [name for name in names if _is_meganexus_player_file(folder, name)]


def _drop_old_player_files():
    folder = _tmdbh_players_dir()
    removed = []
    for name in _stale_player_files():
        try:
            os.remove(os.path.join(folder, name))
            removed.append(name)
        except FileNotFoundError:
            continue
        except Exception as exc:
            xbmc.log('[MegaNexus] stale TMDbH player cleanup failed for %s: %s' % (name, exc), xbmc.LOGWARNING)
    if removed:
        xbmc.log('[MegaNexus] removed stale TMDb Helper player file(s): %s' % ', '.join(removed), xbmc.LOGINFO)
    return removed


@lru_cache(maxsize=1)
def has_tmdbhelper():
    try:
        return bool(xbmc.getCondVisibility('System.HasAddon(%s)' % TMDBH_ID))
    except Exception:
        return False


def player_installed():
    target = os.path.join(_tmdbh_players_dir(), PLAYER_FILENAME)
    try:
        return os.path.exists(target)
    except Exception:
        return False


def install(silent=False):
    if not has_tmdbhelper():
        if not silent:
            xbmcgui.Dialog().notification(
                'MegaNexus',
                tr('TMDb Helper is not installed'),
                xbmcgui.NOTIFICATION_WARNING,
                3500,
            )
        return False

    src = _bundled_player_path()
    if not os.path.exists(src):
        if not silent:
            xbmcgui.Dialog().notification(
                'MegaNexus',
                tr('The player file is missing inside the addon'),
                xbmcgui.NOTIFICATION_ERROR,
                3500,
            )
        xbmc.log('[MegaNexus] tmdbh player source missing: %s' % src, xbmc.LOGERROR)
        return False

    dst_dir = _tmdbh_players_dir()
    try:
        if not os.path.exists(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
    except Exception as exc:
        xbmc.log('[MegaNexus] tmdbh players dir create failed: %s' % exc, xbmc.LOGERROR)
        if not silent:
            xbmcgui.Dialog().notification(
                'MegaNexus',
                tr('Could not create the TMDb Helper players folder'),
                xbmcgui.NOTIFICATION_ERROR,
                3500,
            )
        return False

    dst = os.path.join(dst_dir, PLAYER_FILENAME)
    _drop_old_player_files()
    try:
        shutil.copyfile(src, dst)
    except Exception as exc:
        xbmc.log('[MegaNexus] tmdbh player copy failed: %s' % exc, xbmc.LOGERROR)
        if not silent:
            xbmcgui.Dialog().notification(
                'MegaNexus',
                tr('Could not copy the player file'),
                xbmcgui.NOTIFICATION_ERROR,
                3500,
            )
        return False

    xbmc.log('[MegaNexus] registered as TMDb Helper player at %s' % dst, xbmc.LOGINFO)
    if not silent:
        xbmcgui.Dialog().notification(
            'MegaNexus',
            tr('MegaNexus was registered as a TMDb Helper player'),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )
    return True


def uninstall(silent=False):
    dst = os.path.join(_tmdbh_players_dir(), PLAYER_FILENAME)
    try:
        if os.path.exists(dst):
            os.remove(dst)
            if not silent:
                xbmcgui.Dialog().notification(
                    'MegaNexus',
                    tr('MegaNexus was removed from TMDb Helper'),
                    xbmcgui.NOTIFICATION_INFO,
                    2500,
                )
            return True
    except Exception as exc:
        xbmc.log('[MegaNexus] tmdbh player uninstall failed: %s' % exc, xbmc.LOGWARNING)
    return False


def install_once():
    if not has_tmdbhelper():
        return False
    src = _bundled_player_path()
    dst = os.path.join(_tmdbh_players_dir(), PLAYER_FILENAME)
    try:
        if os.path.exists(src) and os.path.exists(dst):
            try:
                with open(src, 'rb') as fh:
                    src_bytes = fh.read()
                with open(dst, 'rb') as fh:
                    dst_bytes = fh.read()
                if src_bytes == dst_bytes and _stale_player_files() == [PLAYER_FILENAME]:
                    return True
            except Exception:
                pass
    except Exception:
        pass
    return install(silent=True)
