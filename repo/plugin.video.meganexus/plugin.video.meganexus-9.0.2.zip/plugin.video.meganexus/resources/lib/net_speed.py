# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The network's speed for the stream choice (7.0.42).

With "No limit" for the file size, Autoplay and the source list put first the
best link whose bitrate fits SHARE of the measured speed - the rest of the
home network keeps the other 20 % (streaming services lower their quality the
same way; here the link is chosen instead). Links above it are not hidden,
they only move down. The service measures once an hour while nothing plays: a
download of at most MAX_BYTES or SECONDS from a public speed-test server,
kept in the add-on profile (net-speed.json).
"""
import json
import os
import time
from pathlib import Path

SETTING = 'stream_bandwidth_auto'      # default on
SHARE = 0.8
URL = 'https://speed.cloudflare.com/__down?bytes=%d'
UP_URL = 'https://speed.cloudflare.com/__up'     # 7.0.42: the upload too, for the diagnostics overlay
UP_BYTES = 2 * 1000 * 1000
MAX_BYTES = 25 * 1000 * 1000
SECONDS = 4.0
EVERY = 3600
FILE = 'net-speed.json'
RUNTIME = {'movie': 120 * 60, 'episode': 45 * 60}    # when a title's runtime is not known


def measure(opener=None, clock=time.monotonic):
    """Mbit/s of one download (None when it failed)."""
    from urllib.request import Request, urlopen
    opener = opener or (lambda url: urlopen(Request(url, headers={'User-Agent': 'MegaNexus/7'}), timeout=10))
    start, got = clock(), 0
    try:
        with opener(URL % MAX_BYTES) as response:
            while got < MAX_BYTES and clock() - start < SECONDS:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                got += len(chunk)
    except Exception:
        if got < 1000000:
            return None
    seconds = max(clock() - start, 0.05)
    return round(got * 8 / seconds / 1e6, 1) if got >= 1000000 else None


def measure_up(opener=None, clock=time.monotonic):
    """Mbit/s of one upload of UP_BYTES (None when it failed)."""
    from urllib.request import Request, urlopen
    opener = opener or (lambda request: urlopen(request, timeout=20))
    body = b'0' * UP_BYTES
    start = clock()
    try:
        with opener(Request(UP_URL, data=body, method='POST',
                            headers={'User-Agent': 'MegaNexus/7', 'Content-Type': 'application/octet-stream'})) as response:
            response.read(1024)
    except Exception:
        return None
    seconds = max(clock() - start, 0.05)
    return round(len(body) * 8 / seconds / 1e6, 1)


def save(folder, mbps, now=None, up=None):
    path = Path(folder) / FILE
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps({'mbps': mbps, 'up': up, 'at': now or time.time()}), encoding='utf-8')
    os.replace(temp, path)


def last(folder):
    """{'mbps', 'up', 'at'} of the last measurement (any age), or {}."""
    try:
        data = json.loads((Path(folder) / FILE).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def load(folder, max_age=3 * EVERY, now=None):
    """The last measured Mbit/s, or None when there is none or it is old."""
    try:
        data = json.loads((Path(folder) / FILE).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    if (now or time.time()) - float(data.get('at') or 0) > max_age:
        return None
    try:
        return float(data.get('mbps')) or None
    except (TypeError, ValueError):
        return None


def bitrate_limit(mbps):
    """Bits per second a stream may use."""
    return mbps * 1e6 * SHARE if mbps else 0


def run(monitor, busy, folder, log=None, first_wait=120):
    """Service loop: measure at start (after first_wait) and every EVERY seconds, never while busy()."""
    if monitor.waitForAbort(first_wait):
        return
    while not monitor.abortRequested():
        if not busy():
            mbps = measure()
            if mbps:
                up = measure_up()
                save(folder, mbps, up=up)
                if log:
                    log('[MegaNexus] Network speed: %.1f Mbit/s down%s - streams up to %.1f Mbit/s'
                        % (mbps, ', %.1f Mbit/s up' % up if up else '', mbps * SHARE))
            if monitor.waitForAbort(EVERY):
                return
        elif monitor.waitForAbort(60):
            return
