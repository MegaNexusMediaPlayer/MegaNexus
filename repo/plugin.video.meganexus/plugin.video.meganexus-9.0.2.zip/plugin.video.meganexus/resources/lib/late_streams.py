# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Sources of add-ons that answered too late (7.0.43).

Autoplay waits STREAM_GRACE after the first add-on's answer and the source list
up to SLOW_TIMEOUT; an add-on that answers later (Usenet Streamer searching its
indexers and checking NZBs, any slow server) is not waited for. Its answer still
arrives in the background and is kept here for LATE_TTL, so the next search of
the same title or episode has its sources at once - also for Autoplay. Nothing
here is per add-on. Kept in the profile (late_streams.json), at most KEEP answers.
"""
import json
import os
import threading
import time

LATE_TTL = 30 * 60
KEEP = 24
MAX_ROWS = 300
_LOCK = threading.Lock()
_MEM = {}


def _path():
    try:
        from .meganexus.paths import profile_path
        return os.path.join(profile_path(), 'late_streams.json')
    except Exception:
        return ''


def _load():
    if _MEM.get('loaded'):
        return _MEM['data']
    data = {}
    path = _path()
    try:
        if path and os.path.isfile(path):
            with open(path, encoding='utf-8') as handle:
                data = json.load(handle) or {}
    except Exception:
        data = {}
    _MEM.update(loaded=True, data=data)
    return data


def _key(source_id, media_type, video_id):
    return '%s|%s|%s' % (source_id, media_type, video_id)


def put(source_id, media_type, video_id, rows):
    """An add-on's late answer (rows already carry their origin)."""
    if not isinstance(rows, list):
        return
    with _LOCK:
        data = _load()
        data[_key(source_id, media_type, video_id)] = {'at': time.time(), 'rows': rows[:MAX_ROWS]}
        now = time.time()
        fresh = sorted(((k, v) for k, v in data.items() if now - v.get('at', 0) < LATE_TTL),
                       key=lambda pair: pair[1]['at'], reverse=True)[:KEEP]
        data.clear()
        data.update(fresh)
        path = _path()
        if path:
            try:
                temp = path + '.tmp'
                with open(temp, 'w', encoding='utf-8') as handle:
                    json.dump(data, handle)
                os.replace(temp, path)
            except Exception:
                pass


def get(source_id, media_type, video_id):
    """The kept rows, or None."""
    with _LOCK:
        entry = _load().get(_key(source_id, media_type, video_id))
    if not entry or time.time() - entry.get('at', 0) >= LATE_TTL:
        return None
    return entry.get('rows')
