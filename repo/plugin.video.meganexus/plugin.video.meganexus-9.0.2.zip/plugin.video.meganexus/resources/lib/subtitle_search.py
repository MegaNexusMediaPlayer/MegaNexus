# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Subtitles from the user's Stremio subtitle add-ons.

`search` asks every add-on switched on as a subtitle source at once (the subtitles lane,
three at a time), each with the item's ids until one answers, all under one deadline
(`subtitle_timeout`, 10-20 s, or the shared deadline of the start). Most add-ons answer
IMDb ids only (manifest idPrefixes ["tt"]), so a title known by its TMDB id gets its IMDb
id first. The answers are merged with the stream's own subtitles, made unique by address
and language and ordered by the user's languages; an add-on search is kept 10 minutes.

A subtitle the stream or the user already chose ends the search at once: the deadline is a
ceiling for finding one, never a wait before playback."""
import re
import threading
import time
from urllib.parse import unquote, urlparse

import xbmc
import xbmcaddon

from .meganexus import addon_registry
from .meganexus.addon_wire import fetch_subtitles, begin_race, offers

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

SERIES_TYPES = ('series', 'episode', 'show', 'tv', 'anime')
CHOSEN_KINDS = ('manual', 'stream', 'native', 'embedded', 'external')
ADDONS_AT_ONCE = 3              # leaves room for the stream scan running beside it on small boxes
IDS_ASKED = 5
KEPT_SEARCHES = 64
KEPT_FOR = 600
SUBTITLE_FILES = ('.srt', '.vtt', '.ass', '.ssa', '.sub', '.sbv', '.idx', '.zip', '.gz', '.7z')

LANGUAGE_FIELDS = ('lang', 'language', 'languageCode', 'iso639', 'code', 'name')
# Codes and names add-ons use for a language -> its short code.
LANGUAGES = dict((word, code) for code, words in (
    ('hr', 'hrv cro croatian hrvatski'), ('sr', 'srp ser serbian'), ('bs', 'bos bosnian'),
    ('sl', 'slv slovenian'), ('en', 'eng english'), ('fr', 'fre fra french'),
    ('es', 'spa spanish'), ('de', 'ger deu german'), ('pt', 'por'), ('pt-br', 'pob pb brazilian'),
    ('tr', 'tur turkish'), ('ru', 'rus russian'), ('ja', 'jpn japanese'), ('ko', 'kor korean'),
    ('zh', 'chi zho chinese'), ('hi', 'hin hindi'), ('fa', 'fas per persian farsi'),
) for word in words.split())


def _wait():
    try:
        return max(10, min(20, int(ADDON.getSetting('subtitle_timeout') or '15')))
    except Exception:
        return 15


def enabled():
    """The search is on with its own switch, or when the subtitle mode is "Play with subtitles"."""
    try:
        if (ADDON.getSetting('enable_stremio_subtitle_broker') or 'true').lower() == 'true':
            return True
        try:
            mode = (ADDON.getSetting('subtitle_search_mode') or '').strip().lower()
        except Exception:
            return False
        return 'subtitle' in mode or 'with sub' in mode
    except Exception:
        return False


def language_code(value):
    """'hr', 'pt-br', … for a code, a name, a list of them or a language object; 'und' unknown."""
    if isinstance(value, (list, tuple, set)):
        return next((code for code in map(language_code, value) if code and code != 'und'), 'und')
    if isinstance(value, dict):
        return next((code for code in (language_code(value.get(field)) for field in LANGUAGE_FIELDS
                                       if value.get(field)) if code and code != 'und'), 'und')
    try:
        known = (xbmc.convertLanguage(str(value or ''), xbmc.ISO_639_1)
                 or xbmc.convertLanguage(str(value or ''), xbmc.ISO_639_2))
        if known:
            return known.lower()
    except Exception:
        pass
    text = str(value or 'und').strip().lower().replace('_', '-').replace(' ', '-')
    if not text:
        return 'und'
    return LANGUAGES.get(text, LANGUAGES.get(text.split('-')[0], text))


def title_from_address(url):
    """The release name in a subtitle's file name ("Top.Gun.Maverick.2022.hr"), for add-ons
    that give only an address; a bare hash or id gives ''."""
    try:
        name = unquote((urlparse(str(url)).path or '').rsplit('/', 1)[-1]) if url else ''
    except Exception:
        return ''
    for ending in SUBTITLE_FILES:
        if name.lower().endswith(ending):
            name = name[:-len(ending)]
            break
    return name.strip() if any(mark in name for mark in '. -_') else ''


def _first(row, fields):
    return next((row.get(field) for field in fields if row.get(field)), None)


def as_subtitle(row):
    """An add-on's subtitle (an object or a bare address) with url, lang, sourceName,
    sourceType and displayName filled in; None without an address."""
    if not row:
        return None
    if isinstance(row, str):
        return {'id': row, 'url': row, 'lang': 'und'}
    if not isinstance(row, dict):
        return None
    url = _first(row, ('url', 'externalUrl', 'key'))
    if not url:
        return None
    out = dict(row, url=url, lang=language_code(_first(row, ('lang', 'language', 'languageCode', 'iso639')) or 'und'))
    source = _first(row, ('sourceName', 'providerName', 'provider', 'addonName', 'addon', 'sourceAddon', 'source'))
    if source:
        out['sourceName'] = source
    kind = _first(row, ('sourceType', 'origin'))
    if kind:
        out['sourceType'] = str(kind)
    title = _first(row, ('displayName', 'label', 'title', 'name', 'release', 'filename', 'fileName')) \
        or title_from_address(url)
    if title:
        out['displayName'] = str(title)
    return out


def unique(rows):
    """Usable subtitles once each (by address and language), first one kept."""
    out, seen = [], set()
    for row in map(as_subtitle, rows):
        mark = (row.get('url') or '', row.get('lang') or 'und') if row else None
        if mark and mark not in seen:
            seen.add(mark)
            out.append(row)
    return out


def _imdb_in(value):
    text = str(value or '').strip().lower()
    found = re.search(r'\btt\d{5,10}\b', text.split(':', 1)[1] if text.startswith('imdb:') else text, re.I)
    return found.group(0).lower() if found else ''


def _number_id(value, kind):
    text = str(value or '').strip().lower()
    if text.startswith(kind + ':'):
        text = text.split(':', 1)[1]
    text = text.split(':', 1)[0]          # an episode suffix is never copied
    return text if text.isdigit() else ''


def lookup_ids(ctx):
    """The ids a subtitle add-on is asked with: tt…, tmdb:…, tvdb:… (episodes ":S:E" once);
    never "imdb:tt…" and never a doubled suffix. An episode without season and number: []."""
    found = {'imdb': _imdb_in(ctx.get('imdb_id')), 'tmdb': _number_id(ctx.get('tmdb_id'), 'tmdb'),
             'tvdb': _number_id(ctx.get('tvdb_id'), 'tvdb')}
    for field in ('canonical_id', 'video_id'):
        other = str(ctx.get(field) or '').strip()
        found['imdb'] = found['imdb'] or _imdb_in(other)
        for kind in ('tmdb', 'tvdb'):
            if not found[kind] and other.lower().startswith(kind + ':'):
                found[kind] = _number_id(other, kind)
    episode = str(ctx.get('media_type') or '').lower() in SERIES_TYPES
    suffix = ''
    if episode:
        try:
            season, number = int(ctx.get('season')), int(ctx.get('episode'))
        except Exception:
            return []
        if season < 0 or number < 0:
            return []
        suffix = ':%d:%d' % (season, number)
    ids = []
    for kind in ('imdb', 'tmdb', 'tvdb'):
        if found[kind]:
            item = (found[kind] if kind == 'imdb' else '%s:%s' % (kind, found[kind])) + suffix
            if item not in ids:
                ids.append(item)
    whole = absolute_episode(ctx) if episode else 0
    if whole and found['imdb'] and suffix != ':1:%d' % whole:
        ids.append('%s:1:%d' % (found['imdb'], whole))
    return ids


def absolute_episode(ctx):
    """8.1.5: the episode's number counted from the first (an anime from Kitsu: kitsu:<id>:<n>).
    OpenSubtitles keeps long anime as one season - Naruto's S5E7 is its S1E186."""
    try:
        known = int(ctx.get('absolute_episode') or 0)     # from the title's episode list
    except (TypeError, ValueError):
        known = 0
    if known > 0:
        return known
    parts = str(ctx.get('video_id') or '').strip().lower().split(':')
    if len(parts) == 3 and parts[0] == 'kitsu' and parts[2].isdigit():
        return int(parts[2])
    return 0


def imdb_for(ctx, timeout_seconds=None):
    """The IMDb id from the item's TMDB id (TMDB lookups are kept, a repeat costs nothing); ''."""
    tmdb_id = str((ctx or {}).get('tmdb_id') or '').strip()
    if not tmdb_id:
        canonical = str((ctx or {}).get('canonical_id') or '').strip().lower()
        if canonical.startswith('tmdb:'):
            tmdb_id = canonical.split(':', 1)[1].split(':', 1)[0]
    if not tmdb_id:
        return ''
    kind = 'series' if str((ctx or {}).get('media_type') or 'movie').lower() in SERIES_TYPES else 'movie'
    try:
        from . import tmdb_api
        extra = {} if timeout_seconds in (None, '') else {'timeout': max(1.0, float(timeout_seconds))}
        return str(tmdb_api.imdb_of(tmdb_id, media_type=kind, **extra) or '').strip()
    except Exception:
        return ''


def addons_for(ctx):
    """The add-ons switched on as subtitle sources, the stream's own add-on first."""
    addons = list(addon_registry.list_providers())
    try:
        from .subtitle_providers import enabled_ids
        allowed = enabled_ids(addons)
        addons = [addon for addon in addons if addon.get('id') in allowed]
    except Exception:
        pass
    own = str(ctx.get('provider_id') or '').strip()
    if not own:
        return addons
    return [addon for addon in addons if addon.get('id') == own] + [addon for addon in addons if addon.get('id') != own]


def wanted_languages():
    chosen = (ADDON.getSetting('preferred_subtitle_langs') or 'en').strip()
    return [part.strip().lower() for part in chosen.split(',') if part.strip()] if chosen else ['en']


def _language_place(lang, wanted):
    lang = (lang or 'und').strip().lower().replace('_', '-')
    short = lang.split('-')[0]              # rows come with language_code's codes
    return wanted.index(short) if short in wanted else 999 + len(short)


def ordered(rows):
    """The user's languages first (in their order); within one, the stream's own subtitles,
    then the add-ons by name."""
    wanted = wanted_languages()
    from .video_hash import matched
    return sorted(rows, key=lambda row: (_language_place(row.get('lang'), wanted),
                                         0 if row.get('sourceType') == 'stream' else 1,
                                         0 if matched(row) else 1,           # 8.1.5: made for this very file
                                         str(row.get('sourceName') or row.get('providerName') or 'zzz').lower()))


_kept = {}      # (type, id, season, episode) -> (until, subtitles), oldest first


def _recent(key):
    entry = _kept.get(key)
    if not entry:
        return None
    if entry[0] < time.monotonic():
        _kept.pop(key, None)
        return None
    return entry[1]


def _remember(key, rows):
    _kept[key] = (time.monotonic() + KEPT_FOR, rows)
    while len(_kept) > KEPT_SEARCHES:
        _kept.pop(next(iter(_kept)))


def _ask_addon(addon, ids, media_type, deadline, wait, extra=None):
    """One add-on's subtitles for the first id it answers (its other ids mostly repeat them).
    8.1.5: each id also with the file's hash (an add-on that knows it marks the subtitles
    made for this file), and the count-from-first id of a long anime (absolute_episode) -
    all of them side by side, never one after the other: a slow add-on took twice as long."""
    whole = ids[-1] if len(ids) > 1 and ids[-1].count(':') == 2 and ids[-1].split(':')[1] == '1' else ''

    def one(item_id, asked):
        try:
            if not offers(addon, 'subtitles', media_type=media_type, item_id=item_id):
                return []
            answer = fetch_subtitles(addon, media_type, item_id,
                                     timeout_seconds=max(1, min(deadline - time.monotonic(), wait)),
                                     **({'extra': asked} if asked else {}))
        except Exception as exc:
            xbmc.log('[MegaNexus] subtitle broker: %s %s%s: %s' % (addon.get('name'), item_id,
                     ' (hash)' if asked else '', str(exc)[:80]), xbmc.LOGINFO)
            return []
        if isinstance(answer, dict):
            return answer.get('subtitles') or answer.get('subs') or []
        return answer if isinstance(answer, list) else []

    def side_by_side(asks):
        """[found] of each (id, extra) ask, in that order, whatever came within the deadline."""
        out = [[] for _ in asks]

        def run(i, ask):
            out[i] = one(*ask)
        helpers = [threading.Thread(target=run, args=(i, ask), name='MegaNexusSubAsk', daemon=True)
                   for i, ask in enumerate(asks[1:], 1)]
        for helper in helpers:
            helper.start()
        run(0, asks[0])
        for helper in helpers:
            helper.join(max(0.0, deadline - time.monotonic()))
        return out

    found = []
    for item_id in [i for i in ids if i != whole]:
        if time.monotonic() >= deadline:
            break
        asks = [(item_id, None)] + ([(item_id, extra)] if extra else [])
        if whole and not found:
            asks += [(whole, None)] + ([(whole, extra)] if extra else [])
        answers = side_by_side(asks)
        hashed = [rows for (_, asked), rows in zip(asks, answers) if asked]
        plain = [rows for (_, asked), rows in zip(asks, answers) if not asked]
        for rows in hashed + plain:              # made for this file first
            found.extend(rows)
        if any(answers[:2]):
            break                                # this id answered; the others repeat it
        whole = ''                               # asked once
    out = []
    for sub in found:
        row = dict(sub) if isinstance(sub, dict) else {'url': sub, 'id': sub, 'lang': 'und'}
        row.setdefault('sourceType', 'addon')
        row.setdefault('sourceName', addon.get('name') or addon.get('id') or 'Subtitle addon')
        out.append(row)
    return out


def search(ctx, initial_subtitles=None, max_results=12, fresh=False, enough=None):
    """The stream's subtitles plus every subtitle add-on's, best first. `fresh` asks the
    add-ons again (Autosync); `enough(rows)` ends the wait once the start has what it needs
    (that cut-short answer is not kept)."""
    rows = unique(initial_subtitles or [])
    done = lambda: ordered(rows)[:max_results]
    if not fresh and not enabled() and not ctx.get('meganexus_subtitle_language'):
        return done()
    if any((row or {}).get('user_selected') or str((row or {}).get('sourceType') or '').lower() in CHOSEN_KINDS
           for row in rows):
        return done()
    media_type = str(ctx.get('media_type') or 'movie').strip().lower() or 'movie'
    key = (media_type, str(ctx.get('canonical_id') or ''), str(ctx.get('season') or ''), str(ctx.get('episode') or ''))
    if key[1] and not fresh:
        recent = _recent(key)
        if recent is not None:
            return ordered(unique(rows + recent))[:max_results]

    wait = float(_wait())
    deadline = time.monotonic() + wait
    try:
        shared = float(ctx.get('subtitle_deadline_mono') or 0.0)   # the start's deadline, set with the stream scan
        if shared > 0.0:
            deadline = min(deadline, shared)
    except Exception:
        pass

    ids = lookup_ids(ctx)
    if not ids or not any(item.startswith('tt') for item in ids):
        budget = max(0.0, deadline - time.monotonic())
        imdb = imdb_for(ctx, timeout_seconds=budget) if budget >= 1.0 else ''
        if imdb:
            ctx = dict(ctx, imdb_id=imdb)
            ids = lookup_ids(ctx)
    if not ids:
        return done()
    ids = ids[:IDS_ASKED]
    addons = list(addons_for(ctx))
    if not addons:
        return done()
    left = max(0.0, deadline - time.monotonic())
    if left <= 0.0:
        return done()

    fetched, cut_short = [], False
    # 8.1.5: the file's own hash, as Stremio sends it - the OpenSubtitles add-on then marks
    # a subtitle found by this very file (m: "h"), made for exactly this release
    extra = None
    from .video_hash import compute
    room = deadline - time.monotonic()
    found_hash = compute(ctx.get('stream_url'), ctx.get('request_headers'), timeout=min(4.0, room / 3)) if room > 1.5 else None
    if found_hash:
        extra = {'videoHash': found_hash[0], 'videoSize': found_hash[1]}
    race = begin_race(lambda addon: _ask_addon(addon, ids, media_type, deadline, wait, extra), addons,
                               workers=max(1, min(len(addons), ADDONS_AT_ONCE)), timeout=max(0.1, left),
                               lane='subtitles')
    try:
        while not race.done:
            for _addon, found in race.poll(0.05):
                if found and not isinstance(found, Exception):
                    rows.extend(found)
                    fetched.extend(found)
            if enough is not None and not race.done and enough(rows):
                cut_short = True
                break
    finally:
        race.cancel()
    if key[1] and fetched and not cut_short:
        _remember(key, unique(fetched))
    result = ordered(unique(rows))[:max_results]
    xbmc.log('[MegaNexus] Stremio subtitle broker: %d addon(s), %d result(s), %.1fs budget%s'
             % (len(addons), len(result), wait, ' (hash too)' if extra else ''), xbmc.LOGINFO)
    return result
