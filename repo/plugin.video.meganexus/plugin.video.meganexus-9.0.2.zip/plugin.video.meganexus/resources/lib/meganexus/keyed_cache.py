# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import os
import sqlite3
import threading
import time
import uuid

from .paths import profile_path

DB_PATH = os.path.join(profile_path(), 'cache.db')

from collections import OrderedDict
_MEM = OrderedDict()          # 'kind:key' -> payload, the newest last
_MEM_MAX = 256
_LOCK = threading.RLock()
_DB_READY = False
_DISK_DISABLED = False


def _disable_disk(exc):
    global _DISK_DISABLED
    if _DISK_DISABLED:
        return
    _DISK_DISABLED = True
    try:
        import xbmc
        xbmc.log('[MegaNexus] cache store: disk cache disabled for this session '
                 '(%s) — running from memory' % exc, xbmc.LOGWARNING)
    except Exception:
        pass


def _mem_key(kind, cache_key):
    return '%s:%s' % (kind or '', cache_key or '')


def _mem_put(kind, cache_key, payload):
    """Kept in memory too (at most _MEM_MAX, the longest kept goes first)."""
    with _LOCK:
        _MEM[_mem_key(kind, cache_key)] = payload
        while len(_MEM) > _MEM_MAX:
            _MEM.popitem(last=False)


def _mem_get(kind, cache_key):
    with _LOCK:
        return _MEM.get(_mem_key(kind, cache_key))


def _conn():
    global _DB_READY
    try:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    except Exception:
        pass
    conn = sqlite3.connect(DB_PATH, timeout=10)
    try:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
        conn.execute('PRAGMA busy_timeout=10000')
        conn.execute('PRAGMA temp_store=MEMORY')
    except Exception:
        pass
    if not _DB_READY:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS cache_items (
                cache_key TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                payload TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cache_kind_created ON cache_items(kind, created_at DESC)")
        conn.commit()
        _DB_READY = True
    return conn


def put(kind, payload, ttl_hours=24):
    now = int(time.time())
    key = uuid.uuid4().hex
    cutoff = now - int(ttl_hours * 3600)
    with _LOCK:
        _mem_put(kind, key, payload)
        if _DISK_DISABLED:
            return key
        conn = None
        try:
            encoded = json.dumps(payload, ensure_ascii=False)
            conn = _conn()
            conn.execute(
                "INSERT OR REPLACE INTO cache_items(cache_key, kind, payload, created_at) VALUES(?,?,?,?)",
                (key, kind, encoded, now),
            )
            conn.execute("DELETE FROM cache_items WHERE created_at < ?", (cutoff,))
            conn.commit()
        except sqlite3.Error as exc:
            _disable_disk(exc)
        except Exception as exc:
            _disable_disk(exc)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
    return key


def get(kind, cache_key):
    cached = _mem_get(kind, cache_key)
    if cached is not None:
        return cached
    if _DISK_DISABLED:
        return None
    row = None
    with _LOCK:
        conn = None
        try:
            conn = _conn()
            row = conn.execute("SELECT payload FROM cache_items WHERE kind=? AND cache_key=?", (kind, cache_key)).fetchone()
        except Exception as exc:
            _disable_disk(exc)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
    if not row:
        return None
    try:
        payload = json.loads(row[0])
        _mem_put(kind, cache_key, payload)
        return payload
    except Exception:
        return None


def update(kind, cache_key, payload):
    if not cache_key:
        return None
    now = int(time.time())
    with _LOCK:
        _mem_put(kind, cache_key, payload)     # memory first, always
        if _DISK_DISABLED:
            return cache_key
        conn = None
        try:
            encoded = json.dumps(payload, ensure_ascii=False)
            conn = _conn()
            conn.execute(
                "INSERT OR REPLACE INTO cache_items(cache_key, kind, payload, created_at) VALUES(?,?,?,?)",
                (cache_key, kind, encoded, now),
            )
            conn.commit()
        except Exception as exc:
            _disable_disk(exc)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
    return cache_key


def clear_all(kind=None):
    with _LOCK:
        _MEM.clear()                       # memory: all of it, whatever the kind
        if _DISK_DISABLED:
            return
        conn = None
        try:
            conn = _conn()
            if kind:
                conn.execute("DELETE FROM cache_items WHERE kind=?", (kind,))
            else:
                conn.execute("DELETE FROM cache_items")
            conn.commit()
        except Exception as exc:
            _disable_disk(exc)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
        _MEM.clear()                       # and what came in while the disk was cleared
