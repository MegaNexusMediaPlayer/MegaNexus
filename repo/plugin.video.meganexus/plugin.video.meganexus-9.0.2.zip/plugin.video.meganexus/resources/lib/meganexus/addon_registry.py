# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import os
import re
import shutil
import uuid

import xbmc

from .paths import profile_path
from .json_files import write_json as _atomic_write_json, read_json as _safe_read_json
_ORIGIN = 'mnx-f5a236349f56'

PROVIDERS_PATH = os.path.join(profile_path(), 'providers.json')
CATALOG_STATE_PATH = os.path.join(profile_path(), 'catalog_state.json')

_PROVIDERS_CACHE = None
_PROVIDERS_MTIME = None
_STATE_CACHE = None
_STATE_MTIME = None


def _file_mtime(path):
    """When the file last changed; None when it is not there."""
    try:
        return os.path.getmtime(path)
    except (OSError, ValueError, TypeError):
        return None


_read_json, _write_json = _safe_read_json, _atomic_write_json     # the shared safe JSON files


def _drop_addon_cache(rows=None):
    global _PROVIDERS_CACHE, _PROVIDERS_MTIME
    _PROVIDERS_CACHE = rows
    _PROVIDERS_MTIME = _file_mtime(PROVIDERS_PATH)


def _drop_catalog_cache(state=None):
    global _STATE_CACHE, _STATE_MTIME
    _STATE_CACHE = state
    _STATE_MTIME = _file_mtime(CATALOG_STATE_PATH)


# 7.0.30: one install of an add-on behind links that differ only in their last,
# encrypted part - AIOStreams: <host>/stremio/<uuid>/<encrypted>/manifest.json,
# and the encrypted part changes each time the link is copied. Every new copy
# (Nuvio sync, phone page) was added as one more add-on: MEGAMAN11 two or three
# times in every list, and its sources three times.
_INSTANCE = re.compile(r'^(https?://[^/?#]+/(?:[^/?#]+/)*?[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})'
                       r'/[^/?#]+/manifest\.json$', re.I)


def instance_key(manifest_url):
    found = _INSTANCE.match(str(manifest_url or '').strip())
    return found.group(1).lower() if found else ''


# Per-role on/off lists, [{"id": provider id, "enabled": bool}] in one setting each.
ROLE_SETTINGS = ('meganexus_metadata_providers', 'meganexus_stream_providers',
                 'meganexus_subtitle_providers', 'meganexus_sport_providers')
REPAIR_SETTING = 'meganexus_merged_switches'   # 7.0.31: devices merged by 7.0.30 repaired once


def _role_lists(addon):
    for setting in ROLE_SETTINGS:
        try:
            rows = json.loads(addon.getSetting(setting) or 'null')
        except ValueError:
            continue
        if isinstance(rows, list):
            yield setting, [row for row in rows if isinstance(row, dict)]


def _carry_switches(moved):
    """7.0.31: the copy that stays takes over the switches of the copies merged
    into it ({removed id: kept id}). 7.0.30 kept only its own: a device whose
    switched-on copy was merged away had no metadata add-on on ("Retry
    details" everywhere) or no stream add-on."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        for setting, rows in _role_lists(addon):
            on = {moved.get(row.get('id'), row.get('id')) for row in rows if row.get('enabled') is True}
            out, seen = [], set()
            for row in rows:
                pid = moved.get(row.get('id'), row.get('id'))
                if pid in seen:
                    continue
                seen.add(pid)
                out.append({'id': pid, 'enabled': pid in on})
            if out != rows:
                addon.setSetting(setting, json.dumps(out))
        from resources.lib import settings_snapshot
        settings_snapshot.invalidate()
    except Exception as exc:
        xbmc.log('[MegaNexus] add-on switches not carried over: %s' % exc, xbmc.LOGWARNING)


def _repair_switches(rows):
    """Once per device: a switched-on add-on that 7.0.30 merged away passes its
    switch to the copy of the same install that stayed."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.meganexus')
        if addon.getSetting(REPAIR_SETTING) == 'done':
            return
        present = {row.get('id') for row in rows if isinstance(row, dict)}
        copies = {row.get('id') for row in rows if isinstance(row, dict) and instance_key(row.get('manifest_url'))}
        for setting, saved in _role_lists(addon):
            gone_on = [row for row in saved if row.get('enabled') is True and row.get('id') not in present]
            if not gone_on or not copies:
                continue
            ids = [row.get('id') for row in saved]
            out = [dict(row, enabled=True) if row.get('id') in copies else row for row in saved if row.get('id') in present]
            out += [{'id': pid, 'enabled': True} for pid in copies if pid not in ids]
            addon.setSetting(setting, json.dumps(out))
            xbmc.log('[MegaNexus] add-on switches repaired after the 7.0.30 merge (%s)' % setting, xbmc.LOGINFO)
        addon.setSetting(REPAIR_SETTING, 'done')
        from resources.lib import settings_snapshot
        settings_snapshot.invalidate()
    except Exception as exc:
        xbmc.log('[MegaNexus] add-on switch repair skipped: %s' % exc, xbmc.LOGWARNING)


def _merge_instances(rows, moved=None):
    """Copies of one install become one: the first row (its id keeps the add-on's
    switches) with the newest link and manifest. ``moved`` collects
    {removed id: kept id}."""
    first, out = {}, []
    for row in rows:
        key = instance_key(row.get('manifest_url')) if isinstance(row, dict) else ''
        if key and key in first:
            kept = first[key]
            if moved is not None and row.get('id') and kept.get('id'):
                moved[row['id']] = kept['id']
            kept['manifest_url'] = row['manifest_url']
            kept['base_url'] = row.get('base_url') or row['manifest_url'].rsplit('/manifest.json', 1)[0]
            if row.get('manifest'):
                kept['manifest'] = row['manifest']
            continue
        if key:
            first[key] = row
        out.append(row)
    return out


_REPAIRED = []


def list_providers():
    """The installed add-ons (providers.json), read again only when the file has changed;
    copies of one install are merged into one (and the file written so)."""
    global _PROVIDERS_CACHE, _PROVIDERS_MTIME
    mtime = _file_mtime(PROVIDERS_PATH)
    if mtime == _PROVIDERS_MTIME and _PROVIDERS_CACHE is not None:
        return list(_PROVIDERS_CACHE)
    rows, moved = _read_json(PROVIDERS_PATH, []), {}
    listed = isinstance(rows, list)
    merged = _merge_instances(rows, moved) if listed else rows
    if listed and len(merged) != len(rows):
        xbmc.log('[MegaNexus] add-ons: %d copies of the same install merged' % (len(rows) - len(merged)), xbmc.LOGINFO)
        _write_json(PROVIDERS_PATH, merged)
        mtime = _file_mtime(PROVIDERS_PATH)
        _carry_switches(moved)
    if isinstance(merged, list) and not _REPAIRED:
        _REPAIRED.append(True)
        _repair_switches(merged)
    _PROVIDERS_CACHE = merged
    _PROVIDERS_MTIME = mtime
    return list(merged)


def store_addons_text(rows):
    if not isinstance(rows, list):
        return
    _write_json(PROVIDERS_PATH, rows)
    _drop_addon_cache(rows)


def add_provider(name, manifest_url, manifest):
    rows = list_providers()
    base_url = manifest_url.rsplit('/manifest.json', 1)[0]
    key = instance_key(manifest_url)
    for row in rows:
        if row.get('manifest_url') == manifest_url or (key and instance_key(row.get('manifest_url')) == key):
            # 7.0.30: a new copy of the same install's link replaces the old one.
            row.update({'name': name, 'manifest_url': manifest_url, 'base_url': base_url, 'manifest': manifest})
            _write_json(PROVIDERS_PATH, rows)
            _drop_addon_cache(rows)
            return row
    row = {
        'id': uuid.uuid4().hex[:10],
        'name': name,
        'manifest_url': manifest_url,
        'base_url': base_url,
        'manifest': manifest,
    }
    rows.append(row)
    _write_json(PROVIDERS_PATH, rows)
    _drop_addon_cache(rows)
    return row


def reload_manifest(provider_id, new_manifest):
    """The add-on's manifest replaced by a fresh copy (its name taken when it had none)."""
    rows = list_providers()
    row = next((entry for entry in rows if entry.get('id') == provider_id), None)
    if row is None:
        return None
    row['manifest'] = new_manifest
    if not row.get('name') and (new_manifest or {}).get('name'):
        row['name'] = new_manifest['name']
    _write_json(PROVIDERS_PATH, rows)
    _drop_addon_cache(rows)
    return row


def remove_provider(provider_id):
    rows = [row for row in list_providers() if row.get('id') != provider_id]
    _write_json(PROVIDERS_PATH, rows)
    _drop_addon_cache(rows)
    state = _catalog_settings()
    state = {k: v for k, v in state.items() if not k.startswith(provider_id + ':')}
    _write_json(CATALOG_STATE_PATH, state)
    _drop_catalog_cache(state)


def place_addon(provider_id, new_idx):
    rows = list_providers()
    src_idx = None
    for i, row in enumerate(rows):
        if row.get('id') == provider_id:
            src_idx = i
            break
    if src_idx is None:
        return None
    new_idx = max(0, min(int(new_idx), len(rows) - 1))
    if new_idx == src_idx:
        return src_idx
    rows.insert(new_idx, rows.pop(src_idx))
    _write_json(PROVIDERS_PATH, rows)
    _drop_addon_cache(rows)
    return new_idx


def get_provider(provider_id):
    for row in list_providers():
        if row.get('id') == provider_id:
            return row
    return None


def _catalog_settings():
    """Every catalog's choices (catalog_state.json), read again only when the file changed."""
    global _STATE_CACHE, _STATE_MTIME
    stamp = _file_mtime(CATALOG_STATE_PATH)
    if _STATE_CACHE is None or stamp != _STATE_MTIME:
        _STATE_CACHE, _STATE_MTIME = _read_json(CATALOG_STATE_PATH, {}), stamp
    return dict(_STATE_CACHE)


def _catalog_ref(provider_id, catalog_id):
    return '%s:%s' % (provider_id or '', catalog_id or '')


def catalog_settings(provider_id, catalog_id):
    return _catalog_settings().get(_catalog_ref(provider_id, catalog_id), {})


def keep_catalog_filter(provider_id, catalog_id, name, value):
    state = _catalog_settings()
    key = _catalog_ref(provider_id, catalog_id)
    current = dict(state.get(key, {}))
    if value in (None, '', '__clear__'):
        current.pop(name, None)
    else:
        current[name] = value
    state[key] = current
    _write_json(CATALOG_STATE_PATH, state)
    _drop_catalog_cache(state)
    return current


def reset_catalog_filters(provider_id, catalog_id):
    state = _catalog_settings()
    key = _catalog_ref(provider_id, catalog_id)
    if key in state:
        del state[key]
        _write_json(CATALOG_STATE_PATH, state)
        _drop_catalog_cache(state)
