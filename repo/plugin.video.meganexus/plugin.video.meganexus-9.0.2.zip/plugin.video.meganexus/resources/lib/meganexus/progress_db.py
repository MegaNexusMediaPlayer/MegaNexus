# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import os
import sqlite3
import threading
import time

import xbmc

from .paths import profile_path, watched_percent

DB_PATH = os.path.join(profile_path(), 'playback.db')
_DB_READY = False
_DB_LOCK = threading.RLock()


# the playback table, in its column order (ids came later: added to older files when missing)
COLUMNS = (('media_type', 'TEXT NOT NULL'), ('canonical_id', 'TEXT NOT NULL'), ('video_id', 'TEXT NOT NULL'),
           ('title', 'TEXT'), ('provider_name', 'TEXT'), ('poster', 'TEXT'), ('background', 'TEXT'),
           ('clearlogo', 'TEXT'), ('season', 'INTEGER'), ('episode', 'INTEGER'), ('position', 'REAL'),
           ('duration', 'REAL'), ('percent', 'REAL'), ('stream_url', 'TEXT'), ('event_type', 'TEXT'),
           ('updated_at', 'INTEGER'), ('tmdb_id', 'TEXT'), ('imdb_id', 'TEXT'), ('tvdb_id', 'TEXT'),
           ('show_tmdb_id', 'TEXT'), ('native_server_id', 'TEXT'), ('native_item_id', 'TEXT'),
           ('plot', 'TEXT'))
LATER_COLUMNS = COLUMNS[16:]
INDEXES = (('idx_playback_updated', 'updated_at DESC'), ('idx_playback_percent', 'percent'),
           ('idx_playback_imdb', 'imdb_id, updated_at DESC'), ('idx_playback_tmdb', 'tmdb_id, updated_at DESC'),
           ('idx_playback_show_tmdb', 'show_tmdb_id, season, episode, updated_at DESC'),
           ('idx_playback_tvdb', 'tvdb_id, updated_at DESC'))
LISTED = ('media_type', 'canonical_id', 'video_id', 'title', 'provider_name', 'poster', 'background', 'clearlogo',
          'season', 'episode', 'position', 'duration', 'percent', 'updated_at', 'event_type', 'stream_url',
          'tmdb_id', 'imdb_id', 'tvdb_id', 'show_tmdb_id', 'native_server_id', 'native_item_id', 'plot')
RESUMED = tuple(name for name in LISTED if name not in ('event_type', 'stream_url'))
WATCHED_AT = 95.0


def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    try:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
    except Exception:
        pass
    return conn


def _as_dict(row, names):
    return dict(zip(names, row))


def _salvage():
    """8.1.3: "file is not a database" - the watch history is not thrown away. A PC's
    playback.db came back with bytes 5-31 of its header overwritten and every page
    intact: the header is written again from what a SQLite file of this size must say,
    and the file is used when SQLite then finds it whole. Otherwise it is set aside
    (playback.db.broken-<time>) and a new one is started - progress comes back from
    Nuvio / the trackers - instead of the interface failing at every entry."""
    import shutil
    import struct
    import time as _time
    try:
        size = os.path.getsize(DB_PATH)
    except OSError:
        return
    aside = '%s.broken-%d' % (DB_PATH, int(_time.time()))
    try:
        shutil.copyfile(DB_PATH, aside)
    except OSError:
        pass
    try:
        with open(DB_PATH, 'rb') as handle:
            header = bytearray(handle.read(100))
        page = 4096 if size % 4096 == 0 else (1024 if size % 1024 == 0 else 0)
        if page and len(header) == 100:
            header[0:16] = b'SQLite format 3\x00'
            header[16:18] = struct.pack('>H', page)
            # the journal kind (1 rollback, 2 WAL) kept when it is still readable: set to
            # 1, a WAL file's rows not yet copied into the database would be passed over
            mode = header[18] if header[18] in (1, 2) and header[19] == header[18] else 1
            header[18:24] = bytes((mode, mode, 0, 64, 32, 32))
            header[28:32] = struct.pack('>I', size // page)
            with open(DB_PATH, 'r+b') as handle:
                handle.write(bytes(header))
            check = sqlite3.connect(DB_PATH, timeout=10)
            try:
                if check.execute('PRAGMA integrity_check').fetchone()[0] == 'ok':
                    xbmc.log('[MegaNexus] playback.db: a damaged header was repaired; nothing lost', xbmc.LOGWARNING)
                    return
            finally:
                check.close()
    except Exception:
        pass
    for suffix in ('', '-wal', '-shm', '-journal'):
        try:
            os.remove(DB_PATH + suffix)
        except OSError:
            pass
    xbmc.log('[MegaNexus] playback.db could not be read; kept as %s and started again' % os.path.basename(aside),
             xbmc.LOGWARNING)


def _ensure_db():
    global _DB_READY
    if _DB_READY:
        return
    with _DB_LOCK:
        if _DB_READY:
            return
        try:
            probe = _connect()
            try:
                probe.execute('SELECT name FROM sqlite_master LIMIT 1').fetchall()
            finally:
                probe.close()
        except sqlite3.DatabaseError:
            _salvage()
        conn = _connect()
        try:
            conn.execute('CREATE TABLE IF NOT EXISTS playback (%s, PRIMARY KEY (media_type, canonical_id, video_id))'
                         % ', '.join('%s %s' % column for column in COLUMNS))
            present = set(row[1] for row in conn.execute('PRAGMA table_info(playback)').fetchall())
            for name, kind in LATER_COLUMNS:
                if name not in present:
                    conn.execute('ALTER TABLE playback ADD COLUMN %s %s' % (name, kind))
            for name, columns in INDEXES:
                conn.execute('CREATE INDEX IF NOT EXISTS %s ON playback(%s)' % (name, columns))
            # Repair 6.0.9 cloud timestamps written as milliseconds into a seconds column.
            conn.execute('UPDATE playback SET updated_at=updated_at/1000.0 WHERE updated_at>=100000000000')
            from resources.lib.nuvio_progress import ensure
            ensure(conn)
            # Older cloud imports used 'tv' while local playback uses 'series'.
            cursor=conn.execute("SELECT * FROM playback WHERE media_type='tv'")
            names=[column[0] for column in cursor.description]
            for values in cursor.fetchall():
                row=dict(zip(names, values))
                old=(row['media_type'], row['canonical_id'], row['video_id'])
                row['media_type']='series';row['ext_updated_at']=row.get('updated_at')
                if row.get('duration') and row.get('event_type')=='account_sync':
                    row['percent']=min(100, max(0, 100*float(row.get('position') or 0)/float(row['duration'])))
                conn.execute(_UPSERT_SQL, _upsert_params(conn, row))
                conn.execute('DELETE FROM playback WHERE media_type=? AND canonical_id=? AND video_id=?',old)

            conn.commit()
            _DB_READY = True
        finally:
            conn.close()


# One upsert for every write: a newer row (or one as new that changes something) wins;
# what it brings empty never wipes what is kept.
_ALL_COLUMNS = ('media_type', 'canonical_id', 'video_id', 'title', 'provider_name', 'poster', 'background', 'clearlogo',
                'season', 'episode', 'position', 'duration', 'percent', 'stream_url', 'event_type', 'updated_at',
                'tmdb_id', 'imdb_id', 'tvdb_id', 'show_tmdb_id', 'native_server_id', 'native_item_id', 'plot')
_TAKEN = ('season', 'episode', 'percent', 'stream_url', 'event_type', 'updated_at')          # always the new one
_FILLED = ('provider_name', 'poster', 'background', 'clearlogo', 'tmdb_id', 'imdb_id', 'tvdb_id', 'show_tmdb_id',
           'native_server_id', 'native_item_id', 'plot')                                     # the new one when not empty
_NAMED = "lower(trim(excluded.title)) NOT IN ('', 'unknown', 'untitled')"
_SETS = (['title=CASE WHEN %s THEN excluded.title ELSE playback.title END' % _NAMED,
          # a row without a length keeps the known one, its place from its share of it
          'position=CASE WHEN excluded.duration<=0 AND playback.duration>0 THEN playback.duration*excluded.percent/100.0 '
          'ELSE excluded.position END',
          'duration=CASE WHEN excluded.duration>0 THEN excluded.duration ELSE playback.duration END']
         + ['%s=excluded.%s' % (name, name) for name in _TAKEN]
         + ["%s=CASE WHEN excluded.%s != '' THEN excluded.%s ELSE playback.%s END" % ((name,) * 4) for name in _FILLED])
_CHANGES = (['excluded.%s IS NOT playback.%s' % (name, name) for name in ('percent', 'season', 'episode', 'event_type', 'stream_url')]
            + ['(excluded.duration > 0 AND (excluded.duration IS NOT playback.duration OR excluded.position IS NOT playback.position))',
               '(%s AND excluded.title IS NOT playback.title)' % _NAMED]
            + ["(excluded.%s != '' AND excluded.%s IS NOT playback.%s)" % ((name,) * 3) for name in _FILLED if name != 'plot'])
_UPSERT_SQL = ('INSERT INTO playback (%s) VALUES (%s) ON CONFLICT(media_type, canonical_id, video_id) DO UPDATE SET %s '
               'WHERE excluded.updated_at > playback.updated_at OR (excluded.updated_at = playback.updated_at AND (%s))'
               % (', '.join(_ALL_COLUMNS), ', '.join('?' * len(_ALL_COLUMNS)), ', '.join(_SETS), ' OR '.join(_CHANGES)))
# 7.0.45: an unchanged row (the same time and values, as every cloud pull gives back) is not
# written again - SQLite counted it as changed, so every pull (each minute) "changed" all
# rows and Home reloaded Continue Watching, which took Home's workers for seconds.


def _mark_sync_dirty():
    try:
        import xbmcgui
        xbmcgui.Window(10000).setProperty('meganexus.sync_dirty', str(time.time_ns()))
    except Exception:
        pass


def _own_link(url):
    """7.0.60: a Watch Party guest never keeps the host's shared link (the host's TorBox key)."""
    try:
        from ..party_bridge import from_host
        if from_host(url):
            return ''
    except Exception:
        pass
    return url or ''


def _upsert_params(conn, row):
    """The row as the upsert's values (COLUMNS order). A row without its own time is stamped
    now - unless its position and event did not change, then it keeps the stored time (a
    repeated save never moves a title to the front)."""
    kind = _kind_of(row.get('media_type'))
    key = (kind, row.get('canonical_id') or '', row.get('video_id') or '')
    given = row.get('ext_updated_at')
    try:
        from resources.lib.progress_model import timestamp
        when = timestamp(given) if given is not None else time.time()
    except Exception:
        when = time.time()
    if given is None:
        stored = conn.execute('SELECT position, updated_at, event_type FROM playback WHERE media_type=? AND '
                              'canonical_id=? AND video_id=?', key).fetchone()
        try:
            if stored and abs(float(row.get('position') or 0.0) - float(stored[0] or 0.0)) < 0.01 \
                    and (row.get('event_type') or '') == stored[2]:
                when = float(stored[1] or when)
        except Exception:
            pass
    text = lambda name: row.get(name) or ''
    ident = lambda name: str(row.get(name) or '').strip()
    return key + (text('title'), text('provider_name'), text('poster'), text('background'), text('clearlogo'),
                  row.get('season'), row.get('episode'), row.get('position') or 0.0, row.get('duration') or 0.0,
                  row.get('percent') or 0.0, _own_link(row.get('stream_url')), text('event_type'), when,
                  ident('tmdb_id'), ident('imdb_id').lower(), ident('tvdb_id'), ident('show_tmdb_id'),
                  ident('native_server_id'), ident('native_item_id'), text('plot'))


def _keeps_its_end(conn, row):
    """9.0.1: an account's resume (Nuvio, Stremio, Trakt, Simkl) does not replace this title's
    watched row unless it is a real rewatch (progress_model.counts_as_rewatch). A film opened
    for a second on the phone came back newer than the end and took its place: finished films
    showed in Continue Watching at 0 %."""
    from resources.lib.progress_model import counts_as_rewatch, timestamp
    if row.get('event_type') == 'watched' or float(row.get('percent') or 0) >= watched_percent():
        return False
    stored = conn.execute('SELECT event_type, percent, updated_at FROM playback WHERE media_type=? AND canonical_id=? '
                          'AND video_id=?', (_kind_of(row.get('media_type')), row.get('canonical_id') or '',
                                             row.get('video_id') or '')).fetchone()
    if not stored or not (stored[0] == 'watched' or float(stored[1] or 0) >= watched_percent()):
        return False
    given = row.get('ext_updated_at')
    return not counts_as_rewatch(dict(row, updated_at=timestamp(given) if given is not None else time.time()), stored[2])


def keep_rows(entries, mark_dirty=True):
    rows = [dict(row) for row in (entries or []) if isinstance(row, dict)]
    if not rows:
        return 0
    _ensure_db()
    changed = 0
    from resources.lib import nuvio_progress
    account = nuvio_progress.scope() if mark_dirty else ''
    with _DB_LOCK:
        conn = _connect()
        try:
            for row in rows:
                if not (row.get('canonical_id') or row.get('video_id')):
                    continue
                if not mark_dirty and _keeps_its_end(conn, row):
                    continue
                values = _upsert_params(conn, row)
                cursor = conn.execute(_UPSERT_SQL, values)
                if mark_dirty and cursor.rowcount and account:
                    queued = dict(row, media_type=values[0], updated_at=values[15])
                    nuvio_progress.queue(conn, queued, account=account)
                try:
                    changed += max(0, int(cursor.rowcount or 0))
                except Exception:
                    changed += 1
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            conn.close()
    if changed and mark_dirty:
        _mark_sync_dirty()
    return changed


def keep_row(media_type, canonical_id, video_id, title, provider_name,
                 poster, background, clearlogo, season, episode, position,
                 duration, percent, stream_url, event_type,
                 ext_updated_at=None, tmdb_id='', imdb_id='', tvdb_id='',
                 show_tmdb_id='', native_server_id='', native_item_id='',
                 mark_dirty=True):
    row = dict(locals())
    return keep_rows([dict((name, value) for name, value in row.items() if name != 'mark_dirty')],
                          mark_dirty=mark_dirty)


def _kind_of(media_type):
    """The stored media_type, exactly as the upsert writes it. Older cloud imports
    (and Nuvio's wire) say 'tv' where local playback says 'series'; every row is kept
    under one of them. Nothing else about the value is touched, so existing rows keep
    the spelling they were stored with."""
    kind = media_type or ''
    return 'series' if kind in ('tv', 'show', 'tvshow', 'episode') else kind


def _fill_display(media_type, canonical_id, video_id, **values):
    """Only the given non-empty display fields of one row are replaced.

    8.1.0: the row is found by the same media_type the upsert stores (_kind_of) - a
    'tv' key from a cloud row silently repaired nothing."""
    media_type = _kind_of(media_type)
    names = [name for name in ('title', 'poster', 'background', 'clearlogo', 'plot') if name in values]
    with _DB_LOCK:
        conn = _connect()
        try:
            conn.execute('UPDATE playback SET %s WHERE media_type=? AND canonical_id=? AND video_id=?'
                         % ', '.join("%s=CASE WHEN ? != '' THEN ? ELSE %s END" % (name, name) for name in names),
                         tuple(value for name in names for value in (values[name] or '', values[name] or ''))
                         + (media_type or '', canonical_id or '', video_id or ''))
            conn.commit()
        finally:
            conn.close()   # 8.1.0: always closed, also when the file is busy


def update_art(media_type, canonical_id, video_id, poster='', background='', clearlogo=''):
    _ensure_db()
    _fill_display(media_type, canonical_id, video_id, poster=poster, background=background, clearlogo=clearlogo)


def update_metadata(media_type, canonical_id, video_id, title='', poster='', background='', clearlogo='', plot=''):
    """Repair display data only. Never reorder progress or mark it dirty for cloud sync.

    8.1.1: the description travels with the rest. Continue Watching skips its network
    round only when a card is complete, and the description was the one field nothing
    kept - so every Home build fetched every card again (3.5 s for five of them here).
    """
    _ensure_db()
    if str(title).strip().lower() in ('unknown', 'untitled', 'loading title…'):
        title = ''
    _fill_display(media_type, canonical_id, video_id, title=title, poster=poster, background=background,
                  clearlogo=clearlogo, plot=plot)


def title_keys(row):
    """7.0.29: every id a title is saved under - its own and its IMDb / TMDB / TVDB
    ids - so one title saved by Nuvio as tt0381707 and by another app as
    tmdb:12153 is one title (Continue Watching showed it twice)."""
    kind='movie' if row.get('media_type')=='movie' else 'series'
    keys={(kind,str(row.get('canonical_id') or ''))}
    for column,prefix in (('imdb_id',''),('tmdb_id','tmdb:'),('tvdb_id','tvdb:')):
        value=str(row.get(column) or '').strip()
        if value and value not in ('0','None'):
            keys.add((kind,value if prefix=='' or value.startswith(prefix) else prefix+value))
    keys.discard((kind,''))
    return keys


def list_continue_items(limit=50, recent=None):
    # Pick the latest episode before filtering completion. Otherwise an older
    # unfinished episode resurfaces after a newer episode has been watched.
    # 8.1.3: ``recent`` - the rows already read by the caller (one query, not two)
    # 9.0.1: and a resume newer than the title's last end counts only as a real rewatch
    from resources.lib.progress_model import counts_as_rewatch, timestamp
    rows=list(recent if recent is not None else list_recent_items(limit=max(200,int(limit)*8)))
    finished={}
    for row in rows:
        if float(row.get('percent') or 0)>=watched_percent() or row.get('event_type')=='watched':
            for key in title_keys(row):finished[key]=max(finished.get(key,0),timestamp(row.get('updated_at')))
    out=[];seen=set()
    for row in rows:
        if not row.get('position') and row.get('event_type')!='watched' and float(row.get('percent') or 0)<=0:continue
        keys=title_keys(row)
        if keys&seen:
            seen|=keys;continue
        seen|=keys
        if float(row.get('percent') or 0)>=watched_percent() or row.get('event_type')=='watched':continue
        ended=max([finished.get(key,0) for key in keys] or [0])
        if ended and not counts_as_rewatch(row,ended):continue
        out.append(row)
        if len(out)>=limit:break
    return out


def list_recent_items(limit=200, media_types=None, include_watched=True):
    """The newest saved playbacks (of the given types; without watched ones when asked)."""
    _ensure_db()
    kinds = [str(kind or '').strip().lower() for kind in media_types or [] if str(kind or '').strip()]
    where = (['media_type IN (%s)' % ','.join('?' * len(kinds))] if kinds else []) + \
        ([] if include_watched else ['percent < %s' % WATCHED_AT])
    conn = _connect()
    try:
        rows = conn.execute('SELECT %s FROM playback%s ORDER BY updated_at DESC, title COLLATE NOCASE ASC, '
                            'canonical_id ASC, video_id ASC LIMIT ?'
                            % (', '.join(LISTED), ' WHERE ' + ' AND '.join(where) if where else ''),
                            tuple(kinds) + (int(limit or 200),)).fetchall()
    finally:
        conn.close()
    return [_as_dict(row, LISTED) for row in rows]


def _row_to_dict(row):
    return _as_dict(row, RESUMED)


def _resume_ways(canonical_id, tmdb_id, imdb_id, tvdb_id):
    """(condition, values) to find a title by: IMDb id, TMDB id (also as a show), TVDB id, our id."""
    imdb = str(imdb_id or '').strip().lower()
    imdb = imdb.split(':', 1)[1].strip() if imdb.startswith('imdb:') else imdb
    imdb = 'tt' + imdb if imdb.isdigit() else imdb
    tmdb, tvdb, ours = (str(value or '').strip() for value in (tmdb_id, tvdb_id, canonical_id))
    return ([('LOWER(imdb_id)=?', (imdb,))] if imdb else []) + ([('(tmdb_id=? OR show_tmdb_id=?)', (tmdb, tmdb))] if tmdb else []) \
        + ([('tvdb_id=?', (tvdb,))] if tvdb else []) + ([('(canonical_id=? OR video_id=?)', (ours, ours))] if ours else [])


def known_duration(ids, season=None, episode=None):
    """9.0.1: the length MegaNexus measured for this film or episode (s), from any of its ids; 0
    when it was never played here. ``ids``: {'imdb', 'tmdb', 'tvdb'} as the services give them."""
    ids = ids or {}
    ways = _resume_ways('', ids.get('tmdb'), ids.get('imdb'), ids.get('tvdb'))
    if not ways:
        return 0.0
    _ensure_db()
    place = () if season is None or episode is None else (int(season), int(episode))
    conn = _connect()
    try:
        for condition, values in ways:
            row = conn.execute('SELECT MAX(duration) FROM playback WHERE duration > 60 AND %s%s'
                               % (condition, ' AND season=? AND episode=?' if place else
                                  " AND media_type IN ('movie', 'movies', '')"), values + place).fetchone()
            if row and row[0]:
                return float(row[0])
    finally:
        conn.close()
    return 0.0


def find_resume_entry(media_type='movie', canonical_id='', tmdb_id='', imdb_id='', tvdb_id='', season=None, episode=None):
    """The newest unfinished playback of a title (or of the episode) - over 30 s or 1 %, under 95 %."""
    _ensure_db()
    unset = (None, '', 0, '0')
    episode_wanted = str(media_type or 'movie').strip().lower() in ('series', 'anime', 'show', 'tv') \
        or (season not in unset and episode not in unset)
    try:
        place = (int(season or 0), int(episode or 0))
    except Exception:
        place = (0, 0)
    rules = ['percent < %s' % WATCHED_AT, '(position > 30.0 OR percent > 1.0)'] + \
        (['season=?', 'episode=?'] if episode_wanted else ["media_type IN ('movie', 'movies', '')"])
    ways = _resume_ways(canonical_id, tmdb_id, imdb_id, tvdb_id)
    if not ways:
        return None
    conn = _connect()
    try:
        for condition, values in ways:
            row = conn.execute('SELECT %s FROM playback WHERE %s AND %s ORDER BY updated_at DESC LIMIT 1'
                               % (', '.join(RESUMED), ' AND '.join(rules), condition),
                               (place if episode_wanted else ()) + values).fetchone()
            if row:
                return _row_to_dict(row)
    finally:
        conn.close()
    return None


def _mutate_progress(media_type, canonical_id, video_id, operation, mark_dirty=True, at=None):
    from resources.lib import nuvio_progress
    import json
    _ensure_db()
    account = nuvio_progress.scope() if mark_dirty else ''
    conn = _connect()
    changed = False
    try:
        cursor = conn.execute('SELECT * FROM playback WHERE media_type=? AND canonical_id=? AND video_id=?',
                              (media_type or '', canonical_id or '', video_id or ''))
        names = [item[0] for item in cursor.description]
        values = cursor.fetchone()
        if values:
            row = dict(zip(names, values))
            if not mark_dirty and operation != 'delete':
                # 8.1.3: what an account says (Simkl's import, every start) - not "now". It
                # stamped 201 episodes that were watched already with the time of the import,
                # and one that was being watched again: newer than its resume, which then
                # went from Continue Watching. Already watched: left as it is. Watched there
                # before the resume here: the resume stays.
                # 9.0.1: ... only a real rewatch (progress_model.counts_as_rewatch) - a start of a
                # few seconds after the end is the end
                from resources.lib.progress_model import counts_as_rewatch
                if row.get('event_type') == 'watched' or float(row.get('percent') or 0) >= watched_percent():
                    values = None
                elif (not at or float(row.get('updated_at') or 0) > float(at)) and counts_as_rewatch(row, at):
                    values = None
        if values:
            # 9.0.1: an account's mark without a date keeps the row's own time - never "now",
            # which made a mark from years ago newer than last week's resume
            row['updated_at'] = (float(at) if at else float(row.get('updated_at') or 0)) if not mark_dirty else time.time()
            if operation == 'delete':
                conn.execute('DELETE FROM playback WHERE media_type=? AND canonical_id=? AND video_id=?', (media_type, canonical_id, video_id))
            else:
                row.update(percent=100.0, position=row.get('duration') or row.get('position') or 0, event_type='watched')
                conn.execute("UPDATE playback SET percent=100.0, position=CASE WHEN duration>0 THEN duration ELSE position END, event_type='watched', updated_at=? WHERE media_type=? AND canonical_id=? AND video_id=?", (row['updated_at'], media_type, canonical_id, video_id))
            if mark_dirty:
                nuvio_progress.queue(conn, row, operation=operation, account=account)
                exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='meganexus_continue'").fetchone()
                if exists:
                    for key, raw in conn.execute('SELECT identity,payload FROM meganexus_continue').fetchall():
                        local = json.loads(raw)
                        if local.get('canonical_id') == canonical_id and local.get('video_id') == video_id:
                            local.update(percent=100, event_type='removed' if operation=='delete' else 'watched', updated_at=row['updated_at'])
                            conn.execute('UPDATE meganexus_continue SET updated=?,payload=? WHERE identity=?', (row['updated_at'], json.dumps(local), key))
            changed = True
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    if changed and mark_dirty:
        _mark_sync_dirty()
        from resources.lib.simkl_watched import _invalidate_view
        _invalidate_view()
    return changed


def delete_entry(media_type, canonical_id, video_id, mark_dirty=True):
    return _mutate_progress(media_type, canonical_id, video_id, 'delete', mark_dirty)


BULK_STAMP = 20     # 9.0.1: this many watched rows with the very same second were stamped by an import


def correct_bulk_stamps(real_dates):
    """9.0.1: watched rows an earlier import stamped with its own time get the account's real
    date back. ``real_dates``: {IMDb / canonical id: when it was really finished}. One machine
    had 57 films marked watched in the same second; finished years before, they hid the ones
    being watched again (a resume older than "now" counted as before the end). Only a time
    shared by BULK_STAMP rows or more is touched, and only moved back to a known real date -
    nothing is deleted. Returns how many rows were corrected."""
    if not real_dates:
        return 0
    _ensure_db()
    fixed = 0
    with _DB_LOCK:
        conn = _connect()
        try:
            bulk = [row[0] for row in conn.execute(
                "SELECT CAST(updated_at AS INTEGER) AS second FROM playback WHERE event_type='watched' "
                "GROUP BY second HAVING COUNT(*) >= ?", (BULK_STAMP,))]
            for second in bulk:
                for canonical_id, imdb_id, video_id, kind, stamp in conn.execute(
                        "SELECT canonical_id, imdb_id, video_id, media_type, updated_at FROM playback "
                        "WHERE event_type='watched' AND CAST(updated_at AS INTEGER)=?", (second,)).fetchall():
                    real = real_dates.get(str(imdb_id or '').lower()) or real_dates.get(str(canonical_id or ''))
                    if real and float(real) < float(stamp) - 12 * 3600:
                        conn.execute('UPDATE playback SET updated_at=? WHERE media_type=? AND canonical_id=? AND video_id=?',
                                     (float(real), kind, canonical_id, video_id))
                        fixed += 1
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    if fixed:
        xbmc.log('[MegaNexus] %d watched marks an earlier import had dated itself got their real date back' % fixed,
                 xbmc.LOGINFO)
    return fixed


def mark_watched(media_type, canonical_id, video_id, mark_dirty=True, at=None):
    """``at``: when the account says it was watched (an import, ``mark_dirty`` False)."""
    return _mutate_progress(media_type, canonical_id, video_id, 'upsert', mark_dirty, at)


_WATCHED_MEM={}
def watched_snapshot():
    """Account-independent local completion, cached until SQLite changes."""
    _ensure_db()
    def stamp(path):
        try:return os.stat(path).st_mtime_ns
        except OSError:return 0
    stamp_key=(DB_PATH,stamp(DB_PATH),stamp(DB_PATH+'-wal'))
    if _WATCHED_MEM.get('key')==stamp_key:return _WATCHED_MEM['items']
    conn=_connect()
    try:rows=conn.execute("SELECT media_type,canonical_id,season,episode,imdb_id,tmdb_id,tvdb_id FROM playback WHERE percent>=? OR event_type='watched'",(watched_percent(),)).fetchall()
    finally:conn.close()
    items={}
    for media,mid,season,episode,imdb,tmdb,tvdb in rows:
        movie=media=='movie';prefix='movie|' if movie else 'series|'
        mids={mid}
        if imdb:mids.add(imdb if str(imdb).startswith('tt') else 'tt'+str(imdb))
        if tmdb:mids.add('tmdb:'+str(tmdb))
        if tvdb:mids.add('tvdb:'+str(tvdb))
        for identity in mids:
            entry=items.setdefault(prefix+str(identity),{'watched':False,'seasons':[],'episodes':[]})
            if movie:entry['watched']=True
            elif season is not None and episode is not None:
                marker='%s:%s'%(season,episode)
                if marker not in entry['episodes']:entry['episodes'].append(marker)
    _WATCHED_MEM.update(key=stamp_key,items=items)
    return items
