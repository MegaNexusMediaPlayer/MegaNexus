# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from . import addon_wire, addon_registry  # noqa: F401 - loads the client with the package (callers and tests rely on it)


def list_providers():
    return addon_registry.list_providers()


def remove_provider(provider_id):
    return addon_registry.remove_provider(provider_id)


