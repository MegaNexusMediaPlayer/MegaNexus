# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import os
import shutil
import uuid

import xbmc


def write_json(path, value):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        try:
            shutil.copy2(path, path + '.bak')
        except Exception as exc:
            xbmc.log('[MegaNexus] backup snapshot failed for %s: %s' % (path, exc),
                     xbmc.LOGDEBUG)
    # Kodi services and dialogs can write from different threads in one process.
    tmp_path = '%s.tmp.%s' % (path, uuid.uuid4().hex)
    try:
        with open(tmp_path, 'w', encoding='utf-8') as fh:
            json.dump(value, fh, ensure_ascii=False, indent=2)
            try:
                fh.flush()
                os.fsync(fh.fileno())
            except Exception:
                pass
        os.replace(tmp_path, path)
    except Exception:
        try:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
        except Exception:
            pass
        raise


def read_json(path, default):
    primary_err = None
    for candidate, is_backup in ((path, False), (path + '.bak', True)):
        if not os.path.exists(candidate):
            continue
        try:
            with open(candidate, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            if not isinstance(data, type(default)):
                raise ValueError('expected %s, got %s' %
                                  (type(default).__name__, type(data).__name__))
            if is_backup:
                xbmc.log('[MegaNexus] Recovered %s from .bak after primary corruption' % path,
                         xbmc.LOGWARNING)
                try:
                    shutil.copy2(candidate, path)
                except Exception:
                    pass
            return data
        except Exception as exc:
            if not is_backup:
                primary_err = exc
                xbmc.log('[MegaNexus] Corrupt %s (%s) — trying backup' %
                         (path, exc), xbmc.LOGWARNING)
            else:
                xbmc.log('[MegaNexus] Backup also unusable for %s: %s' %
                         (path, exc), xbmc.LOGERROR)
    if primary_err is not None:
        xbmc.log('[MegaNexus] Falling back to default for %s — primary error: %s' %
                 (path, primary_err), xbmc.LOGERROR)
    return default
