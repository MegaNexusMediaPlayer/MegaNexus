# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import os
import time

import xbmcaddon
import xbmcvfs

ADDON_ID = 'plugin.video.meganexus'
# 6.0.35 (GitHub issue #6): watched at 90 %, like the Nuvio apps
# (WatchProgress.COMPLETED_THRESHOLD = 0.90; Simkl 0.80). Titles stopped in
# the end credits no longer stay in Continue Watching.
PROFILE_CHECK = 30.0          # s before the profile folder is made sure of again
WATCHED_PERCENT = 90          # the default; watched_percent() is what to ask
WATCHED_SETTING = 'meganexus_watched_percent'
_WATCHED = [0.0, WATCHED_PERCENT]


def watched_percent():
    """How far through a title counts as watched.

    8.1.2 (GitHub #23, "Next episode too early"): this was fixed at 90, so a 50 minute
    episode counted as finished with five minutes still to run - before the credits on
    many shows. It is a setting now, and still 90 by default, as the Nuvio apps have it.

    The answer is held for a few seconds: Home asks it once per progress row.
    """
    now = time.time()
    if now - _WATCHED[0] < 5.0:
        return _WATCHED[1]
    value = WATCHED_PERCENT
    try:
        typed = (addon().getSetting(WATCHED_SETTING) or '').strip()
        if typed:
            value = min(100, max(50, int(float(typed))))
    except (ValueError, TypeError, AttributeError):
        value = WATCHED_PERCENT
    _WATCHED[0], _WATCHED[1] = now, value
    return value
SIMKL_WATCHED_PERCENT = 80

_ADDON_INSTANCE = None
_ADDON_INSTANCE_TS = 0.0
_ADDON_TTL = 2.0


def addon():
    global _ADDON_INSTANCE, _ADDON_INSTANCE_TS
    now = time.time()
    if _ADDON_INSTANCE is None or (now - _ADDON_INSTANCE_TS) > _ADDON_TTL:
        try:
            _ADDON_INSTANCE = xbmcaddon.Addon(ADDON_ID)
        except Exception:
            try:
                _ADDON_INSTANCE = xbmcaddon.Addon('plugin.video.meganexus')
            except Exception:
                return xbmcaddon.Addon(ADDON_ID)
        _ADDON_INSTANCE_TS = now
    return _ADDON_INSTANCE


_PROFILE = ['', 0.0]


def profile_path():
    """Where this profile keeps its files - made once, then remembered.

    8.1.2: this ran os.makedirs on EVERY call, and it is called from the drawing path:
    _set_rows asks simkl_watched.snapshot() for each row, that asks mdblist for its
    file, and that asks here. A disk call per row, per paint - on the Cube's eMMC the
    loop watchdog caught Home sitting inside this very makedirs for five seconds while
    the screen stood still and the remote only clicked. Home paint was 5,546 ms for
    twelve rows.

    The folder is created once per run (and again if it goes away, checked at most
    every PROFILE_CHECK seconds), which is the same guarantee for a hundredth of the
    cost. A profile change re-reads it through addon(), which is already cached the
    same way.
    """
    path = xbmcvfs.translatePath(addon().getAddonInfo('profile'))
    now = time.time()
    if path != _PROFILE[0] or now - _PROFILE[1] >= PROFILE_CHECK:
        try:
            os.makedirs(path, exist_ok=True)
        except OSError:
            pass
        _PROFILE[0], _PROFILE[1] = path, now
    return path
