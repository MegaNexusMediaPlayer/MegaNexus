# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus' network layer for Stremio add-ons: settings (options), one request
(transport), kept answers (responses), add-ons left out after failures (health) and
work for many add-ons at once (lanes). meganexus.client is the API on top."""
