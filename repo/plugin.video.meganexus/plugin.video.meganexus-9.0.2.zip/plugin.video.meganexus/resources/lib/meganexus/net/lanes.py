# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Work for many add-ons at once, on three kept thread pools ("lanes").

Browsing, streams and subtitles each have their own pool (WIDTH threads), so a slow
catalog never holds a Play back and the thread count never grows with features: any
label maps to one of the three. When Kodi can start no more threads (small CoreELEC /
Android boxes), the work runs one item after another instead of failing.

    run_parallel   every result, in the items' order (a timeout marks the rest)
    iter_parallel  results as they finish (the rest is cancelled when the caller stops)
    JobRace        results as they finish, polled - the same live work can be handed on"""
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, TimeoutError, as_completed
from concurrent.futures import wait as wait_for_first

from . import options

WIDTH = {'browse': 4, 'streams': 4, 'subtitles': 3}
MOST = 8
_lock = threading.Lock()
_pools = {}
_widths = {}


def lane_of(label):
    name = str(label or 'default').strip().lower()[:32] or 'default'
    if 'stream' in name:
        return 'streams'
    if 'subtitle' in name:
        return 'subtitles'
    return 'browse'


def _quit(pool):
    try:
        pool.shutdown(wait=False, cancel_futures=True)
    except TypeError:
        try:
            pool.shutdown(wait=False)
        except Exception:
            pass
    except Exception:
        pass


def pool_for(size=None, label='default'):
    """The lane's pool (made on first use; threads start only as work arrives)."""
    lane = lane_of(label)
    width = WIDTH.get(lane, 4)
    with _lock:
        pool = _pools.get(lane)
        if pool is None or int(_widths.get(lane) or 0) != width:
            if pool is not None:
                _quit(pool)
            pool = _pools[lane] = ThreadPoolExecutor(max_workers=width, thread_name_prefix='MegaNexus-%s' % lane)
            _widths[lane] = width
        return pool


def reset(label=None):
    """A lane's pool (or every pool) dropped after Kodi refused a thread; the next call makes it again."""
    lanes = [lane_of(label)] if label else None
    with _lock:
        for lane in lanes if lanes is not None else list(_pools):
            pool = _pools.pop(lane, None)
            _widths.pop(lane, None)
            if pool is not None:
                _quit(pool)


def stop():
    """Every pool ended (the script finishes): queued work is cancelled, running work ends by itself."""
    with _lock:
        pools = list(_pools.values())
        _pools.clear()
        _widths.clear()
    for pool in pools:
        try:
            pool.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            pool.shutdown(wait=False)
        except Exception:
            pass


def _size(items, workers):
    return max(1, min(int((workers if workers else options.parallel_workers()) or 1), len(items), MOST))


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] ' + text, xbmc.LOGWARNING)
    except Exception:
        pass


def _cancel(futures):
    for future in list(futures):
        try:
            future.cancel()
        except Exception:
            pass


def _one(func, item):
    try:
        return (item, func(item))
    except Exception as exc:
        return (item, exc)


def all_at_once(func, items, workers=None, timeout=None, lane='default'):
    if not items:
        return []
    pool = pool_for(_size(items, workers), lane)
    futures = {}
    try:
        for index, item in enumerate(items):
            futures[pool.submit(func, item)] = index
    except Exception as exc:
        _cancel(futures)
        if isinstance(exc, RuntimeError):
            try:
                reset(lane)
            except Exception:
                pass
            _log('run_parallel fell back to serial scan: %s' % exc)
        return [_one(func, item) for item in items]
    results = [None] * len(items)
    waiting = set(futures)
    try:
        for future in (as_completed(futures, timeout=timeout) if timeout else as_completed(futures)):
            waiting.discard(future)
            index = futures[future]
            try:
                results[index] = (items[index], future.result(timeout=0.1))
            except Exception as exc:
                results[index] = (items[index], exc)
    except Exception as exc:   # the timeout (or anything else): the unfinished ones carry it
        for future in waiting:
            future.cancel()
            index = futures.get(future)
            if index is not None and results[index] is None:
                results[index] = (items[index], exc)
    return [row if row is not None else (items[index], TimeoutError('parallel job skipped'))
            for index, row in enumerate(results)]


def each_parallel(func, items, workers=None, timeout=None, lane='default'):
    if not items:
        return
    pool = pool_for(_size(items, workers), lane)
    futures = {}
    until = time.monotonic() + float(timeout) if timeout else None

    def one_by_one():
        for item in items:
            if until is not None and time.monotonic() >= until:
                return
            yield _one(func, item)
    try:
        for index, item in enumerate(items):
            futures[pool.submit(func, item)] = index
    except Exception as exc:
        _cancel(futures)
        if isinstance(exc, RuntimeError):
            try:
                reset(lane)
            except Exception:
                pass
            _log('iter_parallel fell back to serial scan: %s' % exc)
        for row in one_by_one():
            yield row
        return
    waiting = set(futures)
    try:
        for future in (as_completed(futures, timeout=timeout) if timeout else as_completed(futures)):
            waiting.discard(future)
            index = futures[future]
            try:
                yield (items[index], future.result(timeout=0.1))
            except Exception as exc:
                yield (items[index], exc)
    except Exception:
        return
    finally:
        _cancel(waiting)
        waiting.clear()


class JobRace(object):
    """Results in the order they finish, read by polling (a UI loop checks its own timers
    every 100 ms instead of blocking on the slowest add-on); the live work can be handed to
    another reader (the source window's refresh), and cancelled."""

    def __init__(self, func, items, workers=None, timeout=None, lane='default'):
        self.items = list(items or [])
        self.lane = str(lane or 'default').strip().lower()[:32] or 'default'
        self.deadline = time.monotonic() + max(0.0, float(timeout)) if timeout not in (None, '') else None
        self._func = func
        self._futures = {}
        self._next = 0
        self._serial = False
        self._cancelled = False
        if not self.items:
            return
        try:
            try:
                pool = pool_for(_size(self.items, workers), self.lane)
            except TypeError:
                pool = pool_for(_size(self.items, workers))
            for index, item in enumerate(self.items):
                self._futures[pool.submit(func, item)] = index
        except Exception as exc:
            _cancel(self._futures)
            self._futures.clear()
            self._serial = True
            reset(self.lane)
            _log('%s parallel race fell back to serial: %s' % (self.lane, exc))

    def _left(self):
        return None if self.deadline is None else max(0.0, self.deadline - time.monotonic())

    @property
    def expired(self):
        left = self._left()
        return left is not None and left <= 0.0

    @property
    def done(self):
        if self._cancelled or self.expired:
            return True
        return self._next >= len(self.items) if self._serial else not self._futures

    def pending_items(self):
        if self._serial:
            return list(self.items[self._next:])
        return [self.items[index] for index in sorted(self._futures.values())]

    def poll(self, max_wait=0.1):
        """Every result ready now, waiting at most max_wait (never longer than the deadline)."""
        if self.done:
            return []
        wait = max(0.0, float(max_wait or 0.0))
        left = self._left()
        if left is not None:
            wait = min(wait, left)
        if self._serial:
            if self._next >= len(self.items) or self.expired:
                return []
            item = self.items[self._next]
            self._next += 1
            return [_one(self._func, item)]
        finished, _ = wait_for_first(set(self._futures), timeout=wait, return_when=FIRST_COMPLETED)
        rows = []
        for future in sorted(finished, key=lambda f: self._futures.get(f, 0)):
            index = self._futures.pop(future)
            try:
                rows.append((self.items[index], future.result(timeout=0)))
            except Exception as exc:
                rows.append((self.items[index], exc))
        return rows

    def each_done(self, timeout=None, poll_interval=0.1):
        until = time.monotonic() + max(0.0, float(timeout)) if timeout not in (None, '') else None
        step = max(0.01, float(poll_interval or 0.1))
        while not self.done:
            wait = step
            if until is not None:
                left = until - time.monotonic()
                if left <= 0:
                    return
                wait = min(step, left)
            for row in self.poll(wait):
                yield row

    def cancel(self):
        self._cancelled = True
        _cancel(self._futures)
        self._futures.clear()


def begin_race(func, items, workers=None, timeout=None, lane='default'):
    return JobRace(func, items, workers=workers, timeout=timeout, lane=lane)
