# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Add-on answers kept: in memory (bounded by size) and on disk (http_cache/).

Memory holds at most MEMORY_ENTRIES answers and MEMORY_BYTES in all (an answer's JSON
size counts; one above ONE_ANSWER_MAX stays on disk only) - whole decoded catalog
pages once held hundreds of MiB on a box. The least recently used go first.

An answer past its lifetime but younger than twice that is still shown at once (`stale`)
while REFRESH_WORKERS fetch it again in the background (at most REFRESH_MAX at a time,
never two for one address): the first visit after expiry no longer waits."""
import hashlib
import json
import os
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

from ..paths import profile_path

FOLDER = os.path.join(profile_path(), 'http_cache')
MEMORY_ENTRIES = 256
MEMORY_BYTES = 24 * 1024 * 1024
ONE_ANSWER_MAX = 4 * 1024 * 1024
UNKNOWN_SIZE = 64 * 1024
REFRESH_WORKERS = 2
REFRESH_MAX = 16

try:
    os.makedirs(FOLDER, exist_ok=True)   # once here, never per read
except Exception:
    pass


def file_of(url):
    return os.path.join(FOLDER, hashlib.sha1(url.encode('utf-8')).hexdigest() + '.json')


class _Memory(object):
    def __init__(self):
        self.items = OrderedDict()   # url -> (saved at, data, size)
        self.used = 0
        self.lock = threading.RLock()

    def get(self, url, life):
        with self.lock:
            entry = self.items.get(url)
            if not entry:
                return None
            if time.time() - entry[0] > life:
                del self.items[url]
                self.used -= entry[2]
                return None
            self.items.move_to_end(url)
            return entry[1]

    def put(self, url, data, size=None):
        if size is None:
            try:
                size = os.path.getsize(file_of(url))
            except Exception:
                size = UNKNOWN_SIZE
        size = int(size)
        with self.lock:
            self.drop(url)
            if size > ONE_ANSWER_MAX:
                return
            self.items[url] = (time.time(), data, size)
            self.used += size
            while self.items and (len(self.items) > MEMORY_ENTRIES or self.used > MEMORY_BYTES):
                self.used -= self.items.popitem(last=False)[1][2]

    def drop(self, url):
        with self.lock:
            entry = self.items.pop(url, None)
            if entry is not None:
                self.used -= entry[2]

    def drop_where(self, test):
        with self.lock:
            for url in [u for u in self.items if test(u)]:
                self.drop(url)

    def clear(self):
        with self.lock:
            self.items.clear()
            self.used = 0


memory = _Memory()


def fresh(url, life, memory_only=False):
    """The answer when it is younger than `life` seconds (memory, then disk); else None."""
    if life <= 0:
        return None
    found = memory.get(url, life)
    if found is not None or memory_only:
        return found
    path = file_of(url)
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) <= life:
            with open(path, 'r', encoding='utf-8') as handle:
                data = json.load(handle)
            memory.put(url, data)
            return data
    except Exception:
        return None
    return None


def stale(url, window):
    """(the disk copy, its age) when it is younger than `window` seconds; (None, 0) otherwise."""
    if window <= 0:
        return None, 0
    path = file_of(url)
    try:
        if not os.path.exists(path):
            return None, 0
        age = time.time() - os.path.getmtime(path)
        if age > window:
            return None, 0
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle), age
    except Exception:
        return None, 0


def keep(url, data, memory_only=False, size=None):
    memory.put(url, data, size)
    if not memory_only:
        try:
            with open(file_of(url), 'w', encoding='utf-8') as handle:
                json.dump(data, handle, ensure_ascii=False)
        except Exception:
            pass


class _Refresher(object):
    def __init__(self):
        self.lock = threading.Lock()
        self.running = set()
        self.workers = None

    def later(self, url, fetch):
        """fetch() -> data, run in the background and kept; skipped when this address is under
        way, REFRESH_MAX are, or no thread can be started (the stale answer was already shown)."""
        with self.lock:
            if url in self.running or len(self.running) >= REFRESH_MAX:
                return
            self.running.add(url)

        def work():
            try:
                keep(url, fetch())
            except Exception:
                pass
            finally:
                with self.lock:
                    self.running.discard(url)
        try:
            with self.lock:
                if self.workers is None:
                    self.workers = ThreadPoolExecutor(max_workers=REFRESH_WORKERS)
                workers = self.workers
            workers.submit(work)
        except Exception:
            with self.lock:
                self.running.discard(url)

    def stop(self):
        with self.lock:
            workers, self.workers = self.workers, None
        if workers is not None:
            workers.shutdown(wait=False)


refresher = _Refresher()


def _remove_files():
    removed = 0
    try:
        if os.path.isdir(FOLDER):
            for name in os.listdir(FOLDER):
                path = os.path.join(FOLDER, name)
                try:
                    if os.path.isfile(path):
                        os.remove(path)
                        removed += 1
                except Exception:
                    continue
    except Exception:
        pass
    return removed


def forget_details():
    """Every kept /meta/ answer goes (memory) and the whole disk copy - addresses are hashed,
    so the disk can not tell a detail from a catalog page (a mapping changed: rare)."""
    memory.drop_where(lambda url: '/meta/' in url)
    _remove_files()


def clear():
    memory.clear()
    return _remove_files()
