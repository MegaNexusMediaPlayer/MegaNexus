# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Stream add-ons that keep failing are left out for a while.

FAILURES failures within WINDOW seconds rest an add-on for REST seconds - Play no longer
waits for a broken one. One answer clears it. While something else holds the scan up
(`pause`), timeouts are not the add-ons' fault and are not counted."""
import threading
import time

FAILURES = 3
WINDOW = 60.0
REST = 300.0

_lock = threading.Lock()
_failed = {}       # add-on -> recent failure times
_resting = {}      # add-on -> when it may be asked again
_paused_until = [0.0]


def resting(addon_id):
    if not addon_id:
        return False
    with _lock:
        until = _resting.get(addon_id)
        if not until:
            return False
        if time.time() >= until:   # rested: the next call asks it again
            _resting.pop(addon_id, None)
            _failed.pop(addon_id, None)
            return False
        return True


def answered(addon_id):
    if addon_id:
        with _lock:
            _failed.pop(addon_id, None)
            _resting.pop(addon_id, None)


def pause(seconds=0.0):
    with _lock:
        _paused_until[0] = time.time() + max(0.0, float(seconds or 0))


def failed(addon_id):
    if not addon_id:
        return
    with _lock:
        if time.time() < _paused_until[0]:
            return
    now = time.time()
    with _lock:
        recent = [t for t in _failed.get(addon_id, []) if now - t <= WINDOW] + [now]
        _failed[addon_id] = recent
        if len(recent) < FAILURES:
            return
        _resting[addon_id] = now + REST
    try:
        import xbmc
        xbmc.log('[MegaNexus] provider %s blacklisted for %ds after %d failures'
                 % (addon_id, int(REST), len(recent)), xbmc.LOGINFO)
    except Exception:
        pass
