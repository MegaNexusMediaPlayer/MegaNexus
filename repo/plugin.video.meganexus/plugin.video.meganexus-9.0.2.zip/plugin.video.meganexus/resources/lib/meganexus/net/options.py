# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The network settings, read through a short-lived snapshot.

One screen asks for the timeout, the cache lifetimes and the worker count dozens of
times; each Kodi settings read crosses into C++. The snapshot answers them for
SNAPSHOT_LIFE seconds - shorter than anything a person does after changing a setting."""
import time

from ..paths import addon

SNAPSHOT_LIFE = 2.0
_snapshot = {'at': 0.0, 'values': {}}

# kind -> (at least, at most) seconds of the user's timeout for one request
TIMEOUT_BANDS = {'stream': (4, 8), 'meta': (4, 8), 'search': (3, 6), 'catalog': (2, 3)}


def _read(key):
    try:
        return addon().getSetting(key) or ''
    except Exception:
        return ''


def text(key, default):
    now = time.time()
    if now - _snapshot['at'] > SNAPSHOT_LIFE:
        _snapshot['at'], _snapshot['values'] = now, {}
    values = _snapshot['values']
    if key not in values:
        values[key] = _read(key)
    return values[key] or default


def number(key, default):
    try:
        return max(0, int(float(text(key, str(default)))))
    except Exception:
        return default


def timeout_seconds():
    return max(5, number('timeout', 20))


def catalog_ttl():
    return number('catalog_cache_ttl', 600)


def meta_ttl():
    return number('meta_cache_ttl', 3600)


def stream_ttl():
    """Streams are kept in memory only, 4 to 60 s: going back to the source list reuses them."""
    return min(60, max(4, number('catalog_cache_ttl', 120)))


def fast_timeout(kind='generic'):
    """The timeout of one request of a kind: a folder must not wait for the slowest catalog."""
    base = timeout_seconds()
    if kind in TIMEOUT_BANDS:
        least, most = TIMEOUT_BANDS[kind]
        return max(least, min(base, most))
    return base


def parallel_workers():
    """2 to 4: many Python calls at once ran small boxes out of threads."""
    return max(2, min(4, number('parallel_workers', 4)))


def gzip_enabled():
    return (text('http_gzip', 'true') or 'true').lower() not in ('false', '0', 'no')
