# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""TMDB with the user's own key: pictures, details, titles, IMDb ids and search.

`get` asks the API (a v4 read token goes in the header, a v3 key in the query); without a
key every lookup answers empty and nothing is sent. Answers are kept in
tmdb_direct_cache.sqlite (30 days, 6 hours for "nothing found") with the last 512 in
memory, so a page of cards opens the file once per item at most.

Pictures come in the size a Kodi slot needs (posters w500, backgrounds w1280), English
first, then the user's languages, then pictures without text."""
import json
import os
import sqlite3
import time
from urllib.parse import quote, urlencode

import xbmc
import xbmcaddon

from .meganexus.paths import profile_path

try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

API_BASE = 'https://api.themoviedb.org/3'
PICTURE_SIZES = {'poster': 'w500', 'backdrop': 'w1280', 'logo': 'w500'}
CACHE_FILE = os.path.join(profile_path(), 'tmdb_direct_cache.sqlite')
HIT_LIFE = 30 * 24 * 3600
MISS_LIFE = 6 * 3600
MEMORY = 512
SERIES_WORDS = ('tvshow', 'episode', 'season', 'series', 'show', 'tv', 'anime')
CAST_SHOWN = 15
WRITER_JOBS = ('Writer', 'Screenplay', 'Author')

# 8.1.0: every connection is closed (finally), a failed write is rolled back, the file is
# in WAL mode and a read waits at most READ_WAIT. Kodi's Python 3.11 frees a connection
# that is not closed only when its garbage collector runs: a leaked one kept the file
# locked and every picture lookup of Home and the screensaver waited (a CoreELEC box
# opened MegaNexus after 258 s).
READ_WAIT = 1.0
WRITE_WAIT = 5.0
_made = [False]
_folder = [False]
_memory = {}            # key -> answer, oldest first
_absent = {}            # 8.1.3: key -> when a miss may be looked for on the disk again
ABSENT_LIFE = 120.0     # seconds a miss is remembered (a write clears it at once)


def setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


def api_key():
    return setting('tmdb_api_key', '').strip()


def _wait():
    try:
        return max(4, int(setting('timeout', '20') or '20'))
    except Exception:
        return 12


def kind_of(media_type):
    return 'tv' if str(media_type or 'movie').strip().lower() in SERIES_WORDS else 'movie'


def _languages():
    """English first (its pictures are the clean ones), the user's languages, then none."""
    chosen = (setting('preferred_subtitle_langs', 'en') or 'en').strip()
    order = []
    for lang in ['en'] + [part.strip().lower().replace('_', '-') for part in chosen.split(',') if part.strip()] + ['null', '']:
        if lang not in order:
            order.append(lang)
    return order


def _with_text(langs):
    return ','.join([lang for lang in langs if lang and lang != 'null'] + ['null'])


# ---- kept answers --------------------------------------------------------------------------


def _open(wait=WRITE_WAIT):
    # 8.1.3: the folder is made once, not on every connection. This is called per card
    # (a row of 17 cards asks for 17 pictures) and the three syscalls it costs on the
    # Cube's eMMC were a part of the paint that stood still.
    if not _folder[0]:
        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        _folder[0] = True
    conn = sqlite3.connect(CACHE_FILE, timeout=wait)
    if not _made[0]:
        try:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute('CREATE TABLE IF NOT EXISTS art_cache (cache_key TEXT PRIMARY KEY,'
                         ' expires_at INTEGER NOT NULL, payload TEXT NOT NULL)')
            conn.commit()
            _made[0] = True
        except Exception:
            conn.close()
            raise
    return conn


def _remember(key, value):
    _memory.pop(key, None)
    _absent.pop(key, None)
    _memory[key] = value
    while len(_memory) > MEMORY:
        _memory.pop(next(iter(_memory)))


def kept(key, memory_only=False):
    """A kept answer still in date, or None (a read waits READ_WAIT at most, never writes;
    an expired row is replaced when the answer is fetched again).

    8.1.3: ``memory_only`` answers from RAM alone - what a screen being drawn asks for,
    where opening the file for a card it does not have costs more than the picture is
    worth. A miss is remembered for ABSENT_LIFE, so the same card drawn again does not
    open the file once more for an answer that is not there."""
    if key in _memory:
        return _memory[key]
    if memory_only:
        return None
    if _absent.get(key, 0) > time.monotonic():
        return None
    try:
        conn = _open(READ_WAIT)
    except Exception:
        return None
    try:
        row = conn.execute('SELECT expires_at, payload FROM art_cache WHERE cache_key=?', (key,)).fetchone()
        if not row or int(row[0] or 0) < int(time.time()):
            _absent[key] = time.monotonic() + ABSENT_LIFE
            while len(_absent) > MEMORY * 4:
                _absent.pop(next(iter(_absent)))
            return None
        value = json.loads(row[1] or '{}')
        _remember(key, value)
        return value
    except Exception:
        return None
    finally:
        conn.close()


def keep(key, value, life):
    value = value or {}
    _remember(key, value)
    try:
        conn = _open()
    except Exception:
        return
    try:
        conn.execute('INSERT OR REPLACE INTO art_cache(cache_key, expires_at, payload) VALUES (?, ?, ?)',
                     (key, int(time.time() + max(60, int(life or MISS_LIFE))), json.dumps(value, ensure_ascii=False)))
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
    finally:
        conn.close()


# ---- the API -------------------------------------------------------------------------------


def get(path, params=None, timeout=None):
    """TMDB's answer to `path` ({} without a key or for an empty body)."""
    from urllib.request import Request, urlopen     # not on the card-drawing import path
    key = api_key()
    if not key:
        return {}
    query = dict(params or {})
    headers = {'Accept': 'application/json',
               'User-Agent': 'MegaNexus/%s (Kodi)' % (ADDON.getAddonInfo('version') or '8.1.0')}
    if key.startswith('eyJ') and len(key) > 60:
        headers['Authorization'] = 'Bearer ' + key        # a v4 read access token
    else:
        query['api_key'] = key
    address = API_BASE + path + ('?' + urlencode(query) if query else '')
    with urlopen(Request(address, headers=headers), timeout=_wait() if timeout is None else max(1.0, float(timeout))) as answer:
        body = answer.read().decode('utf-8', 'ignore')
    return json.loads(body) if body else {}


def picture(path, kind='poster'):
    """A TMDB picture address in the size for `kind` (poster / backdrop / logo); full
    addresses stay as they are, an SVG is asked for as PNG (Kodi draws no SVG)."""
    path = str(path or '').strip()
    if not path or path.startswith(('http://', 'https://')):
        return path
    if path.lower().endswith('.svg'):
        path = path[:-4] + '.png'
    return 'https://image.tmdb.org/t/p/%s%s' % (PICTURE_SIZES.get(kind, 'w500'), path)


def _best(rows, langs):
    """The picture in the most wanted language, then the best voted, the largest."""
    def rank(row):
        row = row or {}
        lang = str(row.get('iso_639_1') or '').strip().lower()
        base = lang.split('-')[0] if lang else ''
        place = next((index for index, wanted in enumerate(langs)
                      if lang == str(wanted or '').strip().lower()
                      or (base and base == str(wanted or '').strip().lower().split('-')[0])), None)
        if place is None:
            place = len(langs) + (10 if lang else 1)
        return (place, -float(row.get('vote_average') or 0.0), -int(row.get('width') or 0),
                -int(row.get('height') or 0), -float(row.get('vote_count') or 0.0))
    rows = rows or []
    return min(rows, key=rank) if rows else {}


def _picked(images, langs):
    """{poster, fanart, landscape, clearlogo} from an /images answer."""
    poster = picture((_best(images.get('posters') or [], langs) or {}).get('file_path') or '', 'poster')
    backdrop = picture((_best(images.get('backdrops') or [], langs) or {}).get('file_path') or '', 'backdrop')
    logo = picture((_best(images.get('logos') or [], langs) or {}).get('file_path') or '', 'logo')
    return {'poster': poster, 'fanart': backdrop, 'landscape': backdrop, 'clearlogo': logo}


# ---- finding the TMDB id ---------------------------------------------------------------------


def id_for_imdb(imdb_id, media_type):
    imdb_id = str(imdb_id or '').strip()
    if not imdb_id:
        return ''
    try:
        found = get('/find/%s' % quote(imdb_id), {'external_source': 'imdb_id'}) or {}
    except Exception as exc:
        xbmc.log('[MegaNexus] TMDB imdb lookup failed: %s' % exc, xbmc.LOGDEBUG)
        return ''
    rows = found.get('tv_results' if kind_of(media_type) == 'tv' else 'movie_results') or []
    return str(rows[0].get('id') or '') if rows else ''


def _id_by_title(title, year, media_type):
    title = str(title or '').strip()
    if not title:
        return ''
    kind = kind_of(media_type)
    params = {'query': title}
    year = str(year or '').strip()
    if year.isdigit():
        params['year' if kind == 'movie' else 'first_air_date_year'] = year
    try:
        found = get('/search/%s' % kind, params) or {}
    except Exception as exc:
        xbmc.log('[MegaNexus] TMDB search failed: %s' % exc, xbmc.LOGDEBUG)
        return ''
    rows = found.get('results') or []
    return str(rows[0].get('id') or '') if rows else ''


def find_id(tmdb_id='', imdb_id='', media_type='movie', title='', year=''):
    """The TMDB id as given, else by IMDb id, else by title (and year)."""
    tmdb_id = str(tmdb_id or '').strip()
    if tmdb_id.isdigit():
        return tmdb_id
    imdb_id = str(imdb_id or '').strip()
    return (imdb_id and id_for_imdb(imdb_id, media_type)) or _id_by_title(title, year, media_type)


def _item_key(prefix, kind, tmdb_id, imdb_id, title, year):
    return '%s:%s:%s:%s:%s:%s' % (prefix, kind, tmdb_id or '', imdb_id or '', title or '', year or '')


# ---- search --------------------------------------------------------------------------------


def _found_row(row):
    kind = row.get('media_type') or ''
    if kind not in ('movie', 'tv'):
        return None
    film = kind == 'movie'
    date = row.get('release_date' if film else 'first_air_date')
    poster, backdrop = row.get('poster_path'), row.get('backdrop_path')
    return {'media_type': 'movie' if film else 'series', 'tmdb_id': str(row.get('id') or ''),
            'title': row.get('title' if film else 'name') or '',
            'original_title': row.get('original_title' if film else 'original_name') or '',
            'year': date[:4] if date and len(date) >= 4 and date[:4].isdigit() else '',
            'overview': row.get('overview') or '',
            'poster': picture(poster, 'poster') if poster else '',
            'backdrop': picture(backdrop, 'backdrop') if backdrop else '',
            'rating': row.get('vote_average') or 0.0}


def find_any(query, limit=40):
    """Films and series for a query, in TMDB's order (people left out)."""
    query = str(query or '').strip()
    if not query or not api_key():
        return []
    language = 'en-US'
    key = 'search_multi:%s:%s' % (language, query.casefold())
    found = kept(key)
    if found is not None:
        return found or []
    try:
        answer = get('/search/multi', {'query': query, 'include_adult': 'false', 'language': language},
                     timeout=min(float(_wait()), 6.0)) or {}
    except Exception as exc:
        xbmc.log('[MegaNexus] TMDB search_multi failed: %s' % exc, xbmc.LOGDEBUG)
        return []
    rows = [row for row in map(_found_row, (answer.get('results') or [])[:max(1, int(limit))]) if row]
    keep(key, rows, HIT_LIFE // 4 if rows else MISS_LIFE)
    return rows


def find_titles(query, limit=40):
    """The search as Stremio-shaped items for the unified search."""
    metas = []
    for row in find_any(query, limit=limit) or []:
        tmdb_id = str(row.get('tmdb_id') or '').strip()
        if tmdb_id:
            backdrop, year = row.get('backdrop') or '', row.get('year') or ''
            metas.append({'id': 'tmdb:' + tmdb_id, 'type': row.get('media_type') or 'movie',
                          'name': row.get('title') or '', 'original_title': row.get('original_title') or '',
                          'moviedb_id': tmdb_id, 'year': year, 'releaseInfo': year,
                          'description': row.get('overview') or '', 'poster': row.get('poster') or '',
                          'background': backdrop, 'fanart': backdrop, 'imdbRating': row.get('rating') or 0.0,
                          '_backend': 'tmdb'})
    return metas


# ---- ids and titles ------------------------------------------------------------------------


def imdb_of(tmdb_id, media_type='movie', timeout=None):
    """The IMDb id of a TMDB item (stream add-ons are asked by IMDb id)."""
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id.isdigit() or not api_key():
        return ''
    kind = kind_of(media_type)
    key = 'imdb_for:%s:%s' % (kind, tmdb_id)
    found = kept(key)
    if found is not None:
        return found or ''
    try:
        imdb = ((get('/%s/%s/external_ids' % (kind, tmdb_id), timeout=timeout) or {}).get('imdb_id') or '').strip()
    except Exception:
        imdb = ''
    keep(key, imdb, HIT_LIFE if imdb else MISS_LIFE)
    return imdb


def _add_titles(titles, row, fields):
    for field in fields:
        value = str(row.get(field) or '').strip()
        if value and value.casefold() not in [title.casefold() for title in titles]:
            titles.append(value)


def titles_in_english(tmdb_id, media_type='movie'):
    """English and original titles of a TMDB item: a media server catalogues by these, not by
    the translated title (or "Episode 16") the list showed."""
    tmdb_id = str(tmdb_id or '').strip()
    kind = kind_of(media_type)
    if not tmdb_id.isdigit() or not api_key():
        return []
    key = 'en_titles:%s:%s' % (kind, tmdb_id)
    found = kept(key)
    if found is not None:
        return list(found or [])
    titles = []
    try:
        _add_titles(titles, get('/%s/%s' % (kind, tmdb_id), params={'language': 'en-US'}) or {},
                    ('title', 'name', 'original_title', 'original_name'))
    except Exception:
        titles = []
    keep(key, titles, HIT_LIFE if titles else MISS_LIFE)
    return list(titles)


def titles_by_imdb(imdb_id, media_type='movie'):
    """English and original titles by IMDb id alone (items without a TMDB id); an episode's id
    brings its show's name."""
    imdb_id = str(imdb_id or '').strip()
    if not imdb_id.startswith('tt') or not api_key():
        return []
    kind = kind_of(media_type)
    key = 'find_titles:%s:%s' % (kind, imdb_id)
    found = kept(key)
    if found is not None:
        return list(found or [])
    titles = []
    try:
        answer = get('/find/%s' % imdb_id, params={'external_source': 'imdb_id', 'language': 'en-US'}) or {}
        rows = list(answer.get('tv_results' if kind == 'tv' else 'movie_results') or []) or (
            list(answer.get('tv_episode_results') or []) + list(answer.get('tv_results') or [])
            + list(answer.get('movie_results') or []))
        for row in rows[:2]:
            _add_titles(titles, row, ('title', 'name', 'original_title', 'original_name', 'show_name'))
    except Exception:
        titles = []
    keep(key, titles, HIT_LIFE if titles else MISS_LIFE)
    return list(titles)


# ---- pictures and details --------------------------------------------------------------------


def art_cached_only(tmdb_id='', imdb_id='', media_type='movie', title='', year=''):
    """Kept pictures only - a media-server list never waits on TMDB (it warms them elsewhere)."""
    found = kept(_item_key('art', kind_of(media_type), tmdb_id, imdb_id, title, year))
    return found if isinstance(found, dict) else {}


def art_for(tmdb_id='', imdb_id='', media_type='movie', title='', year='', langs=None, cached_only=False):
    """Poster, background and logo of a title (with its tmdb / imdb / tvdb ids). `langs`
    orders the picture languages ('null' = without text); `cached_only` never asks TMDB
    and answers None when nothing is kept."""
    kind = kind_of(media_type)
    key = _item_key('art', kind, tmdb_id, imdb_id, title, year) + (':' + ','.join(langs) if langs else '')
    found = kept(key, memory_only=cached_only == 'memory')
    if found is not None:
        return found
    if cached_only:
        return None
    if not api_key():
        return {}
    tmdb = find_id(tmdb_id=tmdb_id, imdb_id=imdb_id, media_type=kind, title=title, year=year)
    if not tmdb:
        keep(key, {}, MISS_LIFE)
        return {}
    langs = list(langs or _languages())
    try:
        images = get('/%s/%s/images' % (kind, tmdb), {'include_image_language': _with_text(langs)}) or {}
    except Exception as exc:
        xbmc.log('[MegaNexus] TMDB images failed: %s' % exc, xbmc.LOGDEBUG)
        images = {}
    try:
        ids = get('/%s/%s/external_ids' % (kind, tmdb)) or {}
    except Exception:
        ids = {}
    art = dict({'tmdb_id': tmdb, 'imdb_id': str(ids.get('imdb_id') or imdb_id or '').strip(),
                'tvdb_id': str(ids.get('tvdb_id') or '').strip()}, **_picked(images, langs))
    keep(key, art, HIT_LIFE if (art['poster'] or art['fanart'] or art['clearlogo']) else MISS_LIFE)
    return art


def _plot(detail, langs):
    """The plot in the first of the user's languages TMDB has, else its default one, else English."""
    by_language = {}
    for row in ((detail or {}).get('translations') or {}).get('translations') or []:
        lang = str(row.get('iso_639_1') or '').strip().lower()
        text = str((row.get('data') or {}).get('overview') or '').strip()
        if lang and text:
            by_language.setdefault(lang, text)
    for lang in langs or []:
        short = str(lang or '').strip().lower().split('-')[0]
        if short and short in by_language:
            return by_language[short]
    return str((detail or {}).get('overview') or '').strip() or by_language.get('en', '')


def _number(value, kind, default):
    try:
        return kind(value or 0)
    except Exception:
        return default


def _names(rows):
    return [str(row.get('name')).strip() for row in rows or [] if row.get('name')]


def _people(credits):
    cast = [{'name': str(person.get('name') or '').strip(), 'role': str(person.get('character') or '').strip(),
             'thumbnail': picture(person.get('profile_path') or '', 'logo')}
            for person in (credits.get('cast') or [])[:CAST_SHOWN] if str(person.get('name') or '').strip()]
    director, writers = '', []
    for person in credits.get('crew') or []:
        name, job = str(person.get('name') or '').strip(), str(person.get('job') or '').strip()
        if not name:
            continue
        if job == 'Director' and not director:
            director = name
        elif job in WRITER_JOBS and name not in writers:
            writers.append(name)
    return cast, director, writers


def _first_country(detail):
    countries = detail.get('production_countries') or detail.get('origin_country') or []
    if not isinstance(countries, list) or not countries:
        return ''
    first = countries[0]
    return str(first.get('name') if isinstance(first, dict) else first or '').strip()


def meta_of(tmdb_id='', imdb_id='', media_type='movie', title='', year=''):
    """A title's whole details in one request (credits, pictures, ids and translations
    appended): plot, year, genres, rating, runtime, studios, cast, crew and pictures in
    MegaNexus' item fields; {} without a key or an answer (the add-on's details stay)."""
    kind = kind_of(media_type)
    key = _item_key('meta', kind, tmdb_id, imdb_id, title, year)
    found = kept(key)
    if found is not None:
        return found
    if not api_key():
        return {}
    tmdb = find_id(tmdb_id=tmdb_id, imdb_id=imdb_id, media_type=kind, title=title, year=year)
    if not tmdb:
        keep(key, {}, MISS_LIFE)
        return {}
    langs = _languages()
    try:
        detail = get('/%s/%s' % (kind, tmdb), {
            'language': next((lang for lang in langs if lang and lang != 'null'), 'en'),
            'append_to_response': 'credits,images,external_ids,translations',
            'include_image_language': _with_text(langs)}) or {}
    except Exception as exc:
        xbmc.log('[MegaNexus] TMDB meta_for failed: %s' % exc, xbmc.LOGDEBUG)
        detail = {}
    if not detail:
        keep(key, {}, MISS_LIFE)
        return {}
    series = kind == 'tv'
    ids = detail.get('external_ids') or {}
    names = ('name', 'original_name') if series else ('title', 'original_title')
    name = str(detail.get(names[0]) or detail.get(names[1]) or title or '').strip()
    date = str(detail.get('first_air_date' if series else 'release_date') or '').strip()
    rating = _number(detail.get('vote_average'), lambda value: round(float(value), 1), 0.0)
    if series:
        lengths = detail.get('episode_run_time') or []
        runtime = _number(lengths[0], int, 0) if isinstance(lengths, list) and lengths else 0
    else:
        runtime = _number(detail.get('runtime'), int, 0)
    cast, director, writers = _people(detail.get('credits') or {})
    plot = _plot(detail, langs)
    meta = dict({
        'tmdb_id': str(tmdb), 'imdb_id': str(ids.get('imdb_id') or imdb_id or '').strip(),
        'tvdb_id': str(ids.get('tvdb_id') or '').strip(), 'name': name, 'title': name,
        'year': date[:4] if date[:4].isdigit() else str(year or '').strip(),
        'description': plot, 'overview': plot, 'genres': _names(detail.get('genres')),
        'imdbRating': ('%.1f' % rating) if rating else '', 'rating': rating,
        'vote_count': _number(detail.get('vote_count'), int, 0), 'runtime': runtime,
        'studio': _names(detail.get('networks' if series else 'production_companies')),
        'country': _first_country(detail), 'director': director, 'writer': writers, 'cast': cast,
        'tagline': str(detail.get('tagline') or '').strip(), 'status': str(detail.get('status') or '').strip(),
    }, **_picked(detail.get('images') or {}, langs))
    keep(key, meta, HIT_LIFE if (plot or meta['poster'] or meta['genres'] or cast) else MISS_LIFE)
    return meta
