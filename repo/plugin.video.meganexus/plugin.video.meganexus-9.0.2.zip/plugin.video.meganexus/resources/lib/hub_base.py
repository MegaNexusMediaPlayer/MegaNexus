# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.

import os
import re
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from urllib.parse import urlencode

from .texts import tr


try:
    from .settings_snapshot import cached_addon as _cached_addon
except Exception:
    try:
        from settings_snapshot import cached_addon as _cached_addon
    except Exception:
        _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

try:
    HANDLE = int(sys.argv[1])
except Exception:
    HANDLE = -1
BASE_URL = 'plugin://%s/' % (ADDON.getAddonInfo('id') or 'plugin.video.meganexus')


def refresh_invocation():
    global HANDLE
    try:
        HANDLE = int(sys.argv[1])
    except Exception:
        HANDLE = -1
    return HANDLE

WINDOW_ID = 10000
PROP = 'meganexus.play_context'
SERIES_PROP_PREFIX = 'meganexus.series.'
SUBS_DIR = xbmcvfs.translatePath('special://temp/meganexus_subs/')


# ─────────────────────────────────────────────────────────────────────
# Static lookup tables.
# ─────────────────────────────────────────────────────────────────────
FILTER_NAMES = {
    'search': 'Search', 'sort': 'Sort', 'sortBy': 'Sort', 'sortby': 'Sort', 'orderBy': 'Sort', 'orderby': 'Sort', 'order': 'Order',
    'genre': 'Genre', 'availability': 'Availability', 'year': 'Year', 'language': 'Language', 'country': 'Country',
    'contentRating': 'Rating', 'studio': 'Studio', 'network': 'Network', 'collection': 'Collection', 'unwatched': 'Unwatched',
    'lastRelease': 'Last Release', 'last_release': 'Last Release', 'lastAdded': 'Last Added', 'last_added': 'Last Added',
}

# what some add-ons leave in names (after html.unescape) and what it becomes, in this order
HEX_ENTITIES = list(zip(
    ('&#x26;', '&#x27;', '&#xC6;', '&#xC7;', '&#xF4;', '&#xE9;', '&#xEB;', '&#xED;', '&#xEE;', '&#xA2;', '&#xE2;', '&#xEF;', '&#xE1;', '&#xE8;', '%2E', '&frac12;', '&#xBD;', '&#xB3;', '&#xB0;', '&amp;', '&#xB7;', '&#xE4;', 'â\x80\x99'),
    ('&', "'", 'AE', 'C', 'o', 'e', 'e', 'i', 'i', 'c', 'a', 'i', 'a', 'e', '.', '%BD', '%BD', '%B3', '%B0', '&', '.', 'A', '')))
# characters that end a word in a title (or go)
SPECIAL_BLANKS = list(zip(
    ('"', '/', ':', '<', '>', '?', '\\', '|', '%BD;', '%B3;', '%B0;', "'", ' - ', '.', '!', ';', ','),
    (' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '', ' ', ' ', '', '', ' ')))


# what is taken out of an add-on's stream name: Kodi's colour/bold tags, icon and emoji
# characters, flag pairs, [bracketed] notes and runs of spaces; and what is read from it
COLOR_TAG_RE, BRACKET_RE = re.compile(r'\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|LIGHT)\b[^\]]*\]', re.I), re.compile(r'\[[^\]]*\]')
STREAM_ICON_RE = re.compile('[%s]' % ''.join((r'\u2500-\u257F', r'\u2580-\u259F', r'\u25A0-\u25FF', r'\u2600-\u27BF',
                                              r'\uE000-\uF8FF', r'\U0001F300-\U0001FAFF')))
REGIONAL_FLAG_RE, MULTI_WS_RE = re.compile(r'[\U0001F1E6-\U0001F1FF]{2}'), re.compile(r'\s+')
SIZE_RE, YEAR_RE = re.compile(r'(\d+(?:\.\d+)?\s*(?:GB|MB|GiB|MiB))', re.I), re.compile(r'^(\d{4})')


def build_url(**query):
    return BASE_URL + '?' + urlencode(query)


# ─────────────────────────────────────────────────────────────────────
# Where a click on a source goes: one address, three roads.
# ─────────────────────────────────────────────────────────────────────
SHOW_WORDS = ('series', 'anime', 'show', 'tv')


def is_show(media_type=''):
    return str(media_type or '').strip().lower() in SHOW_WORDS


def _given(value):
    """A number that says something: 0 and '0' are no resume and no episode."""
    return value not in (None, '', 0, '0')


def source_list_url(media_type='movie', canonical_id='', title='', season='', episode='',
                    video_id='', resume_seconds='', resume_percent='',
                    preferred_provider_name='', source_provider_id='', source_mode=''):
    """The sources of a film, of one episode, or a show's seasons when no episode is named.

    The extras ride along on either road, each only when it says something - an
    address is also what Kodi remembers a folder by.
    """
    kind = str(media_type or 'movie').strip().lower()
    shown = title or canonical_id
    if not (_given(season) and _given(episode)):
        if is_show(kind):
            # Nothing names an episode yet, and the seasons are where one is chosen.
            return build_url(action='series_meta', media_type='series', canonical_id=canonical_id,
                             title=shown, source_provider_id=source_provider_id or '')
        args = {'action': 'streams', 'media_type': kind or 'movie', 'canonical_id': canonical_id, 'title': shown}
    else:
        args = {'action': 'episode_streams', 'canonical_id': canonical_id, 'video_id': video_id or canonical_id,
                'season': str(season), 'episode': str(episode), 'title': shown,
                'media_type': 'series' if is_show(kind) else kind}
    for key, value in (('resume_seconds', resume_seconds), ('resume_percent', resume_percent)):
        if _given(value):
            args[key] = str(value)
    for key, value in (('preferred_provider_name', preferred_provider_name),
                       ('source_provider_id', source_provider_id), ('source_mode', source_mode)):
        if value:
            args[key] = value
    return build_url(**args)


def source_list_url_for(context, resume_seconds='', resume_percent=''):
    """The same address out of a playback context. '' when it could not lead anywhere.

    The caller drops this into Container.Update, where '' does nothing: 8.1.0 returns
    it for a context without a title id, which used to build an address with empty ids
    - a context-menu entry that opened a search for nothing.
    """
    context = context or {}
    if not context.get('canonical_id'):
        return ''
    try:
        return source_list_url(
            media_type=context.get('media_type') or 'movie',
            canonical_id=context.get('canonical_id'),
            title=context.get('title') or context.get('show_title') or context.get('canonical_id') or '',
            season=context.get('season') or '',
            episode=context.get('episode') or '',
            video_id=context.get('video_id') or context.get('canonical_id') or '',
            resume_seconds=resume_seconds if resume_seconds not in (None, '') else context.get('resume_seconds', ''),
            resume_percent=resume_percent if resume_percent not in (None, '') else context.get('resume_percent', ''),
            preferred_provider_name=context.get('provider_name') or '',
            source_provider_id=context.get('source_provider_id') or context.get('meta_target_key') or '',
            source_mode=context.get('source_mode') or '',
        )
    except Exception:
        return ''


def notify(msg):
    xbmcgui.Dialog().notification('MegaNexus', tr(msg), xbmcgui.NOTIFICATION_INFO, 2500)


def error(msg):
    xbmcgui.Dialog().notification('MegaNexus', tr(msg), xbmcgui.NOTIFICATION_ERROR, 3500)


def _get_int_setting(key, default, minimum=None, maximum=None):
    try:
        value = int(ADDON.getSetting(key) or default)
    except Exception:
        value = int(default)
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def _get_bool_setting(key, default=False):
    try:
        raw = (ADDON.getSetting(key) or ('true' if default else 'false')).strip().lower()
    except Exception:
        raw = 'true' if default else 'false'
    return raw in ('true', '1', 'yes', 'on')


def _no_pages():
    try:
        raw = (ADDON.getSetting('hide_pagination_more') or 'true').strip().lower()
    except Exception:
        return False
    return raw in ('true', '1', 'yes', 'on')


def clean_defaults_once():
    """Apply the earlier version clean baseline once for existing installs."""
    try:
        _fresh = xbmcaddon.Addon('plugin.video.meganexus')
    except Exception:
        _fresh = ADDON
    try:
        rev = (_fresh.getSetting('meganexus_defaults_rev') or '').strip()
        if not rev:
            from . import legacy_names
            from .meganexus.paths import profile_path
            try:
                # Same rule as below: never write while Kodi's settings dialog
                # holds its own copy of these values.
                if (not xbmc.getCondVisibility('Window.IsVisible(addonsettings)') and
                        legacy_names.carry_forward(_fresh, profile_path())):
                    rev = (_fresh.getSetting('meganexus_defaults_rev') or '').strip()
            except Exception:
                pass
    except Exception:
        rev = ''
    if rev == '470-release-defaults':
        return
    try:
        if int(rev) >= 510:
            return
    except Exception:
        pass
    try:
        if xbmc.getCondVisibility('Window.IsVisible(addonsettings)'):
            return
    except Exception:
        pass
    if rev == '139-clean-defaults':
        try:
            if (_fresh.getSetting('clean_catalog_view') or '').strip().lower() != 'false':
                ADDON.setSetting('clean_catalog_view', 'false')
        except Exception:
            pass
        try:
            ADDON.setSetting('meganexus_defaults_rev', '470-release-defaults')
        except Exception:
            pass
        return
    defaults = {
        'default_meta_source': 'Native (addon)',
        'clean_catalog_view': 'false',
        'hide_pagination_more': 'true',
        'poster_reliability_mode': 'Always clean (no badges)',
    }
    for key, value in defaults.items():
        try:
            ADDON.setSetting(key, value)
        except Exception as exc:
            try:
                xbmc.log('[MegaNexus] clean defaults setSetting(%s) failed: %s' % (key, exc), xbmc.LOGWARNING)
            except Exception:
                pass
    try:
        ADDON.setSetting('meganexus_defaults_rev', '470-release-defaults')
    except Exception:
        pass
