# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from __future__ import absolute_import

import os
import struct
import sys
import zlib

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
try:
    from .texts import tr
except Exception:
    from resources.lib.texts import tr


_LIB = os.path.dirname(os.path.abspath(__file__))
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)


def _profile_dir():
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('profile'))
    except Exception:
        return xbmc.translatePath('special://profile/addon_data/plugin.video.meganexus')


def _png(pixels, side):
    """A square RGB PNG from its rows of pixels (each row already 3 bytes a pixel)."""
    def part(kind, body):
        return struct.pack('>I', len(body)) + kind + body + struct.pack('>I', zlib.crc32(kind + body) & 0xffffffff)
    head = struct.pack('>IIBBBBB', side, side, 8, 2, 0, 0, 0)          # 8-bit RGB, no interlace
    image = zlib.compress(b''.join(b'\x00' + row for row in pixels), 9)  # each row: filter 0
    return b'\x89PNG\r\n\x1a\n' + part(b'IHDR', head) + part(b'IDAT', image) + part(b'IEND', b'')


def qr_png(data, box_size=8, border=4):
    """A QR code of ``data`` as a picture in the profile (the last one only); its path, or ''.
    The bundled qrcode module (pure Python) makes the code, the PNG is drawn here."""
    try:
        import hashlib
        import qrcode
        code = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=1, border=border)
        code.add_data(data)
        code.make(fit=True)
        dark, light = b'\x00' * 3, b'\xff' * 3
        pixels = []
        for line in code.get_matrix():
            row = b''.join((dark if on else light) * box_size for on in line)
            pixels.extend([row] * box_size)
        picture = _png(pixels, len(pixels))
        text = data.encode('utf-8', 'replace') if isinstance(data, str) else bytes(data)
        folder = _profile_dir()
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, 'plex_link_qr_%s.png' % hashlib.sha1(text).hexdigest()[:10])
        for name in os.listdir(folder):              # the earlier codes go
            if name.startswith('plex_link_qr') and name.endswith('.png') and os.path.join(folder, name) != path:
                try:
                    os.remove(os.path.join(folder, name))
                except OSError:
                    pass
        with open(path + '.tmp', 'wb') as handle:
            handle.write(picture)
        os.replace(path + '.tmp', path)
        return path
    except Exception as exc:
        try:
            xbmc.log('[MegaNexus] QR generation failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return ''


class PlexLinkWindow(xbmcgui.WindowDialog):

    def __init__(self, *args, **kwargs):
        self.cancelled = False
        try:
            qr_path = kwargs.get('qr_path') or ''
            code = kwargs.get('code') or ''
        except Exception:
            qr_path, code = '', ''
        w, h = 900, 460
        x = (1280 - w) // 2
        y = (720 - h) // 2
        self.addControl(xbmcgui.ControlImage(x, y, w, h, '', colorDiffuse='DD000000'))
        if qr_path:
            self.addControl(xbmcgui.ControlImage(x + 40, y + 60, 340, 340, qr_path))
        head = xbmcgui.ControlLabel(x + 410, y + 60, w - 450, 40, 'Link Plex',
                                    textColor='FFFFFFFF')
        self.addControl(head)
        body = xbmcgui.ControlTextBox(x + 410, y + 120, w - 450, 280)
        self.addControl(body)
        body.setText(
            tr('Scan the QR code with your phone camera to open the Plex link page.\n\n'
            'Or open: plex.tv/link\n'
            'and enter the code:\n\n'
            '[B]%s[/B]\n\n'
            'Waiting for confirmation… (Back to cancel)') % code)
        self._body = body

    def set_status(self, text):
        try:
            self._body.setText(text)
        except Exception:
            pass

    def onAction(self, action):  # noqa: N802 (Kodi API)
        try:
            if action.getId() in (9, 10, 92, 216, 247, 257, 275, 61467, 61448):
                self.cancelled = True
                self.close()
        except Exception:
            self.cancelled = True
            self.close()
