# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.0.1: one watch history on every tracking service, each kept the way it keeps it.

What was watched is gathered from Trakt, Simkl and MegaNexus itself; each service is then sent
only what it does not have yet, with the date it was really watched. Nothing is ever taken
away and nothing is sent twice (Trakt counts every play: a film sent again would be a second
viewing). A title is the same title whatever id a service keeps it under (IMDb, TMDB, TVDB).

Anime: Simkl numbers it as it aired (Dragon Ball Z 1-291), the others by TVDB seasons (S1-S9).
Simkl's own episode list puts each one on its TVDB place; sent to Simkl, TVDB places are turned
back by Simkl itself. An anime title with any episode of unknown place is left out both ways.
"""
import time
from datetime import datetime, timezone

BATCH = 1000           # items (films + episodes) per request - WeTrakr takes up to 5,000, the others less said
TRAKT_PAUSE = 1.1      # s between two writes - Trakt allows one a second


class Group(object):
    """The ids of one title, across services: every IMDb / TMDB / TVDB id it is known by."""

    def __init__(self):
        self.root = {}

    def key(self, ids):
        names = []
        for field, prefix in (('imdb', ''), ('tmdb', 'tmdb:'), ('tvdb', 'tvdb:')):
            value = str((ids or {}).get(field) or '').strip()
            if value and value not in ('0', 'None'):
                if field == 'imdb' and not value.startswith('tt'):
                    value = 'tt' + value if value.isdigit() else value
                names.append(value if field == 'imdb' else prefix + value)
        if not names:
            return ''
        top = self.find(names[0])
        for name in names[1:]:
            other = self.find(name)
            if other != top:
                self.root[other] = top
        return top

    def find(self, name):
        path = []
        while self.root.get(name, name) != name:
            path.append(name)
            name = self.root[name]
        for step in path:
            self.root[step] = name
        return name


def _iso(stamp):
    return datetime.fromtimestamp(float(stamp), timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z') if stamp else None


def _epoch(value):
    if not value:
        return 0.0
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).timestamp()
    except ValueError:
        return 0.0


def _ids(raw):
    out = {}
    for field in ('imdb', 'tmdb', 'tvdb'):
        value = str((raw or {}).get(field) or '').strip()
        if value and value not in ('0', 'None'):
            out[field] = int(value) if field != 'imdb' and value.isdigit() else value
    return out


def _keep(store, key, ids, when):
    if not key:
        return
    entry = store.setdefault(key, {'ids': {}, 'at': 0.0})
    entry['ids'].update(ids)
    entry['at'] = max(entry['at'], when or 0.0)


def _from_trakt(group):
    from . import trakt_api, trakt_watched
    films, episodes = {}, {}
    for row in trakt_api.pages('/sync/watched/movies') or []:
        ids = _ids((row.get('movie') or {}).get('ids'))
        _keep(films, group.key(ids), ids, _epoch(row.get('last_watched_at')))
    for row in trakt_watched.shows_with_episodes() or []:
        ids = _ids((row.get('show') or {}).get('ids'))
        key = group.key(ids)
        for season in row.get('seasons') or []:
            for episode in season.get('episodes') or []:
                _keep(episodes, (key, int(season['number']), int(episode['number'])) if key else '', ids,
                      _epoch(episode.get('last_watched_at')))
    return films, episodes


ANIME_MAP = 'simkl_anime_map.json'   # Simkl's anime episodes -> TVDB season/episode, per Simkl id
ANIME_MAP_DAYS = 30


def _anime_map(simkl_id, kept):
    """{absolute episode: (TVDB season, episode)} of one Simkl anime title - Simkl numbers anime as
    they aired in Japan (DBZ 1-291), Trakt, MDBList and MegaNexus by TVDB seasons (DBZ S1-S9).
    Simkl's own episode list gives each one its TVDB place; kept on disk for ANIME_MAP_DAYS.
    None when Simkl has no list for it."""
    from . import simkl_api
    entry = kept.get(str(simkl_id)) or {}
    if entry and time.time() - float(entry.get('at') or 0) < ANIME_MAP_DAYS * 86400:
        return {int(k): tuple(v) for k, v in (entry.get('map') or {}).items()} or None
    try:
        rows = simkl_api._request('/anime/episodes/%s?extended=full' % simkl_id, auth=False, timeout=30)
    except Exception:
        rows = None
    if not isinstance(rows, list):
        return {int(k): tuple(v) for k, v in (entry.get('map') or {}).items()} or None
    found = {}
    for row in rows:
        place = (row or {}).get('tvdb') or {}
        if row.get('type') == 'episode' and row.get('episode') is not None \
                and place.get('season') is not None and place.get('episode') is not None:
            found[int(row['episode'])] = (int(place['season']), int(place['episode']))
    kept[str(simkl_id)] = {'at': time.time(), 'map': {str(k): list(v) for k, v in found.items()}}
    return found or None


def _anime_store(kept=None):
    """The kept anime maps: read (no ``kept``) or written."""
    from .meganexus.paths import profile_path
    import json
    import os
    path = os.path.join(profile_path(), ANIME_MAP)
    if kept is None:
        try:
            with open(path, encoding='utf-8') as handle:
                found = json.load(handle)
            return found if isinstance(found, dict) else {}
        except (OSError, ValueError):
            return {}
    try:
        with open(path + '.part', 'w', encoding='utf-8') as handle:
            json.dump(kept, handle)
        os.replace(path + '.part', path)
    except OSError:
        pass
    return kept


def _from_simkl(group):
    """Simkl's watched films and episodes. ``anime``: the anime titles whose episodes could not
    all be put on their TVDB place - left out both ways, nothing is guessed."""
    from . import simkl_api
    films, episodes, anime, cover = {}, {}, set(), {}
    answer = simkl_api._request('/sync/all-items/movies/completed?extended=full', auth=True, timeout=60) or {}
    for row in answer.get('movies') or []:
        ids = _ids((row.get('movie') or {}).get('ids'))
        _keep(films, group.key(ids), ids, _epoch(row.get('last_watched_at')))
    kept = _anime_store()
    for kind in ('shows', 'anime'):
        answer = simkl_api._request('/sync/all-items/%s/?extended=full&episode_watched_at=yes' % kind, auth=True,
                                    timeout=60) or {}
        for row in answer.get(kind) or []:
            raw = (row.get('show') or {}).get('ids') or {}
            ids = _ids(raw)
            key = group.key(ids)
            if not key:
                continue
            places = None
            if kind == 'anime':
                places = _anime_map(raw.get('simkl'), kept) if raw.get('simkl') else None
                if places is None:
                    anime.add(key)
            def place(season, number):
                """Where Simkl's (season, number) is by TVDB; None when not known for sure."""
                if places is None:
                    return (season, number) if kind != 'anime' else None
                return places.get(number) if season in (None, 0, 1) else None
            # a show watched to the end comes without its episodes, only "262 of 262": every one
            # of them is there; one being watched says how far ("S03E05") - up to there
            if not row.get('seasons'):
                seen, total = int(row.get('watched_episodes_count') or 0), int(row.get('total_episodes_count') or 0)
                last = simkl_api.parse_episode_marker(row.get('last_watched'))
                if row.get('status') == 'completed' or (total and seen >= total):
                    cover[key] = 'all'
                elif last:
                    reach = place(*last)
                    if reach:
                        cover[key] = reach
                    else:
                        anime.add(key)
            for season in row.get('seasons') or []:
                for episode in season.get('episodes') or []:
                    if episode.get('number') is None or (season.get('number') is None and kind != 'anime'):
                        continue
                    at = place(season.get('number'), int(episode['number']))
                    if not at:
                        anime.add(key)       # one episode without a sure place: the title waits
                        continue
                    _keep(episodes, (key,) + tuple(at), ids,
                          _epoch(episode.get('watched_at')) or _epoch(row.get('last_watched_at')))
    _anime_store(kept)
    return films, episodes, anime, cover


def covered(cover, key):
    """The episode is on the service though not listed one by one (Simkl's finished shows)."""
    show, season, number = key
    reach = cover.get(show)
    if reach == 'all':
        return True
    return bool(reach) and season > 0 and (season, number) <= tuple(reach)


def _from_mdblist(group):
    from . import mdblist_tracking
    films, episodes = {}, {}
    data = mdblist_tracking._pages('/sync/watched')
    for row in data.get('movies') or []:
        ids = _ids(((row or {}).get('movie') or {}).get('ids'))
        _keep(films, group.key(ids), ids, _epoch(row.get('last_watched_at')))
    for row in data.get('episodes') or []:
        episode = (row or {}).get('episode') or {}
        ids = _ids(((episode.get('show') or {}).get('ids')))
        key = group.key(ids)
        if key and episode.get('season') is not None and episode.get('number') is not None:
            _keep(episodes, (key, int(episode['season']), int(episode['number'])), ids, _epoch(row.get('last_watched_at')))
    return films, episodes


def _from_wetrakr(group):
    """What WeTrakr has as watched - its kept list (wetrakr_api.watched_items): /sync/last_activities
    at most every 3 hours and the list pulled again only when it changed, as agreed with WeTrakr.
    Their list carries no dates."""
    from . import wetrakr_api
    films, episodes, cover = {}, {}, {}
    for name, item in (wetrakr_api.watched_items() or {}).items():
        kind, _, cid = name.partition('|')
        ids = _ids({'imdb': cid} if cid.startswith('tt') else {'tmdb': cid[5:]} if cid.startswith('tmdb:')
                   else {'tvdb': cid[5:]} if cid.startswith('tvdb:') else {})
        key = group.key(ids)
        if not key:
            continue
        if kind == 'movie':
            if item.get('watched'):
                _keep(films, key, ids, 0.0)
            continue
        for marker in item.get('episodes') or []:
            season, _, number = str(marker).partition(':')
            if season.isdigit() and number.isdigit():
                _keep(episodes, (key, int(season), int(number)), ids, 0.0)
        if item.get('watched') and not item.get('episodes'):
            cover[key] = 'all'
    return films, episodes, cover


def _trakt_pauses(group):
    """Trakt's paused films and episodes: {title or (show, season, episode): pause}."""
    from . import trakt_api
    pauses = {}
    for kind in ('movies', 'episodes'):
        for row in trakt_api.pages('/sync/playback/%s?extended=full' % kind) or []:
            ids = _ids(((row.get('movie') if kind == 'movies' else row.get('show')) or {}).get('ids'))
            key = group.key(ids)
            episode = row.get('episode') or {}
            if not key or (kind == 'episodes' and (episode.get('season') is None or episode.get('number') is None)):
                continue
            place = key if kind == 'movies' else (key, int(episode['season']), int(episode['number']))
            pauses[place] = {'id': row.get('id'), 'ids': ids, 'percent': float(row.get('progress') or 0),
                             'at': _epoch(row.get('paused_at'))}
    return pauses


def _from_here(group, resumes=None, clouds=None):
    """MegaNexus's own watched rows; ``resumes`` (a dict) also gets every resume, newest per title
    or episode, so an end older than one is not sent (see plan); ``clouds`` (a list) every resume
    that came from Nuvio or Stremio, with its key."""
    from .meganexus import progress_db
    from .meganexus.paths import watched_percent
    films, episodes = {}, {}
    for row in progress_db.list_recent_items(limit=100000):
        if not (row.get('event_type') == 'watched' or float(row.get('percent') or 0) >= watched_percent()):
            if resumes is not None:
                _resume(group, resumes, row)
            if clouds is not None and row.get('event_type') == 'account_sync':
                cloud = {}
                _resume(group, cloud, row)
                clouds.extend(cloud.items())
            continue
        cid = str(row.get('canonical_id') or '')
        imdb = str(row.get('imdb_id') or '') or (cid if cid.startswith('tt') else '')
        if row.get('media_type') == 'movie':
            ids = _ids({'imdb': imdb, 'tmdb': row.get('tmdb_id') or (cid[5:] if cid.startswith('tmdb:') else ''),
                        'tvdb': row.get('tvdb_id')})
            _keep(films, group.key(ids), ids, float(row.get('updated_at') or 0))
        elif row.get('season') is not None and row.get('episode') is not None:
            ids = _ids({'imdb': imdb, 'tmdb': row.get('show_tmdb_id') or (cid[5:] if cid.startswith('tmdb:') else ''),
                        'tvdb': row.get('tvdb_id')})
            key = group.key(ids)
            _keep(episodes, (key, int(row['season']), int(row['episode'])) if key else '', ids,
                  float(row.get('updated_at') or 0))
    return films, episodes


def _resume(group, resumes, row):
    cid = str(row.get('canonical_id') or '')
    imdb = str(row.get('imdb_id') or '') or (cid if cid.startswith('tt') else '')
    film = row.get('media_type') == 'movie'
    ids = _ids({'imdb': imdb, 'tmdb': (row.get('tmdb_id') if film else row.get('show_tmdb_id'))
                or (cid[5:] if cid.startswith('tmdb:') else ''), 'tvdb': row.get('tvdb_id')})
    key = group.key(ids)
    if not key or (not film and (row.get('season') is None or row.get('episode') is None)):
        return
    place = key if film else (key, int(row['season']), int(row['episode']))
    if float(row.get('updated_at') or 0) > float((resumes.get(place) or {}).get('updated_at') or 0):
        resumes[place] = dict(row, _ids=ids)


def _canon(group, store):
    """The same title under ids met only later becomes one entry."""
    out = {}
    for key, entry in store.items():
        top = (group.find(key[0]),) + tuple(key[1:]) if isinstance(key, tuple) else group.find(key)
        _keep(out, top, entry['ids'], entry['at'])
    return out


def services():
    """The tracking services signed in here that keep a watch history."""
    from . import mdblist_tracking, simkl_api, trakt_api
    found = []
    from . import wetrakr_api
    for name, ready in (('trakt', lambda: trakt_api.authorized()), ('simkl', lambda: simkl_api.authorized()),
                        ('mdblist', lambda: mdblist_tracking.enabled()),
                        ('wetrakr', lambda: wetrakr_api.enabled() and wetrakr_api.authorized())):
        try:
            if ready():
                found.append(name)
        except Exception:
            pass
    return tuple(found)


NAMES = {'trakt': 'Trakt', 'simkl': 'Simkl', 'mdblist': 'MDBList', 'wetrakr': 'WeTrakr'}


def plan(services=('trakt', 'simkl')):
    """{service: {'films': [...], 'episodes': [...]}} - what each one is missing, with ids and
    the date it was watched; plus 'anime_left_out'."""
    group = Group()
    have, anime, covers = {}, set(), {}
    if 'trakt' in services:
        have['trakt'] = _from_trakt(group)
    if 'simkl' in services:
        films, episodes, anime, covers['simkl'] = _from_simkl(group)
        have['simkl'] = (films, episodes)
    if 'mdblist' in services:
        have['mdblist'] = _from_mdblist(group)
    if 'wetrakr' in services:
        films, episodes, covers['wetrakr'] = _from_wetrakr(group)
        have['wetrakr'] = (films, episodes)
    resumes, clouds = {}, []
    have['here'] = _from_here(group, resumes, clouds)
    pauses = _trakt_pauses(group) if 'trakt' in services else {}
    have = {name: (_canon(group, films), _canon(group, episodes)) for name, (films, episodes) in have.items()}
    # being watched again: an end older than a real rewatch (progress_model.counts_as_rewatch) is
    # not sent - Trakt drops its newer resume when an end arrives, and the episode under way
    # jumped to the next one in its app
    from .progress_model import counts_as_rewatch
    again = {}
    for place, row in resumes.items():
        top = (group.find(place[0]),) + tuple(place[1:]) if isinstance(place, tuple) else group.find(place)
        if float(row.get('updated_at') or 0) > float((again.get(top) or {}).get('updated_at') or 0):
            again[top] = row
    anime = {group.find(key) for key in anime}
    covers = {name: {group.find(key): reach for key, reach in cover.items()} for name, cover in covers.items()}
    all_films, all_episodes = {}, {}
    for films, episodes in have.values():
        for key, entry in films.items():
            _keep(all_films, key, entry['ids'], entry['at'])
        for key, entry in episodes.items():
            _keep(all_episodes, key, entry['ids'], entry['at'])
    result, left_out, held = {}, 0, 0
    def watched_again(key, entry):
        row = again.get(key)
        return bool(row) and counts_as_rewatch(row, entry['at'])
    for name in services:
        films, episodes = have[name]
        missing_episodes = []
        for key, entry in all_episodes.items():
            if key in episodes or covered(covers.get(name) or {}, key):
                continue
            if key[0] in anime:
                left_out += 1
                continue
            if watched_again(key, entry):
                held += 1
                continue
            missing_episodes.append((key, entry))
        missing_films = []
        for key, entry in all_films.items():
            if key in films:
                continue
            if watched_again(key, entry):
                held += 1
                continue
            missing_films.append((key, entry))
        result[name] = {'films': missing_films, 'episodes': missing_episodes}
    result['anime_left_out'] = left_out
    result['being_watched_again'] = held
    if 'trakt' in services:
        result['trakt']['pauses_drop'], result['trakt']['pauses_put'] = _pause_plan(
            group, pauses, again, all_films, all_episodes)
    result['clouds_finished'] = _cloud_plan(group, clouds, again, all_films, all_episodes)
    return result


def _pause_plan(group, pauses, again, all_films, all_episodes):
    """Trakt's pauses made the same as here: one a later end made old goes (Trakt keeps it
    otherwise and its app shows it as under way), and a real resume Trakt lacks, or has an older
    one of, is sent. Only resumes Continue Watching would show (continue_rules period), never a
    start of a few seconds, never one of a title finished since (progress_model rules)."""
    from . import continue_rules
    from .progress_model import counts_as_rewatch, timestamp
    canon = lambda place: (group.find(place[0]),) + tuple(place[1:]) if isinstance(place, tuple) else group.find(place)
    ends = {}
    for store in (all_films, all_episodes):
        for key, entry in store.items():
            ends[key] = max(ends.get(key, 0.0), entry['at'])
    drop, put = [], []
    for place, pause in pauses.items():
        key = canon(place)
        end, row = ends.get(key, 0.0), again.get(key)
        rewatch = bool(row) and timestamp(row.get('updated_at')) > end and counts_as_rewatch(row, end)
        if end and end > pause['at'] and not rewatch:
            drop.append(pause)
    known = {canon(place): pause for place, pause in pauses.items()}
    # one per series, as Continue Watching shows it: the episode started last
    latest = {}
    for key, row in again.items():
        show = key[0] if isinstance(key, tuple) else key
        if timestamp(row.get('updated_at')) > timestamp((again.get(latest.get(show)) or {}).get('updated_at')):
            latest[show] = key
    for key in set(latest.values()):
        row = again[key]
        percent, position = float(row.get('percent') or 0), float(row.get('position') or 0)
        if not (1.0 < percent < 95.0) or (0 < position <= 30):
            continue
        if not continue_rules.recent_enough(row.get('updated_at')):
            continue
        end = ends.get(key, 0.0)
        if end and not counts_as_rewatch(row, end):
            continue
        pause = known.get(key)
        if pause and pause not in drop and (abs(pause['percent'] - percent) < 1.0 or pause['at'] >= timestamp(row.get('updated_at'))):
            continue
        ids = row.get('_ids') or {}
        if not ids:
            continue
        if isinstance(key, tuple):
            put.append({'show': {'ids': ids}, 'episode': {'season': key[1], 'number': key[2]}, 'progress': round(percent, 2)})
        else:
            put.append({'movie': {'ids': ids}, 'progress': round(percent, 2)})
    return drop, put


def _cloud_plan(group, clouds, again, all_films, all_episodes):
    """9.0.1: Nuvio's and Stremio's resumes a later end made old - their apps showed a title as
    under way that was finished since. [(resume row, the end's time)], to be written here as
    watched at that time; the Nuvio / Stremio sync takes them over."""
    from .progress_model import counts_as_rewatch, timestamp
    ends = {}
    for store in (all_films, all_episodes):
        for key, entry in store.items():
            ends[key] = max(ends.get(key, 0.0), entry['at'])
    found = []
    for place, row in clouds:
        key = (group.find(place[0]),) + tuple(place[1:]) if isinstance(place, tuple) else group.find(place)
        end, latest = ends.get(key, 0.0), again.get(key)
        if not end or end <= timestamp(row.get('updated_at')):
            continue
        if latest and timestamp(latest.get('updated_at')) > end and counts_as_rewatch(latest, end):
            continue                       # being watched again since: it stays under way
        found.append((row, end))
    return found


def finish_clouds(found):
    """The old Nuvio / Stremio resumes written here as watched at their real time, queued for
    the next Nuvio / Stremio sync (nuvio_progress) - the number written."""
    from .meganexus import progress_db
    rows = []
    for row, end in found:
        rows.append(dict({key: row.get(key) for key in ('media_type', 'canonical_id', 'video_id', 'title', 'poster',
                                                        'background', 'clearlogo', 'season', 'episode', 'tmdb_id',
                                                        'imdb_id', 'tvdb_id', 'show_tmdb_id', 'provider_name')},
                         position=float(row.get('duration') or row.get('position') or 0),
                         duration=float(row.get('duration') or 0), percent=100.0, event_type='watched',
                         stream_url='', ext_updated_at=end))
    return int(progress_db.keep_rows(rows, mark_dirty=True) or 0) if rows else 0


def _payload(films, episodes):
    """Batches in the shape both Trakt and Simkl take for /sync/history."""
    batches = []
    for start in range(0, len(films), BATCH):
        batches.append({'movies': [dict({'ids': entry['ids']}, **({'watched_at': _iso(entry['at'])} if entry['at'] else {}))
                                   for _, entry in films[start:start + BATCH]]})
    # shows: as many as fit in BATCH episodes; a show longer than that goes in parts of its own
    shows = {}
    for (key, season, number), entry in episodes:
        show = shows.setdefault(key, {'ids': dict(entry['ids']), 'seasons': {}})
        show['ids'].update(entry['ids'])
        show['seasons'].setdefault(season, []).append(dict({'number': number},
                                                          **({'watched_at': _iso(entry['at'])} if entry['at'] else {})))
    pending, size = [], 0
    for show in shows.values():
        for number, found in sorted(show['seasons'].items()):
            for start in range(0, len(found), BATCH):
                part = found[start:start + BATCH]
                if size + len(part) > BATCH and pending:
                    batches.append({'shows': pending})
                    pending, size = [], 0
                if pending and pending[-1]['ids'] is show['ids']:
                    pending[-1]['seasons'].append({'number': number, 'episodes': part})
                else:
                    pending.append({'ids': show['ids'], 'seasons': [{'number': number, 'episodes': part}]})
                size += len(part)
    if pending:
        batches.append({'shows': pending})
    return batches


def send(service, films, episodes, step=None):
    """What ``service`` is missing, sent in batches; (films, episodes) it took."""
    from . import mdblist_tracking, simkl_api, trakt_api
    batches = _payload(films, episodes)
    taken = [0, 0]
    for index, body in enumerate(batches):
        if service == 'trakt':
            reply = trakt_api._request('/sync/history', payload=body, method='POST', auth=True, timeout=60) or {}
            time.sleep(TRAKT_PAUSE)
        elif service == 'wetrakr':
            from . import wetrakr_api
            reply = wetrakr_api._request('/sync/tracking', dict(body, status='watched'), method='POST', timeout=60) or {}
            wetrakr_api.invalidate_cache('/sync/tracking')
        elif service == 'mdblist':   # spaced by its own writer (300 writes in 5 minutes)
            reply = mdblist_tracking.request('POST', '/sync/watched', payload=body, timeout=60) or {}
        else:
            reply = simkl_api._request('/sync/history', payload=body, method='POST', auth=True, timeout=60) or {}
        added = (reply or {}).get('added') or (reply or {}).get('updated') or {}
        if isinstance(added, dict) and ('movies' in added or 'episodes' in added):
            taken[0] += int(added.get('movies') or 0)
            taken[1] += int(added.get('episodes') or 0)
        else:   # a service that does not count what it took back: what was sent
            taken[0] += len(body.get('movies') or [])
            taken[1] += sum(len(season.get('episodes') or []) for show in body.get('shows') or []
                            for season in show.get('seasons') or [])
        if step:
            step(index + 1, len(batches))
    return tuple(taken)


def send_pauses(drop, put, step=None):
    """Trakt's pauses: the old ones removed, the real ones sent (a pause, as a player sends it).
    (removed, sent)."""
    from . import trakt_api
    done, total = [0, 0], len(drop) + len(put)
    for index, pause in enumerate(drop):
        try:
            trakt_api._request('/sync/playback/%s' % pause['id'], method='DELETE', auth=True, timeout=20)
            done[0] += 1
        except Exception:
            pass
        time.sleep(TRAKT_PAUSE)
        if step:
            step(index + 1, total)
    for index, body in enumerate(put):
        try:
            trakt_api._request('/scrobble/pause', payload=body, method='POST', auth=True, timeout=20)
            done[1] += 1
        except Exception:
            pass
        time.sleep(TRAKT_PAUSE)
        if step:
            step(len(drop) + index + 1, total)
    return tuple(done)
