# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from concurrent.futures import ThreadPoolExecutor
import threading


_MAX_QUEUED = 8
_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix='MegaNexus-bg')
_SLOTS = threading.BoundedSemaphore(_MAX_QUEUED)
_LOCK = threading.Lock()
_ACTIVE_KEYS = set()


def maybe_run(target, args=(), kwargs=None, key='', on_error=None):
    if not callable(target):
        return False
    task_key = str(key or '').strip()
    with _LOCK:
        if task_key and task_key in _ACTIVE_KEYS:
            return False
        if not _SLOTS.acquire(False):
            return False
        if task_key:
            _ACTIVE_KEYS.add(task_key)

    def _run():
        try:
            return target(*(tuple(args or ())), **dict(kwargs or {}))
        except Exception as exc:
            if callable(on_error):
                try:
                    on_error(exc)
                except Exception:
                    pass
            return None
        finally:
            with _LOCK:
                if task_key:
                    _ACTIVE_KEYS.discard(task_key)
                try:
                    _SLOTS.release()
                except ValueError:
                    pass

    try:
        _POOL.submit(_run)
        return True
    except Exception as exc:
        with _LOCK:
            if task_key:
                _ACTIVE_KEYS.discard(task_key)
            try:
                _SLOTS.release()
            except ValueError:
                pass
        if callable(on_error):
            try:
                on_error(exc)
            except Exception:
                pass
        return False


def active_count():
    with _LOCK:
        return len(_ACTIVE_KEYS)


def stop():
    """End the workers with the script that started them (script_exit).

    8.1.1: this pool was the one module-level pool nothing ever shut down. An idle
    worker never ends by itself, and Kodi waits for every thread of a finished script
    before it lets go of it - so the interface kept the process alive after it closed.
    """
    try:
        _POOL.shutdown(wait=False, cancel_futures=True)
    except TypeError:
        _POOL.shutdown(wait=False)     # Kodi on Windows still embeds Python 3.8
    except Exception:
        pass
