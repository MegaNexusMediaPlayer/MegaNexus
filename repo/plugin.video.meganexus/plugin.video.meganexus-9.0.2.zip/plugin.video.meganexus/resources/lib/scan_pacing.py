# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""When a search or a source scan has enough to show.

`fair_job_order` deals the jobs out one add-on (or media server) at a time, so a slow add-on
with many jobs never holds the others back. The two readers pass on a JobRace's results
as they finish and stop early:

    search   once a real result is in and either `real_goal` results came or nothing new
             arrived for `quiet_seconds` - or `fallback_seconds` after the first result
    sources  `result_goal` sources, or `quick_grace` seconds after the first; never past the
             time limit (`full_timeout` once the user chose Keep searching)"""
import time


def _owner(job):
    try:
        provider = job[0] or {}
        key = str(provider.get('id') or provider.get('name') or id(provider))
        if key in ('__plex__', '__emby__'):           # one queue per media server
            server = provider.get('_server') or {}
            key += ':' + str(server.get('id') or server.get('url') or server.get('name') or id(server))
        return key
    except Exception:
        return str(id(job))


def fair_job_order(jobs):
    queues = {}
    for job in list(jobs or []):
        queues.setdefault(_owner(job), []).append(job)
    dealt = []
    while queues:
        for owner in list(queues):
            dealt.append(queues[owner].pop(0))
            if not queues[owner]:
                del queues[owner]
    return dealt


def iter_search_results(race, result_count, has_real_source, should_stop=None, on_ready=None, real_goal=12,
                        quiet_seconds=0.30, fallback_seconds=1.20, poll_seconds=0.10, cancel_on_exit=True):
    first = changed = None
    seen = 0
    try:
        while not race.done:
            if should_stop and should_stop():
                return
            for row in race.poll(poll_seconds):
                yield row
            now = time.monotonic()
            count = max(0, int(result_count() or 0))
            if count > 0 and first is None:
                first = changed = now
            if count != seen:
                seen, changed = count, now
            if count <= 0 or first is None:
                continue
            settled = bool(has_real_source()) and (count >= int(real_goal or 0) or now - (changed or first) >= quiet_seconds)
            if settled or now - first >= fallback_seconds:
                if on_ready:
                    on_ready()
                return
    finally:
        if cancel_on_exit:
            race.cancel()


def source_rows_until_enough(race, result_count, has_entries, started_at, initial_timeout, stop_after_first, result_goal,
                        quick_grace, should_stop=None, consume_continue=None, clear_sufficient=None,
                        mark_sufficient=None, full_timeout=25.0, poll_seconds=0.10):
    first, patient = None, False
    while not race.done:
        if should_stop and should_stop():
            return
        if consume_continue and consume_continue():
            patient = True
            if clear_sufficient:
                clear_sufficient()
        limit = full_timeout if patient else initial_timeout
        spent = time.time() - started_at
        if spent >= limit:
            return
        for row in race.poll(min(poll_seconds, max(0.01, limit - spent))):
            yield row
        now = time.time()
        if first is None and has_entries():
            first = now
        if not stop_after_first or patient or int(result_goal or 0) == 0:
            continue
        if has_entries() and (int(result_count() or 0) >= int(result_goal or 0)
                              or (first is not None and now - first >= quick_grace)):
            if mark_sufficient:
                mark_sufficient()
            return
