# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""One entry point for the bundled interface, providers, metadata and playback."""
from urllib.parse import urlsplit

import xbmc
import xbmcaddon
import xbmcgui


def resources(provider):
    return {r.get('name') if isinstance(r, dict) else r for r in (provider.get('manifest') or {}).get('resources', [])}


def status(providers):
    return {'catalog': any('catalog' in resources(p) for p in providers),
            'stream': any('stream' in resources(p) for p in providers),
            'aio': any((p.get('manifest') or {}).get('id') == 'aio-metadata' for p in providers)}


def add_manifest(dialog):
    from .meganexus.addon_wire import manifest_ok
    from .meganexus import addon_registry
    value = dialog.input('Paste your configured provider manifest URL').strip()
    if not value:
        return False
    if value.startswith('stremio://'):
        value = 'https://' + value[len('stremio://'):]
    parsed = urlsplit(value)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc or not parsed.path.endswith('/manifest.json'):
        dialog.ok('MegaNexus', 'Enter a complete http(s) manifest.json URL. Include your provider configuration.')
        return False
    busy = xbmcgui.DialogProgressBG()
    busy.create('MegaNexus', 'Checking provider...')
    try:
        manifest = manifest_ok(value)
        addon_registry.add_provider(manifest.get('name') or manifest['id'], value, manifest)
        dialog.notification('MegaNexus', 'Provider connected')
        return True
    except Exception:
        # Configured URLs may contain credentials. Do not display/log them.
        dialog.ok('MegaNexus', 'Could not validate this manifest. Check the URL, provider configuration and connection, then try again.')
        return False
    finally:
        busy.close()


def run():
    """Legacy entry point delegates onboarding to the independent interface."""
    xbmc.executebuiltin('RunScript(script.meganexus,wizard)')
