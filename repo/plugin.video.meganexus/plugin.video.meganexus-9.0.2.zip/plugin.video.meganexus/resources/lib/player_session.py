# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json
import os

from .meganexus.paths import profile_path

SESSION_FILE = os.path.join(profile_path(), "current_session.json")
WINDOW_ID = 10000
PROP_KEY = 'meganexus.session_v1'


def _window():
    try:
        import xbmcgui
        return xbmcgui.Window(WINDOW_ID)
    except Exception:
        return None


def save_session(data):
    """The playback's session: on the Home window (the service reads it there); in the
    profile only when there is no window to keep it on."""
    payload = json.dumps(data or {}, ensure_ascii=False)
    window = _window()
    if window is not None:
        try:
            window.setProperty(PROP_KEY, payload)
            return
        except Exception:
            pass
    try:
        from .meganexus.json_files import write_json
        write_json(SESSION_FILE, data or {})
    except Exception:
        try:
            os.makedirs(os.path.dirname(SESSION_FILE), exist_ok=True)
            with open(SESSION_FILE + '.tmp.%d' % os.getpid(), 'w', encoding='utf-8') as handle:
                handle.write(payload)
            os.replace(SESSION_FILE + '.tmp.%d' % os.getpid(), SESSION_FILE)
        except Exception:
            pass


def load_session():
    win = _window()
    if win is not None:
        try:
            raw = win.getProperty(PROP_KEY) or ''
            if raw:
                return json.loads(raw)
        except Exception:
            pass
    # Fallback: disk
    try:
        with open(SESSION_FILE, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {}


def clear_session():
    win = _window()
    if win is not None:
        try:
            win.clearProperty(PROP_KEY)
        except Exception:
            pass
    try:
        os.remove(SESSION_FILE)
    except FileNotFoundError:
        pass
    except Exception:
        pass
