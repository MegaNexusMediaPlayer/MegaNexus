# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Connect Trakt / Simkl from the phone setup page (6.0.35).

``start`` asks the service for a device code and returns the page to open
plus the code; a background thread on the TV waits for the approval and saves
the token. ``status`` is what the phone page shows. No dialogs on the TV.
"""
import threading
import time
from urllib.parse import quote, urlsplit

SERVICES = ('trakt', 'simkl', 'wetrakr', 'plex')   # plex: 6.0.39 beta, a media server linked the same way
# 8.1.2: WeTrakr is linked from the phone like the others - its code flow is the same
# shape, and the account's own app key has to be set before a code can be asked for.
_LOCK = threading.Lock()
_PENDING = {}   # service -> {'code', 'url', 'expires', 'error'}


def connected(service):
    try:
        if service == 'plex':
            from . import plex
            return plex.is_signed_in()
        if service == 'trakt':
            from . import trakt_api
            return trakt_api.authorized()
        if service == 'wetrakr':
            from . import wetrakr_api
            return wetrakr_api.authorized()
        from . import simkl_api
        return bool(simkl_api.enabled() and simkl_api.authorized())
    except Exception:
        return False


def status():
    now = time.monotonic()
    result = {}
    with _LOCK:
        for service in SERVICES:
            pending = _PENDING.get(service)
            if pending and pending['expires'] < now:
                pending = None
                _PENDING.pop(service, None)
            result[service] = {'connected': connected(service),
                               'code': pending['code'] if pending else '',
                               'url': pending['url'] if pending else '',
                               'error': pending.get('error', '') if pending else ''}
    try:
        from . import wetrakr_api
        result['wetrakr']['key_set'] = bool(wetrakr_api.client_id())
    except Exception:
        result.setdefault('wetrakr', {'connected': False, 'code': '', 'url': '', 'error': ''})['key_set'] = False
    try:
        from . import mdblist_tracking
        result['mdblist']={'connected':mdblist_tracking.enabled(),'key_set':bool(mdblist_tracking.api_key()),'code':'','url':'','error':''}
    except Exception:result['mdblist']={'connected':False,'key_set':False,'code':'','url':'','error':''}
    return result


def _trakt_code():
    from . import trakt_api
    trakt_api.ensure_enabled()
    code = trakt_api._request('/oauth/device/code', payload={'client_id': trakt_api.client_id()}, method='POST', auth=False, timeout=10)
    user_code = str((code or {}).get('user_code') or '').strip()
    device_code = str((code or {}).get('device_code') or '').strip()
    if not user_code or not device_code:
        raise ValueError('Trakt did not return a code. Try again.')
    url = str(code.get('verification_url') or 'https://trakt.tv/activate')
    if urlsplit(url).hostname not in ('trakt.tv', 'www.trakt.tv'):
        url = 'https://trakt.tv/activate'

    def poll():
        try:
            token = trakt_api._request('/oauth/device/token', payload={'code': device_code, 'client_id': trakt_api.client_id(),
                                                                   'client_secret': trakt_api.client_secret()},
                                   method='POST', auth=False, timeout=10)
        except Exception:
            return None   # 400 = not approved yet
        if isinstance(token, dict) and token.get('access_token'):
            token['created_at'] = int(time.time())
            trakt_api.save_token(token)
            return True
        return None
    return user_code, url, int(code.get('interval') or 5), int(code.get('expires_in') or 600), poll


def _simkl_code():
    from . import simkl_api
    from .settings_snapshot import cached_addon
    code = simkl_api._request('/oauth/pin?client_id=' + quote(simkl_api.client_id(), safe=''), timeout=10)
    user_code = str((code or {}).get('user_code') or '').strip()
    if not user_code:
        raise ValueError('Simkl did not return a code. Try again.')
    url = str(code.get('verification_url') or simkl_api.PIN_URL_FALLBACK)
    if urlsplit(url).hostname not in ('simkl.com', 'www.simkl.com'):
        url = simkl_api.PIN_URL_FALLBACK
    path = '/oauth/pin/%s?client_id=%s' % (quote(user_code, safe=''), quote(simkl_api.client_id(), safe=''))

    def poll():
        try:
            data = simkl_api._request(path, timeout=10)
        except Exception:
            return None
        if isinstance(data, dict) and data.get('access_token'):
            simkl_api.save_token({'access_token': data['access_token'], 'created_at': int(time.time())})
            addon = cached_addon()
            addon.setSetting('enable_simkl', 'true')
            addon.setSetting('simkl_mark_watched', 'true')
            simkl_api.invalidate_cache()
            return True
        return None
    return user_code, url, int(code.get('interval') or 5), int(code.get('expires_in') or 900), poll


def _wetrakr_code():
    from . import wetrakr_api
    if not wetrakr_api.client_id():
        raise ValueError('Enter your WeTrakr app\'s client ID first (wetrakr.com - Settings - API).')
    code = wetrakr_api._request('/oauth/device/code', {'client_id': wetrakr_api.client_id()},
                                method='POST', auth=False, timeout=10)
    user_code = str((code or {}).get('user_code') or '').strip()
    device_code = str((code or {}).get('device_code') or '').strip()
    if not (user_code and device_code):
        raise ValueError('WeTrakr did not return a code. Try again.')
    url = str(code.get('verification_url') or wetrakr_api.ACTIVATE_FALLBACK)

    def poll():
        try:
            # 9.0.1: "code" with the client ID, as WeTrakr reads it (wetrakr_api.device_auth)
            data = wetrakr_api._request('/oauth/device/token', {'code': device_code, 'device_code': device_code,
                                                                'client_id': wetrakr_api.client_id()},
                                        method='POST', auth=False, timeout=10, retry=False)
        except Exception:
            return None
        if isinstance(data, dict) and data.get('access_token'):
            wetrakr_api.save_token(data)
            wetrakr_api.invalidate_cache()
            return True
        return None
    return user_code, url, int(code.get('interval') or 5), int(code.get('expires_in') or 600), poll


def _plex_code():
    """plex.tv/link with the short PIN (the page asks the user to sign in)."""
    from . import plex
    from .settings_snapshot import cached_addon
    pin = plex.request_pin()
    code = str(pin.get('code') or '').strip()
    if not code or not pin.get('id'):
        raise ValueError('Plex did not return a code. Try again.')

    def poll():
        try:
            linked = plex.poll_pin(pin['id'], code, flavor=pin.get('flavor') or 'v2')
        except Exception:
            return None
        if linked:
            from .media_servers import switch_on, PLEX
            switch_on(PLEX, cached_addon())     # 7.0.29: with its Home rows
            return True
        return None
    return code, 'https://plex.tv/link', 3, 900, poll


def start(service, sleep=time.sleep):
    """Begin linking; returns {'url', 'code'} for the phone."""
    if service not in SERVICES:
        raise ValueError('Unknown tracking service.')
    try:
        code, url, interval, expires, poll = {'trakt': _trakt_code, 'simkl': _simkl_code,
                                              'wetrakr': _wetrakr_code, 'plex': _plex_code}[service]()
    except ValueError:
        raise
    except Exception:
        raise ValueError('%s could not be reached. Check the connection and retry.' % service.title())
    interval = max(3 if service == 'plex' else 5, min(60, interval))
    expires = max(60, min(1800, expires))
    entry = {'code': code, 'url': url, 'expires': time.monotonic() + expires}
    with _LOCK:
        _PENDING[service] = entry

    def wait():
        while time.monotonic() < entry['expires']:
            sleep(interval)
            with _LOCK:
                if _PENDING.get(service) is not entry:
                    return  # a newer attempt replaced this one
            if poll():
                from . import settings_snapshot
                settings_snapshot.invalidate()
                with _LOCK:
                    if _PENDING.get(service) is entry:
                        _PENDING.pop(service, None)
                return
    threading.Thread(target=wait, name='MegaNexusLink-' + service, daemon=True).start()
    return {'url': url, 'code': code}


def disconnect(service):
    if service == 'trakt':
        from . import trakt_api
        trakt_api.logout()
    elif service == 'simkl':
        from . import simkl_api
        simkl_api.logout()
    elif service == 'wetrakr':
        from . import wetrakr_api
        wetrakr_api.logout()
    elif service == 'plex':
        from . import plex
        from .settings_snapshot import cached_addon
        plex.sign_out()
        cached_addon().setSetting('meganexus_plex_enabled', 'false')
    else:
        raise ValueError('Unknown tracking service.')
    with _LOCK:
        _PENDING.pop(service, None)
    return {}
