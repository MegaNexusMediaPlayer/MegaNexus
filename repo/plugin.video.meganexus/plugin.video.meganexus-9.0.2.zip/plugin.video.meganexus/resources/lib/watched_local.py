# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""What this box says about watched - and it is the one that counts (8.1.2).

The watched view used to be a union read at paint time: Simkl OR Trakt OR MDBList OR
this box's own playback. A union can only ever add, so nothing could be taken back -
unmark a film and any service that still listed it put the mark straight back, for good.

This file is the one place that says otherwise. A mark the person set here beats every
service, until the title is played again (playback clears it, as a newer progress time
clears a Continue Watching removal in continue_rules).

Deliberately a small JSON file and not a column in the progress database: that database
feeds the account sync queue and the Continue Watching rows, and a mark set by hand is
neither playback nor progress. One file, one meaning, bounded in size.

    {"movie|tt1": {"watched": false, "at": 1792}        a film, taken back
     "series|tt2": {"watched": true, "at": 1792,        a whole series
                    "episodes": {"1:2": false}}}        or one episode of it
"""
import json
import os
import threading
import time

KEPT = 2000          # marks held, oldest dropped first - a device that is never cleared
_LOCK = threading.RLock()
_MEM = {}


def key(media_type, canonical_id):
    kind = 'movie' if media_type == 'movie' else 'series'
    return '%s|%s' % (kind, canonical_id or '')


def episode_key(season, episode):
    return '%s:%s' % (season, episode)


def _path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), 'watched_local.json')


def overrides():
    """The marks as they are on disk. The same object while the file has not changed,
    so a caller can memo on its identity (simkl_watched.snapshot does) and painting a
    screen costs one stat."""
    path = _path()
    try:
        stamp = os.stat(path).st_mtime_ns
    except OSError:
        stamp = 0
    with _LOCK:
        if _MEM.get('stamp') == (path, stamp):
            return _MEM['data']
        data = {}
        if stamp:
            try:
                with open(path, encoding='utf-8') as handle:
                    data = json.load(handle)
            except (OSError, ValueError):
                data = {}
        if not isinstance(data, dict):
            data = {}
        _MEM.update(stamp=(path, stamp), data=data)
        return data


def _write(data):
    from .meganexus.json_files import write_json
    kept = dict(sorted(data.items(), key=lambda pair: float((pair[1] or {}).get('at') or 0), reverse=True)[:KEPT])
    write_json(_path(), kept)
    with _LOCK:
        _MEM.clear()
    return kept


def mark(media_type, canonical_id, watched=False, season=None, episode=None, now=None):
    """Say that this box counts the title (or one episode of it) as watched or not.

    ``watched=False`` is the case this exists for: it has to survive every service
    saying otherwise.
    """
    with _LOCK:
        data = dict(overrides())
        entry = dict(data.get(key(media_type, canonical_id)) or {})
        entry['at'] = float(now or time.time())
        if season is not None and episode is not None:
            episodes = dict(entry.get('episodes') or {})
            episodes[episode_key(season, episode)] = bool(watched)
            entry['episodes'] = episodes
        else:
            entry['watched'] = bool(watched)
            if not watched:
                # the whole title taken back: no episode of it is watched either
                entry['episodes'] = {}
                entry['all'] = False
        data[key(media_type, canonical_id)] = entry
        return _write(data)


def forget(media_type, canonical_id, season=None, episode=None):
    """Drop the mark - the title was played again, so playback speaks for itself."""
    with _LOCK:
        data = dict(overrides())
        name = key(media_type, canonical_id)
        entry = dict(data.get(name) or {})
        if not entry:
            return False
        if season is not None and episode is not None:
            episodes = dict(entry.get('episodes') or {})
            if episodes.pop(episode_key(season, episode), None) is None:
                return False
            entry['episodes'] = episodes
            if not episodes and 'watched' not in entry:
                data.pop(name, None)
            else:
                data[name] = entry
        else:
            data.pop(name, None)
        _write(data)
        return True


def played(media_type, canonical_id, season=None, episode=None):
    """This was just played, so playback speaks for itself: the marks it contradicts go.

    An episode drops its own mark and the "the whole thing is not watched" flag above it
    - never the marks of the other episodes, which were set one by one and still mean
    what they said.
    """
    with _LOCK:
        data = dict(overrides())
        name = key(media_type, canonical_id)
        entry = dict(data.get(name) or {})
        if not entry:
            return False
        if season is not None and episode is not None:
            episodes = dict(entry.get('episodes') or {})
            episodes.pop(episode_key(season, episode), None)
            entry['episodes'] = episodes
            if entry.get('watched') is False:
                entry.pop('watched', None)
                entry.pop('all', None)
            if episodes or 'watched' in entry:
                data[name] = entry
            else:
                data.pop(name, None)
        else:
            data.pop(name, None)
        _write(data)
        return True


def apply(items, marks=None):
    """The union, with this box's marks applied over it. ``items`` is the dict
    simkl_watched.snapshot builds; it is changed in place and returned."""
    marks = overrides() if marks is None else marks
    for name, entry in (marks or {}).items():
        if not isinstance(entry, dict):
            continue
        target = items.get(name)
        said = entry.get('watched')
        episodes = entry.get('episodes') or {}
        if target is None:
            if not (said or any(episodes.values())):
                continue          # nothing to show: a mark that only takes away
            target = items[name] = {'watched': False, 'seasons': [], 'episodes': []}
        if said is not None:
            target['watched'] = bool(said)
            if not said:
                target['seasons'] = []
                target['episodes'] = []
        seen = set(target.get('episodes') or [])
        for marker, watched in episodes.items():
            if watched:
                seen.add(marker)
            else:
                seen.discard(marker)
        target['episodes'] = sorted(seen)
        if episodes and not any(episodes.values()) and said is None and not seen:
            target['seasons'] = []
    return items
