# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import importlib.util
import os
import py_compile

_SKIP_DIRS = ('tests', '__pycache__', '.git')


def _needs_compiling(source):
    """No compiled copy yet, or one older than the source (an update came)."""
    try:
        return os.path.getmtime(importlib.util.cache_from_source(source)) < os.path.getmtime(source)
    except (OSError, ValueError):
        return True


def _sources(root):
    for folder, inner, names in os.walk(root):
        inner[:] = [name for name in inner if name not in _SKIP_DIRS]
        for name in sorted(names):
            if name.endswith('.py'):
                yield os.path.join(folder, name)


def warm(root, monitor=None, throttle=0.05):
    """After an update: the add-on's Python compiled ahead, a little at a time, so its first
    screens do not compile while they open. (checked, compiled)."""
    checked = compiled = 0
    for source in _sources(root):
        if monitor is not None and monitor.abortRequested():
            break
        checked += 1
        if not _needs_compiling(source):
            continue
        try:
            py_compile.compile(source, doraise=False, quiet=2)
        except Exception:
            continue
        compiled += 1
        if monitor is not None and throttle > 0 and monitor.waitForAbort(throttle):
            break
    return checked, compiled
