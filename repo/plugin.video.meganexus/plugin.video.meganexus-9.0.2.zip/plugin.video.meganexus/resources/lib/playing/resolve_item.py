# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
def resolve(provider, item, **kwargs):
    fn = getattr(provider, 'playable_of', None)
    if callable(fn):
        return fn(item=item, **kwargs)
    return item
