# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
from ..texts import tr

_TAG = '[B][COLOR FFE53935]\u25b6 %s[/COLOR][/B]  %s'


def current_first(rows, current_key):
    key = str(current_key or '')
    out = list(rows or [])
    if not key:
        return out, False
    for i, row in enumerate(out):
        if str((row or {}).get('k') or '') != key:
            continue
        tagged = dict(row)
        tagged['l'] = _TAG % (tr('Now playing'), row.get('l') or '?')
        return [tagged] + out[:i] + out[i + 1:], True
    return out, False
