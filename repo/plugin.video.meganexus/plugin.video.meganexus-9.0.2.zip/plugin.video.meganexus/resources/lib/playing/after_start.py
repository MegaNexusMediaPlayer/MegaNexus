# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import json

import xbmc
import xbmcgui
import xbmcvfs

WINDOW_ID = 10000
PROP_JOB = 'meganexus.post_start_job_v1'

_FOREIGN_FILE_MARKERS = (
    'plugin.video.themoviedb.helper',
    'dummy.mp4',
)
_NAV_MARKERS = (
    'action=streams', 'action=episode_streams', 'action=item_open',
    'action=series_meta', 'action=play_item', 'action=cw_resume',
    'action=cw_play_from_start', 'action=play', 'action=tmdb_player',
    'action=kodi_route_browse',
)


def _window():
    return xbmcgui.Window(WINDOW_ID)


def leave_job(ctx, stream_key='play', subtitle_path='', subtitle_index=-1,
                force_subtitles=False, existing_paths=None, subtitle_rows=None,
                attach_rows=None, discovery=False):
    ctx = dict(ctx or {})
    uid = str(ctx.get('playback_uid') or '')
    existing_ids = []
    for row in (subtitle_rows or []):
        try:
            rid = str(row.get('id') or row.get('url') or row.get('path') or '')
        except Exception:
            rid = ''
        if rid:
            existing_ids.append(rid)
    apply_job = None
    try:
        idx = int(subtitle_index)
    except Exception:
        idx = -1
    if subtitle_path or idx >= 0 or force_subtitles:
        apply_job = {
            'path': str(subtitle_path or ''),
            'index': idx,
            'force': bool(force_subtitles),
        }
    # what the service needs once the picture moves (read back by do_job)
    job = dict(v=1, uid=uid, stream_key=str(stream_key or 'play'), title=str(ctx.get('title') or ''),
               provider=str(ctx.get('provider_name') or ctx.get('provider_id') or ''), ctx=ctx, apply=apply_job,
               existing_paths=[str(path) for path in existing_paths or () if path], existing_ids=existing_ids,
               attach_rows=list(attach_rows or []), discovery=bool(discovery))
    _window().setProperty(PROP_JOB, json.dumps(job, ensure_ascii=False,
                                               default=str))
    return job


def clear_job():
    try:
        _window().clearProperty(PROP_JOB)
    except Exception:
        pass


def claim_job(expected_uid):
    raw = ''
    try:
        raw = _window().getProperty(PROP_JOB) or ''
    except Exception:
        raw = ''
    if not raw:
        return None
    clear_job()
    try:
        job = json.loads(raw)
    except Exception:
        return None
    if not isinstance(job, dict):
        return None
    uid = str(job.get('uid') or '')
    if not uid or uid != str(expected_uid or ''):
        return None
    if not (job.get('apply') or job.get('attach_rows') or job.get('discovery') or
            (job.get('ctx') or {}).get('meganexus_subtitle_language')):
        return None
    return job


def _player_has_video(player):
    has_video = False
    try:
        has_video = bool(player.isPlayingVideo())
    except Exception:
        has_video = False
    try:
        has_video = has_video or bool(xbmc.getCondVisibility('Player.HasVideo'))
    except Exception:
        pass
    if not has_video:
        return False
    playing_file = ''
    try:
        playing_file = player.getPlayingFile() or ''
    except Exception:
        playing_file = ''
    low = str(playing_file or '').lower()
    if low:
        if all(marker in low for marker in _FOREIGN_FILE_MARKERS):
            return False
        if low.startswith('plugin://plugin.video.meganexus/') and any(
                marker in low for marker in _NAV_MARKERS):
            return False
    return True


def do_job(job, monitor=None):
    job = dict(job or {})
    stream_key = str(job.get('stream_key') or 'play')
    title = str(job.get('title') or '')
    provider = str(job.get('provider') or '')

    def _emit(event, level=None, **fields):
        if monitor is None:
            return
        try:
            if level is not None:
                monitor(event, level=level, **fields)
            else:
                monitor(event, **fields)
        except Exception:
            pass

    kodi_monitor = xbmc.Monitor()
    player = xbmc.Player()
    apply_job = job.get('apply') or None
    ctx = job.get('ctx') or {}
    meganexus_auto = bool(ctx.get('meganexus_subtitle_language'))
    if meganexus_auto:
        from ..player_session import load_session
        _window().setProperty('meganexus.subtitle.status', 'Waiting for video')
    started = False
    try:
        for _ in range(240 if meganexus_auto else 100):
            if kodi_monitor.abortRequested():
                return
            if kodi_monitor.waitForAbort(.25):return
            if meganexus_auto:
                current_uid=(load_session() or {}).get('playback_uid')
                if current_uid and current_uid!=ctx.get('playback_uid'):return
                request=str(ctx.get('meganexus_request_id') or '')
                if request and (_window().getProperty('meganexus.cancelled.'+request) or _window().getProperty('meganexus.playback.finished')==request):return
                if _window().getProperty('meganexus.subtitle.manual')==ctx.get('meganexus_request_id'):return
                if _window().getProperty('meganexus.playback.started')!=ctx.get('meganexus_request_id'):continue
            try:
                if _player_has_video(player):
                    started = True
                    break
            except Exception:
                continue
        if not started:
            if meganexus_auto:_window().setProperty('meganexus.subtitle.status','Video start timed out')
            if apply_job:
                _emit('play-start-timeout', level=xbmc.LOGWARNING,
                      stream_key=stream_key, title=title, provider=provider)
            return
        if meganexus_auto:
            from ..meganexus_subtitles import auto_apply
            _window().setProperty('meganexus.subtitle.status','Searching')
            applied=auto_apply(ctx,player)
            if (load_session() or {}).get('playback_uid')==ctx.get('playback_uid'):
                _window().setProperty('meganexus.subtitle.status','Applied' if applied else 'No matching subtitle')
            _emit('meganexus-auto-subtitle',applied=applied,language=ctx.get('meganexus_subtitle_language'))
            return
        if apply_job:
            _emit('play-started', stream_key=stream_key, title=title,
                  provider=provider)
            xbmc.sleep(800)

        # Stage 2 — elected subtitle.
        if apply_job:
            _turn_on_chosen_subtitle(player, apply_job, kodi_monitor)
            try:
                from ..subtitle_names import choose_on_player
                choose_on_player(
                    player, show=bool(apply_job.get('force')),
                    attempts=4, delay_ms=400)
            except Exception:
                pass

        attach_rows = job.get('attach_rows') or []
        if attach_rows and _player_has_video(player):
            _add_more_subtitles(player, attach_rows,
                                   job.get('existing_paths') or [], stream_key)

        if job.get('discovery') and not kodi_monitor.abortRequested() \
                and _player_has_video(player):
            _find_more_subtitles(player, job, stream_key)
    except Exception as exc:
        if meganexus_auto and (load_session() or {}).get('playback_uid')==ctx.get('playback_uid'):
            _window().setProperty('meganexus.subtitle.status','Subtitle could not be loaded')
        _emit('play-post-start-error', level=xbmc.LOGWARNING, error=exc,
              stream_key=stream_key, title=title)
        try:
            xbmc.log('[MegaNexus] post-start chores failed: %s' % exc,
                     xbmc.LOGDEBUG)
        except Exception:
            pass


def _turn_on_chosen_subtitle(player, apply_job, kodi_monitor):
    path = str(apply_job.get('path') or '')
    try:
        index = int(apply_job.get('index'))
    except Exception:
        index = -1
    if path:
        low = path.lower()
        if not low.startswith(('http://', 'https://', 'smb://', 'nfs://')):
            for _ in range(40):
                try:
                    if xbmcvfs.exists(path):
                        break
                except Exception:
                    break
                if kodi_monitor.abortRequested():
                    return
                xbmc.sleep(250)
            else:
                return
    try:
        player.showSubtitles(False)
    except Exception:
        pass
    applied = False
    if index >= 0:
        try:
            player.setSubtitleStream(index)
            player.showSubtitles(True)
            applied = True
        except Exception:
            applied = False
    if not applied and path:
        try:
            player.setSubtitles(path)
            player.showSubtitles(True)
        except Exception:
            pass


def _add_more_subtitles(player, rows, existing_paths, stream_key):
    try:
        from ..subtitle_choice import automatic_rows
        from .subtitle_handoff import prepare
        safe_rows = automatic_rows(list(rows))
        if not safe_rows:
            return
        prepared = prepare(safe_rows, stream_key, local_copy=True)
        extras = [r.get('path') for r in prepared if r.get('path')]
        if not extras:
            return
        combined = list(existing_paths) + [p for p in extras
                                           if p not in existing_paths]
        try:
            player.setSubtitles(combined[0])
            for extra in combined[1:]:
                try:
                    player.setSubtitles(extra)
                except Exception:
                    pass
        except Exception:
            pass
    except Exception:
        pass


def _find_more_subtitles(player, job, stream_key):
    try:
        from ..subtitle_choice import automatic_rows
        from .subtitle_handoff import collect, prepare
        try:
            discovered = collect(dict(job.get('ctx') or {}), include_broker=True)
        except Exception as exc:
            xbmc.log('[MegaNexus] background subtitle discovery failed: %s' % exc,
                     xbmc.LOGWARNING)
            return
        existing_paths = set(str(p) for p in (job.get('existing_paths') or []))
        # the subtitles found now that the start did not have (each once)
        seen, extras = set(str(known) for known in job.get('existing_ids') or ()), []
        for row in discovered or ():
            mark = str(row.get('id') or row.get('url') or row.get('path') or '')
            if not mark or mark not in seen:
                seen.add(mark)
                extras.append(row)
        extras = automatic_rows(extras)
        if not extras:
            return
        prepared = prepare(extras, stream_key, local_copy=True)
        added = 0
        for row in prepared:
            path = row.get('path')
            if not path or path in existing_paths:
                continue
            if not _player_has_video(player):
                break
            try:
                player.setSubtitles(path)
                existing_paths.add(path)
                added += 1
            except Exception:
                pass
        xbmc.log('[MegaNexus] background subtitle discovery attached %d track(s)'
                 % added, xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[MegaNexus] background subtitle attach failed: %s' % exc,
                 xbmc.LOGWARNING)
