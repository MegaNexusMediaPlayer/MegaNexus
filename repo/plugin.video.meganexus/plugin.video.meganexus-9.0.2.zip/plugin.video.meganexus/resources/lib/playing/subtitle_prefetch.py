# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The subtitle search runs while the sources are looked for.

The search needs only the item's ids, known when the title opens, so `start` begins it at
the same moment as the source scan, under one budget (`subtitle_timeout`, 10-20 s) counted
from there; when a source is picked `take` hands over what was found, waiting at most for
what is left of that budget. One search per item (type, id, season, episode) for
LIFE seconds; at most MOST are kept.

Searches and background subtitle downloads share a small pool (two threads). Kodi waits for
every thread of a finished plugin call, so `shutdown` ends it with the call (script_exit);
running work still finishes, the next call makes a new pool."""
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import xbmc

from ..hub_base import _get_int_setting

LIFE = 300.0
MOST = 32
WORKERS = 2

_lock = threading.Lock()
_searches = {}          # key -> {rows, at, event, running, started_mono, deadline_mono, budget}
_pool_lock = threading.Lock()
_pool = [None]


def pool():
    with _pool_lock:
        if _pool[0] is None:
            _pool[0] = ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='MegaNexus-Subtitle')
        return _pool[0]


def shutdown():
    """Queued and running work still finishes; then the threads end."""
    with _pool_lock:
        old, _pool[0] = _pool[0], None
    if old is not None:
        old.shutdown(wait=False)


def budget():
    """The whole search's time, 10-20 s (a broken setting never makes playback wait longer)."""
    try:
        seconds = float(_get_int_setting('subtitle_timeout', 15))
    except Exception:
        seconds = 15.0
    return max(10.0, min(20.0, seconds))


def _key(media_type, canonical_id, season=None, episode=None):
    return '%s|%s|%s|%s' % (media_type or '', canonical_id or '', season or '', episode or '')


def _tidy(now=None):
    """Old searches dropped; above MOST the oldest finished ones go (a running one stays)."""
    now = float(now or time.time())
    for key in [key for key, state in _searches.items() if now - float((state or {}).get('at') or 0.0) >= LIFE]:
        _searches.pop(key, None)
    extra = len(_searches) - MOST
    if extra <= 0:
        return
    for key in sorted(_searches, key=lambda key: float((_searches.get(key) or {}).get('at') or 0.0))[:extra]:
        if not (_searches.get(key) or {}).get('running'):
            _searches.pop(key, None)


def start(media_type, canonical_id, ids=None, title='', season=None, episode=None):
    """Begin the item's search in the background (once per LIFE); the Event is set when it
    ends. None when the subtitle search is off or no thread could be had."""
    try:
        from ..subtitle_search import enabled
        if not enabled():
            return None
    except Exception:
        return None
    key = _key(media_type, canonical_id, season, episode)
    began = time.monotonic()
    seconds = budget()
    with _lock:
        _tidy()
        known = _searches.get(key)
        if known and time.time() - known.get('at', 0) < LIFE:
            return known.get('event')
        ready = threading.Event()
        _searches[key] = {'rows': None, 'at': time.time(), 'event': ready, 'running': True,
                          'started_mono': began, 'deadline_mono': began + seconds, 'budget': seconds}

    def search():
        rows = []
        try:
            from ..subtitle_search import search as find
            ids_ = ids or {}
            rows = find({'media_type': media_type, 'canonical_id': canonical_id, 'title': title,
                         'season': season, 'episode': episode, 'imdb_id': ids_.get('imdb_id') or '',
                         'tmdb_id': ids_.get('tmdb_id') or '', 'tvdb_id': ids_.get('tvdb_id') or '',
                         'subtitle_deadline_mono': began + seconds}, initial_subtitles=None, max_results=12) or []
        except Exception as exc:
            xbmc.log('[MegaNexus] subtitle prefetch failed: %s' % exc, xbmc.LOGDEBUG)
        with _lock:
            state = _searches.get(key) or {}
            state.update({'rows': rows, 'at': time.time(), 'running': False, 'event': state.get('event') or ready})
            _searches[key] = state
            event = state['event']
        event.set()
        xbmc.log('[MegaNexus] subtitle prefetch ready: %d row(s)' % len(rows), xbmc.LOGINFO)

    try:
        pool().submit(search)
    except Exception:
        with _lock:
            _searches.pop(key, None)        # nothing runs: Play with subtitles may search itself
        ready.set()
        return None
    return ready


def take(media_type, canonical_id, season=None, episode=None, wait=0.0):
    """What the item's search found; a running one is waited for at most `wait` seconds and
    never past its budget (a source picked at 1 s of 15 waits 14 s at most, never 15 more)."""
    key = _key(media_type, canonical_id, season, episode)
    with _lock:
        state = _searches.get(key)
        if not state:
            return []
        rows, event = state.get('rows'), state.get('event')
    if rows is not None:
        return list(rows)
    seconds = max(0.0, float(wait or 0.0))
    if state.get('deadline_mono') not in (None, ''):
        try:
            seconds = min(seconds, max(0.0, float(state['deadline_mono']) - time.monotonic()))
        except Exception:
            pass
    if seconds > 0.0 and event is not None:
        event.wait(seconds)
    with _lock:
        rows = (_searches.get(key) or {}).get('rows')
    return list(rows) if rows is not None else []


def status(media_type, canonical_id, season=None, episode=None):
    """{exists, running, ready, count, budget, elapsed, remaining} for the source window."""
    with _lock:
        state = dict(_searches.get(_key(media_type, canonical_id, season, episode)) or {})
    if not state:
        return {'exists': False, 'running': False, 'ready': False, 'count': 0, 'budget': budget(),
                'elapsed': 0.0, 'remaining': 0.0}
    now = time.monotonic()
    rows = state.get('rows')
    return {'exists': True, 'running': bool(state.get('running') and rows is None), 'ready': rows is not None,
            'count': len(rows or []), 'budget': float(state.get('budget') or budget()),
            'elapsed': max(0.0, now - float(state.get('started_mono') or now)),
            'remaining': max(0.0, float(state.get('deadline_mono') or now) - now)}
