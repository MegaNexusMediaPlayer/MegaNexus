# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Subtitles handed to Kodi's player: gathered, saved as local files, checked and repaired.

`collect` gathers the stream's own subtitles (and the one the user chose) and, for Play with
subtitles, the add-on search - the prefetched one when the source scan began it. `prepare`
saves each as a file named for Kodi's list (subtitle_names.file_name) in a folder per
stream: at once, or (`later`) in the background so the playback handoff never waits.

A download keeps to one urllib try with a short wait (Kodi's VFS may retry for minutes),
refuses HTML / error text, fixes letters a code page mixed up (repair_text) and remembers a
server that is gone for DEAD_FOR seconds. Plex sidecars go through plex.fetch (its TLS
recovery for plex.direct)."""
import json
import os
import re
import socket
import threading
import time
from urllib.parse import parse_qsl, urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .. import plex
from .. import subtitle_names as names
from ..hub_base import SUBS_DIR, WINDOW_ID, _get_int_setting, notify
from ..texts import tr
from . import subtitle_prefetch as prefetch

try:
    from ..settings_snapshot import cached_addon as _cached_addon
except Exception:
    _cached_addon = None
ADDON = _cached_addon() if _cached_addon else xbmcaddon.Addon('plugin.video.meganexus')

SMALLEST = 32                      # bytes: a tiny WebVTT cue
LARGEST = 5 * 1024 * 1024          # a very long episode's .ass
IMAGE_CODECS = frozenset(('pgs', 'hdmv_pgs_subtitle', 'hdmv-pgs-subtitle', 'pgssub', 'vobsub', 'dvd_subtitle',
                          'dvd-subtitle', 'dvdsub', 'dvb_subtitle', 'dvb-subtitle', 'dvbsub', 'xsub'))
SUBTITLE_ENDINGS = ('.srt', '.ass', '.ssa', '.vtt', '.sub', '.idx', '.smi')
WEB = ('http://', 'https://')


def _plugin():
    from .. import hub as plugin
    return plugin


# ---- the subtitles of a playback ------------------------------------------------------------


def _readable_source(ctx):
    """The stream's add-on as a name - a manifest address or a long id gives its last part or nothing."""
    name = (ctx.get('provider_name') or ctx.get('stream_addon_name') or ctx.get('source_provider_name')
            or ctx.get('provider_id') or ctx.get('addon_name') or '')
    if name and ('/' in name or len(name) > 40):
        tail = name.rsplit('/', 1)[-1].split('?')[0]
        name = tail if tail and len(tail) < 40 else ''
    return name


def _row(value, kind, source):
    row = dict(value) if isinstance(value, dict) else {'url': value, 'id': value, 'lang': 'und'}
    row.setdefault('sourceType', kind)
    row.setdefault('sourceName', source)
    return row


def is_image_track(sub):
    """A picture subtitle (PGS, VobSub, DVB) - setSubtitles cannot load it."""
    sub = sub or {}
    return any(str(sub.get(field) or '').strip().lower() in IMAGE_CODECS for field in ('codec', 'format'))


def playable(rows):
    """The subtitles the player can show (picture tracks left out, and logged)."""
    kept, left = [], []
    for row in rows or []:
        if is_image_track(row):
            left.append(str(row.get('lang') or row.get('title') or '?'))
        else:
            kept.append(row)
    if left:
        xbmc.log('[MegaNexus] dropped %d bitmap subtitle(s) the player cannot load: %s'
                 % (len(left), ', '.join(left[:5])), xbmc.LOGINFO)
    return kept


def collect(ctx, include_broker=True):
    """The chosen subtitle first, the stream's own next; with `include_broker` (Play with
    subtitles) also the add-on search - a prefetch, finished or not, is the answer (a
    second search would double the traffic and the wait)."""
    source = _readable_source(ctx)
    rows = []
    if ctx.get('selected_subtitle'):
        chosen = _row(ctx['selected_subtitle'], 'manual', source)
        chosen['user_selected'] = True
        rows.append(chosen)
    rows += [_row(sub, 'stream', source) for sub in ctx.get('subtitles') or []]
    try:
        rows = playable(rows)
        if not include_broker:
            return rows or []
        item = (ctx.get('media_type'), ctx.get('canonical_id'), ctx.get('season'), ctx.get('episode'))
        before = prefetch.status(*item)
        found = playable(prefetch.take(*item, wait=max(1.0, prefetch.budget())))
        after = prefetch.status(*item)
        if before.get('exists') or after.get('exists'):
            xbmc.log('[MegaNexus] subtitles served from source-scan prefetch (%d, %.1fs elapsed)'
                     % (len(found), after.get('elapsed') or 0.0), xbmc.LOGINFO)
            return (rows or []) + [row for row in found if row not in (rows or [])]
        from ..subtitle_search import search
        found = search(ctx, initial_subtitles=rows, max_results=12)
    except Exception as exc:
        xbmc.log('[MegaNexus] subtitle broker failed: %s' % exc, xbmc.LOGWARNING)
        found = rows
    return found or []


def publish_ids(ctx, is_episode):
    """The item's ids as Home window properties, for subtitle services that look before Kodi
    has filled VideoPlayer.* (it does that only after the start)."""
    try:
        home = xbmcgui.Window(10000)
        for name, value in (('imdb_id', lambda: ctx.get('imdb_id') or ''), ('tmdb_id', lambda: ctx.get('tmdb_id') or ''),
                            ('tvdb_id', lambda: ctx.get('tvdb_id') or ''),
                            ('season', lambda: str(int(ctx.get('season') or 0)) if is_episode else ''),
                            ('episode', lambda: str(int(ctx.get('episode') or 0)) if is_episode else ''),
                            ('title', lambda: ctx.get('title') or ''),
                            ('mediatype', lambda: 'episode' if is_episode else 'movie')):
            home.setProperty('meganexus.sub.' + name, value())
    except Exception:
        pass


def kodi_subtitle_addons():
    """The Kodi subtitle add-ons the user installed (a4kSubtitles, …): [{id, name, thumb}]."""
    asked = {'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddons',
             'params': {'type': 'xbmc.subtitle.module', 'enabled': True, 'properties': ['name', 'thumbnail']}}
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps(asked)) or '{}')
    except Exception:
        return []
    return [{'id': str(row['addonid']), 'name': str(row.get('name') or row['addonid']),
             'thumb': str(row.get('thumbnail') or '')}
            for row in (answer.get('result') or {}).get('addons') or [] if row.get('addonid')]


def open_kodi_search():
    """Kodi's own subtitle search for what is playing (every installed subtitle add-on at once)."""
    try:
        if not xbmc.Player().isPlaying():
            notify(tr('Play something first'))
            return
    except Exception:
        pass
    found = kodi_subtitle_addons()
    xbmc.log('[MegaNexus] subtitle addons available: %s' % (', '.join(a['id'] for a in found) or 'none'),
             xbmc.LOGINFO)
    if not found:
        notify(tr('No subtitle addons installed'))
        return
    xbmc.executebuiltin('ActivateWindow(SubtitleSearch)')


# ---- servers ---------------------------------------------------------------------------------

# 7.0.29: a subtitle server that did not answer is skipped for a while (a local
# add-on host that is off made every Croatian release wait for its timeout).
_DEAD_HOSTS = {}
_DEAD_FOR = 600
_SLOW_HOSTS = {}
_ALIVE_HOSTS = {}
_CONNECT_WAIT = 3


def reachable(url):
    """7.0.45: does the subtitle's server take a connection at all (a quick look,
    remembered for _DEAD_FOR)? A server that is gone - an add-on on a network you
    left - is told in 3 s, not after a download's whole wait for each of its
    releases; a busy line still connects at once."""
    parsed = urlparse(str(url or '').split('|', 1)[0])
    host = str(parsed.netloc or '').lower()
    if not host or parsed.scheme not in ('http', 'https'):
        return True
    now = time.time()
    if now - _DEAD_HOSTS.get(host, 0) < _DEAD_FOR:
        return False
    if now - _ALIVE_HOSTS.get(host, 0) < _DEAD_FOR:
        return True
    try:
        port = parsed.port or (443 if parsed.scheme == 'https' else 80)
        socket.create_connection((parsed.hostname, port), _CONNECT_WAIT).close()
    except (OSError, ValueError):
        _DEAD_HOSTS[host] = time.time()
        return False
    _ALIVE_HOSTS[host] = time.time()
    return True


def reachable_hosts(urls):
    """{host: reachable} for the servers of these subtitles, looked at side by side."""
    hosts = {}
    for url in urls:
        host = str(urlparse(str(url or '').split('|', 1)[0]).netloc or '').lower()
        hosts.setdefault(host, url)
    found = {}

    def one(host, url):
        found[host] = reachable(url)
    threads = [threading.Thread(target=one, args=item, daemon=True) for item in hosts.items()]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(_CONNECT_WAIT + 1)
    return {host: found.get(host, False) for host in hosts}


_SUBTITLE_TEXT = re.compile(br'-->|^\s*WEBVTT|\[Script Info\]|^\s*Dialogue:|^\s*\{\d+\}\{\d+\}', re.M)


def _looks_like_subtitle(payload):
    """SRT / WebVTT / ASS / MicroDVD - not a server's error text ("Sorry. We have
    problem with network connection...") that is small enough to pass the size check."""
    return bool(_SUBTITLE_TEXT.search(payload[:65536]))


# ---- letters -------------------------------------------------------------------------------

# 7.0.45: some subtitle add-ons turn a file in a Windows code page into UTF-8 as if it
# were Latin-1 - Croatian "š" became the control character U+009A, Russian "Привет"
# became "Ïðèâåò". Every language's own code page puts its letters back; a file still
# in that code page (not UTF-8) is turned into UTF-8 when its language is known.
PAGES = {}
for _page_name, _langs in (('cp1250', 'hr bs sl cs sk pl hu ro sq me'), ('cp1251', 'ru uk bg mk be kk'),
                           ('cp1253', 'el'), ('cp1254', 'tr az'),
                           ('cp1257', 'lt lv et'), ('cp1258', 'vi')):
    for _lang in _langs.split():
        PAGES[_lang] = (_page_name,)
PAGES['sr'] = ('cp1250', 'cp1251')                    # Serbian: Latin or Cyrillic
SCRIPTS = {'cp1251': ('Ѐ', 'ӿ'), 'cp1253': ('Ͱ', 'Ͽ')}           # pages of another script than Latin
_C1 = re.compile('[\x80-\x9f]')


def _pages(lang):
    return PAGES.get(str(lang or '').lower()[:2], ('cp1252',))


def _convert(text, page):
    def back(match):
        try:
            return bytes([ord(match.group(0))]).decode(page)
        except UnicodeDecodeError:
            return match.group(0)
    return re.sub('[\x80-\xff]', back, text)


def _letters(text, page):
    """How many letters of the page's own alphabet (beyond plain Latin) the text holds."""
    if page in SCRIPTS:
        low, high = SCRIPTS[page]
        return sum(1 for ch in text if low <= ch <= high)
    return sum(1 for ch in text if 'Ā' <= ch <= 'ɏ' or 'Ạ' <= ch <= 'ỹ')


def _mis_read(text, pages):
    if _C1.search(text):
        return True                                   # never in a real subtitle
    # none of the language's own letters (č, ş, ł, ё, α...) - but read in its code page, there they are
    return any(p != 'cp1252' and not _letters(text, p) and _letters(_convert(text, p), p) >= 2 for p in pages)


def repair_text(payload, lang=''):
    """The subtitle's bytes with its language's letters put right (UTF-8)."""
    pages = _pages(lang)
    try:
        text = payload.decode('utf-8')
    except UnicodeDecodeError:
        if str(lang or '').lower()[:2] in ('', 'un'):
            return payload                            # unknown language: Kodi's own charset setting decides
        for page in sorted(pages, key=lambda p: -_letters(payload.decode(p, 'replace'), p)):
            try:
                return payload.decode(page).encode('utf-8')
            except UnicodeDecodeError:
                continue
        return payload
    if not _mis_read(text, pages):
        return payload
    best = max(pages, key=lambda p: _letters(_convert(text, p), p))
    return _convert(text, best).encode('utf-8')


def _repair_file(path, lang=''):
    try:
        handle = xbmcvfs.File(path)
        try:
            payload = bytes(handle.readBytes())
        finally:
            handle.close()
        fixed = repair_text(payload, lang)
        if fixed != payload:
            handle = xbmcvfs.File(path, 'wb')
            try:
                handle.write(fixed)
            finally:
                handle.close()
    except Exception:
        pass


# ---- downloads -------------------------------------------------------------------------------


def _request_parts(url):
    """(address, headers) - Kodi's "url|Header=value&…" form split."""
    headers = {'User-Agent': 'MegaNexus/%s (Kodi)' % (ADDON.getAddonInfo('version') or '8.1.0'),
               'Accept': 'text/plain,text/vtt,application/x-subrip,*/*;q=0.5'}
    if '|' in url:
        url, extra = url.split('|', 1)
        try:
            headers.update((str(key), str(value)) for key, value in parse_qsl(extra, keep_blank_values=True) if key)
        except Exception:
            pass
    return url, headers


def _is_subtitle(payload):
    if not payload or len(payload) < SMALLEST or len(payload) > LARGEST:
        return False
    head = payload[:256].lstrip().lower()
    if b'<tt ' in head:
        return True                                   # TTML
    return not head.startswith((b'<!doctype html', b'<html', b'<?xml')) and _looks_like_subtitle(payload)


def _note_failure(host, exc):
    """7.0.45: one slow answer is a busy line (the film buffering), not a dead server - only
    the second in a row keeps the host out; a refused / unreachable one is out at once."""
    reason = str(getattr(exc, 'reason', '') or exc).lower()
    if isinstance(exc, (socket.timeout, TimeoutError)) or 'timed out' in reason:
        _SLOW_HOSTS[host] = _SLOW_HOSTS.get(host, 0) + 1
        if _SLOW_HOSTS[host] >= 2:
            _DEAD_HOSTS[host] = time.time()
    elif isinstance(exc, ConnectionError) or any(word in reason for word in ('refused', 'unreachable', 'no route')):
        _DEAD_HOSTS[host] = time.time()


def download(url, path, timeout=None):
    """Save an http(s) subtitle to `path` with one urllib try; True when a real subtitle was
    written. `timeout` given: off the playback path (7.0.45), where the wait may be longer;
    else 2-6 s from subtitle_timeout."""
    url = str(url or '').strip()
    if not url.lower().startswith(WEB):
        return False
    url, headers = _request_parts(url)
    host = str(urlparse(url).netloc or '').lower()
    if host and not reachable(url):
        return False
    try:
        timeout = timeout or min(6, max(2, _get_int_setting('subtitle_timeout', 15)))
        parts = urlparse(url)
        if str(parts.hostname or '').lower().endswith('.plex.direct') or 'x-plex-token=' in str(parts.query or '').lower():
            payload = plex.fetch(url, headers=headers, timeout=timeout)[:LARGEST + 1]
        else:
            with urlopen(Request(url, headers=headers), timeout=timeout) as answer:
                payload = answer.read(LARGEST + 1)
        if not _is_subtitle(payload):
            return False
        _SLOW_HOSTS.pop(host, None)
        handle = xbmcvfs.File(path, 'wb')
        try:
            written = handle.write(payload)
        finally:
            handle.close()
        return bool(written is None or int(written) > 0) and xbmcvfs.exists(path)
    except Exception as exc:
        if host:
            _note_failure(host, exc)
        try:
            if xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except Exception:
            pass
        return False


def _fetch(url, path):
    if str(url or '').lower().startswith(WEB):
        download(url, path)
    else:
        xbmcvfs.copy(url, path)


def download_later(jobs):
    """(address, path[, language]) jobs saved in the background: the paths go to Kodi at once
    and a slow server never holds the handoff (Kodi's resolver would time out)."""
    jobs = list(jobs or [])
    if not jobs:
        return

    def work():
        for job in jobs:
            try:
                if xbmcvfs.exists(job[1]):
                    continue
                _fetch(job[0], job[1])
                if len(job) > 2 and xbmcvfs.exists(job[1]):
                    _repair_file(job[1], job[2])
            except Exception as exc:
                xbmc.log('[MegaNexus] subtitle background download failed: %s' % exc, xbmc.LOGDEBUG)
    try:
        prefetch.pool().submit(work)
    except Exception:
        pass


def _size_fits(path):
    try:
        with xbmcvfs.File(path) as handle:
            size = handle.size()
        return SMALLEST <= size <= LARGEST
    except Exception:
        return True                                   # cannot tell: keep it


def _saved(url, path, web, wait, lang):
    """Save one subtitle now; its local path, else the address itself."""
    try:
        if not xbmcvfs.exists(path):
            if web:
                download(url, path, wait)
            else:
                xbmcvfs.copy(url, path)
        if not xbmcvfs.exists(path):
            return url
        _repair_file(path, lang)                      # 7.0.45: letters a code page mixed up
        if _size_fits(path):
            return path
        try:
            xbmcvfs.delete(path)                      # an HTML page the VFS stored: urllib once more
        except Exception:
            pass
    except Exception:
        pass
    return path if web and download(url, path, wait) else url


def _folder(stream_key):
    """A folder per stream (its subtitles keep their names apart); SUBS_DIR when it cannot be made."""
    try:
        if not xbmcvfs.exists(SUBS_DIR):
            xbmcvfs.mkdirs(SUBS_DIR)
    except Exception:
        pass
    folder = os.path.join(SUBS_DIR, (re.sub(r'[^\w\-]+', '_', str(stream_key or 'play')).strip('_') or 'play')[:80])
    try:
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
    except Exception:
        return SUBS_DIR
    return folder


def prepare(subtitles, stream_key, local_copy=False, later=False, wait=None):
    """[{path, subtitle, lang_key}] for Kodi. http(s) subtitles are always saved locally (Kodi
    lists them by file name, and fetching mid-handoff fails silently), other paths only with
    `local_copy`; `later` hands over the paths and saves them in the background."""
    if not subtitles:
        return []
    folder = _folder(stream_key)
    try:
        work_title = (xbmcgui.Window(WINDOW_ID).getProperty('meganexus.source.title') or '').strip()
    except Exception:
        work_title = ''
    out, jobs, taken = [], [], set()
    for sub in subtitles:
        url = sub.get('url') or sub.get('key')
        if not url:
            continue
        name, lang = names.file_name(sub, url, taken, work_title)
        path = os.path.join(folder, name)
        web = str(url).lower().startswith(WEB)
        final = url
        if (web or local_copy) and later:
            final = path
            if not xbmcvfs.exists(path):
                jobs.append((url, path, lang))
        elif web or local_copy:
            final = _saved(url, path, web, wait, lang)
        out.append({'path': final, 'subtitle': sub, 'lang_key': lang})
    download_later(jobs)
    return out


# ---- a source switch -----------------------------------------------------------------------


def _shown_now():
    """Are subtitles on in the playing video (Kodi's player id is not assumed)?"""
    plugin = _plugin()
    players = plugin._kodi_rpc('Player.GetActivePlayers') or []
    for row in players if isinstance(players, list) else []:
        if str(row.get('type') or '') != 'video':
            continue
        try:
            player_id = int(row.get('playerid'))
        except Exception:
            continue
        found = plugin._kodi_rpc('Player.GetProperties', {'playerid': player_id,
                                                              'properties': ['subtitleenabled']}) or {}
        if isinstance(found, dict) and 'subtitleenabled' in found:
            return bool(found['subtitleenabled'])
    try:
        return bool(xbmc.getCondVisibility('VideoPlayer.HasSubtitles'))
    except Exception:
        return True


def _keep_folder():
    folder = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.meganexus/subtitle_cache')
    try:
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
    except Exception:
        try:
            os.makedirs(folder, exist_ok=True)
        except Exception:
            pass
    return folder


def _exists(path):
    try:
        return bool(xbmcvfs.exists(path) or os.path.exists(path))
    except Exception:
        return False


def _copy(source, target):
    try:
        if xbmcvfs.copy(source, target):
            return True
    except Exception:
        pass
    try:
        with open(source, 'rb') as reader, open(target, 'wb') as writer:
            writer.write(reader.read())
        return True
    except Exception:
        return False


def capture_for_switch(player):
    """The external subtitle on screen, kept for the next source of a switch: {} for an
    internal track (track numbers differ between sources). A local / temporary file is
    copied to MegaNexus' own folder before the old source stops (Kodi or an add-on may
    delete it) - a VobSub with its pair; an address stays as it is."""
    try:
        path = str(player.getSubtitles() or '').strip()
    except Exception:
        path = ''
    if not path:
        return {}
    plain = path.lower().split('?', 1)[0]
    if not (plain.endswith(SUBTITLE_ENDINGS) or path.startswith(WEB + ('special://',))):
        return {}
    shown = _shown_now()
    name = os.path.basename(plain.replace('\\', '/')) or 'subtitle.srt'
    kept = path
    if not path.startswith(WEB):
        try:
            source = xbmcvfs.translatePath(path)
        except Exception:
            source = path
        if _exists(source):
            import hashlib
            ending = os.path.splitext(name)[1].lower() or '.srt'
            mark = hashlib.sha1((source + str(time.time_ns())).encode('utf-8', 'ignore')).hexdigest()[:16]
            target = os.path.join(_keep_folder(), 'switch_%s%s' % (mark, ending))
            if _copy(source, target):
                kept = target
                if ending in ('.idx', '.sub'):         # VobSub: index and pictures side by side
                    pair = '.sub' if ending == '.idx' else '.idx'
                    if _exists(os.path.splitext(source)[0] + pair):
                        _copy(os.path.splitext(source)[0] + pair, os.path.splitext(target)[0] + pair)
    return {'switch_subtitle_path': kept, 'switch_subtitle_enabled': bool(shown),
            'switch_subtitle_name': name, 'switch_subtitle_captured_at': int(time.time())}
