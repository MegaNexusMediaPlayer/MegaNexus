# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.1: what a day of the Calendar holds, asked anew every time the day is opened (meganexus_ui/calendar.py) - "u
kalendaru ništa ne keširaj, sve sa interneta grabi ... kad kliknem datum ti traži sa servisa koji nude onda za taj
datum, a iz naših servisa i trackinga šta je pogledano na taj dan, ali ne stavljaj šta sam krenuo gledati nego samo
šta sam završio".

Two rows, each title once ("pojavljuju se dolje dupli naslovi" - a series kept under two ids, the same title in two
rows, eight episodes of a show out on one day):
* ``coming`` - out that day: yours first (Trakt's calendar of your shows and films when it is connected, the episodes
  of the series you watch from the lists MegaNexus keeps of them), then TMDB's most popular: the films and series
  that premiere that day and the series with an episode out that day. A series' episodes of the day are one card
  (S1 E1-E8).
* ``watched`` - what you finished that day (not what was only started): MegaNexus's own (with what the Nuvio account
  brought), Trakt's history of the day, Simkl's watched dates - newest first, a series' episodes on one card.
WeTrakr keeps no dates and MDBList only its whole history, so neither can say what a day held.
"""
import calendar as _calendar
import re
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone

WORKERS = 6
TMDB_PAGES = (('movie', 'primary_release_date', 'Movie'), ('tv', 'first_air_date', 'Series premiere'),
              ('tv', 'air_date', 'New episode'))
ROWS = ('coming', 'watched')


def bounds(year, month):
    """(first day, last day) of the month."""
    return date(year, month, 1), date(year, month, _calendar.monthrange(year, month)[1])


def _local_day(value):
    """The local day of an ISO date or time (a bare date is that day)."""
    from .watch_nextup import release_day
    return release_day({'released': value}) if value else None


def _span(day):
    """(the day's first second, the next day's) as UTC times - a day is the person's own, not Greenwich's."""
    start = datetime(day.year, day.month, day.day).astimezone()
    return start.astimezone(timezone.utc), (start + timedelta(days=1)).astimezone(timezone.utc)


def _iso(stamp):
    return stamp.strftime('%Y-%m-%dT%H:%M:%S.000Z')


def _key(card):
    """One title, whatever id it came under: its kind and its name (a "(2026)" after it left out)."""
    name = re.sub(r'\s*\(\d{4}\)\s*$', '', str(card.get('title') or '')).casefold().strip()
    kind = (card.get('target') or {}).get('media_type') or 'movie'
    return ('series' if kind in ('series', 'tv', 'show', 'anime') else 'movie', re.sub(r'\s+', ' ', name))


def _card(title, poster, target, line='', fanart='', episode=None, when=0.0, plot='', logo=''):
    return {'title': title, 'subtitle': line, 'poster': poster or '', 'fanart': fanart or '', 'target': target,
            'plot': plot or '', 'clearlogo': logo or '', '_episode': episode, '_when': when}


def _episodes_line(found):
    """'S1 E5', or 'S1 E1-E8' for a run of one season, else the first and how many more."""
    found = sorted(set(e for e in found if e))
    if not found:
        return ''
    if len(found) == 1:
        return 'S%d E%d' % found[0]
    if len({season for season, _ in found}) == 1:
        return 'S%d E%d-E%d' % (found[0][0], found[0][1], found[-1][1])
    return 'S%d E%d +%d' % (found[0][0], found[0][1], len(found) - 1)


def together(cards, hour=False):
    """Each title once, in the order first met; a series' episodes on its one card (and the hour it was watched,
    the latest, when ``hour``)."""
    order, kept = [], {}
    for card in cards:
        key = _key(card)
        if not key[1]:
            continue
        if key not in kept:
            kept[key] = dict(card, _episodes=[], _times=[])
            order.append(key)
        one = kept[key]
        if card.get('_episode'):
            one['_episodes'].append(card['_episode'])
        if card.get('_when'):
            one['_times'].append(card['_when'])
        for field in ('poster', 'fanart', 'clearlogo', 'plot'):     # what another source had of it
            if not one.get(field) and card.get(field):
                one[field] = card[field]
    out = []
    for key in order:
        one = kept[key]
        line = _episodes_line(one['_episodes']) or one.get('subtitle') or ''
        if hour and one['_times']:
            at = datetime.fromtimestamp(max(one['_times'])).strftime('%H:%M')
            line = '%s · %s' % (line, at) if one['_episodes'] else at
        if hour:
            one['_order'] = max(one['_times'] or [0])
        out.append({k: v for k, v in dict(one, subtitle=line).items() if not k.startswith('_') or k == '_order'})
    if hour:
        out.sort(key=lambda card: -card.get('_order', 0))
    return [{k: v for k, v in card.items() if k != '_order'} for card in out]


def _ids_target(kind, ids, title):
    ids = ids or {}
    imdb = str(ids.get('imdb') or '')
    tmdb = str(ids.get('tmdb') or '')
    cid = imdb or ('tmdb:' + tmdb if tmdb else '')
    return {'media_type': kind, 'canonical_id': cid, 'imdb_id': imdb, 'tmdb_id': tmdb, 'title': title}


# --- what comes out --------------------------------------------------------------------------------------------
def local():
    """What the device itself says, read once for a whole visit of the Calendar (no internet in it): the playback
    rows and the series that are yours (played or saved) - 0.8 s on the Cube for the Library alone, every day it was
    asked again."""
    played, mine = [], set()
    try:
        from .meganexus import progress_db
        played = progress_db.list_recent_items(limit=5000)
    except Exception:
        pass
    for row in played:
        if row.get('media_type') == 'series':
            mine.update(str(row.get(k) or '') for k in ('canonical_id', 'imdb_id'))
            if row.get('show_tmdb_id'):
                mine.add('tmdb:%s' % row['show_tmdb_id'])
    try:
        from . import library
        for card in library.everything():
            target = card.get('target') or {}
            if target.get('media_type') == 'series':
                mine.add(str(target.get('canonical_id') or ''))
    except Exception:
        pass
    mine.discard('')
    return {'played': played, 'mine': mine}


def _yours(day, known):
    """The series you watch: their kept episode lists (watch_nextup) - only those you have played or saved."""
    from .watch_nextup import _read, number, release_day
    mine = known['mine']
    out = []
    for mid, kept in _read().items():
        meta = (kept or {}).get('meta') or {}
        name = meta.get('name') or meta.get('title') or ''
        if not name or str(mid) not in mine:
            continue
        for episode in meta.get('videos') or []:
            if isinstance(episode, dict) and number(episode.get('season')) > 0 and release_day(episode) == day:
                target = {'media_type': 'series', 'canonical_id': str(mid), 'title': name}
                out.append(_card(name, meta.get('poster'), target, fanart=meta.get('background'),
                                 episode=(number(episode.get('season')), number(episode.get('episode'))),
                                 plot=meta.get('description'), logo=meta.get('logo')))
    return out


def _trakt_coming(day):
    """Trakt's calendar of your shows and your films (connected): what of yours comes out that day."""
    from . import trakt_api
    if not trakt_api.authorized():
        return []
    start = (day - timedelta(days=1)).isoformat()     # (Trakt's days are Greenwich's: one each side, then ours)
    out = []
    for kind in ('shows', 'movies'):
        try:
            rows = trakt_api._request('/calendars/my/%s/%s/3' % (kind, start), auth=True, timeout=10) or []
        except Exception:
            continue
        for row in rows if isinstance(rows, list) else []:
            if kind == 'shows':
                show, episode = row.get('show') or {}, row.get('episode') or {}
                if _local_day(row.get('first_aired')) != day:
                    continue
                title = show.get('title') or ''
                out.append(_card(title, '', _ids_target('series', show.get('ids'), title),
                                 episode=(int(episode.get('season') or 0), int(episode.get('number') or 0))))
            else:
                movie = row.get('movie') or {}
                if _local_day(row.get('released')) != day:
                    continue
                title = movie.get('title') or ''
                out.append(_card(title, '', _ids_target('movie', movie.get('ids'), title), 'Movie'))
    return out


def _tmdb_coming(day):
    """TMDB's most popular of the day: films first shown, series begun, series with an episode out."""
    from . import tmdb_api
    if not tmdb_api.api_key():
        return []

    def ask(job):
        kind, field, line = job
        params = {field + '.gte': day.isoformat(), field + '.lte': day.isoformat(), 'sort_by': 'popularity.desc',
                  'include_adult': 'false', 'page': 1}
        try:
            return job, tmdb_api.get('/discover/' + kind, params, timeout=8).get('results') or []
        except Exception:
            return job, []
    with ThreadPoolExecutor(max_workers=len(TMDB_PAGES), thread_name_prefix='MegaNexusCalendar') as pool:
        answers = list(pool.map(ask, TMDB_PAGES))
    out = []
    for (kind, field, line), results in answers:
        for row in results:
            if not (row.get('poster_path') and row.get('id')):
                continue
            media = 'movie' if kind == 'movie' else 'series'
            title = row.get('title') or row.get('name') or ''
            target = {'media_type': media, 'canonical_id': 'tmdb:%s' % row['id'], 'tmdb_id': str(row['id']), 'title': title}
            out.append(_card(title, tmdb_api.picture(row['poster_path']), target, line,
                             tmdb_api.picture(row.get('backdrop_path'), 'backdrop'), plot=row.get('overview')))
    return out


# --- what was finished -----------------------------------------------------------------------------------------
def _here_watched(day, known):
    """MegaNexus's own playback (and what the Nuvio account brought): what was played to its end that day."""
    from .meganexus.paths import watched_percent
    start, end = (stamp.timestamp() for stamp in _span(day))
    out = []
    for row in known['played']:
        stamp = float(row.get('updated_at') or 0)
        if not start <= stamp < end:
            continue
        if not (row.get('event_type') == 'watched' or float(row.get('percent') or 0) >= watched_percent()):
            continue                                                    # only started: not watched
        series = row.get('media_type') == 'series' and row.get('season') is not None
        target = {'media_type': row.get('media_type') or 'movie', 'canonical_id': str(row.get('canonical_id') or ''),
                  'title': row.get('title') or '', 'tmdb_id': str(row.get('show_tmdb_id') or row.get('tmdb_id') or ''),
                  'imdb_id': str(row.get('imdb_id') or '')}
        out.append(_card(row.get('title') or '', row.get('poster'), target, fanart=row.get('background'),
                         episode=(int(row['season']), int(row.get('episode') or 0)) if series else None, when=stamp))
    return out


def _trakt_watched(day):
    """Trakt's history of the day (connected): every film and episode watched then."""
    from . import trakt_api
    if not trakt_api.authorized():
        return []
    start, end = _span(day)
    try:
        rows = trakt_api._request('/sync/history?start_at=%s&end_at=%s&limit=250' % (_iso(start), _iso(end)),
                                  auth=True, timeout=10) or []
    except Exception:
        return []
    out = []
    for row in rows if isinstance(rows, list) else []:
        when = _epoch(row.get('watched_at'))
        if row.get('type') == 'episode':
            show, episode = row.get('show') or {}, row.get('episode') or {}
            title = show.get('title') or ''
            out.append(_card(title, '', _ids_target('series', show.get('ids'), title),
                             episode=(int(episode.get('season') or 0), int(episode.get('number') or 0)), when=when))
        elif row.get('type') == 'movie':
            movie = row.get('movie') or {}
            title = movie.get('title') or ''
            out.append(_card(title, '', _ids_target('movie', movie.get('ids'), title), when=when))
    return out


def _simkl_watched(day):
    """Simkl's watched dates (connected): films finished that day, episodes watched that day."""
    from . import simkl_api
    if not simkl_api.authorized():
        return []
    start, end = (stamp.timestamp() for stamp in _span(day))
    since = _iso(_span(day)[0])
    out = []
    asks = (('movies', '/sync/all-items/movies/completed?extended=full&date_from=%s' % since),
            ('shows', '/sync/all-items/shows/?extended=full&episode_watched_at=yes&date_from=%s' % since),
            ('anime', '/sync/all-items/anime/?extended=full&episode_watched_at=yes&date_from=%s' % since))
    for kind, path in asks:
        try:
            answer = simkl_api._request(path, auth=True, timeout=15) or {}
        except Exception:
            continue
        for row in answer.get(kind) or []:
            if kind == 'movies':
                movie = row.get('movie') or {}
                when = _epoch(row.get('last_watched_at'))
                if start <= when < end:
                    title = movie.get('title') or ''
                    out.append(_card(title, simkl_api.poster_url(movie.get('poster')),
                                     _ids_target('movie', movie.get('ids'), title), when=when))
                continue
            show = row.get('show') or {}
            title = show.get('title') or ''
            for season in row.get('seasons') or []:
                for episode in season.get('episodes') or []:
                    when = _epoch(episode.get('watched_at'))
                    if start <= when < end:
                        out.append(_card(title, simkl_api.poster_url(show.get('poster')),
                                         _ids_target('series', show.get('ids'), title),
                                         episode=(int(season.get('number') or 1), int(episode.get('number') or 0)),
                                         when=when))
    return out


def _epoch(value):
    if not value:
        return 0.0
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).timestamp()
    except ValueError:
        return 0.0


def _posters(cards):
    """The cards that came without a picture (Trakt's): TMDB's, by their ids - kept details first, then asked."""
    from .title_top import dress
    dress(cards, cached_only=True)
    dress([card for card in cards if not card.get('poster')])
    return cards


def day_rows(day, known=None):
    """{'coming': [card], 'watched': [card]} of ``day`` (a date), every source on the internet asked now; ``known``:
    local(), when it was read already for this visit."""
    known = known if known is not None else local()
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix='MegaNexusCalendar') as pool:
        jobs = [pool.submit(fn, day) for fn in (_trakt_coming, _tmdb_coming, _trakt_watched, _simkl_watched)]
        yours, here = _yours(day, known), _here_watched(day, known)
        trakt_coming, tmdb_coming, trakt_watched, simkl_watched = (job.result() for job in jobs)
    coming = together(trakt_coming + yours + tmdb_coming)
    watched = together(here + trakt_watched + simkl_watched, hour=True)
    _posters(coming + watched)
    return {'coming': coming, 'watched': watched}


def poster_tint(poster):
    """The colour a date's number takes from its first poster ('D9RRGGBB', '' without one) - as the Top 10's
    (top10_rows.tints, from TMDB's smallest picture of it when it is TMDB's)."""
    if not poster:
        return ''
    small = re.sub(r'(image\.tmdb\.org/t/p/)[^/]+/', r'\1w92/', poster)
    try:
        from . import top10_rows
        return top10_rows.tints([small]).get(small, '')
    except Exception:
        return ''


SEARCH_MOST = 8          # titles TMDB is asked about at most for the magnifier


def search(query):
    """The magnifier's: [(date, words, card)] - when titles called so come out or came out (TMDB: a film's
    premiere, a series' next episode or its first), and when you finished something called so here."""
    from . import tmdb_api
    from .meganexus import progress_db
    from .meganexus.paths import watched_percent
    found, wanted = [], query.casefold().strip()
    if tmdb_api.api_key():
        try:
            results = tmdb_api.get('/search/multi', {'query': query, 'include_adult': 'false'}, timeout=8).get('results') or []
        except Exception:
            results = []
        results = [row for row in results if row.get('media_type') in ('movie', 'tv') and row.get('id')][:SEARCH_MOST]

        def when(row):
            if row['media_type'] == 'movie':
                return _local_day(row.get('release_date')), 'Movie'
            try:
                show = tmdb_api.get('/tv/%s' % row['id'], timeout=8) or {}
            except Exception:
                show = {}
            coming = (show.get('next_episode_to_air') or {}).get('air_date')
            return (_local_day(coming), 'Next episode') if coming else (_local_day(row.get('first_air_date')), 'Series')
        with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='MegaNexusCalendarSearch') as pool:
            days = list(pool.map(when, results))
        for row, (day, kind) in zip(results, days):
            if not day:
                continue
            media = 'movie' if row['media_type'] == 'movie' else 'series'
            title = row.get('title') or row.get('name') or ''
            target = {'media_type': media, 'canonical_id': 'tmdb:%s' % row['id'], 'tmdb_id': str(row['id']), 'title': title}
            words = '%s · %s %s' % (kind, 'Comes out' if day > date.today() else 'Out', day.strftime('%d %B %Y').lstrip('0'))
            found.append((day, words, _card(title, tmdb_api.picture(row.get('poster_path')), target)))
    try:
        rows = progress_db.list_recent_items(limit=5000)
    except Exception:
        rows = []
    seen = set()
    for row in rows:
        title = str(row.get('title') or '')
        if wanted not in title.casefold():
            continue
        if not (row.get('event_type') == 'watched' or float(row.get('percent') or 0) >= watched_percent()):
            continue
        day = datetime.fromtimestamp(float(row.get('updated_at') or 0)).date()
        if (title.casefold(), day) in seen:
            continue
        seen.add((title.casefold(), day))
        target = {'media_type': row.get('media_type') or 'movie', 'canonical_id': str(row.get('canonical_id') or ''), 'title': title}
        line = ('S%s E%s · ' % (row.get('season'), row.get('episode'))) if row.get('season') is not None else ''
        found.append((day, '%sWatched %s' % (line, day.strftime('%d %B %Y').lstrip('0')), _card(title, row.get('poster'), target)))
    return found
