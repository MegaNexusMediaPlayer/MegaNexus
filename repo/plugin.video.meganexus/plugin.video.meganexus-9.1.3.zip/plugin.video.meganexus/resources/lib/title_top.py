# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.2: what the top of the Library and the Calendar says of the title under the cursor (the user: "kroz Library
dosta redova u tracking servisima ... ne prikaže logo filma nego samo text ... i nema opisa filmova ... neki imaju
godina · series ili movies a neki nemaju, stavi tu dodatnu točku i ocjenu sa TMDB bar"; "tako provjeri i za kalendar").

* Its details. The services' lists bring a title, a year and a poster - never a logo, and MDBList's, Simkl's and
  Trakt's collection no plot either; MegaNexus' own Library rows keep no year. What TMDB told MegaNexus before is put
  on the cards at once, the rest is asked (one request a title, kept by tmdb_api); what TMDB has not (no TMDB key, an
  anime id it does not know) the metadata add-ons are asked for, as a title page asks them.
* Its words: year · kind · two genres · its rating (TMDB's, else the add-on's IMDb one), each when known - the same
  on every card.
* Its plot: three lines at most - as wide as before when it fits so, else across the screen to the margin the logo
  keeps on the left ("probaj proširiti dužinu prikaza od kraja do kraja ako je potrebno ... iskoristi cijelu širinu
  ekrana"); what even that cannot hold ends with "…" at a word.
"""
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

NARROW, WIDE, LINES = 1100, 1777, 3     # the plot's widths and lines (review/make_library_screen.py hero_band)
FILL = .96                              # of a line counted on: the widths below are rounded, Kodi's are not
# font13's letters (Kodi's media/Fonts/arial.ttf at 30, skin.meganexus Font.xml), U+0020 to U+007E, in pixels
_ASCII = (10, 12, 14, 25, 19, 29, 23, 8, 12, 12, 15, 25, 10, 11, 10, 10, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 10, 10,
          25, 25, 25, 16, 30, 21, 21, 21, 23, 19, 17, 23, 23, 9, 9, 20, 17, 26, 22, 24, 18, 24, 21, 19, 18, 22, 21, 30, 21,
          18, 21, 12, 10, 12, 25, 15, 15, 18, 19, 16, 19, 18, 11, 19, 19, 8, 8, 17, 8, 29, 19, 18, 19, 19, 12, 16, 12, 19,
          18, 25, 18, 18, 16, 19, 10, 19, 25)
LETTER, FULL = 20, 30                   # another script's letter (Cyrillic, Greek ...), a Chinese or Japanese one
ELLIPSIS = '…'
KINDS = {'movie': 'Movie', 'series': 'Series', 'anime': 'Anime'}
DRESS = ('poster', 'fanart', 'clearlogo', 'plot', 'rating')
WORKERS = 6
ADDON_LIFE = 1800                       # s an add-on's details stay kept (as a title page keeps them)
ADDON_AGAIN = 600                       # s before a title no add-on knew is asked again
_MISSED = {}


# ---- the plot ----------------------------------------------------------------------------------------------
def _width(text):
    total = 0
    for char in text:
        code = ord(char)
        if 32 <= code < 127:
            total += _ASCII[code - 32]
            continue
        base = unicodedata.normalize('NFD', char)[:1]       # é as e
        if base and 32 <= ord(base) < 127:
            total += _ASCII[ord(base) - 32]
        else:
            total += FULL if unicodedata.east_asian_width(char) in ('W', 'F') else LETTER
    return total


def _lines(text, room):
    """The lines Kodi's textbox makes of ``text`` ``room`` pixels wide: a word that no longer fits starts the next
    one, a word longer than a whole line is broken."""
    room, space = room * FILL, _width(' ')
    lines, line, used = [], '', 0
    for word in text.split(' '):
        size = _width(word)
        if line and used + space + size <= room:
            line, used = line + ' ' + word, used + space + size
            continue
        if line:
            lines.append(line)
        while size > room:
            cut = ''
            for char in word:
                if cut and _width(cut + char) > room:
                    break
                cut += char
            lines.append(cut)
            word = word[len(cut):]
            size = _width(word)
        line, used = word, size
    if line:
        lines.append(line)
    return lines


def plot(text):
    """(the plot as the top shows it, True when it takes the whole width): one paragraph; three lines as wide as
    before when it fits so, else the whole width; what that cannot hold either ends with "…" at a word."""
    text = ' '.join(str(text or '').split())
    if not text:
        return '', False
    if len(_lines(text, NARROW)) <= LINES:
        return text, False
    lines = _lines(text, WIDE)
    if len(lines) <= LINES:
        return text, True
    last = lines[LINES - 1]
    while last and _width(last + ELLIPSIS) > WIDE * FILL:
        last = last.rsplit(' ', 1)[0] if ' ' in last else last[:-1]     # a word off its end (a letter, without spaces)
    return ' '.join(lines[:LINES - 1] + [last.rstrip(' ,;:-') + ELLIPSIS]), True


# ---- the words ---------------------------------------------------------------------------------------------
def _ratings_on():
    try:
        from .settings_snapshot import cached_addon
        return cached_addon().getSetting('meganexus_show_ratings') != 'false'   # Settings: ratings shown or not
    except Exception:
        return True


def words(year='', kind='', genres='', rating=''):
    """'2024  ·  Movie  ·  Drama, Crime  ·  TMDB 7.8' - what is known of it, in that order."""
    if isinstance(genres, (list, tuple)):
        genres = ', '.join(str(genre) for genre in genres[:2] if genre)
    year = str(year or '')
    found = [year if year != '0' else '', KINDS.get(kind, ''), str(genres or ''), str(rating or '') if _ratings_on() else '']
    return '  ·  '.join(word for word in found if word)


# ---- the details -------------------------------------------------------------------------------------------
def bare(card):
    return not all(card.get(field) for field in DRESS)


def _kind(card):
    kind = (card.get('target') or {}).get('media_type') or 'movie'
    return 'series' if kind in ('series', 'tv', 'show', 'anime') else 'movie'


def _tmdb(card, cached_only):
    """TMDB's details of a card's title: {} when it has none; with ``cached_only``, None when nothing is kept."""
    from . import tmdb_api
    target = card.get('target') or {}
    cid = str(target.get('canonical_id') or '')
    try:
        found = tmdb_api.meta_of(tmdb_id=target.get('tmdb_id') or (cid[5:] if cid.startswith('tmdb:') else ''),
                                 imdb_id=target.get('imdb_id') or (cid if cid.startswith('tt') else ''),
                                 media_type=_kind(card), title=card.get('title') or '', cached_only=cached_only)
    except Exception:
        return {}
    return found if found is not None or cached_only else {}


def _number(value):
    try:
        number = float(str(value).split('/')[0].replace(',', '.'))
    except (TypeError, ValueError):
        return 0.0
    return number if 0 < number <= 10 else 0.0


def _put(card, found):
    """Details on a card - only where it has nothing of its own (an add-on's poster stays)."""
    for field, value in found.items():
        if value and not card.get(field):
            card[field] = value


def _from_tmdb(card, meta):
    rating = _number(meta.get('rating'))
    _put(card, {'poster': meta.get('poster'), 'fanart': meta.get('fanart'), 'clearlogo': meta.get('clearlogo'),
                'plot': meta.get('description'), 'year': meta.get('year'),
                'genres': ', '.join((meta.get('genres') or [])[:2]), 'rating': 'TMDB %.1f' % rating if rating else ''})
    if meta.get('poster') and card.get('poster') == meta.get('poster'):
        card.setdefault('target', {})['ui_seed'] = {'poster': card['poster']}


def _addon_meta(card):
    """The metadata add-ons' details of a card's title, kept as a title page keeps them (the same place: one opened
    after shows at once); {} when none knows it - asked again only after ADDON_AGAIN."""
    from . import backend_api, browse_cache, metadata_providers
    cid, kind = str((card.get('target') or {}).get('canonical_id') or ''), _kind(card)
    if not cid or time.monotonic() < _MISSED.get((kind, cid), 0) or browse_cache.playback_busy():
        return {}
    store = browse_cache.instance()
    key = browse_cache.key('metadata', browse_cache.key(metadata_providers.signature(), ''), kind, cid)
    meta = store.get(key, remember=False)
    if meta is None:
        try:
            meta = backend_api.metadata(kind, cid, title=str(card.get('title') or ''))
        except Exception:
            meta = None
        if not meta:
            if len(_MISSED) > 512:
                _MISSED.clear()
            _MISSED[(kind, cid)] = time.monotonic() + ADDON_AGAIN
            return {}
        store.put(key, meta, ttl=ADDON_LIFE, remember=False)
    return meta if isinstance(meta, dict) else {}


def _from_addon(card, meta):
    rating = _number(meta.get('imdbRating'))
    year = str(meta.get('year') or meta.get('releaseInfo') or '')[:4]
    _put(card, {'poster': meta.get('poster'), 'fanart': meta.get('background'), 'clearlogo': meta.get('logo'),
                'plot': meta.get('description'), 'year': year if year.isdigit() else '',
                'genres': ', '.join(str(g) for g in (meta.get('genres') or [])[:2] if g),
                'rating': 'IMDb %.1f' % rating if rating else ''})


def _asked(card, tmdb, addons):
    if tmdb:
        _from_tmdb(card, _tmdb(card, False))
    if addons and not (card.get('clearlogo') and card.get('plot')):
        _from_addon(card, _addon_meta(card))
    return card


def dress(cards, cached_only=False, addons=False):
    """The cards' logo, background, plot, year, genres and rating: what TMDB told MegaNexus before at once, the rest
    asked (one request a title; one TMDB answered before is not asked again) - and, with ``addons``, the metadata
    add-ons asked for the logo or plot TMDB has not. The cards are changed in place; they are given back."""
    from . import tmdb_api
    wanting = [card for card in cards if bare(card)]
    told = set()
    for card in wanting:
        meta = _tmdb(card, True)
        if meta is not None:
            told.add(id(card))
            _from_tmdb(card, meta)
    if cached_only or (not tmdb_api.api_key() and not addons):
        return cards
    asking = [(card, id(card) not in told) for card in wanting if bare(card)]
    if asking:
        with ThreadPoolExecutor(max_workers=min(WORKERS, len(asking)), thread_name_prefix='MegaNexusTitleTop') as pool:
            list(pool.map(lambda pair: _asked(pair[0], pair[1], addons), asking))
    return cards
