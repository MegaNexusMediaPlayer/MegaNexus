# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""No display mode switch for small preview videos (6.0.35, GitHub issue #4).

With Kodi's "Adjust display refresh rate" on, starting a trailer or a Sports
preview switched the TV's mode. On some CoreELEC builds (Dolby Vision
avdvplus) a video in a small window then stays black - audio only - and the
GUI hangs. While a preview plays the setting is turned off and afterwards put
back. When the setting is already off nothing is touched, so devices that
work today keep working exactly the same way. The original value is also
kept in the add-on settings, so the service restores it after a crash.
"""
import json
import threading
import time

import xbmc

SETTING = 'videoplayer.adjustrefreshrate'
STORE = 'meganexus_refresh_restore'          # original value while suspended
# 9.0.1 (GitHub issue #29): Windows' automatic HDR switch, held with the refresh rate. An SDR
# trailer on an HDR desktop switched the display to SDR and back - black twice. Only where
# Kodi has the setting and it is on; given back with the refresh rate, never switched on.
HDR_SETTING = 'winsystem.ishdrdisplay'
HDR_STORE = 'meganexus_hdr_restore'
PROPERTY = 'meganexus.refresh.suspended'     # Window(Home): previews holding it
# 9.1.0: the user's value kept in Kodi's memory too (Window(Home)) - no settings write can take it away there.
# Another script's old copy of the settings, saved whole, emptied STORE 0.7 s after a trailer paused the
# switch, and the episode after it started with the switch off (a Dolby Vision episode in wrong colours).
KEPT = 'meganexus.refresh.kept'
# 7.0.50: each hold is a lease - {holder: last renewed}. A hold whose process died (a script
# Kodi killed, a crash) is no longer renewed; the service's sweep gives the setting back.
LEASE = 20            # seconds a hold lasts without being renewed
RENEW = 5             # a long hold (IPTV, Sport) renews this often
SETTLE = 5            # 9.0.1: seconds the setting stays off after the last small video let go
CLOSING = 'closing'   # 9.0.1: the hold kept while that video is still being taken down


def _rpc(method, params):
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    except Exception:
        return None              # 9.0.1: Kodi not answering is "nothing done", never a stop on the way
    return reply.get('result') if isinstance(reply, dict) else None


def _log(text):
    xbmc.log('[MegaNexus] ' + text, xbmc.LOGINFO)


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon('plugin.video.meganexus')


def _home():
    import xbmcgui
    return xbmcgui.Window(10000)


def _leases(home):
    """{holder: last renewed}; holds written before 7.0.50 (a list) count as renewed now."""
    raw = home.getProperty(PROPERTY)
    if not raw:
        return {}
    try:
        value = json.loads(raw)
    except ValueError:
        value = ['preview']
    if raw == '1' or not isinstance(value, (list, dict)):
        value = ['preview']                      # a hold written before 7.0.29
    if isinstance(value, list):
        return dict.fromkeys((str(v) for v in value), time.time())
    out = {}
    for holder, stamp in value.items():
        try:
            out[str(holder)] = float(stamp)
        except (TypeError, ValueError):
            out[str(holder)] = time.time()
    return out


def _holders(home):
    return sorted(_leases(home))


def _store(home, holders, leases=None):
    leases = dict(leases if leases is not None else _leases(home))
    now = time.time()
    kept = {h: leases.get(h, now) for h in set(holders)}
    if kept:
        home.setProperty(PROPERTY, json.dumps(kept, sort_keys=True))
    else:
        home.clearProperty(PROPERTY)


def suspend(holder='preview'):
    """Before a small-window video starts. Returns True while the setting is held off.

    7.0.29: every holder is counted (Home previews, trailers, Sport, IPTV); the
    setting comes back only when the last one lets go - a preview ending no longer
    switched it on under a full-screen trailer starting from it.
    """
    _video_layer('keep_last_frame')      # 9.0.2: its stop keeps the frame - no flash (Amlogic)
    home = _home()
    holders = _holders(home)
    if holders:
        leases = _leases(home)
        leases[holder] = time.time()
        _store(home, holders + [holder], leases)
        return True
    addon = _addon()
    if _kept(addon, home) or addon.getSetting(HDR_STORE):
        # 7.0.42: a value kept with no holder left - a hold that was lost. Give the
        # user's setting back first, or it would be read as "off" and stay off.
        restore(force=True)
    _store(home, [holder])           # 7.0.50: the hold first - a sweep never sees a value without it
    hdr = _hdr_pause(addon, holder)
    if _refresh_pause(addon, holder) or hdr:
        return True
    _store(home, [])
    return False


def _kept(addon, home):
    """The user's value while it is held off: the add-on's setting, else Kodi's memory (KEPT)."""
    return addon.getSetting(STORE) or home.getProperty(KEPT)


def _forget(addon, home):
    addon.setSetting(STORE, '')
    home.clearProperty(KEPT)


def _refresh_pause(addon, holder):
    result = _rpc('Settings.GetSettingValue', {'setting': SETTING}) or {}
    value = result.get('value')
    if not value:
        return False  # off (0) or unknown: nothing to do
    addon.setSetting(STORE, str(value))
    _home().setProperty(KEPT, str(value))
    if _rpc('Settings.SetSettingValue', {'setting': SETTING, 'value': 0}) is None:
        _forget(addon, _home())
        return False
    _persist(value)                  # 7.0.50: the file keeps the user's value, not the pause
    _log('Refresh-rate switching paused for %s' % holder)
    return True


def _hdr_pause(addon, holder):
    """9.0.1 (issue #29): the automatic HDR switch off while a small video plays - only
    on Windows, and only when it is on. Kodi 21 on CoreELEC has the same setting ("use the
    display's HDR capabilities"), and switching it there sets the TV up again: every
    trailer flashed the screen twice. A value held before is still given back (restore)."""
    if not xbmc.getCondVisibility('System.Platform.Windows'):
        return False
    result = _rpc('Settings.GetSettingValue', {'setting': HDR_SETTING}) or {}
    if result.get('value') is not True:
        return False
    addon.setSetting(HDR_STORE, 'true')
    if _rpc('Settings.SetSettingValue', {'setting': HDR_SETTING, 'value': False}) is None:
        addon.setSetting(HDR_STORE, '')
        return False
    _log('Automatic HDR switching paused for %s' % holder)
    return True


def _hdr_give_back(addon):
    """True once the HDR switch is the user's again (or was never held)."""
    if not addon.getSetting(HDR_STORE):
        return True
    if _rpc('Settings.SetSettingValue', {'setting': HDR_SETTING, 'value': True}) is None:
        return False                 # Kodi did not answer: the sweep tries again
    addon.setSetting(HDR_STORE, '')
    _log('Automatic HDR switching back')
    return True


def restore(holder='preview', force=False):
    """A holder lets go (cheap when nothing was held). The setting comes back
    when no holder is left. ``force`` releases every hold: service start (a
    crash left one behind) and right before real playback (release_all)."""
    home = _home()
    holders = _holders(home)
    if not force:
        if not holders:
            return False
        holders = [h for h in holders if h != holder]
        if holders:
            _store(home, holders)
            return False
        # 9.0.1: never while that video is still being taken down. Kodi closes a player
        # in two steps and the second one, a moment after the stop, puts the TV back on
        # the menu's mode when the switch is on: given back between the two (as it was,
        # right after Stop was asked), a trailer stopped in the corner made the whole
        # screen go black for a moment. The rule since 6.0.35: the refresh rate changes
        # for a film or an episode in the main player, never for anything else. So the
        # last small video leaves a short hold behind and the service's sweep gives the
        # setting back once it has run out with nothing playing small; a film or an
        # episode takes it back at once, before it opens (release_all).
        if holder != CLOSING:
            _store(home, [CLOSING], {CLOSING: time.time() - LEASE + SETTLE})
            return False
    addon = _addon()
    stored = _kept(addon, home)
    if not stored and not addon.getSetting(HDR_STORE) and not holders and not home.getProperty(PROPERTY):
        return False
    _store(home, [])
    _hdr_give_back(addon)
    if stored:
        try:
            value = int(stored)
        except ValueError:
            _forget(addon, home)
            return False
        # 8.1.3: the user's value is let go only once Kodi has taken it back. It was
        # wiped first, so a Kodi that did not answer (on its way out, with Sport or a
        # trailer still holding the setting) left it off with nothing to give it back -
        # "AFR mi je na start/stop, a u Kodiju piše isključeno". Kept, the service's
        # sweep tries again a few seconds later, or the next start does.
        answer = _rpc('Settings.SetSettingValue', {'setting': SETTING, 'value': value})
        if answer is None:
            _persist(value)
            return False
        _forget(addon, home)                     # taken back - or refused, which no retry changes
        if answer:
            _persist(value)
            _log('Refresh-rate switching back (%s)' % ('all' if force else holder))
        return True
    _forget(addon, home)
    return True


def _persist(value):
    """7.0.50: the user's value into guisettings.xml at once. Kodi wrote the pause (0) to
    the file and saved the value given back only later - a Kodi killed or a power cut in
    between left the setting off for good ("AFR switched itself off")."""
    try:
        from .skin_activation import persist
        persist(SETTING, str(int(value)))
    except Exception:
        pass


def renew(holder):
    """7.0.50: the holder is still there (cheap: Kodi is asked at most every RENEW seconds)."""
    home = _home()
    leases = _leases(home)
    if holder in leases and time.time() - leases[holder] >= RENEW:
        leases[holder] = time.time()
        _store(home, list(leases), leases)


class hold(object):
    """7.0.50: the setting off for as long as a screen is open - IPTV and Sport play
    no film, the TV never switches its mode there (with Kodi's switch a channel
    opening could freeze the picture on the Cube). Renewed in the background; the
    film's own start gives it back at once (release_all)."""

    def __init__(self, holder):
        self.holder = holder
        self.done = threading.Event()

    def __enter__(self):
        try:
            suspend(self.holder)
        except Exception:
            pass
        threading.Thread(target=self._renew, name='MegaNexusRefreshHold', daemon=True).start()
        return self

    def _renew(self):
        while not self.done.wait(RENEW):
            try:
                # 9.0.2: a channel or a stream gone full screen blacks out as Kodi expects
                # when it stops (an HDR / Dolby Vision frame kept would colour the
                # interface); back in the small player its stop keeps the frame again
                if _playing_small():
                    _video_layer('keep_last_frame')
                elif xbmc.Player().isPlayingVideo():
                    _video_layer('give_back')
                if self.holder in _leases(_home()):
                    renew(self.holder)
                elif not xbmc.Player().isPlayingVideo():
                    suspend(self.holder)          # a film in between gave it back: off again, never under a film
            except Exception:
                pass

    def __exit__(self, *exc):
        self.done.set()
        try:
            restore(self.holder)
        except Exception:
            pass
        return False


def sweep(playing_small=None):
    """7.0.50, the service every few seconds: holds that are no longer renewed are gone
    (their process died); with none left the user's setting comes back - it can not stay
    off by accident. A short video still playing in a window keeps an old-style hold."""
    home = _home()
    leases = _leases(home)
    addon = _addon()
    stored = _kept(addon, home) or addon.getSetting(HDR_STORE)
    if not leases and not stored:
        # 9.0.2: no hold at all (the refresh-rate switch off) - the frame kept for the
        # small videos goes back to the box's own value once none plays
        if _video_layer('keeping') and not _playing_small():
            _video_layer('give_back')
        return False
    now = time.time()
    if leases and not home.getProperty(PROPERTY).startswith('{'):
        _store(home, list(leases), leases)        # an old-style hold: its lease starts now, then runs out
    fresh = {h: t for h, t in leases.items() if now - t < LEASE}
    if fresh:
        if len(fresh) != len(leases):
            _store(home, list(fresh), fresh)
        return False
    if playing_small is None:
        playing_small = _playing_small()
    if playing_small and leases:
        return False
    _log('Refresh-rate switching: no hold left (%s) - back to your setting' % (', '.join(sorted(leases)) or 'none'))
    _video_layer('give_back')
    return restore(force=True)


def _playing_small():
    try:
        return xbmc.Player().isPlayingVideo() and not xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)')
    except Exception:
        return False


def _video_layer(name):
    try:
        from . import video_layer
        return getattr(video_layer, name)()
    except Exception:
        return False


def release_all():
    """7.0.29: right BEFORE a film, an episode or a channel starts. Kodi picks the
    TV's refresh rate when playback opens: restored after the start (as before),
    the film ran at the menu's rate - judder - and the setting looked "off".
    9.0.2: and the video layer has the box's own value again, as Kodi expects for a film (a
    Dolby Vision frame kept after it left the interface in its colours)."""
    _video_layer('give_back')
    return restore(force=True)
