# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
import datetime
import json
import os
import time
import urllib.error
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

from .meganexus.paths import profile_path
from .meganexus import progress_db
from . import tmdb_helper_db as _tmdbhelper_art
from .card_art import posters_prefer_local
from . import tmdb_api as _tmdb_api
from .texts import tr

def _the_addon():
    """The add-on's settings, from the snapshot the plugin keeps (Kodi's own when it is not there)."""
    try:
        from .settings_snapshot import cached_addon
        return cached_addon()
    except Exception:
        return xbmcaddon.Addon('plugin.video.meganexus')


ADDON = _the_addon()
API, TOKEN_PATH = 'https://api.trakt.tv', os.path.join(profile_path(), 'trakt_token.json')
DEFAULT_CLIENT_ID = '19abc9f8275ec0d9a8099f6edf809714184222778aa83ac50f997f3b02165001'
DEFAULT_CLIENT_SECRET = '039b60d14d91c7b948479f463e4c4bff7bd09035fc24d51a92e376cf39c47ae1'
_PUBLIC_CACHE = {}


def _setting(key, default=''):
    try:
        return ADDON.getSetting(key) or default
    except Exception:
        return default


def _on(key):
    """A Trakt switch: on unless set to anything but 'true'."""
    return (_setting(key, 'true') or 'true').lower() == 'true'


enabled = lambda: _on('enable_trakt')
scrobble_enabled = lambda: _on('trakt_scrobble')
sync_enabled = lambda: _on('trakt_sync_progress')
client_id = lambda: (_setting('trakt_client_id').strip() or DEFAULT_CLIENT_ID).strip()
client_secret = lambda: (_setting('trakt_client_secret').strip() or DEFAULT_CLIENT_SECRET).strip()
credentials_configured = lambda: bool(client_id() and client_secret())


def ensure_enabled():
    if not enabled():
        try:
            ADDON.setSetting('enable_trakt', 'true')
        except Exception:
            pass


def authorization_status():
    """connected / ready (an app to sign in with) / needs_api."""
    return 'connected' if authorized() else ('ready' if credentials_configured() else 'needs_api')


def _read_json(path, default):
    from .meganexus.json_files import read_json as _safe_read_json
    return _safe_read_json(path, default)


def _write_json(path, value):
    from .meganexus.json_files import write_json as _safe_write_json
    _safe_write_json(path, value)


def token_data():
    return _read_json(TOKEN_PATH, {})


def save_token(data):
    data = dict(data or {})
    data.setdefault('created_at', int(time.time()))
    _write_json(TOKEN_PATH, data)


def clear_token():
    # 6.0.39: the account's watched marks and unsent watches go with it.
    for path in (TOKEN_PATH, os.path.join(os.path.dirname(TOKEN_PATH), 'trakt_watched.json'),
                 os.path.join(os.path.dirname(TOKEN_PATH), 'trakt_outbox.json')):
        try:
            os.remove(path)
        except FileNotFoundError:
            pass


def authorized():
    data = token_data()
    return bool(enabled() and credentials_configured() and data.get('access_token') and not data.get(EXPIRED))


EXPIRED = 'meganexus_expired'      # 7.0.50: Trakt refused to renew this sign-in


def expired():
    """The sign-in Trakt no longer renews (it ran out, or was renewed on another device
    with the same backup): nothing is sent until you sign in again."""
    return bool(token_data().get(EXPIRED))


def _mark_expired(data):
    data = dict(data, **{EXPIRED: int(time.time())})
    _write_json(TOKEN_PATH, data)
    xbmc.log('[MegaNexus] Trakt sign-in expired: Trakt refused to renew it - sign in again', xbmc.LOGWARNING)
    return data   # 9.0.0: told by _ensure_auth (account_notice) - not over a film, and again later


def _headers(auth=False):
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'trakt-api-version': '2',
        'User-Agent': 'MegaNexus/%s (Kodi)' % (ADDON.getAddonInfo('version') or '3.7'),
    }
    cid = client_id()
    if cid:
        headers['trakt-api-key'] = cid
    if auth:
        data = token_data()
        token = data.get('access_token') or ''
        if token:
            headers['Authorization'] = 'Bearer %s' % token
    return headers


RATE_WAIT_MAX = 10      # s a 429 may hold one request before it gives up
_REFRESH_LOCK = __import__('threading').Lock()


def _send(path, payload, method, auth, timeout):
    """One Trakt request: its JSON answer ({} when empty)."""
    body = None if payload is None else json.dumps(payload).encode('utf-8')
    request = urllib.request.Request(API + path, data=body, headers=_headers(auth=auth), method=method)
    with urllib.request.urlopen(request, timeout=timeout) as reply:
        text = reply.read().decode('utf-8', 'ignore')
    return json.loads(text) if text else {}


def _retry_after(exc):
    try:
        return max(1.0, float((exc.headers or {}).get('Retry-After') or 1))
    except (TypeError, ValueError, AttributeError):
        return 1.0


def _request(path, payload=None, method='GET', auth=False, timeout=20):
    """One Trakt call (6.0.39): a 401 refreshes the sign-in once and retries;
    a 429 waits as long as Trakt asks (up to RATE_WAIT_MAX) and retries once."""
    try:
        return _send(path, payload, method, auth, timeout)
    except urllib.error.HTTPError as exc:
        if exc.code == 401 and auth and token_data().get('refresh_token'):
            renewed = _refresh_token_if_needed(force=True)
            if isinstance(renewed, dict) and renewed.get(EXPIRED):
                raise                          # 7.0.50: no retry - Trakt no longer renews it
        elif exc.code == 429 and _retry_after(exc) <= RATE_WAIT_MAX:
            time.sleep(_retry_after(exc))
        else:
            raise
    return _send(path, payload, method, auth, timeout)


PAGE = 250          # 9.0.1: the most Trakt gives in one page
PAGES_MOST = 200    # pages read at most from one list (50,000 rows)


def pages(path, timeout=20):
    """9.0.1: every page of a Trakt list. Since 2026 Trakt pages its lists (100 rows unless a
    limit is asked, at most 250): only the first page was ever read - one user's 780 watched
    films were 100 here, and 187 shows 100. A list Trakt does not page comes back whole."""
    rows, previous = [], None
    for page in range(1, PAGES_MOST + 1):
        part = _request('%s%slimit=%d&page=%d' % (path, '&' if '?' in path else '?', PAGE, page),
                        method='GET', auth=True, timeout=timeout)
        if not isinstance(part, list):
            return part if page == 1 else rows
        if part == previous:
            break                                  # the same rows again: a list without pages
        rows.extend(part)
        if len(part) < PAGE:
            break
        previous = part
    return rows


def _refresh_token_if_needed(force=False):
    with _REFRESH_LOCK, _refresh_turn():   # one refresh at a time: Trakt revokes a used refresh token
        return _refresh_locked(force)


TURN_WAIT = 30.0      # 9.0.0: s a refresh waits for another Python's refresh to finish
TURN_STALE = 60.0     # s after which a turn left behind by a Python that died no longer counts


class _refresh_turn(object):
    """9.0.0: one refresh at a time across all of Kodi's Pythons - the service and every screen
    have their own _REFRESH_LOCK. Trakt's refresh tokens are single-use since 2026: the second
    of two refreshes at once sent the token the first had already replaced, was refused, and
    the fresh sign-in the first had written was then written over as expired - signed out
    every few days ("trakt sad podržava samo 1 uređaj"). A file only one Python can create."""
    def __enter__(self):
        self.path, self.held = TOKEN_PATH + '.turn', False
        until = time.time() + TURN_WAIT
        while True:
            try:
                os.close(os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
                self.held = True
                return self
            except FileExistsError:
                try:
                    if time.time() - os.path.getmtime(self.path) > TURN_STALE:
                        os.remove(self.path)
                        continue
                except OSError:
                    pass
            except OSError:
                return self                 # no file to hold: as before, this Python's lock only
            if time.time() > until:
                return self
            time.sleep(.1)

    def __exit__(self, *exc):
        if self.held:
            try:
                os.remove(self.path)
            except OSError:
                pass
        return False


def _refresh_locked(force=False):
    """The kept sign-in, renewed when it ends within 5 minutes (or `force`). A refusal
    (400/401/403) marks it expired and it is not asked again until the user signs in;
    a network failure keeps the old one."""
    kept = token_data()
    if not kept.get('refresh_token') or kept.get(EXPIRED):
        return kept
    ends = int(kept.get('created_at') or 0) + int(kept.get('expires_in') or 0)
    if not force and kept.get('access_token') and kept.get('expires_in') and ends - 300 > int(time.time()):
        return kept
    try:
        renewed = _send('/oauth/token', {'refresh_token': kept.get('refresh_token'), 'client_id': client_id(),
                                         'client_secret': client_secret(), 'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob',
                                         'grant_type': 'refresh_token'}, 'POST', False, 20)
    except urllib.error.HTTPError as exc:
        if exc.code in (400, 401, 403):
            now = token_data()
            if now.get('access_token') and not now.get(EXPIRED) and now.get('refresh_token') != kept.get('refresh_token'):
                return now                   # 9.0.0: renewed meanwhile - that one stands
            return _mark_expired(kept)
        renewed = None
    except Exception:
        renewed = None
    if not (isinstance(renewed, dict) and renewed.get('access_token')):
        return kept
    renewed['created_at'] = int(time.time())
    save_token(renewed)
    return renewed


def _ensure_auth():
    was_on = enabled()   # 9.0.0: a Trakt that was off is not told about (ensure_enabled turns it on)
    ensure_enabled()
    if not credentials_configured():
        raise RuntimeError('Trakt credentials are not bundled in this build')
    kept = _refresh_token_if_needed(force=False)
    if kept.get(EXPIRED):
        if was_on:
            from .account_notice import signed_out
            signed_out('Trakt', str(kept.get(EXPIRED)))
        raise RuntimeError('Trakt sign-in expired - sign in again')
    if not kept.get('access_token'):
        raise RuntimeError('Trakt is not linked yet')
    return kept


def _pin_prompt_text(verify_url, user_code, remaining=None):
    lines = [
        '[B]1) Open this link:[/B]',
        '[COLOR orange]%s[/COLOR]' % verify_url,
        '',
        '[B]2) Enter this code:[/B]',
        '[COLOR yellow][B]   %s   [/B][/COLOR]' % user_code,
    ]
    if remaining is not None:
        lines.append('')
        lines.append(tr('Remaining: %ss') % int(remaining))
    return '\n'.join(lines)


# a device-token answer that ends the linking: status -> what the user is told
_LINK_ENDS = {404: 'Invalid Trakt link code, please try again',
              409: 'This Trakt code was already used. Start a new link flow',
              410: 'The Trakt code expired. Please try again',
              418: 'The Trakt link was denied on the activation page'}


def _device_code():
    try:
        return _request('/oauth/device/code', payload={'client_id': client_id()}, method='POST', auth=False) or {}
    except urllib.error.HTTPError as exc:
        raise RuntimeError(tr('Trakt device-code request failed (%s): %s') % (exc.code, _body(exc)[:200]))
    except Exception as exc:
        raise RuntimeError(tr('Trakt connection failed: %s') % exc)


def _body(exc):
    try:
        return exc.read().decode('utf-8', 'ignore')
    except Exception:
        return ''


def device_auth():
    """Link Trakt with its device code (trakt.tv/activate): the code is shown, then Trakt is
    asked every few seconds until the user activated it. True once linked, False when
    cancelled or expired; a refused or used code is an error."""
    ensure_enabled()
    if not credentials_configured():
        raise RuntimeError('Trakt credentials are not bundled in this build')
    start = _device_code()
    code, device = (start.get('user_code') or '').strip(), (start.get('device_code') or '').strip()
    if not code or not device:
        raise RuntimeError('Trakt did not return a valid device code')
    address = start.get('verification_url') or 'https://trakt.tv/activate'
    every, lasts = max(5, int(start.get('interval') or 5)), max(60, int(start.get('expires_in') or 600))
    title = tr('MegaNexus • Trakt link')
    try:
        xbmcgui.Dialog().ok(title, tr(_pin_prompt_text(address, code)))
    except Exception as exc:
        xbmc.log('[MegaNexus] Dialog.ok fallback: %s' % exc, xbmc.LOGWARNING)
    xbmc.executebuiltin('Notification(MegaNexus,Trakt code: %s,10000)' % code)
    waiting = xbmcgui.DialogProgress()
    waiting.create(title, tr(_pin_prompt_text(address, code, remaining=lasts)))
    began = time.time()
    try:
        while not waiting.iscanceled() and time.time() - began < lasts:
            spent = time.time() - began
            waiting.update(int(max(0, min(100, spent / float(lasts) * 100))),
                           tr(_pin_prompt_text(address, code, remaining=int(lasts - spent))))
            try:
                answer = _send('/oauth/device/token', {'code': device, 'client_id': client_id(),
                                                       'client_secret': client_secret()}, 'POST', False, 20)
                if isinstance(answer, dict) and answer.get('access_token'):
                    answer['created_at'] = int(time.time())
                    save_token(answer)
                    waiting.close()
                    xbmcgui.Dialog().notification('MegaNexus', tr('Trakt linked successfully'), xbmcgui.NOTIFICATION_INFO, 3000)
                    return True
            except urllib.error.HTTPError as exc:
                detail = _body(exc)
                if exc.code == 429:                          # asked too often
                    every = max(every, 5) * 2
                elif exc.code != 400:                        # 400: not activated yet
                    waiting.close()
                    raise RuntimeError(_LINK_ENDS.get(exc.code) or tr('Trakt link failed: %s %s') % (exc.code, detail[:200]))
            except Exception as exc:
                xbmc.log('[MegaNexus] trakt poll transient error: %s' % exc, xbmc.LOGWARNING)
            xbmc.sleep(every * 1000)
    finally:
        try:
            waiting.close()
        except Exception:
            pass
    return False


def logout():
    """Revoke the token at Trakt (when possible) and forget it."""
    token = token_data().get('access_token')
    if token and client_id() and client_secret():
        try:
            _request('/oauth/revoke', payload={'token': token, 'client_id': client_id(), 'client_secret': client_secret()},
                     method='POST', auth=False)
        except Exception:
            pass
    clear_token()
    xbmcgui.Dialog().notification('MegaNexus', tr('Signed out from Trakt'), xbmcgui.NOTIFICATION_INFO, 2500)


def _number(value):
    try:
        return int(float(value))
    except Exception:
        return None


def _ids_payload(ctx):
    """{imdb, tmdb, tvdb} as Trakt wants them (IMDb with tt, the others as numbers)."""
    imdb = str(ctx.get('imdb_id') or '').strip()
    ids = {'imdb': imdb if imdb.startswith('tt') else 'tt' + imdb} if imdb else {}
    for name in ('tmdb', 'tvdb'):
        value = str(ctx.get(name + '_id') or '').strip()
        number = _number(value) if value else None
        if number is not None:
            ids[name] = number
    return ids


def _progress(ctx, position_ms):
    """Percent played (0-100); 0 without a duration."""
    duration = float(ctx.get('duration_ms') or 0)
    return max(0.0, min(100.0, float(position_ms or 0) / duration * 100.0)) if duration > 0 else 0.0


def _titled(title, ctx):
    """{title, [year], ids} - the year left out when unknown."""
    year = int(ctx.get('year') or 0) or None
    return dict({'title': title, 'ids': _ids_payload(ctx)}, **({'year': year} if year else {}))


def _scrobble_payload(ctx, position_ms):
    """Trakt's scrobble body: the film, or the show and the episode."""
    body = {'progress': round(_progress(ctx, position_ms), 2), 'app_version': ADDON.getAddonInfo('version') or '8.1.0',
            'app_date': datetime.date.today().isoformat()}
    episode = str(ctx.get('media_type') or 'movie').lower() in ('series', 'show', 'tv', 'anime') \
        or ctx.get('season') or ctx.get('episode')
    if episode:
        body['show'] = _titled(ctx.get('show_title') or ctx.get('title') or '', ctx)
        body['episode'] = {'season': int(ctx.get('season') or 0), 'number': int(ctx.get('episode') or 0)}
    else:
        body['movie'] = _titled(ctx.get('title') or '', ctx)
    return body


LEAST_SHARE = 1.0   # 9.0.7: % - Trakt answers a stop or pause below 1 % with 422 and keeps nothing


def scrobble(action, ctx, position_ms=0):
    """Tell Trakt start / pause / stop - never raises into the player. A stop or pause below
    LEAST_SHARE is not sent; a stop that cannot reach Trakt (offline, 5xx, 429) waits in the
    outbox; 409 means Trakt has it already.

    9.0.7: "trakt scrobble failed: HTTP Error 422: Unprocessable Entity" on a film paused at its
    start - the cut was 0.5 %, and Trakt's own contract (trakt/api-help, scrobble /stop: "If the
    progress is less than 1%, you'll get a 422 HTTP status code response and the scrobble will be
    ignored") refuses everything under 1 %: 50 s into a 100-minute film is 0.8 %. Nothing is lost
    by not sending it - Trakt would have kept nothing."""
    if not (enabled() and scrobble_enabled()):
        return None
    try:
        if not _ensure_auth().get('access_token'):
            return None
    except Exception as exc:
        xbmc.log('[MegaNexus] trakt scrobble skipped (not auth): %s' % exc, xbmc.LOGDEBUG)
        # 9.0.1: a film or episode finished while Trakt is signed out waits for the next sign-in
        # (flush_outbox sends it with the time it was watched) - it was lost
        try:
            if str(action or '').lower() == 'stop' and token_data().get('refresh_token') \
                    and _progress(ctx or {}, position_ms) >= FINISHED:
                body = _scrobble_payload(ctx or {}, position_ms)
                if (body.get('movie') or body.get('show') or {}).get('ids'):
                    _queue_scrobble(body)
        except Exception:
            pass
        return None
    ctx = ctx or {}
    action = str(action or '')
    try:
        if action.lower() in ('stop', 'pause') and _progress(ctx, position_ms) < LEAST_SHARE:
            return None
        body = _scrobble_payload(ctx, position_ms)
        if not (body.get('movie') or body.get('show') or {}).get('ids'):
            return None
        try:
            return _request('/scrobble/%s' % action, payload=body, method='POST', auth=True)
        except urllib.error.HTTPError as exc:
            if exc.code == 409:
                return None
            if (exc.code >= 500 or exc.code == 429) and action.lower() == 'stop':
                _queue_scrobble(body)
            raise
        except (urllib.error.URLError, OSError):
            if action.lower() == 'stop':
                _queue_scrobble(body)
            raise
    except Exception as exc:
        xbmc.log('[MegaNexus] trakt scrobble failed: %s' % exc, xbmc.LOGWARNING)
        return None


FINISHED = 80.0     # 9.0.1: Trakt's own mark for a finished scrobble
OUTBOX_PATH = os.path.join(profile_path(), 'trakt_outbox.json')
OUTBOX_MAX = 50
_OUTBOX_LOCK = __import__('threading').Lock()


def _queue_scrobble(payload):
    """A finished watch that could not reach Trakt (offline, Trakt down)."""
    with _OUTBOX_LOCK:
        rows = _read_json(OUTBOX_PATH, [])
        rows = (rows if isinstance(rows, list) else [])[-(OUTBOX_MAX - 1):]
        rows.append({'at': int(time.time()), 'payload': payload})
        _write_json(OUTBOX_PATH, rows)


def flush_outbox(limit=5):
    """Send queued finished watches as history (with their real watch time).

    /sync/history instead of a late /scrobble/stop: Trakt would otherwise log
    them at the moment of sending."""
    if not authorized():
        return 0
    with _OUTBOX_LOCK:
        rows = _read_json(OUTBOX_PATH, [])
        if not isinstance(rows, list) or not rows:
            return 0
        sent = 0
        for row in list(rows[:limit]):
            payload = row.get('payload') or {}
            when = datetime.datetime.utcfromtimestamp(int(row.get('at') or time.time())).strftime('%Y-%m-%dT%H:%M:%S.000Z')
            if payload.get('movie'):
                body = {'movies': [dict(payload['movie'], watched_at=when)]}
            elif payload.get('show') and payload.get('episode'):
                body = {'shows': [dict(payload['show'], seasons=[{'number': payload['episode']['season'],
                        'episodes': [{'number': payload['episode']['number'], 'watched_at': when}]}])]}
            else:
                body = None
            if body:
                try:
                    _request('/sync/history', payload=body, method='POST', auth=True, timeout=10)
                except urllib.error.HTTPError as exc:
                    if exc.code >= 500 or exc.code in (401, 429):
                        break   # keep it for the next round
                except Exception:
                    break
            rows.remove(row)
            sent += 1
        _write_json(OUTBOX_PATH, rows)
        return sent


def _canonical_from_ids(ids, fallback_title=''):
    """Our item id from Trakt's ids: tmdb:…, else the IMDb id, tvdb:…, trakt:…, else the title."""
    ids = ids or {}
    for name, form in (('tmdb', 'tmdb:%s'), ('imdb', '%s'), ('tvdb', 'tvdb:%s'), ('trakt', 'trakt:%s')):
        if ids.get(name):
            return form % ids[name]
    return fallback_title or ''


def _fetch_art_setting():
    return (_setting('trakt_fetch_art', 'true') or 'true').lower() not in ('false', '0', 'no')


NO_ART = {'poster': '', 'fanart': '', 'clearlogo': ''}


def _art_bundle_for_ids(ids, media_type, title='', force_remote=False):
    """{poster, fanart, clearlogo}: TMDb Helper's local pictures, TMDB for what they lack. With
    "local posters" the poster stays empty (the card draws its own) unless `force_remote`."""
    if not _fetch_art_setting():
        return dict(NO_ART)
    ids = ids or {}
    asked = dict(tmdb_id=str(ids.get('tmdb') or '').strip(), imdb_id=str(ids.get('imdb') or '').strip(),
                 media_type='tv' if media_type == 'series' else 'movie', title=title or '')
    local_poster = posters_prefer_local() and not force_remote
    try:
        kept = _tmdbhelper_art.stored_pictures(**asked) or {}
    except Exception:
        kept = {}
    remote = {}
    if not (kept.get('fanart') and kept.get('clearlogo') and (local_poster or kept.get('poster'))):
        try:
            remote = _tmdb_api.art_for(**asked) or {}
        except Exception:
            remote = {}
    return {'poster': '' if local_poster else kept.get('poster') or remote.get('poster') or '',
            'fanart': kept.get('fanart') or kept.get('landscape') or remote.get('fanart') or remote.get('landscape') or '',
            'clearlogo': kept.get('clearlogo') or remote.get('clearlogo') or ''}


def invalidate_cache(prefix=''):
    for key in [key for key in list(_PUBLIC_CACHE) if str(key).startswith(str(prefix))]:
        _PUBLIC_CACHE.pop(key, None)


def _ids_of(ids):
    return dict(('%s_id' % name, str(ids.get(name) or '')) for name in ('tmdb', 'imdb', 'tvdb'))


def _paused_row(row, kind):
    """One paused playback as a local progress row."""
    episode = row.get('episode') or {} if kind == 'series' else {}
    title_node = row.get('show' if kind == 'series' else 'movie') or {}
    ids, title = title_node.get('ids') or {}, title_node.get('title') or 'Unknown'
    minutes = float((episode.get('runtime') if kind == 'series' else None) or title_node.get('runtime') or 0)
    duration = minutes * 60.0 if minutes > 0 else 0.0
    # 9.0.1: Trakt keeps only a share; its runtime is whole minutes and seldom the file's own -
    # the length MegaNexus measured, when it has one, puts the resume on the right second
    try:
        from .meganexus import progress_db
        measured = progress_db.known_duration(ids, episode.get('season') if kind == 'series' else None,
                                              episode.get('number') if kind == 'series' else None)
        if measured:
            duration = measured
    except Exception:
        pass
    percent = float(row.get('progress') or 0.0)
    item = _canonical_from_ids(ids, title)
    art = _art_bundle_for_ids(ids, kind, title=title)
    found = dict({'media_type': kind, 'canonical_id': item, 'video_id': item, 'title': title, 'provider_name': 'Trakt',
                  'poster': art['poster'], 'background': art['fanart'], 'clearlogo': art['clearlogo'],
                  'season': None, 'episode': None, 'position': duration * percent / 100.0 if duration > 0 else 0.0,
                  'duration': duration, 'percent': percent, 'stream_url': '', 'event_type': 'progress',
                  'ext_updated_at': _parse_trakt_ts(row.get('paused_at') or row.get('last_watched_at'))}, **_ids_of(ids))
    if kind == 'series':
        season, number = int(episode.get('season') or 0), int(episode.get('number') or 0)
        found.update(video_id='%s:%s:%s' % (item, season, number), season=season, episode=number,
                     show_tmdb_id=str(ids.get('tmdb') or ''))
    return found


def take_progress(limit=100):
    """Trakt's paused films and episodes into the local progress store; how many were taken."""
    if not (enabled() and sync_enabled()):
        raise RuntimeError('Enable Trakt sync from settings')
    _ensure_auth()
    rows = []
    for path, kind in (('/sync/playback/movies?extended=full', 'movie'), ('/sync/playback/episodes?extended=full', 'series')):
        try:
            answer = _request(path, method='GET', auth=True) or []
        except Exception:
            answer = []
        for row in answer[:limit]:
            try:
                rows.append(_paused_row(row, kind))
            except Exception:
                continue
    return int(progress_db.keep_rows(rows, mark_dirty=False) or 0) if rows else 0


def _parse_trakt_ts(value):
    """Epoch seconds of a Trakt time ('…Z'); None when unreadable."""
    if not value:
        return None
    text = str(value).strip()
    try:
        return int(datetime.datetime.fromisoformat(text[:-1] + '+00:00' if text.endswith('Z') else text).timestamp())
    except Exception:
        try:
            return int(time.mktime(time.strptime(text[:19], '%Y-%m-%dT%H:%M:%S')))
        except Exception:
            return None


def _signed_in():
    if not enabled():
        return False
    try:
        _ensure_auth()
        return True
    except Exception:
        return False


def _art_if_wanted(ids, kind, title, force_remote=False):
    return _art_bundle_for_ids(ids, kind, title=title, force_remote=force_remote) \
        if _setting('trakt_fetch_art', 'true') == 'true' else dict(NO_ART)


def fetch_watchlist(limit=100):
    """The watchlist (films and shows) as Library rows; IMDb ids first (6.0.35: as Simkl and
    the add-ons do - the same title then makes one card, with its poster). 9.0.7: every page
    (pages()) up to ``limit`` of each - Trakt pages the watchlist too, and only its first
    page ever came ("it doesn't show the whole watchlist"), as the watched lists before 9.0.1."""
    if not _signed_in():
        return []
    rows = []
    for path, kind in (('/users/me/watchlist/movies', 'movie'), ('/users/me/watchlist/shows', 'series')):
        try:
            answer = pages(path)
        except Exception:
            answer = []
        if not isinstance(answer, list):
            answer = []
        for row in answer[:limit]:
            try:
                node = row.get('movie' if kind == 'movie' else 'show')
                if not node:
                    continue
                ids, title = node.get('ids') or {}, node.get('title') or ''
                imdb = str(ids.get('imdb') or '').strip()
                art = _art_if_wanted(ids, kind, title)
                rows.append({'media_type': kind, 'title': title, 'year': int(node.get('year') or 0),
                             'canonical_id': (imdb if imdb.startswith('tt') else 'tt' + imdb) if imdb
                             else _canonical_from_ids(ids, title),
                             'plot': node.get('overview') or '', 'poster': art.get('poster') or '',
                             'background': art.get('fanart') or '', 'clearlogo': art.get('clearlogo') or '',
                             'added_at': _parse_trakt_ts(row.get('listed_at')) or int(time.time())})
            except Exception:
                continue
    return rows


NEXT_UP_KEY = 'next_up_v1'
NEXT_UP_LIFE = 600


def next_up_rows(limit=40):
    """The next episode of each recently watched show (Trakt's watched progress); 10 minutes kept."""
    kept = _PUBLIC_CACHE.get(NEXT_UP_KEY)
    if kept and kept[0] > time.time():
        return kept[1]
    if not _signed_in():
        return []
    try:
        shows = pages('/sync/watched/shows') or []
    except Exception:
        shows = []
    rows = []
    for row in sorted(shows, key=lambda row: _parse_trakt_ts(row.get('last_watched_at') or '') or 0, reverse=True)[:limit]:
        try:
            show = row.get('show') or {}
            ids = show.get('ids') or {}
            name = ids.get('slug') or ids.get('trakt')
            if not name:
                continue
            try:
                following = (_request('/shows/%s/progress/watched?hidden=false&specials=false' % name, method='GET',
                                      auth=True) or {}).get('next_episode') or {}
            except Exception:
                continue
            if not following:
                continue
            title = show.get('title') or 'Unknown'
            item = _canonical_from_ids(ids, title)
            season, number = int(following.get('season') or 0), int(following.get('number') or 0)
            art = _art_if_wanted(ids, 'series', title, force_remote=True)
            rows.append({'media_type': 'series', 'canonical_id': item, 'video_id': '%s:%s:%s' % (item, season, number),
                         'title': title, 'episode_title': following.get('title') or '', 'season': season,
                         'episode': number, 'plot': following.get('overview') or show.get('overview') or '',
                         'poster': art.get('poster') or '', 'background': art.get('fanart') or '',
                         'clearlogo': art.get('clearlogo') or '',
                         'last_watched_at': _parse_trakt_ts(row.get('last_watched_at')) or int(time.time())})
        except Exception:
            continue
    _PUBLIC_CACHE[NEXT_UP_KEY] = (time.time() + NEXT_UP_LIFE, rows)
    return rows


# 9.1.1: the Library's Trakt sections (library_sections) - the user's own lists, Trakt's recommendations and
# what was watched last, each with Trakt's own pictures (extended=images, as trakt_lists reads a list)
OWN_LISTS = 10            # the user's lists read at most
LIST_TITLES = 50          # titles read of one list
PICKS = 30                # recommendations of films, and of shows


def _titles(rows):
    """[(media_type, node, epoch)] of Trakt rows holding a film or a show (an episode's row: its show), each
    title once, in the rows' order; the epoch: when it was listed or watched (0 unknown)."""
    out, seen = [], set()
    for row in rows if isinstance(rows, list) else []:
        node = (row.get('movie') or row.get('show')) if isinstance(row, dict) else None
        if not isinstance(node, dict):
            continue
        media = 'movie' if row.get('movie') else 'series'
        key = (media, str((node.get('ids') or {}).get('trakt') or node.get('title') or ''))
        if key not in seen:
            seen.add(key)
            out.append((media, node, _parse_trakt_ts(row.get('listed_at') or row.get('watched_at')) or 0))
    return out


def own_lists(most=OWN_LISTS):
    """[{'id', 'name'}] of the signed-in user's own lists (/users/me/lists), at most ``most``; [] signed out."""
    if not _signed_in():
        return []
    answer = _request('/users/me/lists', method='GET', auth=True)
    found = [{'id': str(row['ids']['trakt']), 'name': str(row.get('name') or '')}
             for row in (answer if isinstance(answer, list) else [])
             if isinstance(row, dict) and isinstance(row.get('ids'), dict) and row['ids'].get('trakt')]
    return found[:most]


def list_titles(list_id, most=LIST_TITLES):
    """The first ``most`` films and shows of one of the user's lists, in its own order (_titles)."""
    return _titles(_request('/users/me/lists/%s/items/movie,show?extended=full,images&limit=%d&page=1'
                            % (int(list_id), most), method='GET', auth=True))


def recommendations(most=PICKS):
    """Trakt's recommendations for the user, films then shows (what is in the collection left out)."""
    found = []
    for kind, media in (('movies', 'movie'), ('shows', 'series')):
        answer = _request('/recommendations/%s?extended=full,images&ignore_collected=true&limit=%d' % (kind, most),
                          method='GET', auth=True)
        found += [(media, node, 0) for node in (answer if isinstance(answer, list) else []) if isinstance(node, dict)]
    return found


def recently_watched(most=60):
    """What was watched last - each film or show once, the newest first (one page of the history)."""
    return _titles(_request('/sync/history?extended=full,images&limit=%d&page=1' % (most * 3), method='GET', auth=True))[:most]


def collection(most=60):
    """9.1.1: the user's collection - the latest collected first, films and shows together (every page: Trakt pages
    its sync lists, 100 rows unless asked - only the first was read)."""
    found = []
    for kind, media in (('movies', 'movie'), ('shows', 'series')):
        answer = pages('/sync/collection/%s?extended=full,images' % kind)
        for row in answer if isinstance(answer, list) else []:
            node = row.get('movie') or row.get('show') if isinstance(row, dict) else None
            if isinstance(node, dict):
                found.append((media, node, _parse_trakt_ts(row.get('last_collected_at') or row.get('collected_at')) or 0))
    return sorted(found, key=lambda item: -item[2])[:most]


def public_titles(name, most=40):
    """9.1.1: one of Trakt's own lists of everyone's - 'popular' or 'anticipated' - films then shows (public: no
    sign-in), in its own order."""
    found = []
    for kind, media in (('movies', 'movie'), ('shows', 'series')):
        answer = _request('/%s/%s?extended=full,images&limit=%d' % (kind, name, most // 2), method='GET', auth=False)
        for row in answer if isinstance(answer, list) else []:
            node = (row.get('movie') or row.get('show') or (row if 'ids' in row else None)) if isinstance(row, dict) else None
            if isinstance(node, dict):
                found.append((media, node, 0))
    return found


# 9.0.8: Trakt's lists of shows taken out of Up Next on Trakt itself ("Hide from progress", "Drop show")
HIDDEN_SECTIONS = ('progress_watched', 'dropped')
UP_NEXT_TIMEOUT = 8      # s one show's progress may take (asked behind Home: a closing script waits for it)


def _hidden_shows():
    """The Trakt ids of the shows hidden from progress or dropped on Trakt; a list that does not
    answer hides nothing."""
    found = set()
    for section in HIDDEN_SECTIONS:
        try:
            answer = pages('/users/hidden/%s?type=show' % section, timeout=UP_NEXT_TIMEOUT)
        except Exception:
            continue
        for row in answer if isinstance(answer, list) else []:
            ids = ((row or {}).get('show') or {}).get('ids') or {}
            if ids.get('trakt'):
                found.add(str(ids['trakt']))
    return found


def up_next(limit=30, stopped=None):
    """9.0.8: Home's Next episodes row from Trakt - Trakt's Up Next: the next episode of each show
    watched last (``limit`` shows, newest first; Trakt counts only aired episodes, so it is always
    one that is out), the shows hidden from progress or dropped on Trakt left out. One request per
    show, so it is asked behind Home only, and ``stopped`` is checked before each one.

    (rows, missed) - ``missed``: the ids of the shows whose own question failed, so the caller keeps
    what it knew of them (a failed question is not "nothing next"). None when Trakt gave no answer at
    all (not signed in, the watched list failed, stopped): never an empty list in its place. Not kept
    here (next_up_rows, the Next Up list, keeps its own)."""
    if not _signed_in():
        return None
    try:
        shows = pages('/sync/watched/shows', timeout=UP_NEXT_TIMEOUT)
    except Exception:
        return None
    if not isinstance(shows, list):
        return None
    hidden = _hidden_shows()
    rows, missed = [], []
    newest = sorted(shows, key=lambda row: _parse_trakt_ts((row or {}).get('last_watched_at') or '') or 0, reverse=True)
    for row in newest[:max(1, int(limit))]:
        if stopped and stopped():
            return None
        try:
            show = row.get('show') or {}
            ids = show.get('ids') or {}
            name = ids.get('slug') or ids.get('trakt')
            if not name or str(ids.get('trakt') or '') in hidden:
                continue
            title = show.get('title') or 'Unknown'
            item = _canonical_from_ids(ids, title)
            try:
                answer = _request('/shows/%s/progress/watched?hidden=false&specials=false' % name, method='GET',
                                  auth=True, timeout=UP_NEXT_TIMEOUT) or {}
            except Exception:
                missed.append(item)
                continue
            following = (answer.get('next_episode') if isinstance(answer, dict) else None) or {}
            season, number = int(following.get('season') or 0), int(following.get('number') or 0)
            if season <= 0 or number <= 0:
                continue
            art = _art_if_wanted(ids, 'series', title, force_remote=True)
            rows.append(dict({'media_type': 'series', 'canonical_id': item, 'video_id': '%s:%s:%s' % (item, season, number),
                              'title': title, 'year': int(show.get('year') or 0), 'episode_title': following.get('title') or '',
                              'season': season, 'episode': number, 'plot': following.get('overview') or '',
                              'poster': art.get('poster') or '', 'background': art.get('fanart') or '',
                              'clearlogo': art.get('clearlogo') or '',
                              'last_watched_at': _parse_trakt_ts(row.get('last_watched_at')) or 0}, **_ids_of(ids)))
        except Exception:
            continue
    return rows, missed


_PROGRESS_LOOKUP_CACHE = {}
_PROGRESS_LOOKUP_TTL = 90
SERIES_KINDS = ('series', 'show', 'tv', 'episode', 'anime')


def _same_title(ids, tmdb_id, imdb, tvdb_id):
    return bool((tmdb_id and str(ids.get('tmdb') or '') == str(tmdb_id))
                or (imdb and str(ids.get('imdb') or '').lower() == imdb)
                or (tvdb_id and str(ids.get('tvdb') or '') == str(tvdb_id)))


def progress_of(media_type='movie', tmdb_id='', imdb_id='', tvdb_id='', season=None, episode=None):
    """{resume_seconds, resume_percent, duration, updated_at, source} of the title's newest
    paused playback on Trakt (1-95 % played); {} when none. Kept 90 seconds."""
    if not (enabled() and sync_enabled() and authorized()):
        return {}
    unset = (None, '', 0, '0')
    episode_wanted = str(media_type or 'movie').lower() in SERIES_KINDS or (season not in unset and episode not in unset)
    try:
        wanted = (int(season or 0), int(episode or 0))
    except Exception:
        wanted = (0, 0)
    imdb = str(imdb_id or '').lower().replace('imdb:', '').strip()
    imdb = 'tt' + imdb if imdb.isdigit() else imdb
    key = ('ep' if episode_wanted else 'movie', str(tmdb_id or ''), imdb, str(tvdb_id or '')) + wanted
    kept = _PROGRESS_LOOKUP_CACHE.get(key)
    if kept and time.time() - kept[0] <= _PROGRESS_LOOKUP_TTL:
        return dict(kept[1])
    try:
        rows = _request('/sync/playback/%s?extended=full' % ('episodes' if episode_wanted else 'movies'),
                        method='GET', auth=True, timeout=12) or []
    except Exception as exc:
        xbmc.log('[MegaNexus] trakt direct progress lookup failed: %s' % exc, xbmc.LOGWARNING)
        return {}
    best = {}
    for row in rows:
        try:
            title = row.get('show' if episode_wanted else 'movie') or {}
            if not _same_title(title.get('ids') or {}, tmdb_id, imdb, tvdb_id):
                continue
            part = row.get('episode') or {}
            if episode_wanted and (int(part.get('season') or 0), int(part.get('number') or 0)) != wanted:
                continue
            percent = float(row.get('progress') or 0.0)
            if not 1.0 < percent < 95.0:
                continue
            minutes = float((part.get('runtime') if episode_wanted else title.get('runtime')) or title.get('runtime') or 0.0)
            duration = minutes * 60.0 if minutes > 0 else 0.0
            when = _parse_trakt_ts(row.get('paused_at') or row.get('last_watched_at')) or 0
            if not best or when > int(best.get('updated_at') or 0):
                best = {'resume_seconds': duration * percent / 100.0 if duration > 0 else 0.0, 'resume_percent': percent,
                        'duration': duration, 'updated_at': when, 'source': 'trakt'}
        except Exception:
            continue
    _PROGRESS_LOOKUP_CACHE[key] = (time.time(), dict(best))
    return best
