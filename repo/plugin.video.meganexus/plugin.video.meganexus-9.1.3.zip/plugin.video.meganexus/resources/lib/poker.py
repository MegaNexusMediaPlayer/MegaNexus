# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Poker (the HUB's Retro row): No-Limit Texas Hold'em for 2 to 8 players around the TV, each with a phone.

The user: "Texas Holdem za vise osoba na uzor guess it ... 3d stol playeri oko stola ... a na mobitelu vidimo karte
i kontrole i koliko para stavljamo". This is the table itself - who sits where, the cards, the blinds, every bet and
every pot - with nothing of Kodi in it (meganexus_ui/poker.py shows it, play_server carries it to the phones).

The rules, as played everywhere: the button moves one seat each hand; the two seats after it post the small and the
big blind (two players: the button is the small blind and acts first before the flop, last after it). Each street a
player may fold, check when nothing is owed, call, bet or raise - at least the last raise, at most everything (no
limit). An all-in for less than a full raise does not let the players who already acted raise again. Whatever was
put in builds the pots: a side pot for every all-in level, each won by the best hand among the players in it, split
when equal (an odd chip to the first winner after the button). A player with no chips is out; the last one with
chips wins the game.
"""
import itertools
import secrets

RANKS = '23456789TJQKA'
SUITS = 'shdc'                    # spades, hearts, diamonds, clubs
NAMES = {2: 'Two', 3: 'Three', 4: 'Four', 5: 'Five', 6: 'Six', 7: 'Seven', 8: 'Eight', 9: 'Nine', 10: 'Ten',
         11: 'Jack', 12: 'Queen', 13: 'King', 14: 'Ace'}
PLURAL = {6: 'Sixes'}
HANDS = ('High card', 'Pair', 'Two pair', 'Three of a kind', 'Straight', 'Flush', 'Full house', 'Four of a kind',
         'Straight flush')
STREETS = ('preflop', 'flop', 'turn', 'river')
MOST = 8


def deck(rng=None):
    """The 52 cards ('As', 'Td' ...), shuffled - by the system's own randomness unless a test gives its own."""
    cards = [rank + suit for rank in RANKS for suit in SUITS]
    (rng or secrets.SystemRandom()).shuffle(cards)
    return cards


def value(card):
    return RANKS.index(card[0]) + 2


def _plural(rank):
    return PLURAL.get(rank, NAMES[rank] + 's')


def rank5(cards):
    """Five cards' strength: (category 0-8, the ranks that break ties), higher is better."""
    values = sorted((value(c) for c in cards), reverse=True)
    counts = {}
    for v in values:
        counts[v] = counts.get(v, 0) + 1
    groups = sorted(counts.items(), key=lambda item: (-item[1], -item[0]))     # by how many, then how high
    flush = len({c[1] for c in cards}) == 1
    unique = sorted(set(values), reverse=True)
    straight = 0
    if len(unique) == 5:
        if unique[0] - unique[4] == 4:
            straight = unique[0]
        elif unique == [14, 5, 4, 3, 2]:          # the wheel: the ace low
            straight = 5
    if straight and flush:
        return (8, straight)
    if groups[0][1] == 4:
        return (7, groups[0][0], groups[1][0])
    if groups[0][1] == 3 and groups[1][1] == 2:
        return (6, groups[0][0], groups[1][0])
    if flush:
        return (5,) + tuple(values)
    if straight:
        return (4, straight)
    if groups[0][1] == 3:
        return (3, groups[0][0]) + tuple(v for v in values if v != groups[0][0])
    if groups[0][1] == 2 and groups[1][1] == 2:
        high, low = groups[0][0], groups[1][0]
        return (2, high, low, groups[2][0])
    if groups[0][1] == 2:
        return (1, groups[0][0]) + tuple(v for v in values if v != groups[0][0])
    return (0,) + tuple(values)


def best(cards):
    """The best five of up to seven cards: (strength, those five)."""
    return max(((rank5(five), five) for five in itertools.combinations(cards, 5)), key=lambda pair: pair[0])


def describe(strength):
    """A hand's name as players say it: 'Two pair, Kings and Sevens', 'Straight, Ace high'."""
    kind = strength[0]
    if kind == 8:
        return 'Royal flush' if strength[1] == 14 else 'Straight flush, %s high' % NAMES[strength[1]]
    if kind == 7:
        return 'Four of a kind, %s' % _plural(strength[1])
    if kind == 6:
        return 'Full house, %s over %s' % (_plural(strength[1]), _plural(strength[2]))
    if kind == 5:
        return 'Flush, %s high' % NAMES[strength[1]]
    if kind == 4:
        return 'Straight, %s high' % NAMES[strength[1]]
    if kind == 3:
        return 'Three of a kind, %s' % _plural(strength[1])
    if kind == 2:
        return 'Two pair, %s and %s' % (_plural(strength[1]), _plural(strength[2]))
    if kind == 1:
        return 'Pair of %s' % _plural(strength[1])
    return 'High card, %s' % NAMES[strength[1]]


class Refused(ValueError):
    """A move the table does not allow (not this player's turn, too little, too much)."""


class Table(object):
    """One game: ``players`` [(slot, name)] in their seats' order, each with ``chips``; blinds ``small`` / ``big``."""

    def __init__(self, players, chips, small, big, rng=None):
        if not 2 <= len(players) <= MOST:
            raise Refused('2 to %d players' % MOST)
        self.rng = rng or secrets.SystemRandom()
        self.seats = [{'slot': slot, 'name': name, 'chips': chips, 'cards': [], 'bet': 0, 'total': 0, 'folded': False,
                       'allin': False, 'out': False, 'acted': False, 'raise_ok': True, 'said': '', 'shown': False}
                      for slot, name in players]
        self.small, self.big = small, big
        self.button = -1
        self.hand = 0
        self.board, self.deck = [], []
        self.street = ''
        self.current = 0                  # the highest bet on this street
        self.last_raise = 0               # what a raise must add at least
        self.turn = None                  # the seat whose move it is
        self.result = None                # the hand's end: {'pots': [...], 'winners': ...}
        self.blind_seats = (None, None)

    # ---- who is where --------------------------------------------------------------------------------------------
    def seat_of(self, slot):
        return next((i for i, s in enumerate(self.seats) if s['slot'] == slot), None)

    def playing(self):
        """The seats still in the game (chips left, or in this hand)."""
        return [i for i, s in enumerate(self.seats) if not s['out']]

    def _next(self, start, test):
        count = len(self.seats)
        for step in range(1, count + 1):
            i = (start + step) % count
            if test(self.seats[i]):
                return i
        return None

    def in_hand(self):
        return [i for i, s in enumerate(self.seats) if not s['out'] and not s['folded']]

    def _can_act(self, seat):
        return not seat['out'] and not seat['folded'] and not seat['allin']

    def over(self):
        """The game's winner's seat once only one has chips, else None."""
        alive = [i for i, s in enumerate(self.seats) if not s['out']]
        return alive[0] if len(alive) == 1 else None

    # ---- a hand -----------------------------------------------------------------------------------------------------
    def start_hand(self):
        """Shuffle, move the button, post the blinds, deal two cards each; the first move is the next seat's."""
        if self.over() is not None:
            raise Refused('the game is over')
        self.hand += 1
        self.result = None
        self.board, self.deck = [], deck(self.rng)
        for seat in self.seats:
            seat.update(cards=[], bet=0, total=0, folded=seat['out'], allin=False, acted=False, raise_ok=True, said='',
                        shown=False)
        self.button = self._next(self.button, lambda s: not s['out'])
        alive = self.playing()
        if len(alive) == 2:               # heads-up: the button posts the small blind
            small = self.button
        else:
            small = self._next(self.button, lambda s: not s['out'])
        big = self._next(small, lambda s: not s['out'])
        self.blind_seats = (small, big)
        self.street = 'preflop'
        self.current, self.last_raise = 0, self.big
        self._put(small, self.small)
        self._put(big, self.big)
        self.seats[small]['said'], self.seats[big]['said'] = 'Small blind', 'Big blind'
        self.current = max(self.seats[small]['bet'], self.seats[big]['bet'])
        for _round in range(2):
            for i in self._order_from(small):
                self.seats[i]['cards'].append(self.deck.pop())
        self.turn = self._next(big, self._can_act)
        self._settle()

    def _order_from(self, first):
        count = len(self.seats)
        return [i % count for i in range(first, first + count) if not self.seats[i % count]['out']]

    def _put(self, i, amount):
        seat = self.seats[i]
        amount = min(amount, seat['chips'])
        seat['chips'] -= amount
        seat['bet'] += amount
        seat['total'] += amount
        if seat['chips'] == 0:
            seat['allin'] = True
        return amount

    def options(self, slot):
        """What ``slot`` may do now: {'fold', 'check', 'call', 'raise_min', 'raise_max', 'raising'} - None when it
        is not their turn. 'call' is what calling costs (all they have when less); 'raise_min' / 'raise_max' are
        the totals a bet or raise goes to ('raising': False when only calling or folding is left)."""
        i = self.seat_of(slot)
        if i is None or i != self.turn or self.result is not None:
            return None
        seat = self.seats[i]
        owed = self.current - seat['bet']
        most = seat['bet'] + seat['chips']
        least = self.current + self.last_raise if self.current else self.big
        raising = seat['raise_ok'] and most > self.current and any(
            self._can_act(self.seats[j]) for j in range(len(self.seats)) if j != i)
        return {'fold': True, 'check': owed <= 0, 'call': min(max(owed, 0), seat['chips']),
                'raise_min': min(least, most), 'raise_max': most, 'raising': raising, 'bet': self.current == 0}

    def act(self, slot, move, to=0):
        """``move`` 'fold' | 'check' | 'call' | 'raise' (to the total ``to``) | 'allin' - Refused when not allowed.
        Returns what happened in words for the table ('Raise to 120')."""
        can = self.options(slot)
        if can is None:
            raise Refused('not your turn')
        i = self.turn
        seat = self.seats[i]
        if move == 'allin':
            move, to = ('raise', seat['bet'] + seat['chips']) if can['raising'] or seat['bet'] + seat['chips'] <= self.current \
                else ('call', 0)
            if move == 'raise' and to <= self.current:
                move = 'call'
        if move == 'fold':
            seat['folded'] = True
            said = 'Fold'
        elif move == 'check':
            if not can['check']:
                raise Refused('there is a bet to call')
            said = 'Check'
        elif move == 'call':
            if can['check']:
                said = 'Check'
            else:
                paid = self._put(i, can['call'])
                said = 'All-in %d' % seat['bet'] if seat['allin'] else 'Call %d' % paid
        elif move == 'raise':
            to = int(to)
            if not can['raising']:
                raise Refused('no raising now')
            if to > can['raise_max'] or (to < can['raise_min'] and to != can['raise_max']):
                raise Refused('a raise to %d is not allowed (%d - %d)' % (to, can['raise_min'], can['raise_max']))
            full = to - self.current >= self.last_raise
            self._put(i, to - seat['bet'])
            if full:
                self.last_raise = to - self.current
            self.current = to
            for j, other in enumerate(self.seats):
                if j != i and self._can_act(other):
                    other['acted'] = False
                    if full:
                        other['raise_ok'] = True
            said = ('All-in %d' if seat['allin'] else ('Bet %d' if can['bet'] else 'Raise to %d')) % to
        else:
            raise Refused('unknown move %r' % move)
        seat['acted'] = True
        seat['raise_ok'] = False
        seat['said'] = said
        self.turn = self._next(i, self._can_act)
        self._settle()
        return said

    def _street_done(self):
        for seat in self.seats:
            if self._can_act(seat) and (not seat['acted'] or seat['bet'] != self.current):
                return False
        return True

    def _settle(self):
        """After a move: the hand won by folds, the next street (the first move the first seat's after the button),
        or - nobody left to bet against - the cards run out to the river and the showdown."""
        if len(self.in_hand()) == 1:
            return self._finish()
        able = [s for s in self.seats if self._can_act(s)]
        alone = len(able) == 1 and able[0]['bet'] >= self.current        # the others all-in, nothing owed
        if able and not alone and not self._street_done():
            if self.turn is None or not self._can_act(self.seats[self.turn]):
                self.turn = self._next(self.turn if self.turn is not None else self.button, self._can_act)
            return None
        while True:
            for seat in self.seats:
                seat['bet'], seat['acted'], seat['raise_ok'] = 0, False, True
            self.current, self.last_raise = 0, self.big
            if self.street == 'river':
                return self._finish()
            self.street = STREETS[STREETS.index(self.street) + 1]
            self.deck.pop()                               # burnt
            self.board += [self.deck.pop() for _ in range(3 if self.street == 'flop' else 1)]
            if len([s for s in self.seats if self._can_act(s)]) >= 2:
                for seat in self.seats:
                    if not seat['folded'] and not seat['out']:
                        seat['said'] = 'All-in' if seat['allin'] else ''
                self.turn = self._next(self.button, self._can_act)
                return None
            self.turn = None

    def pots(self):
        """[{'amount', 'seats'}]: the main pot then each side pot, with the seats that can win it."""
        levels = sorted({s['total'] for s in self.seats if s['total'] and not s['folded'] and not s['out']} |
                        {s['total'] for s in self.seats if s['total'] and s['allin']})
        pots, below = [], 0
        for level in levels:
            amount = sum(min(s['total'], level) - min(s['total'], below) for s in self.seats)
            eligible = [i for i, s in enumerate(self.seats) if not s['folded'] and not s['out'] and s['total'] >= level]
            if amount:
                if pots and pots[-1]['seats'] == eligible:
                    pots[-1]['amount'] += amount
                else:
                    pots.append({'amount': amount, 'seats': eligible})
            below = level
        rest = sum(s['total'] for s in self.seats) - sum(p['amount'] for p in pots)
        if rest and pots:                                  # folded players' chips above the last level
            pots[-1]['amount'] += rest
        return pots

    def _finish(self):
        """The hand's end: each pot to its best hand (folds: to the one left), chips counted, the broke out."""
        contenders = self.in_hand()
        showdown = len(contenders) > 1
        strengths = {}
        if showdown:
            while len(self.board) < 5:
                self.deck.pop()
                self.board.append(self.deck.pop())
            for i in contenders:
                strengths[i] = best(self.seats[i]['cards'] + self.board)
                self.seats[i]['shown'] = True
        won, results = {}, []
        for pot in self.pots():
            seats = [i for i in pot['seats'] if i in contenders] or contenders
            if showdown:
                top = max(strengths[i][0] for i in seats)
                winners = [i for i in seats if strengths[i][0] == top]
            else:
                winners = seats
            share, odd = divmod(pot['amount'], len(winners))
            order = [i for i in self._order_from((self.button + 1) % len(self.seats)) if i in winners]
            for n, i in enumerate(order):
                won[i] = won.get(i, 0) + share + (1 if n < odd else 0)
            results.append({'amount': pot['amount'], 'winners': [self.seats[i]['slot'] for i in order],
                            'hand': describe(strengths[order[0]][0]) if showdown else ''})
        for i, amount in won.items():
            self.seats[i]['chips'] += amount
        for seat in self.seats:
            seat['bet'] = 0
            if seat['chips'] == 0:
                seat['out'] = True
        self.turn = None
        self.street = 'showdown' if showdown else 'won'
        self.result = {'pots': results, 'won': {self.seats[i]['slot']: amount for i, amount in won.items()},
                       'hands': {self.seats[i]['slot']: describe(strengths[i][0]) for i in strengths},
                       'best': {self.seats[i]['slot']: list(strengths[i][1]) for i in strengths}}
        return self.result

    # ---- what the TV and the phones are told --------------------------------------------------------------------
    def pot_total(self):
        return sum(s['total'] for s in self.seats)

    def public(self):
        """Everything anyone may see: no one's cards until they are shown."""
        small, big = self.blind_seats
        return {'hand': self.hand, 'street': self.street, 'board': list(self.board), 'pot': self.pot_total(),
                'current': self.current, 'turn': self.seats[self.turn]['slot'] if self.turn is not None else None,
                'button': self.seats[self.button]['slot'] if self.button >= 0 else None,
                'seats': [{'slot': s['slot'], 'name': s['name'], 'chips': s['chips'], 'bet': s['bet'], 'folded': s['folded'],
                           'allin': s['allin'], 'out': s['out'], 'said': s['said'],
                           'cards': list(s['cards']) if s['shown'] else len(s['cards']),
                           'blind': 'SB' if i == small else 'BB' if i == big else ''}
                          for i, s in enumerate(self.seats)],
                'result': self.result}

    def private(self, slot):
        """One player's own: their cards and what they may do."""
        i = self.seat_of(slot)
        if i is None:
            return {'cards': [], 'options': None, 'chips': 0}
        seat = self.seats[i]
        return {'cards': list(seat['cards']), 'options': self.options(slot), 'chips': seat['chips'], 'bet': seat['bet'],
                'best': describe(best(seat['cards'] + self.board)[0]) if len(seat['cards'] + self.board) >= 5 else ''}
