# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus posters (7.0.48): Home as one wall of the films and series of every
collection (Settings > Home & library > Home layout & cards > Home layout).

The titles of each collection catalog's first page (as its Home row shows them),
each title once, in the order chosen (newest / oldest release, title, as in the
collections) and only the kind chosen (films, series or both), in rows of ROW
posters - a whole row on the screen, so Up / Down keep the column. Built in the
background (build) and kept in the profile (FILE): Home opens with the saved wall
and makes it again when the collections changed or it is older than FRESH; with
none saved yet, one loading row until it is made.
"""
import json
import os
import time

from .meganexus.paths import profile_path

FILE = 'home_posters.json'
ROW = 9                  # posters a row shows whole (1810 px of 196 px cards)
MAX_TITLES = 1800        # the wall at most (200 rows)
FRESH = 2 * 3600         # seconds before a saved wall is made again
WORKERS = 4
SORT_SETTING = 'meganexus_posters_sort'
SHOW_SETTING = 'meganexus_posters_show'
SORTS = (('newest', 'Newest first'), ('oldest', 'Oldest first'), ('title', 'Title A-Z'),
         ('collections', 'As in the collections'))
SHOWS = (('all', 'Films and series'), ('movie', 'Films'), ('series', 'Series'))


def _path():
    return os.path.join(profile_path(), FILE)


def option(setting, choices, addon=None):
    try:
        if addon is None:
            from .settings_snapshot import cached_addon
            addon = cached_addon()
        value = addon.getSetting(setting)
    except Exception:
        value = ''
    return value if value in dict(choices) else choices[0][0]


def signature(shelves):
    """What the wall is made of: the catalogs of the collections (their sources)."""
    keys = []
    for shelf in shelves:
        jobs = shelf.get('collection_job') or ([tuple(shelf['job']) + (shelf.get('extra') or {},)] if shelf.get('job') else [])
        keys.append([(p.get('id'), c.get('type'), c.get('id'), extra) for p, c, extra in jobs])
    return json.dumps(keys, sort_keys=True)


def saved():
    try:
        with open(_path(), encoding='utf-8') as stream:
            data = json.load(stream)
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) and isinstance(data.get('titles'), list) else None


def _kind(card):
    return 'movie' if (card.get('target') or {}).get('media_type') == 'movie' else 'series'


def _released(card):
    """Sortable release: the date, else the year ('' when the add-on gives neither)."""
    return str(card.get('released') or '')[:10] or str(card.get('releaseInfo') or '')[:4]


def arrange(titles, sort='newest', show='all'):
    """The titles of the kind shown, in the order chosen (titles without a date last)."""
    kept = [c for c in titles if show == 'all' or _kind(c) == show]
    if sort == 'title':
        return sorted(kept, key=lambda c: str(c.get('title') or '').casefold())
    if sort in ('newest', 'oldest'):
        dated = [c for c in kept if _released(c)]
        undated = [c for c in kept if not _released(c)]
        return sorted(dated, key=_released, reverse=sort == 'newest') + undated
    return kept


def build(stopped=None):
    """Every collection catalog's first page, each title once (the first collection
    that has it keeps it, the others lend missing pictures); saved for Home."""
    from concurrent.futures import ThreadPoolExecutor
    from .collections_home import catalog_rows
    from .home_data import load_catalog
    shelves = catalog_rows(full=True)
    results = [None] * len(shelves)
    with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='MegaNexusPosters') as pool:
        futures = {pool.submit(load_catalog, dict(shelf), stopped): i for i, shelf in enumerate(shelves)}
        for future, i in futures.items():
            try:
                results[i] = future.result()
            except Exception:
                results[i] = []
    if stopped and stopped():
        return None
    titles, seen = [], {}
    for rows in results:
        for card in rows or []:
            target = card.get('target') or {}
            if not target.get('canonical_id') or card.get('person'):
                continue                       # Browse all, placeholders, people
            key = (_kind(card), target['canonical_id'])
            if key in seen:
                for art in ('poster', 'fanart', 'clearlogo'):
                    if not seen[key].get(art) and card.get(art):
                        seen[key][art] = card[art]
                continue
            seen[key] = dict(card)
            titles.append(seen[key])
    data = {'built': time.time(), 'signature': signature(shelves), 'titles': titles[:MAX_TITLES]}
    path = _path()
    temp = '%s.%d.tmp' % (path, os.getpid())
    try:
        with open(temp, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False)
        os.replace(temp, path)
    except OSError:
        try:
            os.remove(temp)
        except OSError:
            pass
    return data


def stale(data, shelves=None):
    if not data or time.time() - float(data.get('built') or 0) > FRESH:
        return True
    if shelves is None:
        from .collections_home import catalog_rows
        shelves = catalog_rows(full=True)
    return data.get('signature') != signature(shelves)


def shelves():
    """Home's rows of posters; a single loading row until the wall is made once."""
    from .home_data import placeholder
    data = saved()
    if not data:
        return [{'title': '', 'shape': 'poster', 'posters_job': True, 'rows': [placeholder(' ', '')]}]
    sort, show = option(SORT_SETTING, SORTS), option(SHOW_SETTING, SHOWS)
    titles = arrange(data['titles'], sort, show)
    if not titles:
        return [{'title': '', 'shape': 'poster', 'rows': [placeholder('No titles yet', 'Add collections or another kind.')]}]
    rows = [{'title': '', 'shape': 'poster', 'posters_row': True, '_loaded': True, 'rows': titles[i:i + ROW]}
            for i in range(0, len(titles), ROW)]
    rows[0]['title'] = '%s · %s' % (dict(SHOWS)[show], dict(SORTS)[sort])
    rows[0]['posters_refresh'] = True       # Home checks in the background whether it is still current
    return rows
