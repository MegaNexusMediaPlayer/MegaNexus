# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The pause screen (9.1.1, NuvioTV #4142): a film or an episode paused and no key pressed for a few
seconds - its picture over the whole screen, "You're watching", its logo or name, its line and story,
the time and when it ends, and its cast with their photos. Any key takes it away (Kodi's own idle
time, System.IdleTime: no key, no timer of ours); it comes back after the same quiet - over the
player's menu too, when that is all that is open.

The skin's overlay (review/make_pause_screen.py, Custom_1113) draws what this writes to Window(Home):
the title's own details from the playback MegaNexus started (player_session: Kodi 22 plays a bare item,
"InfoTag skipped" - Kodi itself knows no title, story or cast there), Kodi's labels for any other
video; the cast as Kodi has it (Kodi 21, info_tag), else the title's details (backend_api.metadata, as
its page shows them) - asked behind the screen, which shows at once and takes the faces when they come.
No Trakt comments: the title's page has them. HUB Settings > Playback > Pause screen switches it off.
While it may show, Kodi's screensaver keeps away (_hold): its dim-on-pause came over it after a minute.
"""
import json
import threading

PREFIX = 'meganexus.pause.'
READY = PREFIX + 'ready'          # Window(Home): '1' - the screen may show (the option on, what plays known)
HELD = PREFIX + 'held'            # Window(Home): '1' while it keeps Kodi's screensaver away
SETTING = 'meganexus_pause_screen'
CAST = 8                          # people shown at most
FIELDS = ('name', 'role', 'photo')
TEXT = ('title', 'line', 'plot', 'fanart', 'logo')
CREW = ('director', 'writer', 'producer')
_ASKED = {}                       # the title last asked for its cast -> its people (one request per title)


def enabled():
    try:
        from .settings_snapshot import cached_addon
        return cached_addon().getSetting(SETTING) != 'false'
    except Exception:
        return True


def cast_of(item, most=CAST):
    """[(name, role, photo)] of a cast, in its own order - those with a photo first (a row of faces),
    the others after them while there is room. ``item``: Kodi's playing item (cast: name / role /
    thumbnail) or a title's details (meganexus_people: name / role / photo, the crew left out)."""
    rows = (item or {}).get('cast') or [p for p in (item or {}).get('meganexus_people') or []
                                       if isinstance(p, dict) and str(p.get('role') or '').lower() not in CREW]
    people = [(str(p.get('name') or '').strip(), str(p.get('role') or '').strip(),
               str(p.get('thumbnail') or p.get('photo') or ''))
              for p in rows if isinstance(p, dict) and str(p.get('name') or '').strip()]
    people = [(name, '' if role == 'Cast' else role, photo) for name, role, photo in people]
    with_photo = [p for p in people if p[2]]
    return (with_photo + [p for p in people if not p[2]])[:most]


def text_of(session, labels):
    """{title, line, plot, fanart, logo} - the playback's own (session, kodi_info) first, Kodi's labels
    (``labels``: name -> value) for what it does not say."""
    session = session if isinstance(session, dict) else {}
    info = session.get('kodi_info') if isinstance(session.get('kodi_info'), dict) else {}
    pick = lambda *values: next((str(v).strip() for v in values if v not in (None, '') and str(v).strip()), '')
    season = pick(session.get('season'), info.get('season'), labels.get('VideoPlayer.Season'))
    episode = pick(session.get('episode'), info.get('episode'), labels.get('VideoPlayer.Episode'))
    show = pick(session.get('show_title'), info.get('tvshowtitle'), labels.get('VideoPlayer.TVShowTitle'))
    title = pick(info.get('title'), session.get('title'), labels.get('VideoPlayer.Title'))
    if show and episode:
        line = ' · '.join(x for x in ('S%s E%s' % (season or '1', episode), title if title != show else '') if x)
        heading = show
    else:
        genre = info.get('genre') or labels.get('VideoPlayer.Genre') or ''
        genre = ', '.join(genre) if isinstance(genre, list) else str(genre)
        # the length stands beside the time (Kodi's own Player.Duration): the playback's says minutes or seconds
        line = ' · '.join(x for x in (pick(info.get('year'), session.get('year'), labels.get('VideoPlayer.Year')),
                                      genre.replace(' / ', ', ')) if x)
        heading = title
    return {'title': heading, 'line': line, 'plot': pick(info.get('plot'), labels.get('VideoPlayer.Plot')),
            'fanart': pick(session.get('background'), labels.get('Player.Art(fanart)'), labels.get('Player.Art(tvshow.fanart)')),
            'logo': pick(session.get('clearlogo'), labels.get('Player.Art(clearlogo)'), labels.get('Player.Art(tvshow.clearlogo)'))}


def _hold(home, on):
    """Kodi's screensaver away while the screen may show, given back on resume or stop. Kodi dims a paused video
    after its screensaver time (here a minute, "Use dim if paused during video playback") - over this screen,
    which it washed out ("kad je pauza ... kodi dima ekran ... pozadina probija kroz ovaj zaslon")."""
    import xbmc
    if bool(home.getProperty(HELD)) == on:
        return
    xbmc.executebuiltin('InhibitScreensaver(%s)' % ('true' if on else 'false'))
    if on:
        home.setProperty(HELD, '1')
    else:
        home.clearProperty(HELD)


def _playing_item():
    import xbmc
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetItem',
                                                       'params': {'playerid': 1, 'properties': ['cast']}})))
    return (reply.get('result') or {}).get('item') or {}


def _write_cast(home, people):
    for index in range(CAST):
        person = people[index] if index < len(people) else ('', '', '')
        for field, value in zip(FIELDS, person):
            key = '%scast.%d.%s' % (PREFIX, index, field)
            if value:
                home.setProperty(key, value)
            else:
                home.clearProperty(key)


def _details_cast(session, home):
    """The title's cast from its details (behind the screen) - only while this title is still paused there."""
    kind = 'movie' if str(session.get('media_type') or '') == 'movie' else 'series'
    cid = str(session.get('canonical_id') or '')
    key = (kind, cid)
    people = _ASKED.get(key)
    if people is None:
        try:
            from . import backend_api
            people = cast_of(backend_api.metadata(kind, cid, title=str(session.get('show_title') or session.get('title') or '')))
        except Exception:
            people = []
        _ASKED.clear()
        _ASKED[key] = people
    if people and home.getProperty(READY) and home.getProperty(PREFIX + 'title_id') == cid:
        _write_cast(home, people)


def paused():
    """The video was paused: what it is for the screen, and the screen allowed (never with the option off)."""
    try:
        import xbmc
        import xbmcgui
        home = xbmcgui.Window(10000)
        if not enabled() or not xbmc.getCondVisibility('Player.HasVideo'):
            clear()
            return
        from .player_session import load_session
        session = load_session() or {}
        if session and not session.get('meganexus_request_id') == home.getProperty('meganexus.playing.request_id'):
            session = {}                               # another playback's, left behind: not this video's
        names = ('VideoPlayer.Title', 'VideoPlayer.TVShowTitle', 'VideoPlayer.Season', 'VideoPlayer.Episode', 'VideoPlayer.Year',
                 'VideoPlayer.Genre', 'VideoPlayer.Plot', 'Player.Art(fanart)', 'Player.Art(tvshow.fanart)',
                 'Player.Art(clearlogo)', 'Player.Art(tvshow.clearlogo)')
        text = text_of(session, dict((name, xbmc.getInfoLabel(name)) for name in names))
        for name in TEXT:
            if text[name]:
                home.setProperty(PREFIX + name, text[name])
            else:
                home.clearProperty(PREFIX + name)
        people = cast_of(_playing_item())
        _write_cast(home, people)
        home.setProperty(PREFIX + 'title_id', str(session.get('canonical_id') or ''))
        home.setProperty(READY, '1')
        _hold(home, True)
        if not people and session.get('canonical_id'):
            threading.Thread(target=_details_cast, args=(session, home), name='MegaNexusPauseCast', daemon=True).start()
    except Exception:
        pass


def resumed():
    """Playing again: the screensaver as Kodi has it (what the screen shows is kept for the next pause)."""
    try:
        import xbmcgui
        _hold(xbmcgui.Window(10000), False)
    except Exception:
        pass


def clear():
    """Nothing of the screen left: the video stopped, or another one starts."""
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        _hold(home, False)
        home.clearProperty(READY)
        for name in TEXT + ('title_id',):
            home.clearProperty(PREFIX + name)
        _write_cast(home, [])
    except Exception:
        pass
