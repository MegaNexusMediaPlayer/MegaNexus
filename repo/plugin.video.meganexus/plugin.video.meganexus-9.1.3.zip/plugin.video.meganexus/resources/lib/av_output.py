# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.3: what really goes out to the TV and the receiver - picture and sound - for the diagnostics window (the user:
"previse je stvari unknown ... ljudi zele da znaju sta im os izbacuje od zvuka i slike", on CoreELEC, its avdvplus /
P3i builds, LibreELEC, PCs and Android).

Kodi itself says what the source is, how it is decoded, the screen mode it asked for and whether the sound is passed
through (Player.Process(audiodecoder) "pt-truehd" ...), never what the HDMI carries. That is read where the system
keeps it, as the tools made for it read it:

* Amlogic (CoreELEC and its builds, an Amlogic Android box where it may be read): the HDMI driver's own files -
  amhdmitx0/config (VIC, colour space and depth, EOTF, colourimetry, and the audio's type, channels and rate on the
  wire; the avdvplus and P3i Kodis read the same file for their labels), hdmi_hdr_status (Dolby Vision TV-led or
  low latency, HDR10, HDR10+, HLG, SDR), frac_rate_policy (23.976 or 24) and rawedid.
* Linux DRM (LibreELEC on PCs and the Raspberry Pi, any Linux PC), as drm_info reads it: the connector's properties
  Kodi set (HDR_OUTPUT_METADATA - its EOTF, Colorspace, max bpc) and, where debugfs can be read, the AVI infoframe
  (what is really sent: RGB, YCbCr 4:4:4, 4:2:2, 4:2:0); its EDID in /sys/class/drm.
* ALSA (Linux): the running stream's hw_params (IEC958 = a bitstream; channels, rate) and the ELD - what the TV or
  the receiver behind it says it plays.
* Android: Kodi's AudioTrack line in its log (the encoding Android was asked for: TrueHD, E-AC-3 JOC ...).
* The TV's or receiver's EDID, as edid-decode reads it: its name, Dolby Vision, HDR10+, HDR10, HLG, and its sound
  formats (Dolby TrueHD and Dolby Digital+ with Atmos, DTS-HD, DTS, PCM channels).
* The avdvplus and P3i Kodis' own labels (Player.Process(video.hdr.type), video.hdmi.output, amlogic.vs10.mode,
  audiochannelssink ...) when they are there.

Every read fails quietly - a file that is not there, or may not be read, gives nothing; nothing is ever written.
"""
import glob
import os
import re

AML = '/sys/class/amhdmitx/amhdmitx0/'
# Kodi's labels report() reads - the avdvplus / P3i ones and LibreELEC's are empty on another Kodi
LABELS = ('System.ScreenResolution', 'System.SupportedHDRTypes', 'Player.Process(video.hdr.type)',
          'Player.Process(videooutputhdrtype)', 'Player.Process(video.hdmi.output)', 'Player.Process(amlogic.vs10.mode)',
          'Player.Process(audiodecoder)', 'Player.Process(audiochannels)', 'Player.Process(audiosamplerate)',
          'Player.Process(audiobitspersample)', 'Player.Process(audiochannelssink)', 'Player.Process(audio.layout.name.sink)',
          # the film's own pixels: Kodi's word when its decoder names them, the avdvplus / cpm / P3i Kodis' otherwise
          'Player.Process(pixformat)', 'Player.Process(video.bit.depth)', 'Player.Process(video.color.space)',
          'Player.Process(video.color.range)',
          # 9.1.3: CroqueMr's CB1 builds name the source's bits; the decoder where Kodi's pixel word is "unknown"
          'Player.Process(videosourcebits)', 'Player.Process(videodecoder)')
KEYS = ('source', 'mode', 'signal', 'colour', 'dv_mode', 'tv', 'audio_kodi', 'audio_out', 'receiver')
DISPLAY_MODE = '/sys/class/display/mode'
NOT_REPORTED = 'not reported by this system'


def _read(path, binary=False):
    try:
        with open(path, 'rb' if binary else 'r') as handle:
            return handle.read()
    except (OSError, UnicodeDecodeError, ValueError):
        return b'' if binary else ''


# ---- the TV's or the receiver's EDID ---------------------------------------------------------------------------
_SOUND = {1: 'PCM', 2: 'Dolby Digital', 7: 'DTS', 10: 'Dolby Digital+', 11: 'DTS-HD', 12: 'Dolby TrueHD'}
_ORDER = ('Dolby TrueHD', 'Dolby Digital+', 'Dolby Digital', 'DTS-HD', 'DTS', 'PCM')
_LAYOUT = {2: '2.0', 3: '2.1', 6: '5.1', 7: '6.1', 8: '7.1'}
DOLBY_VISION_OUI, HDR10_PLUS_OUI = 0x00D046, 0x90848B


def edid_facts(data):
    """{'name', 'hdr': ['Dolby Vision', 'HDR10+', 'HDR10', 'HLG'], 'sound': ['Dolby TrueHD (Atmos)', ...]} of an EDID
    (bytes); {} when it is none."""
    data = bytes(data or b'')
    if len(data) < 128 or data[:8] != b'\x00\xff\xff\xff\xff\xff\xff\x00':
        return {}
    name = ''
    for at in (54, 72, 90, 108):
        block = data[at:at + 18]
        if block[:3] == b'\x00\x00\x00' and block[3] == 0xFC:
            name = block[5:18].split(b'\n')[0].decode('ascii', 'replace').strip()
    hdr, sound, atmos, pcm = set(), set(), set(), 0
    for start in range(128, min(len(data), 128 * (1 + data[126])), 128):
        block = data[start:start + 128]
        if len(block) < 4 or block[0] != 0x02:
            continue                                   # not a CTA-861 extension
        end, pos = min(block[2], 127), 4
        while pos < end:
            tag, length = block[pos] >> 5, block[pos] & 0x1F
            body = block[pos + 1:pos + 1 + length]
            if tag == 1:                               # audio: three bytes a format
                for k in range(0, len(body) - 2, 3):
                    code, channels = (body[k] >> 3) & 0x0F, (body[k] & 0x07) + 1
                    if code in _SOUND:
                        sound.add(_SOUND[code])
                        if code == 1:
                            pcm = max(pcm, channels)
                        if code in (10, 12) and body[k + 2] & 0x01:
                            atmos.add(_SOUND[code])      # E-AC-3 JOC, MAT with object audio: Dolby Atmos
            elif tag == 7 and body:
                if body[0] == 6 and len(body) > 1:     # HDR static metadata: the EOTFs the TV takes
                    if body[1] & 0x04:
                        hdr.add('HDR10')
                    if body[1] & 0x08:
                        hdr.add('HLG')
                elif body[0] == 1 and len(body) >= 4:  # vendor-specific video: Dolby Vision, HDR10+
                    oui = body[1] | body[2] << 8 | body[3] << 16
                    if oui == DOLBY_VISION_OUI:
                        hdr.add('Dolby Vision')
                    elif oui == HDR10_PLUS_OUI:
                        hdr.add('HDR10+')
            pos += 1 + length
    names = []
    for kind in _ORDER:
        if kind in sound:
            names.append('PCM %s' % _LAYOUT.get(pcm, '%d ch' % pcm) if kind == 'PCM' else
                         kind + (' (Atmos)' if kind in atmos else ''))
    return {'name': name, 'hdr': [kind for kind in ('Dolby Vision', 'HDR10+', 'HDR10', 'HLG') if kind in hdr], 'sound': names}


# ---- Amlogic ---------------------------------------------------------------------------------------------------
_SIGNAL = {'dolbyvision-std': 'Dolby Vision · TV-led', 'dolbyvision-lowlatency': 'Dolby Vision · player-led (low latency)',
           'hdr10plus-vsif': 'HDR10+', 'hdr10-gamma_st2084': 'HDR10', 'hdr10-gamma_hlg': 'HLG', 'hdr10-others': 'HDR',
           'sdr': 'SDR'}
_SPACE = {'rgb': 'RGB', 'yuv444': 'YCbCr 4:4:4', 'yuv422': 'YCbCr 4:2:2', 'yuv420': 'YCbCr 4:2:0'}
_WIRE_SOUND = {'l-pcm': 'PCM', 'ac-3': 'Dolby Digital', 'dobly digital+': 'Dolby Digital+', 'dolby digital+': 'Dolby Digital+',
               'mat': 'Dolby MAT (TrueHD)', 'dts': 'DTS', 'dts_hd': 'DTS-HD', 'dts_hd_ma': 'DTS-HD MA', 'aac': 'AAC',
               'mpeg1': 'MPEG-1', 'mpeg2': 'MPEG-2', 'mp3': 'MP3'}


def amlogic_config(text):
    """The HDMI driver's config file ("Key: value" lines) as {key in lower case: value}."""
    found = {}
    for line in str(text or '').splitlines():
        key, sep, value = line.partition(':')
        if sep and key.strip() and key.strip().lower() not in found:
            found[key.strip().lower()] = value.strip()
    return found


def _rate(hz, fractional):
    """'23.976 Hz' for 24 with the 1000/1001 rate on, '24 Hz' else."""
    try:
        number = int(hz)
    except (TypeError, ValueError):
        return ''
    if fractional and number in (24, 30, 48, 60, 120):
        return '%s Hz' % ('%.3f' % (number / 1.001)).rstrip('0').rstrip('.')
    return '%d Hz' % number


def amlogic_mode(vic, display_mode='', fractional=False):
    """'3840×2160 · 23.976 Hz' from the config's VIC line ("93 3840x2160p24hz") or the display mode ("2160p24hz")."""
    found = re.search(r'(\d+)x(\d+)([pi])(\d+)hz', str(vic or ''), re.I)
    if found:
        width, height, scan, hz = found.groups()
        return '%s×%s%s · %s' % (width, height, ' interlaced' if scan.lower() == 'i' else '', _rate(hz, fractional))
    found = re.search(r'(\d+)([pi])(\d+)hz', str(display_mode or ''), re.I)
    if found:
        lines, scan, hz = found.groups()
        return '%s%s · %s' % (lines, scan.lower(), _rate(hz, fractional))
    return ''


def amlogic(read=_read):
    """What an Amlogic box's HDMI carries now: {'mode', 'signal', 'colour', 'sound', 'tv'} - {} elsewhere."""
    config = amlogic_config(read(AML + 'config'))
    status = read(AML + 'hdmi_hdr_status').strip().lower()
    mode = read(DISPLAY_MODE).strip()
    if not config and not status and not mode:
        return {}
    fractional = read(AML + 'frac_rate_policy').strip() == '1'
    out = {'mode': amlogic_mode(config.get('vic'), mode, fractional), 'signal': _SIGNAL.get(status, '')}
    depth, space = config.get('colour depth', ''), _SPACE.get(config.get('colourspace', '').lower(), '')
    colourimetry = config.get('colourimetry', '').replace('BT.2020nc', 'BT.2020').replace('BT.2020c', 'BT.2020')
    words = [space, depth if depth and depth != 'unknown' else '', colourimetry if 'unknown' not in colourimetry.lower() else '',
             ('%s range' % config['colour range']) if config.get('colour range') in ('limited', 'full') else '']
    out['colour'] = ' · '.join(word for word in words if word)
    kind = _WIRE_SOUND.get(config.get('audio type', '').lower(), '')
    channels = re.match(r'(\d+) channels', config.get('audio channel num', ''))
    rate = config.get('audio sample rate', '')
    if kind and config.get('audio on/off', 'on') != 'off':
        out['sound'] = ' · '.join(word for word in (kind, '%s ch' % channels.group(1) if channels else '',
                                                     rate if re.match(r'[\d.]+kHz', rate) else '') if word)
    raw = read(AML + 'rawedid').strip()
    try:
        out['tv'] = edid_facts(bytes.fromhex(raw)) if raw else {}
    except ValueError:
        out['tv'] = {}
    return {key: value for key, value in out.items() if value}


# ---- Linux DRM -------------------------------------------------------------------------------------------------
def drm_connectors(root='/sys/class/drm'):
    """The connected outputs, an external one (HDMI, DisplayPort) before a built-in screen: [(name, path)]."""
    found = []
    for path in sorted(glob.glob(os.path.join(root, 'card*-*'))):
        if _read(os.path.join(path, 'status')).strip() == 'connected':
            name = os.path.basename(path).split('-', 1)[1]
            found.append((0 if name.startswith(('HDMI', 'DP')) else 1, name, path))
    return [(name, path) for _rank, name, path in sorted(found)]


def _ioctl(number, size):
    return (3 << 30) | (size << 16) | (ord('d') << 8) | number


def drm_properties(card, connector_id, wanted=('HDR_OUTPUT_METADATA', 'Colorspace', 'max bpc', 'EDID')):
    """{name: value} of a connector's properties (an enum's name, a range's number, a blob's bytes) - read as drm_info
    reads them, never a probe of the screen; {} when the device cannot be read."""
    import ctypes
    import fcntl

    class Properties(ctypes.Structure):
        _fields_ = [('props_ptr', ctypes.c_uint64), ('prop_values_ptr', ctypes.c_uint64), ('count_props', ctypes.c_uint32),
                    ('obj_id', ctypes.c_uint32), ('obj_type', ctypes.c_uint32)]

    class Property(ctypes.Structure):
        _fields_ = [('values_ptr', ctypes.c_uint64), ('enum_blob_ptr', ctypes.c_uint64), ('prop_id', ctypes.c_uint32),
                    ('flags', ctypes.c_uint32), ('name', ctypes.c_char * 32), ('count_values', ctypes.c_uint32),
                    ('count_enum_blobs', ctypes.c_uint32)]

    class Enum(ctypes.Structure):
        _fields_ = [('value', ctypes.c_uint64), ('name', ctypes.c_char * 32)]

    class Blob(ctypes.Structure):
        _fields_ = [('blob_id', ctypes.c_uint32), ('length', ctypes.c_uint32), ('data', ctypes.c_uint64)]

    get_props, get_prop, get_blob = (_ioctl(0xB9, ctypes.sizeof(Properties)), _ioctl(0xAA, ctypes.sizeof(Property)),
                                     _ioctl(0xAC, ctypes.sizeof(Blob)))
    try:
        fd = os.open(card, os.O_RDWR | os.O_CLOEXEC)
    except OSError:
        return {}
    found = {}
    try:
        props = Properties(obj_id=int(connector_id), obj_type=0xC0C0C0C0)
        fcntl.ioctl(fd, get_props, props)
        count = props.count_props
        ids, values = (ctypes.c_uint32 * count)(), (ctypes.c_uint64 * count)()
        props.props_ptr, props.prop_values_ptr = ctypes.addressof(ids), ctypes.addressof(values)
        fcntl.ioctl(fd, get_props, props)
        for prop_id, value in zip(ids[:props.count_props], values[:props.count_props]):
            prop = Property(prop_id=prop_id)
            fcntl.ioctl(fd, get_prop, prop)
            name = prop.name.decode('ascii', 'replace')
            if name not in wanted:
                continue
            if prop.flags & (1 << 3):                     # an enum: its name
                enums = (Enum * prop.count_enum_blobs)()
                listed = (ctypes.c_uint64 * max(1, prop.count_values))()
                prop.enum_blob_ptr, prop.values_ptr = ctypes.addressof(enums), ctypes.addressof(listed)
                fcntl.ioctl(fd, get_prop, prop)
                found[name] = next((e.name.decode('ascii', 'replace') for e in enums if e.value == value), str(value))
            elif prop.flags & (1 << 4):                   # a blob: its bytes (none: 0)
                if not value:
                    found[name] = b''
                    continue
                blob = Blob(blob_id=value)
                fcntl.ioctl(fd, get_blob, blob)
                data = (ctypes.c_ubyte * blob.length)()
                blob.data = ctypes.addressof(data)
                fcntl.ioctl(fd, get_blob, blob)
                found[name] = bytes(data)
            else:
                found[name] = int(value)
    except (OSError, ValueError, OverflowError):
        return found
    finally:
        os.close(fd)
    return found


def hdr_signal(metadata):
    """The EOTF of HDR_OUTPUT_METADATA (struct hdr_output_metadata: a u32 type, then the infoframe's EOTF):
    'HDR10', 'HLG', 'SDR'; '' for none read."""
    if metadata is None:
        return ''
    if len(metadata) < 5:
        return 'SDR'                                      # none set: Kodi sends SDR
    return {0: 'SDR', 1: 'HDR', 2: 'HDR10', 3: 'HLG'}.get(metadata[4], '')


def avi_colour(infoframe):
    """The colour format an AVI infoframe (as debugfs gives it: header, checksum, payload) says is sent."""
    if len(infoframe or b'') < 5 or infoframe[0] != 0x82:
        return ''
    return {0: 'RGB', 1: 'YCbCr 4:2:2', 2: 'YCbCr 4:4:4', 3: 'YCbCr 4:2:0'}.get((infoframe[4] >> 5) & 0x03, '')


def drm(root='/sys/class/drm', debug='/sys/kernel/debug/dri', properties=drm_properties):
    """What a Linux DRM output carries: {'output', 'signal', 'colour', 'tv'} - {} where there is none."""
    connectors = drm_connectors(root)
    if not connectors:
        return {}
    name, path = connectors[0]
    connector_id = _read(os.path.join(path, 'connector_id')).strip()
    card = '/dev/dri/' + os.path.basename(path).split('-', 1)[0]
    props = properties(card, connector_id) if connector_id.isdigit() else {}
    # its EDID: sysfs', else the connector's own property (a laptop's screen had an empty sysfs file)
    out = {'output': name, 'tv': edid_facts(_read(os.path.join(path, 'edid'), binary=True) or props.get('EDID'))}
    out['signal'] = hdr_signal(props.get('HDR_OUTPUT_METADATA')) if 'HDR_OUTPUT_METADATA' in props else ''
    colour = ''
    for frame in glob.glob(os.path.join(debug, '*', name, 'infoframes', 'avi')):
        colour = avi_colour(_read(frame, binary=True))
        if colour:
            break
    space = props.get('Colorspace', '')
    words = [colour, ('up to %d-bit' % props['max bpc']) if isinstance(props.get('max bpc'), int) else '',
             'BT.2020' if 'BT2020' in str(space) else '']
    out['colour'] = ' · '.join(word for word in words if word)
    return {key: value for key, value in out.items() if value}


# ---- ALSA ------------------------------------------------------------------------------------------------------
def alsa_playing(root='/proc/asound'):
    """The stream ALSA plays now: {'format', 'channels', 'rate', 'card'} - {} when none."""
    for status in sorted(glob.glob(os.path.join(root, 'card*', 'pcm*p', 'sub*', 'status'))):
        if 'state: RUNNING' not in _read(status):
            continue
        params = dict(line.split(':', 1) for line in _read(os.path.join(os.path.dirname(status), 'hw_params')).splitlines()
                      if ':' in line)
        card = os.path.basename(os.path.dirname(os.path.dirname(os.path.dirname(status))))
        return {'format': params.get('format', '').strip(), 'channels': params.get('channels', '').strip(),
                'rate': params.get('rate', '').strip().split(' ')[0], 'card': _read(os.path.join(root, card, 'id')).strip()}
    return {}


_ELD_SOUND = {0x1: 'PCM', 0x2: 'Dolby Digital', 0x7: 'DTS', 0xA: 'Dolby Digital+', 0xB: 'DTS-HD', 0xC: 'Dolby TrueHD'}


def eld(root='/proc/asound'):
    """What the TV or the receiver on HDMI says it plays (ALSA's ELD): {'name', 'sound'} - {} when none is there."""
    for path in sorted(glob.glob(os.path.join(root, 'card*', 'eld#*'))):
        text = _read(path)
        values = dict(re.findall(r'^(\S+)\s+(.*)$', text, re.M))
        if values.get('monitor_present') != '1' or values.get('eld_valid') != '1':
            continue
        kinds, pcm = set(), 0
        for index in range(int(values.get('sad_count', '0') or 0)):
            code = re.search(r'\[0x([0-9a-f]+)\]', values.get('sad%d_coding_type' % index, ''), re.I)
            kind = _ELD_SOUND.get(int(code.group(1), 16)) if code else None
            if kind:
                kinds.add(kind)
                if kind == 'PCM':
                    try:
                        pcm = max(pcm, int(values.get('sad%d_channels' % index, '0')))
                    except ValueError:
                        pass
        sound = ['PCM %s' % _LAYOUT.get(pcm, '%d ch' % pcm) if kind == 'PCM' else kind for kind in _ORDER if kind in kinds]
        return {'name': values.get('monitor_name', '').strip(), 'sound': sound}
    return {}


# ---- Android: Kodi's AudioTrack, from its log ------------------------------------------------------------------
_ANDROID_ENCODING = {2: 'PCM 16-bit', 3: 'PCM 8-bit', 4: 'PCM float', 5: 'Dolby Digital', 6: 'Dolby Digital+', 7: 'DTS',
                     8: 'DTS-HD', 13: 'IEC 61937 bitstream', 14: 'Dolby TrueHD', 18: 'Dolby Digital+ Atmos (JOC)',
                     19: 'Dolby MAT', 21: 'PCM 24-bit', 22: 'PCM 32-bit'}
_AUDIOTRACK = re.compile(r'Trying to open: samplerate: (\d+), channelMask: (\d+), encoding: (\d+)')


def android_audio(log_text):
    """What Kodi asked Android's AudioTrack for, the last time it opened one: 'Dolby TrueHD · 192 kHz' - '' else."""
    found = _AUDIOTRACK.findall(str(log_text or ''))
    if not found:
        return ''
    rate, _mask, encoding = found[-1]
    kind = _ANDROID_ENCODING.get(int(encoding), 'encoding %s' % encoding)
    return '%s · %s kHz' % (kind, ('%.1f' % (int(rate) / 1000.0)).rstrip('0').rstrip('.'))


# ---- what the window says --------------------------------------------------------------------------------------
_PASSTHROUGH = {'pt-truehd': 'Dolby TrueHD', 'pt-eac3': 'Dolby Digital+', 'pt-ac3': 'Dolby Digital', 'pt-dtshd': 'DTS-HD',
                'pt-dts': 'DTS'}
_SOURCE_HDR = {'dolbyvision': 'Dolby Vision', 'hdr10plus': 'HDR10+', 'hdr10': 'HDR10', 'hlg': 'HLG'}


# FFmpeg's names of a colour space and a range (av_color_space_name, av_color_range_name), as people say them
_SPACES = {'bt2020nc': 'BT.2020', 'bt2020c': 'BT.2020', 'bt709': 'BT.709', 'smpte170m': 'BT.601', 'bt470bg': 'BT.601',
           'ictcp': 'ICtCp'}
_RANGES = {'tv': 'limited range', 'pc': 'full range'}


# 9.1.3: what a hardware decoder's frames are called (its surface on the GPU or the chip), never the film's pixels
_SURFACES = {'vaapi': 'VAAPI', 'vaapi_vld': 'VAAPI', 'vdpau': 'VDPAU', 'drm_prime': 'DRM PRIME', 'mediacodec': 'MediaCodec',
             'd3d11': 'D3D11', 'd3d11va_vld': 'D3D11', 'dxva2_vld': 'DXVA2', 'videotoolbox_vld': 'VideoToolbox',
             'videotoolbox': 'VideoToolbox', 'cuda': 'NVDEC', 'qsv': 'Quick Sync', 'mmal': 'MMAL', 'vulkan': 'Vulkan'}
_CHROMA = {'420': '4:2:0', '422': '4:2:2', '444': '4:4:4', '440': '4:4:0', '411': '4:1:1', '410': '4:1:0'}
_SEMI = {'0': '4:2:0', '2': '4:2:2', '4': '4:4:4'}


def _software(name):
    """FFmpeg's word for decoded pixels in plain words: 'yuv420p10le' -> ('YUV 4:2:0 · 10-bit', full range?)."""
    found = re.fullmatch(r'yuva?(j?)(420|422|444|440|411|410)p(\d+)?(?:le|be)?', name)
    if found:
        return 'YUV %s · %d-bit' % (_CHROMA[found.group(2)], int(found.group(3) or 8)), bool(found.group(1))
    found = re.fullmatch(r'nv(12|21|16|24|42)', name)
    if found:
        return 'YUV %s · 8-bit' % {'12': '4:2:0', '21': '4:2:0', '16': '4:2:2'}.get(found.group(1), '4:4:4'), False
    found = re.fullmatch(r'p([024])(10|12|16)(?:le|be)?', name)
    if found:
        return 'YUV %s · %s-bit' % (_SEMI[found.group(1)], found.group(2)), False
    found = re.fullmatch(r'gbra?p(\d+)?(?:le|be)?', name)
    if found:
        return 'RGB 4:4:4 · %d-bit' % int(found.group(1) or 8), False
    found = re.fullmatch(r'(?:rgb|bgr)(24|48)(?:le|be)?|(?:rgba|bgra|argb|abgr|rgb0|bgr0|0rgb|0bgr)', name)
    if found:
        return 'RGB · %s-bit' % ('16' if found.group(1) == '48' else '8'), False
    found = re.fullmatch(r'gray(\d+)?(?:le|be)?', name)
    if found:
        return 'Grey · %d-bit' % int(found.group(1) or 8), False
    return '', False


def source_format(pixel, depth='', space='', colour_range='', decoder='', stream_bits=None):
    """The film's own pixels for the Pixel format row, from what this system really reports. Decoded in software:
    FFmpeg's word in plain words ('yuv420p10le' -> 'YUV 4:2:0 · 10-bit'). A hardware decoder names only its surface
    ('vaapi', 'd3d11', 'mediacodec'; an Amlogic one Kodi's default "unknown", Player.Process(amlogic.pixformat) being
    the HDMI mode's): then the bits a fork or CB1 gives ('12-bit · BT.2020 · limited range'), else a Dolby Vision
    film's own RPU (``stream_bits``), with the decoder that made them ('10-bit · VAAPI'). Nothing is guessed: what
    no one says reads so."""
    pixel = str(pixel or '').strip()
    low = pixel.lower()
    space = _SPACES.get(str(space or '').strip().lower(), '')
    colour_range = _RANGES.get(str(colour_range or '').strip().lower(), '')
    words, full = _software(low)
    if words:
        return _join(words, space, colour_range or ('full range' if full else ''))
    named = low not in ('', 'unknown', 'none')
    if named:
        surface = _SURFACES.get(low, pixel)
    else:                                  # Kodi's "unknown" (Amlogic): the decoder is named only when nothing else is
        decoder = str(decoder or '').strip()
        surface = decoder if decoder and not decoder.lower().startswith('ff-') else ''
    found = re.search(r'\d+', str(depth or ''))
    bits = int(found.group()) if found else 0
    if bits > 0:                           # the avdvplus / cpm / P3i rows stay as they were
        return _join('%d-bit' % bits, space, colour_range, surface if named else '')
    if stream_bits:
        return _join('%d-bit' % stream_bits, surface if named else '')
    return _join(surface, 'format not reported') if surface else NOT_REPORTED


def _join(*words):
    return ' · '.join(str(word) for word in words if word)


def kodi_audio(decoder, channels='', rate='', bits='', sink_channels='', sink_layout=''):
    """What Kodi hands the system: 'Passthrough (bitstream) · Dolby TrueHD' or 'PCM decoded by Kodi · 7.1 · 48 kHz · 24-bit'."""
    if str(decoder or '').lower() in _PASSTHROUGH:
        return 'Passthrough (bitstream) · %s' % _PASSTHROUGH[decoder.lower()]
    if not decoder:
        return ''
    try:
        khz = ('%.1f' % (int(str(rate).replace(',', '').replace('.', '')) / 1000.0)).rstrip('0').rstrip('.') + ' kHz' if rate else ''
    except ValueError:
        khz = ''
    layout = sink_layout or (_LAYOUT.get(int(sink_channels or channels), '%s ch' % (sink_channels or channels))
                             if str(sink_channels or channels).isdigit() else '')
    return _join('PCM decoded by Kodi (%s)' % decoder, layout, khz, '%s-bit' % bits if str(bits).isdigit() else '')


def report(labels, aml=None, linux=None, playing=None, receiver=None, android='', stream_bits=None):
    """The diagnostics window's rows of what comes in and goes out: {'source', 'mode', 'signal', 'colour', 'dv_mode',
    'tv', 'audio_kodi', 'audio_out', 'receiver'} - from Kodi's labels (``labels``: {label: its value}) and what the system reports
    (amlogic(), drm(), alsa_playing(), eld(), android_audio()). What no layer reports says so."""
    aml, linux, playing, receiver = aml or {}, linux or {}, playing or {}, receiver or {}
    get = lambda name: str(labels.get(name) or '').strip()
    out = {'source': source_format(get('Player.Process(pixformat)'),
                                   get('Player.Process(video.bit.depth)') or get('Player.Process(videosourcebits)'),
                                   get('Player.Process(video.color.space)'), get('Player.Process(video.color.range)'),
                                   get('Player.Process(videodecoder)'), stream_bits),
           'mode': aml.get('mode') or get('System.ScreenResolution')}
    # what goes to the TV: the box's own driver, Linux's connector, the avdvplus / P3i / LibreELEC Kodi's word
    fork_signal = get('Player.Process(video.hdr.type)') or get('Player.Process(videooutputhdrtype)')
    signal = aml.get('signal') or linux.get('signal') or _SOURCE_HDR.get(fork_signal.lower().replace(' ', ''), fork_signal)
    out['signal'] = signal or NOT_REPORTED
    out['colour'] = aml.get('colour') or linux.get('colour') or get('Player.Process(video.hdmi.output)')
    out['dv_mode'] = get('Player.Process(amlogic.vs10.mode)')
    tv = aml.get('tv') or linux.get('tv') or {}
    supported = tv.get('hdr') or [kind.strip() for kind in get('System.SupportedHDRTypes').split(',') if kind.strip()]
    out['tv'] = _join(tv.get('name'), ', '.join(_SOURCE_HDR.get(kind.lower(), kind) for kind in supported)) or ''
    decoder = get('Player.Process(audiodecoder)')
    out['audio_kodi'] = kodi_audio(decoder, get('Player.Process(audiochannels)'), get('Player.Process(audiosamplerate)'),
                                   get('Player.Process(audiobitspersample)'), get('Player.Process(audiochannelssink)'),
                                   get('Player.Process(audio.layout.name.sink)'))
    wire = aml.get('sound')
    if not wire and playing:
        bitstream = 'IEC958' in playing.get('format', '') or decoder.lower() in _PASSTHROUGH
        rate = playing.get('rate', '')
        wire = _join('Bitstream (%s)' % _PASSTHROUGH.get(decoder.lower(), 'IEC 61937') if bitstream else 'PCM %s' % playing.get('format', ''),
                     '%s ch' % playing['channels'] if playing.get('channels') else '',
                     ('%s kHz' % ('%.1f' % (int(rate) / 1000.0)).rstrip('0').rstrip('.')) if rate.isdigit() else '')
    out['audio_out'] = wire or android or (NOT_REPORTED if decoder else '')
    heard = receiver.get('sound') or tv.get('sound') or []
    out['receiver'] = _join(receiver.get('name') if receiver.get('name') != tv.get('name') else '', ', '.join(heard))
    return out
