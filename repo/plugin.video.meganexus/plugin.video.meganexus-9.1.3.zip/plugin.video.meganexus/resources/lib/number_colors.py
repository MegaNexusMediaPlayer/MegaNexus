# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.1: the colour inside the big numbers - Home's Top 10 ranks and the Library's counts ("napravi da mogu
promijeniti boju unutra ovih velikih brojeva, ali ostavi i mogućnost da prati poster, što će biti službena početna
vrijednost ... crnu, srebrnu, zlatnu i tako neki spektar boja").

Poster colours (the default, ''): each number takes the colour of what stands beside it - a Top 10 poster's own
leading colour (top10_rows.tint), a Library tile's its service's (library.TINT). Otherwise one colour for every
number. The numbers' pictures are white at the top going grey at the foot (review/make_rank_images.py), so a colour
is their top's and its shade their foot's - silver and gold keep their sheen. Each place keeps its own see-through
(the alpha of its own colours)."""
from .settings_snapshot import setting

SETTING = 'meganexus_number_color'
POSTER = ''
COLOURS = (('333333', 'Black'), ('B8C0CC', 'Silver'), ('FFC24D', 'Gold'), ('C98B4E', 'Bronze'), ('FFFFFF', 'White'),
           ('E0283C', 'Red'), ('F07A1E', 'Orange'), ('F5CF1F', 'Yellow'), ('35B455', 'Green'), ('17AFA3', 'Teal'),
           ('26BCE0', 'Cyan'), ('3366E0', 'Blue'), ('8048E0', 'Purple'), ('EB4A8A', 'Pink'))
NAMES = dict(COLOURS)
LABEL = 'Poster colours'
ALPHA = 'D9'      # a number with no colour of its own (a Top 10 poster without one): as see-through as the poster ones


def chosen(get=None):
    """'RRGGBB' of the colour chosen for every number; '' - Poster colours (also for a value not in COLOURS).
    ``get``: a setting's value by its id (MegaNexus' settings)."""
    value = str((get or setting)(SETTING) or '').strip().upper()
    return value if value in NAMES else POSTER


def label(value):
    return NAMES.get(value, LABEL)


def fill(own, get=None):
    """The fill of a number whose own colour is ``own`` ('AARRGGBB'; '' none): the chosen colour with ``own``'s
    alpha (ALPHA without one) - or ``own`` itself with Poster colours."""
    own = str(own or '')
    colour = chosen(get)
    if not colour:
        return own
    return (own[:2] if len(own) == 8 else ALPHA) + colour
