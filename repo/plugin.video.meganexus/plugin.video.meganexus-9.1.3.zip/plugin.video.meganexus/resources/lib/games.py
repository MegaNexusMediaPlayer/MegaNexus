# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The HUB's Games app (games branch): free games and your own, played in Kodi's own emulators (RetroPlayer).

The user: "samo ova opcija dolazi u obzir jer je jednostavna i radi svugdje ... ubaciti bar 20 besplatnih igara
postere njihove ... opis igre". The free games are resources/games/catalog.json (review/make_games_catalog.py): none
is shipped - each is the author's own release, downloaded the first time it is played and kept only when its SHA-256
is the one written in the catalogue. Your own games are the files in the folders you add (Options); MegaNexus never
looks for games anywhere else and never offers a place to get them.

A game plays in one of Kodi's game add-ons (game.libretro.*): the one that takes the file's kind, the catalogue's
choice first for its console. Kodi's own RunAddon(core, file) starts it (interfaces/builtins/AddonBuiltins.cpp: a
game add-on with a file is played with that add-on) - and Kodi keeps the game's own saves.

"bitno je da addon ne radi u pozadini nikako ako se ne koristi": nothing here runs by itself - the app asks, then it
is all forgotten (forget()).
"""
import hashlib
import io
import json
import os
import re
import shutil
import tarfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'plugin.video.meganexus'
RECENT, FOLDERS = 'games_recent.json', 'games_folders.json'     # each MegaNexus profile its own (user_profiles)
RECENT_MOST = 30
DOWNLOAD_TIMEOUT = 30            # s without a byte: the download stops
CHUNK = 64 * 1024
# the cores the catalogue takes first for its consoles (any other installed core that takes the file comes after)
FIRST = {'nes': ('game.libretro.nestopia', 'game.libretro.fceumm', 'game.libretro.mesen', 'game.libretro.quicknes'),
         'gb': ('game.libretro.gambatte', 'game.libretro.sameboy', 'game.libretro.mgba', 'game.libretro.tgbdual'),
         'gbc': ('game.libretro.gambatte', 'game.libretro.sameboy', 'game.libretro.mgba', 'game.libretro.tgbdual'),
         'gba': ('game.libretro.mgba', 'game.libretro.vbam', 'game.libretro.beetle-gba'),
         'doom': ('game.libretro.prboom',),
         'quake': ('game.libretro.tyrquake',),
         'dos': ('game.libretro.dosbox-pure',)}
SCAN_DEPTH = 2                   # your folders and the folders in them
# the consoles a file of yours can be for: its name, the short one, libretro's picture folder (thumbnails.libretro.com,
# the pictures RetroArch shows), the kinds of file only it has, and the words a game add-on's <platforms> names it by
CONSOLES = {
    'nes': ('Nintendo Entertainment System', 'NES', 'Nintendo - Nintendo Entertainment System', ('nes', 'fds', 'unf', 'unif'), ('nes', 'famicom')),
    'snes': ('Super Nintendo', 'SNES', 'Nintendo - Super Nintendo Entertainment System', ('sfc', 'smc', 'fig', 'swc'), ('snes', 'super nintendo', 'sfc')),
    'n64': ('Nintendo 64', 'N64', 'Nintendo - Nintendo 64', ('n64', 'v64', 'z64'), ('nintendo 64', 'n64')),
    'gb': ('Game Boy', 'Game Boy', 'Nintendo - Game Boy', ('gb', 'dmg'), ()),
    'gbc': ('Game Boy Color', 'Game Boy Color', 'Nintendo - Game Boy Color', ('gbc',), ()),
    'gba': ('Game Boy Advance', 'Game Boy Advance', 'Nintendo - Game Boy Advance', ('gba', 'agb'), ('game boy advance', 'gba')),
    'nds': ('Nintendo DS', 'DS', 'Nintendo - Nintendo DS', ('nds',), ('nintendo ds',)),
    'vb': ('Virtual Boy', 'Virtual Boy', 'Nintendo - Virtual Boy', ('vb', 'vboy'), ('virtual boy',)),
    'pokemini': ('Pokemon mini', 'Pokemon mini', 'Nintendo - Pokemon Mini', ('min',), ('pokemon mini',)),
    'ps1': ('PlayStation', 'PS1', 'Sony - PlayStation', (), ('playstation', 'psx')),
    'ps2': ('PlayStation 2', 'PS2', 'Sony - PlayStation 2', (), ('playstation 2',)),
    'megadrive': ('Sega Mega Drive / Genesis', 'Mega Drive', 'Sega - Mega Drive - Genesis', ('md', 'gen', 'smd'), ('mega drive', 'genesis')),
    'mastersystem': ('Sega Master System', 'Master System', 'Sega - Master System - Mark III', ('sms',), ('master system',)),
    'gamegear': ('Sega Game Gear', 'Game Gear', 'Sega - Game Gear', ('gg',), ('game gear',)),
    'saturn': ('Sega Saturn', 'Saturn', 'Sega - Saturn', (), ('saturn',)),
    'pce': ('PC Engine / TurboGrafx-16', 'PC Engine', 'NEC - PC Engine - TurboGrafx 16', ('pce',), ('pc engine', 'turbografx')),
    'atari2600': ('Atari 2600', 'Atari 2600', 'Atari - 2600', ('a26',), ('2600',)),
    'atari7800': ('Atari 7800', 'Atari 7800', 'Atari - 7800', ('a78',), ('7800',)),
    'lynx': ('Atari Lynx', 'Lynx', 'Atari - Lynx', ('lnx', 'lyx'), ('lynx',)),
    'ngp': ('Neo Geo Pocket', 'Neo Geo Pocket', 'SNK - Neo Geo Pocket', ('ngp',), ()),
    'ngpc': ('Neo Geo Pocket Color', 'Neo Geo Pocket Color', 'SNK - Neo Geo Pocket Color', ('ngc', 'ngpc'), ()),
    'ws': ('WonderSwan', 'WonderSwan', 'Bandai - WonderSwan', ('ws',), ()),
    'wsc': ('WonderSwan Color', 'WonderSwan Color', 'Bandai - WonderSwan Color', ('wsc',), ()),
}
THUMBS = 'https://thumbnails.libretro.com/'
ART = 'games_art.json'           # what libretro had for your files (one list for every profile)
ART_AGAIN = 7 * 86400            # s: a picture libretro did not have is asked for again a week later
ART_TIMEOUT = 8
ART_WORKERS = 6
_lock = threading.Lock()
_kept = {}


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


def _root():
    return xbmcvfs.translatePath(_addon().getAddonInfo('path'))


def _profile():
    from .meganexus.paths import profile_path
    return profile_path()


def downloads():
    """Where the free games are kept once downloaded (one copy for every profile)."""
    path = os.path.join(_profile(), 'games')
    os.makedirs(path, exist_ok=True)
    return path


def catalog():
    """resources/games/catalog.json, its pictures' paths made whole."""
    with _lock:
        if 'catalog' not in _kept:
            base = os.path.join(_root(), 'resources', 'games')
            with open(os.path.join(base, 'catalog.json'), encoding='utf-8') as source:
                data = json.load(source)
            for item in data['games']:
                for key in ('poster', 'fanart'):
                    item[key] = os.path.join(base, item[key])
            _kept['catalog'] = data
        return _kept['catalog']


def forget():
    """The app closed: nothing of it stays in memory."""
    with _lock:
        _kept.clear()


def free_game(ident):
    return next((g for g in catalog()['games'] if g['id'] == ident), None)


# ---- Kodi's game add-ons ------------------------------------------------------------------------------------

def _rpc(method, params):
    answer = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    return answer.get('result') or {}


def _core_facts(path):
    """What a game add-on's addon.xml says: the files it takes, whether it is a game of its own and the consoles it
    plays (its <platforms>, as its authors wrote them)."""
    try:
        root = ET.parse(os.path.join(xbmcvfs.translatePath(path), 'addon.xml')).getroot()
    except (OSError, ET.ParseError):
        return set(), False, ''
    point = root.find("extension[@point='kodi.gameclient']")
    if point is None:
        return set(), False, ''
    words = (point.findtext('extensions') or '').lower()
    extensions = {w.strip().lstrip('.') for w in re.split(r'[|,\s]+', words) if w.strip()}
    return (extensions, (point.findtext('supports_standalone') or '').strip().lower() == 'true',
            (point.findtext('platforms') or '').strip())


def cores():
    """Kodi's installed, enabled game add-ons: {id: {'name', 'extensions', 'standalone', 'platforms'}} - read from
    Kodi each time the app asks (an add-on installed meanwhile is there)."""
    found = {}
    for addon in _rpc('Addons.GetAddons', {'type': 'kodi.gameclient', 'enabled': True,
                                           'properties': ['name', 'path']}).get('addons') or []:
        extensions, standalone, platforms = _core_facts(addon.get('path') or '')
        found[addon['addonid']] = {'name': addon.get('name') or addon['addonid'], 'extensions': extensions,
                                   'standalone': standalone, 'platforms': platforms}
    return found


def controller_ids():
    """Kodi's controller add-ons that are installed (a game add-on brings the ones it plays with)."""
    return {addon['addonid'] for addon in _rpc('Addons.GetAddons', {'type': 'kodi.game.controller',
                                                                     'enabled': True}).get('addons') or []}


def extension(name):
    return os.path.splitext(name)[1].lower().lstrip('.')


def core_for(item, installed):
    """The game add-on that plays ``item`` (a catalogue game or one of yours): '' when none is installed."""
    if item.get('core'):
        return item['core'] if item['core'] in installed else ''
    kind = extension((item.get('file') or {}).get('name') or item.get('path') or '')
    takes = [ident for ident, facts in sorted(installed.items()) if kind in facts['extensions']]
    for ident in FIRST.get(item.get('system'), ()):
        if ident in takes:
            return ident
    return takes[0] if takes else ''


def core_wanted(item):
    """The game add-on to install for ``item`` when none plays it (the catalogue's first for its console)."""
    if item.get('core'):
        return item['core']
    return (FIRST.get(item.get('system')) or ('',))[0]


# ---- the free games' files ----------------------------------------------------------------------------------

def local_file(item):
    """Where the game's file is kept: its name may have its folder (a Quake game's id1/pak0.pak)."""
    return os.path.join(downloads(), item['id'], *item['file']['name'].split('/'))


DOS_START = 'MNXSTART.BAT'       # a DOS game's start: DOSBox Pure mounts its folder as C:, knows the game (its
                                 # controller mapping) and runs it - no start menu. A .conf would be plain DOSBox: no C:,
                                 # no saves, no mapping (dosbox_pure_libretro.cpp, dbp_skip_c_mount)


def dos_start(spec):
    """A DOS game's start (a batch file): into its folder, ``before`` (Tyrian's sound setup the first time), then its
    program."""
    folder, program = spec['start'].rsplit('/', 1) if '/' in spec['start'] else ('', spec['start'])
    lines = ['@echo off'] + (['cd \\' + folder.replace('/', '\\')] if folder else [])
    return '\r\n'.join(lines + list(spec.get('before') or []) + [program]) + '\r\n'


def _unzip(archive, folder):
    """A DOS game's whole zip into its folder - nothing written outside it, whatever a name in the zip says."""
    with zipfile.ZipFile(archive) as packed:
        for info in packed.infolist():
            parts = [part for part in info.filename.replace('\\', '/').split('/') if part not in ('', '.')]
            if not parts or '..' in parts or ':' in parts[0]:
                raise Refused('%s: a file outside the game' % info.filename)
            target = os.path.join(folder, *parts)
            if info.is_dir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with packed.open(info) as source, open(target, 'wb') as out:
                shutil.copyfileobj(source, out)


def _unpack(spec, archive, target):
    """The game's own file out of what came: a zip's member, a member of the zip its parts make once joined (the
    old DOS installers: DOOMS_19.1 + DOOMS_19.2 are one self-extracting zip), or a tar.gz's member."""
    if spec.get('tar'):
        with tarfile.open(archive) as outer:
            source = outer.extractfile(spec['member'])
            if source is None:
                raise Refused('%s is not in the download' % spec['member'])
            with source, open(target, 'wb') as out:
                shutil.copyfileobj(source, out)
        return
    with zipfile.ZipFile(archive) as outer:
        inner = zipfile.ZipFile(io.BytesIO(b''.join(outer.read(part) for part in spec['join']))) if spec.get('join') else outer
        with inner, inner.open(spec['member']) as source, open(target, 'wb') as out:
            shutil.copyfileobj(source, out)


def ready(item):
    """A catalogue game can start now: Kodi's own, or its file is here (checked when it came)."""
    return not item.get('file') or os.path.isfile(local_file(item))


def sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


class Refused(Exception):
    """The download is not the game the catalogue lists (its SHA-256 differs) - it is not kept."""


def download(item, progress=None, cancelled=lambda: False):
    """The game's own release, from its author's place, into downloads(): kept only when its SHA-256 is the
    catalogue's. ``progress(done, total)``; ``cancelled()`` stops it. Returns the game's file. Never from a GUI
    callback (the app's worker)."""
    spec = item['file']
    folder = os.path.join(downloads(), item['id'])
    os.makedirs(folder, exist_ok=True)
    partial = os.path.join(folder, '.download')
    request = urllib.request.Request(spec['url'], headers={'User-Agent': 'MegaNexus-Kodi'})
    digest, done = hashlib.sha256(), 0
    try:
        with urllib.request.urlopen(request, timeout=DOWNLOAD_TIMEOUT) as answer, open(partial, 'wb') as out:
            total = int(answer.headers.get('Content-Length') or spec.get('size') or 0)
            while True:
                if cancelled():
                    raise InterruptedError('cancelled')
                block = answer.read(CHUNK)
                if not block:
                    break
                out.write(block)
                digest.update(block)
                done += len(block)
                if progress:
                    progress(done, total)
        if digest.hexdigest() != spec['sha256']:
            raise Refused('%s: the download is not the one MegaNexus knows' % item['title'])
        target = local_file(item)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        if spec.get('start'):
            _unzip(partial, folder)
            os.remove(partial)
            with open(target + '.part', 'w', encoding='ascii', newline='') as out:     # last: the game is all here
                out.write(dos_start(spec))
            os.replace(target + '.part', target)
        elif spec.get('member'):
            _unpack(spec, partial, target + '.part')
            os.replace(target + '.part', target)
            os.remove(partial)
        else:
            os.replace(partial, target)
        return target
    finally:
        for left in (partial, local_file(item) + '.part'):
            if os.path.exists(left):
                os.remove(left)


def remove_download(item):
    shutil.rmtree(os.path.join(downloads(), item['id']), ignore_errors=True)


def downloaded_size():
    total = 0
    for top, _dirs, files in os.walk(downloads()):
        total += sum(os.path.getsize(os.path.join(top, name)) for name in files)
    return total


# ---- the phones' code ----------------------------------------------------------------------------------------

def phone_key(new=False):
    """The phones' key on this device: the same every time Games or Guess It opens - a phone's home screen icon
    (an iPhone's only way to the controller without the browser's bars) keeps working; ``new``: another one, the
    phones that had the old one need the code again (Options)."""
    path = os.path.join(downloads(), 'phones.key')
    try:
        with open(path, encoding='ascii') as source:
            kept = source.read().strip()
    except (OSError, ValueError):
        kept = ''
    if kept and not new:
        return kept
    import secrets
    kept = secrets.token_urlsafe(12)
    with open(path + '.tmp', 'w', encoding='ascii') as out:
        out.write(kept)
    os.replace(path + '.tmp', path)
    return kept


# ---- your own games -----------------------------------------------------------------------------------------

def _read(name, default):
    try:
        with open(os.path.join(_profile(), name), encoding='utf-8') as source:
            value = json.load(source)
        return value if isinstance(value, type(default)) else default
    except (OSError, ValueError):
        return default


def _write(name, value):
    path = os.path.join(_profile(), name)
    with open(path + '.tmp', 'w', encoding='utf-8') as out:
        json.dump(value, out, ensure_ascii=False)
    os.replace(path + '.tmp', path)


def folders():
    return [f for f in _read(FOLDERS, []) if isinstance(f, str) and f]


def set_folders(paths):
    _write(FOLDERS, list(dict.fromkeys(p for p in paths if p)))


def title_of(name):
    """A file's name as a title: its kind, region and dump marks taken off ("Game (USA) [!].nes" -> "Game")."""
    words = os.path.splitext(name)[0]
    words = re.sub(r'\s*[\(\[][^\)\]]*[\)\]]', '', words).replace('_', ' ')
    return re.sub(r'\s+', ' ', words).strip() or name


def your_games(installed=None, cancelled=lambda: False):
    """The files in your folders that one of Kodi's installed game add-ons takes, by name - read anew each time
    (a network folder can be slow: the app asks from its worker)."""
    installed = cores() if installed is None else installed
    kinds = set().union(*(facts['extensions'] for facts in installed.values())) if installed else set()
    kinds -= {'zip', '7z'}             # an archive may be anything: only what a core names as its own
    found = []

    def walk(path, depth):
        if cancelled() or depth > SCAN_DEPTH:
            return
        try:
            dirs, files = xbmcvfs.listdir(path)
        except Exception:
            return
        for name in sorted(files, key=str.lower):
            if extension(name) in kinds:
                found.append({'id': 'file:' + path.rstrip('/') + '/' + name, 'title': title_of(name),
                              'path': path.rstrip('/') + '/' + name, 'folder': path})
        for name in sorted(dirs, key=str.lower):
            walk(path.rstrip('/') + '/' + name + '/', depth + 1)
    for folder in folders():
        walk(folder if folder.endswith('/') else folder + '/', 1)
    return found


# ---- your games' consoles and pictures -----------------------------------------------------------------------

def console_of(path, installed):
    """The console a file of yours is for (a CONSOLES key): its kind when only one console has it, else the console
    the game add-on that plays it names (its <platforms>); '' when neither says."""
    kind = extension(path)
    for key, facts in CONSOLES.items():
        if kind in facts[3]:
            return key
    named = ((installed.get(core_for({'path': path}, installed)) or {}).get('platforms') or '').lower()
    words = sorted(((word, key) for key, facts in CONSOLES.items() for word in facts[4]), key=lambda pair: -len(pair[0]))
    return next((key for word, key in words if re.search(r'(?<![a-z0-9])%s(?![a-z0-9])' % re.escape(word), named)), '')


def picture_names(path):
    """The names libretro may have a file's pictures under: its own name (libretro writes &*/:`<>?\\|" as _), then
    without the [..] marks of other sets."""
    name = re.sub(r'[&*/:`<>?\\|"]', '_', os.path.splitext(os.path.basename(path))[0])
    plain = re.sub(r'\s+', ' ', re.sub(r'\s*\[[^\]]*\]', '', name)).strip()
    return list(dict.fromkeys(n for n in (name, plain) if n))


def picture_url(console, kind, name):
    """libretro's picture of a game: ``kind`` Named_Boxarts (its box) or Named_Snaps (its play)."""
    return THUMBS + '/'.join(urllib.parse.quote(part) for part in (CONSOLES[console][2], kind, name + '.png'))


def _has(url):
    request = urllib.request.Request(url, method='HEAD', headers={'User-Agent': 'MegaNexus-Kodi'})
    try:
        with urllib.request.urlopen(request, timeout=ART_TIMEOUT) as answer:
            return answer.status == 200
    except urllib.error.HTTPError:
        return False


def _box(console, path, known):
    """The name libretro has the file's box under, '' when it has none - kept in ``known`` (asked once a week)."""
    key = console + '/' + os.path.basename(path)
    said = known.get(key)
    if isinstance(said, list) and len(said) == 2 and (said[0] or time.time() - said[1] < ART_AGAIN):
        return said[0]
    for name in picture_names(path):
        try:
            if _has(picture_url(console, 'Named_Boxarts', name)):
                known[key] = [name, int(time.time())]
                return name
        except (OSError, ValueError):
            return ''                   # no answer (no network): asked again next time
    known[key] = ['', int(time.time())]
    return ''


def console_poster(console):
    """The app's own poster for a game of yours libretro has no box of: its console's, or any console's."""
    art = os.path.join(_root(), 'resources', 'games', 'art')
    path = os.path.join(art, 'console_%s.jpg' % console)
    return path if console and os.path.exists(path) else os.path.join(art, 'console_any.jpg')


def dressed(found, installed, cancelled=lambda: False):
    """Your files with their console ('console') and pictures: libretro's box as the poster ('boxed': shown whole)
    and its play picture as the fanart, else the console's poster. libretro is asked from the app's worker, a few at
    once, each file once."""
    with _lock:
        known = dict(_kept.setdefault('art', _read(ART, {})))      # this call's own copy (the workers write to it)
    before = dict(known)
    items = [dict(item, console=console_of(item['path'], installed)) for item in found]

    def look(item):
        if cancelled() or not item['console']:
            return ''
        return _box(item['console'], item['path'], known)
    with ThreadPoolExecutor(ART_WORKERS) as pool:
        boxes = list(pool.map(look, items))
    for item, box in zip(items, boxes):
        if box:
            item.update(poster=picture_url(item['console'], 'Named_Boxarts', box),
                        fanart=picture_url(item['console'], 'Named_Snaps', box), boxed=True)
        else:
            item.update(poster=console_poster(item['console']), fanart='', boxed=False)
    learnt = {key: said for key, said in known.items() if before.get(key) != said}
    if learnt:
        with _lock:
            _kept['art'].update(learnt)
            _write(ART, _kept['art'])
    return items


# ---- what was played ----------------------------------------------------------------------------------------

def recent():
    return [r for r in _read(RECENT, []) if isinstance(r, dict) and r.get('id')]


def note_played(item):
    """The game just started, first in Continue playing (a file of yours with its path and title)."""
    entry = {'id': item['id'], 'at': int(time.time())}
    if item.get('path'):
        entry.update(path=item['path'], title=item['title'])
    _write(RECENT, ([entry] + [r for r in recent() if r['id'] != item['id']])[:RECENT_MOST])


def forget_played(ident):
    _write(RECENT, [r for r in recent() if r['id'] != ident])


# ---- playing ------------------------------------------------------------------------------------------------

def play_command(item, core):
    """Kodi's builtin that starts the game in ``core``."""
    if item.get('core') and not item.get('file'):
        return 'RunAddon(%s)' % core
    path = item.get('path') or local_file(item)
    return 'RunAddon(%s,"%s")' % (core, path.replace('"', '\\"'))


def playing():
    """A game plays now (RetroPlayer's window is Kodi's fullscreengame)."""
    return xbmc.getCondVisibility('Window.IsActive(fullscreengame) | Window.IsActive(gameosd)')
