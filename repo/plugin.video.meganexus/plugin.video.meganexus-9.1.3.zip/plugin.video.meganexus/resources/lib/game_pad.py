# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""A phone as a game controller (games branch): a virtual gamepad of the system's own, and what its buttons are.

Kodi takes a game's input only from controllers its peripheral add-on sees: JSON-RPC's Input.ButtonEvent and the
EventServer become menu actions (input/InputManager.cpp: XBMC_BUTTON goes to HandleKey, past the keyboard handlers,
and an EventServer key has no release). So a phone plays through a gamepad Linux makes for it (uinput, as Steam's
own virtual pads do): CoreELEC and LibreELEC run Kodi as root and have it; a Linux PC needs /dev/uinput writable for
the user once. Android lets no app make one - there the phone starts games and opens their menu, and a Bluetooth
controller plays.

Every other system (and Linux too, first): our own peripheral add-on (peripheral.meganexus, binary, made for each
system by review/build_peripheral.py) is the controller - one joystick for each phone, its state sent here to
127.0.0.1 only, its buttons' meaning read from features.txt in its profile folder. It is on only while the Games app
is open (begin / end): "addon ne radi u pozadini nikako ako se ne koristi".

Each phone is one "MegaNexus Phone Pad" (32 buttons, two sticks). Its buttons mean what the game's controller has:
Kodi's controller add-ons say which features a console's pad has (game.controller.*/resources/layout.xml) and the
game add-on which controller it plays with (its resources/topology.xml or buttonmap.xml). The same feature always
gets the same button (a=0, b=1 ...) and Kodi's joystick add-on is told so in our device's own button map
(addon_data/peripheral.joystick/resources/buttonmaps/xml/udev) - for every controller installed, written when the
Games app opens, before any phone's pad exists.
"""
import json
import os
import platform
import re
import shutil
import socket
import struct
import sys
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcvfs

try:
    import fcntl                                   # Linux's virtual pads (not on Windows)
except ImportError:
    fcntl = None

UINPUT = '/dev/uinput'
NAME, VENDOR, PRODUCT = 'MegaNexus Phone Pad', 0x4D4E, 0x0001
BUTTONS, AXES = 32, (0x00, 0x01, 0x03, 0x04)      # BTN_TRIGGER_HAPPY1.., ABS_X, ABS_Y, ABS_RX, ABS_RY
FIRST_BUTTON = 0x2C0
EV_SYN, EV_KEY, EV_ABS, BUS_VIRTUAL = 0x00, 0x01, 0x03, 0x06
UI_DEV_CREATE, UI_DEV_DESTROY = 0x5501, 0x5502
UI_DEV_SETUP, UI_ABS_SETUP = 0x405C5503, 0x401C5504
UI_SET_EVBIT, UI_SET_KEYBIT, UI_SET_ABSBIT = 0x40045564, 0x40045565, 0x40045567
STICK = 32767
EVENT = struct.Struct('@llHHi')                    # struct input_event: the time (two longs), type, code, value
SETUP = struct.Struct('=HHHH80sI')                 # struct uinput_setup
ABS_SETUP = struct.Struct('=H2xiiiiii')            # struct uinput_abs_setup
# the same feature, the same button, whatever the console (Kodi's own names: game.controller.*/layout.xml)
FIXED = {'a': 0, 'b': 1, 'x': 2, 'y': 3, 'start': 4, 'select': 5, 'back': 5, 'up': 6, 'down': 7, 'left': 8,
         'right': 9, 'leftbumper': 10, 'rightbumper': 11, 'lefttrigger': 12, 'righttrigger': 13, 'leftthumb': 14,
         'rightthumb': 15}
BUTTON_TAGS = ('button',)
STICK_TAGS = ('analogstick',)
MAP_FOLDER = 'special://profile/addon_data/peripheral.joystick/resources/buttonmaps/xml/udev'
NOT_PADS = ('keyboard', 'mouse')
PERIPHERAL = 'peripheral.meganexus'
PERIPHERAL_PORT = 8768                             # play_server 8767, art_cache 8766, phone_setup 8765
FEATURES = 'special://profile/addon_data/peripheral.meganexus/features.txt'
PERIPHERAL_WAIT = 3.0                              # s Kodi may take to load the add-on once it is enabled
FIND_WAIT = 30.0                                   # s a slow box may take to find an add-on put in its folder
ADDONS = 'special://home/addons/'
BUILD_MARK = '.meganexus-build'
_kind = ['']                                       # the pads while the Games app is open: 'addon', 'uinput' or ''


def available():
    """This system makes virtual gamepads for MegaNexus (Linux, /dev/uinput writable)."""
    return fcntl is not None and sys.platform.startswith('linux') and os.path.exists(UINPUT) and os.access(UINPUT, os.W_OK)


# ---- which pads: our add-on, else Linux's -----------------------------------------------------------------------

def _rpc(method, params):
    answer = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    return answer.get('result') or {}


def listening():
    """Our add-on is loaded: it holds its port (127.0.0.1)."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.bind(('127.0.0.1', PERIPHERAL_PORT))
        return False
    except OSError:
        return True
    finally:
        probe.close()


def _switch(on):
    _rpc('Addons.SetAddonEnabled', {'addonid': PERIPHERAL, 'enabled': on})


def target():
    """This device's build of our add-on (review/build_peripheral.py): ('kodi22', 'android-arm64') ..., or None. The
    size of a pointer says Kodi's own bits (a 64-bit kernel may run 32-bit Kodi)."""
    major = re.match(r'\d+', xbmc.getInfoLabel('System.BuildVersion') or '')
    major = int(major.group()) if major else 0
    if major < 21:
        return None
    kodi = 'kodi21' if major == 21 else 'kodi22'      # a later Kodi takes 22's while its API allows (begin checks)
    bits, machine = struct.calcsize('P') * 8, platform.machine().lower()
    arm = machine.startswith(('arm', 'aarch64'))
    if xbmc.getCondVisibility('System.Platform.Android'):
        name = 'android-arm64' if arm and bits == 64 else 'android-armv7' if arm else ''
    elif xbmc.getCondVisibility('System.Platform.Windows'):
        name = 'windows-x86_64' if bits == 64 and machine in ('amd64', 'x86_64') else ''
    elif xbmc.getCondVisibility('System.Platform.Linux'):
        name = ('linux-aarch64' if bits == 64 else 'linux-armv7') if arm else 'linux-x86_64' if machine == 'x86_64' and bits == 64 else ''
    else:
        name = ''
    return (kodi, name) if name else None


def install():
    """Our add-on for this device in Kodi's add-ons folder, put there (or its new build) from the plugin's
    resources/peripheral: True when Kodi knows it."""
    found = target()
    source = os.path.join(_addon_path('plugin.video.meganexus'), 'resources', 'peripheral')
    try:
        with open(os.path.join(source, 'manifest.json'), encoding='utf-8') as handle:
            manifest = json.load(handle)
        build = manifest[found[0]]['targets'][found[1]]
    except (OSError, ValueError, KeyError, TypeError):
        return False                                  # no build for this device
    folder = xbmcvfs.translatePath(ADDONS + PERIPHERAL)
    stamp = '%s %s %s' % (manifest.get('version'), found[0], build['sha256'])
    try:
        with open(os.path.join(folder, BUILD_MARK), encoding='utf-8') as handle:
            same = handle.read() == stamp
    except OSError:
        same = False
    monitor = xbmc.Monitor()
    if not same:
        if listening():                                # the old one loaded: Kodi lets it go first
            _switch(False)
            waited = 0.0
            while listening() and waited < PERIPHERAL_WAIT and not monitor.waitForAbort(.1):
                waited += .1
        new = folder.rstrip('/\\') + '.new'
        shutil.rmtree(new, ignore_errors=True)
        os.makedirs(new)
        shutil.copyfile(os.path.join(source, found[0], 'addon.xml'), os.path.join(new, 'addon.xml'))
        shutil.copyfile(os.path.join(source, 'icon.png'), os.path.join(new, 'icon.png'))
        shutil.copyfile(os.path.join(source, found[0], found[1], build['library']), os.path.join(new, build['library']))
        with open(os.path.join(new, BUILD_MARK), 'w', encoding='utf-8') as handle:
            handle.write(stamp)
        shutil.rmtree(folder, ignore_errors=True)
        os.replace(new, folder)
        xbmc.executebuiltin('UpdateLocalAddons')
    waited = 0.0
    while not _rpc('Addons.GetAddonDetails', {'addonid': PERIPHERAL}).get('addon'):
        if waited >= FIND_WAIT or monitor.waitForAbort(.5):
            return False
        waited += .5
    return True


def begin(controllers):
    """The Games app opened: our add-on on (each controller's features written first), else Linux's virtual pads;
    'addon', 'uinput' or '' (no phone pads here)."""
    _kind[0] = ''
    if install():
        write_features(controllers)
        _switch(True)
        monitor, waited = xbmc.Monitor(), 0.0
        while not listening() and waited < PERIPHERAL_WAIT and not monitor.waitForAbort(.1):
            waited += .1
        if listening():
            _kind[0] = 'addon'
            return _kind[0]
        _switch(False)                             # it did not load on this system
        xbmc.log('[MegaNexus] Games: the phone pads add-on did not start here', xbmc.LOGWARNING)
    if available():
        write_button_map(controllers)
        _kind[0] = 'uinput'
    return _kind[0]


def end():
    """The Games app closed. 9.1.3: our add-on stays on, idle - no phone, no joystick, its port only. Switched off here,
    it went while Kodi's peripheral scan the phones' leaving had just woken (their 'gone') still called into it: Kodi
    ran the unloaded add-on's code and crashed (PC, 2026-11-11 07:19). Only a new build of it switches it off
    (install), before any phone joins."""
    _kind[0] = ''


def kind():
    return _kind[0]


def make(slot):
    """Player ``slot``'s pad (1..8)."""
    return NetPad(slot - 1) if _kind[0] == 'addon' else Pad()


def write_maps(controllers, appearance=''):
    """What the pads' buttons are, for the pads in use (a game's controller new to the app; ``appearance``: the
    controller of the game that starts)."""
    if _kind[0] == 'addon':
        write_features(controllers, appearance)
    elif _kind[0] == 'uinput':
        write_button_map(controllers)


class NetPad(object):
    """One phone's joystick in our add-on: its whole state, at each change, to the add-on."""

    def __init__(self, slot):
        self.slot, self.buttons, self.axes = slot, 0, [0] * len(AXES)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._send()

    def _say(self, text):
        try:
            self.sock.sendto(text.encode('ascii'), ('127.0.0.1', PERIPHERAL_PORT))
        except OSError:
            pass

    def _send(self):
        self._say('pad %d %x %s' % (self.slot, self.buttons, ' '.join(str(a) for a in self.axes)))

    def press(self, number, down):
        if 0 <= number < BUTTONS:
            self.buttons = (self.buttons | (1 << number)) if down else (self.buttons & ~(1 << number))
            self._send()

    def axis(self, number, value):
        if 0 <= number < len(AXES):
            self.axes[number] = max(-STICK, min(STICK, int(value)))
            self._send()

    def close(self):
        if self.sock is None:
            return
        self._say('gone %d' % self.slot)
        self.sock.close()
        self.sock = None


class Pad(object):
    """One phone's gamepad, for as long as the phone is there."""

    def __init__(self):
        self.fd = os.open(UINPUT, os.O_WRONLY | os.O_NONBLOCK)
        try:
            fcntl.ioctl(self.fd, UI_SET_EVBIT, EV_KEY)
            fcntl.ioctl(self.fd, UI_SET_EVBIT, EV_ABS)
            for number in range(BUTTONS):
                fcntl.ioctl(self.fd, UI_SET_KEYBIT, FIRST_BUTTON + number)
            for code in AXES:
                fcntl.ioctl(self.fd, UI_SET_ABSBIT, code)
                fcntl.ioctl(self.fd, UI_ABS_SETUP, ABS_SETUP.pack(code, 0, -STICK, STICK, 0, 0, 0))
            fcntl.ioctl(self.fd, UI_DEV_SETUP, SETUP.pack(BUS_VIRTUAL, VENDOR, PRODUCT, 1, NAME.encode(), 0))
            fcntl.ioctl(self.fd, UI_DEV_CREATE)
        except OSError:
            os.close(self.fd)
            raise

    def _send(self, kind, code, value):
        os.write(self.fd, EVENT.pack(0, 0, kind, code, value) + EVENT.pack(0, 0, EV_SYN, 0, 0))

    def press(self, number, down):
        if 0 <= number < BUTTONS:
            self._send(EV_KEY, FIRST_BUTTON + number, 1 if down else 0)

    def axis(self, number, value):
        if 0 <= number < len(AXES):
            self._send(EV_ABS, AXES[number], max(-STICK, min(STICK, int(value))))

    def close(self):
        if self.fd is None:
            return
        try:
            fcntl.ioctl(self.fd, UI_DEV_DESTROY)
        except OSError:
            pass
        os.close(self.fd)
        self.fd = None


# ---- what the buttons are ------------------------------------------------------------------------------------

def _addon_path(ident):
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon(ident).getAddonInfo('path'))
    except Exception:
        return ''


def features(layout_xml):
    """A controller's features in its own order: [{'name', 'kind': 'button' | 'stick', 'button' | 'axes'}]. A known
    feature takes its fixed button, any other the next free one from 16; the first stick takes axes 0 and 1, the
    second 2 and 3."""
    found, taken, sticks = [], set(), 0
    try:
        root = ET.parse(layout_xml).getroot()
    except (OSError, ET.ParseError):
        return found
    names = [(node.tag, node.get('name') or '') for node in root.iter() if node.tag in BUTTON_TAGS + STICK_TAGS]
    for tag, name in names:
        if tag in BUTTON_TAGS and name in FIXED:
            taken.add(FIXED[name])
    spare = (n for n in range(16, BUTTONS) if n not in taken)
    for tag, name in names:
        if not name:
            continue
        if tag in STICK_TAGS:
            if sticks < 2:
                found.append({'name': name, 'kind': 'stick', 'axes': [2 * sticks, 2 * sticks + 1]})
                sticks += 1
        elif name in FIXED:
            found.append({'name': name, 'kind': 'button', 'button': FIXED[name]})
        else:
            number = next(spare, None)
            if number is not None:
                found.append({'name': name, 'kind': 'button', 'button': number})
    return found


def controller_of(core):
    """The controller the game add-on plays with: its topology's first port's first one, else the first one its
    button map names (a keyboard or a mouse is no pad)."""
    folder = _addon_path(core)
    if not folder:
        return ''
    for name, path in (('topology', 'resources/topology.xml'), ('buttonmap', 'resources/buttonmap.xml')):
        try:
            root = ET.parse(os.path.join(folder, path)).getroot()
        except (OSError, ET.ParseError):
            continue
        for node in root.iter('controller' if name == 'buttonmap' else 'accepts'):
            ident = node.get('id') or node.get('controller') or ''
            if ident and not any(word in ident for word in NOT_PADS):
                return ident
    return ''


def layout(controller):
    """The features of one of Kodi's controller add-ons (installed with the game add-ons that need it)."""
    folder = _addon_path(controller)
    return features(os.path.join(folder, 'resources', 'layout.xml')) if folder else []


def button_map(controllers):
    """Our device's button map for Kodi's joystick add-on: every controller's features on our buttons and sticks."""
    root = ET.Element('buttonmap')
    device = ET.SubElement(root, 'device', name=NAME, provider='udev', vid='%04X' % VENDOR, pid='%04X' % PRODUCT,
                           buttoncount=str(BUTTONS), axiscount=str(len(AXES)))
    ET.SubElement(device, 'configuration')
    for controller, found in controllers:
        node = ET.SubElement(device, 'controller', id=controller)
        for feature in found:
            if feature['kind'] == 'button':
                ET.SubElement(node, 'feature', name=feature['name'], button=str(feature['button']))
            else:
                x, y = feature['axes']
                stick = ET.SubElement(node, 'feature', name=feature['name'])
                for way, axis in (('up', '-%d' % y), ('down', '+%d' % y), ('right', '+%d' % x), ('left', '-%d' % x)):
                    ET.SubElement(stick, way, axis=axis)
    return ET.tostring(root, encoding='unicode')


def map_file():
    return os.path.join(xbmcvfs.translatePath(MAP_FOLDER), '%s_v%04X_p%04X_%db_%da.xml' % (
        NAME.replace(' ', '_'), VENDOR, PRODUCT, BUTTONS, len(AXES)))


def features_text(controllers, appearance=''):
    """Our add-on's features.txt: the controller of the game that plays (the pads' picture in Kodi's dialogs), then
    each controller and each of its features on our buttons and sticks."""
    lines = ['appearance %s' % appearance] if appearance else []
    for controller, found in controllers:
        lines.append('controller %s' % controller)
        for feature in found:
            if feature['kind'] == 'button':
                lines.append('%s button %d' % (feature['name'], feature['button']))
            else:
                lines.append('%s stick %d %d' % (feature['name'], feature['axes'][0], feature['axes'][1]))
    return '\n'.join(lines) + '\n'


def _write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path, encoding='utf-8') as source:
            if source.read() == text:
                return path
    except OSError:
        pass
    with open(path + '.tmp', 'w', encoding='utf-8') as out:
        out.write(text)
    os.replace(path + '.tmp', path)
    return path


def write_features(controllers, appearance=''):
    """Our add-on reads it when Kodi asks a pad's buttons, and again by itself when it changes."""
    return _write(xbmcvfs.translatePath(FEATURES), features_text(controllers, appearance))


def write_button_map(controllers):
    """Kodi's joystick add-on reads it when a pad of ours appears: written before any does."""
    return _write(map_file(), '<?xml version="1.0" encoding="UTF-8"?>\n' + button_map(controllers) + '\n')
