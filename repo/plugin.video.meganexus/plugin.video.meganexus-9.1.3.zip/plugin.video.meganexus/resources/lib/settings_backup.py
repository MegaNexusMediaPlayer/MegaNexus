# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Back up and restore every MegaNexus choice (7.0).

Set MegaNexus up once, export, and import the file on another device: the
settings, API keys, accounts (Nuvio, Stremio, Trakt, Simkl, Plex, Jellyfin),
add-ons, collections, Home folders and the local library / Continue Watching
come along. Left out on purpose: caches, installer state, one-time migration
markers and IDs that belong to one device. The file holds sign-ins, so it
must be kept private like a password.
7.0.47 (format 2): everything of MegaNexus - also the profiles with their
pictures and own sign-ins, the screensaver / wallpaper pictures, the IPTV lists,
the TMDB sign-in, synced subtitles, the search history and the skin's own
choices (theme, wallpaper, HUB tint, hidden parts). Paths inside MegaNexus'
folder are moved to the new device's folder. Format 1 files still restore.
"""
import base64
import fnmatch
import json
import os
import re
import sqlite3
import tempfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path

FORMAT = 'meganexus.backup'
VERSION = 2
MAX_BYTES = 120 * 1024 * 1024
ADDON_ID = 'plugin.video.meganexus'

# Settings that describe this device or this installation, not the user's choices.
DEVICE_SETTINGS = {
    'plex_client_identifier', 'plex_servers_cache_json', 'meganexus_components_for', 'meganexus_moved_from_previous',
    'meganexus_previous_cleanup', 'meganexus_skin_applied', 'meganexus_screensaver_applied', 'meganexus_restart_pending',
    'meganexus_update_checked', 'meganexus_manifests_refreshed', 'meganexus_conflicts_skipped',
    'meganexus_trailer_defaults_627', 'meganexus_weather_clock_migrated', 'meganexus_profile_applied',
    'meganexus_defaults_rev', 'meganexus_v510_defaults_applied', 'meganexus_v520_defaults_applied',
    'meganexus_wizard_applied', 'meganexus_setup_v110_done', 'meganexus_setup_offered', 'meganexus_setup_v110_step',
    'ui_lang_autodetected', 'last_account_sync_at', 'catalog_state_json', 'meganexus_iptv_instance', 'meganexus_wallpaper_follow_done', 'meganexus_opensubtitles_woken', 'meganexus_collection_shapes_done',
    'meganexus_iptv_configured', 'meganexus_iptv_last_unique', 'meganexus_iptv_last_group', 'meganexus_auto_layout_key',
    'meganexus_precache_total', 'meganexus_precache_version',
    'meganexus_art_native_offered', 'meganexus_pictures_swept',   # 9.0.0: this device's own
}
# Personal files in the profile (JSON) and databases (SQLite, copied consistently).
FILES = ('providers.json', 'meganexus_collections.json', 'meganexus_collections_own.json', 'collection_sets.json', 'continue_hidden.json',
         'hub_catalog_pins.json', 'hub_folder_filters.json', 'hub_folder_prefs.json', 'hub_home_folders.json',
         'hub_home_subfolders.json', 'last_source_map.json', 'library_origins.json', 'sort_prefs.json',
         'trakt_token.json', 'simkl_token.json', 'nuvio_token.json', 'stremio_token.json', 'nuvio_sync_state.json',
         'trakt_outbox.json', 'meganexus_badges.json',
         'tmdb_session.json', 'iptv-lists.json', 'kept_subtitles.json',   # 7.0.47
         'aio_setup.json',   # 7.0.52: the quick setup's add-ons, made again if their instance lost them
         'party_identity.json', 'party_friends.json',   # 7.0.52: Watch Party key and friends
         # 9.0.8: the Music app (its sources, saved songs, artists you follow, playlists brought in, folders, what you
         # heard), the YouTube app's channels and your own collections kept aside while Home shows an add-on's -
         # only the other profiles' were in a backup (profiles/), the first profile's were lost on a restore
         'music_sources.json', 'music_library.json', 'music_follow.json', 'music_playlists.json', 'music_folders.json',
         'music_history.json', 'youtube_channels.json', 'collections-own-backup.json',
         'anilist_token.json', 'mal_token.json')   # 9.1.1: the anime lists' sign-ins
FILE_PATTERNS = ('iptv-groups-*.json',          # 7.0.47: one per IPTV list
                 'iptv-catchup-*.json')         # 7.0.48: its catch-up channels (works at once after a restore)
DATABASES = ('favorites.db', 'playback.db', 'search_history.db')
# 7.0.47: whole folders, as files (pictures, the other profiles' own sign-ins and libraries)
FOLDERS = ('profiles', 'screensaver', 'kept_subtitles')
FOLDER_SKIP = ('*.bak', '*.tmp*', '*.restoring', '*-wal', '*-shm', '*-journal')
FOLDER_FILE_MAX = 25 * 1024 * 1024

# 8.1.5: a backup without what signs in anywhere ("private": safe to hand on) - no API keys,
# passwords, user names, e-mails or sign-ins, and no links that carry them inside
_PRIVATE = re.compile(r'(pass(word|wd)$|secret|token|api_?key|apikey|_key(_\d+)?$|email|user(name)?$|_user$|login|cookie|'
                      r'session|_auth|auth_json|_pin$|client_id|usenet_server|newznab|indexer|prowlarr)', re.I)
_NOT_PRIVATE = {'meganexus_auto_layout_key'}
PRIVATE_FILES = {'trakt_token.json', 'simkl_token.json', 'nuvio_token.json', 'stremio_token.json', 'tmdb_session.json',
                 'party_identity.json', 'trakt_outbox.json', 'nuvio_sync_state.json', 'iptv-lists.json', 'aio_setup.json',
                 'kept_subtitles.json',                       # its rows' links hold the subtitle add-ons' set-up
                 'music_sources.json',                        # 9.0.8: a music source's link and settings hold its ARL or key
                 'anilist_token.json', 'mal_token.json'}      # 9.1.1: AniList / MyAnimeList sign-ins
PRIVATE_PATTERNS = ('iptv-*.json',)                         # an IPTV list's user name and password are in them
_SIGNED_LINK = re.compile(r'/[A-Za-z0-9_\-=%.]{40,}/|[?&](?:key|token|apikey|api_key|password|pass|username|user)=', re.I)


def private_setting(key):
    return bool(_PRIVATE.search(key)) and key not in _NOT_PRIVATE


def _signed(link):
    """A link that carries a key, a sign-in or an add-on's own configuration inside."""
    return bool(_SIGNED_LINK.search(str(link or '')))


def _without_private(name, value):
    """A profile JSON file as it may be handed on, or None when all of it is private."""
    base = name.rsplit('/', 1)[-1]
    if base in PRIVATE_FILES or any(fnmatch.fnmatch(base, pattern) for pattern in PRIVATE_PATTERNS):
        return None
    if base == 'providers.json' and isinstance(value, list):
        # the add-ons whose link carries the user's own set-up (a debrid key...) stay home
        return [row for row in value if not (isinstance(row, dict) and
                                             (_signed(row.get('manifest_url')) or _signed(row.get('base_url'))))]
    if base == 'settings.json' and isinstance(value, dict):              # a profile's own values
        return {key: item for key, item in value.items() if not private_setting(key)}
    return value


def _db_without_private(name, raw):
    """playback.db without stream links (they can hold debrid tokens) and the accounts'
    outboxes; the other databases as they are."""
    if name != 'playback.db':
        return raw
    fd, tmp = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    try:
        Path(tmp).write_bytes(raw)
        conn = sqlite3.connect(tmp)
        try:
            tables = set(row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'"))
            if 'playback' in tables:
                conn.execute("UPDATE playback SET stream_url=''")
            for table in ('nuvio_progress_outbox', 'meganexus_simkl_outbox'):
                if table in tables:
                    conn.execute('DELETE FROM %s' % table)
            if 'meganexus_continue' in tables:
                for identity, payload in conn.execute('SELECT identity, payload FROM meganexus_continue').fetchall():
                    try:
                        row = json.loads(payload)
                    except ValueError:
                        continue
                    for key in ('stream_url', 'request_headers', 'stream_headers'):
                        row.pop(key, None)
                    conn.execute('UPDATE meganexus_continue SET payload=? WHERE identity=?', (json.dumps(row), identity))
            conn.commit()
            conn.execute('VACUUM')
        finally:
            conn.close()
        return Path(tmp).read_bytes()
    finally:
        os.unlink(tmp)
SKIN_ID = 'skin.meganexus'
SKIN_PREFIX = 'meganexus.'


# 9.0.0: a Trakt sign-in can not be shared: its refresh token works once (Trakt, 2026), so the
# device that renewed it second was signed out - a backup brought one device's sign-in to the
# other. It comes back only on the device it was made on.
# 9.1.1: MyAnimeList's too - it renews its sign-in with a refresh token the same way
ONE_DEVICE_FILES = ('trakt_token.json', 'mal_token.json')
DEVICE_MARK = 'device_mark.txt'


def device_mark(profile=None):
    """This device, the same after MegaNexus is installed again: a digest of its network
    card's address (never the address itself); where Python gets none, a random one kept here."""
    import hashlib
    import uuid
    node = uuid.getnode()
    if not (node >> 40) & 1:            # uuid makes one up (multicast bit set) when it finds none
        return hashlib.sha256(('meganexus-device|%012x' % node).encode('ascii')).hexdigest()[:16]
    path = Path(profile or _profile()) / DEVICE_MARK
    try:
        return path.read_text(encoding='utf-8').strip() or ''
    except OSError:
        mark = uuid.uuid4().hex[:16]
        try:
            path.write_text(mark, encoding='utf-8')
        except OSError:
            pass
        return mark


def _profile():
    import xbmcaddon
    import xbmcvfs
    return Path(xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile')))


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon(ADDON_ID)


def setting_ids():
    """Every setting MegaNexus Hub defines (from its settings.xml)."""
    import xbmcaddon
    import xbmcvfs
    path = Path(xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('path'))) / 'resources' / 'settings.xml'
    return [node.get('id') for node in ET.parse(str(path)).getroot().iter('setting') if node.get('id')]


def _portable(key, value, profile=None):
    """Local file paths (a custom screensaver video) do not travel - 7.0.47: unless the
    file is in MegaNexus' own folder, which travels with the backup (FOLDERS)."""
    if key in ('meganexus_screensaver_video', 'meganexus_screensaver_art') and value:
        return value.startswith('special://home/addons/') or bool(profile and _inside(value, profile))
    return True


def _inside(value, profile):
    root = str(profile).rstrip('/\\')
    return isinstance(value, str) and (value == root or value.startswith(root + '/') or value.startswith(root + '\\'))


def _moved(value, old_root, new_root):
    """A path inside the old device's MegaNexus folder, in this device's folder."""
    if old_root and isinstance(value, str) and _inside(value, old_root):
        rest = value[len(str(old_root).rstrip('/\\')):].replace('\\', '/')
        return str(new_root).rstrip('/\\') + rest
    return value


def _folder_files(profile):
    """(relative path, Path) of every file in FOLDERS, small enough and not a temporary one."""
    for top in FOLDERS:
        base = profile / top
        if not base.is_dir():
            continue
        for path in sorted(base.rglob('*')):
            if not path.is_file() or any(fnmatch.fnmatch(path.name, p) for p in FOLDER_SKIP):
                continue
            try:
                if path.stat().st_size > FOLDER_FILE_MAX:
                    continue
            except OSError:
                continue
            yield path.relative_to(profile).as_posix(), path


def _safe_relative(name):
    """Only a path inside FOLDERS, never one that leaves them."""
    parts = str(name or '').replace('\\', '/').split('/')
    return (len(parts) > 1 and parts[0] in FOLDERS and all(part not in ('', '.', '..') for part in parts)
            and ':' not in name and not name.startswith('/'))


def _skin_settings_path():
    import xbmcvfs
    return Path(xbmcvfs.translatePath('special://profile/addon_data/%s/settings.xml' % SKIN_ID))


def skin_export(path=None):
    """The skin's own MegaNexus choices: {id: [type, value]}."""
    try:
        root = ET.parse(str(path or _skin_settings_path())).getroot()
    except (OSError, ET.ParseError):
        return {}
    found = {}
    for node in root.iter('setting'):
        key = node.get('id') or ''
        if key.startswith(SKIN_PREFIX) and node.get('type') in ('bool', 'string'):
            found[key] = [node.get('type'), node.text or '']
    return found


def skin_import(values, old_root='', new_root='', run=None):
    """Apply them through Kodi's skin builtins (the skin keeps its own file)."""
    if run is None:
        import xbmc
        run = xbmc.executebuiltin
    count = 0
    for key, pair in (values or {}).items():
        if not (isinstance(key, str) and key.startswith(SKIN_PREFIX) and isinstance(pair, list) and len(pair) == 2):
            continue
        kind, value = pair
        if any(c in key for c in ',()[]'):
            continue
        if kind == 'bool':
            run('Skin.SetBool(%s)' % key if value == 'true' else 'Skin.Reset(%s)' % key)
        elif kind == 'string':
            value = _moved(str(value or ''), old_root, new_root)
            run('Skin.SetString(%s,%s)' % (key, value.replace('"', '')) if value else 'Skin.Reset(%s)' % key)
        else:
            continue
        count += 1
    return count


def _db_bytes(path):
    """A consistent copy of a live SQLite database (committed WAL rows too)."""
    fd, tmp = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    try:
        src = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
        try:
            dst = sqlite3.connect(tmp)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        return Path(tmp).read_bytes()
    finally:
        os.unlink(tmp)


def export_data(addon=None, profile=None, ids=None, private=True):
    """Everything of MegaNexus; ``private`` False (8.1.5): without keys, passwords, user
    names and sign-ins (see private_setting / _without_private)."""
    addon = addon or _addon()
    profile = Path(profile or _profile())
    ids = ids if ids is not None else setting_ids()
    settings = {}
    for key in ids:
        if key in DEVICE_SETTINGS or (not private and private_setting(key)):
            continue
        value = addon.getSetting(key)
        if value != '' and _portable(key, value, profile):
            settings[key] = value
    files = {}
    names = list(FILES) + sorted({p.name for pattern in FILE_PATTERNS for p in profile.glob(pattern)})
    for name in names:
        path = profile / name
        if path.is_file():
            try:
                value = json.loads(path.read_text(encoding='utf-8-sig'))
            except (OSError, ValueError):
                continue
            value = value if private else _without_private(name, value)
            if value is not None:
                files[name] = value
    databases = {}
    for name in DATABASES:
        path = profile / name
        if path.is_file():
            try:
                raw = _db_bytes(path)
                databases[name] = base64.b64encode(raw if private else _db_without_private(name, raw)).decode('ascii')
            except (OSError, sqlite3.Error):
                continue
    folders = {}
    for name, path in _folder_files(profile):
        try:
            raw = path.read_bytes()
            if not private and name.endswith('.json'):
                value = _without_private(name, json.loads(raw.decode('utf-8-sig')))
                if value is None:
                    continue
                raw = json.dumps(value, ensure_ascii=False).encode('utf-8')
        except (OSError, ValueError):
            continue
        folders[name] = base64.b64encode(raw).decode('ascii')
    try:
        skin = skin_export()
    except Exception:
        skin = {}
    try:
        version = addon.getAddonInfo('version') or ''
    except Exception:
        version = ''
    return {'format': FORMAT, 'version': VERSION, 'app_version': version,
            'created': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'profile_root': str(profile), 'settings': settings, 'files': files, 'databases': databases,
            'folders': folders, 'skin': skin, 'private': bool(private), 'device': device_mark(profile)}


def export_text(**kwargs):
    return json.dumps(export_data(**kwargs), ensure_ascii=False, indent=1)


def filename(private=True):
    return 'MegaNexus-backup-%s%s.json' % (time.strftime('%Y-%m-%d'), '' if private else '-no-sign-ins')


def _validate(data):
    if not isinstance(data, dict) or data.get('format') != FORMAT:
        raise ValueError('This is not a MegaNexus backup file.')
    if int(data.get('version') or 0) > VERSION:
        raise ValueError('This backup comes from a newer MegaNexus. Update MegaNexus first.')
    for key in ('settings', 'files', 'databases', 'folders', 'skin'):
        if not isinstance(data.get(key, {}), dict):
            raise ValueError('The backup file is damaged.')


def _restore_db(path, raw):
    """Copy into the live database through SQLite (safe while it is open)."""
    fd, tmp = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    try:
        Path(tmp).write_bytes(raw)
        src = sqlite3.connect(tmp)
        try:
            src.execute('PRAGMA integrity_check').fetchone()
            dst = sqlite3.connect(str(path), timeout=10)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
    finally:
        os.unlink(tmp)


def import_data(data, addon=None, profile=None, ids=None):
    """Apply a backup; returns {'settings', 'files', 'databases'} counts."""
    _validate(data)
    addon = addon or _addon()
    profile = Path(profile or _profile())
    profile.mkdir(parents=True, exist_ok=True)
    known = set(ids if ids is not None else setting_ids())
    old_root = str(data.get('profile_root') or '')
    report = {'settings': 0, 'files': 0, 'databases': 0, 'folders': 0, 'skin': 0}
    left_out = []                                          # Trakt's sign-in, made on another device
    elsewhere = data.get('device') != device_mark(profile)   # made on another device (or before 9.0.0)
    # 7.0.47: the folders first (pictures), so settings that point at them find them
    for name, value in (data.get('folders') or {}).items():
        if not _safe_relative(name) or not isinstance(value, str):
            continue
        if elsewhere and name.rsplit('/', 1)[-1] in ONE_DEVICE_FILES:
            left_out.append(name)
            continue
        target = profile.joinpath(*name.split('/'))
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_name(target.name + '.restoring')
            tmp.write_bytes(base64.b64decode(value))
            os.replace(tmp, target)
            report['folders'] += 1
        except (ValueError, OSError):
            continue
    for key, value in (data.get('settings') or {}).items():
        if key in known and key not in DEVICE_SETTINGS and isinstance(value, str):
            addon.setSetting(key, _moved(value, old_root, profile))
            report['settings'] += 1
    for name, value in (data.get('files') or {}).items():
        if name not in FILES and not any(fnmatch.fnmatch(name, p) for p in FILE_PATTERNS) or '/' in name or '\\' in name:
            continue   # only the files MegaNexus knows, never a path from the file
        if elsewhere and name in ONE_DEVICE_FILES:
            left_out.append(name)
            continue
        target = profile / name
        if name == 'providers.json' and data.get('private') is False and isinstance(value, list):
            # 8.1.5: a backup without sign-ins left this device's own set-up add-ons out - they stay
            try:
                here = json.loads(target.read_text(encoding='utf-8-sig')) if target.is_file() else []
            except (OSError, ValueError):
                here = []
            brought = set(str(row.get('manifest_url') or '') for row in value if isinstance(row, dict))
            value = value + [row for row in here if isinstance(row, dict) and str(row.get('manifest_url') or '') not in brought]
        tmp = target.with_name(name + '.restoring')
        tmp.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        os.replace(tmp, target)
        report['files'] += 1
    for name, value in (data.get('databases') or {}).items():
        if name not in DATABASES:
            continue
        try:
            _restore_db(profile / name, base64.b64decode(value))
            report['databases'] += 1
        except (ValueError, sqlite3.Error, OSError):
            continue
    try:
        report['skin'] = skin_import(data.get('skin') or {}, old_root, profile)
    except Exception:
        pass
    try:
        from . import settings_snapshot
        settings_snapshot.invalidate()
        import xbmcgui
        xbmcgui.Window(10000).setProperty('meganexus.progress.revision', 'restore-%s' % time.time())
        if left_out:
            xbmcgui.Dialog().notification('MegaNexus', 'Trakt: sign in on this device · Settings › Accounts & tracking',
                                          xbmcgui.NOTIFICATION_INFO, 8000)
    except Exception:
        pass
    return report


def import_text(text, **kwargs):
    if len(text.encode('utf-8')) > MAX_BYTES:
        raise ValueError('The backup file is too large.')
    try:
        data = json.loads(text)
    except ValueError:
        raise ValueError('This is not a MegaNexus backup file.')
    return import_data(data, **kwargs)
