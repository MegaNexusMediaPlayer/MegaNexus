# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Home's Top 10 rows (9.1.1): ten titles of one list of one source, each poster with its rank beside it
("brojevi veliki ... dio mu ide iza postera", "u veličini postera"; review/make_home_rank.py draws it).

They are tracking_rows' rows - switched on right under Continue Watching, then switched off, hidden or moved like
every other Home row ("da se može iz postavki ugasiti i sakriti i pomaknuti kao sve ostalo"). Any number of them:
"želim da imamo top 10 akcija, top 10 horor, top 10 svega ... i iz više servisa" - a row is a LIST (trending today,
popular, most watched this week, most anticipated, a genre) of a KIND (movies, series) from a SOURCE ("odakle ćemo
izvlačiti trending iz trakta, tmdb, simkl, mdblist" - its "Rows from"). The first two, trending movies and series,
are there from the start, off.

What each source really offers (each checked against the service, 2026-11-06):
* TMDB (the user's TMDb key): /trending/{movie|tv}/day, /{movie|tv}/popular, /discover with with_genres and
  sort_by=popularity.desc (TV has no Horror, Thriller or Romance genre at TMDB).
* Trakt (public, MegaNexus' client id, trakt_api's request path and its 429 rules): /{movies|shows}/trending,
  /popular, /watched/weekly, /anticipated; a genre is trending with ?genres=.
* Simkl (public, MegaNexus' client id): /{movies|tv}/trending/today; popular and the genres (/movies/genres/...
  /popular-this-week) for films only - its series there carry only Simkl's own id, nothing a title page can open.
* MDBList (the user's MDBList key): its official lists /lists/official/{trending|popular|most-watched-week|
  anticipated}/items - no genres.

The ranks are the source's own order. A title goes by its IMDb id when known (the stream add-ons are asked by it),
else by its TMDB id. Asked every FRESH seconds behind Home (tracking_rows.behind), never while Home is drawn.

With the TMDb key each title's details come in one request (append_to_response): its logo, other ids and its
translations - TMDB gives a title it has no Croatian name for in its own script (Japanese, Korean, Thai, Hindi)
and no story at all, and Kodi's font draws no Thai or Devanagari: then the English title and story ("kockice").
Each card's number takes a dark, rich tint of its poster's leading colour (rank_tint, from a small poster)."""
import colorsys
import json
import os
import threading
import urllib.parse
import urllib.request

TOP = 10
FRESH = 3 * 3600          # s a list stands before it is asked again
DETAILS_TIMEOUT = 6       # s one title's details may take
PICTURE_TIMEOUT = 6       # s one small poster may take (its colour)
PICTURE_MOST = 400 * 1024
BACKDROP = 'https://image.tmdb.org/t/p/original'
SMALL = 'https://image.tmdb.org/t/p/w92'
METAHUB = 'https://images.metahub.space/poster/%s/%s/img'
TINTS = 'top10_tints.json'                 # per profile: poster address -> its number's tint ('' none)
TINTS_KEPT = 400
KINDS = (('movie', 'movies'), ('series', 'series'))
SOURCES = ('tmdb', 'trakt', 'simkl', 'mdblist')
NAMES = {'tmdb': 'TMDB', 'trakt': 'Trakt', 'simkl': 'Simkl', 'mdblist': 'MDBList'}
# list -> its words in a row's title (kind: movies / series)
LISTS = (('trending', 'Trending today'), ('popular', 'Popular'), ('watched', 'Most watched this week'),
         ('anticipated', 'Most anticipated'))
# genre -> (its name, TMDB film genre, TMDB series genre, Trakt slug, Simkl film slug); None: not there
GENRES = (('action', 'Action', 28, 10759, 'action', 'action'), ('adventure', 'Adventure', 12, 10759, 'adventure', 'adventure'),
          ('animation', 'Animation', 16, 16, 'animation', 'animation'), ('anime', 'Anime', None, None, 'anime', None),
          ('comedy', 'Comedy', 35, 35, 'comedy', 'comedy'), ('crime', 'Crime', 80, 80, 'crime', 'crime'),
          ('documentary', 'Documentary', 99, 99, 'documentary', 'documentary'), ('drama', 'Drama', 18, 18, 'drama', 'drama'),
          ('family', 'Family', 10751, 10751, 'family', 'family'), ('fantasy', 'Fantasy', 14, 10765, 'fantasy', 'fantasy'),
          ('horror', 'Horror', 27, None, 'horror', 'horror'), ('mystery', 'Mystery', 9648, 9648, 'mystery', 'mystery'),
          ('romance', 'Romance', 10749, None, 'romance', 'romance'), ('scifi', 'Sci-Fi', 878, 10765, 'science-fiction', 'science-fiction'),
          ('thriller', 'Thriller', 53, None, 'thriller', 'thriller'), ('war', 'War', 10752, 10768, 'war', 'war'),
          ('western', 'Western', 37, 37, 'western', 'western'))
GENRE = dict((row[0], row) for row in GENRES)
TRAKT = {'trending': 'trending', 'popular': 'popular', 'watched': 'watched/weekly', 'anticipated': 'anticipated'}
MDBLIST = {'trending': 'trending', 'popular': 'popular', 'watched': 'most-watched-week', 'anticipated': 'anticipated'}
MDBLIST_READ = 100        # an official list's items read at once (films and series together) to find ten of a kind
_TINT_LOCK = threading.Lock()
# Kodi's own font (DejaVu Sans, skin.meganexus/xml/Font.xml) draws these - Latin, Greek, Cyrillic, Armenian, Hebrew,
# Arabic, Georgian and the marks and signs around them; not Thai, the Indian scripts, nor (not on every Kodi) the
# Chinese, Japanese and Korean ones
DRAWN = ((0x0000, 0x058F), (0x0590, 0x06FF), (0x10A0, 0x10FF), (0x1E00, 0x1FFF), (0x2000, 0x2BFF), (0xFB00, 0xFB4F),
         (0xFE70, 0xFEFF))


def ready():
    """The TMDb key is set (no network)."""
    try:
        from . import tmdb_api
        return bool(tmdb_api.api_key())
    except Exception:
        return False


def _mdblist_ready():
    try:
        from . import mdblist_api
        return bool(mdblist_api.configured())
    except Exception:
        return False


def _genre(list_key):
    return GENRE.get(list_key[6:]) if str(list_key).startswith('genre:') else None


def lists():
    """[(key, name)] every list a row can be: the four of LISTS, then a genre each."""
    return list(LISTS) + [('genre:' + row[0], row[1]) for row in GENRES]


def offers(source, list_key, kind):
    """The source has this list of this kind."""
    genre = _genre(list_key)
    if source == 'tmdb':
        if genre:
            return bool(genre[2] if kind == 'movie' else genre[3])
        return list_key in ('trending', 'popular')
    if source == 'trakt':
        return bool(genre[4]) if genre else list_key in TRAKT
    if source == 'simkl':
        if genre:
            return kind == 'movie' and bool(genre[5])
        return list_key == 'trending' or (list_key == 'popular' and kind == 'movie')
    if source == 'mdblist':
        return not genre and list_key in MDBLIST
    return False


def usable(source):
    """It can be asked now: TMDB and MDBList with the user's key, Trakt and Simkl always (MegaNexus' app)."""
    if source == 'tmdb':
        return ready()
    if source == 'mdblist':
        return _mdblist_ready()
    return source in SOURCES


def sources_for(list_key, kind):
    """The sources that can fill a row of this list and kind now, in SOURCES order."""
    return [source for source in SOURCES if offers(source, list_key, kind) and usable(source)]


def automatic(list_key, kind):
    """The source of "Automatic": TMDB with the key, else the first other one that has the list ('' none)."""
    found = sources_for(list_key, kind)
    return found[0] if found else ''


def title(list_key, kind, source=''):
    """'Top 10 movies today', 'Top 10 Action series', 'Top 10 popular movies' - and ' · Trakt' when named."""
    words = dict(KINDS)[kind]
    genre = _genre(list_key)
    if genre:
        text = 'Top 10 %s %s' % (genre[1], words)
    elif list_key == 'trending':
        text = 'Top 10 %s today' % words
    else:
        text = 'Top 10 %s %s' % (dict(LISTS).get(list_key, list_key).lower(), words)
    return text + (' · ' + NAMES[source] if source in NAMES else '')


# ---- what a title is called and told ---------------------------------------------------------------------

def drawable(text):
    """Every letter of ``text`` is one Kodi's font draws (DRAWN)."""
    return all(any(low <= ord(ch) <= high for low, high in DRAWN) for ch in str(text or ''))


def _english(details, field):
    """The English translation's ``field`` (title / name / overview) of TMDB's details: the US one first."""
    rows = [row for row in ((details.get('translations') or {}).get('translations') or []) if row.get('iso_639_1') == 'en']
    rows.sort(key=lambda row: row.get('iso_3166_1') != 'US')
    return next((str((row.get('data') or {}).get(field) or '').strip() for row in rows
                 if str((row.get('data') or {}).get(field) or '').strip()), '')


def named(title, plot, details, kind):
    """(title, plot) to show: the catalogs' own while Kodi can draw them and a story is there; else the English
    ones (a title in a script Kodi has no letters for; an empty story)."""
    field = 'name' if kind == 'tv' else 'title'
    if not drawable(title):
        english = _english(details, field)
        original = str(details.get('original_name' if kind == 'tv' else 'original_title') or '').strip()
        title = english or (original if drawable(original) else title)
    if not str(plot or '').strip():
        plot = _english(details, 'overview')
    return title, str(plot or '').strip()


# ---- the number's tint ---------------------------------------------------------------------------------

def tint(rgb):
    """'D9RRGGBB' - a dark, rich version of a colour (the number's fill): lightness at most 0.42, at least 0.18,
    saturation at least 0.55; '' without one."""
    if not rgb:
        return ''
    hue, light, sat = colorsys.rgb_to_hls(*(max(0, min(255, int(v))) / 255.0 for v in rgb[:3]))
    red, green, blue = colorsys.hls_to_rgb(hue, max(0.18, min(light, 0.42)), max(sat, 0.55))
    return 'D9%02X%02X%02X' % tuple(int(round(v * 255)) for v in (red, green, blue))


def _tints_path():
    from .meganexus.paths import profile_path
    return os.path.join(profile_path(), TINTS)


def _read_tints():
    try:
        with open(_tints_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _download(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'MegaNexus/9 (Kodi)'})
    with urllib.request.urlopen(request, timeout=PICTURE_TIMEOUT) as answer:
        return answer.read(PICTURE_MOST + 1)


def tints(addresses, stopped=None):
    """{small poster address: tint} - each asked once (kept in TINTS, the last TINTS_KEPT), behind Home."""
    stopped = stopped or (lambda: False)
    from . import wallpaper_colors
    with _TINT_LOCK:
        kept = _read_tints()
    found, new = {}, False
    for url in [u for u in addresses if u]:
        if url in kept:
            found[url] = kept[url]
            continue
        if stopped():
            break
        try:
            data = _download(url)
            colour = wallpaper_colors.sample(data) if len(data) <= PICTURE_MOST else None
        except Exception:
            continue                                   # not asked now: tried again with the next list
        found[url] = kept[url] = tint(colour)
        new = True
    if new:
        with _TINT_LOCK:
            from .meganexus.json_files import write_json
            merged = dict(list(_read_tints().items()) + list(kept.items()))
            try:
                write_json(_tints_path(), dict(list(merged.items())[-TINTS_KEPT:]))
            except Exception:
                pass
    return found


# ---- the sources ------------------------------------------------------------------------------------

def _language():
    try:
        from .default_setup import chosen
        return chosen()['language']
    except Exception:
        return 'en-US'


def _details(kind, tmdb_id, language):
    """The title's details with its logos, other ids and translations - one request (append_to_response)."""
    from . import tmdb_api
    try:
        return tmdb_api.get('/%s/%s' % (kind, tmdb_id), {
            'language': language, 'append_to_response': 'images,external_ids,translations',
            'include_image_language': '%s,en,null' % language.split('-')[0]}, timeout=DETAILS_TIMEOUT) or {}
    except Exception:
        return {}


def _logo(details, language):
    """Its title logo: in the catalogs' language, else English, else the best liked."""
    from . import tmdb_api
    own = language.split('-')[0]
    logos = [row for row in (details.get('images') or {}).get('logos') or [] if row.get('file_path')]
    logos.sort(key=lambda row: (row.get('iso_639_1') != own, row.get('iso_639_1') != 'en', -(row.get('vote_average') or 0)))
    return tmdb_api.picture(logos[0]['file_path'], 'logo') if logos else ''


def _imdb(value):
    value = str(value or '').strip()
    return value if value.startswith('tt') else ''


def _row(**fields):
    return dict({'rank': 0, 'tmdb_id': '', 'imdb_id': '', 'title': '', 'year': '', 'plot': '', 'poster': '', 'small': '',
                 'background': '', 'clearlogo': '', 'meta_line': '', 'rank_tint': ''}, **fields)


def _tmdb(list_key, kind, stopped):
    """TMDB: trending of the day, popular, or a genre by popularity - with each title's details."""
    from . import tmdb_api
    from .hub_spotlight import meta_line
    tv = 'tv' if kind == 'series' else 'movie'
    language = _language()
    genre = _genre(list_key)
    if genre:
        path, params = '/discover/%s' % tv, {'with_genres': genre[2] if tv == 'movie' else genre[3], 'sort_by': 'popularity.desc'}
    elif list_key == 'popular':
        path, params = '/%s/popular' % tv, {}
    else:
        path, params = '/trending/%s/day' % tv, {}
    try:
        answer = tmdb_api.get(path, dict(params, language=language)) or {}
    except Exception:
        return None
    found = []
    for item in answer.get('results') or []:
        if stopped():
            return None
        if not item.get('id') or not item.get('poster_path'):
            continue
        details = _details(tv, item['id'], language)
        name, plot = named(item.get('title') or item.get('name') or '', details.get('overview') or item.get('overview') or '',
                           details, tv)
        found.append(_row(tmdb_id=str(item['id']), imdb_id=_imdb((details.get('external_ids') or {}).get('imdb_id') or details.get('imdb_id')),
                          title=name, year=str(item.get('release_date') or item.get('first_air_date') or '')[:4], plot=plot,
                          poster=tmdb_api.picture(item['poster_path'], 'poster'), small=SMALL + item['poster_path'],
                          background=BACKDROP + item['backdrop_path'] if item.get('backdrop_path') else '',
                          clearlogo=_logo(details, language), meta_line=meta_line(tv, item, details)))
        if len(found) >= TOP:
            break
    return found


def _enriched(row, kind, stopped):
    """A title of another source with TMDB's story, logo and backdrop in the catalogs' language, when the key is set
    and its TMDB id known (one request); as it came otherwise."""
    if not (ready() and row.get('tmdb_id')) or stopped():
        return row
    from .hub_spotlight import meta_line
    tv = 'tv' if kind == 'series' else 'movie'
    language = _language()
    details = _details(tv, row['tmdb_id'], language)
    if not details:
        return row
    local = details.get('name' if tv == 'tv' else 'title') or ''
    name, plot = named(local or row['title'], details.get('overview') or '', details, tv)
    return dict(row, title=name if local else row['title'], plot=plot or row['plot'], clearlogo=_logo(details, language) or row['clearlogo'],
                background=(BACKDROP + details['backdrop_path']) if details.get('backdrop_path') else row['background'],
                meta_line=meta_line(tv, details, details),
                imdb_id=row['imdb_id'] or _imdb((details.get('external_ids') or {}).get('imdb_id')))


def _metahub(imdb, size):
    return METAHUB % (size, imdb) if imdb else ''


def _trakt(list_key, kind, stopped):
    """Trakt (public): trending, popular, most watched this week, anticipated; a genre trending."""
    from . import trakt_api
    word = 'shows' if kind == 'series' else 'movies'
    genre = _genre(list_key)
    path = '/%s/%s?%s' % (word, 'trending' if genre else TRAKT[list_key],
                          urllib.parse.urlencode(dict({'limit': TOP * 2, 'extended': 'full,images'},
                                                      **({'genres': genre[4]} if genre else {}))))
    try:
        answer = trakt_api._request(path, auth=False, timeout=15) or []
    except Exception:
        return None
    found = []
    for item in answer if isinstance(answer, list) else []:
        node = item.get('show' if kind == 'series' else 'movie') or (item if 'ids' in item else {})
        ids = node.get('ids') or {}
        imdb, tmdb = _imdb(ids.get('imdb')), str(ids.get('tmdb') or '')
        if not (imdb or tmdb):
            continue
        images = node.get('images') or {}
        picture = lambda name: ('https://' + images[name][0]) if images.get(name) else ''
        found.append(_enriched(_row(tmdb_id=tmdb, imdb_id=imdb, title=str(node.get('title') or ''), year=str(node.get('year') or ''),
                                    plot=str(node.get('overview') or ''), poster=picture('poster') or _metahub(imdb, 'medium'),
                                    small=_metahub(imdb, 'small'), background=picture('fanart'), clearlogo=picture('logo')),
                               kind, stopped))
        if len(found) >= TOP or stopped():
            break
    return None if stopped() else found


def _simkl(list_key, kind, stopped):
    """Simkl (public): trending today; for films also popular this week and a genre."""
    from . import simkl_api
    genre = _genre(list_key)
    if genre or list_key == 'popular':
        path = '/movies/genres/%s/all-types/all-countries/all-years/popular-this-week?limit=%d' % (genre[5] if genre else 'all', TOP * 2)
    else:
        path = '/%s/trending/today?extended=title,slug,overview,metadata,tmdb' % ('tv' if kind == 'series' else 'movies')
    try:
        answer = simkl_api._request(path, timeout=15) or []
    except Exception:
        return None
    found = []
    for item in answer if isinstance(answer, list) else []:
        ids = item.get('ids') or {}
        imdb, tmdb = _imdb(ids.get('imdb')), str(ids.get('tmdb') or '')
        if not (imdb or tmdb):
            continue
        found.append(_enriched(_row(tmdb_id=tmdb, imdb_id=imdb, title=str(item.get('title') or ''),
                                    year=str(item.get('year') or item.get('release_date') or '')[-4:], plot=str(item.get('overview') or ''),
                                    poster=simkl_api.poster_url(item.get('poster')) or _metahub(imdb, 'medium'),
                                    small=_metahub(imdb, 'small') or simkl_api.poster_url(item.get('poster'))),
                               kind, stopped))
        if len(found) >= TOP or stopped():
            break
    return None if stopped() else found


def _mdblist(list_key, kind, stopped):
    """MDBList: an official list (trending, popular, most watched this week, anticipated) - in its own rank order."""
    from . import mdblist_api
    try:
        data, _more = mdblist_api._request('/lists/official/%s/items' % MDBLIST[list_key], params={'limit': MDBLIST_READ})
    except Exception:
        return None
    rows = (data or {}).get('shows' if kind == 'series' else 'movies') or [] if isinstance(data, dict) else []
    found = []
    for item in sorted((r for r in rows if isinstance(r, dict)), key=lambda r: int(r.get('rank') or 0)):
        ids = item.get('ids') or {}
        imdb, tmdb = _imdb(item.get('imdb_id') or ids.get('imdb')), str(ids.get('tmdb') or item.get('tmdb_id') or '')
        if not (imdb or tmdb):
            continue
        found.append(_enriched(_row(tmdb_id=tmdb, imdb_id=imdb, title=str(item.get('title') or ''), year=str(item.get('release_year') or ''),
                                    poster=_metahub(imdb, 'medium'), small=_metahub(imdb, 'small')), kind, stopped))
        if len(found) >= TOP or stopped():
            break
    return None if stopped() else found


FETCH = {'tmdb': _tmdb, 'trakt': _trakt, 'simkl': _simkl, 'mdblist': _mdblist}


def fetch(source, list_key, kind, stopped=None):
    """The list's ten as kept answers ([dict], ranked 1-10, each with its number's tint) - network: never on the
    drawing thread. None when the source did not answer (or cannot be asked now)."""
    stopped = stopped or (lambda: False)
    if source not in FETCH or not usable(source) or not offers(source, list_key, kind):
        return None
    found = FETCH[source](list_key, kind, stopped)
    if found is None or stopped():
        return None
    found = found[:TOP]
    colours = tints([row.get('small') for row in found], stopped)
    return [dict(row, rank=index + 1, rank_tint=colours.get(row.get('small'), '')) for index, row in enumerate(found)]


def card(media, raw):
    """A Home card of one kept answer (``media``: movie / series) - opens the title's page as any Home card;
    ``rank``: the number beside it, ``rank_tint``: its colour."""
    cid = raw.get('imdb_id') or 'tmdb:%s' % raw.get('tmdb_id')
    target = {'media_type': media, 'canonical_id': cid, 'title': raw.get('title') or cid, 'tmdb_id': raw.get('tmdb_id') or ''}
    if raw.get('imdb_id'):
        target['imdb_id'] = raw['imdb_id']
    return {'title': raw.get('title') or cid, 'subtitle': raw.get('year') or '', 'poster': raw.get('poster') or '',
            'fanart': raw.get('background') or '', 'landscape': raw.get('background') or '',
            'clearlogo': raw.get('clearlogo') or '', 'plot': raw.get('plot') or '', 'meta_line': raw.get('meta_line') or '',
            'target': target, 'is_folder': False, 'rank': int(raw.get('rank') or 0), 'rank_tint': raw.get('rank_tint') or ''}


def cards(media, rows):
    return [card(media, raw) for raw in rows or () if isinstance(raw, dict) and (raw.get('imdb_id') or raw.get('tmdb_id'))]
