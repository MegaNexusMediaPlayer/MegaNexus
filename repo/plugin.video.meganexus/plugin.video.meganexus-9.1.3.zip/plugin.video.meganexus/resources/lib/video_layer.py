# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""No black flash when a small video stops on Amlogic boxes (9.0.2).

CoreELEC / LibreELEC on Amlogic show video on a hardware layer under Kodi's interface.
When a video stops the kernel's video driver blacks that layer out (blackout_policy 1),
and on a Fire TV Cube the whole picture flashed each time a trailer, Sport or IPTV
preview stopped or switched. Measured there: with Kodi alone it flashed, with the policy
at 0 (keep the last frame) it did not.

Only for the small videos, though. Kept after a film, the last frame holds the box in
that film's colour processing: after a Dolby Vision episode every colour of the interface
was wrong. So the frame is kept while a small video plays (refresh_guard.suspend) and the
box's own value comes back before a film or an episode starts (release_all), once no small
video is left (sweep) and at every start of the service. PCs and Android have no such
file, or may not write it: nothing happens there.

9.1.1, GitHub #35, #37, #38 (black picture with sound after a seek or a resume, Ugoos AM6B
on CoreELEC "cpm" and "avdvplus" builds): not every box blacks out by itself. Their kernel
(cpm-code-2025/linux-amlogic) starts at 0 and their Kodi no longer keeps the frame during a
seek itself (CoreELEC's own Kodi sets 0 around every decoder reset, theirs counts on 0) - the
1 written here before every film and every 5 s blacked the picture out at each seek. So
nothing is ever forced: the box's own value is noted once per boot while nothing plays, the
frame is lent for a small video only where the box blacks out (1), and what was found is
given back - on those boxes nothing is written at all.
"""
import os

POLICY = '/sys/class/video/blackout_policy'
OWN = '/run/meganexus.blackout_policy'      # the box's own value: in RAM, gone with the driver's at a restart
LENT = OWN + '.lent'                        # there while a small video keeps the frame
STEADY = 2.0                                # s between the two reads that must agree before it is noted


def _read(path):
    try:
        with open(path) as handle:
            return handle.read().strip()
    except OSError:
        return None                  # not an Amlogic box


def _set(value, path):
    current = _read(path)
    if current is None:
        return False
    if current == value:
        return True
    try:
        with open(path, 'w') as handle:
            handle.write(value)
        return True
    except OSError:
        return False                 # not allowed here (Android)


def own():
    """The box's own value as noted this boot ('0' or '1'), None while it is not known."""
    value = _read(OWN)
    return value if value in ('0', '1') else None


def note_own(nothing_plays, pause, path=None):
    """The box's own value, noted once per boot: read while nothing plays, twice STEADY apart and the same both
    times (a Kodi closing a video writes 1 for that moment on cpm builds). ``pause(seconds)`` is True when Kodi
    stops meanwhile."""
    if own() is not None or not nothing_plays():
        return own()
    first = _read(path or POLICY)
    if first not in ('0', '1') or pause(STEADY) or not nothing_plays() or _read(path or POLICY) != first:
        return None
    try:
        with open(OWN, 'w') as handle:
            handle.write(first)
    except OSError:
        return None                  # nowhere to keep it: the frame is never lent
    return first


def keep_last_frame(path=None):
    """A small video is about to play: its stop keeps the frame (no flash) - where the box blacks out by itself."""
    if own() != '1':
        return False                 # not known yet, or the box keeps the frame itself
    try:
        with open(LENT, 'w'):
            pass
    except OSError:
        return False
    return _set('0', path or POLICY)


def give_back(path=None):
    """The box's own value again (films, episodes, nothing playing) - only when a small video had it."""
    if not keeping():
        return False
    value = own()
    done = _set(value, path or POLICY) if value else False
    try:
        os.remove(LENT)
    except OSError:
        pass
    return done


def keeping():
    return os.path.exists(LENT)
