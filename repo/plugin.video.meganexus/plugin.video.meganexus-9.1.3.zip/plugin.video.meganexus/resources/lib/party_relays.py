# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The Watch Party's Nostr relays (7.0.52): several public relays at once, no server of ours.

Each relay has a thread: it connects, sends our subscriptions again, reads, and on any
error waits longer each time (up to a minute) and connects again. An event is published
to every relay that is connected; one that arrives from several relays is handed on once.
Every event's signature is checked before anyone sees it. Relays that ask for a login
(NIP-42 AUTH - some serve gift wraps only to their recipient) get one, signed with our key.
Nothing of an event's content or of a relay's link goes into the log.

9.1.3 ("zasto se ne spaja na relay, dali se oni mijenjaju cesto, imamo li nacin automatskog pronalaska"): public
relays come and go - relay.damus.io answered our WebSocket with 503 and relay.primal.net with 502 while their info
pages answered (2026-11-09), offchain.pub timed out an hour before it answered again. So:
* the list starts from MegaNexus' own pages (LIST_URL - the same file as the built-in one, resources/party_relays.json,
  published with the Kodi repository and changed there as relays come and go, no release needed), kept a day;
* a relay whose information document (NIP-11) says it wants payment or takes writes from some people only is left out;
* a relay that refuses us (an HTTP answer instead of a WebSocket) is asked again ever more rarely, and its trouble is
  logged once until it answers again;
* a party's host tells its guests the relays it is on (the invite, the join code, the party key): they join them too,
  so the party meets whatever list each side started with.
"""
import json
import os
import re
import threading
import time
from collections import OrderedDict

from . import party_crypto as crypto
from .party_ws import WebSocket, Closed

# public relays (a party works while any one of them does). 7.0.61: two more - one relay refusing us (relay.damus.io
# banned a household's address for its rate) left too few for a party; both checked to pass party messages and keep
# gift wraps. 9.1.3: the list is a file (resources/party_relays.json), the one MegaNexus' pages publish (LIST_URL)
BUILT_IN = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'party_relays.json')
LIST_URL = 'https://meganexusmediaplayer.github.io/MegaNexus/relays.json'
LIST_FILE = 'party_relays.json'                     # the list read last, in the profile
LIST_LIFE = 24 * 3600                               # s it is kept before the pages are asked again
MOST = 12                                           # relays at most (a guest's and its host's together)
SHARED = 8                                          # the host's relays told to its guests
REFUSED = re.compile(r'rate|limit|banned|blocked|slow down|too many', re.I)
QUIET_FIRST, QUIET_MAX = 120.0, 1800.0             # s a relay that refused us for our rate gets nothing
RETRY_FIRST, RETRY_MAX = 2.0, 60.0
REFUSAL_FIRST, REFUSAL_MAX = 120.0, 1800.0         # s before a relay that refused the connection is asked again
READ_TIMEOUT = 30                                   # s without a message: a ping keeps NAT routers open
SEEN = 4000                                         # event ids remembered (the same event from several relays)


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] Watch Party: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def _host(url):
    return url.split('//', 1)[-1].split('/', 1)[0][:60]


_URL = re.compile(r'^wss://[a-z0-9.-]+(?::\d{1,5})?(?:/[a-z0-9._~/-]*)?$', re.I)


def clean(url):
    """A relay's address as it is used ('wss://host[/path]'); '' for anything else - an address from the pages or
    from another TV is never taken as it comes."""
    url = str(url or '').strip().rstrip('/')
    return url.lower() if len(url) <= 120 and _URL.match(url) else ''


def _listed(data):
    relays = data.get('relays') if isinstance(data, dict) else None
    found = [clean(url) for url in relays] if isinstance(relays, list) else []
    return list(dict.fromkeys(url for url in found if url))[:MOST]


def _built_in():
    try:
        with open(BUILT_IN, encoding='utf-8') as handle:
            return _listed(json.load(handle))
    except (OSError, ValueError):
        return []


DEFAULT_RELAYS = tuple(_built_in())


def usable(info):
    """False when a relay's information document (NIP-11) says it wants payment or takes writes from some people
    only - a party's messages would not get through; True when it says nothing of it."""
    limits = (info or {}).get('limitation') if isinstance(info, dict) else None
    limits = limits if isinstance(limits, dict) else {}
    return not (limits.get('payment_required') is True or limits.get('restricted_writes') is True)


def _information(url, timeout=4.0):
    """A relay's NIP-11 document (its https address, Accept: application/nostr+json); None when it gave none."""
    from urllib.request import Request, urlopen
    try:
        with urlopen(Request('https://' + url[len('wss://'):], headers={'Accept': 'application/nostr+json',
                                                                       'User-Agent': 'MegaNexus'}), timeout=timeout) as reply:
            return json.loads(reply.read(65536).decode('utf-8'))
    except Exception:
        return None


def _published(timeout=6.0):
    from urllib.request import Request, urlopen
    try:
        with urlopen(Request(LIST_URL, headers={'User-Agent': 'MegaNexus'}), timeout=timeout) as reply:
            return _listed(json.loads(reply.read(65536).decode('utf-8')))
    except Exception:
        return []


def relay_list(folder, published=_published, information=_information, clock=time.time):
    """The relays a Watch Party starts with: the list on MegaNexus' pages, else the built-in one - without those whose
    NIP-11 document rules us out; kept in ``folder`` a day (asked again only then). Never empty while the built-in
    list has any: a relay left out by its document is still better than none."""
    path = os.path.join(folder, LIST_FILE)
    try:
        with open(path, encoding='utf-8') as handle:
            kept = json.load(handle)
        if isinstance(kept, dict) and clock() - float(kept.get('at') or 0) < LIST_LIFE and _listed(kept):
            return _listed(kept)
    except (OSError, ValueError, TypeError):
        pass
    found = published() or list(DEFAULT_RELAYS)
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=max(1, min(8, len(found)))) as pool:
        documents = list(pool.map(information, found))
    chosen = [url for url, info in zip(found, documents) if usable(info)] or found
    try:
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump({'at': clock(), 'relays': chosen}, handle)
    except OSError:
        pass
    return chosen


class Relay(object):
    def __init__(self, url, pool):
        self.url, self.pool = url, pool
        self.ws = None
        self.lock = threading.Lock()
        self.connected = threading.Event()
        self.stopping = False
        self.quiet_until = 0.0              # 7.0.61: it refused us for our rate - nothing sent until then
        self.quiet_for = 0.0
        self.thread = threading.Thread(target=self._run, name='MegaNexusRelay', daemon=True)

    def start(self):
        self.thread.start()

    def send(self, message):
        with self.lock:
            ws = self.ws
            if ws is None or not self.connected.is_set():
                return False
            try:
                ws.send(json.dumps(message, separators=(',', ':'), ensure_ascii=False))
                return True
            except Exception:
                return False

    def _run(self):
        wait, failures = RETRY_FIRST, 0
        while not self.stopping:
            refused = False
            try:
                ws = WebSocket(self.url)
                ws.settimeout(READ_TIMEOUT)
                with self.lock:
                    self.ws = ws
                self.connected.set()
                wait = RETRY_FIRST
                if failures:
                    _log('%s reachable again' % _host(self.url))
                failures = 0
                for sub_id, filters in self.pool.subscriptions():
                    self.send(['REQ', sub_id] + filters)
                self.pool._relay_up(self)
                self._read(ws)
            except Exception as exc:
                # 9.1.3: an HTTP answer instead of a WebSocket ("refused (HTTP/1.1 503 ...)"): it is up and does not
                # want us now - asked again ever more rarely; any trouble is logged once until it answers again
                refused = str(exc).startswith('refused')
                failures += 1
                if not self.stopping and failures == 1:
                    self.pool._relay_down(self, str(exc)[:60] if refused else type(exc).__name__)
            finally:
                self.connected.clear()
                with self.lock:
                    ws, self.ws = self.ws, None
                if ws is not None:
                    ws.close()
            if refused:
                wait = min(REFUSAL_MAX, max(REFUSAL_FIRST, wait * 2))
            if self.stopping or self.pool.stopped.wait(wait):
                return
            if not refused:
                wait = min(RETRY_MAX, wait * 2)

    def _read(self, ws):
        import socket
        while not self.stopping:
            try:
                text = ws.receive()
            except socket.timeout:
                ws.ping()
                continue
            except Closed:
                return
            try:
                message = json.loads(text)
            except ValueError:
                continue
            if isinstance(message, list) and message:
                self.pool._message(self, message)

    def stop(self):
        self.stopping = True
        with self.lock:
            ws = self.ws
        if ws is not None:
            ws.wake()                       # the reading thread closes it (party_ws.wake)


class RelayPool(object):
    """``secret``: our key (32 bytes) - for relays that ask us to log in."""

    def __init__(self, relays=DEFAULT_RELAYS, secret=None):
        self.secret = secret
        self.stopped = threading.Event()
        self.lock = threading.Lock()
        self.subs = OrderedDict()           # id -> (filters, callback)
        self.seen = OrderedDict()           # (subscription, event id): from several relays, handed on once
        self.own = OrderedDict()            # our own events: never handed back to us
        self.waiting_ok = {}                # event id -> [Event, accepted relays]
        self.relays = [Relay(url, self) for url in dict.fromkeys(relays)]
        self.on_status = None
        self.started = False

    def start(self):
        self.started = True
        for relay in list(self.relays):
            relay.start()
        return self

    def add(self, urls):
        """9.1.3: relays a party's host is on (its invite, its join code, its key) - joined too, so the party meets
        whatever list each side started with; MOST in all. How many were new."""
        added = []
        with self.lock:
            known = set(relay.url for relay in self.relays)
            for url in urls if isinstance(urls, (list, tuple)) else ():
                url = clean(url)
                if url and url not in known and len(self.relays) < MOST and not self.stopped.is_set():
                    relay = Relay(url, self)
                    self.relays.append(relay)
                    known.add(url)
                    added.append(relay)
        if getattr(self, 'started', False):
            for relay in added:
                relay.start()
        return len(added)

    def shared(self):
        """The relays we are on now - what a host tells its guests (SHARED of them)."""
        return [relay.url for relay in list(self.relays) if relay.connected.is_set()][:SHARED]

    def stop(self):
        self.stopped.set()
        for relay in self.relays:
            relay.stop()

    def connected(self):
        return sum(1 for r in self.relays if r.connected.is_set())

    def wait_connected(self, timeout=10.0, count=1):
        until = time.monotonic() + timeout
        while self.connected() < count and time.monotonic() < until and not self.stopped.is_set():
            time.sleep(0.05)
        return self.connected() >= count

    def subscriptions(self):
        with self.lock:
            return [(sub_id, filters) for sub_id, (filters, _) in self.subs.items()]

    def subscribe(self, sub_id, filters, callback):
        """``callback(event, relay host)`` for every new verified event matching the filters."""
        with self.lock:
            self.subs[sub_id] = (list(filters), callback)
        for relay in self.relays:
            relay.send(['REQ', sub_id] + list(filters))

    def unsubscribe(self, sub_id):
        with self.lock:
            self.subs.pop(sub_id, None)
        for relay in self.relays:
            relay.send(['CLOSE', sub_id])

    def publish(self, event, wait=0.0):
        """Sent to every connected relay; with ``wait`` seconds, how many said OK."""
        waiter = [threading.Event(), set(), None]          # done, relays that said OK, how many were sent
        if wait:
            with self.lock:
                self.waiting_ok[event['id']] = waiter
        with self.lock:
            self.own[event['id']] = True
            while len(self.own) > SEEN:
                self.own.popitem(last=False)
        now = time.monotonic()
        sent = sum(1 for relay in self.relays if relay.quiet_until <= now and relay.send(['EVENT', event]))
        if not wait:
            return sent
        with self.lock:
            waiter[2] = sent
            if len(waiter[1]) >= sent:
                waiter[0].set()
        waiter[0].wait(wait)
        with self.lock:
            self.waiting_ok.pop(event['id'], None)
        return len(waiter[1])

    def _remember(self, key):
        with self.lock:
            if key in self.seen:
                return False
            self.seen[key] = True
            while len(self.seen) > SEEN:
                self.seen.popitem(last=False)
            return True

    def _message(self, relay, message):
        kind = message[0]
        if kind == 'EVENT' and len(message) >= 3 and isinstance(message[2], dict):
            event = message[2]
            key = (message[1], event.get('id'))
            with self.lock:
                entry = self.subs.get(message[1])
                if not entry or key in self.seen or event.get('id') in self.own:
                    return
            # 8.1.0: claimed before it is checked - the same event from six relays at once was
            # verified up to six times (pure Python, Kodi's Python lock held each time)
            if not self._remember(key) or not crypto.verify_event(event):
                return
            try:
                entry[1](event, _host(relay.url))
            except Exception as exc:
                _log('an event was not handled (%s)' % type(exc).__name__)
        elif kind == 'OK' and len(message) >= 3:
            with self.lock:
                waiter = self.waiting_ok.get(message[1])
            if message[2] is False and REFUSED.search(str(message[3] if len(message) > 3 else '')):
                # it refused us for our rate (or banned the address): it gets nothing for a while,
                # longer each time - sending on only made it worse
                relay.quiet_for = min(QUIET_MAX, (relay.quiet_for * 2) or QUIET_FIRST)
                if relay.quiet_until <= time.monotonic():
                    _log('%s refused us (%s) - nothing sent there for %d s'
                         % (_host(relay.url), str(message[3])[:60], relay.quiet_for))
                relay.quiet_until = time.monotonic() + relay.quiet_for
            elif message[2] is True:
                relay.quiet_for = 0.0
            if waiter is not None and message[2] is True:
                with self.lock:
                    waiter[1].add(relay.url)
                    if waiter[2] is not None and len(waiter[1]) >= waiter[2]:
                        waiter[0].set()
        elif kind == 'AUTH' and len(message) >= 2 and self.secret:
            event = crypto.sign_event(22242, '', [['relay', relay.url], ['challenge', str(message[1])]], self.secret)
            relay.send(['AUTH', event])
            for sub_id, filters in self.subscriptions():      # asked again, now logged in
                relay.send(['REQ', sub_id] + filters)

    def _relay_up(self, relay):
        if self.on_status:
            self.on_status(self.connected(), len(self.relays))

    def _relay_down(self, relay, reason):
        _log('%s not reachable (%s) - trying again' % (_host(relay.url), reason))
        if self.on_status:
            self.on_status(self.connected(), len(self.relays))
