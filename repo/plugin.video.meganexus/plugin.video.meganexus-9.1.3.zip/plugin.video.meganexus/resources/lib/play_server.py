# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""The phones' side of the Games app (games branch): a page served by this Kodi device and a WebSocket to it.

The user: "qr za povezivanje da vise ljudi moze da se poveze i igra neki lokalni multiplayer na jednom ekranu" and
"kako sa mobitela pokrenuti igre ako nema kontroler spojen". One QR for everyone (the Players screen): each phone
that opens it is the next player (1 to 8, its colour), and stays that player when it comes back. On the phone: the
games to start on the TV, the game's menu (Kodi's own: pause, save, load, reset, stop) and the pad of the game that
plays - Kodi tells the phone which game it is and what its controller has (game_pad), the phone draws that pad.

As phone_setup does it: plain HTTP inside the home network, every call with the session's key from the QR code
(compared in constant time); nothing is served without it but the page itself. It runs only while the Games app is
open ("pali se kad kliknemo na games i kad izajemo gasi se") - stop() closes every phone and its pad.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import socket
import struct
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

import xbmc

from . import game_pad

PORT = 8767                     # one fixed port (a firewall allows it once; 8765 is phone_setup's, 8766 art_cache's)
MOST = 8
GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
FRAME_MOST = 64 * 1024
COLOURS = ('#2F7BFF', '#FF4D5E', '#2ECC71', '#F5C518', '#A66BFF', '#FF8A2A', '#1EC8E0', '#FF5FB5')
PAGE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'play_phone', 'index.html')
ICON = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'media', 'meganexus_icon.png')   # home screen
GAMES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'games')
# the game's menu from the phone - Kodi's own actions and windows (RetroPlayer: input/actions, WindowTranslator)
MENU = {'menu': 'Action(OSD)', 'pause': 'PlayerControl(Play)', 'reset': 'PlayerControl(Reset)',
        'stop': 'PlayerControl(Stop)', 'saves': 'ActivateWindow(ingamesaves)',
        'up': 'Action(Up)', 'down': 'Action(Down)', 'left': 'Action(Left)', 'right': 'Action(Right)',
        'ok': 'Action(Select)', 'back': 'Action(Back)', 'louder': 'Action(VolumeUp)', 'quieter': 'Action(VolumeDown)'}


def _log(text):
    xbmc.log('[MegaNexus] Games phones: ' + text, xbmc.LOGINFO)


def lan_ip():
    from .phone_setup import lan_ip as address
    return address()


class Player(object):
    def __init__(self, ident, slot, name):
        self.ident, self.slot, self.name = ident, slot, name
        self.connection = None
        self.pad = None

    def public(self):
        return {'slot': self.slot, 'name': self.name, 'colour': COLOURS[self.slot - 1], 'here': self.connection is not None}


class Connection(object):
    """One phone's WebSocket (server side: its frames come masked, ours go plain)."""

    def __init__(self, stream):
        self.stream = stream
        self.lock = threading.Lock()

    def send(self, message):
        data = json.dumps(message, separators=(',', ':')).encode('utf-8')
        size = len(data)
        head = bytes((0x81, size)) if size < 126 else (bytes((0x81, 126)) + struct.pack('!H', size) if size < 65536
                                                       else bytes((0x81, 127)) + struct.pack('!Q', size))
        with self.lock:
            self.stream.write(head + data)
            self.stream.flush()

    def receive(self):
        """The next text message (a ping answered on the way), None when the phone went."""
        while True:
            head = self.stream.read(2)
            if len(head) < 2:
                return None
            opcode, size = head[0] & 0x0F, head[1] & 0x7F
            if size == 126:
                size = struct.unpack('!H', self.stream.read(2))[0]
            elif size == 127:
                size = struct.unpack('!Q', self.stream.read(8))[0]
            if size > FRAME_MOST or not head[1] & 0x80:
                return None                    # too big, or not from a browser (a client's frames are masked)
            mask = self.stream.read(4)
            data = bytearray(self.stream.read(size))
            if len(data) < size:
                return None
            for at in range(size):
                data[at] ^= mask[at % 4]
            if opcode == 0x8:
                return None
            if opcode == 0x9:
                with self.lock:
                    self.stream.write(bytes((0x8A, len(data))) + bytes(data[:125]))
                    self.stream.flush()
                continue
            if opcode in (0x1, 0x0):
                return bytes(data).decode('utf-8', 'replace')

    def close(self):
        try:
            with self.lock:
                self.stream.write(b'\x88\x00')
                self.stream.flush()
        except (OSError, ValueError):
            pass


class PlayServer(object):
    """``on_play(game id)``: a phone asked for a game; ``games()``: the list the phones browse; the game that plays
    now (set_game) - what the phones are told. ``mode`` 'quiz': the page is Guess It's buttons instead
    (``on_answer(slot, question, option)``; set_quiz / tell); 'poker': the poker table's (``on_move(slot, move, to)``;
    set_table for everyone, tell for each one's own cards)."""

    def __init__(self, games, on_play, on_answer=None, mode='games', key='', on_move=None):
        self.key = key or secrets.token_urlsafe(9)        # the device's own (games.phone_key), else this time's
        self.players = {}
        self.lock = threading.RLock()
        self.games, self.on_play, self.on_answer, self.mode = games, on_play, on_answer, mode
        self.on_move = on_move
        self.game = None
        self.quiz = {'phase': 'lobby'}
        self.table = {'phase': 'lobby'}
        self.pads = game_pad.kind()                      # 'addon', 'uinput' or '' (game_pad.begin)
        self.httpd = None
        self.thread = None
        # every phone's open connection (a page kept alive, a WebSocket): stop() ends them. Left to the phones, their
        # threads waited minutes (a locked phone: for ever) - and Kodi keeps the whole game in memory until they end
        self.sockets = set()

    # ---- running -----------------------------------------------------------------------------------
    def start(self):
        handler = type('PlayHandler', (_Handler,), {'server_owner': self})
        for port in (PORT, 0):
            try:
                self.httpd = ThreadingHTTPServer(('0.0.0.0', port), handler)
                break
            except OSError:
                continue
        self.httpd.daemon_threads = True
        self.thread = threading.Thread(target=self.httpd.serve_forever, name='MegaNexusGamesPhones', daemon=True)
        self.thread.start()
        _log('ready on port %d (%s)' % (self.port(), 'phone pads' if self.pads else 'no phone pads on this system'))
        return self

    def port(self):
        return self.httpd.server_address[1] if self.httpd else 0

    def url(self):
        return 'http://%s:%d/?k=%s' % (lan_ip(), self.port(), self.key)

    def stop(self):
        with self.lock:
            for player in self.players.values():
                if player.connection:
                    player.connection.close()
                self._drop_pad(player)
            self.players.clear()
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
        with self.lock:
            still = list(self.sockets)
        for sock in still:
            try:
                sock.shutdown(socket.SHUT_RDWR)          # its thread's read ends at once
            except OSError:
                pass
        _log('closed')

    def opened(self, sock):
        with self.lock:
            self.sockets.add(sock)

    def ended(self, sock):
        with self.lock:
            self.sockets.discard(sock)

    def allowed(self, key):
        return bool(key) and hmac.compare_digest(str(key).encode(), self.key.encode())

    # ---- the players -------------------------------------------------------------------------------
    def join(self, ident, name, connection):
        """The phone's player: the one it was, else the first free place; None when all eight are taken."""
        with self.lock:
            player = self.players.get(ident)
            if player is None:
                free = [n for n in range(1, MOST + 1) if n not in {p.slot for p in self.players.values()}]
                if not free:
                    return None
                player = self.players[ident] = Player(ident, free[0], name or 'Player %d' % free[0])
            elif name:
                player.name = name
            if player.connection is not None:
                player.connection.close()
            player.connection = connection
            if self.pads and player.pad is None and self.mode == 'games':     # Guess It needs no gamepads
                try:
                    player.pad = game_pad.make(player.slot)
                except OSError as exc:
                    _log('no pad for player %d (%s)' % (player.slot, exc.__class__.__name__))
        return player

    def leave(self, player, connection):
        with self.lock:
            if player.connection is connection:
                player.connection = None
                self._drop_pad(player)
        self.broadcast_players()

    @staticmethod
    def _drop_pad(player):
        if player.pad is not None:
            player.pad.close()
            player.pad = None

    def roster(self):
        with self.lock:
            return sorted((p.public() for p in self.players.values()), key=lambda p: p['slot'])

    def swap(self, first, second):
        """The TV puts two players in each other's place."""
        with self.lock:
            found = {p.slot: p for p in self.players.values()}
            if first in found:
                found[first].slot = second
            if second in found:
                found[second].slot = first
        self.broadcast_players()

    # ---- what the phones are told -------------------------------------------------------------------
    def broadcast(self, message):
        with self.lock:
            connections = [p.connection for p in self.players.values() if p.connection]
        for connection in connections:
            try:
                connection.send(message)
            except (OSError, ValueError):
                pass

    def broadcast_players(self):
        self.broadcast({'t': 'players', 'players': self.roster()})

    def set_game(self, game):
        """The game that plays now (its controller and pad), or None - every phone follows it."""
        self.game = game
        self.broadcast({'t': 'game', 'game': game})

    def set_quiz(self, state):
        """Guess It's state for every phone: its phase, the question's words and its four answers."""
        self.quiz = state
        self.broadcast(dict(state, t='quiz'))

    def set_table(self, state):
        """Poker: what everyone at the table may see (no one's cards until they are shown)."""
        self.table = state
        self.broadcast(dict(state, t='table'))

    def tell(self, slot, message):
        """One player's own news (their answer right or wrong, their points and place)."""
        with self.lock:
            connection = next((p.connection for p in self.players.values() if p.slot == slot and p.connection), None)
        if connection is not None:
            try:
                connection.send(message)
            except (OSError, ValueError):
                pass

    # ---- one phone's messages -------------------------------------------------------------------------
    def handle(self, player, message):
        kind = message.get('t')
        if kind == 'b' and player.pad is not None:
            player.pad.press(int(message.get('i', -1)), bool(message.get('v')))
        elif kind == 'a' and player.pad is not None:
            player.pad.axis(int(message.get('i', -1)), int(message.get('v') or 0))
        elif kind == 'menu' and message.get('a') in MENU:
            xbmc.executebuiltin(MENU[message['a']])
        elif kind == 'play' and isinstance(message.get('id'), str) and self.on_play:
            self.on_play(message['id'])
        elif kind == 'move' and self.on_move:
            self.on_move(player.slot, str(message.get('a') or '')[:8], int(message.get('to') or 0))
        elif kind == 'answer' and self.on_answer:
            self.on_answer(player.slot, int(message.get('q', -1)), int(message.get('i', -1)))
        elif kind == 'name':
            player.name = str(message.get('name') or '')[:20] or player.name
            self.broadcast_players()
        elif kind == 'games':
            player.connection.send({'t': 'games', 'games': self.games()})


class _Handler(BaseHTTPRequestHandler):
    server_owner = None
    protocol_version = 'HTTP/1.1'

    def log_message(self, *_args):
        pass                                    # nothing of the phones' addresses or keys in Kodi's log

    def setup(self):
        super().setup()
        self.server_owner.opened(self.connection)

    def finish(self):
        try:
            super().finish()
        finally:
            self.server_owner.ended(self.connection)

    def _send(self, code, body=b'', kind='text/plain; charset=utf-8', cache=False):
        self.send_response(code)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'max-age=86400' if cache else 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        owner = self.server_owner
        parts = urlsplit(self.path)
        query = parse_qs(parts.query)
        if parts.path in ('/', '/index.html'):
            with open(PAGE, 'rb') as page:
                return self._send(200, page.read(), 'text/html; charset=utf-8')
        if parts.path.startswith('/pictures/'):
            return self._picture(parts.path[len('/pictures/'):])
        if parts.path == '/icon.png':
            with open(ICON, 'rb') as icon:
                return self._send(200, icon.read(), 'image/png', cache=True)
        if parts.path == '/ws' and owner.allowed((query.get('k') or [''])[0]) and \
                self.headers.get('Upgrade', '').lower() == 'websocket':
            return self._websocket()
        return self._send(404 if parts.path != '/ws' else 403)

    def _picture(self, name):
        """A game's poster or a console's logo (the page's own; nothing else of the add-on)."""
        folder, _, leaf = name.partition('/')
        allowed = {'art': ('.jpg',), 'logos': ('.svg',)}
        if folder not in allowed or not leaf or '/' in leaf or leaf.startswith('.') or not leaf.endswith(allowed[folder]):
            return self._send(404)
        path = os.path.join(GAMES, folder, leaf)
        if not os.path.isfile(path):
            return self._send(404)
        with open(path, 'rb') as picture:
            return self._send(200, picture.read(), 'image/jpeg' if leaf.endswith('.jpg') else 'image/svg+xml', cache=True)

    def _websocket(self):
        owner = self.server_owner
        accept = base64.b64encode(hashlib.sha1((self.headers.get('Sec-WebSocket-Key', '') + GUID).encode()).digest())
        self.send_response(101)
        self.send_header('Upgrade', 'websocket')
        self.send_header('Connection', 'Upgrade')
        self.send_header('Sec-WebSocket-Accept', accept.decode())
        self.end_headers()
        self.wfile.flush()
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)   # a press goes at once
        except OSError:
            pass
        connection = Connection(_Stream(self.rfile, self.wfile))
        player = None
        try:
            hello = json.loads(connection.receive() or '{}')
            if hello.get('t') != 'hello' or not isinstance(hello.get('id'), str):
                return
            player = owner.join(hello['id'][:40], str(hello.get('name') or '')[:20], connection)
            if player is None:
                connection.send({'t': 'full'})
                return
            connection.send({'t': 'welcome', 'mode': owner.mode, 'player': player.public(), 'pads': player.pad is not None,
                             'game': owner.game, 'quiz': owner.quiz, 'table': owner.table, 'players': owner.roster(),
                             'games': owner.games()})
            owner.broadcast_players()
            while True:
                text = connection.receive()
                if text is None:
                    break
                try:
                    owner.handle(player, json.loads(text))
                except (ValueError, TypeError, AttributeError):
                    continue
        except (OSError, ValueError):
            pass
        finally:
            if player is not None:
                owner.leave(player, connection)
            self.close_connection = True


class _Stream(object):
    def __init__(self, reader, writer):
        self.read, self.write, self.flush = reader.read, writer.write, writer.flush
