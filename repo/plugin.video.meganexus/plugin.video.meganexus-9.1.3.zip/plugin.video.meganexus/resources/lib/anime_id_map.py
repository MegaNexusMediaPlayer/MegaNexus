# -*- coding: utf-8 -*-
# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""An anime's other ids (IMDb, TMDB, TVDB, Kitsu, MAL, AniList, AniDB) from Fribb's public
anime-lists, so an anime add-on can be asked by the id it understands.

The list (about 40 000 rows) is kept in anime_ids.db and rebuilt every 14 days in the
background - a lookup never waits for it (`anime_id_mapping` switches it off).

9.1.1: Fribb's list now gives the IMDb ids as a list, the TMDB id as {"tv"|"movie": id} and
"tvdb_id" for "thetvdb_id" - read as they were, no IMDb, TMDB or TVDB id was ever found (the
Library's Anime filter, an anime add-on asked by its own id). Kept with each row now: its kind and
the TMDB / TVDB season it is and the episodes before it there (AniList and MyAnimeList count each
season, or part of one, as an anime of its own: episode_entry)."""
import json
import os
import sqlite3
import threading
import time
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

SOURCE_URL = 'https://raw.githubusercontent.com/Fribb/anime-lists/master/anime-list-full.json'
REBUILD_AFTER = 14 * 86400
# Fribb's fields -> ours (the first one the row has; "thetvdb_id" is the name it had before)
FIELDS = ((('imdb_id',), 'imdb_id'), (('themoviedb_id',), 'tmdb_id'), (('tvdb_id', 'thetvdb_id'), 'tvdb_id'),
          (('kitsu_id',), 'kitsu_id'), (('mal_id',), 'mal_id'), (('anilist_id',), 'anilist_id'), (('anidb_id',), 'anidb_id'))
KEYS = tuple(ours for _theirs, ours in FIELDS)
# what each row also keeps: TV / MOVIE / OVA..., what its TMDB id is of (tv / movie), its season and the
# episodes before it in that season, as TMDB and as TVDB number them
PLACE = ('kind', 'tmdb_kind', 'season_tmdb', 'season_tvdb', 'offset_tmdb', 'offset_tvdb')
COLUMNS = KEYS + PLACE

_lock = threading.Lock()
_building = [False]
_answers = {}


def _addon():
    return xbmcaddon.Addon('plugin.video.meganexus')


def enabled():
    try:
        return (_addon().getSetting('anime_id_mapping') or 'true').strip().lower() in ('true', '1', 'yes', 'on')
    except Exception:
        return True


def _file():
    try:
        folder = xbmcvfs.translatePath(_addon().getAddonInfo('profile'))
    except Exception:
        folder = xbmc.translatePath('special://profile/addon_data/plugin.video.meganexus')
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, 'anime_ids.db')


def _open():
    conn = sqlite3.connect(_file(), timeout=5)
    conn.execute('CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)')
    had = [row[1] for row in conn.execute('PRAGMA table_info(map)')]
    if had and set(had) != set(COLUMNS):          # a list kept before 9.1.1: built again in the new shape
        conn.execute('DROP TABLE map')
        conn.execute("DELETE FROM meta WHERE k='built_at'")
        conn.commit()
    conn.execute('CREATE TABLE IF NOT EXISTS map (%s)' % ', '.join('%s TEXT' % key for key in COLUMNS))
    for key in KEYS:
        conn.execute('CREATE INDEX IF NOT EXISTS idx_%s ON map(%s)' % (key, key))
    return conn


def _current(conn):
    try:
        row = conn.execute("SELECT v FROM meta WHERE k='built_at'").fetchone()
        return float(row[0] if row else 0.0) + REBUILD_AFTER > time.time()
    except Exception:
        return False


def _text(value):
    return str(value).strip().lower() or None if value not in (None, '') else None


def _all(value):
    return [v for v in (value if isinstance(value, list) else [value]) if _text(v)] or [None]


def rows_of(entry):
    """The rows one entry of Fribb's list is kept as (one for each of its IMDb and TMDB ids), in
    COLUMNS order; its fields as Fribb writes them now or did before (an id or a list of them, a TMDB
    id or {"tv": id} / {"movie": [ids]})."""
    values, tmdb_kind = {}, None
    for theirs, ours in FIELDS:
        value = next((entry.get(name) for name in theirs if entry.get(name) not in (None, '', [], {})), None)
        if ours == 'tmdb_id' and isinstance(value, dict):
            tmdb_kind, value = next(((kind, value[kind]) for kind in ('tv', 'movie') if value.get(kind)), (None, None))
        values[ours] = value
    season = entry.get('season') if isinstance(entry.get('season'), dict) else {}
    offset = entry.get('episode_offset') if isinstance(entry.get('episode_offset'), dict) else {}
    place = (_text(entry.get('type')), tmdb_kind, _text(season.get('tmdb')), _text(season.get('tvdb')),
             _text(offset.get('tmdb')), _text(offset.get('tvdb')))
    out = []
    for imdb in _all(values['imdb_id']):
        for tmdb in _all(values['tmdb_id']):
            row = tuple(_text(imdb if ours == 'imdb_id' else tmdb if ours == 'tmdb_id' else values[ours]) for ours in KEYS) + place
            if any(row[:len(KEYS)]):
                out.append(row)
    return out


def build(force=False):
    """Download and store the list (unless it is current); True when the map is usable."""
    with _lock:
        conn = _open()
        try:
            if not force and _current(conn):
                return True
            with urlopen(Request(SOURCE_URL, headers={'User-Agent': 'MegaNexus/8', 'Accept': 'application/json'}),
                         timeout=60) as answer:
                entries = json.loads(answer.read().decode('utf-8'))
            if not isinstance(entries, list) or not entries:
                return False
            rows = [row for entry in entries if isinstance(entry, dict) for row in rows_of(entry)]
            conn.execute('DELETE FROM map')
            conn.executemany('INSERT INTO map (%s) VALUES (%s)' % (','.join(COLUMNS), ','.join('?' * len(COLUMNS))), rows)
            conn.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('built_at', ?)", (str(time.time()),))
            conn.commit()
            xbmc.log('[MegaNexus] anime id map built: %d entries' % len(rows), xbmc.LOGINFO)
            return True
        except Exception as exc:
            try:
                conn.rollback()
            except Exception:
                pass
            xbmc.log('[MegaNexus] anime id map build failed: %s' % exc, xbmc.LOGWARNING)
            return False
        finally:
            conn.close()


def ensure_async():
    """(Re)build in the background, once at a time."""
    if _building[0]:
        return
    _building[0] = True

    def work():
        try:
            build()
        finally:
            _building[0] = False
    try:
        from .side_jobs import maybe_run
        started = maybe_run(work, key='anime-id-map-build')
    except Exception:
        started = False
    if not started:
        _building[0] = False


def _clean(key, value):
    value = str(value or '').strip().lower()
    if key == 'imdb_id':
        return value if value.startswith('tt') else ''
    return value.split(':')[-1] if value else ''


TMDB_KINDS = {'movie': 'movie', 'series': 'tv', 'tv': 'tv', 'show': 'tv', 'shows': 'tv'}


def lookup(ids, media_type=''):
    """The ids the map adds to the given ones ({} when unknown, switched off or not built yet). ``media_type``
    (movie / series), 9.1.1: TMDB and TVDB number films and series apart - a film's number is also some anime
    series' - so a TMDB id is matched within its kind, and a film's TVDB id not at all (Fribb's are the series')."""
    if not enabled() or not isinstance(ids, dict):
        return {}
    known = dict((key, value) for key, value in ((key, _clean(key, ids.get(key))) for key in KEYS) if value)
    kind = TMDB_KINDS.get(str(media_type or '').lower())
    if kind == 'movie':
        known.pop('tvdb_id', None)
    if not known:
        return {}
    key = (tuple(sorted(known.items())), kind)
    if key in _answers:
        return dict(_answers[key])
    if not os.path.isfile(_file()):
        ensure_async()
        return {}
    found = {}
    try:
        conn = _open()
        try:
            if not _current(conn):
                ensure_async()
            for name, value in known.items():
                query, args = 'SELECT %s FROM map WHERE %s = ?' % (','.join(KEYS), name), (value,)
                if name == 'tmdb_id' and kind:
                    query, args = query + ' AND (tmdb_kind = ? OR tmdb_kind IS NULL)', (value, kind)
                row = conn.execute(query + ' LIMIT 1', args).fetchone()
                if row:
                    found = dict((field, str(row[place])) for place, field in enumerate(KEYS)
                                 if row[place] and not known.get(field))
                    break
        finally:
            conn.close()
    except Exception as exc:
        xbmc.log('[MegaNexus] anime id lookup failed: %s' % exc, xbmc.LOGDEBUG)
        return {}
    _answers[key] = dict(found)
    return found


ANIME_PREFIXES = (('kitsu', 'kitsu_id'), ('mal', 'mal_id'), ('anilist', 'anilist_id'), ('anidb', 'anidb_id'))


def _number(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def _entry(row, episode):
    named = dict(zip(COLUMNS, row))
    if not (named['anilist_id'] or named['mal_id']) or not episode or episode < 1:
        return {}
    return {'anilist_id': named['anilist_id'] or '', 'mal_id': named['mal_id'] or '', 'episode': episode}


def _one(rows):
    """The single anime among ``rows`` (a TV series before an OVA or a special of the same place), else None."""
    tv = [r for r in rows if dict(zip(COLUMNS, r))['kind'] == 'tv'] or rows
    found = {(dict(zip(COLUMNS, r))['anilist_id'], dict(zip(COLUMNS, r))['mal_id']) for r in tv}
    return tv[0] if len(found) == 1 else None


def place_in(rows, numbering, season, episode, absolute=0):
    """(row, its episode) the episode ``season``x``episode`` (as ``numbering`` - tmdb / tvdb - counts) is in:
    the part of that season that starts last before it; a show that is one anime as a whole (no season
    kept: One Piece, Naruto Shippuden) counts on from its first episode (``absolute``). (None, 0) unsure."""
    named = [(r, dict(zip(COLUMNS, r))) for r in rows]
    parts = [(r, _number(n['offset_' + numbering]) or 0) for r, n in named
             if _number(n['season_' + numbering]) == season and (_number(n['offset_' + numbering]) or 0) < episode]
    if parts:
        start = max(offset for _r, offset in parts)
        row = _one([r for r, offset in parts if offset == start])
        return (row, episode - start) if row else (None, 0)
    whole = [r for r, n in named if n['season_tmdb'] is None and n['season_tvdb'] is None and n['kind'] != 'movie']
    row = _one(whole) if whole else None
    if not row:
        return None, 0
    return row, (absolute or 0) if season > 1 else episode


def _rows(conn, column, value, kind=None):
    query = 'SELECT %s FROM map WHERE %s = ?' % (','.join(COLUMNS), column)
    return conn.execute(query + ' AND tmdb_kind = ?' if kind else query, (value, kind) if kind else (value,)).fetchall()


def episode_entry(ids, media='series', season=None, episode=None, absolute=0, video_id=''):
    """{'anilist_id', 'mal_id', 'episode'}: the anime AniList / MyAnimeList keep what was watched under and
    its number there - {} when not known for sure (never another anime's). ``ids``: the title's
    imdb / tmdb / tvdb / kitsu / mal / anilist / anidb ids; ``video_id``: an anime add-on's own
    ('kitsu:7442:5' - the anime and its episode); a film is its anime's one episode."""
    if not enabled() or not os.path.isfile(_file()):
        ensure_async()
        return {}
    ids = dict(ids or {})
    parts = str(video_id or '').strip().lower().split(':')
    direct = dict(ANIME_PREFIXES).get(parts[0]) if len(parts) >= 2 else None
    if direct:
        ids[direct] = parts[1]
    known = dict((key, value) for key, value in ((key, _clean(key, ids.get(key))) for key in KEYS) if value)
    film = str(media or '').lower() == 'movie'
    season, episode = _number(season), _number(episode)
    try:
        conn = _open()
        try:
            if not _current(conn):
                ensure_async()                 # two weeks old: built again behind (the playback is over)
            for key in ('anilist_id', 'mal_id', 'kitsu_id', 'anidb_id'):   # the anime itself
                if known.get(key):
                    number = 1 if film else (_number(parts[2]) if direct and len(parts) >= 3 else episode)
                    row = conn.execute('SELECT %s FROM map WHERE %s = ? LIMIT 1' % (','.join(COLUMNS), key),
                                       (known[key],)).fetchone()
                    if row:
                        return _entry(row, number)
                    # not in the list: an AniList / MyAnimeList id is still that service's own
                    return _entry(tuple(known[key] if column == key else None for column in COLUMNS), number)
            if film:
                rows = (_rows(conn, 'tmdb_id', known['tmdb_id'], 'movie') if known.get('tmdb_id') else []) or \
                       [r for r in (_rows(conn, 'imdb_id', known['imdb_id']) if known.get('imdb_id') else [])
                        if dict(zip(COLUMNS, r))['kind'] == 'movie']
                found = {(dict(zip(COLUMNS, r))['anilist_id'], dict(zip(COLUMNS, r))['mal_id']) for r in rows}
                return _entry(rows[0], 1) if len(found) == 1 else {}
            if not season or not episode:
                return {}                      # a special (season 0) or no episode: no one place for it
            # TMDB's seasons with its id, TVDB's with its own - and an IMDb id's as TVDB counts them
            for column, value, numbering, kind in (('tmdb_id', known.get('tmdb_id'), 'tmdb', 'tv'),
                                                   ('tvdb_id', known.get('tvdb_id'), 'tvdb', None),
                                                   ('imdb_id', known.get('imdb_id'), 'tvdb', None)):
                rows = _rows(conn, column, value, kind) if value else []
                if rows:
                    row, number = place_in(rows, numbering, season, episode, absolute)
                    return _entry(row, number) if row else {}
        finally:
            conn.close()
    except Exception as exc:
        xbmc.log('[MegaNexus] anime entry lookup failed: %s' % type(exc).__name__, xbmc.LOGDEBUG)
    return {}


def _order(named):
    """Where an anime stands in its show: the whole show first, then its seasons (TVDB's, else TMDB's) and
    the parts of one, its specials and films last."""
    season = _number(named['season_tvdb'])
    season = season if season is not None else _number(named['season_tmdb'])
    offset = _number(named['offset_tvdb']) or _number(named['offset_tmdb']) or 0
    return (0 if season is None else 999 if season == 0 else season, offset, named['kind'] != 'tv')


def title_of(key, anime):
    """The title an AniList (``key`` 'anilist_id') or MyAnimeList ('mal_id') anime is kept under here:
    {'media_type', 'canonical_id', 'order'} - by its IMDb id, else its TMDB id, else its Kitsu id (an anime
    add-on's); {} when the list knows none of them (or is not built yet)."""
    if key not in ('anilist_id', 'mal_id') or not enabled() or not os.path.isfile(_file()):
        ensure_async()
        return {}
    try:
        conn = _open()
        try:
            row = conn.execute('SELECT %s FROM map WHERE %s = ? LIMIT 1' % (','.join(COLUMNS), key),
                               (str(anime).strip(),)).fetchone()
        finally:
            conn.close()
    except Exception:
        return {}
    if not row:
        return {}
    named = dict(zip(COLUMNS, row))
    film = named['kind'] == 'movie' and (named['imdb_id'] or named['tmdb_kind'] != 'tv')
    if named['imdb_id']:
        canonical = named['imdb_id']
    elif named['tmdb_id']:
        canonical = 'tmdb:%s' % named['tmdb_id']
        film = named['tmdb_kind'] == 'movie'
    elif named['kitsu_id']:
        canonical = 'kitsu:%s' % named['kitsu_id']
    else:
        return {}
    return {'media_type': 'movie' if film else 'series', 'canonical_id': canonical, 'order': _order(named)}


def parts_of(ids, media='series'):
    """[{'anilist_id', 'mal_id'}] of a title, its first anime first (a show: the whole show or its first
    season before the next ones, its specials last; a film: itself) - [] when it is no anime."""
    known = dict((key, value) for key, value in ((key, _clean(key, (ids or {}).get(key))) for key in KEYS) if value)
    if not known or not enabled() or not os.path.isfile(_file()):
        return []
    film = str(media or '').lower() == 'movie'
    try:
        conn = _open()
        try:
            rows = []
            for column, kind in (('imdb_id', None), ('tmdb_id', 'movie' if film else 'tv'), ('kitsu_id', None),
                                 ('anilist_id', None), ('mal_id', None)):
                if known.get(column):
                    rows = _rows(conn, column, known[column], kind)
                    if rows:
                        break
        finally:
            conn.close()
    except Exception:
        return []
    named = [dict(zip(COLUMNS, r)) for r in rows]
    named = [n for n in named if (n['kind'] == 'movie') == film]
    out, seen = [], set()
    for n in sorted(named, key=_order):
        pair = (n['anilist_id'] or '', n['mal_id'] or '')
        if any(pair) and pair not in seen:
            seen.add(pair)
            out.append({'anilist_id': pair[0], 'mal_id': pair[1]})
    return out
