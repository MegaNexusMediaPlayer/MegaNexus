# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Best stream first, by the user's preferences (7.0.12).

Every stream row (add-ons, TorBox) is read for resolution, size, Dolby Vision /
HDR, audio, cached state and CAM releases, then ordered so the first row is
the one Autoplay starts and the top of the source list. Nothing is hidden:
rows over the size limit or above the resolution limit only move down, so a
title with nothing inside the limits still plays. The user's own Plex /
Jellyfin copies stay first. HUB Settings > Playback > Automatic stream choice.

9.1.2: video made for editing (Apple ProRes, DNxHD, CineForm, uncompressed) goes last on a TV box,
whatever the preferences: no TV box's video chip decodes it, and decoded by its processor it froze the
Fire TV Cube ("upalio sam film ... ali je sve zamrzlo" - Apple ProRes 4K with 24-bit PCM, from TorBox).
A PC decodes it with its processor and keeps the add-ons' order.
"""
import os
import re

SORT = 'stream_sort_prefs'           # on: order by these preferences
MAX_RES = 'stream_max_res'           # 4k | 1080p | 720p
MOVIE_GB = 'stream_movie_max_gb'     # 0 = no limit
EPISODE_GB = 'stream_episode_max_gb'
DOLBY_VISION = 'stream_dolby_vision'  # prefer | neutral | avoid
HDR = 'stream_hdr'                   # prefer | neutral
CACHED = 'stream_prefer_cached'      # debrid: cached (instant) first
GROUPS = 'stream_release_groups'     # 7.0.43: TRaSH Guides release group tiers

RES_CHOICES = ('4k', '1080p', '720p')
RES_LABELS = {'4k': 'Up to 4K', '1080p': 'Up to 1080p', '720p': 'Up to 720p'}
MOVIE_GB_CHOICES = ('0', '5', '10', '15', '20', '30', '50')
EPISODE_GB_CHOICES = ('0', '1', '2', '3', '5', '8', '10')
DV_CHOICES = ('prefer', 'neutral', 'avoid')
DV_LABELS = {'prefer': 'Prefer Dolby Vision', 'neutral': 'No preference', 'avoid': 'Avoid Dolby Vision'}
HDR_CHOICES = ('prefer', 'neutral')
HDR_LABELS = {'prefer': 'Prefer HDR', 'neutral': 'No preference'}
RES_RANK = {'4k': 4, '1080p': 3, '720p': 2}

_RES = ((4, re.compile(r'(?<!\d)(?:2160p?|4k|uhd)(?!\d)', re.I)), (3, re.compile(r'(?<!\d)1080[pi]?(?!\d)', re.I)),
        (2, re.compile(r'(?<!\d)720p?(?!\d)', re.I)), (1, re.compile(r'(?<!\d)(?:480p?|576p?|360p?)(?!\d)|\bsd\b', re.I)))
# 7.0.43: a written-out number wins over the words: "1080p.UHD.BluRay" is a 1080p file
# made from a UHD Blu-ray, not 4K.
_RES_NUMBER = ((4, re.compile(r'(?<!\d)2160[pi]?(?!\d)', re.I)), (3, re.compile(r'(?<!\d)1080[pi]?(?!\d)', re.I)),
               (2, re.compile(r'(?<!\d)720[pi]?(?!\d)', re.I)), (1, re.compile(r'(?<!\d)(?:480|576|360)[pi]?(?!\d)', re.I)))
SIZE_BAND = 1.15          # 7.0.43: files within ~15 % count as the same size
MIN_4K_MBPS = 3.0         # a "4K" film below this bitrate is not really 4K
_DV = re.compile(r'\b(?:dolby[ ._-]?vision|dovi|dv)\b', re.I)
_HDR = re.compile(r'\b(?:hdr10\+?|hdr|hlg)\b', re.I)
_CAM = re.compile(r'\b(?:cam|camrip|hdcam|ts|telesync|hdts|tc|telecine|scr|screener)\b', re.I)
_CACHED = re.compile(r'⚡|\[(?:rd|ad|pm|tb|ed|dl|oc|pp)\+\]|\bcached\b|\binstant\b', re.I)
_UNCACHED = re.compile(r'⏳|\[(?:rd|ad|pm|tb|ed|dl)\s*(?:download|⏳)\]|\bnot cached\b|\buncached\b|\bdownload\b', re.I)
_SIZE = re.compile(r'(\d+(?:[.,]\d+)?)\s*(TB|GB|GiB|MB|MiB)\b', re.I)
# 7.0.29: the best audio first - TrueHD Atmos, DTS:X / DTS-HD MA, Atmos (DD+), lossless
# TrueHD / DTS-HD, DD+ / 7.1, DTS / AC3 5.1.
_AUDIO = ((6, re.compile(r'\btruehd\b.*\batmos\b|\batmos\b.*\btruehd\b', re.I)),
          (5, re.compile(r'\bdts[ ._:-]?x\b|\bdts[ ._-]?hd[ ._-]?ma\b|\bdts[ ._-]?ma\b', re.I)),
          (4, re.compile(r'\batmos\b', re.I)),
          (3, re.compile(r'\btruehd\b|\bdts[ ._-]?hd\b|\blpcm\b|\bflac\b', re.I)),
          (2, re.compile(r'\b(?:dd\+|ddp|eac3|e-ac-3)|\b7[ .]1\b', re.I)),
          (1, re.compile(r'\bdts\b|\bac3\b|\bdd(?:5[ .]?1)?\b|\b5[ .]1\b', re.I)))
# 7.0.29: the release's source - REMUX, Blu-ray, WEB-DL, WEBRip, TV / DVD.
_SOURCE = ((6, re.compile(r'\b(?:bd|uhd|bluray|blu[ ._-]?ray)?[ ._-]?remux\b', re.I)),
           (5, re.compile(r'\b(?:blu[ ._-]?ray|bluray|bdrip|brrip|bd(?:25|50|66|100)?|uhd[ ._-]?bd)\b', re.I)),
           (4, re.compile(r'\bweb[ ._-]?dl\b|\bwebdl\b|\b(?:amzn|nf|dsnp|atvp|hmax|max|pcok|hulu)[ ._-]web\b', re.I)),
           (3, re.compile(r'\bweb[ ._-]?rip\b|\bweb\b', re.I)),
           (2, re.compile(r'\bhdtv\b|\bpdtv\b|\bdvd(?:rip|5|9)?\b|\bhdrip\b', re.I)))
# 7.0.43: release group tiers (TRaSH Guides, resources/release_groups.json): a tier-01
# group counts as a file BONUS[1] size bands (~1.15 x each) bigger, so a good group
# wins over a slightly bigger file but not over one twice its size. A group TRaSH
# rates low quality counts as LQ_PENALTY bands (~3 x) smaller - still ahead of a
# file a tenth its size; upscaled / 3D / retagged / obfuscated releases go below
# every other file of the resolution.
BONUS = {1: 4, 2: 3, 3: 2}
LQ_PENALTY = -8
ANIME_BONUS = {'anime-bd': lambda tier: max(4 - (tier - 1) // 2, 1), 'anime-web': lambda tier: max(2 - (tier - 1) // 2, 0)}
_VIDEO_EXT = re.compile(r'\.(?:mkv|mp4|m4v|avi|ts|m2ts|webm|mov|wmv|iso)$', re.I)
_RELEASE_LIKE = re.compile(r'(?<!\d)(?:19|20)\d\d(?!\d)|(?<!\d)(?:2160|1080|720|480)[pi]\b|\bx26[45]\b|\bhevc\b|\bweb[ ._-]?(?:dl|rip)?\b|\bblu[ ._-]?ray\b|\bs\d\de\d\d\b', re.I)
_GROUP_TAIL = re.compile(r'(?:([A-Za-z0-9]{1,8})-)?([A-Za-z0-9][\w.&@]*)\s*(?:\[[^\]]*\]|\([^)]*\))?$')
_GROUP_HEAD = re.compile(r'^\s*\[([^\]]+)\]')
# Add-ons decorate names with invisible joiners and look-alike brackets ("Web\u200d-\u200ddl").
_INVISIBLE = re.compile('[\u00ad\u200b-\u200f\u2060-\u2064\ufeff]')


_TIERS = {}


def tiers(media):
    """The compiled TRaSH rules for 'movie' / 'series' (read once)."""
    if media not in _TIERS:
        import json
        import os
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'release_groups.json')
        try:
            with open(path, encoding='utf-8') as handle:
                data = json.load(handle)
        except Exception:
            data = {}
        def joined(patterns):
            return re.compile('|'.join('(?:%s)' % p for p in patterns), re.I) if patterns else None
        rated = [(row['category'], row['tier'], joined(row.get('groups')), joined(row.get('titles')))
                 for row in (data.get('tiers') or {}).get(media, [])]
        avoid = (data.get('avoid') or {}).get(media, {})
        _TIERS[media] = (rated, joined(avoid.get('groups')), joined(avoid.get('titles')))
    return _TIERS[media]


# what the row says of itself, and what Kodi names the codec once it plays (VideoPlayer.VideoCodec)
# (as a word of its own: file names join them with _ and .)
_EDIT = ((re.compile(r'(?<![a-z0-9])pro[ ._-]?res(?![a-z])', re.I), 'Apple ProRes'),
         (re.compile(r'(?<![a-z0-9])dnx(?:hd|hr)(?![a-z])', re.I), 'Avid DNxHD'),
         (re.compile(r'(?<![a-z0-9])cine[ ._-]?form(?![a-z])', re.I), 'CineForm'))
EDIT_CODECS = {'prores': 'Apple ProRes', 'dnxhd': 'Avid DNxHD', 'cfhd': 'CineForm', 'v210': 'uncompressed video',
               'rawvideo': 'uncompressed video'}
_BOX = []


def hardware_only():
    """A TV box - Amlogic (CoreELEC, LibreELEC on Amlogic: the video driver's file), Android, any ARM board: what its
    video chip does not decode it cannot play. Asked once."""
    if not _BOX:
        from .video_layer import POLICY
        try:
            machine = os.uname().machine.lower()
        except AttributeError:
            machine = ''
        box = os.path.exists(POLICY) or machine.startswith(('arm', 'aarch64'))
        if not box:
            try:
                import xbmc
                box = bool(xbmc.getCondVisibility('System.Platform.Android'))
            except Exception:
                pass
        _BOX.append(box)
    return _BOX[0]


def edit_format(row):
    """'Apple ProRes', 'Avid DNxHD', 'CineForm' when the row says it is one; '' otherwise."""
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    text = ' '.join(str(value or '') for value in (row.get('name'), row.get('title'), row.get('description'), hints.get('filename')))
    return next((name for pattern, name in _EDIT if pattern.search(text)), '')


def release_names(row):
    """The release's own name(s): the file name, else the lines that read like one."""
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    if hints.get('filename'):
        return [_INVISIBLE.sub('', str(hints['filename'])).strip()]
    lines = []
    for value in (row.get('title'), row.get('description')):
        lines += [_INVISIBLE.sub('', line).strip() for line in str(value or '').split('\n')]
    return [line for line in lines if _RELEASE_LIKE.search(line) and len(re.findall(r'[ .]', line)) >= 2]


def groups_of(names):
    """Release group candidates: what follows the last "-" (also "GROUP.Re.En.S" ->
    GROUP and two-part ones, D-Z0N3), or a leading [Group] (anime)."""
    found = []
    for name in names:
        base = _VIDEO_EXT.sub('', name).strip()
        if '-' in base:
            before, last = base.rsplit('-', 1)
            tail = _GROUP_TAIL.match(last.strip())
            if tail and not tail.group(1):
                group = tail.group(2)
                found += [group] + ([group.split('.')[0]] if '.' in group else [])
                prefix = re.search(r'(?:^|[ ._\[-])([A-Za-z0-9]{1,8})$', before)
                if prefix:
                    found.append(prefix.group(1) + '-' + group)
        head = _GROUP_HEAD.match(base)
        if head:
            found.append(head.group(1).strip())
    return found


def release_rank(row, text, t, media):
    """(avoid, bonus in size bands) from the TRaSH Guides tiers."""
    rated, avoid_groups, avoid_titles = tiers(media)
    names = release_names(row)
    groups = groups_of(names)
    title = ' '.join(names) or text
    if avoid_titles and avoid_titles.search(title):
        return True, 0
    if avoid_groups and any(avoid_groups.search(g) for g in groups):
        return False, LQ_PENALTY
    source, res = t['source'], t['res']
    fits = {'remux': source == 6, 'uhd-bluray': source == 5 and res == 4, 'hd-bluray': source == 5 and res != 4,
            'web': source in (3, 4), 'anime-bd': source in (5, 6), 'anime-web': source in (3, 4)}
    for category, tier, by_group, by_title in rated:
        if not fits.get(category):
            continue
        if (by_group and any(by_group.search(g) for g in groups)) or (by_title and by_title.search(title)):
            return False, ANIME_BONUS[category](tier) if category in ANIME_BONUS else BONUS.get(tier, 1)
    return False, 0


def _setting(addon, name, default):
    try:
        return (addon.getSetting(name) or default).strip().lower()
    except Exception:
        return default


def preferences(addon=None):
    if addon is None:
        from .settings_snapshot import cached_addon
        addon = cached_addon()
    def number(name):
        try:
            return float(_setting(addon, name, '0'))
        except ValueError:
            return 0.0
    prefs = {'sort': _setting(addon, SORT, 'true') != 'false',
             'max_res': RES_RANK.get(_setting(addon, MAX_RES, '4k'), 4),
             'movie_gb': number(MOVIE_GB), 'episode_gb': number(EPISODE_GB),
             'dv': _setting(addon, DOLBY_VISION, 'neutral'), 'hdr': _setting(addon, HDR, 'prefer'),
             'cached': _setting(addon, CACHED, 'true') != 'false', 'mbps': None,
             'groups': _setting(addon, GROUPS, 'true') != 'false'}
    # 7.0.42: with "No limit", the network's measured speed decides (net_speed.py)
    from . import net_speed
    if _setting(addon, net_speed.SETTING, 'true') != 'false':
        try:
            from .meganexus.paths import profile_path
            prefs['mbps'] = net_speed.load(profile_path())
        except Exception:
            pass
    return prefs


def _text(row):
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    text = ' '.join(str(x or '') for x in (row.get('name'), row.get('title'), row.get('description'), hints.get('filename')))
    text = _INVISIBLE.sub('', text).replace('\u00a0', ' ')
    return text.translate({0x3008: '[', 0x3009: ']', 0x2010: '-', 0x2011: '-', 0x2012: '-', 0x2013: '-'})


def size_bytes(row, text=None):
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    for value in (hints.get('videoSize'), row.get('size')):
        try:
            if value and float(value) > 0:
                return float(value)
        except (TypeError, ValueError):
            pass
    match = _SIZE.search(text if text is not None else _text(row))
    if not match:
        return 0.0
    number = float(match.group(1).replace(',', '.'))
    unit = match.group(2).upper()
    return number * {'TB': 1e12, 'GB': 1e9, 'GIB': 1073741824, 'MB': 1e6, 'MIB': 1048576}[unit]


def resolution_of(row, text):
    """The add-on's own label at the start of the source name first (AIOStreams,
    Torrentio... put it there); then a written-out number anywhere; the words
    4K / UHD only when no number is written."""
    name = _INVISIBLE.sub('', str(row.get('name') or '')).strip().split('\n')[0]
    found = next((rank for rank, pattern in _RES if pattern.search(name)), 0)
    if found:
        return found
    found = next((rank for rank, pattern in _RES_NUMBER if pattern.search(text)), 0)
    return found or next((rank for rank, pattern in _RES if pattern.search(text)), 0)


def traits(row):
    text = _text(row)
    resolution = resolution_of(row, text)
    cached = row.get('meganexus_cached')
    if cached is None:
        cached = True if _CACHED.search(text) else (False if _UNCACHED.search(text) else None)
    return {'res': resolution, 'size': size_bytes(row, text), 'dv': bool(_DV.search(text)),
            'hdr': bool(_HDR.search(text)) or bool(_DV.search(text)), 'cam': bool(_CAM.search(text)),
            'cached': cached, 'audio': next((score for score, pattern in _AUDIO if pattern.search(text)), 0),
            'source': next((score for score, pattern in _SOURCE if pattern.search(text)), 0)}


def playable(row):
    """7.0.43: can Kodi play the row - a link, a torrent (debrid / handoff), an NZB
    with a Usenet server (usenet_stream), a media link in externalUrl. Read from the
    row, the same for every add-on; the others go last (Autoplay never starts them)."""
    if row.get('url') or row.get('infoHash') or row.get('_meganexus_server'):
        return True
    if row.get('nzbUrl'):
        try:
            from . import usenet_stream
            return usenet_stream.playable(row)
        except Exception:
            return False
    external = str(row.get('externalUrl') or '').lower()
    return external.startswith(('plugin://', 'magnet:')) or bool(re.search(r'\.(?:m3u8|mp4|mkv|webm|ts|avi|mov|mpd)(?:$|\?)', external))


def score(row, prefs, episode):
    """7.0.43: within a resolution the bigger file first - names can be wrong (a
    "REMUX" of 900 MB), sizes cannot; a TRaSH-rated release group counts as a few
    size bands bigger, groups to avoid go down; the release type, Dolby Vision /
    HDR and the audio decide between files of about the same size (SIZE_BAND).
    Before, the release type came before the size, so any small file named REMUX led."""
    import math
    t = traits(row)
    limit = (prefs['episode_gb'] if episode else prefs['movie_gb']) * 1e9
    within_size = not limit or not t['size'] or t['size'] <= limit
    from . import net_speed
    runtime = prefs.get('runtime') or net_speed.RUNTIME['episode' if episode else 'movie']
    if not limit and prefs.get('mbps') and t['size']:
        # 7.0.42: No limit - the bitrate must fit 80 % of the network's speed
        within_size = t['size'] * 8 / runtime <= net_speed.bitrate_limit(prefs['mbps'])
    res = t['res']
    if res == 4 and t['size'] and t['size'] * 8 / runtime / 1e6 < MIN_4K_MBPS:
        res = 3                                                # a "4K" too small to be one
    within_res = not res or res <= prefs['max_res']
    dv = (1 if prefs['dv'] == 'prefer' else -1 if prefs['dv'] == 'avoid' else 0) if t['dv'] else 0
    hdr = 1 if (prefs['hdr'] == 'prefer' and t['hdr']) else 0
    cached = (1 if t['cached'] else (-1 if t['cached'] is False else 0)) if prefs['cached'] else 0
    band = int(math.log(t['size']) / math.log(SIZE_BAND)) if t['size'] > 1 else 0
    avoid, bonus = False, 0
    if prefs.get('groups', True):
        try:
            avoid, bonus = release_rank(row, _text(row), dict(t, res=res), 'series' if episode else 'movie')
        except Exception:
            pass
    return (playable(row), not t['cam'], within_size, within_res, cached, res if within_res else 0, not avoid, band + bonus,
            t['source'], dv, hdr, t['audio'], t['size'])


def order(rows, media_type='movie', prefs=None):
    """Best first; the user's own servers stay on top; ties keep add-on order. On a TV box video for editing
    goes last, with the preferences off too."""
    prefs = prefs or preferences()
    rows = list(rows or [])
    if prefs['sort']:
        episode = str(media_type or '').lower() not in ('movie', 'movies')
        own = [r for r in rows if r.get('_meganexus_server')]
        rest = [r for r in rows if not r.get('_meganexus_server')]
        ranked = sorted(enumerate(rest), key=lambda pair: (score(pair[1], prefs, episode), -pair[0]), reverse=True)
        rows = own + [row for _, row in ranked]
    if hardware_only():
        rows = [r for r in rows if not edit_format(r)] + [r for r in rows if edit_format(r)]
    return rows
