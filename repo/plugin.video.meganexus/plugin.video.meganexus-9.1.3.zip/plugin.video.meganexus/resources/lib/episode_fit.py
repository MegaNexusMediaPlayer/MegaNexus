# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.2: a series' sources that are another episode by their own name go last (GitHub: none; the user, on the
Cube: "2, 3 puta pokrenuo Lupin S2E2 i bile su pogrešne epizode ... kako da bolje riješimo epizode i filtriramo
kod sličnih serija da se epizode ne miješaju").

Lupin is numbered two ways: Netflix's, since Part 3 (S1 = chapters 1-10, S2 = Part 3 - the metadata's on the Cube:
10, 7 and 8 episodes), and by its parts (S2 = Part 2, chapters 6-10 - what releases and subtitles of 2021 still say).
An index asked for S2E2 answered with "Lupin S02E07 Chapter 7 ... FLUX" (Part 3's last episode), and Autoplay took
it first for its 2160p and Dolby Vision. Metadata that counts by the parts (S2E2 = chapter 7) meets Netflix's names.

What a source says of itself is weighed against the episode asked for:

* its marker (S02E02, 2x02, Season 2 Episode 2, S02E01-E02): the episode asked for - or the same episode counted
  through the seasons when the marker names one the metadata does not have (S01E07 of a first season of five is
  the seventh episode: S2E2);
* its chapter (Chapter 7, Chapitre 7, Capitolo 7, Poglavlje 7 ...), when the episode's own title has one: the
  same number.

Nothing is hidden: another episode only goes last, and the list says so - a source may be right under a numbering
nobody can tell from its name.
"""
import re

_MARKERS = (
    re.compile(r'(?<![a-z0-9])s(\d{1,2})[ ._-]*e(\d{1,3})(?:[ ._-]*(?:e|-e?)(\d{1,3}))?(?!\d)', re.I),
    re.compile(r'(?<![a-z0-9])(\d{1,2})x(\d{1,3})(?:-(\d{1,3}))?(?!\d)', re.I),
    re.compile(r'season[ ._-]*(\d{1,2})[ ._-]*(?:episode|ep)[ ._-]*(\d{1,3})(?!\d)', re.I),
)
_CHAPTER = re.compile(r'(?<![a-z])(?:chapter|chapitre|capitolo|cap[ií]tulo|kapitel|poglavlje|hoofdstuk|rozdzia[lł]|'
                      r'глава|chap)[ ._-]*(\d{1,3})(?!\d)', re.I)


def markers(text):
    """The (season, episode) pairs a name says - a double episode says both."""
    found = set()
    for pattern in _MARKERS:
        for match in pattern.finditer(str(text or '')):
            season, first = int(match.group(1)), int(match.group(2))
            last = int(match.group(3)) if match.lastindex and match.lastindex >= 3 and match.group(3) else first
            if 0 < season and 0 < first <= last <= first + 3:
                found.update((season, number) for number in range(first, last + 1))
    return found


def chapter(text):
    """The chapter number a name or an episode's title says; 0 when it says none."""
    match = _CHAPTER.search(str(text or ''))
    return int(match.group(1)) if match else 0


def _counts(meta):
    """{season: its number of episodes} of the metadata (specials, season 0, left out)."""
    counts = {}
    for video in (meta or {}).get('videos') or []:
        if not isinstance(video, dict):
            continue
        try:
            season, number = int(video.get('season') or 0), int(video.get('episode') or video.get('number') or 0)
        except (TypeError, ValueError):
            continue
        if season > 0 and number > 0:
            counts[season] = max(counts.get(season, 0), number)
    return counts


def _through(counts, season, episode):
    """The episode counted through the seasons (S2E2 after a first season of five: 7)."""
    return sum(n for s, n in counts.items() if s < season) + episode


def _title(meta, season, episode):
    for video in (meta or {}).get('videos') or []:
        if isinstance(video, dict) and str(video.get('season')) == str(season) and \
                str(video.get('episode') or video.get('number')) == str(episode):
            return str(video.get('title') or video.get('name') or '')
    return ''


def _texts(row):
    hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
    return ' \n'.join(str(value or '') for value in (hints.get('filename'), row.get('title'), row.get('description')))


def other_episode(row, season, episode, meta=None):
    """What a source names instead of the episode asked for ('S02E07', 'Chapter 2'), or '' when it is the episode
    asked for or says nothing that tells."""
    try:
        season, episode = int(season), int(episode)
    except (TypeError, ValueError):
        return ''
    text = _texts(row)
    said = markers(text)
    if said and (season, episode) not in said:
        counts = _counts(meta)
        wanted = _through(counts, season, episode)
        # another numbering of the same episode: a pair the metadata does not have, counted through the seasons
        if not any(counts and n > counts.get(s, 0) and _through(counts, s, n) == wanted for s, n in said):
            s, n = sorted(said)[0]
            return 'S%02dE%02d' % (s, n)
    asked, named = chapter(_title(meta, season, episode)), chapter(text)
    if asked and named and asked != named:
        return 'Chapter %d' % named
    return ''


def arrange(rows, meta, season, episode):
    """The rows with the ones that are another episode by their own name last (each marked '_meganexus_other',
    what it names); nothing for a film, or without a season and an episode."""
    rows = list(rows or [])
    if not season or not episode or str((meta or {}).get('type') or '') == 'movie':
        return rows
    fits, others = [], []
    for row in rows:
        named = other_episode(row, season, episode, meta)
        if named:
            row['_meganexus_other'] = named
            others.append(row)
        else:
            row.pop('_meganexus_other', None)
            fits.append(row)
    return fits + others
