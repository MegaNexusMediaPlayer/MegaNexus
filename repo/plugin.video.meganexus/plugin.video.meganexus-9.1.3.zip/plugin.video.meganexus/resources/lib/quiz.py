# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""Guess It (games branch): MegaNexus' own party quiz - films, series and actors, in English, from TMDB.

The user: "napravit ces nasu igru pogodi film seriju glumca itd napravi brutalno, naravno sve na eng". Each round is
made fresh from TMDB's best-known titles and people (by how many voted: the easy level its first pages, the hard one
further down): a still to recognise as its tiles fall away, a face, a tagline, a story with its names taken out, the
year, the cast, who played whom, who directed it. The wrong answers come from the same pool, the same kind of title
when there is one, so a guess is a real guess. Asked from the quiz's worker only, never from a GUI callback; nothing
is kept once the round is made.
"""
import random
import re
from concurrent.futures import ThreadPoolExecutor

from . import tmdb_api

KINDS = (('mixed', 'Everything'), ('movies', 'Movies'), ('series', 'Series'), ('actors', 'Actors'))
LEVELS = (('easy', 'Easy'), ('medium', 'Medium'), ('hard', 'Hard'))
LENGTHS = (10, 15, 20)
PAGES = {'easy': (1, 5), 'medium': (3, 15), 'hard': (10, 40)}     # TMDB's pages, most voted first
POOL_PAGES = 3
WORKERS = 6
PROFILE = 'https://image.tmdb.org/t/p/h632'
# the question makers each kind of round draws from (each its own way of asking)
MOVIE_ASKS = ('still', 'still', 'tagline', 'year', 'cast', 'character', 'director', 'poster')
SERIES_ASKS = ('still', 'still', 'story', 'year', 'cast', 'character', 'poster')
ACTOR_ASKS = ('face', 'face', 'character', 'starred')
HIDDEN = '_____'                 # a name taken out: a blank to fill (the TV draws it in its colour, meganexus_ui/quiz.py)


class NoKey(Exception):
    """TMDB answers nothing without the user's own key (Settings > API keys)."""


def ready():
    return bool(tmdb_api.api_key())


def _get(path, **params):
    params.setdefault('language', 'en-US')
    return tmdb_api.get(path, params) or {}


def _year(row):
    return str(row.get('release_date') or row.get('first_air_date') or '')[:4]


def _title(row):
    return row.get('title') or row.get('name') or ''


def _pages(level, rng):
    first, last = PAGES[level]
    return rng.sample(range(first, last + 1), min(POOL_PAGES, last - first + 1))


def pool(kind, level, rng):
    """Titles of one kind for a round: [rows] from TMDB's discover lists, most voted first (below the hard level
    English-language ones only - the ones everyone on the sofa may know)."""
    found, seen = [], set()
    path = '/discover/movie' if kind == 'movie' else '/discover/tv'
    extra = {'without_genres': '16,10767,10763,10764'} if kind == 'tv' else {}
    if level != 'hard':
        extra['with_original_language'] = 'en'
    for page in _pages(level, rng):
        rows = _get(path, page=page, sort_by='vote_count.desc', include_adult='false', **extra).get('results') or []
        rows = [r for r in rows if _title(r) and _year(r)]
        for row in rows:
            if row['id'] not in seen and not row.get('adult'):
                seen.add(row['id'])
                found.append(dict(row, media=kind))
    return found


def details(row):
    """A title's details with its credits (its cast in billing order, its crew) and its pictures without words on
    them (a poster or a still with its title on it would give the answer away)."""
    path = ('/movie/%d' if row['media'] == 'movie' else '/tv/%d') % row['id']
    return _get(path, append_to_response='credits,images', include_image_language='null')


def wordless(detail, kind, rng):
    """One of the title's best liked pictures with no words on it ('backdrops' / 'posters'), or ''."""
    rows = [i for i in ((detail.get('images') or {}).get(kind) or []) if not i.get('iso_639_1') and i.get('file_path')]
    rows.sort(key=lambda i: -(i.get('vote_average') or 0))
    return _picture(rng.choice(rows[:3])['file_path'], 'backdrop' if kind == 'backdrops' else 'poster') if rows else ''


def _others(answer, candidates, rng, count=3, key=str, near=0):
    """``count`` wrong answers, different from the answer and from each other - from the first ``near`` candidates
    (the most alike) first."""
    picked, seen = [], {key(answer).lower()}
    first, rest = candidates[:near], candidates[near:]
    for item in rng.sample(first, len(first)) + rng.sample(rest, len(rest)):
        word = key(item).strip()
        if word and word.lower() not in seen:
            seen.add(word.lower())
            picked.append(item)
            if len(picked) == count:
                break
    return picked


def _like(target, rows):
    """The titles most like ``target`` first: sharing a genre, then the rest."""
    genres = set(target.get('genre_ids') or [])
    same = [r for r in rows if r['id'] != target['id'] and genres & set(r.get('genre_ids') or [])]
    return same + [r for r in rows if r['id'] != target['id'] and r not in same]


def _choices(answer, wrong, rng):
    options = [answer] + list(wrong)
    if len(options) < 4:
        return None, None
    rng.shuffle(options)
    return options, options.index(answer)


def mask(text, names):
    """The story without the title's own words and its characters' names, each a blank (HIDDEN)."""
    for name in sorted({n for n in names if n}, key=len, reverse=True):
        for word in re.findall(r"[\w']{3,}", name):
            if word.lower() in ('the', 'and', 'of', 'mr', 'mrs', 'dr'):
                continue
            text = re.sub(r'\b%s\b' % re.escape(word), HIDDEN, text, flags=re.I)
    return text


def _cast(detail, most=8):
    return [c for c in ((detail.get('credits') or {}).get('cast') or [])[:most]
            if c.get('name') and c.get('character') and not re.search(r'\b(self|himself|herself|voice|narrator)\b',
                                                                       c['character'], re.I)]


def _directors(detail):
    return [c['name'] for c in ((detail.get('credits') or {}).get('crew') or []) if c.get('job') == 'Director']


def _picture(path, kind='backdrop'):
    return tmdb_api.picture(path, kind) if path else ''


def ask(way, target, detail, rows, names, rng):
    """One question about ``target`` asked ``way`` - None when its data does not allow it."""
    noun = 'movie' if target['media'] == 'movie' else 'series'
    title, year = _title(target), _year(target)
    after = {'after': '%s (%s)' % (title, year), 'after_picture': _picture(target.get('poster_path'), 'poster')}
    like = _like(target, rows)
    backdrop = wordless(detail, 'backdrops', rng) or _picture(target.get('backdrop_path'))   # beside a question naming it
    titles = lambda: _others(title, [_title(r) for r in like], rng, near=12)     # the same kind of title first
    if way in ('still', 'poster'):
        picture = wordless(detail, 'backdrops' if way == 'still' else 'posters', rng)
        options, answer = _choices(title, titles(), rng)
        if not picture or not options:
            return None
        prompt = 'Which %s is this?' % noun if way == 'still' else 'Name the %s from its poster' % noun
        return dict(after, ask=way, prompt=prompt, picture=picture, tall=way == 'poster', text='', options=options, answer=answer)
    if way in ('tagline', 'story'):
        words = (detail.get('tagline') if way == 'tagline' else detail.get('overview')) or ''
        if len(words) < 12:
            return None
        hidden = mask(words, [title, detail.get('original_title') or detail.get('original_name') or ''] +
                      [c['character'] for c in _cast(detail)])
        if way == 'story' and len(hidden) > 420:
            hidden = hidden[:420].rsplit(' ', 1)[0] + '…'
        options, answer = _choices(title, titles(), rng)
        if not options:
            return None
        prompt = 'Which %s says this?' % noun if way == 'tagline' else 'Which %s is this story?' % noun
        if HIDDEN in hidden:
            # "u pitanjima mi se pojavljuju kod texta neke prazne kockice": what the blanks are, said with them
            prompt += ' (its names are left out)' if way == 'story' else ' (its title is left out)'
        return dict(after, ask=way, prompt=prompt, picture='', text='“%s”' % hidden, options=options, answer=answer)
    if way == 'year':
        if not year.isdigit():
            return None
        now = int(year)
        wrong = rng.sample([str(now + d) for d in (-9, -7, -5, -4, -3, -2, 2, 3, 4, 5, 7) if now + d <= 2026], 3)
        options = sorted([year] + wrong)
        return dict(after, ask=way, prompt='When did %s come out?' % title, picture=backdrop,
                    tall=False, text='', options=options, answer=options.index(year), reveal=False)
    if way == 'cast':
        cast = [c['name'] for c in _cast(detail)][:3]
        options, answer = _choices(title, titles(), rng)
        if len(cast) < 3 or not options:
            return None
        return dict(after, ask=way, prompt='Which %s stars them all?' % noun, picture='', text='[CR]'.join(cast),
                    options=options, answer=answer)
    if way == 'character':
        cast = _cast(detail, 5)
        if not cast or len(names['actors']) < 6:
            return None
        part = rng.choice(cast[:3])
        options, answer = _choices(part['name'], _others(part['name'], names['actors'], rng), rng)
        if not options:
            return None
        return dict(after, ask=way, prompt='Who played %s in %s?' % (part['character'].split('/')[0].strip(), title),
                    picture=backdrop, tall=False, text='', options=options, answer=answer,
                    reveal=False, after_picture=PROFILE + part['profile_path'] if part.get('profile_path') else after['after_picture'])
    if way == 'director':
        directors = _directors(detail)
        if not directors or len(names['directors']) < 4:
            return None
        options, answer = _choices(directors[0], _others(directors[0], names['directors'], rng), rng)
        if not options:
            return None
        return dict(after, ask=way, prompt='Who directed %s?' % title, picture=backdrop,
                    tall=False, text='', options=options, answer=answer, reveal=False)
    return None


def stars(titled, found):
    """The round's actors: the first three billed of its famous titles, with a face - and the title they are in."""
    people, seen = [], set()
    for row in titled:
        for part in _cast(found.get(row['id']) or {}, 3):
            if part.get('profile_path') and part['id'] not in seen:
                seen.add(part['id'])
                people.append({'id': part['id'], 'name': part['name'], 'gender': part.get('gender'),
                               'profile_path': part['profile_path'], 'in': row})
    return people


def ask_person(way, person, people, titles, rng):
    """A question about an actor: their face, or a title they are in."""
    name = person['name']
    same = [p for p in people if p['id'] != person['id'] and p.get('gender') == person.get('gender')] or people
    if way == 'face':
        options, answer = _choices(name, _others(name, [p['name'] for p in same], rng), rng)
        if not options:
            return None
        return dict(ask=way, prompt='Who is this?', picture=PROFILE + person['profile_path'], tall=True, text='',
                    options=options, answer=answer, after=name, after_picture=PROFILE + person['profile_path'])
    if way == 'starred':
        film = person['in']
        options, answer = _choices(_title(film), _others(_title(film), titles, rng), rng)
        if not options:
            return None
        return dict(ask=way, prompt='Which of these is %s in?' % name, picture=PROFILE + person['profile_path'],
                    tall=True, text='', options=options, answer=answer, reveal=False,
                    after='%s (%s)' % (_title(film), _year(film)), after_picture=_picture(film.get('poster_path'), 'poster'))
    return None


def round_of(kind='mixed', level='easy', count=10, rng=None, cancelled=lambda: False):
    """A round: ``count`` questions of ``kind`` at ``level``, each a different title and way of asking where it can.
    Raises NoKey without a TMDB key."""
    if not ready():
        raise NoKey()
    rng = rng or random.Random()
    wanted = {'movies': ('movie',), 'series': ('tv',), 'actors': ('people',),
              'mixed': ('movie', 'tv', 'people')}[kind]
    plan = [wanted[number % len(wanted)] for number in range(count)]
    rng.shuffle(plan)
    lists = ('movie', 'tv') if kind in ('mixed', 'actors') else (('movie',) if kind == 'movies' else ('tv',))
    with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='MegaNexusQuiz') as workers:
        pools = dict(zip(lists, workers.map(lambda k: pool(k, level, rng), lists)))
        if cancelled():
            return []
        movies, shows = pools.get('movie', []), pools.get('tv', [])
        # the actors come from the round's own famous titles: one title more for every two of their questions
        actors = plan.count('people')
        targets = {'movie': rng.sample(movies, min(len(movies), plan.count('movie') + 4 + (actors + 1) // 2)),
                   'tv': rng.sample(shows, min(len(shows), plan.count('tv') + 4 + actors // 2))}
        titled = targets['movie'] + targets['tv']
        found = dict(zip([r['id'] for r in titled], workers.map(details, titled)))
    names = {'actors': [], 'directors': []}
    for detail in found.values():
        names['actors'] += [c['name'] for c in _cast(detail, 6)]
        names['directors'] += _directors(detail)
    names = {k: list(dict.fromkeys(v)) for k, v in names.items()}
    questions, last = [], ''
    used = {'movie': 0, 'tv': 0, 'people': 0}
    people = stars(titled, found)
    people_left = rng.sample(people, len(people))
    for media in plan:
        if cancelled():
            return []
        question = None
        for _attempt in range(6):
            if media == 'people':
                if not people_left:
                    break
                person = people_left.pop()
                way = rng.choice([w for w in ACTOR_ASKS if w != last] or ACTOR_ASKS)
                if way == 'character':
                    way = 'face'
                others = [_title(r) for r in movies + shows if r['id'] != person['in']['id']]
                question = ask_person(way, person, people, others, rng)
            else:
                rows = targets[media]
                if used[media] >= len(rows):
                    break
                target = rows[used[media]]
                used[media] += 1
                asks = MOVIE_ASKS if media == 'movie' else SERIES_ASKS
                way = rng.choice([w for w in asks if w != last] or asks)
                question = ask(way, target, found.get(target['id']) or {}, movies if media == 'movie' else shows, names, rng)
            if question:
                break
        if question:
            question['category'] = {'movie': 'Movie', 'tv': 'Series', 'people': 'Actor'}[media]
            question.setdefault('reveal', bool(question.get('picture')) and question['ask'] in ('still', 'poster', 'face'))
            question.setdefault('tall', False)
            last = question['ask']
            questions.append(question)
    return questions


def points(correct, left, limit, streak):
    """A right answer's points: 500 to 1000 by how fast it came, and 100 more for each in a row past two."""
    if not correct:
        return 0
    fast = max(0.0, min(1.0, left / float(limit)))
    return int(round((500 + 500 * fast) / 10.0)) * 10 + 100 * max(0, streak - 2)
