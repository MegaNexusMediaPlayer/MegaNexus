# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""What really plays, over the title in the player (9.1.1): "4K · Dolby Vision · Dolby Atmos · English 5.1".

The most asked-for thing of the Nuvio apps (NuvioTV #4141): the resolution, HDR, audio format and the
language and channels of the track playing - not what the source's name promised (those are the badges
beside the title). Kodi's own labels of the playing streams, worked out when the picture starts and
again whenever Kodi changes a stream (another audio track, a new resolution: onAVChange), written to
Window(Home) for the skin (review/make_now_playing.py). Nothing for what has no picture.

Atmos and DTS:X: Kodi names the codec so when FFmpeg knows its profile (eac3_ddp_atmos, truehd_atmos,
dtshd_ma_x); a stream it does not know so is told by the track's own name ("English Atmos 7.1").
"""
import json
import re

PROPERTY = 'meganexus.playing.now'
HDR = {'dolbyvision': 'Dolby Vision', 'hdr10plus': 'HDR10+', 'hdr10': 'HDR10', 'hlg': 'HLG'}
AUDIO = {'truehd_atmos': 'Dolby Atmos', 'eac3_ddp_atmos': 'Dolby Atmos', 'truehd': 'Dolby TrueHD',
         'eac3': 'Dolby Digital+', 'ac3': 'Dolby Digital', 'dtshd_ma_x_imax': 'DTS:X IMAX', 'dtshd_ma_x': 'DTS:X',
         'dtshd_ma': 'DTS-HD MA', 'dtshd_hra': 'DTS-HD HRA', 'dca': 'DTS', 'dts': 'DTS', 'aac': 'AAC',
         'aac_latm': 'AAC', 'opus': 'Opus', 'flac': 'FLAC', 'alac': 'ALAC', 'mp3': 'MP3', 'mp3float': 'MP3',
         'mp2': 'MP2', 'vorbis': 'Vorbis'}
CHANNELS = {1: '1.0', 2: '2.0', 3: '2.1', 4: '4.0', 5: '5.0', 6: '5.1', 7: '6.1', 8: '7.1'}
NO_LANGUAGE = ('', 'und', 'unk', 'unknown', 'zxx', 'mis', 'mul')
_ATMOS = re.compile(r'\batmos\b', re.I)
_DTS_X = re.compile(r'\bdts[\s:-]?x\b', re.I)


def _language(code):
    """'eng' -> 'English' (Kodi's own names); a code Kodi does not know stays as it is."""
    code = str(code or '').strip()
    if code.lower() in NO_LANGUAGE:
        return ''
    try:
        import xbmc
        return xbmc.convertLanguage(code, xbmc.ENGLISH_NAME) or code
    except Exception:
        return code


def _audio(codec, track):
    codec = str(codec or '').strip().lower()
    if codec in ('eac3', 'truehd') and _ATMOS.search(track):
        return 'Dolby Atmos'
    if codec == 'dtshd_ma' and _DTS_X.search(track):
        return 'DTS:X'
    if codec.startswith('pcm'):
        return 'PCM'
    return AUDIO.get(codec) or codec.upper()


def line(resolution='', hdr='', codec='', channels='', language='', track=''):
    """The line from Kodi's labels: VideoPlayer.VideoResolution / HdrType / AudioCodec / AudioChannels /
    AudioLanguage, and the playing audio track's name. What is not known is left out, SDR too."""
    parts = []
    resolution = str(resolution or '').strip()
    if resolution:
        parts.append(resolution + 'p' if resolution.isdigit() else resolution)
    if HDR.get(str(hdr or '').strip().lower()):
        parts.append(HDR[str(hdr).strip().lower()])
    audio = _audio(codec, str(track or ''))
    if audio:
        parts.append(audio)
    try:
        count = CHANNELS.get(int(str(channels or '').strip()), '')
    except ValueError:
        count = ''
    sound = ' '.join(part for part in (_language(language), count) if part)
    if sound:
        parts.append(sound)
    return ' · '.join(parts)


def _track_name():
    """The name of the audio track playing ('' when Kodi does not say)."""
    try:
        import xbmc
        reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                                                           'params': {'playerid': 1, 'properties': ['currentaudiostream']}})))
        return str(((reply.get('result') or {}).get('currentaudiostream') or {}).get('name') or '')
    except Exception:
        return ''


def publish():
    """The line for what plays now, or none when nothing with a picture plays. Written only when it changed."""
    try:
        import xbmc
        import xbmcgui
        home = xbmcgui.Window(10000)
        text = ''
        if xbmc.getCondVisibility('Player.HasVideo'):
            label = xbmc.getInfoLabel
            text = line(label('VideoPlayer.VideoResolution'), label('VideoPlayer.HdrType'), label('VideoPlayer.AudioCodec'),
                        label('VideoPlayer.AudioChannels'), label('VideoPlayer.AudioLanguage'), _track_name())
        if home.getProperty(PROPERTY) != text:
            if text:
                home.setProperty(PROPERTY, text)
            else:
                home.clearProperty(PROPERTY)
    except Exception:
        pass


def clear():
    try:
        import xbmcgui
        xbmcgui.Window(10000).clearProperty(PROPERTY)
    except Exception:
        pass
