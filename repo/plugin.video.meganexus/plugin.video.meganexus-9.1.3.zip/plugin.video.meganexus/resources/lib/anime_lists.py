# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""AniList and MyAnimeList (9.1.1, NuvioMobile #763 / #1526): an anime's episode watched here is counted
on the anime's entry there - "watching" and how many episodes are seen, "completed" with its last one.

Which anime: AniList and MyAnimeList keep each season (or part of one) as an anime of its own; Fribb's
list (anime_id_map.episode_entry) says which one an episode is in and its number there - unsure, it is
left alone (never another anime's entry). What changes: the count only goes up (an earlier episode seen
again changes nothing), a completed anime is never touched (unless the service says it is being
watched again: then that count, and "completed" once more at its end).

Signing in is on the phone (phone_setup): AniList's page shows a sign-in token, MyAnimeList's ends on an
address with a code - the phone page takes either back. Kodi has no safe store: the sign-ins are kept in
this profile's files, readable only by Kodi's user, and are never logged or sent back to the page. A
change that could not be sent (no network, the service busy) is tried again at the next playback."""
import base64
import json
import os
import secrets
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .meganexus.paths import profile_path

OUTBOX = 'anime_outbox.json'
KEEP_FOR = 14 * 86400         # a change not sent in two weeks is let go
_LOCK = threading.Lock()


def _path(name):
    return os.path.join(profile_path(), name)


def _read(name, default):
    try:
        with open(_path(name), encoding='utf-8') as handle:
            value = json.load(handle)
        return value if isinstance(value, type(default)) else default
    except (OSError, ValueError):
        return default


def _write(name, value):
    """Atomic, readable only by Kodi's user (a sign-in is in it)."""
    path = _path(name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    handle, temporary = tempfile.mkstemp(dir=os.path.dirname(path), prefix='.%s.' % name)
    try:
        with os.fdopen(handle, 'w', encoding='utf-8') as out:
            json.dump(value, out)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def _forget(name):
    try:
        os.remove(_path(name))
    except OSError:
        pass


def _setting(key):
    try:
        from .settings_snapshot import cached_addon
        return (cached_addon().getSetting(key) or '').strip()
    except Exception:
        return ''


def _log(text):
    try:
        import xbmc
        xbmc.log('[MegaNexus] %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def _call(request, timeout=15):
    with urllib.request.urlopen(request, timeout=timeout) as answer:
        body = answer.read().decode('utf-8', 'ignore')
    return json.loads(body) if body else {}


def _plain(text):
    """A story without the markup AniList / MyAnimeList keep in it."""
    import re
    text = re.sub(r'<br\s*/?>', '\n', str(text or ''), flags=re.I)
    text = re.sub(r'<[^>]+>|\[Written by [^\]]*\]|\(Source: [^)]*\)', '', text)
    return re.sub(r'\n{3,}', '\n\n', text).strip()


def _epoch(value):
    from datetime import datetime
    try:
        return int(datetime.fromisoformat(str(value).replace('Z', '+00:00')).timestamp()) if value else 0
    except (TypeError, ValueError, OverflowError):
        return 0


def _version():
    try:
        from .settings_snapshot import cached_addon
        return cached_addon().getAddonInfo('version') or '9'
    except Exception:
        return '9'


class Service(object):
    """One anime list: its sign-in, its entry of an anime, a change to it."""
    ID = NAME = TOKEN = KEY_SETTING = DEFAULT_CLIENT_ID = APP_PAGE = ''

    @classmethod
    def client_id(cls):
        return _setting(cls.KEY_SETTING) or cls.DEFAULT_CLIENT_ID

    @classmethod
    def token(cls):
        return _read(cls.TOKEN, {})

    @classmethod
    def connected(cls):
        return bool(cls.token().get('access_token'))

    @classmethod
    def user(cls):
        return str(cls.token().get('user') or '')

    @classmethod
    def logout(cls):
        _forget(cls.TOKEN)

    @classmethod
    def _refused(cls):
        """The service no longer takes the sign-in: Kodi's notice once (account_notice), the sign-in kept
        until the user signs in again or out (a passing fault must not sign anyone out)."""
        try:
            from .account_notice import signed_out
            signed_out(cls.NAME, cls.token().get('access_token') or '')
        except Exception:
            pass


class AniList(Service):
    """AniList's implicit grant with its "pin" page: no secret, the token (a year) shown to copy."""
    ID, NAME, TOKEN = 'anilist', 'AniList', 'anilist_token.json'
    KEY_SETTING = 'anilist_client_id'
    DEFAULT_CLIENT_ID = '56130'     # MegaNexus's own AniList client (public, no secret; Redirect URL: the pin page)
    APP_PAGE = 'https://anilist.co/settings/developer'
    REDIRECT = 'https://anilist.co/api/v2/oauth/pin'
    API = 'https://graphql.anilist.co'
    # their list's states -> ours (REPEATING: a completed anime watched again)
    STATES = {'CURRENT': 'watching', 'PLANNING': 'planning', 'COMPLETED': 'completed', 'DROPPED': 'dropped',
              'PAUSED': 'paused', 'REPEATING': 'rewatching'}
    SENT = {'watching': 'CURRENT', 'completed': 'COMPLETED', 'rewatching': 'REPEATING'}

    @classmethod
    def start(cls):
        return {'url': 'https://anilist.co/api/v2/oauth/authorize?client_id=%s&response_type=token'
                       % urllib.parse.quote(cls.client_id())}

    @classmethod
    def _ask(cls, query, variables=None, token=None):
        token = token or cls.token().get('access_token') or ''
        request = urllib.request.Request(cls.API, data=json.dumps({'query': query, 'variables': variables or {}}).encode('utf-8'),
                                         headers={'Content-Type': 'application/json', 'Accept': 'application/json',
                                                  'Authorization': 'Bearer ' + token,
                                                  'User-Agent': 'MegaNexus/%s (Kodi)' % _version()}, method='POST')
        try:
            answer = _call(request)
        except urllib.error.HTTPError as exc:
            # AniList answers an ended or withdrawn token with 400 / 401 "Invalid token"
            try:
                said = exc.read().decode('utf-8', 'ignore').lower()
            except Exception:
                said = ''
            if exc.code in (400, 401) and 'token' in said and token == cls.token().get('access_token'):
                cls._refused()
            raise
        if answer.get('errors') and not answer.get('data'):
            raise ValueError('AniList: %s' % str((answer['errors'][0] or {}).get('message') or 'refused')[:120])
        return answer.get('data') or {}

    @staticmethod
    def _expires(token):
        """When the token ends (its own "exp"; a year when it says none)."""
        try:
            part = token.split('.')[1]
            return int(json.loads(base64.urlsafe_b64decode(part + '=' * (-len(part) % 4)).decode('utf-8'))['exp'])
        except Exception:
            return int(time.time()) + 365 * 86400

    @classmethod
    def finish(cls, text):
        token = ''.join(str(text or '').split())
        if token.count('.') != 2 or len(token) < 40:
            raise ValueError('Paste the whole token AniList shows after you approve (a long text with two dots).')
        try:
            viewer = (cls._ask('query { Viewer { id name } }', token=token) or {}).get('Viewer') or {}
        except urllib.error.HTTPError as exc:
            raise ValueError('AniList did not take this token (%s). Approve again and copy the new one.' % exc.code)
        except urllib.error.URLError:
            raise ValueError('AniList could not be reached. Check the connection and try again.')
        if not viewer.get('id'):
            raise ValueError('AniList did not take this token. Approve again and copy the new one.')
        _write(cls.TOKEN, {'access_token': token, 'user': str(viewer.get('name') or ''), 'user_id': int(viewer['id']),
                           'expires_at': cls._expires(token), 'created_at': int(time.time())})
        return {'user': str(viewer.get('name') or '')}

    @classmethod
    def entry(cls, anime):
        data = cls._ask('query ($id: Int) { Media(id: $id, type: ANIME) { id episodes mediaListEntry { id status progress repeat } } }',
                        {'id': int(anime)})
        media = data.get('Media') or {}
        mine = media.get('mediaListEntry') or {}
        return {'status': cls.STATES.get(mine.get('status'), ''), 'progress': int(mine.get('progress') or 0),
                'repeat': int(mine.get('repeat') or 0), 'total': int(media.get('episodes') or 0), 'entry_id': mine.get('id')}

    @classmethod
    def _viewer(cls):
        """The signed-in user's id (kept with the sign-in; asked once for one made before it was kept)."""
        signed = cls.token()
        if signed.get('user_id'):
            return int(signed['user_id'])
        viewer = (cls._ask('query { Viewer { id name } }') or {}).get('Viewer') or {}
        if not viewer.get('id'):
            raise ValueError('AniList did not say who is signed in.')
        _write(cls.TOKEN, dict(signed, user_id=int(viewer['id']), user=signed.get('user') or str(viewer.get('name') or '')))
        return int(viewer['id'])

    ASKED = dict((ours, theirs) for theirs, ours in STATES.items())

    @classmethod
    def listed(cls, statuses=('watching', 'rewatching', 'planning'), most=None):
        """The entries of the lists ``statuses`` (ours: watching, rewatching, planning, paused, completed), each
        with its status and when it last changed (9.1.1: the Library's sections ask for more than its
        Watching and Plan to watch). AniList gives a whole list at once: ``most`` is not needed here."""
        wanted = ', '.join(cls.ASKED[status] for status in statuses if status in cls.ASKED)
        data = cls._ask('query ($user: Int) { MediaListCollection(userId: $user, type: ANIME, status_in: [%s]) '
                        '{ lists { entries { status createdAt updatedAt media { id status title { english romaji } coverImage { large } '
                        'description(asHtml: false) seasonYear } } } } }' % wanted, {'user': cls._viewer()})
        out = []
        for group in (data.get('MediaListCollection') or {}).get('lists') or []:
            for entry in group.get('entries') or []:
                media = entry.get('media') or {}
                if not media.get('id'):
                    continue
                title = media.get('title') or {}
                out.append({'anime': str(media['id']), 'title': str(title.get('english') or title.get('romaji') or ''),
                            'poster': str((media.get('coverImage') or {}).get('large') or ''), 'plot': _plain(media.get('description')),
                            'year': int(media.get('seasonYear') or 0),
                            'added_at': int(entry.get('createdAt') or entry.get('updatedAt') or 0),
                            'changed_at': int(entry.get('updatedAt') or entry.get('createdAt') or 0),
                            'status': cls.STATES.get(entry.get('status'), ''), 'airing': media.get('status') == 'RELEASING'})
        return out

    @classmethod
    def plan(cls, anime):
        cls._ask('mutation ($id: Int) { SaveMediaListEntry(mediaId: $id, status: PLANNING) { id } }', {'id': int(anime)})

    @classmethod
    def drop(cls, anime, entry):
        cls._ask('mutation ($id: Int) { DeleteMediaListEntry(id: $id) { deleted } }', {'id': int(entry['entry_id'])})

    @classmethod
    def save(cls, anime, change):
        variables = {'id': int(anime), 'progress': change['progress'], 'status': cls.SENT[change['status']]}
        if change.get('repeat') is not None:
            variables['repeat'] = change['repeat']
        names = [name for name in ('progress', 'status', 'repeat') if name in variables]
        kinds = {'progress': 'Int', 'status': 'MediaListStatus', 'repeat': 'Int'}
        cls._ask('mutation ($id: Int, %s) { SaveMediaListEntry(mediaId: $id, %s) { id } }'
                 % (', '.join('$%s: %s' % (n, kinds[n]) for n in names), ', '.join('%s: $%s' % (n, n) for n in names)), variables)


class MyAnimeList(Service):
    """MyAnimeList's authorization code with PKCE (an "other" app: no secret); the code comes back on the
    address its page ends on, the phone page takes that. The sign-in lasts a month and is renewed."""
    ID, NAME, TOKEN = 'mal', 'MyAnimeList', 'mal_token.json'
    KEY_SETTING = 'mal_client_id'
    DEFAULT_CLIENT_ID = '26532656742df5680286cc8904f19747'   # MegaNexus's own MyAnimeList app (type other: no secret)
    APP_PAGE = 'https://myanimelist.net/apiconfig'
    REDIRECT = 'http://localhost'
    AUTHORIZE = 'https://myanimelist.net/v1/oauth2/authorize'
    TOKEN_URL = 'https://myanimelist.net/v1/oauth2/token'
    API = 'https://api.myanimelist.net/v2'
    PENDING = 'mal_pending.json'     # the sign-in begun: its check (PKCE) and state, a quarter of an hour
    STATES = {'watching': 'watching', 'plan_to_watch': 'planning', 'completed': 'completed', 'dropped': 'dropped',
              'on_hold': 'paused'}

    @classmethod
    def start(cls):
        verifier, state = secrets.token_urlsafe(96)[:128], secrets.token_urlsafe(16)
        _write(cls.PENDING, {'verifier': verifier, 'state': state, 'until': int(time.time()) + 900})
        return {'url': '%s?%s' % (cls.AUTHORIZE, urllib.parse.urlencode({
            'response_type': 'code', 'client_id': cls.client_id(), 'code_challenge': verifier,
            'code_challenge_method': 'plain', 'state': state}))}

    @classmethod
    def _grant(cls, fields):
        request = urllib.request.Request(cls.TOKEN_URL, data=urllib.parse.urlencode(dict(fields, client_id=cls.client_id())).encode('utf-8'),
                                         headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
                                         method='POST')
        answer = _call(request)
        if not answer.get('access_token'):
            raise ValueError('MyAnimeList did not sign in.')
        return answer

    @classmethod
    def _keep(cls, answer, user):
        _write(cls.TOKEN, {'access_token': answer['access_token'], 'refresh_token': answer.get('refresh_token') or '',
                           'expires_at': int(time.time()) + int(answer.get('expires_in') or 2592000), 'user': user,
                           'created_at': int(time.time())})

    @classmethod
    def finish(cls, text):
        text = str(text or '').strip()
        pending = _read(cls.PENDING, {})
        if not pending.get('verifier') or pending.get('until', 0) < time.time():
            raise ValueError('Tap Connect again: the sign-in was begun too long ago.')
        query = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(text).query)) if '?' in text else {}
        code = query.get('code') or ('' if '=' in text or '/' in text else text)
        if not code:
            raise ValueError('Paste the whole address the page ended on (it starts with http://localhost/?code=).')
        if query.get('state') and query['state'] != pending.get('state'):
            raise ValueError('This address is from another sign-in. Tap Connect again.')
        try:
            answer = cls._grant({'grant_type': 'authorization_code', 'code': code, 'code_verifier': pending['verifier']})
            me = cls._get('/users/@me', token=answer['access_token'])
        except urllib.error.HTTPError as exc:
            raise ValueError('MyAnimeList did not take this code (%s). Tap Connect again.' % exc.code)
        except urllib.error.URLError:
            raise ValueError('MyAnimeList could not be reached. Check the connection and try again.')
        cls._keep(answer, str(me.get('name') or ''))
        _forget(cls.PENDING)
        return {'user': str(me.get('name') or '')}

    @classmethod
    def _fresh(cls):
        """The access token - renewed when it ends within a day (its refresh token, read again first:
        another Kodi Python may just have renewed it)."""
        signed = cls.token()
        if signed.get('expires_at', 0) - 86400 > time.time() or not signed.get('refresh_token'):
            return signed.get('access_token') or ''
        with _LOCK:
            again = cls.token()
            if again.get('access_token') != signed.get('access_token'):
                return again.get('access_token') or ''
            try:
                answer = cls._grant({'grant_type': 'refresh_token', 'refresh_token': signed['refresh_token']})
            except urllib.error.HTTPError as exc:
                if exc.code in (400, 401):
                    cls._refused()
                raise
            cls._keep(answer, signed.get('user') or '')
            return answer['access_token']

    @classmethod
    def _get(cls, path, token=None, data=None, method='GET'):
        token = token or cls._fresh()
        request = urllib.request.Request(cls.API + path, data=urllib.parse.urlencode(data).encode('utf-8') if data else None,
                                         headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/json',
                                                  'Content-Type': 'application/x-www-form-urlencoded'}, method=method)
        try:
            return _call(request)
        except urllib.error.HTTPError as exc:
            if exc.code == 401 and token == cls.token().get('access_token'):
                cls._refused()
            raise

    @classmethod
    def entry(cls, anime):
        # 9.1.1: my_list_status gives the count of times watched again only when asked for by name - without it a
        # rewatch finished was saved as the first one
        data = cls._get('/anime/%d?fields=num_episodes,my_list_status{status,num_episodes_watched,is_rewatching,'
                        'num_times_rewatched}' % int(anime))
        mine = data.get('my_list_status') or {}
        status = 'rewatching' if mine.get('is_rewatching') else cls.STATES.get(mine.get('status'), '')
        return {'status': status, 'progress': int(mine.get('num_episodes_watched') or 0),
                'repeat': int(mine.get('num_times_rewatched') or 0), 'total': int(data.get('num_episodes') or 0)}

    ASKED = {'watching': 'watching', 'planning': 'plan_to_watch', 'paused': 'on_hold', 'completed': 'completed',
             'rewatching': 'completed'}      # watched again: a completed one MyAnimeList marks so

    @classmethod
    def listed(cls, statuses=('watching', 'planning'), most=None):
        """The entries of the lists ``statuses`` (ours), each with its status and when it last changed;
        ``most``: the latest that many of each list (9.1.1: the Library's sections - a Completed list can be
        thousands long), else every one (a hundred a page, two thousand at most)."""
        out = []
        for status in dict.fromkeys(cls.ASKED[status] for status in statuses if status in cls.ASKED):
            query = {'status': status, 'limit': min(100, most or 100), 'nsfw': 'true',
                     'fields': 'list_status,synopsis,start_season,alternative_titles,status'}
            if most:
                query['sort'] = 'list_updated_at'
            path, pages, taken = '/users/@me/animelist?' + urllib.parse.urlencode(query), 0, 0
            while path and pages < 20 and not (most and taken >= most):
                data = cls._get(path)
                for row in data.get('data') or []:
                    node, mine = row.get('node') or {}, row.get('list_status') or {}
                    ours = 'rewatching' if mine.get('is_rewatching') else cls.STATES.get(mine.get('status') or status, '')
                    if not node.get('id') or ours not in statuses:
                        continue
                    picture = node.get('main_picture') or {}
                    out.append({'anime': str(node['id']),
                                'title': str((node.get('alternative_titles') or {}).get('en') or node.get('title') or ''),
                                'poster': str(picture.get('large') or picture.get('medium') or ''), 'plot': _plain(node.get('synopsis')),
                                'year': int((node.get('start_season') or {}).get('year') or 0), 'added_at': _epoch(mine.get('updated_at')),
                                'changed_at': _epoch(mine.get('updated_at')), 'status': ours,
                                'airing': node.get('status') == 'currently_airing'})
                    taken += 1
                after = str((data.get('paging') or {}).get('next') or '')
                path, pages = (after[len(cls.API):] if after.startswith(cls.API) else ''), pages + 1
        return out

    @classmethod
    def plan(cls, anime):
        cls._get('/anime/%d/my_list_status' % int(anime), data={'status': 'plan_to_watch'}, method='PATCH')

    @classmethod
    def drop(cls, anime, entry):
        cls._get('/anime/%d/my_list_status' % int(anime), method='DELETE')

    @classmethod
    def save(cls, anime, change):
        fields = {'num_watched_episodes': change['progress'],
                  'status': 'watching' if change['status'] == 'watching' else 'completed',
                  'is_rewatching': 'true' if change['status'] == 'rewatching' else 'false'}
        if change.get('repeat') is not None:
            fields['num_times_rewatched'] = change['repeat']
        cls._get('/anime/%d/my_list_status' % int(anime), data=fields, method='PATCH')


SERVICES = (AniList, MyAnimeList)
BY_ID = dict((service.ID, service) for service in SERVICES)
ID_OF = {'anilist': 'anilist_id', 'mal': 'mal_id'}


def connected():
    return [service for service in SERVICES if service.connected()]


def change(entry, episode):
    """What the entry becomes once ``episode`` was watched: {'status': watching | completed | rewatching,
    'progress', 'repeat' (only when it grows)} - None when it stays as it is."""
    status, progress, total = entry.get('status') or '', int(entry.get('progress') or 0), int(entry.get('total') or 0)
    if episode < 1 or (total and episode > total):
        return None                    # not this anime's episode: the list and the service disagree
    if episode <= progress or status == 'completed':
        return None                    # seen before, or an anime done (watched again only when it says so)
    done = bool(total) and episode >= total
    if status == 'rewatching':
        return ({'status': 'completed', 'progress': total, 'repeat': int(entry.get('repeat') or 0) + 1} if done
                else {'status': 'rewatching', 'progress': episode})
    return {'status': 'completed', 'progress': total} if done else {'status': 'watching', 'progress': episode}


def target(ctx):
    """The anime of a playback and its episode there ({} when it is no anime, or not known for sure)."""
    from . import anime_id_map
    ctx = ctx or {}
    ids = dict(ctx.get('external_ids') or {}) if isinstance(ctx.get('external_ids'), dict) else {}
    for key in ('imdb_id', 'tmdb_id', 'tvdb_id'):
        if ctx.get(key):
            ids[key] = str(ctx[key])
    canonical = str(ctx.get('canonical_id') or '')
    if canonical.startswith('tt'):
        ids.setdefault('imdb_id', canonical.split(':')[0])
    video = str(ctx.get('video_id') or '')
    anime_video = video if video.split(':')[0].lower() in dict(anime_id_map.ANIME_PREFIXES) else (
        canonical if canonical.split(':')[0].lower() in dict(anime_id_map.ANIME_PREFIXES) else '')
    return anime_id_map.episode_entry(ids, str(ctx.get('media_type') or ''), ctx.get('season'), ctx.get('episode'),
                                      absolute=ctx.get('absolute_episode') or 0, video_id=anime_video)


def _send(service, anime, episode):
    """One service's entry brought up to ``episode``: True when it is as it should be."""
    now = service.entry(anime)
    wanted = change(now, episode)
    if wanted:
        service.save(anime, wanted)
        _log('%s: an anime counted at episode %d (%s)' % (service.NAME, wanted['progress'], wanted['status']))
    return True


def _passing(exc):
    """A fault worth trying again later: no network, or the service busy / down."""
    if isinstance(exc, urllib.error.HTTPError):
        return exc.code == 429 or exc.code >= 500
    return isinstance(exc, (urllib.error.URLError, OSError, TimeoutError))


def _queue(service, anime, episode):
    with _LOCK:
        rows = [r for r in _read(OUTBOX, []) if isinstance(r, dict) and not (r.get('service') == service.ID and r.get('anime') == anime)]
        _write(OUTBOX, (rows + [{'service': service.ID, 'anime': anime, 'episode': episode, 'at': int(time.time())}])[-50:])


def _sync(service, anime, episode):
    try:
        return _send(service, anime, episode)
    except Exception as exc:
        _log('%s: the anime\'s episode not sent (%s)' % (service.NAME, getattr(exc, 'code', '') or type(exc).__name__))
        if _passing(exc):
            _queue(service, anime, episode)
        return False


def watched(ctx):
    """A playback watched to its end: each connected list told (behind the player - the report thread)."""
    services = connected()
    if not services:
        return []
    found = target(ctx)
    if not found:
        return []
    return [_sync(service, found[ID_OF[service.ID]], found['episode'])
            for service in services if found.get(ID_OF[service.ID])]


def retry():
    """The changes left unsent, tried again (a playback starting: the network is up)."""
    with _LOCK:
        rows = _read(OUTBOX, [])
        if not rows:
            return 0
        _forget(OUTBOX)
    sent = 0
    for row in rows:
        service = BY_ID.get(str(row.get('service') or ''))
        if not service or not service.connected() or row.get('at', 0) + KEEP_FOR < time.time():
            continue
        sent += bool(_sync(service, str(row.get('anime') or ''), int(row.get('episode') or 0)))
    return sent


def status():
    """What the phone page and HUB Settings show - never a token."""
    return dict((service.ID, {'name': service.NAME, 'connected': service.connected(), 'user': service.user(),
                              'app': bool(service.client_id()), 'app_page': service.APP_PAGE, 'redirect': service.REDIRECT})
                for service in SERVICES)


SHOWN = ('watching', 'rewatching', 'planning')     # the entries the Library shows: Watching and Plan to watch


def library_rows(service_id):
    """9.1.1: the service's Watching and Plan to watch as the Library's rows - one card per title here (a
    show's seasons and parts there are one card, by its first one's name and picture; an anime the list
    of ids knows no title of is left out); [] signed out. Raises when the service cannot be read."""
    service = BY_ID[service_id]
    if not service.connected():
        return []
    return _merged(service_id, service.listed())


def _merged(service_id, entries):
    """Their entries as rows here, one per title (its first season's or part's name and picture, the
    latest change of any of them)."""
    from . import anime_id_map
    cards = {}
    for entry in entries:
        found = anime_id_map.title_of(ID_OF[service_id], entry['anime'])
        if not found:
            continue
        key = (found['media_type'], found['canonical_id'])
        card = cards.get(key)
        row = {'media_type': found['media_type'], 'canonical_id': found['canonical_id'], 'title': entry['title'],
               'poster': entry['poster'], 'background': '', 'clearlogo': '', 'year': entry['year'], 'plot': entry['plot'],
               'added_at': entry['added_at'], 'order': found['order']}
        if card is None or row['order'] < card['order']:
            row['added_at'] = max(row['added_at'], card['added_at']) if card else row['added_at']
            cards[key] = row
        else:
            card['added_at'] = max(card['added_at'], row['added_at'])
    return [dict((k, v) for k, v in row.items() if k != 'order') for row in cards.values()]


# 9.1.1: the Library's sections of an anime list (library_sections): id, title, the statuses in it
SECTIONS = (('watching', 'Watching', ('watching', 'rewatching')), ('planning', 'Plan to watch', ('planning',)),
            ('paused', 'Paused', ('paused',)), ('completed', 'Completed', ('completed',)))
SECTION_MOST = 60          # titles in a section at most (the latest changed first)
AIRING = ('watching', 'rewatching', 'planning')     # 9.1.1: "Airing now" - of these, what still has episodes coming


def section_rows(service_id, most=SECTION_MOST):
    """[(id, title, rows)] of one anime list - Airing now (of Watching and Plan to watch), Watching (watched again
    too), Plan to watch, Paused, Completed -
    each one card per title as library_rows makes them, the latest changed first; [] signed out. Raises when
    the service cannot be read."""
    service = BY_ID[service_id]
    if not service.connected():
        return []
    entries = sorted(service.listed(tuple(s for _id, _title, states in SECTIONS for s in states), most=most),
                     key=lambda entry: -int(entry.get('changed_at') or 0))
    # what of yours is out week by week now: watched or planned ("airing now from your list")
    out = [('airing', 'Airing now', _merged(service_id, [entry for entry in entries if entry.get('airing') and
                                                         entry.get('status') in AIRING])[:most])]
    for section, title, states in SECTIONS:
        rows = _merged(service_id, [entry for entry in entries if entry.get('status') in states])
        out.append((section, title, rows[:most]))        # in the order of their latest change
    return out


def _parts(service_id, item):
    from . import anime_id_map
    ids = dict((key, str(item.get(key))) for key in ('imdb_id', 'tmdb_id', 'tvdb_id') if item.get(key))
    canonical = str(item.get('canonical_id') or '')
    prefix, _sep, rest = canonical.partition(':')
    if canonical.startswith('tt'):
        ids.setdefault('imdb_id', canonical.split(':')[0])
    elif prefix in ('tmdb', 'kitsu', 'anilist', 'mal') and rest:
        ids.setdefault(prefix + '_id', rest.split(':')[0])
    media = 'movie' if str(item.get('media_type') or '') == 'movie' else 'series'
    return [part[ID_OF[service_id]] for part in anime_id_map.parts_of(ids, media) if part.get(ID_OF[service_id])]


def plan(service_id, item):
    """A title saved in the Library: its (first) anime to Plan to watch - one already on the list is left as
    it is. True when it is on the list among what the Library shows (Watching, Plan to watch)."""
    service = BY_ID[service_id]
    parts = _parts(service_id, item) if service.connected() else []
    if not parts:
        return False
    status = service.entry(parts[0])['status']
    if status:
        return status in SHOWN
    service.plan(parts[0])
    return True


def unplan(service_id, item, force=False):
    """A title taken out of the Library: its anime that wait on Plan to watch off the list - those being
    watched too when it is asked for by name (``force``: "Remove from AniList"), never a finished, paused or
    dropped one (their count would be lost). True when one went."""
    service = BY_ID[service_id]
    gone = False
    for anime in (_parts(service_id, item) if service.connected() else []):
        entry = service.entry(anime)
        if entry['status'] in (SHOWN if force else ('planning',)):
            service.drop(anime, entry)
            gone = True
    return gone


def set_app(service_id, client_id):
    """An own app's client ID (public - no secret), for the service without MegaNexus's built in."""
    service = BY_ID.get(service_id)
    client_id = str(client_id or '').strip()
    if not service:
        raise ValueError('Unknown anime list.')
    if not client_id or any(ch.isspace() for ch in client_id) or len(client_id) > 80:
        raise ValueError('Paste the client ID of your %s app.' % service.NAME)
    from .meganexus.paths import writer
    writer().setSetting(service.KEY_SETTING, client_id)
    from . import settings_snapshot
    settings_snapshot.invalidate()
    return status()


def begin(service_id):
    service = BY_ID.get(service_id)
    if not service:
        raise ValueError('Unknown anime list.')
    if not service.client_id():
        raise ValueError('Add the client ID of your %s app first.' % service.NAME)
    return service.start()


def finish(service_id, text):
    service = BY_ID.get(service_id)
    if not service:
        raise ValueError('Unknown anime list.')
    found = service.finish(text)
    _log('%s connected' % service.NAME)
    from . import anime_id_map
    anime_id_map.ensure_async()          # Fribb's list ready before the first episode ends (it is not built while one plays)
    return dict(found, status=status())


def disconnect(service_id):
    service = BY_ID.get(service_id)
    if not service:
        raise ValueError('Unknown anime list.')
    service.logout()
    return status()
