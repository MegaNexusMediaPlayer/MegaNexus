# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""9.1.2: what language a subtitle's lines are in - not only what it is called.

On the Cube a "Croatian" subtitle of Lupin (the MegaNexus source's own, the same file on OpenSubtitles) was
Hungarian ("A NETFLIX SAJÁT GYÁRTÁSÚ SOROZATA", "Menekülj!"); it went on by itself as Croatian - "automatski mi
je stavio neki turski". A subtitle's lines are read for the most common words of each language; one that clearly
speaks another than its name says is passed over for the next. When it cannot be told (a language not known
here, too few words, two languages alike) it counts as what it says it is.

Every language a user may choose is weighed the same way: first its alphabet (a Greek one written in Latin letters,
a Croatian one in Cyrillic, a Japanese one without kana is another), then - for the languages whose common words
are known here - its words. Serbian and Bosnian are right in either alphabet.
"""
import re

_WORDS = {
    'hr': 'je i da se ne što sam to u na li su mi ti nije ovo za kako ali ja me bi sve smo ste će hoću možeš znam gdje'
          ' је и да се не шта што сам то у на ли су ми ти није ово за како али ја ме би све смо сте ће знам где',
    'sl': 'je in da se ne to na v sem kaj ki pa so bi za ti mi ja tako si še ali me bo nisem res kje zdaj',
    'en': "the you i to a and it is of that what in me we this don't no yes he for on be not have are do was my your",
    'de': 'ich du die der und das ist nicht sie es wir zu ein mit was den er ja nein mir dich auf hier so aber wie eine',
    'fr': 'je tu le la les de et pas vous est un une que il ce on à qui en ne des du nous mais oui non moi ça',
    'es': 'que de no la el y es en lo un me por qué se los te una con para mi está si bien pero yo eso las sí',
    'it': 'che di non il è e la un per mi sono ho ma si lo ti una in cosa questo del le qui bene no sì perché ci',
    'pt': 'que não de o a é e um eu você se do da uma me em os isso para com está mas no na sim muito bem aqui',
    'nl': 'ik je het de een is niet dat en wat van we hij ze in op dit zijn maar er met ja nee mij hier goed wel',
    'pl': 'nie to się w i na jest że co ja z mnie tak do jak ty ale mi już tu czy o go jesteś dobrze wiem być',
    'cs': 'je to se na že ne jsem v a co tak mi jak ale už jsi by tady jo mě ty do s není bude jen jsme',
    'hu': 'a az és nem hogy van is egy de ez mi meg már csak én te itt mit jó volt ki még vagy igen most nincs kell így',
    'ro': 'nu și să e în de ce la un o mă pe că am ai este asta eu tu cu sunt da mai dar bine aici ești acum',
    'tr': 'bir ve bu ne de da mi ben sen için çok var yok ama o şey gibi evet hayır daha şimdi nasıl sana beni bana',
    'sv': 'jag du det är inte att och en som vi har på vad med för han här så hon ja nej mig dig kan',
    'da': 'jeg du det er ikke at og en der vi har på hvad med for han her så hun ja nej mig dig kan',
    'no': 'jeg du det er ikke at og en som vi har på hva med for han her så hun ja nei meg deg kan',
    'fi': 'on ei se ja minä sinä että mitä en me hän olen tämä mutta kun no nyt niin oli joo tule',
    'ru': 'и в не я что на ты он с это а как мы да вы но так все она мне меня его у там нет только было здесь же вот',
    'uk': 'і в не я що на ти він з це а як ми так ви але все вона мені мене його у там ні тільки було тут й та',
    'bg': 'и в не да се на е ти той с това а как ние за вие но така всичко тя ми ме го там само беше тук съм си',
    'mk': 'и во не да се на е ти тој со ова а како ние за вие но така сè таа ми ме го таму само беше тука сум си',
}
_WORDS = {code: set(words.split()) for code, words in _WORDS.items()}
# one tongue under several names: a Serbian or a Bosnian subtitle is right for Croatian; close neighbours are never
# taken for each other
_SAME = {'sr': 'hr', 'bs': 'hr', 'sh': 'hr', 'sk': 'cs', 'nb': 'no', 'nn': 'no', 'pb': 'pt'}
_NEAR = ({'hr', 'sl'}, {'da', 'no', 'sv'}, {'es', 'pt'}, {'cs', 'pl'}, {'ru', 'uk'}, {'bg', 'mk'}, {'hr', 'mk'})
_TOKEN = re.compile(r"[^\W\d_]+(?:'[^\W\d_]+)?", re.U)
# the alphabets, by their Unicode blocks
_ALPHABETS = (
    ('latin', '\u0041-\u005a\u0061-\u007a\u00c0-\u024f\u1e00-\u1eff'), ('cyrillic', '\u0400-\u052f'),
    ('greek', '\u0370-\u03ff\u1f00-\u1fff'), ('arabic', '\u0600-\u06ff\u0750-\u077f\ufb50-\ufdff\ufe70-\ufeff'),
    ('hebrew', '\u0590-\u05ff'), ('thai', '\u0e00-\u0e7f'), ('han', '\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff'),
    ('kana', '\u3040-\u30ff\u31f0-\u31ff'), ('hangul', '\u1100-\u11ff\u3130-\u318f\uac00-\ud7af'),
    ('devanagari', '\u0900-\u097f'), ('bengali', '\u0980-\u09ff'), ('tamil', '\u0b80-\u0bff'),
    ('telugu', '\u0c00-\u0c7f'), ('kannada', '\u0c80-\u0cff'), ('malayalam', '\u0d00-\u0d7f'),
    ('georgian', '\u10a0-\u10ff'), ('armenian', '\u0530-\u058f'))
_ALPHABETS = tuple((name, re.compile('[%s]' % chars)) for name, chars in _ALPHABETS)
# each language's alphabets; a language not here is not judged by its alphabet
_WRITTEN = dict(
    [(code, {'latin'}) for code in ('hr sl en de fr es it pt pb nl pl cs sk hu ro tr sv da no nb nn fi vi id ms et lv '
                                    'lt sq is ga eu ca gl af sw tl mt cy eo lb fo').split()] +
    [(code, {'cyrillic'}) for code in 'ru uk bg mk be mn'.split()] +
    [(code, {'latin', 'cyrillic'}) for code in 'sr bs sh kk uz'.split()] +
    [(code, {'arabic'}) for code in 'ar fa ur ps'.split()] + [(code, {'hebrew'}) for code in 'he iw yi'.split()] +
    [(code, {'devanagari'}) for code in 'hi mr ne'.split()] +
    [('el', {'greek'}), ('th', {'thai'}), ('zh', {'han'}), ('ja', {'han', 'kana'}), ('ko', {'hangul'}),
     ('bn', {'bengali'}), ('ta', {'tamil'}), ('te', {'telugu'}), ('kn', {'kannada'}), ('ml', {'malayalam'}),
     ('ka', {'georgian'}), ('hy', {'armenian'})])
_SAID = {'greek': 'el', 'arabic': 'ar', 'hebrew': 'he', 'thai': 'th', 'hangul': 'ko', 'devanagari': 'hi',
         'bengali': 'bn', 'tamil': 'ta', 'telugu': 'te', 'kannada': 'kn', 'malayalam': 'ml', 'georgian': 'ka',
         'armenian': 'hy'}
LEAST = 60            # words a subtitle needs before it is judged
CLEAR = 0.12          # share of its words that are the other language's common ones...
TIMES = 2.0           # ...and this many times the share of the language it says it is
MOSTLY = 0.5          # share of its letters in one alphabet that makes it that alphabet's
KANA = 0.05           # share of kana among its Chinese characters below which a "Japanese" one is Chinese


def _group(code):
    code = str(code or '').lower()
    return _SAME.get(code, code)


def alphabet(text):
    """(the alphabet most of ``text``'s letters are in, their share, the share of kana among its CJK letters)."""
    counts = {}
    for char in str(text or ''):
        if char.isalpha():
            name = next((name for name, chars in _ALPHABETS if chars.match(char)), 'other')
            counts[name] = counts.get(name, 0) + 1
    letters = sum(counts.values())
    if not letters:
        return '', 0.0, 0.0
    best = max(counts, key=counts.get)
    cjk = counts.get('han', 0) + counts.get('kana', 0)
    kana = counts.get('kana', 0) / float(cjk) if cjk else 0.0
    if best in ('han', 'kana'):
        return best, cjk / float(letters), kana       # Japanese writes with both
    return best, counts[best] / float(letters), kana


def spoken(text):
    """(language, share of its words that are that language's common ones, {language: share}) of ``text``; a
    language known only by its alphabet has the alphabet's share. Serbian in Cyrillic is 'sr'."""
    words = [w.lower() for w in _TOKEN.findall(str(text or ''))]
    if len(words) < LEAST:
        return '', 0.0, {}
    written, part, kana = alphabet(text)
    if written in ('han', 'kana') and part >= MOSTLY:
        return ('ja' if kana >= KANA else 'zh'), part, {}
    if written in _SAID and part >= MOSTLY:
        return _SAID[written], part, {}
    shares = {code: sum(1 for w in words if w in common) / float(len(words)) for code, common in _WORDS.items()}
    best = max(shares, key=shares.get)
    return ('sr' if best == 'hr' and written == 'cyrillic' else best), shares[best], shares


def speaks(text, wanted):
    """False only when ``text`` clearly is another language than ``wanted`` (an ISO 639-1 code)."""
    raw = str(wanted or '').lower()
    wanted = _group(raw)
    if len(_TOKEN.findall(str(text or ''))) < LEAST:
        return True                                   # too few words to tell
    written, part, kana = alphabet(text)
    alphabets = _WRITTEN.get(raw) or _WRITTEN.get(wanted)
    if alphabets and part >= MOSTLY and written not in alphabets:
        return False                                  # another alphabet (a Croatian one in Cyrillic, a Greek one in Latin)
    if raw == 'ja' and written in ('han', 'kana') and kana < KANA:
        return False                                  # Chinese: no kana at all
    if raw == 'zh' and written in ('han', 'kana') and kana >= KANA:
        return False                                  # Japanese
    if wanted not in _WORDS:
        return True                                   # a language not known here by its words: its alphabet was all
    best, share, shares = spoken(text)
    best = _group(best)
    if best == wanted or any(best in near and wanted in near for near in _NEAR):
        return True
    return not (share >= CLEAR and share >= TIMES * shares.get(wanted, 0.0))


def name(code):
    return {'hr': 'Croatian', 'sr': 'Serbian', 'sl': 'Slovenian', 'en': 'English', 'de': 'German', 'fr': 'French',
            'es': 'Spanish', 'it': 'Italian', 'pt': 'Portuguese', 'nl': 'Dutch', 'pl': 'Polish', 'cs': 'Czech',
            'hu': 'Hungarian', 'ro': 'Romanian', 'tr': 'Turkish', 'sv': 'Swedish', 'da': 'Danish', 'no': 'Norwegian',
            'fi': 'Finnish', 'ru': 'Russian', 'uk': 'Ukrainian', 'bg': 'Bulgarian', 'mk': 'Macedonian',
            'el': 'Greek', 'ar': 'Arabic', 'he': 'Hebrew', 'th': 'Thai', 'zh': 'Chinese', 'ja': 'Japanese',
            'ko': 'Korean', 'hi': 'Hindi', 'bn': 'Bengali', 'ta': 'Tamil', 'te': 'Telugu', 'kn': 'Kannada',
            'ml': 'Malayalam', 'ka': 'Georgian', 'hy': 'Armenian'}.get(code, code)
