"""MegaNexus screensaver entry point.

7.0.27: the screen starts fading to black at once - a plain black curtain shown
before any MegaNexus code loads (loading it took a second or more on TV
boxes, so the screensaver used to appear a moment after Kodi started it). The
screensaver opens behind the curtain, which goes once it is ready.
"""
import os
import sys
import time

import xbmcaddon
import xbmcgui

WHITE = 'special://home/addons/script.meganexus/resources/media/white.png'


class Curtain(object):
    """A black layer over everything that fades in for one second."""

    def __init__(self):
        self.window = None
        self.shown = time.monotonic()
        try:
            self.window = xbmcgui.WindowDialog()
            black = xbmcgui.ControlImage(0, 0, 1280, 720, WHITE, colorDiffuse='FF000000')
            self.window.addControl(black)
            black.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=1000 tween=sine easing=inout')])
            self.window.show()
            self.shown = time.monotonic()
        except Exception as exc:
            import xbmc
            xbmc.log('[MegaNexus] Screensaver curtain unavailable: %r' % exc, xbmc.LOGWARNING)
            self.window = None

    def black(self):
        """Fully dark (the fade has run)."""
        return self.window is None or time.monotonic() - self.shown >= 1.0

    def close(self):
        if self.window is not None:
            try:
                self.window.close()
            except Exception:
                pass
            self.window = None


if __name__ == '__main__':
    curtain = Curtain()
    try:
        backend = xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('path')
        frontend = xbmcaddon.Addon('script.meganexus').getAddonInfo('path')
        for path in (backend, os.path.join(backend, 'resources', 'lib'), frontend):
            if path not in sys.path:
                sys.path.insert(0, path)
        from meganexus_ui.saver import launch
        launch(curtain)
    finally:
        curtain.close()
