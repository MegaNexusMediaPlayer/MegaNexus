# MegaNexus - Copyright (c) 2024-2026 MegaNexusMediaPlayer. All rights reserved.
# MegaNexus License (LICENSE.md): no redistribution, no modified versions and no use
# of this code to train, fine-tune or prompt AI models without written permission.
"""MegaNexus screensaver entry point."""
import os
import sys
import xbmcaddon

backend=xbmcaddon.Addon('plugin.video.meganexus').getAddonInfo('path')
frontend=xbmcaddon.Addon('script.meganexus').getAddonInfo('path')
for path in (backend,os.path.join(backend,'resources','lib'),frontend):
    if path not in sys.path:sys.path.insert(0,path)

if __name__=='__main__' and len(sys.argv)>1:
    from meganexus_ui.saver import run_video
    run_video(sys.argv[1])
