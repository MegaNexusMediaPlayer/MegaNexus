# Source acknowledgements

The logo mark, wordmark, banner, screensaver artwork and add-on icons are the project's own MegaNexus artwork.

Collection artwork of the built-in Cinemeta collections is MegaNexus's own (`review/make_collection_covers.py`; text in Noto Sans, SIL Open Font License). Collections imported from Nuvio or add-ons show the pictures their own links point to; those are not bundled. Streaming service marks identify catalog categories; they do not grant subscription access.

TheIntroDB API is used for segment timing, according to its public v3 API. No upstream updater, analytics service or account-submission code is included.
